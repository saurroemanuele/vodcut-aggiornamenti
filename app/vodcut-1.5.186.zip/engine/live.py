"""NoonFrame - le live (VOD di Twitch, Kick, YouTube): montaggio per YouTube e clip verticali virali con l'AI.

Una live e' diversa da un video parlato: tanti minuti di gioco senza parole, attese, menu, lettura della chat,
e poi reazioni forti di pochi secondi. Qui si guardano insieme le parole (trascrizione) e il volume (urli, risate,
esplosioni del gioco) e l'AI valuta pezzi di live, non singole parole.

- montaggio: la live divisa in blocchi di 15-45 s; l'AI da' un voto a ogni blocco (quanto e' interessante in un video
  di highlight), si tengono i migliori fino alla durata scelta, si tolgono i silenzi senza azione, zoom sulle reazioni
  e scritte meme sui momenti forti. Esce lo stesso piano del Montaggio AI (pause, tagli, zoom, scritte).
- clip: l'AI cerca i momenti che funzionano da soli come Short/TikTok (inizio che aggancia, fine con il payoff),
  con un punteggio di viralita' 0-100, un titolo, una scritta d'apertura e il motivo del punteggio.
"""
import json
import re

import numpy as np

from engine import ai
from engine import analyze as A

LENGTHS = {   # quanto della live resta nel video per YouTube
    "highlights": {"keep": 0.30, "gap": 1.4, "drop": 4, "name": "Solo i momenti migliori"},
    "normale": {"keep": 0.55, "gap": 2.2, "drop": 3, "name": "Video completo e ritmato"},
    "leggero": {"keep": 0.85, "gap": 3.5, "drop": 2, "name": "Togli solo i tempi morti"},
}
MEME_LOOKS = ("punch", "yellow", "wow", "orange", "greenhl")


# ------------------------------------------------------------------ segnali: parole e volume, secondo per secondo
def sec_levels(db, dur):
    """Volume di ogni secondo (dB, il 90esimo percentile dentro il secondo)."""
    db = np.asarray(db if db is not None else [], dtype=np.float32)
    n = max(1, int(np.ceil(dur)))
    per = max(1, int(round(1.0 / A.HOP)))
    out = np.full(n, -90.0, np.float32)
    for s in range(n):
        seg = db[s * per:(s + 1) * per]
        if len(seg):
            out[s] = float(np.percentile(seg, 90))
    return out


def speech_mask(words, dur):
    n = max(1, int(np.ceil(dur)))
    m = np.zeros(n, bool)
    for w in words:
        m[max(0, int(w["a"])):min(n, int(w["b"]) + 1)] = True
    return m


def level_stats(lev, speech):
    voiced = lev[speech] if speech.any() else lev
    med = float(np.median(voiced)) if len(voiced) else -30.0
    floor = float(np.percentile(lev, 10)) if len(lev) else -60.0
    return med, floor


def peaks(lev, med, min_gap=6):
    """Secondi con un picco forte (urlo, risata, esplosione): sopra la voce normale di almeno 6 dB."""
    thr = med + 6.0
    out = []
    for s in np.argsort(-lev):
        if lev[s] < thr:
            break
        if all(abs(int(s) - p) >= min_gap for p in out):
            out.append(int(s))
    return sorted(out)


def removed_ranges(proj):
    return sorted((float(s["a"]), float(s["b"])) for s in proj.get("segs") or [] if s.get("removed"))


def _cut_in(t, rs):
    return any(a - 0.01 <= t <= b + 0.01 for a, b in rs)


def _kept_len(a, b, rs):
    tot = b - a
    for ra, rb in rs:
        lo, hi = max(a, ra), min(b, rb)
        if hi > lo:
            tot -= hi - lo
    return max(0.0, tot)


# ------------------------------------------------------------------ frasi e blocchi
def units(words):
    """Frasi (o pezzi di frase): si spezza su punto/domanda/esclamazione, pausa vera o frase troppo lunga."""
    out, cur = [], []
    for i, w in enumerate(words):
        if cur and (w["a"] - words[i - 1]["b"] > 1.2 or len(cur) >= 22):
            out.append(cur)
            cur = []
        cur.append(i)
        if w["w"][-1:] in ".?!" and len(cur) >= 3:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return [{"a": words[u[0]]["a"], "b": words[u[-1]]["b"], "i": u[0], "j": u[-1]} for u in out]


def blocks(words, lev, dur, rs, target=30.0, max_len=48.0):
    """La live in blocchi di circa 30 s che finiscono a fine frase. I lunghi pezzi senza parole (solo gioco)
    diventano blocchi a se': l'AI li giudica dal volume (azione) e dal parlato intorno."""
    us = units(words)
    out = []
    t = 0.0
    cur = None

    def close(b):
        nonlocal cur
        if cur and b - cur["a"] > 0.3:
            cur["b"] = b
            out.append(cur)
        cur = None
    for u in us:
        if u["a"] - t > 6.0:   # silenzio lungo prima di questa frase: blocco di solo gioco
            close(t)
            g0 = t
            while u["a"] - g0 > 0.3:
                g1 = min(u["a"], g0 + max_len)
                out.append({"a": g0, "b": g1, "i": None, "j": None, "silent": True})
                g0 = g1
        if cur is None:
            cur = {"a": u["a"] if u["a"] - t > 6.0 else t, "i": u["i"], "j": u["j"]}
        cur["j"] = u["j"]
        t = u["b"]
        if t - cur["a"] >= target:
            close(t)
    close(t)
    if dur - t > 0.5:
        g0 = t
        while dur - g0 > 0.3:
            g1 = min(dur, g0 + max_len)
            out.append({"a": g0, "b": g1, "i": None, "j": None, "silent": True})
            g0 = g1
    med, _ = level_stats(lev, speech_mask(words, dur))
    res = []
    for n, b in enumerate(out):
        s0, s1 = int(b["a"]), max(int(b["a"]) + 1, int(np.ceil(b["b"])))
        seg = lev[s0:s1] if s1 <= len(lev) else lev[s0:]
        loud = float(seg.max() - med) if len(seg) else -20.0
        kept = _kept_len(b["a"], b["b"], rs)
        txt = " ".join(words[k]["w"] for k in range(b["i"], b["j"] + 1)) if b.get("i") is not None else ""
        res.append({"n": n, "a": round(b["a"], 2), "b": round(b["b"], 2), "i": b.get("i"), "j": b.get("j"), "text": txt,
                    "silent": bool(b.get("silent")), "loud": round(loud, 1), "kept": kept,
                    "peak_t": round(s0 + int(np.argmax(seg)) + 0.5, 1) if len(seg) else b["a"]})
    return res


def _block_line(b):
    tag = []
    if b["loud"] >= 9:
        tag.append("VOLUME MOLTO ALTO (urlo/risata/azione)")
    elif b["loud"] >= 5:
        tag.append("volume alto")
    if b["silent"]:
        tag.append("nessuno parla, solo gioco")
    head = f"#{b['n']} [{b['a']:.0f}-{b['b']:.0f}s]" + (f" ({', '.join(tag)})" if tag else "")
    txt = b["text"]
    if len(txt) > 420:
        txt = txt[:300] + " ... " + txt[-110:]
    return head + (": " + txt if txt else "")


def _lang(proj):
    # lingua scelta dal creator prima di cercare le clip, altrimenti quella riconosciuta nella trascrizione
    return (proj.get("subLang") or (proj.get("transcript") or {}).get("language") or "it").lower()[:2]


LANG_NAME = {"it": "italiano", "en": "inglese", "es": "spagnolo", "fr": "francese", "de": "tedesco", "pt": "portoghese"}


# ------------------------------------------------------------------ montaggio della live per YouTube
EDIT_SYSTEM = ("Sei il montatore di highlight di live (Twitch, Kick, YouTube Gaming) piu' bravo al mondo: dai VOD di ore tiri fuori "
               "video per YouTube che non annoiano mai, come i migliori canali di highlight. Ricevi la live divisa in blocchi numerati "
               "(tempo in secondi, volume, quello che viene detto). Dai a OGNI blocco un voto s da 0 a 10: quanto merita di stare in un "
               "video di highlight.\n"
               "ALTI (7-10): reazioni forti e genuine (urli, spaventi, risate), momenti divertenti con battuta e payoff, giocate epiche, fail, "
               "rage, storie interessanti raccontate bene, interazioni divertenti con la chat o con gli altri, colpi di scena.\n"
               "MEDI (4-6): gioco con commento vivo, contesto che serve a capire un momento forte subito dopo.\n"
               "BASSI (0-3): attese, menu, caricamenti, \"aspetta che sistemo\", problemi tecnici, ringraziamenti e letture di donazioni "
               "ripetitive, saluti a chi entra, silenzio senza azione, frasi spezzate senza senso, chiacchiere che non portano a niente.\n"
               "Un blocco di solo gioco con VOLUME ALTO puo' essere azione forte: giudicalo anche da cosa si dice prima e dopo.\n"
               "Per i blocchi con voto 7 o piu' scrivi anche: z = il secondo esatto del picco della reazione (per uno zoom sulla webcam); "
               "t = SOLO se il momento e' davvero forte, una scritta meme di 1-3 parole nella lingua della live (es. \"NO WAY\", "
               "\"SPAVENTO\", \"CHE GIOCATA\"), altrimenti niente; k = una parola sul tipo (reazione, comico, epico, fail, storia, chat).\n"
               "Rispondi SOLO con JSON compatto: {\"summary\": \"di cosa parla questa parte della live, una frase\", "
               "\"blocks\": [{\"n\": 0, \"s\": 3}, {\"n\": 1, \"s\": 8, \"k\": \"reazione\", \"z\": 51.5, \"t\": \"NO WAY\"}]}. "
               "Tutti i blocchi devono avere un voto. Niente altro testo.")


def _read_obj(raw, key):
    try:
        obj = ai.parse_json(raw)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    items = []
    for m in re.finditer(r"\{[^{}]*\}", raw or ""):
        try:
            items.append(json.loads(m.group(0)))
        except Exception:
            try:
                items.append(json.loads(ai._repair_json(m.group(0))))
            except Exception:
                continue
    m = re.search(r'"summary"\s*:\s*"((?:[^"\\]|\\.)*)"', raw or "")
    return {"summary": json.loads('"' + m.group(1) + '"') if m else "", key: items} if items else None


def rate_blocks(proj, bl, cfg, cancel=None, progress=None, prompt=""):
    """Voto dell'AI per ogni blocco (a gruppi). -> (voti per numero di blocco, riassunto, costo)"""
    rated, summary, usd = {}, "", 0.0
    groups = [bl[i:i + 55] for i in range(0, len(bl), 55)]
    lang = LANG_NAME.get(_lang(proj), _lang(proj))
    for gi, g in enumerate(groups):
        if cancel and cancel():
            raise ai.AIError("Annullato")
        if progress:
            progress(gi / max(1, len(groups)), "L'AI guarda la live" + (f" ({gi + 1}/{len(groups)})" if len(groups) > 1 else ""))
        user = (f"Lingua della live: {lang}. Parte {gi + 1} di {len(groups)}." +
                (f"\nRICHIESTA DEL CREATOR (ha la precedenza): {prompt.strip()[:600]}" if (prompt or "").strip() else "") +
                "\n\nBLOCCHI:\n" + "\n".join(_block_line(b) for b in g))
        raw = ai.text(cfg, EDIT_SYSTEM, user, max_tokens=6000, cancel=cancel)
        usd += ai.text_usd(cfg.get("model"), EDIT_SYSTEM, user, raw)
        obj = _read_obj(raw, "blocks")
        if obj is None:
            raw = ai.text(cfg, EDIT_SYSTEM, user + "\nRispondi solo con il JSON, compatto e chiuso.", max_tokens=6000, cancel=cancel)
            usd += ai.text_usd(cfg.get("model"), EDIT_SYSTEM, user, raw)
            obj = _read_obj(raw, "blocks") or {}
        summary = summary or str(obj.get("summary") or "")
        ok = {b["n"] for b in g}
        for x in obj.get("blocks") or []:
            try:
                n = int(x.get("n"))
            except (TypeError, ValueError, AttributeError):
                continue
            if n in ok:
                try:
                    s = max(0.0, min(10.0, float(x.get("s"))))
                except (TypeError, ValueError):
                    s = 4.0
                z = x.get("z")
                try:
                    z = float(z) if z is not None else None
                except (TypeError, ValueError):
                    z = None
                rated[n] = {"s": s, "k": str(x.get("k") or "")[:16], "z": z, "t": str(x.get("t") or "").strip()[:28]}
    return rated, summary, usd


def heuristic_score(b):
    """Voto senza AI (per i blocchi che l'AI ha saltato): volume e quantita' di parlato."""
    s = 4.0 + max(-3.0, min(4.0, b["loud"] / 2.5))
    if b["silent"] and b["loud"] < 4:
        s = 1.5
    return round(s, 1)


def edit_plan(proj, db, cfg, length="normale", opts=None, prompt="", cancel=None, progress=None, words=None):
    """Piano di montaggio della live, nello stesso formato del Montaggio AI: items pause/cut/zoom/text (tempi della timeline)."""
    opts = opts or {}
    L = LENGTHS.get(length) or LENGTHS["normale"]
    from engine import aiedit as AE
    words = words if words is not None else AE.words_of(proj)
    if len(words) < 5:
        raise ai.AIError("Serve la trascrizione della live: premi \"Trascrivi il video\" e riprova")
    dur = float(proj.get("duration") or words[-1]["b"])
    rs = removed_ranges(proj)
    lev = sec_levels(db, dur)
    sp = speech_mask(words, dur)
    med, floor = level_stats(lev, sp)
    bl = [b for b in blocks(words, lev, dur, rs) if b["kept"] > 0.5]
    if not bl:
        raise ai.AIError("Non c'e' niente da montare: e' tutto gia' tagliato")
    rated, summary, usd = rate_blocks(proj, bl, cfg, cancel, (lambda x, m: progress(0.05 + 0.8 * x, m)) if progress else None, prompt)
    for b in bl:
        r = rated.get(b["n"]) or {"s": heuristic_score(b), "k": "", "z": None, "t": ""}
        b.update(score=r["s"], kind=r["k"], z=r["z"], meme=r["t"])
    if progress:
        progress(0.88, "Scelgo i momenti migliori")
    total = sum(b["kept"] for b in bl)
    keep = set()
    # i momenti forti restano sempre, quelli brutti vanno sempre via; in mezzo si sceglie per voto fino alla durata
    for b in bl:
        if b["score"] >= 7.5:
            keep.add(b["n"])
    acc = sum(b["kept"] for b in bl if b["n"] in keep)
    for b in sorted(bl, key=lambda x: (-x["score"], -x["loud"])):
        if b["n"] in keep or b["score"] < L["drop"]:
            continue
        if acc >= L["keep"] * total:
            break
        keep.add(b["n"])
        acc += b["kept"]
    if not keep:   # nessun voto sopra la soglia: si tiene comunque il meglio che c'e'
        best = max(bl, key=lambda x: x["score"])
        keep.add(best["n"])
    byn = {b["n"]: b for b in bl}
    ordered = sorted(bl, key=lambda x: x["a"])
    # contesto: prima di un momento forte si tengono gli ultimi secondi del blocco prima (la domanda prima della risposta)
    lead = {}
    for k, b in enumerate(ordered):
        if b["n"] in keep and b["score"] >= 8 and k > 0 and ordered[k - 1]["n"] not in keep and not ordered[k - 1]["silent"]:
            p = ordered[k - 1]
            st = max(p["a"], b["a"] - 7.0)
            for u in units([w for w in words if p["a"] <= w["a"] < b["a"]]):
                if u["a"] >= st:
                    st = u["a"]
                    break
            lead[b["n"]] = st
    kept_ranges = []
    for b in ordered:
        if b["n"] in keep:
            a0 = lead.get(b["n"], b["a"])
            if kept_ranges and a0 <= kept_ranges[-1][1] + 0.05:
                kept_ranges[-1][1] = b["b"]
            else:
                kept_ranges.append([a0, b["b"]])
    items = []
    if opts.get("cuts", True):
        t = 0.0
        for a, b in kept_ranges + [[dur, dur]]:
            if a - t > 0.4:
                ca, cb = t, a
                # tagli che non spezzano le parole: si allarga ai bordi delle parole vicine
                for w in words:
                    if w["a"] < ca < w["b"]:
                        ca = w["a"]
                    if w["a"] < cb < w["b"]:
                        cb = w["b"]
                txt = " ".join(w["w"] for w in words if ca <= w["a"] and w["b"] <= cb)
                items.append({"type": "cut", "a": round(ca, 3), "b": round(cb, 3), "why": "parte lenta",
                              "text": (txt[:150] + ("…" if len(txt) > 150 else "")) if txt else "solo gioco, niente di forte"})
            t = max(t, b)
    if opts.get("pauses", True):
        # silenzi senza azione dentro le parti tenute
        quiet = med - 6.0
        for a, b in kept_ranges:
            s = int(a)
            while s < int(b):
                if not sp[s] and lev[s] < quiet:
                    e = s
                    while e < int(b) and not sp[e] and lev[e] < quiet:
                        e += 1
                    if e - s >= L["gap"]:
                        pa, pb = s + 0.35, e - 0.35
                        if pb - pa > 0.5 and not any(w["a"] < pb and pa < w["b"] for w in words):
                            items.append({"type": "pause", "a": round(pa, 2), "b": round(pb, 2), "why": "silenzio"})
                    s = e
                s += 1
    in_keep = lambda t: any(a <= t <= b for a, b in kept_ranges)
    if opts.get("zooms", True):
        last = -99.0
        for b in sorted((byn[n] for n in keep), key=lambda x: x["a"]):
            z = b.get("z") if b.get("z") is not None and b["a"] - 1 <= b["z"] <= b["b"] + 1 else (b["peak_t"] if b["loud"] >= 6 else None)
            if z is None or not in_keep(z) or z - last < 12:
                continue
            za, zb = max(b["a"], z - 1.2), min(b["b"], z + 3.6)
            if zb - za >= 2.0:
                items.append({"type": "zoom", "a": round(za, 2), "b": round(zb, 2), "level": 1.4, "style": "scatto",
                              "why": b.get("kind") or "reazione"})
                last = z
    if opts.get("texts", True):
        looks = [k for k in ((opts.get("lv") or {}).get("looks") or []) if k in MEME_LOOKS] or list(MEME_LOOKS[:3])
        last, nt = -99.0, 0
        for b in sorted((byn[n] for n in keep if byn[n].get("meme")), key=lambda x: -x["score"]):
            t0 = b["z"] if b.get("z") is not None and in_keep(b["z"]) else b["a"] + 0.5
            if abs(t0 - last) < 25 or nt >= max(2, int(total / 60)):
                continue
            items.append({"type": "text", "a": round(t0, 2), "b": round(t0 + 2.4, 2), "text": b["meme"].upper(),
                          "look": looks[nt % len(looks)], "why": b.get("kind") or "momento forte"})
            last, nt = t0, nt + 1
    items = AE._tidy(items, dur)
    for n, it in enumerate(items):
        it["id"] = f"i{n}"
    out_len = sum(b - a for a, b in kept_ranges) - sum(i["b"] - i["a"] for i in items if i["type"] == "pause")
    if not summary:
        summary = "Montaggio della live"
    summary = f"{summary} Da {fmt_min(total)} a circa {fmt_min(out_len)} ({L['name'].lower()})."
    return {"summary": summary, "items": items, "usd": round(usd, 4), "words": len(words),
            "live": {"length": length, "from": round(total, 1), "to": round(out_len, 1), "blocks": len(bl)}}


def fmt_min(s):
    s = int(round(s))
    return f"{s // 60} min" if s >= 120 else f"{s} s"


# ------------------------------------------------------------------ clip verticali virali (stile Opus)
CLIP_SYSTEM = ("Sei il miglior editor di Shorts, TikTok e Reels: sai riconoscere al primo colpo i momenti di un video lungo (live di "
               "gaming, podcast, intervista, chiacchierata, video) che fanno milioni di visualizzazioni. Ricevi un pezzo del video: righe "
               "con il tempo in secondi, quello che viene detto e i momenti con il volume molto alto (urli, risate, azione). Trova i "
               "momenti che funzionano DA SOLI come video verticale.\n"
               "Una clip buona: aggancia nei primi 2 secondi (una frase forte, una domanda, l'inizio di una reazione, una situazione "
               "assurda, un numero che sorprende), si capisce senza aver visto il resto del video, ha un payoff (la battuta, lo "
               "spavento, la giocata, la reazione, la rivelazione, la risposta) e finisce subito dopo. Durata 15-60 secondi (meglio "
               "20-45). Mai iniziare a meta' frase, mai finire prima del payoff.\n"
               "Apertura e chiusura contano quanto il momento: la prima frase si regge da sola (mai una risposta senza la sua "
               "domanda, mai un nome o una parola buttata li', mai una reazione a qualcosa successo prima che nella clip non si "
               "vede, mai un pezzetto di frase staccato dal resto da una pausa); l'ultima frase e' finita e chiude il discorso "
               "(il payoff o il commento subito dopo), mai un commento staccato dopo una pausa, mai l'inizio di un discorso nuovo.\n"
               "Nei podcast e nelle interviste i momenti piu' forti sono: una storia personale con un finale, un'opinione forte o "
               "controcorrente, numeri e soldi (quanto si guadagna, quanto costa, quanto si e' perso o investito), un consiglio "
               "pratico da usare subito, un retroscena o una confessione, una battuta, un momento emozionante, uno scontro di idee. "
               "Se la clip risponde a una domanda, comincia dalla domanda (se e' breve) o dalla frase che fa capire di cosa si parla. "
               "Guarda tutto il pezzo: i momenti migliori possono essere ovunque, anche verso la fine.\n"
               "Mai clip dalla schermata d'attesa iniziale (starting soon, solo musica o testi di canzoni), dalle pause (BRB) o "
               "dalla fine/outro: li' non c'e' nessuno o non succede niente.\n"
               "Titoli e scritte (il copy) devono sembrare scritti da un creator bravo, non da un'AI: specifici su QUELLO che succede "
               "in quel momento (cosa dice, il gioco, la persona, la situazione), parole vere della live quando funzionano, niente frasi "
               "generiche da clickbait (\"Incredibile!\", \"Non ci crederai\", \"Momento epico\", \"Guarda fino alla fine\"), niente "
               "emoji a raffica, niente maiuscole su tutto. Il titolo incuriosisce senza svelare il payoff.\n"
               "Per ogni clip: from e to (secondi), title (titolo stile YouTube Shorts/TikTok, max 60 caratteri, nella lingua "
               "della live, senza hashtag), hook (scritta d'apertura a schermo di 2-5 parole, nella lingua della live: una frase che "
               "aggancia nei primi 2 secondi, detta come la direbbe chi parla), kw (2-3 parole prese tali e quali dal title, "
               "quelle da colorare quando il titolo va a schermo: nomi, numeri, la cosa che succede; mai articoli o parole vuote), score (0-100: "
               "quanto e' probabile che diventi virale; 90+ solo per momenti eccezionali, sii severo e realista), why (perche' ha questo "
               "punteggio, una frase breve in italiano, concreta: cosa succede e perche' tiene), k (comico, spavento, epico, fail, rage, "
               "storia, chat, wholesome), pf (dove funzionerebbe meglio: punteggio 0-100 per tiktok, reels (Instagram) e shorts (YouTube), pensando a chi guarda su ognuna: TikTok premia reazioni, caos, trend e ritmo veloce; Reels premia momenti belli da vedere, relazioni, wholesome e cose da mandare agli amici; Shorts premia giocate, storie complete, momenti da gamer e titoli che fanno cercare. Le tre piattaforme devono avere punteggi diversi quando il contenuto e' piu' adatto a una; non mettere sempre davanti TikTok: in una live normale la migliore cambia da clip a clip (le giocate e le storie con un finale spesso vanno meglio su Shorts, i momenti belli o teneri su Reels)), pfw (perche' la migliore, una frase breve in italiano).\n"
               "Rispondi SOLO con JSON compatto: {\"clips\": [{\"from\": 120.5, \"to\": 151.0, \"title\": \"...\", \"hook\": \"...\", "
               "\"kw\": [\"...\", \"...\"], \"score\": 84, \"why\": \"...\", \"k\": \"comico\", \"pf\": {\"tiktok\": 64, \"reels\": 58, \"shorts\": 81}, \"pfw\": \"...\"}]}. Ordina per score. Niente altro testo.")

RANK_SYSTEM = ("Sei il miglior editor di Shorts per streamer. Hai una lista di clip candidate della stessa live (con titolo, durata, "
               "cosa succede). Confrontale tra loro e dai a ognuna il punteggio di viralita' finale 0-100, coerente su tutta la lista: "
               "90+ solo per le eccezionali, 70-89 molto forti, 50-69 buone, sotto 50 deboli. Migliora i titoli quando sono generici: "
               "specifici sul momento, naturali come li scriverebbe un creator, senza clickbait vuoto. "
               "Rispondi SOLO con JSON: {\"clips\": [{\"id\": 0, \"score\": 88, \"title\": \"...\", \"why\": \"...\"}]}")


REFINE_SYSTEM = ("Sei un montatore esperto di clip verticali (TikTok, Reels, Shorts) e correggi i sottotitoli. Per ogni clip ricevi il "
                 "testo parola per parola, con il numero di ogni parola (#numero parola) e il tempo in secondi a inizio riga, e da "
                 "dove a dove l'aveva messa l'editor.\n"
                 "1) INIZIO E FINE: scegli il numero della prima e dell'ultima parola. La clip comincia all'inizio di una frase e fa "
                 "capire subito di cosa si parla: se per capire serve la domanda o la frase prima, includila; se c'e' un preambolo che "
                 "non serve, toglilo. Finisce quando il pensiero e' concluso, dopo il payoff (la battuta, la rivelazione, la risposta, "
                 "la reazione): MAI a meta' frase, mai con l'inizio di un discorso nuovo. Durata tra 15 e 75 secondi. Resta vicino "
                 "alla scelta dell'editor: sposta solo quanto serve.\n"
                 "La prima parola apre una frase che si capisce da sola: mai una risposta senza la sua domanda (se la domanda e' "
                 "subito prima, includila), mai un nome, un saluto o una parola buttata li', mai una reazione a qualcosa successo "
                 "prima della clip, mai un pezzetto staccato dal resto da una pausa (le righe segnate \"pausa\" vengono dopo un "
                 "silenzio). L'ultima parola chiude una frase finita: mai un commento buttato li' dopo una pausa, mai l'inizio di "
                 "una frase nuova, mai una parola a meta'.\n"
                 "2) PAROLE SBAGLIATE: la trascrizione automatica a volte sbaglia (parole che suonano simili, nomi di persone e "
                 "aziende, parole spezzate). Correggi SOLO le parole sicuramente sbagliate guardando il senso della frase: per ognuna "
                 "il numero e la parola giusta (anche due parole se ne serve una in piu'). Non cambiare lo stile, non togliere "
                 "intercalari o ripetizioni, non tradurre, non correggere la grammatica di chi parla.\n"
                 "Rispondi SOLO con JSON compatto: {\"clips\": [{\"id\": 0, \"from\": 1520, \"to\": 1640, "
                 "\"fix\": [{\"i\": 1533, \"w\": \"secondo\"}]}]}. Niente altro testo.")


def _refine_block(words, c, i, rs, ctx=25.0):
    """Il testo di una clip per la seconda passata: parole numerate da ctx secondi prima a ctx dopo."""
    idx = [k for k, w in enumerate(words) if c["a"] - ctx <= w["a"] <= c["b"] + ctx and not _cut_in(w["a"], rs)]
    if len(idx) < 8:
        return None, idx
    i0 = next((k for k in idx if words[k]["a"] >= c["a"] - 0.3), idx[0])
    i1 = max((k for k in idx if words[k]["a"] <= c["b"]), default=idx[-1])
    lines, cur, last, seg = [], [], None, None
    for k in idx:
        w = words[k]
        sg = str(w.get("k") or "").split("_")[0]
        if last is None or w["a"] - last > 1.0 or sg != seg or len(cur) >= 16:
            if cur:
                lines.append(" ".join(cur))
            # un silenzio lungo prima della riga si vede: un pezzetto staccato non apre e non chiude la clip
            cur = [f"[{w['a']:.1f}]" + (f" (pausa {w['a'] - last:.0f} s)" if last is not None and w["a"] - last >= 1.5 else "")]
        cur.append(f"#{k} {w['w']}")
        last, seg = w["b"], sg
    if cur:
        lines.append(" ".join(cur))
    head = f"CLIP id {i} · titolo: {c.get('title', '')} · l'editor l'aveva messa da #{i0} a #{i1} ({c['b'] - c['a']:.0f} s)"
    return head + "\n" + "\n".join(lines), idx


def refine_clips(cfg, words, clips, dur, rs, lang, cancel=None, batch=4):
    """Seconda passata sulle clip scelte: inizio e fine precisi parola per parola (frasi intere, con il contesto che serve
    per capire e fino al payoff) e le parole trascritte male dentro le clip.
    Cambia a e b delle clip; -> (usd, correzioni [{"k": chiave della parola, "from": com'era, "w": giusta}])."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    blocks = []
    for i, c in enumerate(clips):
        txt, idx = _refine_block(words, c, i, rs)
        if txt:
            blocks.append((i, txt, set(idx)))
    if not blocks:
        return 0.0, []
    groups = [blocks[j:j + batch] for j in range(0, len(blocks), batch)]
    usd, fixes, lock = [0.0], {}, threading.Lock()

    def ask(g):
        if cancel and cancel():
            return
        user = f"Lingua del video: {lang}.\n\n" + "\n\n".join(t for _, t, _ in g)
        try:
            raw = ai.text(cfg, REFINE_SYSTEM, user, max_tokens=2500, cancel=cancel)
        except ai.AIError as e:
            print("[clip] seconda passata non riuscita:", str(e)[:160], flush=True)
            return
        obj = _read_obj(raw, "clips") or {}
        with lock:
            usd[0] += ai.text_usd(cfg.get("model"), REFINE_SYSTEM, user, raw)
        ids = {i: idx for i, _, idx in g}
        for x in obj.get("clips") or []:
            try:
                i = int(x.get("id"))
            except (TypeError, ValueError, AttributeError):
                continue
            if i not in ids:
                continue
            idx, c = ids[i], clips[i]
            try:
                f, t = int(x.get("from")), int(x.get("to"))
            except (TypeError, ValueError):
                f = t = None
            if f is not None and f in idx and t in idx and t > f:
                a = words[f]["a"] - min(0.25, max(0.06, (words[f]["a"] - words[f - 1]["b"] if f > 0 else 9.0) - 0.06))
                b = words[t]["b"] + min(0.6, max(0.12, (words[t + 1]["a"] - words[t]["b"] if t + 1 < len(words) else 9.0) - 0.12))
                a, b = max(0.0, a), min(dur, b)
                if 10.0 <= _kept_len(a, b, rs) and b - a <= 95.0:
                    with lock:
                        c["a"], c["b"] = round(a, 2), round(b, 2)
                        c["refined"] = True
            for fx in (x.get("fix") or [])[:30]:
                try:
                    k = int(fx.get("i"))
                    nw = re.sub(r"\s+", " ", str(fx.get("w") or "")).strip()
                except (TypeError, ValueError, AttributeError):
                    continue
                if k not in idx or not nw or len(nw) > 40 or nw == words[k]["w"] or not words[k].get("k"):
                    continue
                with lock:
                    fixes[words[k]["k"]] = {"k": words[k]["k"], "from": words[k]["w"], "w": nw}
    ex = ThreadPoolExecutor(max_workers=min(3, len(groups)))
    try:
        list(ex.map(ask, groups))
    finally:
        ex.shutdown(wait=True)
    return round(usd[0], 4), list(fixes.values())


def apply_word_fixes(tr, fixes):
    """Le parole corrette dalla seconda passata nella trascrizione (solo se la parola e' ancora quella di prima).
    -> quante cambiate."""
    segs = (tr or {}).get("segments") or []
    n = 0
    for fx in fixes or []:
        try:
            si, wi = (int(x) for x in str(fx.get("k")).split("_"))
            w = segs[si]["words"][wi]
        except (ValueError, IndexError, KeyError, TypeError):
            continue
        if str(w.get("w") or "").strip() == str(fx.get("from") or "") and fx.get("w"):
            w["w"] = str(fx["w"])
            n += 1
    return n


PLATFORMS = ("tiktok", "reels", "shorts")


def _read_pf(v):
    """Punteggio per piattaforma (TikTok, Reels, Shorts) dall'AI: solo numeri 0-100, altrimenti niente."""
    if not isinstance(v, dict):
        return None
    out = {}
    for k in PLATFORMS:
        try:
            out[k] = max(0, min(100, int(round(float(v.get(k))))))
        except (TypeError, ValueError):
            return None
    return out


def _clip_lines(words, lev, med, a, b, rs):
    lines, cur, last = [], [], None
    for w in words:
        if w["a"] < a or w["a"] > b:
            continue
        if _cut_in(w["a"], rs):
            continue
        gap = w["a"] - last if last is not None else 0
        if last is None or gap > 1.0 or len(cur) >= 18:
            if cur:
                lines.append(" ".join(cur))
            cur = [f"[{w['a']:.1f}]"]
        cur.append(w["w"])
        last = w["b"]
    if cur:
        lines.append(" ".join(cur))
    pk = [p for p in peaks(lev[int(a):int(b) + 1], med, 4)]
    if pk:
        lines.append("VOLUME MOLTO ALTO ai secondi: " + ", ".join(f"{int(a) + p}" for p in pk[:25]))
    return lines


def clip_target(dur_kept, talk=False):
    """Quante clip: nei video tutti parlati (podcast, interviste) una ogni ~3 minuti; nelle live almeno 8 per ogni ora
    (minimo 3 per i video corti). Al massimo 30."""
    m = dur_kept / 60.0
    if talk:
        return int(max(3, min(30, round(m / 3.0))))
    h = m / 60.0
    return max(3, min(30, int(round(8 * h)))) if h >= 0.25 else max(2, int(round(10 * h)) + 1)


def is_talk(words, kept):
    """Video tutto parlato (podcast, intervista, chiacchierata): tante parole al minuto, quasi senza pause."""
    return kept > 60 and len(words) / (kept / 60.0) >= 140


# parole che non chiudono mai una frase (articoli, preposizioni, congiunzioni, pronomi atoni, ausiliari)
_CONT = set("""il lo la i gli le l un uno una un' di a da in con su per tra fra del dello della dei degli delle al allo alla ai
agli alle dal dallo dalla dai dagli dalle nel nello nella nei negli nelle sul sullo sulla sui sugli sulle col che e ed o od
ma se non mi ti ci vi si ne gli è e' sono sei siamo siete ho hai ha abbiamo avete hanno sto stai sta stiamo state stanno
mio mia tuo tua suo sua nostro nostra vostro vostra loro questo questa quello quella cosa come quando dove perché perche
cioè cioe the a an of to and or but with for in on at from by is are was were be been am i you we they he she it my your
his her their our this that these those if so as than""".split())
# parole con cui comincia una frase nuova: una clip che finisce con una di queste ha appena attaccato un altro discorso
_OPEN = set("""allora quindi cioè cioe comunque però pero perché perche infatti insomma vabbè vabbe dunque invece anzi tipo
praticamente sostanzialmente niente aspetta senti guarda ascolta poi e' so then anyway well like and but because""".split())
_PUNCT_END = ".?!…"


def _bare(w):
    return re.sub(r"[^\wàèéìòùç']", "", str(w or "").lower())


def _edge_info(ws):
    """Per ogni parola: fine del suo pezzo di trascrizione (le frasi di Whisper), pausa prima e dopo."""
    n = len(ws)
    seg_end = []
    for j, w in enumerate(ws):
        k1 = str(w.get("k") or "").split("_")[0]
        k2 = str(ws[j + 1].get("k") or "").split("_")[0] if j + 1 < n else None
        seg_end.append(j + 1 >= n or (bool(k1) and k1 != k2))
    gap_after = [(ws[j + 1]["a"] - ws[j]["b"]) if j + 1 < n else 9.0 for j in range(n)]
    gap_before = [(ws[j]["a"] - ws[j - 1]["b"]) if j > 0 else 9.0 for j in range(n)]
    return seg_end, gap_after, gap_before


def _end_score(ws, j, seg_end, gap_after):
    """Quanto e' buono finire la clip dopo la parola j: frase finita (punto, domanda, esclamazione, fine del pezzo di
    Whisper), pausa vera dopo, la parola dopo che comincia una frase nuova. Mai dopo un articolo, una preposizione o
    una parola che attacca un discorso nuovo ("allora", "quindi")."""
    t = str(ws[j]["w"])
    g = gap_after[j]
    s = 0.0
    if t[-1:] in _PUNCT_END:
        s += 3.0
    elif t[-1:] in ",;:":
        s += 0.5
    if seg_end[j]:
        s += 1.2
    s += 2.6 if g >= 1.0 else 1.7 if g >= 0.6 else 0.8 if g >= 0.35 else (-0.9 if g < 0.12 else 0.0)
    nx = ws[j + 1]["w"] if j + 1 < len(ws) else ""
    if nx[:1].isupper() and t[-1:] != ",":
        s += 0.5
    if _bare(nx) in _OPEN and t[-1:] not in ",":
        s += 0.4
    if t[-1:] not in _PUNCT_END + ",;:":
        b = _bare(t)
        if b in _CONT:
            s -= 3.2
        elif b in _OPEN:
            s -= 2.2
    return s


def _start_score(ws, i, seg_end, gap_before):
    """Quanto e' buono cominciare la clip dalla parola i: la frase prima e' finita, c'e' una pausa, comincia una frase."""
    g = gap_before[i]
    s = 2.6 if g >= 1.0 else 1.7 if g >= 0.6 else 0.8 if g >= 0.35 else (-0.9 if g < 0.12 else 0.0)
    if i == 0:
        return s + 3.0
    p = str(ws[i - 1]["w"])
    if p[-1:] in _PUNCT_END:
        s += 3.0
    elif p[-1:] in ",;:":
        s += 0.3
    if seg_end[i - 1]:
        s += 1.2
    if str(ws[i]["w"])[:1].isupper():
        s += 0.5
    if p[-1:] not in _PUNCT_END + ",;:" and _bare(p) in _CONT:
        s -= 3.0          # la frase e' cominciata prima: si partirebbe a meta'
    return s


def _snap_clip(c, words, dur, rs, lo_len=12.0, hi_len=75.0):
    """Bordi della clip su frasi intere, precisi: si comincia dove comincia una frase e si finisce dove una frase (o
    un turno di parola) e' davvero finita, vicino a dove l'ha messa l'AI. Mai a meta' frase, mai con l'inizio del
    discorso dopo ("allora…"). Durata 12-75 s."""
    a0, b0 = max(0.0, c["a"]), min(dur, c["b"])
    ws = [w for w in words if not _cut_in(w["a"], rs)]
    if not ws:
        a, b = a0, b0
        if b - a < lo_len:
            b = min(dur, a + lo_len)
        return round(a, 2), round(min(b, a + hi_len), 2)
    seg_end, gap_after, gap_before = _edge_info(ws)
    # inizio: la frase che comincia vicino a dove l'ha messo l'AI (un po' prima va bene, dopo taglierebbe il gancio)
    best, bi = None, None
    for i, w in enumerate(ws):
        if w["a"] < a0 - 4.0 or w["a"] > a0 + 2.0 or w["a"] >= b0 - 3.0:
            continue
        d = w["a"] - a0
        sc = _start_score(ws, i, seg_end, gap_before) - (0.45 * -d if d < 0 else 0.8 * d)
        if best is None or sc > best:
            best, bi = sc, i
    if bi is None:
        bi = next((i for i, w in enumerate(ws) if w["a"] >= a0 - 0.4), None)
    if bi is None:
        a = a0
    else:
        a = max(0.0, ws[bi]["a"] - min(0.25, max(0.06, gap_before[bi] - 0.06)))

    # fine: dove la frase e' finita davvero. Un po' dopo l'AI va bene (si completa la frase), prima costa di piu'
    # (si rischia di togliere il finale)
    def pick(lo_t, hi_t):
        best, bj = None, None
        for j, w in enumerate(ws):
            if w["b"] < lo_t or w["b"] > hi_t or w["a"] < a + 1.0:
                continue
            ln = w["b"] - a
            if ln < lo_len - 0.01 or ln > hi_len:
                continue
            d = w["b"] - b0
            sc = _end_score(ws, j, seg_end, gap_after) - (0.3 * d if d > 0 else 0.6 * -d)
            if best is None or sc > best:
                best, bj = sc, j
        return best, bj
    best, bj = pick(b0 - 4.0, b0 + 7.0)
    if bj is None or _end_score(ws, bj, seg_end, gap_after) < 2.0:
        # niente fine di frase vicino: si cerca un po' piu' in la' (meglio qualche secondo in piu' che una frase a meta')
        b2, j2 = pick(b0 - 4.0, b0 + 15.0)
        if j2 is not None and _end_score(ws, j2, seg_end, gap_after) >= 2.0:
            bj = j2
        elif bj is None:
            bj = j2
    if bj is None:
        b = max(b0, a + lo_len)
    else:
        b = ws[bj]["b"] + min(0.6, max(0.12, gap_after[bj] - 0.12))
        nxt_a = ws[bj + 1]["a"] if bj + 1 < len(ws) else dur
        if nxt_a > b0 > b:
            # dopo l'ultima parola l'AI teneva ancora un attimo (la risata, la reazione): resta, fino a 2 s
            b = max(b, min(b0, nxt_a - 0.15, ws[bj]["b"] + 2.0))
    b = min(dur, b)
    if b - a < lo_len:
        b = min(dur, a + lo_len)
    if b - a > hi_len:
        b = a + hi_len
    return round(a, 2), round(b, 2)


def _ask_windows(cfg, todo, cancel=None, progress=None, workers=3):
    """I pezzi della live chiesti all'AI qualche alla volta insieme (una live di ore sono decine di pezzi: uno dopo
    l'altro erano un quarto d'ora). Le risposte tornano nell'ordine dei pezzi. Un pezzo che non passa (troppe richieste
    insieme) si richiede alla fine, da solo."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    out = [None] * len(todo)
    if not todo:
        return out
    lock, done = threading.Lock(), [0]

    def tick():
        with lock:
            done[0] += 1
            if progress:
                progress(done[0] / len(todo), f"Cerco i momenti virali ({done[0]}/{len(todo)})")

    def ask(i):
        if cancel and cancel():
            raise ai.AIError("Annullato")
        r = ai.text(cfg, CLIP_SYSTEM, todo[i][2], max_tokens=5000, cancel=cancel)
        tick()
        return r
    if progress:
        progress(0.0, f"Cerco i momenti virali (0/{len(todo)})")
    again = []
    ex = ThreadPoolExecutor(max_workers=max(1, min(workers, len(todo))))
    try:
        futs = [ex.submit(ask, i) for i in range(len(todo))]
        for i, f in enumerate(futs):
            try:
                out[i] = f.result()
            except ai.AIError as e:
                if "Annullato" in str(e) or (cancel and cancel()):
                    raise ai.AIError("Annullato")
                again.append(i)
    finally:
        ex.shutdown(wait=False, cancel_futures=True)
    for i in again:
        if cancel and cancel():
            raise ai.AIError("Annullato")
        out[i] = ai.text(cfg, CLIP_SYSTEM, todo[i][2], max_tokens=5000, cancel=cancel)
        tick()
    return out


def find_clips(proj, db, cfg, cancel=None, progress=None, words=None, n_target=None, prompt=""):
    """-> {"clips": [{a, b, title, hook, score, why, k}], "usd"} ordinate per punteggio."""
    from engine import aiedit as AE
    words = words if words is not None else AE.words_of(proj)
    if len(words) < 5:
        raise ai.AIError("Serve la trascrizione della live per trovare le clip")
    dur = float(proj.get("duration") or words[-1]["b"])
    rs = removed_ranges(proj)
    lev = sec_levels(db, dur)
    med, _ = level_stats(lev, speech_mask(words, dur))
    kept = _kept_len(0.0, dur, rs)
    n = n_target or clip_target(kept, is_talk([w for w in words if not _cut_in(w["a"], rs)], kept))
    lang = LANG_NAME.get(_lang(proj), _lang(proj))
    win, step = 480.0, 420.0   # finestre di 8 minuti che si sovrappongono di 1 (una clip a cavallo non si perde)
    starts = list(np.arange(0.0, max(1.0, dur - 60.0), step)) or [0.0]
    cands, usd = [], 0.0
    per_win = max(2, int(np.ceil(n * 1.8 * win / max(win, kept))) + 1)
    todo = []
    for wi, s in enumerate(starts):
        a, b = float(s), float(min(dur, s + win))
        lines = _clip_lines(words, lev, med, a, b, rs)
        if len([ln for ln in lines if not ln.startswith("VOLUME")]) < 2:
            continue
        user = (f"Lingua del video: {lang}. Pezzo dal secondo {a:.0f} al {b:.0f}. Trova fino a {per_win} clip (le migliori del pezzo, "
                f"anche meno se il pezzo e' debole)." + (f"\nRICHIESTA DEL CREATOR: {prompt.strip()[:500]}" if (prompt or "").strip() else "") +
                "\n\n" + "\n".join(lines))
        todo.append((a, b, user))
    raws = _ask_windows(cfg, todo, cancel, progress)
    for (a, b, user), raw in zip(todo, raws):
        usd += ai.text_usd(cfg.get("model"), CLIP_SYSTEM, user, raw)
        obj = _read_obj(raw, "clips") or {}
        for x in obj.get("clips") or []:
            try:
                ca, cb = float(x.get("from")), float(x.get("to"))
                sc = max(0, min(100, int(round(float(x.get("score"))))))
            except (TypeError, ValueError, AttributeError):
                continue
            if cb <= ca or ca < a - 30 or cb > b + 60:
                continue
            title = re.sub(r"#\w+", "", str(x.get("title") or "")).strip()[:70]
            if not title:
                continue
            kw = [re.sub(r"\s+", " ", w).strip()[:30] for w in (x.get("kw") if isinstance(x.get("kw"), list) else []) if isinstance(w, str)]
            cands.append({"a": ca, "b": cb, "title": title, "hook": str(x.get("hook") or "").strip()[:40], "kw": [w for w in kw if w][:4],
                          "score": sc, "why": str(x.get("why") or "").strip()[:220], "k": str(x.get("k") or "")[:14],
                          "pf": _read_pf(x.get("pf")), "pfWhy": str(x.get("pfw") or "").strip()[:200]})
    # bordi su frasi intere, niente doppioni (finestre sovrapposte)
    for c in cands:
        c["a"], c["b"] = _snap_clip(c, words, dur, rs)
        c["kept"] = _kept_len(c["a"], c["b"], rs)
        s0, s1 = int(c["a"]), max(int(c["a"]) + 1, int(c["b"]))
        seg = lev[s0:s1]
        c["energy"] = float(seg.max() - med) if len(seg) else 0.0
    cands = [c for c in cands if c["kept"] >= 8.0]
    uniq = []
    for c in sorted(cands, key=lambda x: -x["score"]):
        if all(min(c["b"], u["b"]) - max(c["a"], u["a"]) < 0.4 * min(c["b"] - c["a"], u["b"] - u["a"]) for u in uniq):
            uniq.append(c)
    # punteggio finale coerente su tutta la live (una chiamata sola con tutte le candidate)
    if len(uniq) > 1:
        if progress:
            progress(0.95, "Confronto le clip tra loro")
        lst = []
        for i, c in enumerate(uniq[:40]):
            txt = " ".join(w["w"] for w in words if c["a"] <= w["a"] <= c["b"])
            lst.append(f"id {i} · {c['b'] - c['a']:.0f}s · voto {c['score']} · {c['title']} · {c['why']} · testo: {txt[:260]}")
        try:
            raw = ai.text(cfg, RANK_SYSTEM, f"Lingua della live: {lang}.\n" + "\n".join(lst), max_tokens=4000, cancel=cancel)
            usd += ai.text_usd(cfg.get("model"), RANK_SYSTEM, "\n".join(lst), raw)
            obj = _read_obj(raw, "clips") or {}
            for x in obj.get("clips") or []:
                try:
                    i = int(x.get("id"))
                    sc = max(0, min(100, int(round(float(x.get("score"))))))
                except (TypeError, ValueError, AttributeError):
                    continue
                if 0 <= i < len(uniq):
                    uniq[i]["score"] = sc
                    t = re.sub(r"#\w+", "", str(x.get("title") or "")).strip()[:70]
                    if t:
                        uniq[i]["title"] = t
                    w_ = str(x.get("why") or "").strip()[:220]
                    if w_:
                        uniq[i]["why"] = w_
        except ai.AIError as e:
            if "Annullato" in str(e):
                raise
    # un po' di peso al volume (le reazioni forti tengono di piu'), poi i migliori
    for c in uniq:
        c["score"] = int(max(1, min(99, round(c["score"] + max(-3.0, min(4.0, (c["energy"] - 4.0) / 2.0))))))
    uniq.sort(key=lambda x: -x["score"])
    extra = [c for c in uniq[n:] if c["score"] >= 75][: max(2, n // 2)]
    best = uniq[:n] + extra
    for c in best:
        c.pop("kept", None)
        c["energy"] = round(c["energy"], 1)
    # seconda passata: inizio e fine parola per parola, con il contesto giusto, e le parole sbagliate dei sottotitoli
    fixes = []
    if best:
        if progress:
            progress(0.98, "Rifinisco inizio e fine delle clip")
        u2, fixes = refine_clips(cfg, words, best, dur, rs, lang, cancel)
        usd += u2
        # dopo i bordi nuovi niente doppioni (due clip che ora coprono lo stesso momento: resta la migliore)
        keep = []
        for c in best:
            if all(min(c["b"], u["b"]) - max(c["a"], u["a"]) < 0.5 * min(c["b"] - c["a"], u["b"] - u["a"]) for u in keep):
                keep.append(c)
        best = keep
    balance_pf(best)
    return {"clips": best, "usd": round(usd, 4), "target": n, "fixes": fixes}


_KW_STOP = set("""il lo la i gli le un uno una di a da in con su per tra fra e ed o od ma che chi cui non si se mi ti ci vi lui lei
loro noi voi io tu del dello della dei degli delle al allo alla ai agli alle dal dallo dalla dai dagli dalle nel nello nella nei ecco ora oggi qui li
negli nelle sul sullo sulla sui sugli sulle col coi come quando dove anche ancora poi pure gia piu molto tutto tutti tutta tutte
questo questa questi queste quello quella quelli quelle cosa fa fanno ha hanno ho hai era sono sei siamo e' è c'e c'è l' un'
the a an of to in on at for with and or but is are was were be been it its his her their they he she you we i my your our this
that these those so just very what who how why when where from by as not no do does did have has had""".split())
_KW_GAME = set("""win vince vinto vittoria victory kill kills clutch 1v1 2v2 qualifica qualificato qualifica finals grand grands
finale torneo record top primo impossibile pazzesco pazzesca assurdo assurda incredibile masterclass rotation rage fail
boss speedrun ranked mvp ace headshot sniper combo build edit box crown""".split())


def title_keywords(title, kw=None, n=3):
    """Le parole del titolo da colorare quando va a schermo (titolo da gaming): quelle scelte dall'AI se ci sono davvero
    nel titolo, se no nomi, numeri e le parole forti del gaming. -> [parola o due parole vicine, ...] come nel titolo."""
    title = str(title or "")
    toks = re.findall(r"[\w'’]+", title, re.U)
    if len(title) >= 70 and toks and not re.search(r"[.!?…\"»)]\s*$", title):
        toks = toks[:-1]      # titolo tagliato a 70 caratteri: l'ultima parola e' a meta'
    low = [t.lower().strip("'’") for t in toks]
    # titolo corto: una parola colorata (due se e' medio), non tutto il titolo
    n = min(n, 1 if len(toks) <= 3 else 2 if len(toks) <= 6 else n)
    out = []
    for k in kw or []:
        ws = [w.lower() for w in re.findall(r"[\w'’]+", str(k), re.U)]
        if ws and any(low[i:i + len(ws)] == ws for i in range(len(low))) and k not in out:
            out.append(str(k))
    if len(out) >= min(2, n):
        return out[:n]
    scored = []
    for i, (t, w) in enumerate(zip(toks, low)):
        if w in _KW_STOP or len(w) < 3 and not any(ch.isdigit() for ch in w):
            continue
        s = 0.0
        if t[:1].isupper():
            s += 3 if i > 0 else (1.5 if len(w) >= 4 else 0)     # un nome (Kurama, Uli, Roman); la prima parola e' maiuscola comunque
        if t.isupper() and len(t) >= 2:
            s += 1      # sigle (VOD, MVP)
        if any(ch.isdigit() for ch in w):
            s += 3      # numeri (1v1, 200 kill)
        if w in _KW_GAME:
            s += 2
        s += (0.5 if len(w) >= 5 else 0) + (1 if len(w) >= 7 else 0)
        if s > 0:
            scored.append((s, i, t))
    pick = sorted(sorted(scored, key=lambda x: (-x[0], x[1]))[:n], key=lambda x: x[1])
    for _, i, t in pick:
        if t not in out and not any(t.lower() in o.lower().split() for o in out):
            out.append(t)
    return out[:n]


def balance_pf(clips):
    """L'AI tende a dare il voto piu' alto sempre alla stessa piattaforma (quasi sempre TikTok): toglie a ogni piattaforma la sua
    spinta media su questa live, cosi' resta quanto ogni clip e' adatta a TikTok, Reels o Shorts rispetto alle altre clip."""
    pfs = [c["pf"] for c in clips if isinstance(c.get("pf"), dict) and all(k in c["pf"] for k in PLATFORMS)]
    if len(pfs) < 3:
        return clips
    mean = {k: sum(p[k] for p in pfs) / len(pfs) for k in PLATFORMS}
    tot = sum(mean.values()) / len(PLATFORMS)
    for c in clips:
        p = c.get("pf")
        if not isinstance(p, dict) or not all(k in p for k in PLATFORMS):
            continue
        before = max(PLATFORMS, key=lambda k: p[k])
        c["pf"] = {k: int(max(0, min(100, round(p[k] - 0.85 * (mean[k] - tot))))) for k in PLATFORMS}
        if max(PLATFORMS, key=lambda k: c["pf"][k]) != before:
            c["pfWhy"] = ""   # il perche' parlava dell'altra piattaforma
    return clips


EDGE_FRAG = 3.0     # pezzo tenuto all'inizio o alla fine della clip piu' corto di cosi'...
EDGE_GAP = 2.0      # ...staccato dal resto da un silenzio tolto almeno cosi': un commento staccato, non fa parte del momento


def _question_start(ws, i, back=4.0):
    """La domanda che finisce con la parola i ("?"): da dove comincia (indice), al massimo back secondi prima."""
    j = i
    while j > 0:
        p = ws[j - 1]
        if str(p["w"])[-1:] in _PUNCT_END or ws[j]["a"] - p["b"] >= 0.45 or ws[i]["b"] - p["a"] > back:
            break
        if str(ws[j]["w"])[:1].isupper() and i - j >= 1:
            break       # una frase nuova (Whisper mette la maiuscola all'inizio delle frasi)
        j -= 1
    return j


def tidy_clip_edges(rgs, words, hook="", min_len=12.0):
    """Inizio e fine della clip gia' montata (pezzi tenuti dopo aver tolto i silenzi) su frasi che hanno senso:
    - via i pezzetti isolati all'inizio e alla fine: una parola o un commento staccato dal resto da una lunga pausa
      ("Tini" ... "Tini volevo dire", "Non paricare fratello" dopo sei secondi di silenzio). All'inizio resta se dentro
      c'e' la scritta d'apertura scelta dall'AI (e' il gancio);
    - se la clip comincia con una risposta, dentro anche la domanda appena prima ("Quanto sta la top?" "96");
    - la fine su una frase finita (mai "...si e' qualificato. Non").
    rgs: [[a, b], ...] in tempi della live. -> (nuovi rgs, cosa e' cambiato)."""
    rs = [list(r) for r in rgs or []]
    if not rs or not words:
        return rs, []
    tot = lambda x: sum(b - a for a, b in x)   # noqa: E731
    ws = sorted((w for w in words if w.get("b") is not None), key=lambda w: w["a"])
    if not ws:
        return rs, []
    hook_ws = [w for w in re.findall(r"[\wàèéìòùç']+", str(hook or "").lower()) if len(w) >= 3]
    said = lambda a, b: " ".join(_bare(w["w"]) for w in ws if a - 0.05 <= w["a"] < b)   # noqa: E731
    notes = []
    while len(rs) >= 2 and rs[0][1] - rs[0][0] < EDGE_FRAG and rs[1][0] - rs[0][1] >= EDGE_GAP and tot(rs[1:]) >= min_len:
        txt = said(rs[0][0], rs[0][1])
        # (la scritta d'apertura dell'AI detta li' resta, se la pausa dopo non e' lunghissima: e' il gancio)
        if rs[1][0] - rs[0][1] < 3.5 and hook_ws and sum(1 for w in hook_ws if w in txt.split()) >= max(1, (len(hook_ws) + 1) // 2):
            break
        notes.append("inizio staccato tolto: " + txt[:60])
        rs.pop(0)
    while len(rs) >= 2 and rs[-1][1] - rs[-1][0] < EDGE_FRAG and rs[-1][0] - rs[-2][1] >= EDGE_GAP and tot(rs[:-1]) >= min_len:
        notes.append("fine staccata tolta: " + said(rs[-1][0], rs[-1][1])[:60])
        rs.pop()
    seg_end, gap_after, gap_before = _edge_info(ws)
    # risposta senza la sua domanda: la domanda (appena prima, senza pause lunghe) entra nella clip
    i0 = next((i for i, w in enumerate(ws) if w["a"] >= rs[0][0] - 0.05), None)
    if i0 is not None and i0 > 0 and ws[i0]["a"] < rs[0][1]:
        p = ws[i0 - 1]
        if str(p["w"]).rstrip()[-1:] == "?" and ws[i0]["a"] - p["b"] < 1.2 and p["b"] <= rs[0][0] + 0.05:
            q = _question_start(ws, i0 - 1)
            if ws[i0]["a"] - ws[q]["a"] <= 5.0:
                rs[0][0] = round(max(0.0, ws[q]["a"] - min(0.25, max(0.06, gap_before[q] - 0.06))), 2)
                notes.append("domanda aggiunta: " + said(ws[q]["a"], p["b"] + 0.01)[:60])
    # fine: l'ultima frase deve essere finita. Se si chiude a meta' (l'ultima parola attacca il resto della frase, o chi
    # parla continua subito la stessa frase) si completa la frase se finisce entro pochi secondi, se no si finisce
    # sull'ultima frase chiusa poco prima
    def ends_ok(j):
        t = str(ws[j]["w"])
        if t[-1:] in _PUNCT_END:
            return True
        if t[-1:] not in ",;:" and _bare(t) in _CONT | _OPEN:
            return False
        nx = ws[j + 1] if j + 1 < len(ws) else None
        return nx is None or gap_after[j] >= 0.45 or str(nx["w"])[:1].isupper()
    last = [j for j, w in enumerate(ws) if rs[-1][0] - 0.05 <= w["a"] and w["b"] <= rs[-1][1] + 0.15]
    if last and not ends_ok(last[-1]):
        jl = last[-1]
        nb, why = None, ""
        j = jl
        while j + 1 < len(ws) and ws[j + 1]["a"] - ws[j]["b"] < 0.45 and ws[j + 1]["b"] - ws[jl]["b"] <= 3.0:
            j += 1
            if ends_ok(j):
                nb, why = ws[j]["b"], "fine con la frase completata: ..."
                break
        if nb is None:
            for j in reversed(last[:-1]):
                if ws[jl]["b"] - ws[j]["b"] > 6.0:
                    break
                if ends_ok(j):
                    nb, why = ws[j]["b"], "fine sulla frase finita: ..."
                    break
        if nb is not None:
            g = gap_after[j]
            # un filo dopo l'ultima parola, mai dentro la parola dopo (si sentirebbe l'inizio di un'altra frase)
            nb = round(nb + (max(0.0, g - 0.03) if g < 0.15 else min(0.5, g - 0.12)), 2)
            if tot(rs) - (rs[-1][1] - nb) >= min_len and nb > rs[-1][0] + 0.5:
                notes.append(why + said(ws[max(0, j - 5)]["a"], ws[j]["a"] + 0.01)[-70:])
                rs[-1][1] = nb
    return rs, notes


def dead_air(words, lev, a, b, gap=1.5):
    """Pezzi della clip senza parole e senza azione da togliere (le clip devono andare veloci)."""
    med, _ = level_stats(lev, speech_mask(words, len(lev)))
    ws = [w for w in words if a <= w["a"] <= b]
    out, t = [], a
    for w in ws + [{"a": b, "b": b}]:
        if w["a"] - t > gap:
            s0, s1 = int(t), max(int(t) + 1, int(w["a"]))
            loud = float(lev[s0:s1].max()) if s1 <= len(lev) and s1 > s0 else -90.0
            if loud < med - 3.0:   # piu' piano della voce: niente urlo, niente azione del gioco in mezzo
                out.append((round(t + 0.3, 2), round(w["a"] - 0.25, 2)))
        t = max(t, w["b"])
    return [(x, y) for x, y in out if y - x > 0.4]


def estimate(proj, cfg, words=None):
    from engine import aiedit as AE
    words = words if words is not None else AE.words_of(proj)
    n = len(words)
    dur = float(proj.get("duration") or (words[-1]["b"] if words else 0))
    wins = max(1, int(np.ceil(max(1.0, dur - 60.0) / 420.0)))
    tin = (sum(len(w["w"]) + 2 for w in words) * 1.15 + wins * 1800) / 3.3
    tout = wins * 900 + 1500
    usd = ai.text_cost(cfg.get("model"), tin, tout)
    return {"words": n, "usd": round(usd if usd is not None else 0.012 * wins + 0.01, 4), "windows": wins,
            "target": clip_target(dur)}
