// Grafica: il documento (pagine, livelli) e i formati pronti. Niente interfaccia qui.
import { t } from '../i18n.js';

export const uid = (p = 'l') => p + Math.random().toString(36).slice(2, 10);
export const clone = (o) => JSON.parse(JSON.stringify(o));

// formati pronti per i creator: [id, nome, sottotitolo, w, h, categoria]
export const PRESETS = [
  ['ig-post', 'Post Instagram', '1080 × 1080', 1080, 1080, 'social'],
  ['ig-45', 'Post verticale', '1080 × 1350 · Instagram', 1080, 1350, 'social'],
  ['story', 'Storia / Reel', '1080 × 1920 · IG, TikTok', 1080, 1920, 'social'],
  ['carousel', 'Carosello', '1080 × 1350 · più pagine', 1080, 1350, 'social'],
  ['yt-thumb', 'Miniatura YouTube', '1280 × 720', 1280, 720, 'video'],
  ['yt-banner', 'Banner YouTube', '2560 × 1440', 2560, 1440, 'video'],
  ['twitch-banner', 'Banner Twitch', '1200 × 480', 1200, 480, 'video'],
  ['twitch-panel', 'Pannello Twitch', '320 × 160', 320, 160, 'video'],
  ['x-post', 'Post X', '1600 × 900', 1600, 900, 'social'],
  ['linkedin', 'Post LinkedIn', '1200 × 627', 1200, 627, 'social'],
  ['pin', 'Pin Pinterest', '1000 × 1500', 1000, 1500, 'social'],
  ['fb-cover', 'Copertina Facebook', '1640 × 624', 1640, 624, 'social'],
  ['podcast', 'Copertina podcast', '3000 × 3000', 3000, 3000, 'print'],
  ['slide', 'Presentazione', '1920 × 1080', 1920, 1080, 'print'],
  ['a4', 'Locandina A4', '2480 × 3508 · 300 dpi', 2480, 3508, 'print'],
  ['logo', 'Logo', '1000 × 1000 · trasparente', 1000, 1000, 'print'],
];

export const BLENDS = [['normal', 'Normale'], ['multiply', 'Moltiplica'], ['screen', 'Scolora'], ['overlay', 'Sovrapponi'],
  ['darken', 'Scurisci'], ['lighten', 'Schiarisci'], ['color-dodge', 'Colore scherma'], ['color-burn', 'Colore brucia'],
  ['hard-light', 'Luce intensa'], ['soft-light', 'Luce soffusa'], ['difference', 'Differenza'], ['exclusion', 'Esclusione'],
  ['hue', 'Tonalità'], ['saturation', 'Saturazione'], ['color', 'Colore'], ['luminosity', 'Luminosità']];

export const FX_DEFAULT = {
  shadow: { on: false, color: '#000000', opacity: 0.45, blur: 24, x: 0, y: 10 },
  stroke: { on: false, color: '#FFFFFF', width: 8 },
  glow: { on: false, color: '#4F8CFF', opacity: 0.8, blur: 30 },
  colorOverlay: { on: false, color: '#FF3B6B', opacity: 1 },
  gradOverlay: { on: false, fill: { type: 'linear', angle: 90, stops: [[0, '#FFFFFF'], [1, '#000000']] }, opacity: 0.6 },
  innerShadow: { on: false, color: '#000000', opacity: 0.6, blur: 16, x: 0, y: 6 },
  bevel: { on: false, size: 12, angle: 120, highlight: 0.75, shadow: 0.6 },
};
export const FILTER_DEFAULT = { brightness: 0, contrast: 0, saturation: 0, hue: 0, blur: 0, grayscale: 0, sepia: 0, invert: 0 };
export const ADJUST_KINDS = [['bc', 'Luminosità / contrasto'], ['hsl', 'Tonalità / saturazione'], ['bw', 'Bianco e nero'],
  ['warm', 'Temperatura'], ['invert', 'Inverti'], ['blur', 'Sfocatura'],
  ['curves', 'Curve'], ['levels', 'Livelli'], ['exposure', 'Esposizione'], ['vibrance', 'Vividezza'], ['colorbal', 'Bilanciamento colore'],
  ['shadhigh', 'Ombre / luci'], ['photo', 'Filtro fotografico'], ['gradmap', 'Mappa sfumatura'], ['lut', 'LUT (look da film)']];

export function baseLayer(type, extra) {
  return { id: uid(), type, name: '', visible: true, locked: false, opacity: 1, blend: 'normal', x: 0, y: 0, w: 100, h: 100, rot: 0, flipX: false, flipY: false, ...extra };
}

export const TEXT_DEF = { text: 'Il tuo testo', font: 'Inter', size: 96, weight: 700, italic: false, color: '#111111', align: 'center', lineH: 1.15, letter: 0, upper: false };
export function textLayer(doc, extra) {
  const size = Math.round(Math.max(24, Math.min(doc.w, doc.h) * 0.08));
  const w = Math.round(doc.w * 0.7);
  return baseLayer('text', { name: t('Testo'), ...TEXT_DEF, text: t('Il tuo testo'), size, w, h: Math.round(size * 1.2), x: Math.round((doc.w - w) / 2), y: Math.round(doc.h / 2 - size * 0.6), auto: true, ...extra });
}
export function shapeLayer(kind, x, y, w, h, extra) {
  const names = { rect: t('Rettangolo'), ellipse: t('Ellisse'), line: t('Linea'), triangle: t('Triangolo'), star: t('Stella'), poly: t('Poligono') };
  return baseLayer('shape', { name: names[kind] || t('Forma'), kind, x, y, w, h, fill: '#2F8BFF', stroke: '', strokeW: 0, radius: 0, sides: 6, ...extra });
}
export function imageLayer(file, iw, ih, doc, name) {
  // dentro la tela, centrata (piu' piccola se serve)
  const k = Math.min(1, (doc.w * 0.9) / iw, (doc.h * 0.9) / ih);
  const w = Math.round(iw * k), hh = Math.round(ih * k);
  return baseLayer('image', { name: name || t('Immagine'), src: file, iw, ih, w, h: hh, x: Math.round((doc.w - w) / 2), y: Math.round((doc.h - hh) / 2) });
}
export function paintLayer(doc) {
  return baseLayer('paint', { name: t('Pittura'), src: '', w: doc.w, h: doc.h, x: 0, y: 0 });
}
export function adjustLayer(kind) {
  const p = { bc: { brightness: 0, contrast: 0 }, hsl: { hue: 0, saturation: 0, lightness: 0 }, bw: { amount: 100 }, warm: { amount: 20 }, invert: {}, blur: { amount: 4 },
    curves: { rgb: [[0, 0], [255, 255]], r: [[0, 0], [255, 255]], g: [[0, 0], [255, 255]], b: [[0, 0], [255, 255]] },
    levels: { inBlack: 0, inWhite: 255, gamma: 1, outBlack: 0, outWhite: 255 }, exposure: { exposure: 0, offset: 0, gamma: 1 },
    vibrance: { vibrance: 30, saturation: 0 }, colorbal: { cr: 0, mg: 0, yb: 0 }, shadhigh: { shadows: 35, highlights: 0 },
    photo: { color: '#EC8A00', density: 25, keepLum: true }, gradmap: { stops: [[0, '#1B1464'], [0.5, '#E8417C'], [1, '#FFE29A']] },
    lut: { lut: '', name: '', amount: 100 } }[kind] || {};
  return baseLayer('adjust', { name: t((ADJUST_KINDS.find((k) => k[0] === kind) || [0, 'Regolazione'])[1]), kind, p });
}
export function groupLayer(children) {
  return baseLayer('group', { name: t('Gruppo'), children, open: true });
}

// --- albero dei livelli: i livelli sono dal basso verso l'alto; i gruppi hanno children (stesso ordine)
export function walk(list, fn, parent = null) {
  for (let i = 0; i < list.length; i++) {
    const l = list[i];
    if (fn(l, parent, list, i) === false) return false;
    if (l.type === 'group' && walk(l.children || [], fn, l) === false) return false;
  }
  return true;
}
export function findLayer(list, id) {
  let out = null;
  walk(list, (l, parent, arr, i) => { if (l.id === id) { out = { layer: l, parent, arr, i }; return false; } return true; });
  return out;
}
export function flatVisible(list, out = []) {
  for (const l of list) { if (!l.visible) continue; if (l.type === 'group') flatVisible(l.children || [], out); else out.push(l); }
  return out;
}

// riquadro di un livello in coordinate della tela (con la rotazione): 4 angoli
export function corners(l) {
  const cx = l.x + l.w / 2, cy = l.y + l.h / 2, a = (l.rot || 0) * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
  return [[-l.w / 2, -l.h / 2], [l.w / 2, -l.h / 2], [l.w / 2, l.h / 2], [-l.w / 2, l.h / 2]].map(([x, y]) => [cx + x * c - y * s, cy + x * s + y * c]);
}
export function bounds(l) {
  if (l.type === 'group') {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    walk(l.children || [], (c) => { if (c.type === 'group' || c.type === 'adjust') return true; for (const [x, y] of corners(c)) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); } return true; });
    return isFinite(x0) ? { x: x0, y: y0, w: x1 - x0, h: y1 - y0 } : { x: 0, y: 0, w: 0, h: 0 };
  }
  const cs = corners(l);
  const xs = cs.map((p) => p[0]), ys = cs.map((p) => p[1]);
  return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
}
// punto della tela -> coordinate locali del livello (0..w, 0..h)
export function toLocal(l, px, py) {
  const cx = l.x + l.w / 2, cy = l.y + l.h / 2, a = -(l.rot || 0) * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
  const dx = px - cx, dy = py - cy;
  let x = dx * c - dy * s, y = dx * s + dy * c;
  if (l.flipX) x = -x;
  if (l.flipY) y = -y;
  return [x + l.w / 2, y + l.h / 2];
}
// sposta un livello (anche un gruppo: si spostano i figli)
export function moveBy(l, dx, dy) {
  if (l.type === 'group') { for (const c of l.children || []) moveBy(c, dx, dy); return; }
  if (l.type === 'adjust') return;
  l.x += dx; l.y += dy;
}
// scala un gruppo intorno a un punto (i figli)
export function scaleAround(l, ox, oy, kx, ky) {
  if (l.type === 'group') { for (const c of l.children || []) scaleAround(c, ox, oy, kx, ky); return; }
  if (l.type === 'adjust') return;
  const cx = l.x + l.w / 2, cy = l.y + l.h / 2;
  const ncx = ox + (cx - ox) * kx, ncy = oy + (cy - oy) * ky;
  l.w = Math.max(1, l.w * Math.abs(kx)); l.h = Math.max(1, l.h * Math.abs(ky));
  if (l.type === 'text') { l.size = Math.max(4, l.size * Math.abs(ky)); }
  if (l.fx && l.fx.stroke) l.fx.stroke.width = Math.max(0, (l.fx.stroke.width || 0) * Math.min(Math.abs(kx), Math.abs(ky)));
  l.x = ncx - l.w / 2; l.y = ncy - l.h / 2;
}

export const hex2rgba = (hex, a = 1) => {
  let s = String(hex || '#000').replace('#', '');
  if (s.length === 3) s = s.split('').map((c) => c + c).join('');
  const n = parseInt(s.slice(0, 6), 16) || 0;
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};
