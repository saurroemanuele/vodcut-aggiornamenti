"""Segnalazioni di errori e richieste di modifica dagli utenti.

L'app prepara un pacchetto (testo, screenshot, e se l'utente vuole i log e il progetto aperto), lo salva in
~/VODcut/segnalazioni e lo manda al database di Nuvora collegato all'account. Se non c'e' connessione resta
in coda e parte da solo piu' tardi: nessuna segnalazione si perde.

Sicurezza: nell'app non c'e' nessuna chiave segreta. L'invio usa solo la sessione dell'utente, e il database
accetta la segnalazione solo tramite una funzione controllata (nessuno puo' leggere quelle degli altri).
"""
import base64
import gzip
import json
import os
import platform
import re
import secrets
import subprocess
import sys
import threading
import time

from .util import APP_DIR
from .version import VERSION

QUEUE_DIR = os.path.join(APP_DIR, "segnalazioni")
MAX_LOG = 400_000
MAX_IMAGES = 6
_LOCK = threading.Lock()



def _tail(path, n):
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - n))
            return f.read().decode("utf-8", errors="replace")
    except OSError:
        return ""


def _log_path():
    if os.environ.get("VODCUT_LOG"):     # Mac: il log sta in ~/Library/Logs/VODcut (l'app non si puo' scrivere)
        return os.environ["VODCUT_LOG"]
    base = os.environ.get("VODCUT_BASE") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "vodcut.log")


def _ffmpeg_version():
    try:
        from .util import ffmpeg_bin
        r = subprocess.run([ffmpeg_bin(), "-hide_banner", "-version"], capture_output=True, timeout=10,
                           creationflags=0x08000000 if sys.platform == "win32" else 0)
        return r.stdout.decode(errors="ignore").splitlines()[0][:160]
    except Exception:
        return ""


def system_info(extra=None):
    info = {
        "app": VERSION, "os": platform.platform(terse=True), "machine": platform.machine(), "python": platform.python_version(),
        "cpu": os.cpu_count(), "ffmpeg": _ffmpeg_version(), "booted": bool(os.environ.get("VODCUT_BOOTED")),
    }
    info.update(extra or {})
    return info


def _image(data_url):
    m = re.match(r"^data:image/(png|jpeg|jpg|webp);base64,(.+)$", data_url or "", re.S)
    if not m:
        return None
    return {"type": m.group(1).replace("jpg", "jpeg"), "b64": m.group(2)}


_HOME = os.path.expanduser("~")
_USER = os.path.basename(_HOME.rstrip("\\/"))


def redact(text):
    """Toglie dai testi tecnici quello che non serve per trovare l'errore: la chiave di sessione dell'app
    e il nome utente del PC nei percorsi dei file."""
    if not text:
        return text
    text = re.sub(r"(token=)[0-9a-fA-F]{16,}", r"\1***", text)
    text = re.sub(r"(X-Token[\"':\s]+)[0-9a-fA-F]{16,}", r"\1***", text)
    text = re.sub(r"eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}", "***", text)     # sessioni dell'account
    text = re.sub(r"(?i)(refresh_token|access_token|code_verifier|auth_code)([\"':=\s]+)[A-Za-z0-9._~-]{8,}", r"\1\2***", text)
    if _HOME and len(_HOME) > 3:
        text = re.sub(re.escape(_HOME), "~", text, flags=re.I)
        text = re.sub(re.escape(_HOME.replace("\\", "\\\\")), "~", text, flags=re.I)   # dentro i JSON
        text = re.sub(re.escape(_HOME.replace("\\", "/")), "~", text, flags=re.I)
    if _USER and len(_USER) > 1:
        text = re.sub(r"(?i)((?:\\\\|\\|/)(?:users|home)(?:\\\\|\\|/))" + re.escape(_USER) + r"(?=[\\/\"']|$)", r"\1<utente>", text)
        # anche nei percorsi scritti dentro gli indirizzi (C%3A%5CUsers%5Cnome...)
        text = re.sub(r"(?i)((?:%5C|%2F)(?:users|home)(?:%5C|%2F))" + re.escape(_USER) + r"(?=%5C|%2F|&|\s|$)", r"\1<utente>", text)
    return text


def _clean_project(proj):
    """Il progetto senza il testo parlato (i sottotitoli restano come tempi, senza parole) e senza nomi utente."""
    q = json.loads(redact(json.dumps(proj, ensure_ascii=False)))
    for sg in (q.get("transcript") or {}).get("segments") or []:
        for w in sg.get("words") or []:
            if "w" in w:
                w["w"] = "x" * min(12, len(str(w["w"]).strip()) or 1)
        if "text" in sg:
            sg["text"] = ""
    return q


def build(data, project=None, extra_info=None):
    """Il pacchetto della segnalazione (un dict), dai dati mandati dalla finestra."""
    kind = "idea" if data.get("kind") == "idea" else "bug"
    rid = time.strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    rep = {
        "id": rid, "kind": kind, "at": time.strftime("%Y-%m-%d %H:%M:%S"), "text": str(data.get("text") or "")[:20000],
        "contact": str(data.get("contact") or "")[:200], "errors": [redact(str(e)[:2000]) for e in (data.get("errors") or [])][:20],
        "screen": str(data.get("screen") or "")[:200], "system": system_info(extra_info),
        "images": [i for i in (_image(x) for x in (data.get("images") or [])[:MAX_IMAGES]) if i],
    }
    if data.get("logs"):
        rep["log"] = redact(_tail(_log_path(), MAX_LOG))
        rep["exportError"] = redact(_tail(os.path.join(APP_DIR, "ultimo-errore-export.txt"), 60_000))
        rep["clientLog"] = [redact(str(x)[:2000]) for x in (data.get("clientLog") or [])][-80:]
    if project is not None:
        rep["project"] = _clean_project(project)
    return rep


def save(rep):
    os.makedirs(QUEUE_DIR, exist_ok=True)
    path = os.path.join(QUEUE_DIR, f"{rep['id']}-{rep['kind']}.json.gz")
    tmp = path + ".tmp"
    with gzip.open(tmp, "wb", compresslevel=9) as f:
        f.write(json.dumps(rep, ensure_ascii=False).encode("utf-8"))
    os.replace(tmp, path)
    return path


def pending():
    try:
        return sorted(os.path.join(QUEUE_DIR, f) for f in os.listdir(QUEUE_DIR) if f.endswith(".json.gz"))
    except OSError:
        return []



def _send_account(path):
    """Con l'account: la segnalazione va nel database di Nuvora, collegata a chi la manda."""
    try:
        from . import account
        if not account.status().get("signedIn"):
            return False
        with gzip.open(path, "rb") as f:
            rep = json.loads(f.read().decode("utf-8"))
        return account.send_report(rep)
    except Exception as e:
        print(f"[segnalazioni] account: {e}", flush=True)
        return False


def send_pending():
    """Manda le segnalazioni in coda (serve l'accesso). Ritorna quante ne restano."""
    with _LOCK:
        for path in pending():
            if _send_account(path):
                os.remove(path)     # inviata: sul PC non ne resta copia
                print(f"[segnalazioni] inviata {os.path.basename(path)}", flush=True)
            else:
                break
    return len(pending())


def start_background():
    def loop():
        time.sleep(20)
        while True:
            try:
                if pending():
                    send_pending()
            except Exception as e:
                print(f"[segnalazioni] {e}", flush=True)
            time.sleep(15 * 60)
    threading.Thread(target=loop, daemon=True, name="segnalazioni").start()
