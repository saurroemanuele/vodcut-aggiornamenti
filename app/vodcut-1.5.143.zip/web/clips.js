// NoonFrame - clip virali dalla live (stile Opus): l'AI trova i momenti migliori, ognuno e' gia' una clip verticale montata.
// Galleria con punteggio di viralita', titolo e motivo; anteprima al passaggio del mouse; ogni clip si apre nell'editor.
import { get, post, put, api, h, icon, toast, confirmBox, promptBox, pollJob, mediaUrl, thumbUrl, TOKEN } from './lib.js';
import { drawText } from './text.js';
import { ensureFont } from './fonts.js';

// scritta d'apertura delle clip: grande, bianca con contorno, l'ultima parola colorata
const HOOK_STYLE = { font: 'Montserrat', weight: 900, size: 0.056, color: '#FFFFFF', bold: true, upper: true, align: 'center', stroke: true,
  strokeColor: '#000000', strokeW: 0.1, shadow: true, crisp: true, hlColor: '#FFD60A', lineH: 1.06, v: 2 };
const VW = 1080, VH = 1920;
// stili pronti della scritta d'apertura; "Il tuo stile" li parte da uno e lo personalizzi (font e colori del tuo brand)
const HOOK_PRESETS = [
  ['classico', 'Classico', {}],
  ['verde', 'Verde', { hlColor: '#3DDC84' }],
  ['box', 'Riquadro', { color: '#111111', stroke: false, shadow: false, box: true, boxColor: '#FFFFFF', boxOp: 100, boxR: 0.22, hlColor: '#FF3B30' }],
  ['neon', 'Neon', { hlColor: '#FF4FD8', bloom: '#FF4FD8', bloomK: 0.4 }],
  ['pulito', 'Pulito', { font: 'Poppins', weight: 800, stroke: false, shadow: true, hlColor: '#3DDC84' }],
  ['impatto', 'Impatto', { font: 'Anton', weight: 400, upper: true, strokeW: 0.12, hlColor: '#FF5A1F' }],
];
const HOOK_FONTS = ['Montserrat', 'Poppins', 'Inter', 'Bebas Neue', 'Anton', 'Oswald', 'Archivo Black', 'Rubik', 'Lilita One', 'Luckiest Guy', 'Bangers', 'Barlow Condensed'];
let userHook = null;   // stile scelto (impostazioni dell'app): {preset, ...personalizzazioni}
async function loadHookStyle() {
  if (userHook) return userHook;
  try { const s = await post('/api/settings', {}); userHook = (s && s.hookStyle) || { preset: 'classico' }; } catch (e) { userHook = { preset: 'classico' }; }
  return userHook;
}
function hookStyle(u) {
  const pr = HOOK_PRESETS.find((x) => x[0] === (u && u.preset)) || HOOK_PRESETS[0];
  const own = {};
  for (const k of ['font', 'color', 'hlColor', 'stroke', 'box', 'boxColor']) if (u && u[k] !== undefined && u[k] !== null && u[k] !== '') own[k] = u[k];
  return { ...HOOK_STYLE, ...pr[2], ...own };
}

export const scoreColor = (s) => (s == null ? 'var(--text3)' : s >= 90 ? '#3DDC84' : s >= 75 ? '#A3E635' : s >= 60 ? '#FFD60A' : '#FF9F43');
const mmss = (t) => { t = Math.max(0, Math.round(t || 0)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); };
const hms = (t) => { t = Math.max(0, Math.round(t || 0)); const hh = Math.floor(t / 3600); return (hh ? hh + ':' : '') + String(Math.floor(t / 60) % 60).padStart(hh ? 2 : 1, '0') + ':' + String(t % 60).padStart(2, '0'); };

function hookContent(txt) {
  const w = String(txt || '').trim().split(/\s+/).filter(Boolean);
  if (!w.length) return '';
  const last = w.length > 1 ? w.pop() : null;
  let lines = [w.join(' ')];
  // due righe quando e' lunga (si legge meglio sul telefono)
  if ((w.join(' ') + (last ? ' ' + last : '')).length > 16 && w.length > 1) {
    const k = Math.ceil(w.length / 2);
    lines = [w.slice(0, k).join(' '), w.slice(k).join(' ')];
  }
  if (last) lines[lines.length - 1] = (lines[lines.length - 1] + ' *' + last + '*').trim();
  return lines.join('\n');
}

// dove va la scritta d'apertura: quando si vede solo la webcam (zoom sulla cam o impaginazione "solo cam")
// sta in alto, sopra la testa; con cam sopra e gioco sotto sta sulla linea tra i due
function hookY(ch, c) {
  const a = c.a || 0, b = a + (c.dur || 3.2);
  const lay = (ch.vert && ch.vert.layout) || 'split';
  const zoomed = (ch.zooms || []).some((z) => z.on !== false && z.a < b && a < z.b);
  return lay === 'split' && !zoomed ? 0.33 : 0.07;
}

// disegna la scritta d'apertura con lo stesso motore dei testi dell'editor e la salva nella clip
async function bakeHooks(cid, force) {
  const ch = await get('/api/p/' + cid);
  let changed = false;
  const st = hookStyle(await loadHookStyle());
  await ensureFont(st.font);
  for (const t of ch.tracks || []) {
    for (const c of t.clips || []) {
      const old = c.hook && c.text && c.text.font && c.text.v !== HOOK_STYLE.v;   // scritte fatte con lo stile vecchio: si ridisegnano
      if (!c.isText || (c.file && c.text && c.text.font && !(force && c.hook) && !old)) continue;
      const raw = String((c.text && c.text.content) || '').replace(/\*/g, '').replace(/\n/g, ' ');
      const spec = { ...st, content: c.hook ? hookContent(raw) : String((c.text && c.text.content) || '') };
      const cv = drawText(spec, VH);
      const natW = cv.width / VW, ar = cv.height / cv.width;
      const w = Math.min(0.9, natW);
      const blob = await new Promise((res) => cv.toBlob(res, 'image/png'));
      const r = await fetch(`/api/p/${cid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: blob });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Scritta non salvata');
      const p0 = c.pos || {};
      const autoY = c.hook && (p0.auto || p0.y == null || !c.file || (old && Math.abs(p0.y - 0.33) < 0.005));
      const y = autoY ? hookY(ch, c) : p0.y;
      Object.assign(c, { file: j.path, text: spec, natW, ar, pos: { x: +((1 - w) / 2).toFixed(4), y, w: +w.toFixed(4), ...(autoY ? { auto: true } : {}) } });
      changed = true;
    }
  }
  if (changed) await put('/api/p/' + cid, ch);
}

async function findJob(pid, kind) {
  try { return (await get('/api/jobs')).find((j) => j.pid === pid && j.kind === kind) || null; } catch (e) { return null; }
}

export async function screenClips(pid, ctx) {
  const { app, nav, setTitle, setCleanup, topbar } = ctx;
  let data = await post(`/api/p/${pid}/cliplist`);
  const parent = await get('/api/p/' + pid);
  setTitle('Clip · ' + parent.name);
  let alive = true, sort = 'score', minScore = 0, selecting = false, query = '';
  const selected = new Set();
  let job = await findJob(pid, 'clips');
  let pjob = await findJob(pid, 'clipprev');
  const working = new Set();   // clip con l'anteprima in preparazione
  const queued = new Set();   // clip che aspettano le anteprime in corso

  app.innerHTML = '';
  const right = h('div', { class: 'row' });
  app.append(topbar(-1, right, false, { parentName: parent.name, parent: pid, name: 'Clip virali', icon: 'phone', parentTip: 'Torna al video della live' }));
  const page = h('main', { class: 'cg' });
  app.append(page);

  // ---------------------------------------------------------------- barra: cosa cercare, ordina, filtra, seleziona
  const qIn = h('input', { class: 'cg-q', placeholder: 'Cosa cercare? Es. spaventi, momenti divertenti, giocate epiche (facoltativo)', maxlength: '300',
    value: (data.run && data.run.prompt) || '', 'aria-label': 'Cosa cercare nella live' });
  const findBtn = h('button', { class: 'btn primary', onclick: () => start() }, icon('sparkle', 14, '#fff', 2.2), 'Trova le clip');
  const subsBtn = h('button', { class: 'btn', 'data-tip': 'Dove stanno i sottotitoli nelle clip, font e colori: si sceglie prima di creare le clip', onclick: () => subsBox() }, icon('cc', 14, 'currentColor', 2), 'Sottotitoli');
  const searchIn = h('input', { class: 'cg-search', placeholder: 'Cerca nei titoli', 'aria-label': 'Cerca nei titoli',
    oninput: () => { query = searchIn.value.trim().toLowerCase(); drawGrid(); } });
  const tools = h('div', { class: 'cg-tools' });
  const status = h('div', { class: 'cg-status', style: { display: 'none' } });
  const grid = h('div', { class: 'cg-grid' });
  const selBar = h('div', { class: 'cg-selbar', style: { display: 'none' } });
  page.append(h('div', { class: 'cg-head' },
    h('div', { class: 'cg-title' }, h('h1', null, 'Clip virali'), h('span', { class: 'cg-count' })),
    h('div', { class: 'cg-find' }, qIn, subsBtn, findBtn)), status, tools, grid, selBar);

  // sottotitoli delle clip: posizione (sotto la cam, al centro, in basso), parole per volta, font e colori
  const SUB_FONTS = ['Montserrat', 'Poppins', 'Inter', 'Bebas Neue', 'Anton', 'Oswald', 'Archivo Black', 'Rubik', 'Lilita One', 'Luckiest Guy', 'Bangers', 'Barlow Condensed'];
  async function subsBox() {
    const u = { pos: 'cam', words: 'poche', font: 'Montserrat', color: '#FFFFFF', hiColor: '#FFD60A', upper: true, box: false, size: 'grandi', ...(data.clipSubs || {}) };
    if ((u.hiColor || '').toUpperCase() === '#3DDC84') u.hiColor = '#FFD60A';   // il verde era il vecchio colore di base
    const bg = h('div', { class: 'modal-bg' });
    const cv = h('canvas', { class: 'cg-spv', width: 270, height: 480 });
    const paint = async () => {
      await ensureFont(u.font);
      const g = cv.getContext('2d'), W = cv.width, H = cv.height, camH = data.webcam ? 0.4 : 0;
      g.fillStyle = '#1c2533'; g.fillRect(0, 0, W, H);
      if (camH) { g.fillStyle = '#3a2a40'; g.fillRect(0, 0, W, H * camH); g.fillStyle = 'rgba(255,255,255,.35)'; g.font = '600 13px sans-serif'; g.textAlign = 'center'; g.fillText('WEBCAM', W / 2, H * camH / 2); }
      g.fillStyle = 'rgba(255,255,255,.18)'; g.font = '600 13px sans-serif'; g.textAlign = 'center'; g.fillText('GIOCO', W / 2, H * (camH + (1 - camH) * 0.75));
      const pos = u.pos === 'cam' && !camH ? 'centro' : u.pos;
      const y = pos === 'cam' ? Math.min(0.86, camH + 0.12) : pos === 'centro' ? 0.62 : 0.8;
      const words = u.words === 'parola' ? ['NON'] : u.words === 'frase' ? ['NON CI POSSO', 'CREDERE RAGAZZI'] : ['NON CI', 'POSSO'];
      const px = Math.round(H * (u.size === 'medi' ? 0.04 : 0.052));
      g.font = `900 ${px}px "${u.font}", sans-serif`; g.textAlign = 'center'; g.lineJoin = 'round';
      const lines = words.map((t) => (u.upper ? t : t.charAt(0) + t.slice(1).toLowerCase()));
      const lh = px * 1.15, bottom = H * y;
      lines.forEach((t, i) => {
        const yy = bottom - (lines.length - 1 - i) * lh;
        if (u.box) { const w = g.measureText(t).width; g.fillStyle = 'rgba(0,0,0,.65)'; g.fillRect(W / 2 - w / 2 - 8, yy - px, w + 16, px * 1.25); }
        else { g.strokeStyle = '#000'; g.lineWidth = px * 0.18; g.strokeText(t, W / 2, yy); }
        g.fillStyle = i === lines.length - 1 ? u.hiColor : u.color; g.fillText(t, W / 2, yy);
      });
    };
    const segOf = (key, opts) => { const el = h('div', { class: 'seg cg-seg' }); const draw = () => el.replaceChildren(...opts.map(([k, l]) => h('button', { type: 'button', class: u[key] === k ? 'on' : '', onclick: () => { u[key] = k; draw(); paint(); } }, l))); draw(); return el; };
    const font = h('select', { class: 'cg-lang', 'aria-label': 'Font dei sottotitoli' }, ...SUB_FONTS.map((f) => h('option', { value: f, selected: f === u.font ? true : null }, f)));
    font.addEventListener('change', () => { u.font = font.value; paint(); });
    const col = h('input', { type: 'color', value: u.color, 'aria-label': 'Colore' }); col.addEventListener('input', () => { u.color = col.value.toUpperCase(); paint(); });
    const hl = h('input', { type: 'color', value: u.hiColor, 'aria-label': 'Parola che si sta dicendo' }); hl.addEventListener('input', () => { u.hiColor = hl.value.toUpperCase(); paint(); });
    const up = h('input', { type: 'checkbox', checked: u.upper ? true : null }); up.addEventListener('change', () => { u.upper = up.checked; paint(); });
    const bx = h('input', { type: 'checkbox', checked: u.box ? true : null }); bx.addEventListener('change', () => { u.box = bx.checked; paint(); });
    const row = (label, el) => h('label', { class: 'cg-hrow' }, h('span', null, label), el);
    const close = () => bg.remove();
    const has = data.clips.length > 0;
    const save = async () => {
      let r;
      try { r = await post(`/api/p/${pid}/clipsubs`, { ...u, apply: has }); } catch (e) { return toast(e.message, true); }
      data.clipSubs = u; close();
      if (has) { toast('Sottotitoli aggiornati in ' + r.clips + ' clip: rifaccio le anteprime'); await reload(); await previews(data.clips.map((c) => c.id)); }
      else toast('Salvato: le prossime clip avranno questi sottotitoli');
    };
    bg.append(h('div', { class: 'modal cg-smodal', role: 'dialog', 'aria-label': 'Sottotitoli delle clip' },
      h('h2', null, 'Sottotitoli delle clip'),
      h('div', { class: 'cg-scols' },
        h('div', { class: 'cg-spvw' }, cv),
        h('div', { class: 'cg-sopts' },
          h('div', { class: 'cg-slbl' }, 'Dove'), segOf('pos', [['cam', 'Sotto la cam'], ['centro', 'Al centro'], ['basso', 'In basso']]),
          h('div', { class: 'cg-slbl' }, 'Parole per volta'), segOf('words', [['parola', 'Una'], ['poche', 'Poche'], ['frase', 'Frase']]),
          h('div', { class: 'cg-slbl' }, 'Grandezza'), segOf('size', [['medi', 'Medi'], ['grandi', 'Grandi']]),
          h('div', { class: 'cg-hgrid one' }, row('Font', font), row('Colore', col), row('Parola detta', hl), row('Maiuscolo', up), row('Riquadro scuro', bx)))),
      h('p', { class: 'muted', style: { margin: '10px 0 0' } }, has ? 'Vale per tutte le clip di questa live e per le prossime.' : 'Lo scegli adesso e le clip escono già così.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px', marginTop: '14px' } },
        h('button', { class: 'btn ghost', type: 'button', onclick: close }, 'Annulla'),
        h('button', { class: 'btn primary', type: 'button', onclick: save }, has ? 'Salva e applica' : 'Salva'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
    paint();
  }

  function drawTools() {
    const n = data.clips.length;
    page.querySelector('.cg-count').textContent = n ? String(n) : '';
    tools.style.display = n ? '' : 'none';
    tools.replaceChildren(...[
      h('div', { class: 'cg-tl' }, searchIn),
      h('div', { class: 'cg-tl' },
        h('div', { class: 'seg cg-seg', role: 'group', 'aria-label': 'Ordina' },
          ...[['score', 'Più virali'], ['time', 'Ordine nella live']].map(([k, l]) => h('button', { class: sort === k ? 'on' : '', type: 'button', onclick: () => { sort = k; drawTools(); drawGrid(); } }, l))),
        h('div', { class: 'seg cg-seg', role: 'group', 'aria-label': 'Punteggio minimo' },
          ...[[0, 'Tutte'], [70, '70+'], [85, '85+']].map(([k, l]) => h('button', { class: minScore === k ? 'on' : '', type: 'button', onclick: () => { minScore = k; drawTools(); drawGrid(); } }, l))),
        langSel(),
        n ? h('button', { class: 'btn sm', type: 'button', 'data-tip': 'Font e colori della scritta d\'apertura: scegli uno stile o fai il tuo', onclick: () => styleBox() }, icon('text', 13, 'currentColor', 2.2), 'Stile titoli') : null,
        n ? h('button', { class: 'btn sm' + (selecting ? ' on' : ''), type: 'button', onclick: () => { selecting = !selecting; selected.clear(); drawTools(); drawGrid(); drawSel(); } },
          icon('check', 13, 'currentColor', 2.2), selecting ? 'Fine' : 'Seleziona') : null)].filter(Boolean));
  }
  // lingua delle clip: sottotitoli riscritti nella lingua scelta, titoli e scritte tradotti
  function langSel() {
    const L = data.langs || { it: 'italiano', en: 'inglese' };
    const sel = h('select', { class: 'cg-lang', 'aria-label': 'Lingua delle clip', 'data-tip': 'Lingua di sottotitoli, titoli e scritte delle clip' },
      ...Object.entries(L).map(([k, v]) => h('option', { value: k, selected: k === data.lang ? true : null }, v.charAt(0).toUpperCase() + v.slice(1))));
    sel.addEventListener('change', async () => {
      const lang = sel.value;
      if (!await confirmBox('Clip in ' + L[lang] + '?', 'Riscrivo i sottotitoli delle clip ascoltando di nuovo l\'audio in ' + L[lang] + ' (gratis, sul tuo computer) e traduco titoli e scritte d\'apertura con l\'AI.', 'Cambia lingua')) { sel.value = data.lang; return; }
      let j;
      try { j = await post(`/api/p/${pid}/cliplang`, { lang }); } catch (e) { sel.value = data.lang; return toast(e.message, true); }
      showStatus(j, 'Cambio la lingua delle clip');
      let r;
      try { r = await pollJob(j.id, (x) => { if (alive) showStatus(x, 'Cambio la lingua delle clip'); }); } catch (e) { r = { status: 'error', error: e.message }; }
      if (!alive) return;
      status.style.display = 'none';
      if (r.status !== 'done') { toast(r.error || 'Lingua non cambiata', true); await reload(); return; }
      toast(r.result && r.result.translated ? 'Clip in ' + L[lang] + ': sottotitoli e titoli aggiornati' : 'Sottotitoli in ' + L[lang] + ' (titoli non tradotti: serve una chiave AI)');
      await reload();
      await previews(data.clips.map((c) => c.id));
    });
    return sel;
  }
  // stile della scritta d'apertura (vale per tutte le clip e per le prossime)
  async function styleBox() {
    const u = { ...(await loadHookStyle()) };
    const bg = h('div', { class: 'modal-bg' });
    const pv = h('canvas', { class: 'cg-hpv' });
    const paint = async () => {
      const st = hookStyle(u);
      await ensureFont(st.font);
      const cv = drawText({ ...st, content: hookContent('Non ci credo IMPOSSIBILE') }, 900);
      pv.width = cv.width; pv.height = cv.height; pv.getContext('2d').drawImage(cv, 0, 0);
    };
    const presets = h('div', { class: 'cg-hpre' });
    const drawPre = () => presets.replaceChildren(...HOOK_PRESETS.map(([k, name]) => h('button', { class: 'btn sm' + (u.preset === k ? ' on' : ''), type: 'button',
      onclick: () => { u.preset = k; delete u.font; delete u.color; delete u.hlColor; delete u.stroke; delete u.box; delete u.boxColor; syncInputs(); drawPre(); paint(); } }, name)));
    const font = h('select', { class: 'cg-lang', 'aria-label': 'Font' }, ...HOOK_FONTS.map((f) => h('option', { value: f }, f)));
    const col = h('input', { type: 'color', 'aria-label': 'Colore del testo' });
    const hl = h('input', { type: 'color', 'aria-label': 'Colore della parola in evidenza' });
    const stroke = h('input', { type: 'checkbox' });
    const box = h('input', { type: 'checkbox' });
    const syncInputs = () => { const st = hookStyle(u); font.value = st.font; col.value = st.color; hl.value = st.hlColor || '#FFD60A'; stroke.checked = !!st.stroke; box.checked = !!st.box; };
    font.addEventListener('change', () => { u.font = font.value; paint(); });
    col.addEventListener('input', () => { u.color = col.value.toUpperCase(); paint(); });
    hl.addEventListener('input', () => { u.hlColor = hl.value.toUpperCase(); paint(); });
    stroke.addEventListener('change', () => { u.stroke = stroke.checked; paint(); });
    box.addEventListener('change', () => { u.box = box.checked; if (box.checked && !hookStyle(u).boxColor) u.boxColor = '#FFFFFF'; paint(); });
    syncInputs(); drawPre(); paint();
    const close = () => bg.remove();
    const save = async () => {
      try { await post('/api/settings', { hookStyle: u }); } catch (e) { return toast(e.message, true); }
      userHook = u; close();
      toast('Stile salvato: aggiorno le scritte delle clip');
      for (const c of data.clips) { try { await bakeHooks(c.id, true); } catch (e) { /* */ } }
      await reload();
      await previews(data.clips.map((c) => c.id));
    };
    const row = (label, el) => h('label', { class: 'cg-hrow' }, h('span', null, label), el);
    bg.append(h('div', { class: 'modal cg-hmodal', role: 'dialog', 'aria-label': 'Stile dei titoli' },
      h('h2', null, 'Stile dei titoli'),
      h('p', { class: 'muted' }, 'La scritta d\'apertura di tutte le clip. Parti da uno stile e mettici font e colori del tuo brand: vale anche per le prossime clip.'),
      h('div', { class: 'cg-hpvw' }, pv), presets,
      h('div', { class: 'cg-hgrid' }, row('Font', font), row('Testo', col), row('Parola in evidenza', hl), row('Contorno', stroke), row('Riquadro', box)),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px', marginTop: '14px' } },
        h('button', { class: 'btn ghost', type: 'button', onclick: close }, 'Annulla'),
        h('button', { class: 'btn primary', type: 'button', onclick: save }, 'Salva e applica'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  function visible() {
    let l = data.clips.filter((c) => (c.score == null || c.score >= minScore) && (!query || String(c.name || '').toLowerCase().includes(query)));
    l = l.slice().sort((a, b) => (sort === 'time' ? a.a - b.a : (b.score ?? -1) - (a.score ?? -1) || a.a - b.a));
    return l;
  }

  // ---------------------------------------------------------------- scheda di una clip
  function card(c) {
    const pv = h('div', { class: 'cg-pv' });
    const posterSrc = c.poster ? mediaUrl(c.poster) + '&v=' + Math.round(c.previewAt || 0) : thumbUrl(pid, Math.min((data.duration || 1) - 0.5, c.a + 1), 480);
    const img = h('img', { class: 'cg-poster' + (c.poster ? '' : ' raw'), src: posterSrc, alt: '', loading: 'lazy', draggable: 'false' });
    pv.append(img);
    let vid = null;
    if (c.preview) {
      pv.addEventListener('pointerenter', () => {
        if (selecting) return;
        if (!vid) { vid = h('video', { class: 'cg-vid', src: mediaUrl(c.preview) + '&v=' + Math.round(c.previewAt || 0), muted: true, loop: true, playsinline: true, preload: 'auto' }); vid.muted = true; pv.append(vid); }
        vid.currentTime = 0; vid.play().catch(() => {});
      });
      pv.addEventListener('pointerleave', () => { if (vid) vid.pause(); });
    }
    if (working.has(c.id) || queued.has(c.id) || (!c.preview && (pjob || job))) pv.append(h('div', { class: 'cg-wait' }, h('span', { class: 'spinner sm' }), h('span', null, 'Preparo l\'anteprima')));
    else if (!c.preview) pv.append(h('div', { class: 'cg-wait soft' }, h('span', null, 'Anteprima non pronta')));
    if (c.edited) pv.append(h('span', { class: 'cg-badge' }, 'Modificato'));
    pv.append(h('span', { class: 'cg-time' }, h('b', null, mmss(c.dur)), h('span', null, 'da ' + hms(c.a))));
    if (selecting) pv.append(h('span', { class: 'cg-check' + (selected.has(c.id) ? ' on' : '') }, icon('check', 14, '#fff', 3)));
    const el = h('article', { class: 'cg-card' + (selected.has(c.id) ? ' sel' : ''), tabindex: '0', 'aria-label': c.name },
      pv,
      h('div', { class: 'cg-meta' },
        h('div', { class: 'cg-row' },
          h('b', { class: 'cg-score', style: { color: scoreColor(c.score) }, 'data-tip': 'Punteggio di viralità (0-100)' }, c.score != null ? String(c.score) : '–'),
          h('div', { class: 'cg-acts' },
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Esporta', 'data-tip': 'Esporta il video', onclick: (e) => { e.stopPropagation(); exportClips([c.id]); } }, icon('download', 17, 'currentColor', 2)),
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Modifica', 'data-tip': 'Modifica nell\'editor', onclick: (e) => { e.stopPropagation(); openClip(c); } }, icon('scissors', 17, 'currentColor', 2)),
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Altro', 'data-tip': 'Altro', onclick: (e) => { e.stopPropagation(); more(c, e.currentTarget); } }, icon('dots', 17, 'currentColor', 2)))),
        h('h3', { class: 'cg-name', 'data-notr': '' }, c.name),
        c.why ? h('p', { class: 'cg-why' }, c.why) : null));
    el.addEventListener('click', () => { if (selecting) { selected.has(c.id) ? selected.delete(c.id) : selected.add(c.id); drawGrid(); drawSel(); } else player(c); });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') el.click(); });
    return el;
  }

  function drawGrid() {
    const l = visible();
    if (!data.clips.length) { grid.replaceChildren(empty()); return; }
    if (!l.length) { grid.replaceChildren(h('div', { class: 'cg-none' }, 'Nessuna clip con questi filtri.')); return; }
    grid.replaceChildren(...l.map(card));
  }

  function empty() {
    const est = h('p', { class: 'cg-est' }, ' ');
    post(`/api/p/${pid}/clipestimate`).then((e) => {
      if (!alive) return;
      if (e.error) { est.textContent = e.error; return; }
      est.textContent = `Circa ${e.target} clip per questa live · lettura AI ~$${(+e.usd).toFixed(2)}` + (e.hasTranscript ? '' : ' · prima la trascrivo');
    }).catch(() => {});
    return h('div', { class: 'cg-empty' },
      h('div', { class: 'cg-empty-art' }, h('span'), h('span'), h('span')),
      h('h2', null, 'Le clip migliori della tua live, già montate'),
      h('p', null, 'L\'AI ascolta la live, trova i momenti che possono diventare virali e li trasforma in clip verticali: webcam sopra, gioco sotto, sottotitoli grandi e silenzi tolti. Ogni clip ha un punteggio e il motivo.'),
      est,
      h('button', { class: 'btn primary lg', onclick: () => start() }, icon('sparkle', 15, '#fff', 2.2), 'Trova le clip virali'));
  }

  function drawSel() {
    if (!selecting) { selBar.style.display = 'none'; return; }
    selBar.style.display = '';
    const n = selected.size;
    selBar.replaceChildren(h('span', null, n ? `${n} ${n === 1 ? 'clip selezionata' : 'clip selezionate'}` : 'Tocca le clip da scegliere'),
      h('button', { class: 'btn sm', type: 'button', onclick: () => { visible().forEach((c) => selected.add(c.id)); drawGrid(); drawSel(); } }, 'Tutte'),
      h('button', { class: 'btn sm danger', type: 'button', disabled: n ? null : true, onclick: () => removeClips([...selected]) }, icon('trash', 13, 'currentColor', 2), 'Elimina'),
      h('button', { class: 'btn sm primary', type: 'button', disabled: n ? null : true, onclick: () => exportClips([...selected]) }, icon('download', 13, '#fff', 2.2), 'Esporta'));
  }

  // ---------------------------------------------------------------- azioni
  async function openClip(c) {
    try { await bakeHooks(c.id); } catch (e) { /* la scritta la ridisegna l'editor */ }
    nav('editor', c.id);
  }
  async function exportClips(ids) {
    try {
      for (const id of ids) { const c = data.clips.find((x) => x.id === id); if (c && c.needsBake) await bakeHooks(id); }
    } catch (e) { return toast(e.message, true); }
    nav('export', pid, { vod: false, verticals: ids, back: pid, backTo: 'clips' });
  }
  async function rename(c) {
    const nm = await promptBox('Rinomina la clip', 'È anche il nome del file quando la esporti.', c.name, 'Rinomina');
    if (!nm || nm === c.name) return;
    try { await post(`/api/p/${c.id}/rename`, { name: nm }); await post(`/api/p/${pid}/cliprename`, { id: c.id, name: nm }); } catch (e) { return toast(e.message, true); }
    c.name = nm; drawGrid();
  }
  async function removeClips(ids) {
    const one = ids.length === 1;
    if (!await confirmBox(one ? 'Eliminare la clip?' : `Eliminare ${ids.length} clip?`, 'Il video della live resta com\'è.', 'Elimina', true)) return;
    for (const id of ids) {
      try { await api('DELETE', '/api/p/' + id); } catch (e) { /* gia' tolta */ }
      try { await post(`/api/p/${pid}/clipremove`, { id }); } catch (e) { /* */ }
    }
    data.clips = data.clips.filter((c) => !ids.includes(c.id));
    selected.clear(); drawTools(); drawGrid(); drawSel();
  }
  function more(c, at) {
    document.querySelectorAll('.popmenu').forEach((x) => x.remove());
    const it = (ic, label, fn, cls) => h('button', { class: 'pm-it' + (cls ? ' ' + cls : ''), role: 'menuitem', onclick: () => { close(); fn(); } },
      h('span', { class: 'pm-ic' }, icon(ic, 16, cls === 'danger' ? 'var(--danger)' : 'currentColor')), h('span', { class: 'pm-tx' }, h('b', null, label)));
    const m = h('div', { class: 'popmenu cg-menu', role: 'menu' },
      it('play', 'Guarda', () => player(c)), it('type', 'Rinomina', () => rename(c)), it('refresh', 'Aggiorna l\'anteprima', () => refresh([c.id])),
      it('trash', 'Elimina', () => removeClips([c.id]), 'danger'));
    document.body.append(m);
    const r = at.getBoundingClientRect();
    m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, r.right - m.offsetWidth)) + 'px';
    m.style.top = (r.bottom + m.offsetHeight + 8 < innerHeight ? r.bottom + 6 : r.top - m.offsetHeight - 6) + 'px';
    const close = () => { m.remove(); removeEventListener('pointerdown', out, true); };
    const out = (e) => { if (!m.contains(e.target)) close(); };
    setTimeout(() => addEventListener('pointerdown', out, true), 0);
  }

  // finestra per guardare una clip con l'audio, con il punteggio e il motivo
  function player(c) {
    const list = visible();
    let idx = list.findIndex((x) => x.id === c.id);
    const bg = h('div', { class: 'modal-bg cg-modal-bg' });
    const box = h('div', { class: 'cg-modal', role: 'dialog', 'aria-modal': 'true' });
    const close = () => { bg.remove(); removeEventListener('keydown', key); };
    const key = (e) => { if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') go(1); if (e.key === 'ArrowLeft') go(-1); };
    function go(d) { if (list.length < 2) return; idx = (idx + d + list.length) % list.length; draw(); }
    function draw() {
      const x = list[idx];
      const media = x.preview ? h('video', { class: 'cg-mvid', src: mediaUrl(x.preview) + '&v=' + Math.round(x.previewAt || 0), poster: x.poster ? mediaUrl(x.poster) : null, controls: true, autoplay: true, playsinline: true })
        : h('div', { class: 'cg-mnone' }, h('img', { src: thumbUrl(pid, x.a + 1, 640), alt: '' }), h('span', null, 'L\'anteprima non è ancora pronta'));
      box.replaceChildren(...[
        h('button', { class: 'iconbtn cg-mx', 'aria-label': 'Chiudi', onclick: close }, icon('x', 18, 'currentColor', 2)),
        list.length > 1 ? h('button', { class: 'iconbtn cg-mnav l', 'aria-label': 'Clip precedente', onclick: () => go(-1) }, icon('left', 20, 'currentColor', 2.2)) : null,
        h('div', { class: 'cg-mstage' }, media),
        h('div', { class: 'cg-minfo' },
          h('div', { class: 'cg-mscore' }, h('b', { style: { color: scoreColor(x.score) } }, x.score != null ? String(x.score) : '–'), h('span', null, 'su 100 di viralità')),
          h('h2', { 'data-notr': '' }, x.name),
          x.why ? h('p', { class: 'cg-mwhy' }, x.why) : null,
          h('dl', { class: 'cg-mfacts' },
            h('dt', null, 'Durata'), h('dd', null, mmss(x.dur)),
            h('dt', null, 'Nella live'), h('dd', null, hms(x.a) + ' – ' + hms(x.b)),
            x.hook ? h('dt', null, 'Scritta d\'apertura') : null, x.hook ? h('dd', { 'data-notr': '' }, x.hook) : null),
          h('div', { class: 'cg-mbtns' },
            h('button', { class: 'btn primary', onclick: () => { close(); openClip(x); } }, icon('scissors', 14, '#fff', 2), 'Modifica'),
            h('button', { class: 'btn', onclick: () => { close(); exportClips([x.id]); } }, icon('download', 14, 'currentColor', 2), 'Esporta'))),
        list.length > 1 ? h('button', { class: 'iconbtn cg-mnav r', 'aria-label': 'Clip successiva', onclick: () => go(1) }, icon('right', 20, 'currentColor', 2.2)) : null].filter(Boolean));
    }
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
    bg.append(box); document.body.append(bg); addEventListener('keydown', key); draw();
  }

  // ---------------------------------------------------------------- ricerca con l'AI e anteprime
  function showStatus(j, label) {
    status.style.display = '';
    const pct = Math.round((j.progress || 0) * 100);
    status.replaceChildren(...[h('span', { class: 'spinner sm' }),
      h('div', { class: 'cg-st-tx' }, h('b', null, label), h('span', null, j.message || '…')),
      h('div', { class: 'cg-st-bar' }, h('div', { style: { width: pct + '%' } })),
      h('span', { class: 'cg-st-pct' }, pct + '%'),
      j.kind === 'clips' ? h('button', { class: 'btn sm', onclick: () => post(`/api/jobs/${j.id}/cancel`).catch(() => {}) }, 'Annulla') : null].filter(Boolean));
  }
  async function start() {
    if (job) return;
    if (data.clips.some((c) => c.ai && c.edited) || data.clips.length) {
      if (!await confirmBox('Cerco di nuovo le clip?', 'Le clip dell\'AI che non hai modificato vengono sostituite. Quelle che hai modificato restano.', 'Cerca di nuovo')) return;
    }
    try { job = await post(`/api/p/${pid}/clips`, { prompt: qIn.value.trim() }); } catch (e) { return toast(e.message, true); }
    findBtn.disabled = true;
    await follow();
  }
  async function follow() {
    if (!job) return;
    findBtn.disabled = true;
    drawGrid();
    showStatus(job, 'L\'AI cerca le clip');
    let r;
    try { r = await pollJob(job.id, (j) => { if (alive) showStatus(j, 'L\'AI cerca le clip'); }); } catch (e) { r = { status: 'error', error: e.message }; }
    job = null; findBtn.disabled = false;
    if (!alive) return;
    status.style.display = 'none';
    if (r.status !== 'done') { if (r.error && !/annullat/i.test(r.error)) toast(r.error, true); await reload(); return; }
    toast(`${(r.result.clips || []).length} clip pronte da guardare`);
    await reload();
    await previews();
  }
  async function reload() {
    try { data = await post(`/api/p/${pid}/cliplist`); } catch (e) { return; }
    if (alive) { drawTools(); drawGrid(); drawSel(); }
  }
  async function refresh(ids) {
    for (const id of ids) {
      try { await bakeHooks(id); } catch (e) { /* */ }
    }
    await previews(ids);
  }
  // anteprime: prima le scritte d'apertura (le disegna l'app), poi i video leggeri, che compaiono uno alla volta
  const tried = new Set();   // anteprime gia' provate in questa visita (se una non riesce non si riprova all'infinito)
  async function previews(only) {
    const need = (only || data.clips.filter((c) => (!c.preview || c.edited || c.needsBake) && !tried.has(c.id + ':' + (c.updated || 0))).map((c) => c.id))
      .filter((id) => data.clips.some((c) => c.id === id));
    if (!need.length) return;
    if (pjob) { need.forEach((id) => queued.add(id)); drawGrid(); return; }   // dopo quelle in corso
    for (const id of need) {
      const c = data.clips.find((x) => x.id === id);
      if (c && c.needsBake) { try { await bakeHooks(id); } catch (e) { console.warn(e); } }
    }
    if (pjob) return;
    need.forEach((id) => { working.add(id); const c = data.clips.find((x) => x.id === id); if (c) tried.add(c.id + ':' + (c.updated || 0)); });
    drawGrid();
    try { pjob = await post(`/api/p/${pid}/clippreview`, { ids: need }); } catch (e) { working.clear(); return toast(e.message, true); }
    await followPrev();
  }
  async function followPrev() {
    if (!pjob) return;
    let lastDone = -1;
    showStatus(pjob, 'Preparo le anteprime');
    const timer = setInterval(async () => {
      try {
        const d = await post(`/api/p/${pid}/cliplist`);
        if (!alive) return;
        const ready = d.clips.filter((c) => c.preview && working.has(c.id)).map((c) => c.id);
        if (ready.length !== lastDone) { lastDone = ready.length; ready.forEach((id) => working.delete(id)); data = d; drawGrid(); }
      } catch (e) { /* */ }
    }, 4000);
    try { await pollJob(pjob.id, (j) => { if (alive) showStatus(j, 'Preparo le anteprime'); }); } catch (e) { /* */ }
    clearInterval(timer);
    pjob = null; working.clear();
    if (!alive) return;
    status.style.display = 'none';
    await reload();
    const next = [...queued].filter((id) => data.clips.some((c) => c.id === id && (!c.preview || c.edited || c.needsBake)));
    queued.clear();
    if (next.length) await previews(next);
  }

  setCleanup(() => { alive = false; });
  drawTools(); drawGrid(); drawSel();
  if (job) follow();
  else if (pjob) followPrev();
  else if (data.clips.some((c) => !c.preview || c.edited || c.needsBake)) previews();
}
