"""Utility condivise: ffmpeg, probe, cartelle, encoder."""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

# versione installata: ffmpeg sta accanto all'app (cartella "ffmpeg" dell'installazione).
# Se gira un aggiornamento automatico, il codice sta altrove: VODCUT_BASE e' la cartella dell'installazione.
_APP_CODE = os.environ.get("VODCUT_BASE") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _d in (os.path.join(_APP_CODE, "ffmpeg"), os.path.join(os.path.dirname(_APP_CODE), "ffmpeg"),
           os.path.join(os.path.dirname(_APP_CODE), "ffmpeg", "bin")):
    if os.path.isfile(os.path.join(_d, "ffmpeg.exe")) or os.path.isfile(os.path.join(_d, "ffmpeg")):
        os.environ["PATH"] = _d + os.pathsep + os.environ.get("PATH", "")
        break

APP_DIR = os.path.join(os.path.expanduser("~"), "VODcut")
PROJECTS_DIR = os.path.join(APP_DIR, "progetti")
IMPORTS_DIR = os.path.join(APP_DIR, "importati")
EXPORTS_DIR = os.path.join(APP_DIR, "video")
CACHE_DIR = os.path.join(APP_DIR, "cache")
SETTINGS_FILE = os.path.join(APP_DIR, "impostazioni.json")

for d in (APP_DIR, PROJECTS_DIR, IMPORTS_DIR, EXPORTS_DIR, CACHE_DIR):
    os.makedirs(d, exist_ok=True)

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0  # niente finestre nere su Windows


def ffmpeg_bin():
    return shutil.which("ffmpeg") or "ffmpeg"


def ffprobe_bin():
    return shutil.which("ffprobe") or "ffprobe"


def run(cmd, **kw):
    kw.setdefault("creationflags", NO_WINDOW)
    return subprocess.run(cmd, **kw)


def popen(cmd, **kw):
    kw.setdefault("creationflags", NO_WINDOW)
    return subprocess.Popen(cmd, **kw)


def probe(path):
    r = subprocess.run([
        ffprobe_bin(), "-v", "error", "-show_entries",
        "stream=codec_type,codec_name,width,height,r_frame_rate,avg_frame_rate,sample_rate,channels:stream_tags=rotate"
        ":stream_side_data=rotation:format=duration",
        "-of", "json", path], capture_output=True, stdin=subprocess.DEVNULL, creationflags=NO_WINDOW)
    if r.returncode != 0:
        # il motivo vero (es. "moov atom not found" = registrazione non finita) serve a spiegare l'errore
        raise subprocess.CalledProcessError(r.returncode, "ffprobe", r.stdout, r.stderr.decode(errors="ignore")[-400:] if r.stderr else "")
    out = r.stdout
    j = json.loads(out)
    info = {"duration": float(j.get("format", {}).get("duration") or 0), "has_video": False, "has_audio": False}
    for s in j.get("streams", []):
        if s.get("codec_type") == "video" and not info["has_video"]:
            fr = s.get("avg_frame_rate") or s.get("r_frame_rate") or "30/1"
            try:
                num, den = map(float, fr.split("/"))
                fps = num / den if den else 30.0
            except ValueError:
                fps = 30.0
            if not (5 < fps < 241):
                num, den = map(float, (s.get("r_frame_rate") or "30/1").split("/"))
                fps = num / den if den else 30.0
            w_, h_ = int(s["width"]), int(s["height"])
            # video del telefono: salvato in orizzontale con la rotazione nei metadati. ffmpeg, OpenCV e l'anteprima
            # lo mostrano gia' ruotato, quindi le misure vere sono quelle girate
            rot = 0
            try:
                rot = int(float((s.get("tags") or {}).get("rotate") or 0))
            except ValueError:
                pass
            for sd in s.get("side_data_list") or []:
                if "rotation" in sd:
                    try:
                        rot = int(float(sd["rotation"]))
                    except (TypeError, ValueError):
                        pass
            if abs(rot) % 180 == 90:
                w_, h_ = h_, w_
            info.update(has_video=True, width=w_, height=h_, rotation=rot,
                        fps=round(fps, 3), vcodec=s.get("codec_name"))
        elif s.get("codec_type") == "audio" and not info["has_audio"]:
            info.update(has_audio=True, acodec=s.get("codec_name"))
    return info


_ffver = None


def ffmpeg_major():
    global _ffver
    if _ffver is None:
        try:
            out = subprocess.check_output([ffmpeg_bin(), "-version"], creationflags=NO_WINDOW).decode(errors="ignore")
            m = re.search(r"version\s+n?(\d+)", out)
            _ffver = int(m.group(1)) if m else 8  # build 'nightly' = recente
        except Exception:
            _ffver = 6
    return _ffver


def filter_script_args(path):
    """Passa un filter_complex da file (evita limiti di lunghezza su Windows)."""
    if ffmpeg_major() >= 7:
        return ["-/filter_complex", path]
    return ["-filter_complex_script", path]


_nvenc = None


MAC = sys.platform == "darwin"


def nvenc_ok():
    """C'e' un encoder video della scheda grafica? (NVIDIA su Windows, VideoToolbox sul Mac)"""
    global _nvenc
    if _nvenc is None:
        try:
            r = run([ffmpeg_bin(), "-v", "error", "-f", "lavfi", "-i", "color=s=640x360:d=0.1", "-frames:v", "1",
                     "-c:v", "h264_videotoolbox" if MAC else "h264_nvenc", "-f", "null", "-"], capture_output=True, timeout=30)
            _nvenc = r.returncode == 0
        except Exception:
            _nvenc = False
    return _nvenc


def gpu_name():
    return "Apple VideoToolbox" if MAC else "GPU NVIDIA"


def proxy_gpu_args(g=None):
    """Encoder della scheda grafica per le copie leggere dell'anteprima (None se non c'e')."""
    if not nvenc_ok():
        return None
    gop = ["-g", str(g)] if g else []
    if MAC:
        return ["-c:v", "h264_videotoolbox", "-b:v", "2500k", "-allow_sw", "1", *gop, "-pix_fmt", "yuv420p"]
    return ["-c:v", "h264_nvenc", "-preset", "p1", "-rc", "vbr", "-cq", "30", "-b:v", "0", *gop, "-pix_fmt", "yuv420p"]


_hevc = None


def nvenc_hevc_ok():
    global _hevc
    if _hevc is None:
        r = run([ffmpeg_bin(), "-v", "error", "-f", "lavfi", "-i", "color=s=640x360:d=0.1",
                 "-frames:v", "1", "-c:v", "hevc_videotoolbox" if MAC else "hevc_nvenc", "-f", "null", "-"], capture_output=True)
        _hevc = r.returncode == 0
    return _hevc


def export_encoder_args(gpu, codec, bitrate):
    """Encoder per l'esportazione: bitrate scelto (cosi' il peso del file e' prevedibile)."""
    kb = max(300, int(bitrate / 1000))
    rate = ["-b:v", f"{kb}k", "-maxrate", f"{int(kb * 1.5)}k", "-bufsize", f"{kb * 2}k"]
    if codec == "h265":
        if gpu and MAC and nvenc_hevc_ok():
            return ["-c:v", "hevc_videotoolbox", *rate, "-allow_sw", "1", "-pix_fmt", "yuv420p", "-tag:v", "hvc1"]
        if gpu and nvenc_hevc_ok():
            return ["-c:v", "hevc_nvenc", "-preset", "p5", "-rc", "vbr", *rate, "-pix_fmt", "yuv420p", "-tag:v", "hvc1"]
        return ["-c:v", "libx265", "-preset", "fast", *rate, "-x265-params", "log-level=error", "-pix_fmt", "yuv420p", "-tag:v", "hvc1"]
    if gpu and MAC:
        return ["-c:v", "h264_videotoolbox", *rate, "-allow_sw", "1", "-profile:v", "high", "-pix_fmt", "yuv420p"]
    if gpu:
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", *rate, "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "veryfast", *rate, "-pix_fmt", "yuv420p"]


def video_encoder_args(gpu, crf=19):
    if gpu and not MAC:
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", str(crf + 1), "-b:v", "0",
                "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p"]


def replace_retry(src, dst, wait_s=20.0):
    """os.replace che non si arrende subito: su Windows l'antivirus (o un'altra lettura) tiene aperto il file
    appena scritto per qualche secondo. Si riprova; alla fine si prova a copiare."""
    import time
    t0 = time.time()
    delay = 0.1
    last = None
    while time.time() - t0 < wait_s:
        try:
            os.replace(src, dst)
            return dst
        except PermissionError as e:
            last = e
            time.sleep(delay)
            delay = min(1.0, delay * 1.6)
    try:
        shutil.copyfile(src, dst)
        try:
            os.remove(src)
        except OSError:
            pass
        return dst
    except OSError:
        raise RuntimeError("Il file e' bloccato da un altro programma (spesso l'antivirus): riprova tra poco") from last


def tempdir(prefix="vodcut_"):
    return tempfile.mkdtemp(prefix=prefix, dir=CACHE_DIR)


def load_settings():
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(s):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=1)


def fmt_time(t):
    t = max(0, t)
    h, rem = divmod(int(t), 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
