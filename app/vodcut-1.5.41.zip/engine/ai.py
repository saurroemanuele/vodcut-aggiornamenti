"""Storie AI: collegamento ai servizi di intelligenza artificiale con le chiavi dell'utente.

Ogni utente mette le SUE chiavi (OpenAI, Anthropic, Google Gemini, ElevenLabs, fal.ai): i costi sono suoi e
Noonframe non vede niente. Le chiavi restano solo su questo computer, cifrate con l'utente di Windows (DPAPI)
o in un file leggibile solo dall'utente su Mac, e non vengono mai mandate all'interfaccia, nei log o nelle
segnalazioni. Le chiamate partono dal computer direttamente verso il servizio scelto.

Tutti i servizi hanno la stessa forma per il resto dell'app:
- text(cfg, system, user) -> testo (JSON quando serve)
- image(cfg, prompt, refs) -> (bytes, estensione)
- speech(cfg, text) -> (bytes mp3, parole [[parola, inizio, fine]] oppure None)
"""
import base64
import json
import mimetypes
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .util import APP_DIR
from .version import VERSION

KEYS_PATH = os.path.join(APP_DIR, "ai-chiavi.json")
_LOCK = threading.RLock()

PROVIDERS = {
    "openai": {"name": "OpenAI", "does": ["text", "image", "voice"], "site": "https://platform.openai.com/api-keys"},
    "anthropic": {"name": "Anthropic (Claude)", "does": ["text"], "site": "https://console.anthropic.com/settings/keys"},
    "gemini": {"name": "Google Gemini", "does": ["text", "image"], "site": "https://aistudio.google.com/apikey"},
    "elevenlabs": {"name": "ElevenLabs", "does": ["voice"], "site": "https://elevenlabs.io/app/settings/api-keys"},
    "fal": {"name": "fal.ai", "does": ["image", "video"], "site": "https://fal.ai/dashboard/keys"},
}

# modelli proposti (l'utente puo' scriverne un altro nella pagina)
MODELS = {
    "text": {"openai": ["gpt-5-mini", "gpt-5", "gpt-4.1-mini"],
             "anthropic": ["claude-sonnet-5", "claude-haiku-4-5-20251001", "claude-opus-5-5"],
             "gemini": ["gemini-2.5-flash", "gemini-2.5-pro"]},
    "image": {"fal": ["fal-ai/nano-banana-2/edit", "fal-ai/flux/dev", "fal-ai/flux/schnell"],
              "openai": ["gpt-image-1"],
              "gemini": ["gemini-3.1-flash-image", "gemini-2.5-flash-image"]},
    "voice": {"elevenlabs": ["eleven_multilingual_v2", "eleven_v3", "eleven_flash_v2_5"],
              "openai": ["gpt-4o-mini-tts"]},
    "video": {"fal": ["fal-ai/kling-video/v2.6/pro/image-to-video", "fal-ai/kling-video/v3/pro/image-to-video",
                      "fal-ai/kling-video/v2.1/standard/image-to-video"]},
}
OPENAI_VOICES = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer"]

# costi indicativi in dollari (solo una stima: il costo vero lo decide il servizio con il tuo piano)
PRICE = {
    "text": 0.02,                                    # una storia intera (script + scene)
    "image": {"openai": 0.06, "fal": 0.04, "gemini": 0.04},
    "voice_char": {"elevenlabs": 0.00018, "openai": 0.000015},
    "video_sec": {"fal": 0.08},
}


class AIError(Exception):
    code = 0


# ------------------------------------------------------------------ chiavi (mai in chiaro fuori da qui)
def _keychain(op, provider, secret=None):
    """Mac: le chiavi nel Portachiavi di macOS (come le password), non in un file."""
    import subprocess
    svc = "Noonframe AI"
    try:
        if op == "set":
            r = subprocess.run(["security", "add-generic-password", "-a", provider, "-s", svc, "-w", secret, "-U"],
                               capture_output=True, timeout=10)
            return r.returncode == 0
        if op == "get":
            r = subprocess.run(["security", "find-generic-password", "-a", provider, "-s", svc, "-w"], capture_output=True, timeout=10)
            return r.stdout.decode().strip() if r.returncode == 0 else ""
        if op == "del":
            subprocess.run(["security", "delete-generic-password", "-a", provider, "-s", svc], capture_output=True, timeout=10)
            return True
    except Exception:
        return "" if op == "get" else False


def _seal(s, provider=""):
    import sys
    if sys.platform == "darwin" and provider and _keychain("set", provider, s):
        return "keychain:" + provider
    from .account import _seal as seal
    return seal(s)


def _unseal(s):
    if s.startswith("keychain:"):
        return _keychain("get", s.split(":", 1)[1])
    from .account import _unseal as unseal
    return unseal(s)


def _load_keys():
    try:
        with open(KEYS_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_keys(d):
    os.makedirs(APP_DIR, exist_ok=True)
    tmp = KEYS_PATH + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, KEYS_PATH)
    try:
        os.chmod(KEYS_PATH, 0o600)
    except OSError:
        pass


def keys_status():
    d = _load_keys()
    out = {}
    for p, info in PROVIDERS.items():
        e = d.get(p) or {}
        out[p] = {"name": info["name"], "does": info["does"], "site": info["site"], "set": bool(e.get("key")),
                  "hint": e.get("hint") or "", "ok": e.get("ok"), "checked": e.get("checked")}
    return out


def set_key(provider, key):
    if provider not in PROVIDERS:
        raise AIError("Servizio sconosciuto")
    key = (key or "").strip()
    with _LOCK:
        d = _load_keys()
        if not key:
            if (d.get(provider) or {}).get("key", "").startswith("keychain:"):
                _keychain("del", provider)
            d.pop(provider, None)
            _save_keys(d)
            return keys_status()
        if len(key) < 12 or len(key) > 400 or not re.fullmatch(r"[A-Za-z0-9_\-.:/+=]+", key):
            raise AIError("Questa chiave non sembra valida: copiala di nuovo dal sito del servizio")
        d[provider] = {"key": _seal(key, provider), "hint": "…" + key[-4:], "ok": None, "checked": None}
        _save_keys(d)
    return keys_status()


def _key(provider):
    e = _load_keys().get(provider) or {}
    k = _unseal(e.get("key") or "")
    if not k:
        raise AIError(f"Manca la chiave di {PROVIDERS[provider]['name']}: aggiungila in Storie AI → Chiavi AI")
    return k


def _mark(provider, ok):
    with _LOCK:
        d = _load_keys()
        if provider in d:
            d[provider]["ok"] = ok
            d[provider]["checked"] = time.time()
            _save_keys(d)


def test_key(provider):
    """Una chiamata leggera per sapere se la chiave funziona (non costa niente)."""
    k = _key(provider)
    try:
        if provider == "openai":
            _req("GET", "https://api.openai.com/v1/models", {"Authorization": "Bearer " + k}, provider=provider)
        elif provider == "anthropic":
            _req("GET", "https://api.anthropic.com/v1/models", {"x-api-key": k, "anthropic-version": "2023-06-01"}, provider=provider)
        elif provider == "gemini":
            _req("GET", "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1", {"x-goog-api-key": k}, provider=provider)
        elif provider == "elevenlabs":
            _req("GET", "https://api.elevenlabs.io/v1/voices", {"xi-api-key": k}, provider=provider)
        elif provider == "fal":
            # nessuna chiamata gratuita: si chiede lo stato di una richiesta che non esiste (401 = chiave sbagliata)
            try:
                _req("GET", "https://queue.fal.run/fal-ai/flux/requests/00000000-0000-0000-0000-000000000000/status",
                     {"Authorization": "Key " + k}, provider=provider)
            except AIError as e:
                if getattr(e, "code", 0) not in (404, 422, 400):
                    raise
    except AIError:
        _mark(provider, False)
        raise
    _mark(provider, True)
    return keys_status()


# ------------------------------------------------------------------ richieste
def _ssl():
    try:
        from .updater import _ssl_ctx
        return _ssl_ctx()
    except Exception:
        return None


def _friendly(provider, code, msg):
    name = PROVIDERS.get(provider, {}).get("name", provider)
    m = (msg or "").lower()
    if code in (401, 403) and ("key" in m or "auth" in m or "permission" in m or "unauthor" in m or code == 401):
        return f"{name}: la chiave non è valida o non ha i permessi. Controllala in Chiavi AI"
    if code == 402 or "credit" in m or "quota" in m or "balance" in m or "billing" in m or "insufficient" in m:
        return f"{name}: credito finito o fatturazione non attiva sul tuo account"
    if code == 429:
        return f"{name}: troppe richieste in poco tempo. Riprovo tra poco"
    if "safety" in m or "content_policy" in m or "moderation" in m or "blocked" in m:
        return f"{name}: il servizio ha rifiutato questo contenuto (regole di sicurezza). Cambia la descrizione della scena"
    if code and code >= 500:
        return f"{name} non risponde bene in questo momento (errore {code}). Riprova tra poco"
    return f"{name}: {msg or 'errore ' + str(code)}"[:300]


def _req(method, url, headers=None, body=None, raw=None, timeout=120, provider="", want="json"):
    mock = os.environ.get("NOONFRAME_AI_MOCK")     # solo per le prove automatiche: tutte le chiamate a un server finto
    if mock:
        u = urllib.parse.urlparse(url)
        url = mock.rstrip("/") + "/" + u.netloc + u.path + ("?" + u.query if u.query else "")
    h = {"User-Agent": f"Noonframe/{VERSION}"}
    h.update(headers or {})
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        h["Content-Type"] = "application/json"
    elif raw is not None:
        data = raw
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
            b = r.read()
            if want == "bytes":
                return b
            return json.loads(b) if b else {}
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read() or b"{}")
        except Exception:
            j = {}
        err = j.get("error") if isinstance(j, dict) else None
        msg = (err.get("message") if isinstance(err, dict) else err) or (j.get("detail") if isinstance(j, dict) else None) \
            or (j.get("message") if isinstance(j, dict) else None) or ""
        if isinstance(msg, (list, dict)):
            msg = json.dumps(msg)[:200]
        x = AIError(_friendly(provider, e.code, str(msg)))
        x.code = e.code
        raise x
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        x = AIError(f"{PROVIDERS.get(provider, {}).get('name', provider)}: nessuna connessione ({getattr(e, 'reason', e)})")
        x.code = 0
        raise x


def _retry(fn, tries=3, cancel=None):
    """Riprova solo per gli errori temporanei (troppe richieste, server giu', rete)."""
    for k in range(tries):
        try:
            return fn()
        except AIError as e:
            code = getattr(e, "code", 0)
            if k == tries - 1 or not (code == 429 or code == 0 or code >= 500):
                raise
            if cancel and cancel():
                raise
            time.sleep(2 + k * 4)


def parse_json(txt):
    """Il JSON della risposta (anche se il modello ci mette intorno ``` o due righe di testo)."""
    t = (txt or "").strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t)
    try:
        return json.loads(t)
    except Exception:
        a, b = t.find("{"), t.rfind("}")
        if a >= 0 and b > a:
            return json.loads(t[a:b + 1])
        raise AIError("La risposta dell'AI non è nel formato giusto: riprova")


# ------------------------------------------------------------------ testo
def text(cfg, system, user, max_tokens=6000, cancel=None):
    p, model = cfg.get("provider") or "openai", cfg.get("model") or ""
    k = _key(p)
    if p == "openai":
        body = {"model": model or MODELS["text"]["openai"][0], "response_format": {"type": "json_object"},
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        r = _retry(lambda: _req("POST", "https://api.openai.com/v1/chat/completions", {"Authorization": "Bearer " + k}, body,
                                timeout=240, provider=p), cancel=cancel)
        return r["choices"][0]["message"]["content"]
    if p == "anthropic":
        body = {"model": model or MODELS["text"]["anthropic"][0], "max_tokens": max_tokens, "system": system,
                "messages": [{"role": "user", "content": user}]}
        r = _retry(lambda: _req("POST", "https://api.anthropic.com/v1/messages", {"x-api-key": k, "anthropic-version": "2023-06-01"},
                                body, timeout=240, provider=p), cancel=cancel)
        return "".join(b.get("text", "") for b in r.get("content", []) if b.get("type") == "text")
    if p == "gemini":
        m = model or MODELS["text"]["gemini"][0]
        body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": [{"role": "user", "parts": [{"text": user}]}],
                "generationConfig": {"responseMimeType": "application/json"}}
        r = _retry(lambda: _req("POST", f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(m)}:generateContent",
                                {"x-goog-api-key": k}, body, timeout=240, provider=p), cancel=cancel)
        return "".join(pt.get("text", "") for pt in ((r.get("candidates") or [{}])[0].get("content") or {}).get("parts", []))
    raise AIError("Servizio non adatto a scrivere testi")


# ------------------------------------------------------------------ immagini
def _data_uri(path):
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as f:
        return mime, base64.b64encode(f.read()).decode()


def _ext_of(b):
    if b[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return ".webp"
    return ".png"


def image(cfg, prompt, refs=None, ratio="9:16", cancel=None):
    """-> (bytes dell'immagine, estensione). refs: immagini dei personaggi per tenerli uguali tra le scene."""
    p, model = cfg.get("provider") or "fal", cfg.get("model") or ""
    refs = [r for r in (refs or []) if r and os.path.isfile(r)][:4]
    k = _key(p)
    if p == "openai":
        m = model or "gpt-image-1"
        size = "1024x1536" if ratio == "9:16" else "1536x1024" if ratio == "16:9" else "1024x1024"
        if refs:
            bnd = "----nf" + uuid.uuid4().hex
            parts = []
            for key, val in (("model", m), ("prompt", prompt), ("size", size), ("n", "1")):
                parts.append(f'--{bnd}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{val}\r\n'.encode())
            for r in refs:
                mime = mimetypes.guess_type(r)[0] or "image/png"
                with open(r, "rb") as f:
                    parts.append(f'--{bnd}\r\nContent-Disposition: form-data; name="image[]"; filename="{os.path.basename(r)}"\r\n'
                                 f'Content-Type: {mime}\r\n\r\n'.encode() + f.read() + b"\r\n")
            parts.append(f"--{bnd}--\r\n".encode())
            res = _retry(lambda: _req("POST", "https://api.openai.com/v1/images/edits",
                                      {"Authorization": "Bearer " + k, "Content-Type": "multipart/form-data; boundary=" + bnd},
                                      raw=b"".join(parts), timeout=300, provider=p), cancel=cancel)
        else:
            res = _retry(lambda: _req("POST", "https://api.openai.com/v1/images/generations", {"Authorization": "Bearer " + k},
                                      {"model": m, "prompt": prompt, "size": size, "n": 1}, timeout=300, provider=p), cancel=cancel)
        d = (res.get("data") or [{}])[0]
        if d.get("b64_json"):
            b = base64.b64decode(d["b64_json"])
        elif d.get("url"):
            b = _req("GET", d["url"], want="bytes", provider=p)
        else:
            raise AIError("OpenAI non ha restituito l'immagine")
        return b, _ext_of(b)
    if p == "gemini":
        m = model or MODELS["image"]["gemini"][0]
        parts = [{"text": prompt}]
        for r in refs:
            mime, data = _data_uri(r)
            parts.append({"inline_data": {"mime_type": mime, "data": data}})
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(m)}:generateContent"
        body = {"contents": [{"role": "user", "parts": parts}],
                "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": ratio}}}
        try:
            r = _retry(lambda: _req("POST", url, {"x-goog-api-key": k}, body, timeout=300, provider=p), cancel=cancel)
        except AIError as e:
            if getattr(e, "code", 0) != 400:
                raise
            body["generationConfig"] = {"responseModalities": ["TEXT", "IMAGE"]}   # modello che non accetta il formato
            r = _retry(lambda: _req("POST", url, {"x-goog-api-key": k}, body, timeout=300, provider=p), cancel=cancel)
        for pt in ((r.get("candidates") or [{}])[0].get("content") or {}).get("parts", []):
            inl = pt.get("inlineData") or pt.get("inline_data")
            if inl and inl.get("data"):
                b = base64.b64decode(inl["data"])
                return b, _ext_of(b)
        raise AIError("Gemini non ha restituito l'immagine (forse ha rifiutato la richiesta): cambia la descrizione")
    if p == "fal":
        m = model or MODELS["image"]["fal"][0]
        body = {"prompt": prompt, "num_images": 1}
        if "flux" in m:
            body["image_size"] = "portrait_16_9" if ratio == "9:16" else "landscape_16_9" if ratio == "16:9" else "square_hd"
        else:
            body["aspect_ratio"] = ratio
        if refs and m.endswith("/edit"):
            body["image_urls"] = ["data:%s;base64,%s" % _data_uri(r) for r in refs]
        elif m.endswith("/edit"):
            m = m[:-5]      # senza personaggi di riferimento: stesso modello, da solo testo
        res = fal_run(m, body, k, cancel=cancel)
        imgs = res.get("images") or ([res["image"]] if res.get("image") else [])
        if not imgs or not imgs[0].get("url"):
            raise AIError("fal.ai non ha restituito l'immagine")
        u = imgs[0]["url"]
        if not (u.startswith("https://") or u.startswith("data:image/")):
            raise AIError("fal.ai ha restituito un indirizzo non valido")
        b = base64.b64decode(u.split(",", 1)[1]) if u.startswith("data:") else _req("GET", u, want="bytes", provider=p, timeout=180)
        return b, _ext_of(b)
    raise AIError("Servizio non adatto a creare immagini")


def fal_run(model, body, key, cancel=None, timeout=600):
    hdr = {"Authorization": "Key " + key}
    sub = _retry(lambda: _req("POST", "https://queue.fal.run/" + model, hdr, body, provider="fal"), cancel=cancel)
    status_url = sub.get("status_url") or f"https://queue.fal.run/{model}/requests/{sub['request_id']}/status"
    resp_url = sub.get("response_url") or f"https://queue.fal.run/{model}/requests/{sub['request_id']}"
    t0 = time.time()
    while True:
        if cancel and cancel():
            try:
                if sub.get("cancel_url"):
                    _req("PUT", sub["cancel_url"], hdr, provider="fal")
            except AIError:
                pass
            raise AIError("Annullato")
        st = _retry(lambda: _req("GET", status_url, hdr, provider="fal"))
        if st.get("status") == "COMPLETED":
            break
        if st.get("status") in ("FAILED", "ERROR"):
            raise AIError("fal.ai: generazione non riuscita")
        if time.time() - t0 > timeout:
            raise AIError("fal.ai ci sta mettendo troppo: riprova")
        time.sleep(1.5)
    return _retry(lambda: _req("GET", resp_url, hdr, provider="fal"))


# ------------------------------------------------------------------ video (un'immagine che si anima)
def video(cfg, image_path, prompt, seconds=5, cancel=None):
    """Clip video AI a partire dall'immagine della scena (senza audio: la voce la mette Noonframe). -> bytes mp4."""
    p, model = cfg.get("provider") or "fal", cfg.get("model") or ""
    if p != "fal":
        raise AIError("Per i video AI serve fal.ai")
    k = _key(p)
    m = model or MODELS["video"]["fal"][0]
    uri = "data:%s;base64,%s" % _data_uri(image_path)
    dur = "10" if seconds > 5.2 else "5"
    body = {"prompt": prompt, "image_url": uri, "start_image_url": uri, "duration": dur, "generate_audio": False,
            "negative_prompt": "blur, distort, low quality, text, watermark, extra limbs, deformed face"}
    res = fal_run(m, body, k, cancel=cancel, timeout=1200)
    v = res.get("video") or ((res.get("videos") or [None])[0]) or {}
    u = v.get("url") if isinstance(v, dict) else None
    if not u or not u.startswith("https://"):
        raise AIError("fal.ai non ha restituito il video")
    return _req("GET", u, want="bytes", provider=p, timeout=300), int(dur)


# ------------------------------------------------------------------ voce
def voices(provider):
    if provider == "openai":
        return [{"id": v, "name": v.capitalize(), "labels": {}, "preview": ""} for v in OPENAI_VOICES]
    if provider == "elevenlabs":
        r = _req("GET", "https://api.elevenlabs.io/v1/voices", {"xi-api-key": _key("elevenlabs")}, provider="elevenlabs")
        out = []
        for v in r.get("voices", []):
            lab = v.get("labels") or {}
            out.append({"id": v.get("voice_id"), "name": v.get("name") or "", "preview": v.get("preview_url") or "",
                        "labels": {k: lab.get(k) for k in ("gender", "age", "accent", "description", "use_case") if lab.get(k)}})
        return out
    raise AIError("Servizio non adatto alle voci")


def _words_from_alignment(al):
    """Caratteri con i loro tempi -> parole [[parola, inizio, fine]]."""
    chars = al.get("characters") or []
    a = al.get("character_start_times_seconds") or []
    b = al.get("character_end_times_seconds") or []
    words, cur, ca, cb = [], "", None, None
    for ch, s, e in zip(chars, a, b):
        if ch.isspace():
            if cur:
                words.append([cur, round(ca, 3), round(cb, 3)])
            cur, ca, cb = "", None, None
            continue
        if not cur:
            ca = s
        cur += ch
        cb = e
    if cur:
        words.append([cur, round(ca, 3), round(cb, 3)])
    return words


def speech(cfg, text_, voice_id, settings=None, lang="", cancel=None):
    """-> (mp3 bytes, parole con i tempi oppure None)."""
    p, model = cfg.get("provider") or "elevenlabs", cfg.get("model") or ""
    st = settings or {}
    k = _key(p)
    if p == "elevenlabs":
        if not voice_id:
            raise AIError("Scegli una voce ElevenLabs nella pagina")
        body = {"text": text_, "model_id": model or MODELS["voice"]["elevenlabs"][0],
                "voice_settings": {"stability": float(st.get("stability", 0.5)), "similarity_boost": float(st.get("similarity", 0.75)),
                                   "style": float(st.get("style", 0.0)), "speed": float(st.get("speed", 1.0))}}
        if lang and len(lang) == 2 and "multilingual_v2" not in body["model_id"]:
            body["language_code"] = lang
        r = _retry(lambda: _req("POST", f"https://api.elevenlabs.io/v1/text-to-speech/{urllib.parse.quote(voice_id)}/with-timestamps"
                                "?output_format=mp3_44100_128", {"xi-api-key": k}, body, timeout=180, provider=p), cancel=cancel)
        audio = base64.b64decode(r.get("audio_base64") or "")
        if not audio:
            raise AIError("ElevenLabs non ha restituito l'audio")
        return audio, _words_from_alignment(r.get("alignment") or r.get("normalized_alignment") or {}) or None
    if p == "openai":
        body = {"model": model or "gpt-4o-mini-tts", "voice": voice_id or "alloy", "input": text_, "response_format": "mp3"}
        if st.get("instructions"):
            body["instructions"] = str(st["instructions"])[:500]
        if st.get("speed"):
            body["speed"] = float(st["speed"])
        audio = _retry(lambda: _req("POST", "https://api.openai.com/v1/audio/speech", {"Authorization": "Bearer " + k}, body,
                                    timeout=180, provider=p, want="bytes"), cancel=cancel)
        return audio, None
    raise AIError("Servizio non adatto alle voci")


def redact(s):
    """Per log e segnalazioni: toglie tutto quello che somiglia a una chiave."""
    s = re.sub(r"\b(sk-[A-Za-z0-9_\-]{12,})", "sk-***", s or "")
    s = re.sub(r"\bAIza[0-9A-Za-z_\-]{20,}", "AIza***", s)
    s = re.sub(r"(?i)(xi-api-key|x-api-key|x-goog-api-key|authorization)([\"':=\s]+)(Bearer |Key )?[A-Za-z0-9_\-.:]{8,}", r"\1\2***", s)
    return s
