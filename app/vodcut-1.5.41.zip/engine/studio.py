"""Storie AI: pagine (identita' di ogni profilo social) e storie generate con l'AI, scena per scena.

Una PAGINA e' il preset fisso di un profilo: stile delle immagini, personaggi (con foto di riferimento), voci,
regole della narrazione, sottotitoli e musica. Ogni storia nuova usa la sua pagina, cosi' lo stile non cambia.

Una STORIA e' una cartella in ~/VODcut/storie-ai/<id> con storia.json e i file generati. Ogni scena ha il suo
stato: si puo' rigenerare o bloccare una sola scena (o una sola battuta) senza rifare il resto. Se qualcosa si
interrompe, si riparte da dove era arrivato: i file gia' fatti restano.
"""
import json
import os
import re
import secrets
import shutil
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from . import ai
from .util import APP_DIR, NO_WINDOW, ffmpeg_bin, probe

PAGES_DIR = os.path.join(APP_DIR, "pagine")
STORIES_DIR = os.path.join(APP_DIR, "storie-ai")
_LOCKS = {}
_GLOCK = threading.Lock()
MOTIONS = ["zoomIn", "zoomOut", "panL", "panR", "panU", "panD"]

STYLE_PRESETS = {
    "cinematic": "Cinematic photorealistic still, dramatic lighting, shallow depth of field, rich color grading, 35mm film look",
    "anime": "High quality anime illustration, clean line art, expressive characters, vibrant cel shading, detailed backgrounds",
    "pixar": "3D animated film style, soft global illumination, appealing stylized characters, warm colors, high detail render",
    "dark": "Dark horror atmosphere, desaturated palette, heavy shadows, fog, eerie cold light, cinematic composition",
    "comic": "Graphic novel illustration, bold ink outlines, halftone shading, strong contrast, dynamic panels",
    "watercolor": "Soft watercolor painting, delicate textures, pastel palette, gentle light, storybook illustration",
}


def _lock(key):
    with _GLOCK:
        return _LOCKS.setdefault(key, threading.RLock())


def _sid(x):
    x = str(x or "")
    if not re.fullmatch(r"[a-z]{1,2}[0-9a-f]{6,20}", x):
        raise ValueError("Identificativo non valido")
    return x


def _write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def _read(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------------ pagine
def _page_path(pid):
    return os.path.join(PAGES_DIR, _sid(pid), "pagina.json")


def page_defaults():
    return {"name": "Nuova pagina", "handle": "", "lang": "it", "niche": "", "duration": 60,
            "style": {"preset": "cinematic", "prompt": STYLE_PRESETS["cinematic"]},
            "narrative": {"kind": "", "tone": "", "hook": "", "avoid": "", "rules": "", "pov": "terza persona", "ending": ""},
            "characters": [], "narrator": {"id": "", "name": ""},
            "textCfg": {"provider": "", "model": ""}, "imageCfg": {"provider": "", "model": ""},
            "voiceCfg": {"provider": "", "model": "", "stability": 0.5, "similarity": 0.75, "style": 0.0, "speed": 1.0},
            "videoCfg": {"provider": "", "model": "", "share": "few"},
            "edit": {"captions": "word", "music": None, "musicVol": 22}, "history": [],
            "product": {"name": "", "what": "", "audience": "", "benefits": "", "offer": "", "cta": ""}}


def list_pages():
    out = []
    try:
        names = os.listdir(PAGES_DIR)
    except OSError:
        return out
    for n in names:
        try:
            p = _read(os.path.join(PAGES_DIR, n, "pagina.json"))
            out.append(p)
        except Exception:
            continue
    out.sort(key=lambda p: p.get("created") or 0)
    return out


def get_page(pid):
    return _read(_page_path(pid))


def _clean_str(v, n):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v or ""))[:n]


def save_page(data):
    """Crea o aggiorna una pagina (solo i campi conosciuti, con limiti di lunghezza)."""
    pid = data.get("id") or ("pg" + secrets.token_hex(5))
    with _lock(pid):
        try:
            cur = get_page(pid)
        except (FileNotFoundError, ValueError):
            if data.get("id"):
                _sid(pid)
            cur = page_defaults()
            cur.update({"id": pid, "created": time.time()})
        base = page_defaults()
        for k in ("name", "handle", "lang", "niche"):
            if k in data:
                cur[k] = _clean_str(data[k], 2000 if k == "niche" else 80)
        if "duration" in data:
            cur["duration"] = max(15, min(180, int(data.get("duration") or 60)))
        for grp, lim in (("style", 2500), ("narrative", 1500), ("textCfg", 80), ("imageCfg", 80), ("voiceCfg", 200), ("videoCfg", 80),
                         ("narrator", 120), ("edit", 400), ("product", 1500)):
            if isinstance(data.get(grp), dict):
                g = dict(cur.get(grp) or base[grp])
                for k, v in data[grp].items():
                    if k not in base[grp] and grp != "edit":
                        continue
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        g[k] = max(0.0, min(4.0, float(v))) if grp == "voiceCfg" else v
                    elif isinstance(v, dict) and grp == "edit" and k == "music":
                        g[k] = {"file": str(v.get("file") or ""), "name": _clean_str(v.get("name"), 120)} if v.get("file") and os.path.isfile(str(v.get("file"))) else None
                    elif v is None:
                        g[k] = None
                    else:
                        g[k] = _clean_str(v, lim)
                cur[grp] = g
        if isinstance(data.get("characters"), list):
            chars = []
            old = {c["id"]: c for c in cur.get("characters") or []}
            for c in data["characters"][:12]:
                cid = c.get("id") if re.fullmatch(r"ch[0-9a-f]{6,12}", str(c.get("id") or "")) else "ch" + secrets.token_hex(4)
                prev = old.get(cid) or {}
                refs = [r for r in (c.get("refs") if isinstance(c.get("refs"), list) else prev.get("refs") or [])
                        if isinstance(r, str) and os.path.isfile(r) and r.startswith(os.path.join(PAGES_DIR, pid))][:4]
                chars.append({"id": cid, "name": _clean_str(c.get("name"), 40).strip() or "Personaggio",
                              "look": _clean_str(c.get("look"), 1200), "personality": _clean_str(c.get("personality"), 600),
                              "role": _clean_str(c.get("role"), 120),
                              "voice": {"id": _clean_str((c.get("voice") or {}).get("id"), 120), "name": _clean_str((c.get("voice") or {}).get("name"), 120)},
                              "refs": refs})
            cur["characters"] = chars
        cur["updated"] = time.time()
        _write(_page_path(pid), cur)
        return cur


def delete_page(pid):
    d = os.path.join(PAGES_DIR, _sid(pid))
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    return True


def add_ref(pid, cid, src):
    """Foto di riferimento di un personaggio: copiata nella cartella della pagina."""
    import cv2
    import numpy as np
    p = get_page(pid)
    ch = next((c for c in p.get("characters") or [] if c["id"] == cid), None)
    if not ch:
        raise ValueError("Personaggio non trovato: salva la pagina e riprova")
    if len(ch.get("refs") or []) >= 4:
        raise ValueError("Al massimo 4 foto per personaggio")
    # OpenCV (gia' dentro l'app); np.fromfile/tofile per i percorsi con lettere accentate su Windows
    try:
        im = cv2.imdecode(np.fromfile(src, dtype=np.uint8), cv2.IMREAD_COLOR)
    except Exception:
        im = None
    if im is None:
        raise ValueError("Non è un'immagine valida")
    h_, w_ = im.shape[:2]
    k = min(1.0, 1536 / max(h_, w_))
    if k < 1:
        im = cv2.resize(im, (int(w_ * k), int(h_ * k)), interpolation=cv2.INTER_AREA)
    d = os.path.join(PAGES_DIR, pid, "riferimenti")
    os.makedirs(d, exist_ok=True)
    dst = os.path.join(d, f"{cid}_{secrets.token_hex(3)}.jpg")
    ok, buf = cv2.imencode(".jpg", im, [cv2.IMWRITE_JPEG_QUALITY, 92])
    if not ok:
        raise ValueError("Non riesco a salvare la foto")
    buf.tofile(dst)
    ch.setdefault("refs", []).append(dst)
    return save_page({"id": pid, "characters": p["characters"]})


def remove_ref(pid, cid, path):
    p = get_page(pid)
    for c in p.get("characters") or []:
        if c["id"] == cid and path in (c.get("refs") or []):
            c["refs"].remove(path)
            try:
                if path.startswith(os.path.join(PAGES_DIR, pid)):
                    os.remove(path)
            except OSError:
                pass
    return save_page({"id": pid, "characters": p["characters"]})


# ------------------------------------------------------------------ servizi scelti (quelli con la chiave, se la pagina non dice)
def pick(page, what):
    keys = ai.keys_status()
    cfg = dict(page.get({"text": "textCfg", "image": "imageCfg", "voice": "voiceCfg", "video": "videoCfg"}[what]) or {})
    order = {"text": ["anthropic", "openai", "gemini"], "image": ["fal", "gemini", "openai"], "voice": ["elevenlabs", "openai"], "video": ["fal"]}[what]
    if not cfg.get("provider") or not keys.get(cfg["provider"], {}).get("set"):
        cfg["provider"] = next((p for p in order if keys[p]["set"]), "")
        cfg["model"] = ""
    if not cfg["provider"]:
        need = {"text": "OpenAI, Anthropic o Gemini", "image": "fal.ai, Gemini o OpenAI", "voice": "ElevenLabs o OpenAI", "video": "fal.ai"}[what]
        raise ai.AIError(f"Per questo passaggio serve una chiave di {need}: aggiungila in Chiavi AI")
    if not cfg.get("model"):
        cfg["model"] = ai.MODELS[what][cfg["provider"]][0]
    return cfg


# ------------------------------------------------------------------ storie
def _story_dir(sid):
    return os.path.join(STORIES_DIR, _sid(sid))


def _story_path(sid):
    return os.path.join(_story_dir(sid), "storia.json")


def get_story(sid):
    return _read(_story_path(sid))


def save_story(st):
    st["updated"] = time.time()
    _write(_story_path(st["id"]), st)
    return st


def list_stories(pid=None):
    out = []
    try:
        names = os.listdir(STORIES_DIR)
    except OSError:
        return out
    for n in names:
        try:
            s = _read(os.path.join(STORIES_DIR, n, "storia.json"))
        except Exception:
            continue
        if pid and s.get("page") != pid:
            continue
        sc = s.get("scenes") or []
        out.append({"id": s["id"], "page": s.get("page"), "title": s.get("title"), "status": s.get("status"), "created": s.get("created"),
                    "updated": s.get("updated"), "scenes": len(sc), "images": sum(1 for x in sc if (x.get("image") or {}).get("file")),
                    "voices": sum(1 for x in sc if (x.get("audio") or {}).get("file")), "project": s.get("project"),
                    "cost": round(sum(c.get("usd", 0) for c in s.get("costs") or []), 3),
                    "thumb": next(((x.get("image") or {}).get("file") for x in sc if (x.get("image") or {}).get("file")), None)})
    out.sort(key=lambda s: s.get("updated") or 0, reverse=True)
    return out


def delete_story(sid):
    d = _story_dir(sid)
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    return True


def story_files(st):
    """File che l'interfaccia puo' mostrare (immagini e voci della storia)."""
    out = []
    if (st.get("ownVoice") or {}).get("file"):
        out.append(st["ownVoice"]["file"])
    for sc in st.get("scenes") or []:
        for k in ("image", "audio", "video"):
            f = (sc.get(k) or {}).get("file")
            if f:
                out.append(f)
    return out


def _cost(st, kind, provider, model, usd, units=None):
    st.setdefault("costs", []).append({"at": time.time(), "kind": kind, "provider": provider, "model": model,
                                       "usd": round(float(usd), 4), "units": units, "estimate": True})


def estimate(st, page):
    """Costo stimato di quello che manca da fare (dollari, indicativo)."""
    keys = ai.keys_status()
    try:
        ic = pick(page, "image")["provider"]
    except ai.AIError:
        ic = "fal"
    try:
        vc = pick(page, "voice")["provider"]
    except ai.AIError:
        vc = "elevenlabs"
    sc = st.get("scenes") or []
    imgs = sum(1 for x in sc if not (x.get("image") or {}).get("file"))
    chars = sum(len(x.get("text") or "") for x in sc
                if not (x.get("audio") or {}).get("file") or (x.get("audio") or {}).get("text") != x.get("text"))
    if st.get("ownVoice"):
        chars = 0
    durs = scene_durations(st)
    vids = [i for i, x in enumerate(sc) if x.get("kind") == "video" and not _video_ok(x)]
    vid_sec = sum(10 if durs[i] > 5.2 else 5 for i in vids)
    img_usd = imgs * ai.PRICE["image"].get(ic, 0.04)
    v_usd = chars * ai.PRICE["voice_char"].get(vc, 0.0002)
    vid_usd = vid_sec * ai.PRICE["video_sec"]["fal"]
    spent = sum(c.get("usd", 0) for c in st.get("costs") or [])
    return {"images": imgs, "imageUsd": round(img_usd, 3), "chars": chars, "voiceUsd": round(v_usd, 3), "imageProvider": ic,
            "voiceProvider": vc, "videos": len(vids), "videoSec": vid_sec, "videoUsd": round(vid_usd, 3),
            "todo": round(img_usd + v_usd + vid_usd, 3), "spent": round(spent, 3), "keys": {k: v["set"] for k, v in keys.items()},
            "durations": [round(d, 2) for d in durs]}


def _video_ok(sc):
    v = sc.get("video") or {}
    return bool(v.get("file") and os.path.isfile(v["file"]) and v.get("image") == (sc.get("image") or {}).get("file"))


def scene_durations(st):
    """Quanto dura ogni scena: dalla voce vera (generata o registrata) oppure stimata dal testo."""
    own = st.get("ownVoice") or {}
    if own.get("times") and len(own["times"]) == len(st["scenes"]):
        return [max(0.5, b - a) for a, b in own["times"]]
    out = []
    for s in st["scenes"]:
        a = s.get("audio") or {}
        if a.get("file") and a.get("text") == s.get("text") and a.get("dur"):
            out.append(float(a["dur"]) + 0.12)
        else:
            out.append(max(1.2, len((s.get("text") or "").split()) / 2.6))
    return out


SHARES = {"none": 0.0, "few": 0.25, "half": 0.5, "all": 1.0}


def choose_videos(st, share):
    """Quali scene diventano video AI: le piu' importanti (apertura, azione, climax), le altre restano immagini animate."""
    n = len(st["scenes"])
    want = round(n * SHARES.get(share, 0.25))
    if share == "few":
        want = max(1, min(want, 4))
    def score(i):   # importanza scritta dall'AI, poi l'apertura (hook) e il climax (verso i 3/4 della storia)
        return (st["scenes"][i].get("importance") or 2) * 10 + (5 if i == 0 else 0) + (3 if 0.6 * n <= i <= 0.9 * n else 0) - i * 0.01
    order = sorted(range(n), key=score, reverse=True)
    pick = set(order[:want])
    for i, sc in enumerate(st["scenes"]):
        if not sc.get("locked"):
            sc["kind"] = "video" if i in pick else "image"
    st["videoShare"] = share
    return st


# ------------------------------------------------------------------ testo della storia (prompt)
LANG_NAME = {"it": "italiano", "en": "English", "es": "español", "fr": "français", "de": "Deutsch", "pt": "português"}


def _bible(page):
    n = page.get("narrative") or {}
    chars = page.get("characters") or []
    parts = [f"Pagina: {page.get('name')}" + (f" (@{page['handle']})" if page.get("handle") else ""),
             f"Nicchia e argomenti: {page.get('niche') or 'libera'}"]
    for k, lbl in (("kind", "Tipo di storie"), ("tone", "Tono"), ("hook", "Come aprire (hook)"), ("pov", "Punto di vista"),
                   ("ending", "Tipo di finale"), ("rules", "Regole di scrittura"), ("avoid", "Argomenti da evitare")):
        if n.get(k):
            parts.append(f"{lbl}: {n[k]}")
    if chars:
        parts.append("Personaggi ricorrenti (usa questi nomi esatti):")
        for c in chars:
            parts.append(f"- {c['name']}: {c.get('role') or ''} {c.get('personality') or ''}".strip())
    pr = page.get("product") or {}
    if pr.get("name") or pr.get("what"):
        parts.append("PRODOTTO DA PROMUOVERE (usa solo queste informazioni, non inventarne altre):")
        for k, lbl in (("name", "Nome"), ("what", "Cos'è e cosa fa"), ("audience", "Per chi è"), ("benefits", "Benefici"),
                       ("offer", "Prezzo / offerta"), ("cta", "Invito all'azione")):
            if pr.get(k):
                parts.append(f"- {lbl}: {pr[k]}")
    hist = [h.get("title") for h in (page.get("history") or [])[-40:] if h.get("title")]
    if hist:
        parts.append("Storie già pubblicate da NON ripetere (né titoli, né hook, né finali simili): " + "; ".join(hist))
    return "\n".join(parts)


SCHEMA = """Rispondi SOLO con un oggetto JSON, senza testo prima o dopo:
{"title": "titolo breve della storia",
 "scenes": [
   {"speaker": "NARRATORE oppure il nome esatto di un personaggio che parla",
    "text": "la frase detta a voce in questa scena (breve: 6-22 parole)",
    "visual": "in INGLESE: cosa si vede nell'immagine (soggetto, azione, ambiente, luce, emozione). Nomina i personaggi con il loro nome. Niente testo scritto nell'immagine.",
    "characters": ["nomi dei personaggi che si vedono"],
    "shot": "in inglese: tipo di inquadratura (es. close-up, medium shot, wide shot, low angle)",
    "motion": "uno tra zoomIn, zoomOut, panL, panR, panU, panD",
    "importance": 1, 2 o 3 (3 = momento chiave con un'azione o un movimento che merita un vero video: apertura, colpo di scena, climax)}
 ]}"""


def _system(page, lang, fmt=None):
    ln = LANG_NAME.get(lang or page.get("lang") or "it", lang or "italiano")
    extra = ""
    if fmt and fmt.get("prompt"):
        extra = ("\n\nSEGUI QUESTO FORMATO (ricavato da video che funzionano; prendi la struttura, mai le frasi). "
                 "Se contrasta con la struttura generica qui sotto, vale il formato:\n" + fmt["prompt"][:9000] + "\n")
    return extra + (f"Sei lo sceneggiatore di video brevi verticali (TikTok, Reels, Shorts) per questa pagina social.\n{_bible(page)}\n\n"
            f"Scrivi in {ln} il testo parlato. Struttura: HOOK (la prima scena deve incuriosire subito) → contesto → sviluppo → "
            "escalation → climax → finale. Frasi naturali da dire a voce, senza ripetizioni, con ritmo. Distingui narrazione e dialoghi "
            "con lo speaker. Non inventare fatti, citazioni o fonti reali e non usare persone reali: se la storia sembra vera, "
            "mantienila chiaramente narrativa. Ogni scena dura 3-5 secondi.\n\n" + SCHEMA)


def _scenes_from(obj, page):
    names = {c["name"].lower(): c["name"] for c in page.get("characters") or []}
    out = []
    for i, s in enumerate(obj.get("scenes") or []):
        t = _clean_str(s.get("text"), 400).strip()
        if not t:
            continue
        sp = _clean_str(s.get("speaker"), 40).strip()
        sp = names.get(sp.lower(), "" if sp.upper() in ("NARRATORE", "NARRATOR", "") else sp)
        chars = [names[c.lower()] for c in (s.get("characters") or []) if isinstance(c, str) and c.lower() in names]
        mo = s.get("motion") if s.get("motion") in MOTIONS else MOTIONS[i % len(MOTIONS)]
        out.append({"id": "sc" + secrets.token_hex(4), "speaker": sp, "text": t, "visual": _clean_str(s.get("visual"), 1200),
                    "shot": _clean_str(s.get("shot"), 120), "characters": chars, "motion": mo, "locked": False,
                    "importance": max(1, min(3, int(s.get("importance") or 2))) if str(s.get("importance") or "2").isdigit() else 2, "kind": "image",
                    "image": None, "audio": None, "error": None})
    if not out:
        raise ai.AIError("L'AI non ha scritto nessuna scena: riprova")
    return out


def write_story(page, mode, topic, script, duration, lang, cancel=None, fmt=None):
    """Scrive la storia divisa in scene. mode: auto (sceglie l'AI) | topic (argomento dato) | script (testo gia' scritto).
    fmt: formato imparato da video di riferimento (struttura, ritmo, regole)."""
    from . import formats as FM
    cfg = pick(page, "text")
    per = (FM.scene_sec(fmt) if fmt else None) or 4
    n = max(4, min(60, round((duration or page.get("duration") or 60) / per)))
    if mode == "script":
        user = ("Dividi QUESTO script in scene senza cambiare le parole (puoi solo spezzare le frasi). Per ogni scena scrivi "
                f"visual, shot, characters e motion.\n\nSCRIPT:\n{script}")
    elif mode == "topic":
        user = f"Scrivi una storia originale di circa {duration} secondi (circa {n} scene) su questo argomento: {topic}"
    else:
        user = (f"Scegli tu un argomento nuovo, adatto alla pagina, e scrivi una storia originale di circa {duration} secondi "
                f"(circa {n} scene).")
    if fmt and mode == "script":
        user += f"\n\nDividi in scene di circa {per:.1f} secondi (come nel formato)."
    raw = ai.text(cfg, _system(page, lang, fmt), user, cancel=cancel)
    obj = ai.parse_json(raw)
    return {"title": _clean_str(obj.get("title"), 120) or (topic or "Storia")[:60], "scenes": _scenes_from(obj, page), "cfg": cfg}


def rewrite_scene(page, st, i, instruction, cancel=None):
    cfg = pick(page, "text")
    ctx = "\n".join(f"{k + 1}. {(s.get('speaker') or 'NARRATORE')}: {s['text']}" for k, s in enumerate(st["scenes"]))
    user = (f"Questa è la storia attuale:\n{ctx}\n\nRiscrivi SOLO la scena {i + 1}" + (f" seguendo questa indicazione: {instruction}" if instruction else
            " rendendola più forte") + ". Rispondi con lo stesso JSON ma con una sola scena in \"scenes\".")
    obj = ai.parse_json(ai.text(cfg, _system(page, st.get("lang"), _story_fmt(st)), user, cancel=cancel))
    sc = _scenes_from(obj, page)[0]
    return sc, cfg


def refresh_visuals(page, st, cancel=None):
    """Dopo aver cambiato il testo a mano: nuove descrizioni delle immagini per le scene non bloccate."""
    cfg = pick(page, "text")
    ctx = "\n".join(f"{k + 1}. {(s.get('speaker') or 'NARRATORE')}: {s['text']}" for k, s in enumerate(st["scenes"]))
    user = ("Per OGNUNA di queste scene (stesso numero e stesso testo, non cambiarlo) scrivi visual, shot, characters e motion. "
            f"Rispondi con il JSON, una scena per riga dello script, nello stesso ordine.\n\n{ctx}")
    obj = ai.parse_json(ai.text(cfg, _system(page, st.get("lang"), _story_fmt(st)), user, cancel=cancel))
    return obj.get("scenes") or [], cfg


def _story_fmt(st):
    if not st.get("format"):
        return None
    try:
        from . import formats as FM
        return FM.get(st["format"])
    except Exception:
        return None


def image_prompt(page, sc):
    style = ((page.get("style") or {}).get("prompt") or "").strip()
    chars = [c for c in page.get("characters") or [] if c["name"] in (sc.get("characters") or [])]
    parts = []
    if style:
        parts.append(style.rstrip(".") + ".")
    parts.append((sc.get("visual") or sc.get("text") or "").strip().rstrip(".") + ".")
    if sc.get("shot"):
        parts.append(sc["shot"].strip().rstrip(".") + ".")
    for c in chars:
        if c.get("look"):
            parts.append(f"{c['name']} looks exactly like this: {c['look'].strip().rstrip('.')}.")
    parts.append("Vertical 9:16 composition. Keep the same characters, faces and outfits as the reference images. "
                 "No text, no letters, no captions, no watermark, no logos.")
    return " ".join(parts), [r for c in chars for r in (c.get("refs") or [])][:4]


def voice_for(page, sc):
    if sc.get("speaker"):
        c = next((c for c in page.get("characters") or [] if c["name"] == sc["speaker"]), None)
        if c and (c.get("voice") or {}).get("id"):
            return c["voice"]["id"]
    return (page.get("narrator") or {}).get("id") or ""


# ------------------------------------------------------------------ produzione (immagini e voci in parallelo)
def gen_images(sid, only=None, progress=None, cancel=None, workers=3):
    """Crea le immagini che mancano (o quelle scelte). Le scene bloccate non si toccano."""
    with _lock(sid):
        st = get_story(sid)
        page = get_page(st["page"])
    cfg = pick(page, "image")
    todo = [i for i, s in enumerate(st["scenes"]) if not s.get("locked") and
            ((only is None and not (s.get("image") or {}).get("file")) or (only is not None and i in only))]
    if not todo:
        return {"done": 0, "errors": 0}
    d = os.path.join(_story_dir(sid), "immagini")
    os.makedirs(d, exist_ok=True)
    done = [0]
    errors = []

    def one(i):
        if cancel and cancel():
            return
        sc = st["scenes"][i]
        prompt, refs = image_prompt(page, sc)
        try:
            b, ext = ai.image(cfg, prompt, refs, "9:16", cancel=cancel)
            path = os.path.join(d, f"{i + 1:02d}_{sc['id']}_{secrets.token_hex(2)}{ext}")
            with open(path, "wb") as f:
                f.write(b)
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    old = (s2.get("image") or {}).get("file")
                    s2["image"] = {"file": path, "prompt": prompt, "provider": cfg["provider"], "model": cfg["model"], "at": time.time()}
                    s2["error"] = None
                    _cost(cur, "image", cfg["provider"], cfg["model"], ai.PRICE["image"].get(cfg["provider"], 0.04), 1)
                    save_story(cur)
                    if old and old != path and os.path.dirname(old) == d:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
        except ai.AIError as e:
            errors.append(str(e))
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    s2["error"] = str(e)
                    save_story(cur)
        done[0] += 1
        if progress:
            progress(done[0] / len(todo), f"Immagini {done[0]} / {len(todo)}")

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(one, todo))
    if errors and len(errors) == len(todo):
        raise ai.AIError(errors[0])
    return {"done": len(todo) - len(errors), "errors": len(errors), "first": errors[0] if errors else None}


def gen_voices(sid, only=None, progress=None, cancel=None, workers=2):
    with _lock(sid):
        st = get_story(sid)
        page = get_page(st["page"])
    cfg = pick(page, "voice")
    vs = page.get("voiceCfg") or {}
    todo = []
    for i, s in enumerate(st["scenes"]):
        a = s.get("audio") or {}
        stale = a.get("file") and (a.get("text") != s["text"] or a.get("voice") != voice_for(page, s))
        if s.get("locked") and a.get("file"):
            continue
        if (only is None and (not a.get("file") or stale)) or (only is not None and i in only):
            todo.append(i)
    if not todo:
        return {"done": 0, "errors": 0}
    d = os.path.join(_story_dir(sid), "voci")
    os.makedirs(d, exist_ok=True)
    done = [0]
    errors = []

    def one(i):
        if cancel and cancel():
            return
        sc = st["scenes"][i]
        vid = voice_for(page, sc)
        try:
            if not vid and cfg["provider"] == "elevenlabs":
                raise ai.AIError("Scegli la voce del narratore nella pagina (Voci)")
            b, words = ai.speech(cfg, sc["text"], vid or "alloy", vs, st.get("lang") or page.get("lang"), cancel=cancel)
            path = os.path.join(d, f"{i + 1:02d}_{sc['id']}_{secrets.token_hex(2)}.mp3")
            with open(path, "wb") as f:
                f.write(b)
            dur = probe(path)["duration"]
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    old = (s2.get("audio") or {}).get("file")
                    s2["audio"] = {"file": path, "dur": round(dur, 3), "words": words, "text": sc["text"], "voice": vid,
                                   "provider": cfg["provider"], "model": cfg["model"], "at": time.time()}
                    s2["error"] = None
                    _cost(cur, "voice", cfg["provider"], cfg["model"], len(sc["text"]) * ai.PRICE["voice_char"].get(cfg["provider"], 0.0002), len(sc["text"]))
                    save_story(cur)
                    if old and old != path and os.path.dirname(old) == d:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
        except ai.AIError as e:
            errors.append(str(e))
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    s2["error"] = str(e)
                    save_story(cur)
        done[0] += 1
        if progress:
            progress(done[0] / len(todo), f"Voci {done[0]} / {len(todo)}")

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(one, todo))
    if errors and len(errors) == len(todo):
        raise ai.AIError(errors[0])
    return {"done": len(todo) - len(errors), "errors": len(errors), "first": errors[0] if errors else None}


def gen_videos(sid, only=None, progress=None, cancel=None, workers=2):
    """Clip video AI per le scene scelte (dall'immagine gia' approvata). Durata: 5 o 10 secondi secondo la frase."""
    with _lock(sid):
        st = get_story(sid)
        page = get_page(st["page"])
    cfg = pick(page, "video")
    durs = scene_durations(st)
    todo = [i for i, s in enumerate(st["scenes"]) if s.get("kind") == "video" and (s.get("image") or {}).get("file")
            and ((only is None and not _video_ok(s) and not (s.get("locked") and (s.get("video") or {}).get("file")))
                 or (only is not None and i in only))]
    if not todo:
        return {"done": 0, "errors": 0}
    d = os.path.join(_story_dir(sid), "video")
    os.makedirs(d, exist_ok=True)
    done = [0]
    errors = []

    def one(i):
        if cancel and cancel():
            return
        sc = st["scenes"][i]
        img = sc["image"]["file"]
        mot = {"zoomIn": "slow push-in camera", "zoomOut": "slow pull-back camera", "panL": "slow pan to the left", "panR": "slow pan to the right",
               "panU": "slow tilt up", "panD": "slow tilt down"}.get(sc.get("motion"), "subtle camera movement")
        prompt = f"{(sc.get('visual') or sc.get('text') or '').strip().rstrip('.')}. {mot}, natural realistic motion, cinematic, consistent faces, no text."
        try:
            b, sec = ai.video(cfg, img, prompt, durs[i], cancel=cancel)
            path = os.path.join(d, f"{i + 1:02d}_{sc['id']}_{secrets.token_hex(2)}.mp4")
            with open(path, "wb") as f:
                f.write(b)
            try:
                vdur = probe(path)["duration"]
            except Exception:
                vdur = float(sec)
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    old = (s2.get("video") or {}).get("file")
                    s2["video"] = {"file": path, "dur": round(vdur, 3), "image": img, "provider": cfg["provider"], "model": cfg["model"], "at": time.time()}
                    s2["error"] = None
                    _cost(cur, "video", cfg["provider"], cfg["model"], sec * ai.PRICE["video_sec"]["fal"], sec)
                    save_story(cur)
                    if old and old != path and os.path.dirname(old) == d:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
        except ai.AIError as e:
            errors.append(str(e))
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    s2["error"] = str(e)
                    save_story(cur)
        done[0] += 1
        if progress:
            progress(done[0] / len(todo), f"Video {done[0]} / {len(todo)}")

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(one, todo))
    if errors and len(errors) == len(todo):
        raise ai.AIError(errors[0])
    return {"done": len(todo) - len(errors), "errors": len(errors), "first": errors[0] if errors else None}


def join_voices(st, gap=0.12):
    """Una sola traccia voce dalle battute, con i tempi esatti di ogni scena e di ogni parola."""
    sc = st["scenes"]
    if not all((s.get("audio") or {}).get("file") and os.path.isfile(s["audio"]["file"]) for s in sc):
        return None
    d = _story_dir(st["id"])
    out = os.path.join(d, "voce_completa.wav")
    cmd = [ffmpeg_bin(), "-y", "-v", "error"]
    for s in sc:
        cmd += ["-i", s["audio"]["file"]]
    filt = "".join(f"[{k}:a]aresample=44100,aformat=channel_layouts=mono,apad=pad_dur={gap}[a{k}];" for k in range(len(sc)))
    filt += "".join(f"[a{k}]" for k in range(len(sc))) + f"concat=n={len(sc)}:v=0:a=1[out]"
    cmd += ["-filter_complex", filt, "-map", "[out]", "-c:a", "pcm_s16le", out]
    r = subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW)
    if r.returncode != 0:
        raise RuntimeError("Non riesco a unire le voci: " + r.stderr.decode(errors="ignore")[-300:])
    times, words, t = [], [], 0.0
    have_words = True
    for s in sc:
        dur = float(s["audio"].get("dur") or probe(s["audio"]["file"])["duration"])
        seg = dur + gap
        times.append([round(t, 3), round(t + seg, 3)])
        ws = s["audio"].get("words")
        if ws:
            words += [[w, round(a + t, 3), round(b + t, 3)] for w, a, b in ws]
        else:
            have_words = False
        t += seg
    return {"voice": out, "times": times, "words": words if have_words else None, "dur": round(t, 3)}
