"""Account social collegati (per ora TikTok): servono solo a scaricare i video di riferimento nei Formati.

Privacy:
- l'utente accede nella pagina ufficiale di TikTok dentro Noonframe: la password la vede solo TikTok;
- teniamo solo i cookie di sessione di tiktok.com, cifrati sul computer (DPAPI su Windows, Portachiavi su Mac);
- non escono mai dal computer: li usa solo il download locale, con un file temporaneo cancellato subito dopo.
"""
import http.cookiejar
import json
import os
import tempfile
import threading
import time
from contextlib import contextmanager
from email.utils import parsedate_to_datetime

from . import ai

APP_DIR = os.path.join(os.path.expanduser("~"), "VODcut")
PATH = os.path.join(APP_DIR, "social.json")
_LOCK = threading.Lock()
SITES = {"tiktok": ("tiktok.com", "sessionid")}   # sito -> (dominio, cookie che dice "sei dentro")


def _load():
    try:
        with open(PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(d):
    os.makedirs(APP_DIR, exist_ok=True)
    tmp = PATH + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, PATH)
    try:
        os.chmod(PATH, 0o600)
    except OSError:
        pass


def _exp(v):
    """Scadenza del cookie in secondi (0 = di sessione)."""
    if v in (None, "", 0):
        return 0
    if isinstance(v, (int, float)):
        return int(v)
    try:
        return int(parsedate_to_datetime(str(v)).timestamp())
    except Exception:
        pass
    try:
        return int(float(v.timeIntervalSince1970()))     # NSDate (Mac)
    except Exception:
        return int(time.time()) + 30 * 86400


def from_webview(cookies):
    """Lista di SimpleCookie (pywebview) -> lista di dict semplici."""
    out = []
    for c in cookies or []:
        try:
            items = c.items() if hasattr(c, "items") else []
            for name, m in items:
                out.append({"name": name, "value": m.value, "domain": m.get("domain") or "", "path": m.get("path") or "/",
                            "expires": _exp(m.get("expires")), "secure": bool(m.get("secure"))})
        except Exception:
            continue
    return out


def _mine(site, cookies):
    dom = SITES[site][0]
    return [c for c in cookies if str(c.get("domain", "")).lstrip(".").endswith(dom) and c.get("name") and c.get("value") is not None]


def logged_in(site, cookies):
    need = SITES[site][1]
    return any(c["name"] == need and c.get("value") for c in _mine(site, cookies))


def connect(site, cookies):
    """Salva la sessione (solo i cookie del sito, cifrati). True se l'accesso c'e' davvero."""
    cs = _mine(site, cookies)
    if not logged_in(site, cs):
        return False
    with _LOCK:
        d = _load()
        d[site] = {"sealed": ai._seal(json.dumps(cs), "social-" + site), "since": d.get(site, {}).get("since") or time.time(), "updated": time.time()}
        _save(d)
    return True


def disconnect(site):
    with _LOCK:
        d = _load()
        x = d.pop(site, None)
        _save(d)
    if x and str(x.get("sealed", "")).startswith("keychain:"):
        ai._keychain("del", x["sealed"].split(":", 1)[1])


def _cookies(site):
    x = _load().get(site)
    if not x:
        return []
    try:
        return json.loads(ai._unseal(x.get("sealed", "")) or "[]")
    except Exception:
        return []


def status():
    d = _load()
    return {s: {"connected": bool(d.get(s)) and logged_in(s, _cookies(s)), "since": (d.get(s) or {}).get("since")} for s in SITES}


def connected(site):
    return status().get(site, {}).get("connected", False)


@contextmanager
def cookie_file(site):
    """File cookie temporaneo per yt-dlp (solo sul computer, cancellato alla fine). Dopo il download
    tiene aggiornata la sessione se TikTok l'ha rinnovata."""
    cs = _cookies(site)
    if not cs:
        yield None
        return
    d = os.path.join(APP_DIR, "cache")
    os.makedirs(d, exist_ok=True)
    fd, path = tempfile.mkstemp(prefix="c-", suffix=".txt", dir=d)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write("# Netscape HTTP Cookie File\n")
            for c in cs:
                dom = c["domain"] if c["domain"].startswith(".") else c["domain"]
                sub = "TRUE" if dom.startswith(".") else "FALSE"
                f.write("\t".join([dom, sub, c.get("path") or "/", "TRUE" if c.get("secure") else "FALSE",
                                   str(int(c.get("expires") or 0)), c["name"], str(c["value"])]) + "\n")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        yield path
        try:   # sessione rinnovata da TikTok durante il download -> la risalvo
            jar = http.cookiejar.MozillaCookieJar(path)
            jar.load(ignore_discard=True, ignore_expires=True)
            fresh = [{"name": k.name, "value": k.value, "domain": k.domain, "path": k.path, "expires": k.expires or 0, "secure": k.secure} for k in jar]
            if fresh and logged_in(site, fresh):
                connect(site, fresh)
        except Exception:
            pass
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
