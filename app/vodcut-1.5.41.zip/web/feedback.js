// Noonframe - errori che restano a schermo + "Segnala un problema / Richiedi una modifica"
import { h, icon, post, hooks } from './lib.js';

const CTX = { screen: 'home', pid: null };
export function setContext(screen, pid) { CTX.screen = screen; CTX.pid = pid || null; }

// ----------------------------------------------------------------- errori: finestre che restano finché non le chiudi
const LOG = [];          // ultimi errori visti (vanno nella segnalazione)
const CARDS = [];        // {msg, n, el}
let dock = null;
const MAX_CARDS = 3;

function ensureDock() {
  if (dock && dock.isConnected) return dock;
  dock = h('div', { class: 'errdock', role: 'region', 'aria-label': 'Errori' });
  document.body.append(dock);
  return dock;
}
const hhmm = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export function showError(msg) {
  msg = String(msg || 'Errore').trim();
  LOG.push(hhmm() + ' ' + msg);
  if (LOG.length > 60) LOG.shift();
  const same = CARDS.find((c) => c.msg === msg);
  if (same) {                       // stesso errore di nuovo: contatore, niente finestre doppie
    same.n++; same.count.textContent = '×' + same.n; same.count.hidden = false;
    same.el.classList.remove('bump'); void same.el.offsetWidth; same.el.classList.add('bump');
    return;
  }
  const d = ensureDock();
  const count = h('span', { class: 'errcard-n', hidden: true }, '');
  const card = { msg, n: 1, count, time: hhmm() };
  const close = () => { card.el.remove(); CARDS.splice(CARDS.indexOf(card), 1); syncMore(); };
  card.el = h('div', { class: 'errcard', role: 'alertdialog', 'aria-label': 'Errore' },
    h('div', { class: 'errcard-top' },
      h('span', { class: 'errcard-ic' }, icon('alert', 15, 'currentColor', 2.2)),
      h('b', null, 'Qualcosa non ha funzionato'), count,
      h('span', { class: 'errcard-t', 'data-notr': '' }, card.time),
      h('button', { class: 'errcard-x', 'aria-label': 'Chiudi', onclick: close }, icon('x', 13, 'currentColor', 2.4))),
    h('div', { class: 'errcard-msg' }, msg),
    h('div', { class: 'errcard-acts' },
      h('button', { class: 'btn sm primary', onclick: () => openReport({ kind: 'bug', errors: [msg], onSent: close }) }, icon('send', 13, 'currentColor', 2.2), 'Segnala il problema'),
      h('button', { class: 'btn sm ghost', onclick: close }, 'Chiudi')));
  CARDS.push(card);
  d.append(card.el);
  syncMore();
}
function syncMore() {
  if (!dock) return;
  CARDS.forEach((c, i) => c.el.classList.toggle('hid', i < CARDS.length - MAX_CARDS));
  let more = dock.querySelector('.errmore');
  const extra = CARDS.length - MAX_CARDS;
  if (CARDS.length > 1) {
    if (!more) {
      more = h('div', { class: 'errmore' });
      dock.prepend(more);
    }
    more.innerHTML = '';
    more.append(h('span', null, extra > 0 ? `+${extra} altri errori` : `${CARDS.length} errori`),
      h('button', { class: 'linkbtn', onclick: () => openReport({ kind: 'bug', errors: CARDS.map((c) => c.msg), onSent: closeAll }) }, 'Segnalali tutti'),
      h('button', { class: 'linkbtn', onclick: closeAll }, 'Chiudi tutti'));
  } else if (more) more.remove();
}
function closeAll() { CARDS.splice(0).forEach((c) => c.el.remove()); syncMore(); }

// errori del codice dell'app (non dei singoli comandi): anche questi si possono segnalare
function jsError(m) {
  if (!m || /ResizeObserver|Script error\.?$|AbortError|The play\(\) request/i.test(m)) return;
  showError('Errore interno dell\'app: ' + m);
}
window.addEventListener('error', (e) => jsError(e.message));
window.addEventListener('unhandledrejection', (e) => jsError(e.reason && e.reason.message || String(e.reason || '')));
hooks.error = showError;

// ----------------------------------------------------------------- finestra "Segnala / Richiedi una modifica"
const MAX_IMG = 6;
function shrink(file) {
  // screenshot ridotto (max 1600 px, JPEG): leggero da mandare ma ancora leggibile
  return new Promise((res) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, 1600 / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      res(c.toDataURL('image/jpeg', 0.84));
    };
    img.onerror = () => { URL.revokeObjectURL(url); res(null); };
    img.src = url;
  });
}

let open = false;
export function openReport(opt = {}) {
  if (open) return;
  open = true;
  let kind = opt.kind || 'bug';
  const errors = opt.errors || [];
  const images = [];
  const bg = h('div', { class: 'modal-bg' });
  const close = () => { open = false; bg.remove(); document.removeEventListener('keydown', onKey, true); document.removeEventListener('paste', onPaste, true); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };

  const tabs = h('div', { class: 'seg fb-tabs' });
  const title = h('h2', null);
  const sub = h('p', { class: 'muted small fb-sub' });
  const ta = h('textarea', { class: 'fb-text', rows: 5 });
  const errBox = errors.length ? h('div', { class: 'fb-err' }, h('div', { class: 'fb-err-h' }, icon('alert', 13, 'currentColor', 2.2), h('span', null, errors.length > 1 ? 'Errori allegati' : 'Errore allegato')),
    ...errors.map((m) => h('div', { class: 'fb-err-m' }, m))) : null;
  const thumbs = h('div', { class: 'fb-thumbs' });
  const fileIn = h('input', { type: 'file', accept: 'image/*', multiple: true, hidden: true });
  const drop = h('div', { class: 'fb-drop', role: 'button', tabindex: '0' },
    icon('image', 18, 'currentColor', 1.8),
    h('div', null, h('div', { class: 'fb-drop-t' }, 'Aggiungi screenshot'),
      h('div', { class: 'xs muted' }, 'Trascinali qui, clicca, oppure incollali con Ctrl+V (Win+Shift+S per fare uno screen)')));
  const logs = h('input', { type: 'checkbox' });
  const proj = h('input', { type: 'checkbox' });
  const logRow = h('label', { class: 'fb-check' }, logs, h('span', null, h('b', null, 'Allega i log dell\'app'), h('span', { class: 'xs muted' }, 'Ci fanno trovare l\'errore subito. Contengono i nomi dei file e dei progetti (senza il nome utente del PC), niente video.')));
  const projRow = CTX.pid ? h('label', { class: 'fb-check' }, proj, h('span', null, h('b', null, 'Allega il progetto aperto'), h('span', { class: 'xs muted' }, 'Solo le modifiche: niente video e niente parole dette nella live.'))) : null;
  let contactSaved = '';
  try { contactSaved = localStorage.getItem('vodcut.contact') || ''; } catch (e) { /* */ }
  const contact = h('input', { class: 'fb-contact', type: 'text', value: contactSaved, placeholder: 'Il tuo nome o contatto (facoltativo)' });
  const status = h('div', { class: 'fb-status' });
  const sendBtn = h('button', { class: 'btn primary', onclick: () => send() }, icon('send', 14, 'currentColor', 2.1), 'Invia');
  const body = h('div', { class: 'fb-body' });

  function setKind(k) {
    kind = k;
    tabs.innerHTML = '';
    [['bug', 'alert', 'Segnala un problema'], ['idea', 'bulb', 'Richiedi una modifica']].forEach(([key, ic, lab]) =>
      tabs.append(h('button', { 'aria-pressed': kind === key ? 'true' : 'false', onclick: () => setKind(key) }, icon(ic, 13, 'currentColor', 2.1), lab)));
    title.textContent = kind === 'bug' ? 'Segnala un problema' : 'Richiedi una modifica';
    sub.textContent = kind === 'bug' ? 'Racconta cosa stavi facendo e cosa è successo. Arriva direttamente a chi sviluppa Noonframe.'
      : 'Cosa vorresti che Noonframe facesse, o facesse meglio? Ogni richiesta viene letta e valutata.';
    ta.placeholder = kind === 'bug' ? 'Es. Ho cliccato Esporta e il video è uscito senza i tagli…' : 'Es. Vorrei poter cambiare il colore dei sottotitoli parola per parola…';
    logs.checked = kind === 'bug';
    proj.checked = kind === 'bug';
  }
  function renderThumbs() {
    thumbs.innerHTML = '';
    images.forEach((src, i) => thumbs.append(h('div', { class: 'fb-th' }, h('img', { src, alt: '' }),
      h('button', { class: 'fb-th-x', 'aria-label': 'Togli', onclick: () => { images.splice(i, 1); renderThumbs(); } }, icon('x', 11, '#fff', 2.6)))));
    drop.classList.toggle('full', images.length >= MAX_IMG);
  }
  async function addFiles(files) {
    for (const f of [...files].filter((x) => /^image\//.test(x.type))) {
      if (images.length >= MAX_IMG) break;
      const d = await shrink(f);
      if (d) images.push(d);
    }
    renderThumbs();
  }
  const onPaste = (e) => {
    const fs = [...(e.clipboardData && e.clipboardData.items || [])].filter((it) => it.kind === 'file').map((it) => it.getAsFile()).filter(Boolean);
    if (fs.length) { e.preventDefault(); addFiles(fs); }
  };
  drop.addEventListener('click', () => fileIn.click());
  drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileIn.click(); } });
  fileIn.addEventListener('change', () => { addFiles(fileIn.files); fileIn.value = ''; });
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); addFiles(e.dataTransfer.files); });

  async function send() {
    const text = ta.value.trim();
    if (!text && !errors.length) { ta.focus(); ta.classList.add('need'); status.textContent = kind === 'bug' ? 'Scrivi due parole su cosa è successo.' : 'Scrivi cosa vorresti.'; return; }
    try { localStorage.setItem('vodcut.contact', contact.value.trim()); } catch (e) { /* */ }
    sendBtn.disabled = true; status.className = 'fb-status'; status.innerHTML = '';
    status.append(h('span', { class: 'spinner' }), h('span', null, 'Invio…'));
    try {
      const j = await post('/api/feedback', { kind, text, contact: contact.value.trim(), errors, images, logs: logs.checked,
        project: !!(CTX.pid && proj.checked), pid: CTX.pid, screen: CTX.screen, clientLog: LOG.slice(-40) });
      body.innerHTML = '';
      body.append(h('div', { class: 'fb-done' },
        h('div', { class: 'fb-done-ic' }, icon('check', 26, '#fff', 3)),
        h('h2', null, j.sent ? 'Inviata, grazie!' : 'Salvata, grazie!'),
        h('p', { class: 'muted' }, j.sent ? (kind === 'bug' ? 'La segnalazione è arrivata: la guardiamo e sistemiamo con un aggiornamento.' : 'La richiesta è arrivata: se viene approvata la trovi in un prossimo aggiornamento.')
          : 'Adesso non riesco a inviarla (manca la connessione?). È salvata sul PC e parte da sola appena possibile.'),
        h('div', { class: 'row', style: { justifyContent: 'center' } }, h('button', { class: 'btn primary', onclick: close }, 'Ok'))));
      if (opt.onSent) opt.onSent();
    } catch (e) {
      sendBtn.disabled = false;
      status.className = 'fb-status err'; status.textContent = 'Non riesco a salvarla: ' + e.message;
    }
  }

  setKind(kind);
  body.append(...[
    tabs, h('div', null, title, sub), errBox, ta,
    h('div', { class: 'fb-att' }, drop, thumbs), fileIn,
    h('div', { class: 'fb-checks' }, ...[logRow, projRow].filter(Boolean)),
    contact,
    h('div', { class: 'row fb-foot' }, status, h('span', { style: { flex: '1' } }),
      h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), sendBtn)].filter(Boolean));
  bg.append(h('div', { class: 'modal fbmodal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Segnalazione' }, body));
  document.addEventListener('keydown', onKey, true);
  document.addEventListener('paste', onPaste, true);
  document.body.append(bg);
  setTimeout(() => ta.focus(), 50);
}

// pulsante sempre presente nella barra in alto
export function feedbackButton() {
  return h('button', { class: 'fbbtn', 'data-tip': 'Segnala un problema o chiedi una modifica', onclick: () => openReport({ kind: 'bug' }) },
    icon('chat', 14, 'currentColor', 2), h('span', null, 'Feedback'));
}
