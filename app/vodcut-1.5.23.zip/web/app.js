// VODcut - app principale: navigazione e schermate semplici. L'editor e' in editor.js
import { api, get, post, put, h, icon, fmt, fmtDur, toast, confirmBox, seg, pollJob, mediaUrl, thumbUrl, TOKEN, targetRect, IS_MAC } from './lib.js';
import { mountEditor } from './editor.js';
import { feedbackButton, setContext } from './feedback.js';
import { LANG, loadLang, pickLang, startTranslating } from './i18n.js';

const app = document.getElementById('app');
let ENV = { ffmpeg: true, whisper: false, gpu: false, ytdlp: false };
let cleanup = null;

// ----------------------------------------------------------------- barra in alto
const STEPS = ['Importa', 'Webcam', 'Stile', 'Modifica', 'Esporta'];
function topbar(stepIdx, right, allDone, crumb) {
  return h('header', { class: 'topbar' },
    h('button', { class: 'brand', onclick: () => nav('home'), 'aria-label': 'Torna alla home' },
      h('img', { class: 'logo', src: '/web/logo.png', alt: '', draggable: 'false' }), 'VODcut'),
    // clip verticale: al posto dei passaggi, la strada per tornare al video orizzontale
    crumb ? h('nav', { class: 'steps crumbs', 'aria-label': 'Dove sei' },
      crumb.parent ? h('button', { class: 'crumb-back', 'data-tip': 'Torna al video orizzontale (non è stato toccato)', onclick: () => nav('editor', crumb.parent) },
        icon('left', 13, 'currentColor', 2.4), h('span', { 'data-notr': '' }, crumb.parentName || 'Video orizzontale'))
        : h('button', { class: 'crumb-back', 'data-tip': 'Tutti i progetti', onclick: () => nav('home') }, icon('left', 13, 'currentColor', 2.4), h('span', null, 'Progetti')),
      h('span', { class: 'crumb-sep' }, '/'),
      h('span', { class: 'crumb-cur' + (crumb.parent ? '' : ' h') }, icon(crumb.parent ? 'phone' : 'film', 13, 'currentColor', 2), h('span', { 'data-notr': '' }, crumb.name)))
    : stepIdx < 0 ? h('nav', { class: 'steps' }) : h('nav', { class: 'steps', 'aria-label': 'Passaggi' }, STEPS.map((s, i) => {
      const done = allDone || i < stepIdx, cur = !allDone && i === stepIdx;
      return h('div', { class: 'step' + (done ? ' done' : '') + (cur ? ' cur' : ''), 'aria-current': cur ? 'step' : null },
        h('span', { class: 'n' }, done ? icon('check', 11, '#fff', 3.5) : String(i + 1)), s);
    })),
    feedbackButton(),
    updSlot(),
    h('div', { class: 'topright' }, right || null),
    winCtl());
}

// ----------------------------------------------------------------- aggiornamenti automatici
// l'app scarica da sola le versioni nuove in background; qui solo l'avviso "pronto: riavvia" (come CapCut)
let UPD = null, updLater = false, updNewsShown = false;
function updSlot() { const s = h('div', { class: 'updslot' }); fillUpd(s); return s; }
function fillUpd(s) {
  s.innerHTML = '';
  if (!UPD || updLater) return;
  if (UPD.state === 'ready') {
    s.append(h('button', { class: 'updpill', 'data-tip': 'Novità e riavvio', onclick: updDialog },
      h('span', { class: 'updpill-dot' }), 'Aggiornamento pronto'));
  } else if (UPD.state === 'installer') {
    s.append(h('button', { class: 'updpill', 'data-tip': 'C\'è una nuova versione da installare', onclick: updDialog },
      icon('download', 13, 'currentColor', 2.2), 'Nuova versione'));
  }
}
function onUpd(u) {
  if (!u) return;
  const was = UPD && UPD.state + (UPD.version || '');
  UPD = u;
  if (was !== u.state + (u.version || '')) document.querySelectorAll('.updslot').forEach(fillUpd);
  if (u.justUpdated && !updNewsShown) { updNewsShown = true; newsDialog(u.justUpdated); }
}
function notesList(notes) {
  const items = String(notes || '').split(/\n+/).map((x) => x.replace(/^\s*[-•*]\s*/, '').trim()).filter(Boolean);
  return items.length ? h('ul', { class: 'upd-notes' }, ...items.map((x) => h('li', { 'data-notr': '' }, x))) : null;
}
// novita' divise per tipo; se le versioni sono piu' d'una, un riepilogo di tutto con la versione accanto
const CH_TYPES = [['feat', 'Novità', 'sparkle'], ['fix', 'Correzioni', 'check'], ['impr', 'Miglioramenti', 'wand']];
function changesView(hist, notes) {
  hist = (hist || []).filter((e) => e.items && e.items.length);
  if (!hist.length) return notesList(notes);
  const many = hist.length > 1;
  const box = h('div', { class: 'upd-changes' });
  if (many) box.append(h('div', { class: 'upd-recap' }, h('b', null, `${hist.length} aggiornamenti`), h('span', null, ' · ecco tutto quello che è cambiato')));
  CH_TYPES.forEach(([type, label, ic]) => {
    const rows = [];
    hist.forEach((e) => e.items.filter((i) => i.type === type).forEach((i) => rows.push([i.text, e.version])));
    if (!rows.length) return;
    box.append(h('div', { class: 'upd-sec upd-' + type },
      h('div', { class: 'upd-sec-h' }, h('span', { class: 'upd-sec-ic' }, icon(ic, 12, 'currentColor', 2.4)), h('span', null, label), h('span', { class: 'upd-sec-n' }, String(rows.length))),
      h('ul', null, ...rows.map(([t, v]) => h('li', null, h('span', { 'data-notr': '' }, t), many ? h('span', { class: 'upd-ver', 'data-notr': '' }, v) : null)))));
  });
  return box;
}
function updModal(kids) {
  const bg = h('div', { class: 'modal-bg' });
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.append(h('div', { class: 'modal updmodal', role: 'dialog', 'aria-modal': 'true' }, ...kids(close)));
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
}
function updDialog() {
  const u = UPD || {};
  const inst = u.state === 'installer';
  updModal((close) => [
    h('div', { class: 'upd-hero' }, h('img', { src: '/web/logo.png', alt: '' }),
      h('div', null, h('h2', null, inst ? 'Nuova versione di VODcut' : 'Aggiornamento pronto'),
        h('div', { class: 'muted small' }, h('span', null, 'Versione'), ' ', h('b', { 'data-notr': '' }, u.version || ''),
          ' · ', h('span', null, 'ora hai la'), ' ', h('span', { 'data-notr': '' }, u.current || ENV.version || '')))),
    changesView(u.history, u.notes) || h('p', { class: 'muted' }, 'Correzioni e miglioramenti.'),
    inst ? h('p', { class: 'xs', style: { margin: 0 } }, 'Questa versione cambia anche i componenti interni: va scaricata e installata sopra quella che hai. I progetti restano.')
      : h('p', { class: 'xs', style: { margin: 0 } }, 'È già scaricata. Si applica riavviando VODcut, anche più tardi: al prossimo avvio parte da sola.'),
    h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
      h('button', { class: 'btn ghost', onclick: () => { updLater = true; document.querySelectorAll('.updslot').forEach(fillUpd); close(); } }, 'Più tardi'),
      inst ? h('button', { class: 'btn primary', onclick: () => { if (u.installer) post('/api/openurl', { url: u.installer }).catch((e) => toast(e.message, true)); close(); } }, icon('download', 14), 'Scarica')
        : h('button', { class: 'btn primary', onclick: () => { close(); restartForUpdate(); } }, 'Riavvia ora')),
  ]);
}
async function restartForUpdate(force) {
  try {
    const j = await post('/api/update/restart', { force: !!force });
    if (j.busy) {
      if (await confirmBox('C\'è un lavoro in corso', 'Un\'esportazione o un\'analisi non è ancora finita. Se riavvii adesso si interrompe. Meglio aspettare che finisca: l\'aggiornamento si applica anche al prossimo avvio.', 'Riavvia comunque', true)) restartForUpdate(true);
      return;
    }
    document.body.append(h('div', { class: 'modal-bg upd-restarting' }, h('div', { class: 'upd-rs' }, h('div', { class: 'spinner' }), h('div', null, 'Riavvio VODcut…'))));
    // di solito questa finestra si chiude e se ne apre una nuova; se resta aperta, si ricarica da sola
    const old = (await fetch('/api/ping').then((r) => r.json()).catch(() => ({}))).stamp;
    const t0 = Date.now();
    const iv = setInterval(async () => {
      const j = await fetch('/api/ping').then((r) => r.json()).catch(() => null);
      if ((j && j.stamp !== old) || Date.now() - t0 > 60000) { clearInterval(iv); location.href = '/'; }
    }, 1000);
  } catch (e) { toast(e.message, true); }
}
function newsDialog(j) {
  const notes = changesView(j.history, j.notes);
  if (!notes) { toast('VODcut aggiornato alla versione ' + j.version); return; }
  const n = (j.history || []).filter((e) => e.items && e.items.length).length;
  updModal((close) => [
    h('div', { class: 'upd-hero' }, h('img', { src: '/web/logo.png', alt: '' }),
      h('div', null, h('h2', null, n > 1 ? 'Cosa è cambiato' : 'Novità di questa versione'),
        h('div', { class: 'muted small', 'data-notr': '' }, (n > 1 && j.from ? 'VODcut ' + j.from + ' → ' : 'VODcut ') + j.version))),
    notes,
    h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn primary', onclick: close }, 'Ok')),
  ]);
}
async function checkUpdatesNow(btn) {
  const lab = btn.textContent;
  btn.disabled = true; btn.textContent = 'Controllo…';
  try {
    const u = await post('/api/update/check');
    updLater = false; onUpd(u);
    document.querySelectorAll('.updslot').forEach(fillUpd);
    if (u.state === 'ready' || u.state === 'installer') updDialog();
    else if (u.state === 'uptodate') toast('Hai già l\'ultima versione');
    else if (u.state === 'error') toast('Non riesco a controllare gli aggiornamenti adesso. Riprova più tardi.', true);
  } catch (e) { toast(e.message, true); }
  btn.disabled = false; btn.textContent = lab;
}

// ----------------------------------------------------------------- finestra nativa (barra del titolo disegnata dall'app)
// sul Mac la finestra ha la sua barra di macOS: niente pulsanti e bordi disegnati dall'app
const wapi = () => (!IS_MAC && window.pywebview && window.pywebview.api) || null;
const fsApi = () => (window.pywebview && window.pywebview.api) || null;
const WIN_ICONS = {
  min: '<svg width="10" height="10" viewBox="0 0 10 10"><path d="M0 5h10" stroke="currentColor" stroke-width="1"/></svg>',
  max: '<svg width="10" height="10" viewBox="0 0 10 10"><rect x=".5" y=".5" width="9" height="9" rx="1.5" fill="none" stroke="currentColor"/></svg>',
  restore: '<svg width="10" height="10" viewBox="0 0 10 10"><rect x=".5" y="2.5" width="7" height="7" rx="1.2" fill="none" stroke="currentColor"/><path d="M2.5 2.5V1.8A1.3 1.3 0 0 1 3.8.5h4.4A1.3 1.3 0 0 1 9.5 1.8v4.4A1.3 1.3 0 0 1 8.2 7.5H7.5" fill="none" stroke="currentColor"/></svg>',
  close: '<svg width="10" height="10" viewBox="0 0 10 10"><path d="M.5.5l9 9M9.5.5l-9 9" stroke="currentColor" stroke-width="1"/></svg>',
};
let winMax = false;
function winBtn(ic, label, fn, cls) {
  const b = h('button', { class: 'wc' + (cls ? ' ' + cls : ''), 'aria-label': label, 'data-wc': ic, onclick: fn });
  b.innerHTML = WIN_ICONS[ic];
  return b;
}
function syncMaxBtn() {
  document.documentElement.classList.toggle('maxed', winMax);
  document.querySelectorAll('.wc[data-wc="max"], .wc[data-wc="restore"]').forEach((b) => { b.innerHTML = WIN_ICONS[winMax ? 'restore' : 'max']; b.setAttribute('aria-label', winMax ? 'Ripristina' : 'Ingrandisci'); });
}
async function toggleMax() { const a = wapi(); if (!a) return; winMax = !!(await a.toggle_maximize()); syncMaxBtn(); }
function winCtl() {
  return h('div', { class: 'winctl' },
    winBtn('min', 'Riduci a icona', () => wapi() && wapi().minimize()),
    winBtn(winMax ? 'restore' : 'max', winMax ? 'Ripristina' : 'Ingrandisci', toggleMax),
    winBtn('close', 'Chiudi', () => wapi() && wapi().close(), 'close'));
}
// trascinare la barra in alto sposta la finestra; doppio clic la ingrandisce
const NO_DRAG = 'button, input, select, textarea, a, [role="button"], .winctl';
// la barra in alto e' la barra del titolo: trascinandola si sposta la finestra (lo fa Windows), doppio clic = ingrandisci
let lastDown = { t: 0, x: 0, y: 0 };
document.addEventListener('pointerdown', (e) => {
  const a = wapi();
  if (!a || e.button !== 0) return;
  if (!e.target.closest('.topbar') || e.target.closest(NO_DRAG)) return;
  const now = Date.now();
  if (now - lastDown.t < 400 && Math.abs(e.screenX - lastDown.x) < 6 && Math.abs(e.screenY - lastDown.y) < 6) { lastDown.t = 0; toggleMax(); return; }
  lastDown = { t: now, x: e.screenX, y: e.screenY };
  // di riserva, se lo spostamento di Windows non parte: si sposta a mano seguendo il mouse
  const sx = e.screenX, sy = e.screenY, wx = window.screenX, wy = window.screenY, dpr = window.devicePixelRatio || 1;
  let busy = false, next = null, moved = false;
  const push = () => { if (busy || !next) return; busy = true; const n = next; next = null; a.set_bounds(n[0], n[1], 0, 0, dpr).finally(() => { busy = false; push(); }); };
  const mv = (ev) => { if (winMax) return; moved = true; next = [wx + ev.screenX - sx, wy + ev.screenY - sy]; push(); };
  const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); };
  window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  if (a.start_drag) a.start_drag().then(() => { up(); if (a.is_max) a.is_max().then((m) => { winMax = !!m; syncMaxBtn(); }).catch(() => {}); }).catch(() => {});
});
// bordi per ridimensionare la finestra
function mountEdges() {
  for (const ed of ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw']) {
    const el = h('div', { class: 'wedge ' + ed });
    el.addEventListener('pointerdown', (e) => {
      const a = wapi(); if (!a || winMax) return;
      e.preventDefault(); el.setPointerCapture(e.pointerId);
      const sx = e.screenX, sy = e.screenY, dpr = window.devicePixelRatio || 1;
      const r0 = { x: window.screenX, y: window.screenY, w: window.outerWidth, h: window.outerHeight };
      let busy = false, next = null;
      const push = () => { if (busy || !next) return; busy = true; const n = next; next = null; a.set_bounds(n.x, n.y, n.w, n.h, dpr).finally(() => { busy = false; push(); }); };
      const mv = (ev) => {
        const dx = ev.screenX - sx, dy = ev.screenY - sy, r = { ...r0 };
        if (ed.includes('e')) r.w = Math.max(1000, r0.w + dx);
        if (ed.includes('s')) r.h = Math.max(640, r0.h + dy);
        if (ed.includes('w')) { r.w = Math.max(1000, r0.w - dx); r.x = r0.x + r0.w - r.w; }
        if (ed.includes('n')) { r.h = Math.max(640, r0.h - dy); r.y = r0.y + r0.h - r.h; }
        next = r; push();
      };
      const up = () => { el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); };
      el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up);
    });
    document.body.append(el);
  }
}
window.addEventListener('pywebviewready', async () => {
  if (IS_MAC) return;
  document.documentElement.classList.add('native');
  mountEdges();
  try {
    const info = await wapi().setup();
    winMax = !!info.max; syncMaxBtn();
  } catch (e) { /* resta il trascinamento via script */ }
});
// ingrandita anche da Windows (doppio clic o trascinando in alto): aggiorna l'icona
window.addEventListener('resize', () => {
  if (!wapi() || document.fullscreenElement) return;
  const m = window.outerWidth >= screen.availWidth - 2 && window.outerHeight >= screen.availHeight - 2;
  if (m !== winMax) { winMax = m; syncMaxBtn(); }
});
// schermo intero dell'anteprima: la finestra copre tutto lo schermo, anche la barra delle app
document.addEventListener('fullscreenchange', () => { const a = fsApi(); if (a) a.fullscreen(!!document.fullscreenElement).catch(() => {}); });
// niente zoom dell'intera app (Ctrl + rotella, Ctrl +/-/0): e' un'app, non una pagina web
window.addEventListener('wheel', (e) => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
window.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && ['+', '=', '-', '_', '0'].includes(e.key)) e.preventDefault(); });
document.addEventListener('gesturestart', (e) => e.preventDefault());

// ----------------------------------------------------------------- navigazione
// una sola schermata alla volta: un doppio clic (o due aperture ravvicinate) non deve aprire l'editor due volte
let navSeq = 0, lastNav = { key: '', t: 0 };
const stale = (my) => my !== navSeq;
export async function nav(screen, pid, extra) {
  const key = screen + '|' + (pid || '');
  if (key === lastNav.key && Date.now() - lastNav.t < 1500) return;
  lastNav = { key, t: Date.now() };
  const my = ++navSeq;
  setContext(screen, pid);
  if (cleanup) { const c = cleanup; cleanup = null; try { await c(); } catch (e) { /* ignora */ } }
  if (stale(my)) return;
  app.innerHTML = '';
  const routes = { story: screenStory, home: screenHome, webcam: screenWebcam, style: screenStyle, editor: screenEditor, export: screenExport, done: screenDone };
  try { await routes[screen](pid, extra); } catch (e) { console.error(e); toast(e.message, true); if (screen !== 'home') nav('home'); }
}
function setTitle(t) { document.title = t ? t + ' · VODcut' : 'VODcut'; }

// ----------------------------------------------------------------- PROGETTO DA UN ALTRO PC (.vodcut)
const KIND_ICON = { video: 'film', image: 'frame', audio: 'music', file: 'folder' };
const KIND_NAME = { video: 'Video della live', image: 'Immagine', audio: 'Suono', file: 'File' };
// finestra "ricollega i file" (come CapCut): un file alla volta o tutti insieme da una cartella
export function relinkDialog(pid, missing) {
  return new Promise((resolve) => {
    let miss = missing.slice();
    const bg = h('div', { class: 'modal-bg' });
    const list = h('div', { class: 'rl-list' });
    const note = h('p', { class: 'xs', style: { margin: 0 } });
    const openBtn = h('button', { class: 'btn primary' });
    const close = (v) => { bg.remove(); resolve(v); };
    const sourceMissing = () => miss.some((m) => m.source);
    function draw() {
      list.replaceChildren(...missing.map((m) => {
        const still = miss.some((x) => x.path === m.path);
        return h('div', { class: 'rl-row' + (still ? '' : ' ok') },
          h('span', { class: 'rl-ic' }, icon(still ? KIND_ICON[m.kind] || 'folder' : 'check', 16, still ? 'currentColor' : '#32D74B', 2)),
          h('div', { class: 'rl-tx' }, h('b', null, m.name), h('span', null, (KIND_NAME[m.kind] || 'File') + ' · ' + m.path)),
          still ? h('button', { class: 'btn sm', onclick: () => pickOne(m) }, 'Cerca…') : h('span', { class: 'rl-okt' }, 'Collegato'));
      }));
      note.textContent = miss.length ? `Mancano ${miss.length} file su ${missing.length}.` + (sourceMissing() ? ' Senza il video della live il progetto non si può aprire.' : '') : 'Tutti i file sono collegati.';
      openBtn.textContent = miss.length ? 'Apri comunque' : 'Apri il progetto';
      openBtn.disabled = sourceMissing() ? true : null;
    }
    async function pickOne(m) {
      try {
        const r = await post('/api/pick', { kind: m.kind === 'video' ? 'video' : m.kind === 'image' ? 'relink-image' : m.kind === 'audio' ? 'relink-audio' : 'relink-file' });
        let path = r.path;
        if (r.fallback) path = prompt('Percorso completo del file:', '') || '';
        if (!path) return;
        const j = await post(`/api/p/${pid}/relink`, { old: m.path, new: path });
        miss = j.missing;
        // se nella stessa cartella ci sono anche gli altri file, li collega da solo
        if (miss.length) {
          const dir = path.replace(/[\\/][^\\/]*$/, '');
          try { const k = await post(`/api/p/${pid}/relink-folder`, { folder: dir }); miss = k.missing; } catch (e) { /* */ }
        }
        draw();
      } catch (e) { toast(e.message, true); }
    }
    const folderBtn = h('button', { class: 'btn' });
    const folderIdle = () => folderBtn.replaceChildren(icon('folder', 14), 'Cerca in una cartella…');
    folderIdle();
    folderBtn.addEventListener('click', async () => {
      try {
        const r = await post('/api/pick', { kind: 'folder' });
        if (!r.path) return;
        folderBtn.disabled = true; folderBtn.textContent = 'Cerco…';
        const j = await post(`/api/p/${pid}/relink-folder`, { folder: r.path });
        miss = j.missing;
        toast(j.found ? `Collegati ${j.found} file` : 'In questa cartella non ho trovato i file mancanti', !j.found);
      } catch (e) { toast(e.message, true); }
      folderBtn.disabled = null; folderIdle();
      draw();
    });
    openBtn.addEventListener('click', () => close(true));
    bg.append(h('div', { class: 'modal rl-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'File da ricollegare' },
      h('h2', null, 'Ricollega i file'),
      h('p', null, 'Questo progetto usa file che non si trovano in questo PC. Indica dove sono: se sono nella stessa cartella basta sceglierne uno, oppure cerca in una cartella e VODcut li trova tutti.'),
      list, note,
      h('div', { class: 'row', style: { justifyContent: 'space-between' } }, folderBtn,
        h('div', { class: 'row' }, h('button', { class: 'btn ghost', onclick: () => close(false) }, 'Annulla'), openBtn))));
    document.body.append(bg);
    draw();
  });
}
// apre un .vodcut (da percorso o dal file trascinato) e poi, se serve, fa ricollegare i file
// salva il progetto in un file .vodcut (da editor, home e schermata finale)
export async function exportProjectFile(pid, name) {
  try {
    const safe = (name || 'progetto').replace(/[\\/:*?"<>|]+/g, '_');
    const r = await post('/api/pick', { kind: 'project-save:' + safe });
    let path = r.path;
    if (r.fallback) path = prompt('Dove salvo il file? (percorso completo, finisce con .vodcut)', '') || '';
    if (!path) return;
    const j = await post(`/api/p/${pid}/export-project`, { path });
    const nv = j.files.filter((f) => !f.source).length;
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    bg.append(h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
      h('h2', null, 'Progetto salvato'),
      h('p', null, 'Sull\'altro PC fai doppio clic sul file, oppure in VODcut scegli "Apri un progetto da un altro PC".'),
      h('p', { class: 'xs', style: { margin: 0 } }, 'Copia anche il video della live' + (nv ? ` e ${nv} file (immagini e suoni)` : '') + '. Se li metti nella stessa cartella, VODcut li trova tutti insieme.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
        h('button', { class: 'btn ghost', onclick: () => { post('/api/open', { path: j.path, reveal: true }).catch(() => {}); } }, icon('folder', 14), 'Mostra nella cartella'),
        h('button', { class: 'btn primary', onclick: close }, 'Ok'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  } catch (e) { toast(e.message, true); }
}
async function afterImport(res) {
  const proj = res.project;
  toast('Progetto importato: ' + (proj.name || ''));
  if (res.missing && res.missing.length) { const ok = await relinkDialog(proj.id, res.missing); if (!ok) return nav('home'); }
  openProject(proj, true);
}
export async function importProjectPath(path) {
  try { afterImport(await post('/api/import-project', { path })); } catch (e) { toast(e.message, true); }
}
function importProjectFile(file) {
  const xhr = new XMLHttpRequest();
  xhr.open('PUT', '/api/upload?kind=project&token=' + TOKEN + '&name=' + encodeURIComponent(file.name));
  xhr.onload = () => { let j = {}; try { j = JSON.parse(xhr.responseText); } catch (e) { /* */ } if (xhr.status === 200 && j.project) afterImport(j); else toast(j.error || 'Non riesco ad aprire il progetto', true); };
  xhr.onerror = () => toast('Non riesco ad aprire il progetto', true);
  xhr.send(file);
}
async function pickProjectFile() {
  try {
    const r = await post('/api/pick', { kind: 'project-open' });
    let path = r.path;
    if (r.fallback) path = prompt('Percorso completo del file .vodcut:', '') || '';
    if (path) importProjectPath(path);
  } catch (e) { toast(e.message, true); }
}

async function openProject(p, checked) {
  if (!checked) {
    // file spostati o progetto da un altro PC: prima si ricollegano
    try {
      const miss = await get('/api/p/' + p.id + '/missing');
      if (miss.length && !(await relinkDialog(p.id, miss))) return;
    } catch (e) { /* */ }
  }
  const proj = await get('/api/p/' + p.id);
  if (proj.lastExport && proj.stage === 'editor') return nav('editor', p.id);
  nav(proj.stage || 'webcam', p.id);
}

// ----------------------------------------------------------------- HOME
// licenza, privacy e componenti di terze parti (la prima volta la licenza va accettata)
const LIC_FILES = [['Licenza', 'LICENZA.txt', 'en/LICENSE.txt'], ['Privacy', 'PRIVACY.txt', 'en/PRIVACY.txt'], ['Componenti di terze parti', 'COMPONENTI-DI-TERZE-PARTI.txt', 'en/THIRD-PARTY-NOTICES.txt']];
function licenseDialog(start, mustAccept) {
  return new Promise((resolve) => {
    let cur = start || 0;
    const body = h('pre', { class: 'lictext' }, 'Carico…');
    const load = async () => {
      body.textContent = 'Carico…';
      try { body.textContent = await (await fetch('/web/licenze/' + LIC_FILES[cur][LANG === 'en' ? 2 : 1])).text(); } catch (e) { body.textContent = 'Non riesco a leggere il file.'; }
      body.scrollTop = 0;
    };
    const tabs = seg(LIC_FILES.map((x) => x[0]), cur, (i) => { cur = i; [...tabs.children].forEach((b, k) => b.setAttribute('aria-pressed', k === i ? 'true' : 'false')); load(); });
    const bg = h('div', { class: 'modal-bg' });
    const close = (ok) => { bg.remove(); resolve(ok); };
    const acts = mustAccept
      ? [h('span', { class: 'xs muted', style: { marginRight: 'auto' } }, 'Per usare VODcut serve accettare la licenza.'),
        h('button', { class: 'btn primary', onclick: async () => { try { await post('/api/settings', { licenza: ENV.licenseVer || '1.0' }); } catch (e) { /* */ } close(true); } }, 'Accetto')]
      : [h('button', { class: 'btn primary', onclick: () => close(true) }, 'Chiudi')];
    bg.append(h('div', { class: 'modal licmodal' }, h('h2', null, mustAccept ? 'Benvenuto in VODcut' : 'Licenza e informazioni'), tabs, body,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', alignItems: 'center' } }, ...acts)));
    if (!mustAccept) bg.addEventListener('click', (e) => { if (e.target === bg) close(false); });
    document.body.append(bg);
    load();
  });
}

// lingua dell'app: menu a tendina (ogni lingua scritta nella sua lingua)
const LANG_NAMES = [['it', 'Italiano'], ['en', 'English']];
function langPicker() {
  const sel = h('select', { class: 'langsel', 'aria-label': 'Lingua', 'data-notr': '1' },
    ...LANG_NAMES.map(([k, l]) => h('option', { value: k, selected: LANG === k ? true : null }, l)));
  sel.addEventListener('change', () => {
    const k = sel.value;
    try { localStorage.setItem('vodcut.lang', k); } catch (e) { /* */ }
    post('/api/settings', { lang: k }).catch(() => {}).finally(() => location.reload());
  });
  return h('label', { class: 'langpick', 'data-tip': LANG === 'en' ? 'Language' : 'Lingua' }, icon('globe', 13), sel);
}

async function screenHome() {
  const my = navSeq;
  setTitle('');
  const drop = h('div', { class: 'drop', role: 'button', tabindex: '0', 'aria-label': 'Scegli o trascina qui il VOD' });
  const dropMsg = h('div', { style: { fontSize: '20px', fontWeight: '600' } }, 'Trascina qui il VOD');
  const dropSub = h('div', { class: 'muted small' }, 'MP4 o MKV, anche di più ore');
  const pickBtn = h('button', { class: 'btn', onclick: (e) => { e.stopPropagation(); pickVideo(); } }, 'Scegli file…');
  const bar = h('div', { class: 'progress', style: { width: '320px', display: 'none' } }, h('div', { style: { width: '0%' } }));
  drop.append(h('div', { class: 'ico' }, icon('upload', 30, '#F5F5F7', 1.8)), h('div', { style: { textAlign: 'center', display: 'flex', flexDirection: 'column', gap: '4px' } }, dropMsg, dropSub), bar, pickBtn);
  drop.addEventListener('click', () => pickVideo());
  drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickVideo(); } });
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', (e) => {
    e.preventDefault(); drop.classList.remove('over');
    const f = e.dataTransfer.files[0];
    if (f && /\.vodcut$/i.test(f.name)) importProjectFile(f);
    else if (f) uploadVideo(f);
  });

  function busy(msg, pct) {
    dropMsg.textContent = msg; dropSub.textContent = pct != null ? Math.round(pct * 100) + '%' : '';
    bar.style.display = pct != null ? 'block' : 'none'; bar.firstChild.style.width = ((pct || 0) * 100) + '%';
    pickBtn.style.display = 'none';
  }
  function idle() { dropMsg.textContent = 'Trascina qui il VOD'; dropSub.textContent = 'MP4 o MKV, anche di più ore'; bar.style.display = 'none'; pickBtn.style.display = ''; }

  async function pickVideo() {
    try {
      const r = await post('/api/pick', { kind: 'video' });
      if (r.fallback) return askPath();
      if (!r.path) return;
      await createFrom(r.path);
    } catch (e) { toast(e.message, true); }
  }
  async function askPath() {
    const inp = h('input', { class: 'input', placeholder: 'C:\\Users\\...\\video.mp4', style: { width: '100%' } });
    const ok = await new Promise((res) => {
      const bg = h('div', { class: 'modal-bg' });
      const done = (v) => { bg.remove(); res(v); };
      bg.append(h('div', { class: 'modal' }, h('h2', null, 'Percorso del VOD'), h('p', null, 'Incolla il percorso completo del file.'), inp,
        h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: () => done(false) }, 'Annulla'), h('button', { class: 'btn primary', onclick: () => done(true) }, 'Apri'))));
      document.body.append(bg); inp.focus();
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') done(true); });
    });
    if (ok && inp.value.trim()) await createFrom(inp.value.trim());
  }
  async function createFrom(path) {
    busy('Apro il VOD…');
    try { const p = await post('/api/projects', { source: path }); nav('webcam', p.id); } catch (e) { idle(); toast(e.message, true); }
  }
  function uploadVideo(file) {
    busy('Importo ' + file.name, 0);
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', '/api/upload?token=' + TOKEN + '&name=' + encodeURIComponent(file.name));
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) busy('Importo ' + file.name, e.loaded / e.total); };
    xhr.onload = () => {
      let j = {}; try { j = JSON.parse(xhr.responseText); } catch (e) { /* */ }
      if (xhr.status === 200 && j.id) nav('webcam', j.id); else { idle(); toast(j.error || 'Import non riuscito', true); }
    };
    xhr.onerror = () => { idle(); toast('Import non riuscito', true); };
    xhr.send(file);
  }

  const link = h('input', { id: 'vodlink', class: 'input', type: 'text', placeholder: 'twitch.tv/videos/…  ·  kick.com/…', style: { flexGrow: '1' } });
  const linkStatus = h('div', { class: 'xs', style: { minHeight: '16px' } });
  const linkBtn = h('button', { class: 'btn primary', onclick: importLink }, 'Importa');
  link.addEventListener('keydown', (e) => { if (e.key === 'Enter') importLink(); });
  async function importLink() {
    const url = link.value.trim();
    if (!url) return link.focus();
    if (!ENV.ytdlp) return toast('Per importare da link serve yt-dlp: riesegui INSTALLA.bat', true);
    linkBtn.disabled = true;
    try {
      const j = await post('/api/import-url', { url });
      const res = await pollJob(j.id, (jj) => { linkStatus.textContent = 'Scarico il VOD… ' + Math.round(jj.progress * 100) + '%'; });
      if (res.status === 'done') nav('webcam', res.result.project);
      else { linkStatus.textContent = ''; toast(res.error || 'Download non riuscito', true); }
    } catch (e) { toast(e.message, true); }
    linkBtn.disabled = false;
  }

  const recentGrid = h('div', { class: 'pgrid' });
  const trashN = h('span', { class: 'trash-n' });
  const trashBtn = h('button', { class: 'btn ghost sm', 'data-tip': 'I progetti eliminati restano qui per 30 giorni', onclick: () => trashDialog(() => nav('home')) }, icon('trash', 14), 'Cestino', trashN);
  const refreshTrashN = () => get('/api/trash').then((l) => { trashN.textContent = l.length ? String(l.length) : ''; }).catch(() => {});
  refreshTrashN();
  const search = h('input', { class: 'psearch', type: 'search', placeholder: 'Cerca un progetto' });
  const pcount = h('span', { class: 'pcount' });
  const recent = h('section', { class: 'projects', style: { display: 'none' } },
    h('div', { class: 'phead' }, h('h2', null, 'I tuoi progetti'), pcount, h('div', { class: 'grow' }),
      h('label', { class: 'psearch-w' }, icon('magnify', 14), search),
      h('button', { class: 'btn ghost sm', 'data-tip': 'Apri un progetto passato da un altro PC (.vodcut)', onclick: pickProjectFile }, icon('folder', 14), 'Importa'),
      trashBtn),
    recentGrid);
  const banner = h('div', { class: 'banner', style: { display: 'none' } });

  // prima cosa: che tipo di video fai
  const vodBox = h('div', { class: 'vodbox', style: { display: 'none' } },
    h('button', { class: 'btn ghost sm', style: { alignSelf: 'flex-start' }, onclick: () => showChoice(true) }, icon('left', 14), 'Indietro'),
    h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'center' } },
      h('h1', null, 'Dalla live a YouTube, in automatico.'),
      h('p', { class: 'lead' }, 'Tagliamo le pause lunghe e zoomiamo sulla tua faccia quando reagisci. Tu scegli solo lo stile.')),
    drop,
    h('div', { style: { width: 'min(760px,100%)', display: 'flex', flexDirection: 'column', gap: '6px' } },
      h('div', { class: 'row' }, h('label', { for: 'vodlink', class: 'muted', style: { whiteSpace: 'nowrap' } }, 'Oppure incolla il link'), link, linkBtn), linkStatus));
  // ---- home: in alto le partenze (un progetto nuovo in un clic, con il formato), sotto i tuoi progetti
  const QF = [['16:9', 'YouTube'], ['9:16', 'TikTok · Reels'], ['1:1', 'Post'], ['4:5', 'Instagram']];
  const fmtChip = ([k, sub]) => {
    const [a, b2] = k.split(':').map(Number);
    return h('button', { class: 'hq-fmt', onclick: (e) => { e.stopPropagation(); quickBlank(k); } },
      h('i', { style: { aspectRatio: a + ' / ' + b2 } }), h('b', null, k), h('small', null, sub));
  };
  const art = (kind) => {
    if (kind === 'live') return h('div', { class: 'hc-art art-live' }, h('span', { class: 'art-pill' }, 'LIVE'),
      h('div', { class: 'art-wave' }, ...Array.from({ length: 28 }, (_, i) => h('i', { style: { height: (18 + Math.abs(Math.sin(i * 1.7)) * 70) + '%' } }))),
      h('span', { class: 'art-cut', style: { left: '38%' } }), h('span', { class: 'art-cut', style: { left: '71%' } }));
    if (kind === 'story') return h('div', { class: 'hc-art art-story' }, h('i'), h('i'), h('i'));
    return h('div', { class: 'hc-art art-video' }, h('div', { class: 'art-strip' }, ...Array.from({ length: 5 }, () => h('i'))), h('span', { class: 'art-head' }));
  };
  const tool = (kind, title, sub, onclick) => h('button', { class: 'hcard', onclick }, art(kind),
    h('div', { class: 'hc-txt' }, h('b', null, title), h('span', null, sub)));
  const choice = h('div', { class: 'home' },
    h('div', { class: 'home-top' },
      h('div', { class: 'hero-new', role: 'button', tabindex: '0', onclick: () => newBlank() },
        h('div', { class: 'hn-head' },
          h('span', { class: 'hn-plus' }, icon('plus', 22, '#fff', 2.4)),
          h('div', null, h('h1', null, 'Nuovo progetto'), h('p', null, 'Scegli il formato e inizia a montare'))),
        h('div', { class: 'hq-row' }, ...QF.map(fmtChip))),
      tool('live', 'Dalla live', 'Pause tagliate e zoom sulla faccia, da soli', () => showChoice(false)),
      tool('video', 'Monta un video', 'Il tuo video con tagli, testi e musica', () => newVideo()),
      tool('story', 'Storia con immagini', 'Da uno script, un\'immagine per battuta', () => nav('story'))));
  let creating = false;   // un doppio clic non crea due progetti
  async function quickBlank(fm) {
    if (creating) return;
    creating = true;
    try { const p = await post('/api/projects/blank', { format: fm, name: 'Progetto ' + fm }); nav('editor', p.id); }
    catch (e) { creating = false; toast(e.message, true); }
  }
  function showChoice(v) { choice.style.display = v ? '' : 'none'; vodBox.style.display = v ? 'none' : ''; }
  async function newVideo() {
    try {
      let path = null;
      const r = await post('/api/pick', { kind: 'video' });
      if (r.fallback) path = prompt('Percorso completo del video:', '') || ''; else path = r.path;
      if (!path) return;
      const p = await post('/api/projects', { source: path, kind: 'video' });
      nav('editor', p.id);
    } catch (e) { toast(e.message, true); }
  }
  function newBlank() {
    const FM = [['16:9', 'Orizzontale', 'YouTube'], ['9:16', 'Verticale', 'TikTok, Reels, Shorts'], ['1:1', 'Quadrato', 'Post'], ['4:5', 'Verticale 4:5', 'Instagram']];
    let fm = '16:9';
    const tiles = h('div', { class: 'fmgrid' });
    const draw = () => tiles.replaceChildren(...FM.map(([k, n, sub]) => {
      const [a, b] = k.split(':').map(Number);
      return h('button', { class: 'fmt-t' + (k === fm ? ' on' : ''), onclick: () => { fm = k; draw(); } },
        h('i', { style: { aspectRatio: a + ' / ' + b } }), h('b', null, k), h('span', null, n), h('small', null, sub));
    }));
    draw();
    const name = h('input', { class: 'input', value: 'Progetto vuoto', style: { width: '100%' } });
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const go = h('button', { class: 'btn primary', onclick: async () => {
      go.disabled = true;
      try { const p = await post('/api/projects/blank', { format: fm, name: name.value.trim() }); close(); nav('editor', p.id); }
      catch (e) { go.disabled = false; toast(e.message, true); }
    } }, 'Crea');
    bg.append(h('div', { class: 'modal', style: { width: 'min(520px, 94vw)' } }, h('h2', null, 'Progetto vuoto'),
      h('label', { class: 'lbl' }, 'Formato'), tiles,
      h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } }, h('label', { class: 'lbl' }, 'Nome'), name),
      h('p', { class: 'xs muted', style: { margin: 0 } }, 'La durata la decidono le clip che metti: parte da zero e cresce (o cala) man mano.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(-1),
    h('main', { class: 'page' },
      banner, choice, vodBox,
      recent,
      h('footer', { class: 'homefoot' },
        h('span', null, 'VODcut ' + (ENV.version || '') + ' · Emanuele Saurro'),
        h('button', { class: 'footlink', onclick: (e) => checkUpdatesNow(e.currentTarget) }, 'Cerca aggiornamenti'),
        h('button', { class: 'footlink', onclick: () => licenseDialog(0) }, 'Licenza'),
        h('button', { class: 'footlink', onclick: () => licenseDialog(1) }, 'Privacy'),
        h('button', { class: 'footlink', onclick: () => licenseDialog(2) }, 'Componenti di terze parti'),
        h('span', { class: 'footsep' }),
        langPicker())));

  try { ENV = await get('/api/env'); } catch (e) { /* */ }
  const vs = app.querySelector('.homefoot span'); if (vs) vs.textContent = 'VODcut ' + (ENV.version || '') + ' · Emanuele Saurro';
  if (ENV.licenseOk === false && !stale(my)) await licenseDialog(0, true);
  if (!ENV.ffmpeg) { banner.style.display = ''; banner.textContent = 'Manca ffmpeg: esegui INSTALLA.bat e riapri VODcut.'; }
  const list = await get('/api/projects');
  const KIND = { vod: ['webcam', 'Live'], video: ['film', 'Video'], blank: ['plus', 'Progetto'], story: ['sparkle', 'Storia'] };
  const ratioLabel = (w, hh) => {
    const r = w / hh;
    for (const [k, v] of [['16:9', 16 / 9], ['9:16', 9 / 16], ['1:1', 1], ['4:5', 0.8], ['4:3', 4 / 3], ['21:9', 21 / 9]]) if (Math.abs(r - v) < 0.03) return k;
    return r > 1 ? 'Orizzontale' : 'Verticale';
  };
  const ago = (ts) => {
    const d = (Date.now() / 1000 - ts);
    if (d < 90) return 'adesso';
    if (d < 3600) return Math.round(d / 60) + ' min fa';
    if (d < 86400) return Math.round(d / 3600) + (Math.round(d / 3600) === 1 ? ' ora fa' : ' ore fa');
    if (d < 172800) return 'ieri';
    if (d < 7 * 86400) return Math.round(d / 86400) + ' giorni fa';
    return new Date(ts * 1000).toLocaleDateString([], { day: 'numeric', month: 'short' });
  };
  function projCard(p) {
    const [kic, klab] = KIND[p.kind] || KIND.vod;
    const fl = ratioLabel(p.aw || 16, p.ah || 9);
    const vertical = (p.aw || 16) < (p.ah || 9);
    const shot = h('div', { class: 'pc-shot' + (vertical ? ' v' : '') });
    const frame = h('div', { class: 'pc-frame', style: { aspectRatio: (p.aw || 16) + ' / ' + (p.ah || 9) } });
    shot.append(frame);
    if (p.exists) {
      const im = h('img', { src: `/api/p/${p.id}/cover?token=${TOKEN}&v=${Math.round(p.updated)}`, alt: '', loading: 'lazy', decoding: 'async' });
      im.addEventListener('error', () => { im.remove(); frame.classList.add('empty'); frame.append(icon(kic, 22, 'currentColor', 1.6)); });
      frame.append(im);
    } else { frame.classList.add('empty', 'missing'); frame.append(h('span', null, 'File non trovato')); }
    const del = h('button', { class: 'pc-act', 'aria-label': 'Elimina il progetto ' + p.name, 'data-tip': 'Elimina', onclick: async (e) => {
      e.stopPropagation();
      if (await confirmBox('Spostare nel cestino?', `"${p.name}" va nel cestino: per 30 giorni lo recuperi quando vuoi. I file e i video esportati restano sul PC.`, 'Sposta nel cestino', true)) {
        await api('DELETE', '/api/p/' + p.id); card.remove(); pcount.textContent = String(recentGrid.children.length);
        refreshTrashN();
        toast('Progetto nel cestino: lo recuperi per 30 giorni');
      }
    } }, icon('trash', 14));
    const share = h('button', { class: 'pc-act', 'aria-label': 'Passa ' + p.name + ' a un altro PC', 'data-tip': 'Passa a un altro PC (.vodcut)', onclick: (e) => { e.stopPropagation(); exportProjectFile(p.id, p.name); } }, icon('share', 14));
    shot.append(...[
      h('span', { class: 'pc-fmt' }, h('i', { style: { aspectRatio: (p.aw || 16) + ' / ' + (p.ah || 9) } }), fl),
      p.duration > 0.5 ? h('span', { class: 'pc-dur' }, fmt(p.duration)) : null,
      h('div', { class: 'pc-acts' }, share, del),
      p.exported ? h('span', { class: 'pc-done', 'data-tip': 'Già esportato' }, icon('check', 11, '#fff', 3)) : null].filter(Boolean));
    const card = h('div', { class: 'rcard pcard', role: 'button', tabindex: '0', 'data-name': p.name.toLowerCase(), onclick: () => openProject(p) },
      shot,
      h('div', { class: 'pc-info' },
        h('div', { class: 't', 'data-notr': '' }, p.name),
        h('div', { class: 'pc-meta' }, h('span', { class: 'pc-kind' }, icon(kic, 11, 'currentColor', 2), klab), h('span', null, '·'), h('span', null, ago(p.updated)),
          p.verticals ? h('span', null, '· ' + p.verticals + (p.verticals === 1 ? ' clip verticale' : ' clip verticali')) : null)));
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter') card.click(); });
    return card;
  }
  if (list.length) {
    recent.style.display = '';
    pcount.textContent = String(list.length);
    for (const p of list.slice(0, 60)) recentGrid.append(projCard(p));
    search.addEventListener('input', () => {
      const q = search.value.trim().toLowerCase();
      for (const c of recentGrid.children) c.style.display = !q || c.dataset.name.includes(q) ? '' : 'none';
    });
  } else {
    recent.style.display = '';
    recentGrid.replaceWith(h('div', { class: 'pempty' }, icon('film', 26, 'currentColor', 1.5), h('b', null, 'Ancora nessun progetto'), h('span', null, 'Crea il primo qui sopra: in un minuto sei nell\'editor.')));
  }
}

// ----------------------------------------------------------------- cestino dei progetti (30 giorni)
async function trashDialog(onChange) {
  const bg = h('div', { class: 'modal-bg' });
  let changedAny = false;
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); if (changedAny && onChange) onChange(); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  const body = h('div', { class: 'trash-list' }, h('div', { class: 'muted xs' }, 'Carico…'));
  const emptyBtn = h('button', { class: 'btn danger sm', onclick: async () => {
    if (!(await confirmBox('Svuotare il cestino?', 'I progetti nel cestino spariscono per sempre. I video sul PC restano.', 'Svuota', true))) return;
    try { await post('/api/trash/purge', { all: true }); changedAny = true; load(); } catch (e) { toast(e.message, true); }
  } }, 'Svuota il cestino');
  async function load() {
    let list = [];
    try { list = await get('/api/trash'); } catch (e) { toast(e.message, true); }
    emptyBtn.style.display = list.length ? '' : 'none';
    if (!list.length) { body.replaceChildren(h('div', { class: 'trash-empty' }, icon('trash', 22, 'currentColor', 1.5), h('b', null, 'Il cestino è vuoto'), h('span', null, 'I progetti che elimini restano qui per 30 giorni.'))); return; }
    body.replaceChildren(...list.map((p) => {
      const row = h('div', { class: 'trash-row' },
        h('div', { class: 'trash-shot' }, h('div', { class: 'trash-frame', style: { aspectRatio: (p.aw || 16) + ' / ' + (p.ah || 9) } },
          h('img', { src: `/api/p/${p.id}/cover?token=${TOKEN}`, alt: '', loading: 'lazy', onerror: (e) => e.target.remove() }))),
        h('div', { class: 'trash-info' }, h('b', { 'data-notr': '' }, p.name),
          h('span', { class: 'muted xs' }, p.daysLeft <= 1 ? 'Si elimina per sempre domani' : `Si elimina per sempre tra ${p.daysLeft} giorni`)),
        h('button', { class: 'btn primary sm', onclick: async () => {
          try { await post('/api/trash/restore', { id: p.id }); changedAny = true; toast('Progetto recuperato'); load(); } catch (e) { toast(e.message, true); }
        } }, 'Recupera'),
        h('button', { class: 'iconbtn', 'aria-label': 'Elimina per sempre', 'data-tip': 'Elimina per sempre', onclick: async () => {
          if (!(await confirmBox('Eliminare per sempre?', `"${p.name}" non si potrà più recuperare. I video sul PC restano.`, 'Elimina per sempre', true))) return;
          try { await post('/api/trash/purge', { id: p.id }); changedAny = true; load(); } catch (e) { toast(e.message, true); }
        } }, icon('trash', 15)));
      return row;
    }));
  }
  bg.append(h('div', { class: 'modal trash-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Cestino' },
    h('div', { class: 'trash-head' }, h('h3', null, 'Cestino'), h('span', { class: 'muted xs' }, 'I progetti eliminati restano qui 30 giorni, poi spariscono da soli.')),
    body,
    h('div', { class: 'trash-foot' }, emptyBtn, h('div', { class: 'grow' }), h('button', { class: 'btn', onclick: close }, 'Chiudi'))));
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  load();
}

// ----------------------------------------------------------------- STORIA CON IMMAGINI
// script a battute -> una immagine per battuta (animata) + la frase a schermo. Tempi dalla voce o dal testo.
const STORY_MOTIONS = [['zoomIn', 'Zoom avanti'], ['zoomOut', 'Zoom indietro'], ['panL', 'Verso sinistra'], ['panR', 'Verso destra'], ['panU', 'Verso l\'alto'], ['panD', 'Verso il basso']];
const STORY_AUTO = ['zoomIn', 'panL', 'zoomOut', 'panU', 'panR', 'zoomIn', 'panD', 'zoomOut'];
const STORY_COLORS = ['#FFFFFF', '#FFD166', '#8FD3FF', '#FFA8B8', '#B9F5A2'];
function toggleEl(on, onChange) {
  const b = h('button', { class: 'toggle', 'aria-pressed': on ? 'true' : 'false', onclick: (e) => { e.preventDefault(); onChange(b.getAttribute('aria-pressed') !== 'true'); } });
  return b;
}
async function screenStory() {
  const my = navSeq;
  setTitle('Storia con immagini');
  // stato del wizard: nome -> script -> immagini -> voce
  const st = { trim: true, captions: 'word', step: 0, name: 'La mia storia', text: '', lines: [], images: [], motions: [], colors: {}, voice: null, check: null, checking: false };
  const STEPS = [['Nome', 'Come si chiama il video'], ['Script', 'Una frase per riga'], ['Immagini', 'Una per ogni frase'], ['Voce', 'Facoltativa']];
  const head = h('div', { class: 'wz-steps' });
  const body = h('div', { class: 'wz-body' });
  const back = h('button', { class: 'btn ghost', onclick: () => go(st.step - 1) }, icon('left', 15), 'Indietro');
  const next = h('button', { class: 'btn primary', onclick: () => go(st.step + 1) }, 'Avanti', icon('chev', 13, 'currentColor', 2.4));
  const foot = h('div', { class: 'wz-foot' }, back, h('div', { class: 'grow' }), next);

  const canGo = (k) => k <= 0 || (k === 1 ? !!st.name.trim() : k === 2 ? st.lines.length > 0 : k === 3 ? st.lines.length > 0 : false);
  function go(k) {
    if (k < 0) return nav('home');
    if (k > 3) return create();
    if (!canGo(k)) return;
    st.step = k; draw();
  }
  function drawHead() {
    head.replaceChildren(...STEPS.map(([t, sub], k) => h('button', { class: 'wz-st' + (k === st.step ? ' on' : k < st.step ? ' done' : ''), disabled: canGo(k) ? null : true, onclick: () => go(k) },
      h('span', { class: 'n' }, k < st.step ? icon('check', 11, '#fff', 3.5) : String(k + 1)), h('span', { class: 't' }, h('b', null, t), h('small', null, sub)))));
  }
  function draw() {
    drawHead();
    back.replaceChildren(icon('left', 15), st.step ? 'Indietro' : 'Annulla');
    if (st.step === 3) next.replaceChildren(icon('sparkle', 15, '#fff'), st.voice ? 'Crea il video' : 'Crea senza voce');
    else next.replaceChildren('Avanti', icon('chev', 13, 'currentColor', 2.4));
    next.disabled = !(st.step === 3 ? st.lines.length && !st.checking : canGo(st.step + 1));
    body.replaceChildren(...[stepName, stepScript, stepImages, stepVoice][st.step]());
  }

  // ---- 1. nome
  function stepName() {
    const inp = h('input', { class: 'input big', value: st.name, placeholder: 'Es. Manifestazione — parte 1' });
    inp.addEventListener('input', () => { st.name = inp.value; next.disabled = !st.name.trim(); drawHead(); });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(1); });
    setTimeout(() => { inp.focus(); inp.select(); }, 30);
    return [h('h2', null, 'Come si chiama?'), h('p', { class: 'wz-p' }, 'È il nome del progetto e del video che esporti. Il video sarà verticale 9:16.'), inp];
  }

  // ---- 2. script
  let parseT = 0;
  async function parse(text) {
    const r = await post('/api/story/parse', { text });
    st.lines = r.lines;
    st.motions = st.lines.map((_, i) => st.motions[i] || STORY_AUTO[i % STORY_AUTO.length]);
    st.images = st.lines.map((_, i) => st.images[i] || null);
    st.lines.forEach((l) => { if (l.speaker && !st.colors[l.speaker]) st.colors[l.speaker] = STORY_COLORS[Object.keys(st.colors).length % STORY_COLORS.length]; });
    st.check = null;
  }
  function stepScript() {
    const ta = h('textarea', { class: 'input wz-script', spellcheck: 'false',
      placeholder: 'Perché quando mi innamoro…\nFinisco sempre per diventare un\'altra persona?\nPerché forse hai imparato che, per essere amata…\n…devi essere esattamente ciò che l\'altra persona vuole.' });
    ta.value = st.text;
    const prev = h('div', { class: 'wz-prev' });
    const paint = () => {
      next.disabled = !st.lines.length; drawHead();
      const sp = [...new Set(st.lines.map((l) => l.speaker).filter(Boolean))];
      prev.replaceChildren(
        h('div', { class: 'wz-prev-h' }, h('b', null, st.lines.length ? st.lines.length + ' frasi = ' + st.lines.length + ' immagini' : 'Anteprima'),
          ...sp.map((k) => h('button', { class: 'st-sp', 'data-tip': 'Colore del testo di ' + k + ' (clic per cambiarlo)', onclick: () => {
            st.colors[k] = STORY_COLORS[(STORY_COLORS.indexOf(st.colors[k]) + 1) % STORY_COLORS.length]; paint(); } }, h('i', { style: { background: st.colors[k] } }), k))),
        st.lines.length ? h('ol', { class: 'wz-lines' }, ...st.lines.map((l, i) => h('li', null, h('span', { class: 'img' }, 'IMG ' + (i + 1)),
          l.speaker ? h('b', { style: { color: st.colors[l.speaker] } }, l.speaker) : null, h('span', null, l.text))))
          : h('div', { class: 'wz-empty' }, 'Scrivi o incolla lo script: ogni riga diventa una frase a schermo con la sua immagine.'));
    };
    ta.addEventListener('input', () => { st.text = ta.value; clearTimeout(parseT); parseT = setTimeout(async () => { await parse(st.text); paint(); }, 200); });
    paint();
    setTimeout(() => ta.focus(), 30);
    return [h('h2', null, 'Scrivi lo script'),
      h('div', { class: 'wz-rules' },
        h('div', null, h('b', null, 'Una frase per riga.'), ' Ogni riga è una frase a schermo e avrà la sua immagine: riga 1 → immagine 1, riga 2 → immagine 2…'),
        h('div', null, h('b', null, 'Personaggi (facoltativo):'), ' scrivi il nome prima della frase, es. ', h('code', null, 'VOLPE: Forse.'), ' — ogni personaggio avrà il suo colore.'),
        h('div', null, 'Va bene anche il formato ', h('code', null, 'BATTUTA 1 — IMG 1'), ' con il nome e la frase sotto.')),
      h('div', { class: 'wz-2col' }, ta, prev)];
  }

  // ---- 3. immagini
  async function uploadImg(file) {
    const r = await fetch('/api/upload?kind=asset&token=' + TOKEN + '&name=' + encodeURIComponent(file.name), { method: 'PUT', body: file });
    const j = await r.json();
    if (!r.ok || j.kind !== 'image') throw new Error(j.error || 'Non è un\'immagine: ' + file.name);
    return j.path;
  }
  function stepImages() {
    const grid = h('div', { class: 'st-slots' });
    const count = h('span', { class: 'wz-count' });
    const paint = () => {
      const n = st.images.filter(Boolean).length;
      count.textContent = n + ' / ' + st.lines.length + ' immagini';
      grid.replaceChildren(...st.lines.map((l, i) => {
        const f = st.images[i];
        const mot = (STORY_MOTIONS.find(([k]) => k === st.motions[i]) || STORY_MOTIONS[0])[1];
        const pic = h('button', { class: 'st-pic', 'data-tip': f ? 'Clic o trascina qui un\'altra immagine' : 'Clic per sceglierla, o trascinala qui', onclick: () => pickOne(i) },
          f ? h('img', { src: mediaUrl(f), alt: '', loading: 'lazy' }) : h('span', { class: 'st-add' }, icon('plus', 20, 'currentColor', 2), h('small', null, 'Scegli o trascina')),
          h('span', { class: 'st-num' }, String(i + 1)),
          f ? h('span', { class: 'st-x', role: 'button', 'aria-label': 'Togli', onclick: (e) => { e.stopPropagation(); st.images[i] = null; paint(); } }, icon('x', 12, '#fff', 2.4)) : null);
        pic.addEventListener('dragover', (e) => { e.preventDefault(); pic.classList.add('over'); });
        pic.addEventListener('dragleave', () => pic.classList.remove('over'));
        pic.addEventListener('drop', async (e) => {
          e.preventDefault(); e.stopPropagation(); pic.classList.remove('over');
          const files = imgFiles(e.dataTransfer);
          if (files.length > 1) return dropMany(files);   // tante immagini: si ordinano da sole col numero nel nome
          if (files[0]) { try { st.images[i] = await uploadImg(files[0]); paint(); } catch (er) { toast(er.message, true); } }
        });
        return h('div', { class: 'st-slot' + (f ? '' : ' empty') }, pic,
          h('div', { class: 'st-line' }, l.speaker ? h('b', { style: { color: st.colors[l.speaker] } }, l.speaker) : null, h('span', null, l.text)),
          h('button', { class: 'st-mot', 'data-tip': 'Clic: cambia movimento', onclick: () => {
            const ids = STORY_MOTIONS.map(([k]) => k); st.motions[i] = ids[(ids.indexOf(st.motions[i]) + 1) % ids.length]; paint();
          } }, icon('sparkle', 11), mot));
      }));
    };
    // tutte le immagini trascinate insieme: caricate e messe al loro posto in base al numero nel nome (1, 2, 3…)
    const numOf = (name) => { const m = name.replace(/\.[^.]+$/, '').match(/\d+/g); return m ? parseInt(m[m.length - 1], 10) : null; };
    async function dropMany(files) {
      files = files.slice().sort((a, b) => (numOf(a.name) ?? 1e9) - (numOf(b.name) ?? 1e9) || a.name.localeCompare(b.name, undefined, { numeric: true }));
      const nums = files.map((f) => numOf(f.name));
      const byNum = nums.every((n) => n != null && n >= 1 && n <= st.lines.length) && new Set(nums).size === nums.length;
      let done = 0;
      dz.classList.add('busy'); dzTxt.textContent = 'Carico le immagini… 0 / ' + files.length;
      const q = files.map((f, k) => ({ f, slot: byNum ? nums[k] - 1 : k }));
      const worker = async () => {
        for (;;) {
          const it = q.shift(); if (!it) return;
          try { const path = await uploadImg(it.f); if (it.slot < st.lines.length) st.images[it.slot] = path; } catch (er) { toast(er.message, true); }
          done++; dzTxt.textContent = 'Carico le immagini… ' + done + ' / ' + files.length; paint();
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
      dz.classList.remove('busy'); dzTxt.textContent = DZ_TXT;
      if (files.length > st.lines.length) toast(`${files.length - st.lines.length} immagini in più rispetto alle frasi: le ho lasciate fuori`);
      paint();
    }
    const imgFiles = (dt) => [...(dt.files || [])].filter((x) => /^image\//.test(x.type) || /\.(png|jpe?g|webp|bmp|gif)$/i.test(x.name));
    const DZ_TXT = 'Trascina qui tutte le immagini insieme: le metto in ordine col numero nel nome (1, 2, 3…)';
    const dzTxt = h('span', null, DZ_TXT);
    const dz = h('div', { class: 'wz-imgdrop' }, icon('upload', 20, 'currentColor', 1.8), dzTxt);
    dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('over'));
    dz.addEventListener('drop', (e) => { e.preventDefault(); dz.classList.remove('over'); const f = imgFiles(e.dataTransfer); if (f.length) dropMany(f); });
    grid.addEventListener('dragover', (e) => e.preventDefault());
    grid.addEventListener('drop', (e) => { e.preventDefault(); const f = imgFiles(e.dataTransfer); if (f.length) dropMany(f); });
    async function useFiles(res) {
      if (!res.files.length) return toast('Nessuna immagine trovata', true);
      st.images = st.lines.map((_, i) => res.match[i] || st.images[i] || null); paint();
    }
    async function pickFolder() {
      try {
        const r = await post('/api/pick', { kind: 'folder' });
        let folder = r.path;
        if (r.fallback) folder = prompt('Percorso completo della cartella con le immagini:', '') || '';
        if (!folder) return;
        useFiles(await post('/api/story/images', { folder, lines: st.lines }));
      } catch (e) { toast(e.message, true); }
    }
    async function pickMany() {
      try {
        const r = await post('/api/pick', { kind: 'media' });
        const files = (r.files || []).filter((f) => f.kind === 'image').map((f) => f.path);
        if (files.length) useFiles(await post('/api/story/images', { files, lines: st.lines }));
      } catch (e) { toast(e.message, true); }
    }
    async function pickOne(i) {
      try {
        const r = await post('/api/pick', { kind: 'media' });
        const f = (r.files || []).find((x) => x.kind === 'image');
        if (!f) return;
        await post('/api/story/images', { files: [f.path] });
        st.images[i] = f.path; paint();
      } catch (e) { toast(e.message, true); }
    }
    paint();
    return [h('h2', null, 'Metti le immagini'),
      h('p', { class: 'wz-p' }, 'Ogni casella è una frase dello script. Trascina tutte le immagini insieme nel riquadro qui sotto (le ordino col numero nel nome), oppure clicca una casella per sceglierne una.'),
      h('div', { class: 'wz-bar' },
        h('button', { class: 'btn primary sm', onclick: pickFolder }, icon('folder', 14, '#fff'), 'Da una cartella numerata'),
        h('button', { class: 'btn sm', onclick: pickMany }, icon('plus', 14), 'Scegli più immagini'),
        h('div', { class: 'grow' }), count),
      dz, grid];
  }

  // ---- 4. voce
  function stepVoice() {
    const box = h('div', { class: 'wz-voice' });
    const paint = () => {
      next.disabled = st.checking;
      next.replaceChildren(icon('sparkle', 15, '#fff'), st.voice ? 'Crea il video' : 'Crea senza voce');
      if (!st.voice) {
        const drop = h('button', { class: 'wz-drop', onclick: pickVoice }, icon('music', 26, 'currentColor', 1.6),
          h('b', null, 'Carica la voce'), h('span', null, 'MP3, WAV, M4A… Clic o trascina qui il file'));
        drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
        drop.addEventListener('dragleave', () => drop.classList.remove('over'));
        drop.addEventListener('drop', async (e) => {
          e.preventDefault(); drop.classList.remove('over');
          const f = e.dataTransfer.files[0]; if (!f) return;
          try {
            const r = await fetch('/api/upload?kind=audio&token=' + TOKEN + '&name=' + encodeURIComponent(f.name), { method: 'PUT', body: f });
            const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Upload non riuscito');
            setVoice(j);
          } catch (er) { toast(er.message, true); }
        });
        box.replaceChildren(drop, h('p', { class: 'wz-p', style: { textAlign: 'center' } }, 'Senza voce i tempi si calcolano dalla lunghezza delle frasi (poi li cambi nell\'editor).'));
        return;
      }
      const vf = h('div', { class: 'st-vf' }, icon('music', 16, '#2DD4BF'), h('span', { 'data-notr': '' }, st.voice.name), h('span', { class: 'xs' }, fmt(st.voice.duration || 0)),
        h('button', { class: 'btn sm ghost', onclick: pickVoice }, 'Cambia'),
        h('button', { class: 'iconbtn', 'aria-label': 'Togli la voce', onclick: () => { st.voice = null; st.check = null; paint(); } }, icon('x', 14)));
      if (st.checking) {
        const bar = h('div', { class: 'progress' }, h('div', { style: { width: Math.round((st.checkProg || 0) * 100) + '%' } }));
        box.replaceChildren(vf, h('div', { class: 'wz-checking' }, h('div', { class: 'spinner' }), h('span', null, st.checkMsg || 'Ascolto la voce e la confronto con lo script…')), bar);
        return;
      }
      const c = st.check;
      if (!c) { box.replaceChildren(vf); return; }
      if (!c.report) { box.replaceChildren(vf, h('div', { class: 'wz-note' }, c.note || '')); return; }
      const bad = c.report.map((r, i) => ({ r, i })).filter(({ r }) => r.missing.length || r.extra.length);
      // durata: con i silenzi o senza
      const trimBox = c.trimDur && c.trimDur < c.dur - 0.5 ? h('div', { class: 'wz-trim' + (st.trim ? ' on' : '') },
        h('div', { class: 'wz-durs' },
          h('div', { class: 'd' + (st.trim ? '' : ' cur') }, h('small', null, 'Voce così com\'è'), h('b', null, fmt(c.dur))),
          icon('chev', 14, 'currentColor', 2.2),
          h('div', { class: 'd' + (st.trim ? ' cur' : '') }, h('small', null, 'Senza silenzi'), h('b', null, fmt(c.trimDur)))),
        h('label', { class: 'wz-tg' }, toggleEl(st.trim, (v) => { st.trim = v; paint(); }), h('span', null, h('b', null, 'Togli i silenzi tra le frasi'),
          h('small', null, `Resta una pausa breve e naturale tra una frase e l'altra · −${fmt(c.dur - c.trimDur)}`)))) : null;
      const summary = bad.length
        ? h('div', { class: 'wz-sum warn' }, icon('info', 16, 'currentColor', 2), h('span', null, h('b', null, bad.length + (bad.length === 1 ? ' frase un po\' diversa' : ' frasi un po\' diverse')), ' dallo script. Le immagini seguono la voce e il testo a schermo sarà quello che si sente davvero (i piccoli errori di ascolto restano come nello script). Qui sotto vedi cosa cambia.'))
        : h('div', { class: 'wz-sum ok' }, icon('check', 16, 'currentColor', 2.6), h('span', null, h('b', null, 'La voce corrisponde allo script.'), ' Ogni immagine durerà quanto la sua frase.'));
      const row = (r, i) => {
        const t = (st.trim && c.timesTrim ? c.timesTrim : c.times)[i];
        return h('div', { class: 'wz-vr' + (r.missing.length || r.extra.length ? ' bad' : '') },
          h('span', { class: 'n' }, String(i + 1)), h('span', { class: 'tm' }, fmt(t[0], 1)),
          h('div', { class: 'tx' }, h('div', null, st.lines[i].text),
            r.missing.length || r.extra.length ? h('div', { class: 'df' },
              r.missing.length ? h('span', { class: 'miss' }, 'Non si sente: ', r.missing.join(' ')) : null,
              r.extra.length ? h('span', { class: 'extra' }, 'Si sente in più: ', r.extra.join(' ')) : null,
              h('span', { class: 'heard' }, 'Nella voce: “' + (r.heard || '—') + '”')) : null));
      };
      const capBox = c.words ? h('div', { class: 'wz-cap' }, h('b', null, 'Testo a schermo'),
        seg(['Parola per parola', 'Frase intera'], st.captions === 'word' ? 0 : 1, (i) => { st.captions = i ? 'line' : 'word'; paint(); }),
        h('small', null, st.captions === 'word' ? 'Ogni parola compare quando viene detta, a tempo con la voce.' : 'La frase intera resta a schermo per tutta l\'immagine.')) : null;
      box.replaceChildren(vf, trimBox, capBox, summary, h('div', { class: 'wz-vlist' }, ...c.report.map(row)));
    };
    async function setVoice(f) {
      // una voce nuova mentre l'altra si sta ancora ascoltando: la vecchia si ferma
      if (st.voiceJob) { post(`/api/jobs/${st.voiceJob}/cancel`).catch(() => {}); st.voiceJob = null; }
      st.voice = f; st.check = null; st.checking = true; st.checkProg = 0; st.checkMsg = ''; paint();
      try {
        const job = await post('/api/story/voice', { voice: f.path, lines: st.lines });
        st.voiceJob = job.id;
        const res = await pollJob(job.id, (j) => { if (st.voiceJob !== job.id) return; st.checkProg = j.progress; st.checkMsg = j.message; if (st.step === 3) paint(); });
        if (st.voiceJob !== job.id) return;   // sostituita da un'altra voce
        st.voiceJob = null;
        if (res.status !== 'done') throw new Error(res.error || 'Non riuscito');
        st.check = res.result;
      } catch (e) { toast(e.message, true); }
      st.checking = false;
      if (st.step === 3) paint();
    }
    async function pickVoice() {
      try { const r = await post('/api/pick', { kind: 'audio' }); const f = (r.files || [])[0]; if (f) setVoice(f); } catch (e) { toast(e.message, true); }
    }
    paint();
    if (st.voice && !st.check && !st.checking) setTimeout(() => setVoice(st.voice), 0);   // lo script e' cambiato: si ricontrolla
    return [h('h2', null, 'Aggiungi la voce'), h('p', { class: 'wz-p' }, 'Con la voce ogni immagine resta a schermo quanto la sua frase. Te la confronto con lo script e ti segnalo le frasi diverse.'), box];
  }

  async function create() {
    const bg = h('div', { class: 'modal-bg' });
    const msg = h('div', { class: 'xs' }, 'Preparo il video…');
    const bar = h('div', { class: 'progress' }, h('div'));
    bg.append(h('div', { class: 'modal' }, h('h2', null, 'Creo la storia'), bar, msg));
    document.body.append(bg);
    try {
      const job = await post('/api/story/create', { name: st.name.trim() || 'Storia', lines: st.lines, images: st.images, motions: st.motions, colors: st.colors,
        voice: st.voice ? st.voice.path : '', times: st.check ? st.check.times : null, format: '9:16',
        trim: !!(st.trim && st.check && st.check.words), words: st.check ? st.check.words : null,
        captions: st.voice && st.check && st.check.words ? st.captions : 'line' });
      const res = await pollJob(job.id, (j) => { bar.firstChild.style.width = Math.round(j.progress * 100) + '%'; if (j.message) msg.textContent = j.message; });
      if (res.status !== 'done') throw new Error(res.error || 'Non riuscito');
      bg.remove(); nav('editor', res.result.project);
    } catch (e) { bg.remove(); toast(e.message, true); }
  }

  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(-1, null, false, { name: 'Storia con immagini', home: true }),
    h('main', { class: 'wizard' }, head, h('div', { class: 'wz-card' }, body, foot)));
  draw();
}

// ----------------------------------------------------------------- WEBCAM
async function findJob(pid, kind) {
  const jobs = await get('/api/jobs');
  return jobs.find((j) => j.pid === pid && j.kind === kind);
}

async function screenWebcam(pid) {
  const my = navSeq;
  let proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  const W = proj.width, H = proj.height;
  let box = proj.webcam && proj.webcam.box ? proj.webcam.box.slice() : null;
  let job = await findJob(pid, 'prepare');
  if (!job && !(proj.analysis && proj.analysis.ready)) job = await post(`/api/p/${pid}/prepare`);

  const stage = h('div', { class: 'stage' });
  const img = h('img', { src: `/api/p/${pid}/frame?token=${TOKEN}&t=${(proj.duration * 0.35).toFixed(1)}`, alt: 'Fotogramma del VOD' });
  stage.append(img);
  const rect = h('div', { class: 'camrect', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }),
    h('div', { class: 'tag' }, 'Webcam'));
  stage.append(rect);

  const title = h('h1', null, 'Cerco la tua webcam…');
  const text = h('p', null, 'Guardo dove compare la tua faccia durante la live.');
  const yes = h('a', { class: 'btn primary big', href: '#', role: 'button', style: { textDecoration: 'none' } }, 'Sì, è questa');
  const fix = h('button', { class: 'btn big' }, 'Correggi il riquadro');
  const none = h('button', { class: 'btn ghost', style: { height: '40px', fontSize: '14px' } }, 'Non uso la webcam');
  const remember = h('input', { type: 'checkbox', checked: true });
  const waiting = h('div', { class: 'row muted small' }, h('div', { class: 'spinner' }), 'Un attimo…');
  const actions = h('div', { style: { display: 'none', flexDirection: 'column', gap: '10px' } }, yes, fix, none,
    h('label', { class: 'check' }, remember, 'Ricorda per le prossime live'));

  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(1), h('main', { class: 'split' }, stage, h('aside', { class: 'side' }, h('div', { style: { display: 'flex', flexDirection: 'column', gap: '10px' } }, title, text), waiting, actions)));

  function place() {
    if (!box) return;
    const sw = stage.clientWidth, sh = stage.clientHeight;
    Object.assign(rect.style, { display: 'block', left: (box[0] / W * sw) + 'px', top: (box[1] / H * sh) + 'px', width: (box[2] / W * sw) + 'px', height: (box[3] / H * sh) + 'px' });
  }
  function ready(msgTitle, msgText) {
    waiting.style.display = 'none'; actions.style.display = 'flex';
    title.textContent = msgTitle; text.textContent = msgText;
    place();
  }
  const ro = new ResizeObserver(place); ro.observe(stage);

  // trascina / ridimensiona il riquadro
  let drag = null;
  rect.addEventListener('pointerdown', (e) => {
    e.preventDefault(); rect.setPointerCapture(e.pointerId);
    drag = { mode: e.target.dataset.h || 'move', x: e.clientX, y: e.clientY, box: box.slice() };
  });
  rect.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const sx = W / stage.clientWidth, sy = H / stage.clientHeight;
    const dx = (e.clientX - drag.x) * sx, dy = (e.clientY - drag.y) * sy;
    let [x, y, w, hh] = drag.box;
    if (drag.mode === 'move') { x += dx; y += dy; }
    if (drag.mode.includes('w')) { x += dx; w -= dx; }
    if (drag.mode.includes('e')) { w += dx; }
    if (drag.mode.includes('n')) { y += dy; hh -= dy; }
    if (drag.mode.includes('s')) { hh += dy; }
    w = Math.max(60, w); hh = Math.max(40, hh);
    x = Math.min(Math.max(0, x), W - w); y = Math.min(Math.max(0, y), H - hh);
    box = [Math.round(x), Math.round(y), Math.round(w), Math.round(hh)];
    place();
  });
  rect.addEventListener('pointerup', () => { drag = null; });
  fix.addEventListener('click', () => {
    title.textContent = 'Sistema il riquadro';
    text.textContent = 'Trascina il riquadro sulla webcam e tira gli angoli finché la copre tutta.';
    rect.animate([{ transform: 'scale(1.03)' }, { transform: 'scale(1)' }], { duration: 300 });
  });
  none.addEventListener('click', async () => {
    proj = await get('/api/p/' + pid);
    proj.webcam = { none: true }; proj.stage = 'style';
    await put('/api/p/' + pid, proj); nav('style', pid);
  });
  yes.addEventListener('click', async (e) => {
    e.preventDefault();
    proj = await get('/api/p/' + pid);
    proj.webcam = { box, confidence: 1 }; proj.stage = 'style';
    await put('/api/p/' + pid, proj);
    if (remember.checked) post('/api/settings', { webcam: { box, size: [W, H] } });
    nav('style', pid);
  });

  let alive = true;
  cleanup = () => { alive = false; ro.disconnect(); };
  // aspetta la webcam
  for (let i = 0; alive; i++) {
    proj = await get('/api/p/' + pid);
    if (proj.webcam && proj.webcam.box) {
      box = proj.webcam.box.slice();
      const conf = proj.webcam.confidence;
      if (proj.webcam.remembered) ready('È questa la tua webcam?', 'È la stessa posizione dell\'ultima volta.');
      else if (conf >= 0.5) ready('È questa la tua webcam?', 'L\'abbiamo trovata da soli. Serve per sapere dove zoomare quando reagisci.');
      else ready('Aiutaci a trovare la webcam', 'Non siamo sicuri: sposta il riquadro sulla webcam e tira gli angoli.');
      break;
    }
    if (proj.webcam && proj.webcam.none) { box = [W - W * 0.26, H * 0.01, W * 0.24, W * 0.24 * 9 / 16].map(Math.round); ready('Webcam', 'Avevi scelto di non usarla. Se c\'è, sistemala qui.'); break; }
    if (job) { const j = await get('/api/jobs/' + job.id); if (j.status !== 'running') { if (j.error) toast(j.error, true); box = [W - W * 0.26, H * 0.01, W * 0.24, W * 0.24 * 9 / 16].map(Math.round); ready('Dov\'è la webcam?', 'Sposta il riquadro sulla webcam e tira gli angoli.'); break; } }
    await new Promise((r) => setTimeout(r, 500));
  }
}

// ----------------------------------------------------------------- STILE
const CUT_HELP = ['Togliamo solo le pause molto lunghe (oltre 8 secondi).', 'Togliamo le pause oltre 4 secondi, lasciando sempre un po\' di contesto.', 'Ritmo veloce: togliamo quasi ogni pausa oltre 2 secondi.'];
const ZOOM_HELP = ['Solo le reazioni più forti, ben distanziate.', 'Le reazioni forti, con una pausa tra uno zoom e l\'altro.', 'Zoom frequenti su ogni reazione. Stile molto dinamico.'];

async function screenStyle(pid) {
  const my = navSeq;
  let proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  try { ENV = await get('/api/env'); } catch (e) { /* */ }
  let cuts = proj.style ? proj.style.cuts : 1, zooms = proj.style ? proj.style.zooms : 1;
  // quanto ingrandisce ogni zoom (vale per tutti; si ricorda per la prossima volta)
  const ZL = [2, 2.4, 2.8, 3.4, 4];
  let zl = 2.8;
  try { const v = parseFloat(localStorage.getItem('vodcut.zoomLevel')); if (ZL.includes(v)) zl = v; } catch (e) { /* */ }
  if (proj.settings && ZL.includes(proj.settings.zoomLevel)) zl = proj.settings.zoomLevel;
  const hasCam = proj.webcam && proj.webcam.box;
  const t = (proj.duration * 0.35).toFixed(1);
  const prev = h('div', { class: 'zprev' });
  const pimg = h('img', { src: `/api/p/${pid}/frame?token=${TOKEN}&t=${t}`, alt: 'Anteprima dello zoom sulla webcam' });
  prev.append(pimg, h('div', { class: 'chip' }, hasCam ? 'Anteprima zoom' : 'Senza webcam: niente zoom'));
  function layoutPrev() {
    const cw = prev.clientWidth, ch = prev.clientHeight;
    if (!hasCam) { Object.assign(pimg.style, { left: 0, top: 0, width: cw + 'px', height: ch + 'px' }); return; }
    const [rx, ry, rw] = targetRect(proj.width, proj.height, proj.webcam.box, zl);
    const k = cw / rw;
    Object.assign(pimg.style, { width: proj.width * k + 'px', height: proj.height * k + 'px', left: -rx * k + 'px', top: -ry * k + 'px' });
  }
  const ro = new ResizeObserver(layoutPrev); ro.observe(prev);

  const cutHelp = h('div', { class: 'help' }, CUT_HELP[cuts]);
  const zoomHelp = h('div', { class: 'help' }, hasCam ? ZOOM_HELP[zooms] : 'Senza webcam non facciamo zoom.');
  const cutSeg = h('div');
  const zoomSeg = h('div');
  const zlSeg = h('div');
  // sottotitoli: si chiede prima di partire (la scelta viene ricordata per la prossima volta)
  const hasTr = !!(proj.transcript && proj.transcript.status && proj.transcript.status !== 'none' && proj.transcript.status !== 'error');
  let subs = 1;
  try { const v = localStorage.getItem('vodcut.autoSubs'); if (v !== null) subs = v === '1' ? 0 : 1; else subs = 0; } catch (e) { subs = 0; }
  const SUB_HELP = ['Li preparo mentre lavori: ci vogliono alcuni minuti e puoi già modificare il video.', 'Niente sottotitoli per ora: puoi crearli quando vuoi dalla traccia Testo dell\'editor.'];
  const subHelp = h('div', { class: 'help' }, SUB_HELP[subs]);
  const subSeg = h('div');
  // formato del video finale
  let fmtV = proj.format === '9:16' ? 1 : 0;
  const fmtLocked = !!(proj.analysis && proj.analysis.ready);
  const FMT_HELP = ['Per YouTube: il video resta orizzontale, come la tua live.',
    hasCam ? 'Per TikTok, Shorts e Reels: webcam sopra e gioco sotto. Nelle reazioni la webcam va a tutto schermo.' : 'Per TikTok, Shorts e Reels: tutto il video con lo sfondo sfocato (puoi cambiarlo nell\'editor).'];
  const fmtHelp = h('div', { class: 'help' }, FMT_HELP[fmtV]);
  const fmtSeg = h('div');
  // in verticale: cosa si vede in tutte le clip all'inizio (poi si cambia clip per clip nell'editor)
  const VL = [['split', 'Webcam e gioco'], ['fit', 'Tutto il video'], ['game', 'Solo il gioco'], ['cam', 'Solo webcam'], ['free', 'Libero']];
  let vl = (proj.vert && proj.vert.layout) || (hasCam ? 'split' : 'fit');
  const vlWrap = h('div', { class: 'ctl' });
  function renderSegs() {
    fmtSeg.replaceChildren(seg(['Orizzontale 16:9', 'Verticale 9:16'], fmtV, (i) => { if (fmtLocked) return; fmtV = i; fmtHelp.textContent = FMT_HELP[i]; renderSegs(); }, 'big'));
    // rifacendo l'analisi il formato non cambia: resta quello con cui e' nato il progetto
    if (fmtLocked) fmtSeg.querySelectorAll('button').forEach((b, i) => { if (i !== fmtV) b.disabled = true; });
    vlWrap.style.display = fmtV ? '' : 'none';
    const sg = seg(VL.map((x) => x[1]), VL.findIndex((x) => x[0] === vl), (i) => { vl = VL[i][0]; renderSegs(); }, 'vl4');
    sg.querySelectorAll('button').forEach((b, i) => { if (!hasCam && (VL[i][0] === 'split' || VL[i][0] === 'cam')) b.disabled = true; });
    vlWrap.replaceChildren(h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Cosa si vede'), sg,
      h('div', { class: 'help' }, 'Vale per tutte le clip. Nell\'editor puoi cambiarlo clip per clip.'));
    cutSeg.replaceChildren(seg(['Pochi', 'Normali', 'Tanti'], cuts, (i) => { cuts = i; cutHelp.textContent = CUT_HELP[i]; renderSegs(); }, 'big'));
    zoomSeg.replaceChildren(seg(['Pochi', 'Normali', 'Tanti'], zooms, (i) => { zooms = i; if (hasCam) zoomHelp.textContent = ZOOM_HELP[i]; renderSegs(); }, 'big'));
    if (!hasCam) zoomSeg.querySelectorAll('button').forEach((b) => { b.disabled = true; });
    zlSeg.replaceChildren(seg(ZL.map((v) => (v + '×').replace('.', ',')), ZL.indexOf(zl), (i) => { zl = ZL[i]; try { localStorage.setItem('vodcut.zoomLevel', String(zl)); } catch (e) { /* */ } layoutPrev(); renderSegs(); }, 'big'));
    if (!hasCam) zlSeg.querySelectorAll('button').forEach((b) => { b.disabled = true; });
    subSeg.replaceChildren(seg(['Sì, creali', 'No, per ora'], subs, (i) => { subs = i; subHelp.textContent = SUB_HELP[i]; try { localStorage.setItem('vodcut.autoSubs', i ? '0' : '1'); } catch (e) { /* */ } renderSegs(); }, 'big'));
  }
  renderSegs();
  const go = h('button', { class: 'btn primary big', disabled: true }, icon('sparkle', 18), 'Analizza e apri l\'editor');
  const status = h('div', { class: 'row muted small' }, h('div', { class: 'spinner' }), h('span', null, 'Sto ascoltando l\'audio…'));
  const back = h('button', { class: 'btn ghost', style: { height: '36px', fontSize: '13px', alignSelf: 'flex-start' }, onclick: () => nav('webcam', pid) }, icon('left', 16), 'Webcam');

  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(2), h('main', { class: 'split', style: { alignItems: 'flex-start' } },
    h('div', { style: { flexGrow: '1', maxWidth: '760px', display: 'flex', flexDirection: 'column', gap: '14px' } }, prev,
      h('div', { class: 'row muted small' }, icon('info', 18), `Durata del VOD: ${fmt(proj.duration)} · L'analisi richiede pochi secondi.`)),
    h('aside', { class: 'side', style: { width: '400px', gap: '22px' } },
      back,
      h('h1', null, 'Scegli lo stile'),
      h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Formato'), fmtSeg, fmtHelp),
      vlWrap,
      h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Tagli'), cutSeg, cutHelp),
      h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Zoom sulla webcam'), zoomSeg, zoomHelp),
      hasCam ? h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Quanto ingrandire'), zlSeg,
        h('div', { class: 'help' }, 'Vale per tutti gli zoom: lo vedi subito nell\'anteprima. Nell\'editor puoi cambiarli anche tutti insieme.')) : null,
      ENV.whisper && !hasTr ? h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Sottotitoli automatici'), subSeg, subHelp) : null,
      status, go)));

  go.addEventListener('click', async () => {
    go.disabled = true;
    try {
      proj = await post(`/api/p/${pid}/propose`, { cuts, zooms, zoomScale: hasCam ? zl : null, format: fmtV ? '9:16' : '16:9', vlayout: fmtV ? vl : null });
      if (ENV.whisper && subs === 0 && (!proj.transcript || proj.transcript.status === 'none' || proj.transcript.status === 'error')) {
        post(`/api/p/${pid}/transcribe`).catch(() => {});
      }
      nav('editor', pid);
    } catch (e) { toast(e.message, true); go.disabled = false; }
  });

  let alive = true;
  cleanup = () => { alive = false; ro.disconnect(); };
  let job = await findJob(pid, 'prepare');
  if (!job && !(proj.analysis && proj.analysis.ready)) job = await post(`/api/p/${pid}/prepare`);
  while (alive) {
    proj = await get('/api/p/' + pid);
    if (proj.analysis && proj.analysis.ready) { status.style.display = 'none'; go.disabled = false; break; }
    if (job) {
      const j = await get('/api/jobs/' + job.id);
      status.lastChild.textContent = 'Sto ascoltando l\'audio… ' + Math.round(j.progress * 100) + '%';
      if (j.status === 'error') { toast(j.error, true); break; }
    }
    await new Promise((r) => setTimeout(r, 500));
  }
}

// ----------------------------------------------------------------- EDITOR
async function screenEditor(pid) {
  const my = navSeq;
  const proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  try { ENV = await get('/api/env'); } catch (e) { /* */ }
  if (stale(my)) return;
  app.innerHTML = '';
  const right = h('div', { class: 'row' });
  app.append(topbar(3, right, false, proj.parent && !proj.timeline ? { parent: proj.parent, parentName: proj.parentName, name: proj.name } : { name: proj.timeline ? (proj.parentName || proj.name) : proj.name }));
  const c = await mountEditor(app, proj, { env: ENV, nav, topRight: right, saveProject: exportProjectFile });
  if (stale(my)) { try { await c(); } catch (e) { /* */ } return; }
  cleanup = c;
}

// ----------------------------------------------------------------- ESPORTAZIONE
async function screenExport(pid, want) {
  const my = navSeq;
  const proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  let job = await findJob(pid, 'export');
  if (!job) job = await post(`/api/p/${pid}/export`, want || {});
  const many = !!(want && ((want.vod ? 1 : 0) + (want.verticals || []).length + (want.timelines || []).length > 1));
  const back = (want && want.back) || pid;   // si torna alla timeline da cui hai esportato
  const msg = h('p', { class: 'xs muted', style: { margin: 0, minHeight: '16px' } }, '');
  const pct = h('div', { class: 'xs' }, '0%');
  const bar = h('div', { class: 'progress', role: 'progressbar', 'aria-label': 'Avanzamento', 'aria-valuemin': '0', 'aria-valuemax': '100' }, h('div', { style: { width: '0%' } }));
  const eta = h('p', { class: 'lead', style: { fontSize: '15px' } }, 'Preparo…');
  const steps = [['Audio sistemato', 'audio'], ['Zoom e tagli applicati', 'video'], ['Unisco i pezzi', 'join'], ['Esportazione finale', 'final']];
  const items = steps.map(([label]) => h('div', { class: 'it' }, h('div', { class: 'spinner', style: { visibility: 'hidden' } }), h('span', { style: { flexGrow: '1' } }, label)));
  const cancel = h('button', { class: 'btn ghost' }, 'Annulla');
  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(4), h('main', { class: 'center' }, h('div', { class: 'exportbox' },
    h('img', { src: thumbUrl(pid, Math.min(30, proj.duration / 3), 180), alt: '', style: { width: '320px', height: '180px', objectFit: 'cover', borderRadius: '16px' } }),
    h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'center' } }, h('h1', { style: { margin: 0, fontSize: '28px' } }, many ? 'Sto esportando i tuoi video' : 'Sto esportando il tuo video'), eta),
    h('div', { style: { width: '100%', display: 'flex', flexDirection: 'column', gap: '6px' } }, bar, h('div', { style: { display: 'flex', justifyContent: 'space-between', gap: '12px' } }, msg, pct)),
    many ? null : h('div', { class: 'steplist' }, items),
    h('div', { class: 'row' }, h('span', { class: 'muted small' }, 'Puoi lasciare il PC da solo: il video si salva in automatico.'), cancel))));

  function mark(i, state) {
    const sp = items[i].firstChild;
    if (state === 'done') sp.replaceWith(icon('check', 20, '#34C759', 2.4));
    else if (state === 'run') sp.style.visibility = 'visible';
  }
  const t0 = Date.now();
  let lastStage = -1;
  cancel.addEventListener('click', async () => {
    if (await confirmBox('Annullare l\'esportazione?', 'Le modifiche restano salvate, puoi esportare di nuovo quando vuoi.', 'Annulla esportazione', true)) {
      await post(`/api/jobs/${job.id}/cancel`); nav('editor', back);
    }
  });
  let alive = true;
  cleanup = () => { alive = false; };
  const res = await pollJob(job.id, (j) => {
    if (!alive) return;
    const p = j.progress;
    bar.firstChild.style.width = (p * 100).toFixed(1) + '%'; bar.setAttribute('aria-valuenow', Math.round(p * 100));
    pct.textContent = Math.round(p * 100) + '%';
    if (many && j.message) msg.textContent = j.message;
    const el = (Date.now() - t0) / 1000;
    if (p > 0.03) { const left = el / p - el; eta.textContent = left > 90 ? 'Circa ' + Math.round(left / 60) + ' minuti rimanenti' : 'Meno di ' + Math.max(1, Math.ceil(left / 60)) + ' minuto rimanente'; }
    const stage = p < 0.02 ? 0 : p < 0.87 ? 1 : p < 0.93 ? 2 : 3;
    if (!many && stage !== lastStage) { for (let i = 0; i < stage; i++) mark(i, 'done'); mark(stage, 'run'); lastStage = stage; }
  });
  if (!alive) return;
  if (res.status === 'done') nav('done', pid, { back });
  else if (res.status === 'error') exportFailed(back, res.error || '');
}
// errore dell'export: resta a schermo, si puo' copiare e mandare (e' anche in VODcut/ultimo-errore-export.txt)
function exportFailed(pid, err) {
  const txt = h('pre', { class: 'lictext', 'data-notr': '1', style: { maxHeight: '220px', minHeight: '0' } }, err);
  const bg = h('div', { class: 'modal-bg' });
  const close = () => { bg.remove(); nav('editor', pid); };
  bg.append(h('div', { class: 'modal licmodal' },
    h('h2', null, 'Esportazione non riuscita'),
    h('p', null, 'Il progetto è salvato, non hai perso niente. Copia l\'errore e mandalo a chi ti aiuta: lo trovi anche nel file ultimo-errore-export.txt nella cartella VODcut.'),
    txt,
    h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px' } },
      h('button', { class: 'btn', onclick: async () => { try { await navigator.clipboard.writeText(err); toast('Errore copiato'); } catch (e) { const r = document.createRange(); r.selectNodeContents(txt); const s2 = getSelection(); s2.removeAllRanges(); s2.addRange(r); } } }, 'Copia l\'errore'),
      h('button', { class: 'btn', onclick: () => post('/api/open', { path: (ENV.appDir || '') + '/ultimo-errore-export.txt', reveal: true }).catch(() => {}) }, 'Mostra il file'),
      h('button', { class: 'btn primary', onclick: close }, 'Torna all\'editor'))));
  document.body.append(bg);
}

// ----------------------------------------------------------------- FATTO
async function screenDone(pid, extra) {
  const back = (extra && extra.back) || pid;
  const my = navSeq;
  const proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  const ex = proj.lastExport;
  if (!ex) return nav('editor', back);
  const video = h('video', { src: mediaUrl(ex.path), controls: true, style: { width: '100%', height: '100%', background: '#000', borderRadius: '18px' } });
  const openBtn = (label, path, reveal, primary) => h('button', { class: 'btn' + (primary ? ' primary' : ''), onclick: async () => { const r = await post('/api/open', { path, reveal }); if (!r.ok) toast('File non trovato', true); } }, label);
  const extras = [];
  if (ex.srt) extras.push(h('div', { class: 'row small muted' }, icon('text', 16), 'Sottotitoli per YouTube (.srt) ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); post('/api/open', { path: ex.srt, reveal: true }); } }, 'mostra')));
  if (ex.chapters) extras.push(h('div', { class: 'row small muted' }, icon('text', 16), 'Capitoli per la descrizione ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); post('/api/open', { path: ex.chapters }); } }, 'apri')));
  const vert = ex.width && ex.height && ex.height > ex.width;
  const many = ex.files && ex.files.length > 1;
  const sz = (b) => (b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round((b || 0) / 1e6)) + ' MB');
  if (many) {
    // piu' video: la lista, ognuno si apre da solo; la cartella li contiene tutti
    const folder = ex.folder || ex.path;
    if (stale(my)) return;
    app.innerHTML = '';
    app.append(topbar(4, null, true), h('main', { class: 'page', style: { gap: '20px', paddingTop: '32px' } },
      h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' } },
        h('div', { class: 'okc' }, icon('check', 22, '#34C759', 2.6)),
        h('h1', null, `${ex.files.length} video pronti`),
        h('div', { class: 'muted' }, 'Tutti nella stessa cartella' + (ex.files.some((f) => f.vertical) && ex.files.some((f) => !f.vertical) ? ', le verticali in "Clip verticali"' : ''))),
      h('div', { class: 'donelist' }, ...ex.files.map((f) => h('div', { class: 'donerow' },
        h('span', { class: 'dr-ic' + (f.vertical ? ' v' : '') }, icon(f.vertical ? 'phone' : 'film', 16, 'currentColor', 2)),
        h('div', { class: 'dr-tx' }, h('b', { 'data-notr': '' }, f.name), h('span', null, `${fmt(f.duration)} · ${f.width}×${f.height} · ${sz(f.size)}`)),
        h('button', { class: 'btn sm', onclick: () => post('/api/open', { path: f.path, reveal: true }) }, 'Mostra'),
        h('button', { class: 'btn sm primary', onclick: async () => { const r = await post('/api/open', { path: f.path }); if (!r.ok) toast('File non trovato', true); } }, 'Apri')))),
      h('div', { class: 'row' },
        h('button', { class: 'btn', onclick: () => nav('editor', back) }, 'Torna all\'editor'),
        h('button', { class: 'btn primary', onclick: async () => { const r = await post('/api/open', { path: folder, reveal: !ex.folder }); if (!r.ok) toast('Cartella non trovata', true); } }, icon('folder', 14, '#fff'), 'Apri la cartella'))));
    return;
  }
  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(4, null, true), h('main', { class: 'page', style: { gap: '20px', paddingTop: '32px' } },
    h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' } },
      h('div', { class: 'okc' }, icon('check', 22, '#34C759', 2.6)),
      h('h1', null, 'Il tuo video è pronto'),
      h('div', { class: 'muted' }, `${proj.name} · ${fmt(ex.duration)} · ${Math.min(ex.width || ex.height, ex.height)}p` + (ex.fps ? ` · ${Math.round(ex.fps)} fps` : '') + (ex.size ? ` · ${ex.size >= 1e9 ? (ex.size / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(ex.size / 1e6)) + ' MB'}` : '') + ' · pronto per YouTube')),
    h('div', { style: vert ? { height: 'min(62vh, 700px)', aspectRatio: '9/16' } : { width: 'min(860px, 100%)', aspectRatio: '16/9' } }, video),
    h('div', { class: 'row' },
      h('button', { class: 'btn', onclick: () => nav('editor', back) }, 'Torna all\'editor'),
      openBtn('Mostra nella cartella', ex.path, true),
      proj.parent ? null : h('button', { class: 'btn', onclick: () => exportProjectFile(pid, proj.name) }, icon('share', 14), 'Passa a un altro PC'),
      openBtn('Apri il video', ex.path, false, true)),
    extras.length ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px', alignItems: 'center' } }, extras) : null));
  cleanup = () => { video.pause(); video.removeAttribute('src'); video.load(); };
}

// ----------------------------------------------------------------- avvio
window.addEventListener('error', (e) => post('/api/clientlog', { msg: 'ERRORE JS: ' + e.message + ' @ ' + (e.filename || '') + ':' + e.lineno }).catch(() => {}));
window.addEventListener('unhandledrejection', (e) => post('/api/clientlog', { msg: 'ERRORE promessa: ' + (e.reason && e.reason.message || e.reason) }).catch(() => {}));
post('/api/clientlog', { msg: 'app avviata ' + location.href.split('?')[0] }).catch(() => {});
// lingua: quella scelta, se no quella di Windows
{
  let saved = null;
  try { saved = localStorage.getItem('vodcut.lang'); } catch (e) { /* */ }
  const lang = pickLang(saved);
  await loadLang(lang);
  startTranslating();
  post('/api/settings', { lang }).catch(() => {});   // per le finestre di Windows (scegli file, salva)
}
const ping = () => fetch('/api/ping?ui=1').then((r) => r.json()).then((j) => onUpd(j.upd)).catch(() => {});
setInterval(ping, 5000);
ping();
nav('home');
// avvio con doppio clic su un file .vodcut
{
  const op = new URLSearchParams(location.search).get('open');
  if (op) { history.replaceState(null, '', '/'); setTimeout(() => importProjectPath(op), 400); }
}
// niente menu del browser col tasto destro (resta solo nei campi di testo); le tracce hanno il loro menu
document.addEventListener('contextmenu', (e) => { if (!e.target.closest('input, textarea, [contenteditable="true"]')) e.preventDefault(); });
