"""Esportazione: applica tagli, zoom, audio e sottotitoli e crea il video finale.

Strategia (veloce anche su VOD di ore):
- il video viene diviso in pezzi; i pezzi SENZA zoom passano direttamente da ffmpeg
  (veloce), i pezzi CON zoom passano da Python fotogramma per fotogramma;
- i pezzi vengono uniti senza ricodifica;
- l'audio viene mixato in un unico grafo ffmpeg (volumi, muti, suoni, musica che si
  abbassa quando parli, rumore, bip, normalizzazione) e tagliato negli stessi punti.
"""
import json
import math
from . import easing as EASE
import os
import re
import shutil
import sys
import subprocess
import threading
import time

import cv2
import numpy as np

from . import fx as FX
from . import overlay as OV
from . import project as P
from . import vertical as VT
from . import face as FACE
from .util import (EXPORTS_DIR, SETTINGS_FILE, probe, export_encoder_args, ffmpeg_bin, filter_script_args, fmt_time, gpu_name, nvenc_ok, popen, run,
                   tempdir, video_encoder_args, NO_WINDOW, ffprobe_bin)

EXPORT_DEFAULT = {"dir": "", "format": "mp4", "codec": "h264", "bitrate": "rec", "fps": "source", "audio": True, "abr": 192}
BPP = {"low": 0.05, "rec": 0.1, "high": 0.18}   # bit per pixel per fotogramma (uguale al calcolo del peso nell'app)


def export_opts(proj):
    e = dict(EXPORT_DEFAULT)
    e.update((proj.get("settings") or {}).get("export") or {})
    return e


def video_bitrate(e, W, H, fps):
    return BPP.get(e.get("bitrate"), 0.1) * W * H * fps * (0.6 if e.get("codec") == "h265" else 1.0)

DRIFT = 0.10
SNAP_T = 0.35
SMOOTH_IN = 0.6
SMOOTH_OUT = 0.45

PROFANITY = {
    "cazzo", "cazzi", "cazzata", "cazzate", "minchia", "merda", "stronzo", "stronza", "stronzi", "vaffanculo",
    "fanculo", "coglione", "coglioni", "puttana", "troia", "bastardo", "bastarda", "porcodio", "porcamadonna",
    "fuck", "fucking", "fucked", "shit", "bitch", "motherfucker", "asshole", "dick",
}


class Cancelled(Exception):
    pass


# ------------------------------------------------------------------ curva zoom
def ease_in_out_cubic(t):
    t = max(0.0, min(1.0, t))
    return 4 * t ** 3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2


IN_DUR = {"fast": 0.25, "smooth": SMOOTH_IN, "slow": 1.2, "punch": 0.45}
OUT_DUR = {"fast": 0.25, "smooth": SMOOTH_OUT, "slow": 1.0}


def ease_out_back(t):
    t = max(0.0, min(1.0, t))
    c = 1.2
    return 1 + (c + 1) * (t - 1) ** 3 + c * (t - 1) ** 2


def zoom_progress(t, z):
    """Stessi calcoli di web/lib.js zoomProgress (effetti di entrata e uscita)."""
    a, b = z["a"], z["b"]
    if not (a <= t < b):
        return 0.0
    dt, D = t - a, max(0.01, b - a)
    u = dt / D
    ki = z.get("in") or "snap"
    drift = DRIFT
    if ki == "snap" or ki not in IN_DUR and ki not in ("punch", "ramp"):
        base, drift = 1.0, 0.0   # scatto: subito ingrandito, nessuna animazione
    elif ki == "punch":
        base = ease_out_back(dt / IN_DUR["punch"])
    elif ki == "ramp":   # spinge piano per tutto lo zoom (come web/lib.js)
        base, drift = 0.25 + 0.75 * (0.5 - 0.5 * math.cos(math.pi * min(1.0, u))), 0.0
    else:
        base = ease_in_out_cubic(dt / IN_DUR[ki])
    p = base + drift * (1 - (1 - u) ** 2)
    od = OUT_DUR.get(z.get("out"))
    if od and b - t < od:
        p *= ease_in_out_cubic((b - t) / od)
    return p


def zoom_at(z, t):
    """Zoom con l'inquadratura dell'istante t se ha i keyframe (z["kf"] = [{t, rect} o {t, vrect}], t dall'inizio
    dello zoom). Stessa matematica di web/lib.js zoomAt."""
    kf = z.get("kf") or []
    lv = bool(EASE.pk_list(z, "level"))
    if not kf and not lv:
        return z
    tr = t - z["a"]
    out = dict(z)
    if lv:   # ingrandimento dello zoom sulla webcam che cambia nel tempo
        out["level"] = EASE.pk_at(z, "level", tr, z.get("level") or 2.8)
    for key in ("rect", "vrect"):
        ks = sorted((k for k in kf if isinstance(k.get(key), (list, tuple)) and len(k[key]) >= 3), key=lambda k: k["t"])
        if not ks:
            continue
        if tr <= ks[0]["t"]:
            out[key] = list(ks[0][key]); continue
        if tr >= ks[-1]["t"]:
            out[key] = list(ks[-1][key]); continue
        i = 0
        while i < len(ks) - 2 and tr >= ks[i + 1]["t"]:
            i += 1
        k0, k1 = ks[i], ks[i + 1]
        u0 = (tr - k0["t"]) / max(1e-6, k1["t"] - k0["t"])
        u = EASE.ease(u0, k0.get("ease", "smooth"))
        out[key] = [a + (b - a) * u for a, b in zip(k0[key], k1[key])]
    return out


def target_rect(W, H, cam, level):
    """Inquadratura a zoom pieno: la webcam grande, dalla stessa parte in cui sta."""
    cx, cy, cw, ch = cam
    Z = max(1.05, level)
    w, h = W / Z, H / Z
    mx, my = 0.02 * w, 0.03 * h
    if cx + cw / 2 > W * 0.55:
        x = cx + cw + mx - w          # webcam a destra
    elif cx + cw / 2 < W * 0.45:
        x = cx - mx                   # webcam a sinistra
    else:
        x = cx + cw / 2 - w / 2
    if cy + ch / 2 < H * 0.5:
        y = cy - my                   # in alto
    else:
        y = cy + ch + my - h          # in basso
    x = min(max(0, x), W - w)
    y = min(max(0, y), H - h)
    return x, y, w, h


def custom_rect(W, H, rect):
    """Inquadratura scelta dall'utente: stesso formato del video, dentro il fotogramma."""
    x, y, w = rect[0], rect[1], rect[2]
    w = max(W / 8, min(W / 1.05, w))
    h = w * H / W
    return min(max(0, x), W - w), min(max(0, y), H - h), w, h


def rect_at(p, W, H, R):
    x, y, w, h = R
    Z = W / w
    k = 1 - 1 / Z
    px, py = x / k, y / k
    s = math.exp(p * math.log(Z))
    rw, rh = W / s, H / s
    rx, ry = px - px / s, py - py / s
    return min(max(0, rx), W - rw), min(max(0, ry), H - rh), rw, rh


# ------------------------------------------------------------------ helpers
def out_size(proj):
    """Qualita' scelta, mai sopra quella del VOD (niente ingrandimenti inutili)."""
    q = str(proj["settings"].get("quality") or "")
    sw, sh = proj["width"], proj["height"]
    m = re.match(r"(\d+)p", q)
    Q = 2160 if q == "4K" else (int(m.group(1)) if m else min(sw, sh))
    if sh > sw:   # video verticale: la qualita' (1080p…) e' la larghezza, il lato corto
        W = int(min(Q, sw) // 2 * 2)
        return W, int(round(W * sh / sw / 2) * 2)
    H = int(min(Q, sh) // 2 * 2)
    W = int(round(H * sw / sh / 2) * 2)
    return W, H


class FrameReader:
    """Fotogrammi grezzi da ffmpeg per lo zoom. Se il decoder si ferma prima del previsto (capita con alcune live
    scaricate: pezzi con i tempi sballati), lo si riavvia con una ricerca precisa e si riprende dal fotogramma giusto,
    invece di ripetere l'ultimo (video che si blocca durante lo zoom)."""

    def __init__(self, make_cmd, fsize, work, log, label):
        self.make_cmd, self.fsize, self.work, self.log, self.label = make_cmd, fsize, work, log, label
        self.k, self.tries = 0, 0
        self._start(False, 0)

    def _start(self, precise, skip):
        import tempfile
        self.err = tempfile.TemporaryFile(dir=self.work)
        self.p = popen(self.make_cmd(precise), stdout=subprocess.PIPE, stderr=self.err, bufsize=self.fsize * 2, cwd=self.work)
        for _ in range(skip):
            if len(self.p.stdout.read(self.fsize)) < self.fsize:
                break

    def _err_tail(self):
        try:
            self.err.seek(0)
            return self.err.read().decode(errors="ignore")[-300:].strip()
        except Exception:
            return ""

    def read(self):
        buf = self.p.stdout.read(self.fsize)
        if len(buf) == self.fsize:
            self.k += 1
            return buf
        if self.tries < 2:
            self.tries += 1
            self.log(f"[zoom] {self.label}: il video si ferma al fotogramma {self.k}, riprovo ({self._err_tail()})")
            self.kill()
            self._start(True, self.k)
            return self.read()
        self.log(f"[zoom] {self.label}: mancano fotogrammi dal {self.k} ({self._err_tail()})")
        return buf

    @property
    def stdout(self):
        return self.p.stdout

    def kill(self):
        try:
            self.p.kill()
            self.p.wait(timeout=5)
        except Exception:
            pass

    def poll(self):
        return self.p.poll()


def seek_args(ss, precise):
    """Ricerca veloce (sul fotogramma chiave prima) o precisa (decodifica gli ultimi secondi)."""
    t = float(ss)
    if not precise or t < 6:
        return ["-ss", f"{t:.6f}"] if not precise else [], (["-ss", f"{t:.6f}"] if precise else [])
    return ["-ss", f"{t - 5:.6f}"], ["-ss", "5"]


def cfr_args(fps_str):
    """Fotogrammi a ritmo costante quando si leggono per lo zoom: con le live a frame rate variabile il decoder
    ne darebbe meno del previsto e l'ultimo si ripeterebbe (video che si blocca e poi riparte)."""
    from .util import ffmpeg_major
    return (["-fps_mode", "cfr"] if ffmpeg_major() >= 6 else ["-vsync", "cfr"]) + ["-r", fps_str]


def fps_string(src):
    try:
        out = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                                       "stream=avg_frame_rate,r_frame_rate", "-of", "csv=p=0", src],
                                      creationflags=NO_WINDOW).decode().strip().split("\n")[0]
        avg, rfr = (out.split(",") + ["", ""])[:2]
        for cand in (avg, rfr):
            if cand and "/" in cand:
                n, d = map(int, cand.split("/"))
                if d and 5 < n / d < 241:
                    return cand, n / d
    except Exception:
        pass
    return "30/1", 30.0


def seekable_source(src, log=print, progress=None, check=None):
    """I VOD scaricati da Twitch sono spesso MPEG-TS (anche se finiscono in .mp4): li' saltare a un punto preciso non e'
    affidabile e dopo ogni taglio o zoom il video resta fermo. Si ricopia una volta in un MP4 vero (senza ricodificare,
    solo contenitore: veloce), tenuto in cache e riusato."""
    try:
        fmt = subprocess.check_output([ffprobe_bin(), "-v", "error", "-show_entries", "format=format_name", "-of", "csv=p=0", src],
                                      creationflags=NO_WINDOW, timeout=60).decode().strip()
    except Exception:
        return src
    if "mpegts" not in fmt:
        return src
    import hashlib
    from .util import CACHE_DIR
    st = os.stat(src)
    key = hashlib.sha1(f"{os.path.abspath(src)}|{st.st_size}|{int(st.st_mtime)}".encode()).hexdigest()[:16]
    d = os.path.join(CACHE_DIR, "remux")
    os.makedirs(d, exist_ok=True)
    out = os.path.join(d, key + ".mp4")
    if os.path.isfile(out) and os.path.getsize(out) > 0:
        return out
    for f in os.listdir(d):                  # tiene solo l'ultimo (sono file grandi)
        try:
            os.remove(os.path.join(d, f))
        except OSError:
            pass
    log("Sorgente MPEG-TS: lo ricopio in MP4 per tagli precisi (una volta sola)")
    tmp = out + ".part.mp4"
    dur = 0.0
    try:
        dur = float(probe(src)["duration"] or 0)
    except Exception:
        pass
    p = popen([ffmpeg_bin(), "-v", "error", "-y", "-fflags", "+genpts", "-i", src, "-map", "0:v:0", "-map", "0:a?", "-c", "copy",
               "-avoid_negative_ts", "make_zero", "-progress", "pipe:1", "-nostats", tmp], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for line in p.stdout:
        if check:
            try:
                check()
            except Exception:
                p.kill()
                raise
        m = re.match(rb"out_time_us=(\d+)", line)
        if m and dur and progress:
            progress(min(1.0, int(m.group(1)) / 1e6 / dur))
    p.wait()
    if p.returncode != 0 or not os.path.isfile(tmp):
        log("Copia in MP4 non riuscita, uso il file originale: " + p.stderr.read().decode(errors="ignore")[-300:])
        try:
            os.remove(tmp)
        except OSError:
            pass
        return src
    os.replace(tmp, out)
    return out


def source_info(src):
    out = subprocess.check_output([ffprobe_bin(), "-v", "error", "-select_streams", "v:0", "-show_entries",
                                   "stream=codec_name,avg_frame_rate,r_frame_rate,start_time:format=start_time,format_name",
                                   "-of", "json", src], creationflags=NO_WINDOW, timeout=30)
    j = json.loads(out)
    st = (j.get("streams") or [{}])[0]
    return (f"{st.get('codec_name')} avg {st.get('avg_frame_rate')} r {st.get('r_frame_rate')} inizio {st.get('start_time')} "
            f"({(j.get('format') or {}).get('format_name')})")


def count_frames(path):
    out = subprocess.check_output([ffprobe_bin(), "-v", "error", "-select_streams", "v:0", "-count_packets", "-show_entries",
                                   "stream=nb_read_packets", "-of", "csv=p=0", path], creationflags=NO_WINDOW, timeout=60)
    t = out.decode().strip().split(",")[0]
    return int(t) if t.isdigit() else None


def timing_report(path, fps):
    """Quanti salti o doppioni di tempo ci sono nel video finale (dovrebbero essere 0)."""
    out = subprocess.check_output([ffprobe_bin(), "-v", "error", "-select_streams", "v:0", "-show_entries", "packet=pts_time",
                                   "-of", "csv=p=0", path], creationflags=NO_WINDOW, timeout=600)
    ts = sorted(float(x.split(",")[0]) for x in out.decode().split() if x and x[0].isdigit())
    step = 1.0 / fps
    gaps = [(a, b - a) for a, b in zip(ts, ts[1:]) if b - a > step * 1.5]
    dups = [a for a, b in zip(ts, ts[1:]) if b - a < step * 0.5]
    txt = f"{len(ts)} fotogrammi, {len(gaps)} salti, {len(dups)} doppioni"
    if gaps:
        txt += " · salti a " + ", ".join(f"{a:.2f}s (+{d:.3f})" for a, d in gaps[:12])
    if dups:
        txt += " · doppioni a " + ", ".join(f"{a:.2f}s" for a in dups[:12])
    return txt


def unique_path(folder, name, ext):
    base = re.sub(r'[\\/:*?"<>|]+', "_", name).strip() or "video"
    p = os.path.join(folder, base + ext)
    i = 2
    while os.path.exists(p):
        p = os.path.join(folder, f"{base} ({i}){ext}")
        i += 1
    return p


def seg_at(proj, t):
    for c in proj.get("segs") or []:
        if c["a"] <= t < c["b"]:
            return c
    return None


def _ev(v):
    return max(2, int(round(v / 2.0)) * 2)


def tf_chain(seg, SW, SH):
    """Clip spostata/ingrandita a mano (come web: tf = {s, x, y}): filtro ffmpeg che la mette al suo posto,
    con il nero dove non c'e' video. Solo la parte che si vede viene ritagliata e ingrandita."""
    tf = (seg or {}).get("tf")
    if not tf:
        return None
    s_ = max(0.05, min(30.0, float(tf.get("s") or 1)))
    x, y = float(tf.get("x") or 0), float(tf.get("y") or 0)
    if abs(s_ - 1) < 1e-4 and abs(x) < 1e-4 and abs(y) < 1e-4:
        return None
    sw, sh = SW * s_, SH * s_
    px, py = (SW - sw) / 2 + x * SW, (SH - sh) / 2 + y * SH
    ox0, oy0, ox1, oy1 = max(0.0, px), max(0.0, py), min(float(SW), px + sw), min(float(SH), py + sh)
    if ox1 - ox0 < 2 or oy1 - oy0 < 2:
        return f"drawbox=c=black:t=fill"
    cx, cy = (ox0 - px) / s_, (oy0 - py) / s_
    cw, ch = (ox1 - ox0) / s_, (oy1 - oy0) / s_
    ow, oh = _ev(ox1 - ox0), _ev(oy1 - oy0)
    ow, oh = min(ow, SW), min(oh, SH)
    ax, ay = min(int(round(ox0)), SW - ow), min(int(round(oy0)), SH - oh)
    return (f"crop={max(2, int(round(cw)))}:{max(2, int(round(ch)))}:{int(round(cx))}:{int(round(cy))},"
            f"scale={ow}:{oh}:flags=lanczos,setsar=1,pad={SW}:{SH}:{ax}:{ay}:black")


def tf_has_kf(seg):
    pk = (seg or {}).get("pk") or {}
    return bool(pk.get("s") or pk.get("x") or pk.get("y"))


def tf_at(seg, t):
    """Posizione/zoom della clip all'istante t (con i keyframe pk.s/x/y). Come tfOf in web/editor.js."""
    b = {"s": 1.0, "x": 0.0, "y": 0.0, **((seg or {}).get("tf") or {})}
    if not tf_has_kf(seg):
        return b
    tr = t - seg["a"]
    return {k: EASE.pk_at(seg, k, tr, float(b[k])) for k in ("s", "x", "y")}


def tf_frame(img, tf):
    """Stesso spostamento/ingrandimento di tf_chain, su un fotogramma gia' pronto (dopo lo zoom)."""
    H, W = img.shape[:2]
    s_ = max(0.05, min(30.0, float(tf.get("s") or 1)))
    ox = ((1 - s_) / 2 + float(tf.get("x") or 0)) * W
    oy = ((1 - s_) / 2 + float(tf.get("y") or 0)) * H
    M = np.array([[s_, 0, ox], [0, s_, oy]], np.float32)
    return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))


def unique_dir(folder, name):
    """Cartella nuova (se esiste gia': "nome (2)", "nome (3)"…)."""
    p = os.path.join(folder, name)
    i = 2
    while os.path.exists(p):
        p = os.path.join(folder, f"{name} ({i})")
        i += 1
    return p


# ------------------------------------------------------------------ sottotitoli
SUB_DEFAULT = {
    "font": "Arial", "size": 0.055, "y": 0.92, "color": "#FFFFFF", "bold": True, "upper": False,
    "stroke": False, "strokeColor": "#000000", "strokeW": 0.08,
    "box": True, "boxColor": "#000000", "boxOp": 70,
    "shadow": False, "effect": "none", "hiColor": "#FFD60A", "maxChars": 38,
}
# file dei font di Windows da mettere accanto ai sottotitoli
FONT_FILES = {
    "Arial": ("arial.ttf", "arialbd.ttf"), "Verdana": ("verdana.ttf", "verdanab.ttf"),
    "Georgia": ("georgia.ttf", "georgiab.ttf"), "Trebuchet MS": ("trebuc.ttf", "trebucbd.ttf"),
    "Impact": ("impact.ttf",), "Segoe UI": ("segoeui.ttf", "segoeuib.ttf"),
    "Comic Sans MS": ("comic.ttf", "comicbd.ttf"), "Tahoma": ("tahoma.ttf", "tahomabd.ttf"),
}


def sub_style(proj):
    st = dict(SUB_DEFAULT)
    st.update(proj.get("subStyle") or {})
    return st


def subtitle_chunks(proj, mapper):
    """Frasi brevi dei sottotitoli: [(inizio, fine, testo, [(inizio, fine, parola)])]."""
    removed = P.removed_ranges(proj)
    max_chars = int(sub_style(proj).get("maxChars") or 38)

    def is_removed(a, b):
        mid = (a + b) / 2
        return any(ra <= mid <= rb for ra, rb in removed)

    chunks = []
    for seg in proj.get("transcript", {}).get("segments", []):
        cur = []
        for w in seg.get("words", []):
            if w.get("del") or is_removed(w["a"], w["b"]):
                continue
            if w.get("nosub"):  # sottotitoli nascosti in questa parte
                if cur:
                    chunks.append(cur)
                    cur = []
                continue
            ta, tb = mapper(w["a"]), mapper(w["b"])
            if ta is None or tb is None:
                continue
            text_len = sum(len(x[2]) + 1 for x in cur)
            if cur and (text_len + len(w["w"]) > max_chars or ta - cur[-1][1] > 0.7 or tb - cur[0][0] > 3.5):
                chunks.append(cur)
                cur = []
            word = w["w"]
            if w.get("cens") or (proj["settings"].get("bleep") and re.sub(r"[^\wàèéìòù]", "", word.lower()) in PROFANITY):
                word = word[0] + "*" * max(1, len(word) - 2) + (word[-1] if len(word) > 2 else "")
            cur.append((ta, tb, word))
        if cur:
            chunks.append(cur)
    out = []
    for c in chunks:
        a, b = c[0][0], max(c[-1][1], c[0][0] + 0.6)
        out.append((a, b, " ".join(x[2] for x in c), c))
    for i in range(len(out) - 1):  # niente sovrapposizioni
        if out[i][1] > out[i + 1][0]:
            out[i] = (out[i][0], out[i + 1][0], out[i][2], out[i][3])
    return out


def _ts_srt(t):
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _ts_ass(t):
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def write_srt(chunks, path):
    with open(path, "w", encoding="utf-8") as f:
        for i, ch in enumerate(chunks, 1):
            f.write(f"{i}\n{_ts_srt(ch[0])} --> {_ts_srt(ch[1])}\n{ch[2]}\n\n")


def ass_color(hexc, alpha=0):
    """#RRGGBB -> &HAABBGGRR (alpha 0 = opaco)."""
    h = (hexc or "#FFFFFF").lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{int(alpha):02X}{b}{g}{r}".upper()


def _ass_text(t):
    return t.replace("\\", "/").replace("{", "(").replace("}", ")")


def write_ass(chunks, path, W, H, st=None):
    """Sottotitoli con lo stile scelto nell'app (stessi valori dell'anteprima)."""
    st = dict(SUB_DEFAULT, **(st or {}))
    fs = max(8, round(st["size"] * H))
    bold = -1 if st.get("bold") else 0
    margin_v = max(0, round((1 - st["y"]) * H))
    margin_lr = round(W * 0.06)
    outline = round(st["strokeW"] * fs, 1) if st.get("stroke") else 0
    shadow = round(0.06 * fs, 1) if st.get("shadow") else 0
    pad = round(0.18 * fs, 1)
    box_alpha = round(255 * (1 - max(0, min(100, st.get("boxOp", 70))) / 100))
    font = st.get("font") or "Arial"
    prim = ass_color(st["color"])
    hi = "&H" + ass_color(st.get("hiColor") or "#FFD60A")[4:] + "&"
    prim_i = "&H" + prim[4:] + "&"
    with open(path, "w", encoding="utf-8") as f:
        f.write("[Script Info]\nScriptType: v4.00+\nPlayResX: %d\nPlayResY: %d\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n" % (W, H))
        f.write("[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
                "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, "
                "Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n")
        # testo: contorno e ombra
        f.write(f"Style: T,{font},{fs},{prim},{prim},{ass_color(st['strokeColor'])},&H80000000,{bold},0,0,0,100,100,0,0,1,"
                f"{outline},{shadow},2,{margin_lr},{margin_lr},{margin_v},1\n")
        # riquadro dietro al testo (livello sotto, testo invisibile)
        box = ass_color(st["boxColor"], box_alpha)
        f.write(f"Style: B,{font},{fs},&HFF000000,&HFF000000,{box},{box},{bold},0,0,0,100,100,0,0,3,"
                f"{pad},0,2,{margin_lr},{margin_lr},{margin_v},1\n\n")
        f.write("[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
        up = (lambda x: x.upper()) if st.get("upper") else (lambda x: x)
        pop = "{\\fscx82\\fscy82\\t(0,140,\\fscx100\\fscy100)}" if st.get("effect") == "pop" else ""
        for ch in chunks:
            a, b, text = ch[0], ch[1], ch[2]
            words = ch[3] if len(ch) > 3 else [(a, b, text)]
            ws = [_ass_text(up(w[2])) for w in words]
            full = " ".join(ws)
            if st.get("box"):
                f.write(f"Dialogue: 0,{_ts_ass(a)},{_ts_ass(b)},B,,0,0,0,,{pop}{full}\n")
            if st.get("effect") == "highlight" and len(words) > 1:
                # la parola che stai dicendo cambia colore
                for i, w in enumerate(words):
                    s0 = a if i == 0 else w[0]
                    s1 = b if i == len(words) - 1 else min(b, words[i + 1][0])
                    if s1 <= s0:
                        continue
                    txt = " ".join(("{\\c%s}%s{\\c%s}" % (hi, x, prim_i)) if j == i else x for j, x in enumerate(ws))
                    f.write(f"Dialogue: 1,{_ts_ass(s0)},{_ts_ass(s1)},T,,0,0,0,,{pop if i == 0 else ''}{txt}\n")
            else:
                f.write(f"Dialogue: 1,{_ts_ass(a)},{_ts_ass(b)},T,,0,0,0,,{pop}{full}\n")


def app_lang():
    """Lingua scelta nell'app (per i file di testo esportati)."""
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            return json.load(f).get("lang") or "it"
    except Exception:
        return "it"


def write_chapters(proj, mapper, total, path):
    if total < 180:
        return False
    step = max(60, int(round(total / 6 / 60)) * 60)
    marks = list(range(0, int(total - 30), step))
    if len(marks) < 3:
        return False
    words = []
    for seg in proj.get("transcript", {}).get("segments", []):
        for w in seg.get("words", []):
            if not w.get("del"):
                tt = mapper(w["a"])
                if tt is not None:
                    words.append((tt, w["w"]))
    lines = []
    for i, m in enumerate(marks):
        if i == 0:
            title = "Inizio"
        else:
            nxt = [w for w in words if w[0] >= m][:6]
            title = (" ".join(w[1] for w in nxt).strip(" ,.") or f"Parte {i + 1}")
            title = title[:1].upper() + title[1:]
        lines.append(f"{fmt_time(m)} {title}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(("Chapters (paste them into the YouTube description, then rename them if you like):\n\n" if app_lang() == "en"
                 else "Capitoli (incollali nella descrizione di YouTube, poi rinominali se vuoi):\n\n"))
        f.write("\n".join(lines) + "\n")
    return True


# ------------------------------------------------------------------ audio
def _num(x):
    return f"{x:.3f}"


def live_volume_expr(proj, bleeps):
    track = next(t for t in proj["tracks"] if t["type"] == "live")
    if track.get("mute"):
        return "0"
    tv = track.get("vol", 100) / 100
    terms = []
    P.ensure_segs(proj)
    for c in proj["segs"]:
        if c.get("mute") or c.get("vol", 100) <= 0:
            continue
        a, b, v = c["a"], c["b"], c.get("vol", 100) / 100 * tv
        term = f"between(t,{_num(a)},{_num(b)})*{v:.3f}"
        if c.get("fin"):
            term += f"*min(1,(t-{_num(a)})/0.5)"
        if c.get("fout"):
            term += f"*min(1,({_num(b)}-t)/0.5)"
        terms.append(term)
    if not terms:
        return "0"
    expr = "(" + "+".join(terms) + ")"
    if bleeps:
        mask = "+".join(f"between(t,{_num(a)},{_num(b)})" for a, b in bleeps)
        expr += f"*(1-min(1,{mask}))"
    return expr


def _merge(iv):
    out = []
    for a, b in sorted(iv):
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def live_volume_cmds(proj, bleeps):
    """Volume della live nel tempo come comandi (asendcmd) invece di un'unica espressione enorme:
    con tante clip l'espressione diventava cosi' lunga che ffmpeg finiva la memoria."""
    track = next(t for t in proj["tracks"] if t["type"] == "live")
    if track.get("mute"):
        return [(0.0, "0")]
    tv = track.get("vol", 100) / 100
    P.ensure_segs(proj)
    segs = sorted(proj["segs"], key=lambda c: c["a"])
    bl = _merge(bleeps)
    pts = {0.0} | {x for c in segs for x in (c["a"], c["b"])} | {x for iv in bl for x in iv}
    for c in segs:   # volume con i keyframe: tanti tratti dritti che seguono la curva
        sm = EASE.pk_samples(c, "vol", c["b"] - c["a"], c.get("vol", 100))
        if sm:
            pts |= {c["a"] + t for t, _ in sm if 0 < t < c["b"] - c["a"]}
    pts = sorted(pts)
    cmds, prev = [], None
    si = bi = 0
    for x, y in zip(pts, pts[1:] + [pts[-1] + 1e9]):
        m = (x + min(y, x + 1e6)) / 2
        while si < len(segs) and segs[si]["b"] <= m:
            si += 1
        while bi < len(bl) and bl[bi][1] <= m:
            bi += 1
        c = segs[si] if si < len(segs) and segs[si]["a"] <= m < segs[si]["b"] else None
        if c is None or c.get("mute") or c.get("vol", 100) <= 0 or (bi < len(bl) and bl[bi][0] <= m < bl[bi][1]):
            e = "0"
        elif EASE.pk_list(c, "vol"):
            v0 = EASE.pk_at(c, "vol", x - c["a"], c.get("vol", 100)) / 100 * tv
            v1 = EASE.pk_at(c, "vol", min(y, c["b"]) - c["a"], c.get("vol", 100)) / 100 * tv
            dx = max(1e-6, min(y, c["b"]) - x)
            e = f"{v0:.4f}" if abs(v1 - v0) < 1e-6 else f"({v0:.4f}+({(v1 - v0) / dx:.6f})*(t-{x:.4f}))"
            if c.get("fin"):
                e += f"*min(1,(t-{_num(c['a'])})/0.5)"
            if c.get("fout"):
                e += f"*min(1,({_num(c['b'])}-t)/0.5)"
        else:
            v = c.get("vol", 100) / 100 * tv
            e = f"{v:.3f}"
            if c.get("fin"):
                e += f"*min(1,(t-{_num(c['a'])})/0.5)"
            if c.get("fout"):
                e += f"*min(1,({_num(c['b'])}-t)/0.5)"
        if e != prev:
            cmds.append((x, e))
            prev = e
    return cmds


def write_cmds(path, cmds, target="volume"):
    with open(path, "w", encoding="utf-8") as f:
        for t, e in cmds:
            f.write(f"{max(0.0, t):.4f} {target} volume '{e}';\n")


def find_bleeps(proj, profanity=True):
    """Parole da coprire con il bip: quelle censurate a mano (+ parolacce se attivo)."""
    out = []
    segs = proj.get("transcript", {}).get("segments", [])
    for seg in segs:
        ws = seg.get("words", [])
        for i, w in enumerate(ws):
            clean = re.sub(r"[^\wàèéìòù]", "", w["w"].lower())
            hit = profanity and clean in PROFANITY
            if profanity and clean == "dio" and i > 0 and re.sub(r"\W", "", ws[i - 1]["w"].lower()) in ("porco", "porca"):
                hit = True
            hit = hit or bool(w.get("cens"))
            if hit and not w.get("del"):
                out.append((w["a"] - 0.03, w["b"] + 0.03))
    return out


def build_audio_graph(proj, keep_frames, fps, dur, work="."):
    """Ritorna (lista input extra, testo del grafo). Input 0 = VOD."""
    S = proj["settings"]
    inputs = []
    lines = []
    bleeps = find_bleeps(proj, bool(S.get("bleep")))
    write_cmds(os.path.join(work, "live_vol.cmd"), live_volume_cmds(proj, bleeps))
    fmt = "aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo"
    pcs = P.pieces(proj)
    if len(pcs) == 1:
        src_a = f"[0:a]{fmt}" if proj.get("hasAudio", True) else f"anullsrc=r=48000:cl=stereo,atrim=0:{_num(dur)}"
    else:
        # video inseriti: l'audio della timeline e' la live a pezzi + l'audio dei video inseriti
        nlive = sum(1 for p_ in pcs if p_["live"])
        if proj.get("hasAudio", True):
            lines.append(f"[0:a]{fmt}" + (f",asplit={nlive}" + "".join(f"[lv{k}]" for k in range(nlive)) if nlive > 1 else "[lv0]"))
        cat, k = [], 0
        for j, p_ in enumerate(pcs):
            ln = p_["t1"] - p_["t0"]
            if p_["live"] and proj.get("hasAudio", True):
                lines.append(f"[lv{k}]atrim={_num(p_['off'])}:{_num(p_['off'] + ln)},asetpts=PTS-STARTPTS[pc{j}]")
            elif not p_["live"] and p_["ins"].get("hasAudio") and os.path.exists(p_["file"]):
                idx = len(inputs) + 1
                inputs.append(p_["file"])
                lines.append(f"[{idx}:a]{fmt},atrim={_num(p_['off'])}:{_num(p_['off'] + ln)},asetpts=PTS-STARTPTS,"
                             f"apad=whole_dur={_num(ln)},atrim=0:{_num(ln)}[pc{j}]")
            else:
                lines.append(f"anullsrc=r=48000:cl=stereo,atrim=0:{_num(ln)}[pc{j}]")
            if p_["live"]:
                k += 1
            cat.append(f"[pc{j}]")
        lines.append("".join(cat) + f"concat=n={len(cat)}:v=0:a=1[liveraw]")
        src_a = "[liveraw]anull"
    chain = src_a
    if S.get("denoise"):
        chain += ",afftdn=nf=-25"
    chain += ",asendcmd=f=live_vol.cmd,volume=0:eval=frame[live]"
    lines.append(chain)

    duck_labels, plain_labels = [], []
    for tr in proj["tracks"]:
        is_ov = tr["type"] == "overlay"
        if (tr["type"] != "sound" and not is_ov) or tr.get("mute") or (is_ov and tr.get("hidden")):
            continue
        tv = tr.get("vol", 100) / 100
        for c in tr["clips"]:
            if is_ov and not (c.get("kind") == "video" and c.get("hasAudio")):
                continue   # dalle tracce video conta solo l'audio dei video in sovrimpressione
            if c.get("mute") or not os.path.exists(c.get("file", "")):
                continue
            idx = len(inputs) + 1
            inputs.append(c["file"])
            lab = f"s{idx}"
            ln = max(0.05, c["dur"])
            off = c.get("offset", 0.0)
            sc_ = EASE.step_cmds(c, "vol", ln, c.get("vol", 100), tv / 100)
            if sc_:   # volume con i keyframe: comandi fitti nel tempo della clip
                write_cmds(os.path.join(work, f"vol_{lab}.cmd"), sc_)
                vol = f"asendcmd=f=vol_{lab}.cmd,volume={sc_[0][1]}:eval=frame"
            else:
                vol = f"volume={c.get('vol', 100) / 100 * tv:.3f}"
            ch = (f"[{idx}:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
                  f"atrim={_num(off)}:{_num(off + ln)},asetpts=PTS-STARTPTS,{vol}")
            if c.get("fin"):
                ch += f",afade=t=in:d={min(0.5, ln / 2):.3f}"
            if c.get("fout"):
                ch += f",afade=t=out:st={max(0, ln - 0.5):.3f}:d={min(0.5, ln / 2):.3f}"
            ch += f",adelay=delays={int(round(c['a'] * 1000))}:all=1[{lab}]"
            lines.append(ch)
            (duck_labels if (c.get("duck") and S.get("duck")) else plain_labels).append(f"[{lab}]")

    mix_in = []
    if duck_labels:
        if len(duck_labels) > 1:
            lines.append("".join(duck_labels) + f"amix=inputs={len(duck_labels)}:duration=longest:normalize=0[duckbus]")
        else:
            lines.append(duck_labels[0] + "anull[duckbus]")
        lines.append("[live]asplit=2[live1][sc]")
        lines.append("[duckbus][sc]sidechaincompress=threshold=0.02:ratio=8:attack=20:release=600[ducked]")
        mix_in += ["[live1]", "[ducked]"]
    else:
        mix_in.append("[live]")
    mix_in += plain_labels
    if bleeps:
        bc = []
        for a, b in _merge(bleeps):
            bc += [(a, "0.18"), (b, "0")]
        write_cmds(os.path.join(work, "bleep.cmd"), bc)
        lines.append(f"sine=frequency=1000:sample_rate=48000:duration={_num(dur)},"
                     f"aformat=sample_fmts=fltp:channel_layouts=stereo,asendcmd=f=bleep.cmd,volume=0:eval=frame[bleep]")
        mix_in.append("[bleep]")
    if len(mix_in) > 1:
        lines.append("".join(mix_in) + f"amix=inputs={len(mix_in)}:duration=first:dropout_transition=0:normalize=0[mix0]")
    else:
        lines.append(mix_in[0] + "anull[mix0]")
    last = "[mix0]"
    if S.get("norm"):
        lines.append(f"{last}loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[mixn]")
        last = "[mixn]"
    # tutta la timeline mixata: i pezzi da tenere si tagliano dopo, a gruppi (vedi render_audio)
    lines.append(f"{last}anull[aout]")
    return inputs, ";\n".join(lines)


def render_audio(proj, keep_frames, fps, dur, work, abr, procs, check, src):
    """Audio del video finale in due passi, senza tenere in memoria tutta la live:
    1) mix di tutta la timeline (live, suoni, bip, volume uguale) in un file FLAC;
    2) i pezzi da tenere letti da quel file a gruppi (velocita' e micro dissolvenze), poi uniti.
    Prima si faceva tutto in un colpo: con live lunghe e tanti tagli la memoria esplodeva e l'export restava fermo."""
    extra_inputs, graph = build_audio_graph(proj, keep_frames, fps, dur, work)
    gpath = os.path.join(work, "audio_graph.txt")
    with open(gpath, "w", encoding="utf-8") as f:
        f.write(graph)
    mix = os.path.join(work, "mix.flac")

    def go(cmd, what):
        log_path = os.path.join(work, "audio_err.txt")
        with open(log_path, "wb") as errf:
            p = popen(cmd, stderr=errf, cwd=work)
            procs.append(p)
            while p.poll() is None:
                check()
                time.sleep(0.2)
            procs.remove(p)
        if p.returncode != 0:
            with open(log_path, "rb") as f:
                raise RuntimeError(what + f.read().decode(errors="ignore")[-600:])

    cmd = [ffmpeg_bin(), "-v", "error", "-y", "-i", src]
    for fpath in extra_inputs:
        cmd += ["-i", fpath]
    cmd += filter_script_args(gpath) + ["-map", "[aout]", "-c:a", "flac", "-ar", "48000", mix]
    go(cmd, "Errore audio: ")
    # pezzi da tenere, a gruppi: ogni pezzo e' un input a se' (niente code di audio in memoria)
    G = 24
    parts = []
    for gi in range(0, len(keep_frames), G):
        group = keep_frames[gi:gi + G]
        cmd = [ffmpeg_bin(), "-v", "error", "-y"]
        lines, cat = [], []
        for i, (fa, fb, *rest) in enumerate(group):
            sp = rest[0] if rest else 1.0
            a, b = fa / fps, fb / fps
            d = (b - a) / sp
            fd = min(0.01, d / 3)
            cmd += ["-ss", f"{a:.6f}", "-t", f"{b - a + 0.05:.6f}", "-i", mix]
            lines.append(f"[{i}:a]atrim=0:{b - a:.6f},asetpts=PTS-STARTPTS,{atempo_chain(sp)}"
                         f"apad=whole_dur={d:.6f},atrim=0:{d:.6f},"
                         f"afade=t=in:d={fd:.4f},afade=t=out:st={max(0, d - fd):.5f}:d={fd:.4f}[c{i}]")
            cat.append(f"[c{i}]")
        lines.append("".join(cat) + f"concat=n={len(cat)}:v=0:a=1[g]")
        gp = os.path.join(work, f"ag{gi // G:04d}.txt")
        with open(gp, "w", encoding="utf-8") as f:
            f.write(";\n".join(lines))
        out = os.path.join(work, f"ag{gi // G:04d}.wav")
        cmd += filter_script_args(gp) + ["-map", "[g]", "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", out]
        go(cmd, "Errore audio: ")
        parts.append(out)
    lst = os.path.join(work, "audio_parts.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p_ in parts:
            f.write(f"file '{os.path.basename(p_)}'\n")
    audio_out = os.path.join(work, "audio.m4a")
    go([ffmpeg_bin(), "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "audio_parts.txt",
        "-c:a", "aac", "-b:a", f"{int(abr or 192)}k", audio_out], "Errore audio: ")
    try:
        os.remove(mix)
        for p_ in parts:
            os.remove(p_)
    except OSError:
        pass
    return audio_out


def atempo_chain(sp):
    """Cambio di velocita' dell'audio senza cambiare il tono (atempo va da 0.5 a 2 per passaggio)."""
    if abs(sp - 1) < 1e-6:
        return ""
    parts = []
    while sp > 2.0 + 1e-9:
        parts.append(2.0)
        sp /= 2.0
    while sp < 0.5 - 1e-9:
        parts.append(0.5)
        sp /= 0.5
    parts.append(sp)
    return "".join(f"atempo={x:.6f}," for x in parts)


# ------------------------------------------------------------------ video
def plan_pieces(keep_frames, zooms, fps):
    """Divide i segmenti da tenere in pezzi 'plain' e 'zoom' (in fotogrammi) con la loro velocita'."""
    zr = sorted((int(math.floor(z["a"] * fps)), int(math.ceil(z["b"] * fps))) for z in zooms)
    pieces = []
    for fa, fb, *rest in keep_frames:
        sp = rest[0] if rest else 1.0
        cur = fa
        for za, zb in zr:
            if zb <= cur or za >= fb:
                continue
            s, e = max(za, cur), min(zb, fb)
            if s > cur:
                pieces.append(("plain", cur, s, sp))
            pieces.append(("zoom", s, e, sp))
            cur = e
        if cur < fb:
            pieces.append(("plain", cur, fb, sp))
    # unisci pezzi plain minuscoli ai vicini zoom (evita file da 1 fotogramma)
    out = []
    for kind, a, b, sp in pieces:
        if b <= a:
            continue
        if out and out[-1][2] == a and out[-1][3] == sp and (kind == out[-1][0] or (b - a) < 3):
            k0 = "zoom" if "zoom" in (out[-1][0], kind) else "plain"
            out[-1] = (k0, out[-1][1], b, sp)
        else:
            out.append((kind, a, b, sp))
    return out


# ------------------------------------------------------------------ livelli (immagini, sottotitoli)
def has_libass():
    try:
        out = run([ffmpeg_bin(), "-hide_banner", "-filters"], capture_output=True).stdout.decode(errors="ignore")
        return " subtitles " in out
    except Exception:
        return False


def layer_items(proj, sub_chunks):
    """Livelli sopra il video, dal basso verso l'alto: (sotto lo zoom, sopra lo zoom).
    Quello che sta sotto lo zoom viene ingrandito insieme al video."""
    order = [x for x in P.norm_layers(proj) if x != "video"][::-1]
    tracks = {"ov:" + t["id"]: t for t in proj.get("tracks", []) if t.get("type") == "overlay"}
    below, above = [], []
    side = below
    for k in order:
        if k == "zoom":
            side = above
            continue
        if k == "subs":
            if sub_chunks:
                side.append(("subs", sub_chunks))
            continue
        if k == "fx" or k.startswith("fx:"):
            tid = "fx" if k == "fx" else k[3:]
            fxs = [f for f in P.all_filters(proj) if f.get("b", 0) > f.get("a", 0) and not f.get("off")
                   and (f.get("track") or "fx") == tid]
            if fxs:
                side.append(("fx", fxs))
            continue
        t = tracks.get(k)
        if not t or t.get("hidden"):
            continue
        for c in t.get("clips", []):
            if c.get("file") and os.path.exists(c["file"]) and c.get("dur", 0) > 0:
                side.append(("img", c))
    return below, above



def ov_video_kf_source(it, Wt, Ht, fps, work, cache):
    """Video sovrapposto con keyframe: i suoi fotogrammi (gia' scontornati se serve) vengono spostati,
    ingranditi e sfumati qui con precisione sotto il pixel, dentro il riquadro che li contiene tutti.
    Ritorna (video con trasparenza, x, y del riquadro). Preparato una volta per clip."""
    key = ("ovk", it.get("id"), Wt, Ht, json.dumps(it.get("kf"), sort_keys=True), json.dumps(it.get("pos"), sort_keys=True))
    if key in cache:
        return cache[key]
    dur = float(it["dur"])
    ar = float(it.get("ar") or (9 / 16))
    n = max(1, int(math.ceil(dur * fps)))
    st = [OV.state_at(it, min(dur, k / fps)) for k in range(n)]
    x0 = max(0, int(math.floor(min(s_["x"] * Wt for s_ in st))) - 1)
    y0 = max(0, int(math.floor(min(s_["y"] * Ht for s_ in st))) - 1)
    x1 = min(Wt, int(math.ceil(max((s_["x"] + abs(s_["w"])) * Wt for s_ in st))) + 1)
    y1 = min(Ht, int(math.ceil(max(s_["y"] * Ht + abs(s_["w"]) * Wt * ar for s_ in st))) + 1)
    if x1 - x0 < 2 or y1 - y0 < 2:
        x0, y0, x1, y1 = 0, 0, 2, 2
    cw, ch = (x1 - x0 + 1) // 2 * 2, (y1 - y0 + 1) // 2 * 2
    mw = max(2, int(math.ceil(max(abs(s_["w"]) for s_ in st) * Wt / 2)) * 2)
    mh = max(2, int(math.ceil(mw * ar / 2)) * 2)
    off = it.get("offset") or 0.0
    ins = ["-ss", f"{off:.3f}", "-t", f"{dur + 0.1:.3f}", "-i", it["file"]]
    kk, cut = OV.key_of(it), OV.ai_cut(it)
    if kk:
        g = f"[0:v]fps={fps:.6f},scale={mw}:{mh}," + OV.key_ffmpeg(kk) + ",format=bgra[o]"
    elif cut:
        ins += ["-ss", f"{max(0.0, off - float(cut.get('off') or 0)):.3f}", "-t", f"{dur + 0.1:.3f}", "-i", cut["mask"]]
        g = (f"[1:v]fps={fps:.6f},scale={mw}:{mh},format=gray,setpts=PTS-STARTPTS[km];"
             f"[0:v]fps={fps:.6f},scale={mw}:{mh},format=rgba,setpts=PTS-STARTPTS[kv];[kv][km]alphamerge,format=bgra[o]")
    else:
        g = f"[0:v]fps={fps:.6f},scale={mw}:{mh},format=bgra[o]"
    out = os.path.join(work, "ovk_%s_%d.mkv" % (re.sub(r"[^A-Za-z0-9_-]", "", str(it.get("id")))[:40] or "v", Ht))
    dec = subprocess.Popen([ffmpeg_bin(), "-nostdin", "-v", "error", *ins, "-filter_complex", g, "-map", "[o]",
                            "-frames:v", str(n), "-f", "rawvideo", "-pix_fmt", "bgra", "-"],
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
    enc = subprocess.Popen([ffmpeg_bin(), "-nostdin", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgra",
                            "-s", f"{cw}x{ch}", "-r", f"{fps:.6f}", "-i", "-", "-c:v", "ffv1", "-pix_fmt", "bgra", out],
                           stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
    fsz = mw * mh * 4
    last = np.zeros((mh, mw, 4), np.uint8)
    try:
        for k in range(n):
            buf = dec.stdout.read(fsz)
            if len(buf) == fsz:
                last = np.frombuffer(buf, np.uint8).reshape(mh, mw, 4)
            s_ = st[k]
            sc = abs(s_["w"]) * Wt / mw
            M = np.float32([[sc, 0, s_["x"] * Wt - x0], [0, sc, s_["y"] * Ht - y0]])
            fr = cv2.warpAffine(last, M, (cw, ch), flags=cv2.INTER_LINEAR if sc > 0.98 else cv2.INTER_AREA,
                                borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
            o_ = max(0.0, min(1.0, s_["op"] / 100))
            if o_ < 0.999:
                fr[:, :, 3] = (fr[:, :, 3].astype(np.float32) * o_).astype(np.uint8)
            enc.stdin.write(np.ascontiguousarray(fr).tobytes())
    finally:
        try:
            enc.stdin.close()
        except OSError:
            pass
        try:
            dec.stdout.close()
            dec.kill()
        except Exception:
            pass
    if enc.wait() != 0:
        raise RuntimeError("Non riesco a preparare il video sovrapposto: " + enc.stderr.read().decode(errors="ignore")[-300:])
    cache[key] = (out, x0, y0)
    return cache[key]

def layer_graph(items, t0, t1, Wt, Ht, first_input, fonts, fps=30.0, work=".", cache=None, cur0="0:v"):
    """Filtri ffmpeg che disegnano i livelli su un pezzo che inizia a t0 (tempo del VOD).
    Ritorna (argomenti degli input da aggiungere, righe del grafo, etichetta finale)."""
    inputs, lines, cur, n = [], [], cur0, 0
    cache = {} if cache is None else cache
    for kind, it in items:
        if kind == "fx":
            # filtri: agiscono su tutto quello che sta sotto (i pezzi sono gia' divisi ai loro bordi)
            tm = (t0 + t1) / 2
            active = [f for f in it if f["a"] <= tm < f["b"]]
            if active:
                fi, fl, cur = FX.graph(active, Wt, Ht, first_input + len(inputs), work, fps, cache, cur, pre=f"x{n}_")
                n += 1
                inputs += fi
                lines += fl
            continue
        if kind == "subs":
            if not any(ch[0] < t1 and ch[1] > t0 for ch in it):
                continue
            fd = ":fontsdir=fonts" if fonts else ""
            lines.append(f"[{cur}]setpts=PTS+{t0:.6f}/TB,subtitles=subs.ass{fd},setpts=PTS-{t0:.6f}/TB[l{n}]")
            cur = f"l{n}"
            n += 1
            continue
        if not (it["a"] < t1 and it["a"] + it["dur"] > t0):
            continue
        if it.get("kind") == "video":
            # video in sovrimpressione: posizione, dimensione e trasparenza (niente 3D/keyframe)
            a, b = it["a"], it["a"] + it["dur"]
            st = max(a, t0)
            ss = (it.get("offset") or 0.0) + (st - a)
            pos = it.get("pos") or {"x": 0, "y": 0, "w": 1}
            ar = float(it.get("ar") or (9 / 16))
            pw = max(2, int(round(pos["w"] * Wt / 2)) * 2)
            ph = max(2, int(round(pos["w"] * Wt * ar / 2)) * 2)
            op = max(0.0, min(1.0, (it.get("opacity", 100)) / 100))
            idx = first_input + len(inputs)
            inputs.append(["-ss", f"{ss:.3f}", "-t", f"{max(0.05, b - st):.3f}", "-i", it["file"]])
            chain = f"[{idx}:v]fps={fps:.6f},scale={pw}:{ph},format=rgba"
            kk = OV.key_of(it)
            cut = OV.ai_cut(it)
            if kk:   # green screen: il colore dello sfondo diventa trasparente
                chain = f"[{idx}:v]fps={fps:.6f},scale={pw}:{ph}," + OV.key_ffmpeg(kk)
            elif cut:   # sfondo rimosso con l'AI: la maschera della persona diventa la trasparenza
                midx = first_input + len(inputs)
                inputs.append(["-ss", f"{max(0.0, ss - float(cut.get('off') or 0)):.3f}", "-t", f"{max(0.05, b - st):.3f}", "-i", cut["mask"]])
                lines.append(f"[{midx}:v]fps={fps:.6f},scale={pw}:{ph},format=gray,setpts=PTS-STARTPTS[km{n}]")
                lines.append(f"[{idx}:v]fps={fps:.6f},scale={pw}:{ph},format=rgba,setpts=PTS-STARTPTS[kv{n}]")
                lines.append(f"[kv{n}][km{n}]alphamerge[ka{n}]")
                chain = f"[ka{n}]format=rgba"
            if it.get("kf"):
                # keyframe (posizione, dimensione, trasparenza): fotogrammi gia' pronti, preparati una volta per clip
                path, bx, by = ov_video_kf_source(it, Wt, Ht, fps, work, cache)
                ucut = bool(cut) and not kk
                idx = first_input + len(inputs) - (2 if ucut else 1)
                del inputs[len(inputs) - (2 if ucut else 1):]
                if ucut:
                    del lines[-3:]
                k0 = max(0, int(math.floor((t0 - a) * fps)))
                inputs.append(["-ss", f"{k0 / fps:.6f}", "-i", path])
                lines.append(f"[{idx}:v]format=rgba,setpts=PTS-STARTPTS+{(a + k0 / fps - t0):.6f}/TB[i{n}]")
                lines.append(f"[{cur}][i{n}]overlay=x={bx}:y={by}:eof_action=pass:"
                             f"enable='between(t,{st - t0:.4f},{b - t0 - 0.0005:.4f})'[l{n}]")
            else:
                if op < 0.999:
                    chain += f",colorchannelmixer=aa={op:.3f}"
                ox, oy = int(round(pos['x'] * Wt)), int(round(pos['y'] * Ht))
                lines.append(chain + f",setpts=PTS-STARTPTS+{(st - t0):.6f}/TB[i{n}]")
                lines.append(f"[{cur}][i{n}]overlay=x={ox}:y={oy}:eof_action=pass:"
                             f"enable='between(t,{st - t0:.4f},{b - t0 - 0.0005:.4f})'[l{n}]")
            cur = f"l{n}"
            n += 1
            continue
        # immagine gia' trasformata (posizione, 3D, keyframe) a fotogramma intero
        for typ, path, a, b in OV.sources(it, Wt, Ht, fps, work, cache):
            if not (a < t1 and b > t0):
                continue
            idx = first_input + len(inputs)
            if typ == "png":
                inputs.append(["-i", path])
                lines.append(f"[{idx}:v]format=rgba[i{n}]")
                eof = "repeat"
            elif typ == "vid":
                # pezzo animato gia' pronto come video: si parte dal fotogramma giusto
                k0 = max(0, int(math.floor((t0 - a) * fps)))
                inputs.append(["-ss", f"{k0 / fps:.6f}", "-i", path])
                lines.append(f"[{idx}:v]format=rgba,setpts=PTS-STARTPTS+{(a + k0 / fps - t0):.6f}/TB[i{n}]")
                # "repeat": l'ultimo fotogramma resta fino alla fine della clip (con "pass" tra l'ultimo fotogramma e
                # la fine poteva passare un fotogramma nero al cambio d'immagine); la fine la decide enable
                eof = "repeat"
            else:
                k0 = max(0, int(math.floor((t0 - a) * fps)))
                inputs.append(["-framerate", f"{fps:.6f}", "-start_number", str(k0), "-i", path])
                lines.append(f"[{idx}:v]format=rgba,setpts=PTS+{(a + k0 / fps - t0):.6f}/TB[i{n}]")
                eof = "repeat"
            lines.append(f"[{cur}][i{n}]overlay=x=0:y=0:eof_action={eof}:"
                         f"enable='between(t,{a - t0:.4f},{b - t0 - 0.0005:.4f})'[l{n}]")
            cur = f"l{n}"
            n += 1
    return inputs, lines, cur


# sul Mac gli stessi font hanno nomi diversi (e stanno in piu' cartelle)
MAC_FONT_FILES = {
    "Arial": ("Arial.ttf", "Arial Bold.ttf"), "Verdana": ("Verdana.ttf", "Verdana Bold.ttf"),
    "Georgia": ("Georgia.ttf", "Georgia Bold.ttf"), "Trebuchet MS": ("Trebuchet MS.ttf", "Trebuchet MS Bold.ttf"),
    "Impact": ("Impact.ttf",), "Segoe UI": ("Arial.ttf", "Arial Bold.ttf"),
    "Comic Sans MS": ("Comic Sans MS.ttf", "Comic Sans MS Bold.ttf"), "Tahoma": ("Tahoma.ttf", "Tahoma Bold.ttf"),
}
MAC_FONT_DIRS = ("/System/Library/Fonts/Supplemental", "/Library/Fonts", os.path.expanduser("~/Library/Fonts"), "/System/Library/Fonts")


def copy_fonts(work, font=None):
    """Font del sistema accanto ai sottotitoli: libass li trova sempre."""
    if sys.platform == "darwin":
        table, dirs = MAC_FONT_FILES, MAC_FONT_DIRS
    else:
        table, dirs = FONT_FILES, (os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),)
    names = list(table["Arial"]) + list(table.get(font or "", ()))
    found = []
    try:   # font inclusi nell'app o aggiunti dall'utente
        from .fonts import files_for
        found += [f for f in files_for(font) if os.path.isfile(f)]
    except Exception:
        pass
    for n in dict.fromkeys(names):
        for d in dirs:
            if os.path.exists(os.path.join(d, n)):
                found.append(os.path.join(d, n))
                break
    if not found:
        return False
    os.makedirs(os.path.join(work, "fonts"), exist_ok=True)
    for f in found:
        shutil.copy(f, os.path.join(work, "fonts", os.path.basename(f)))
    return True


def render(proj, progress=None, cancel=None, log=print):
    src = proj["source"]
    if not os.path.exists(src):
        raise RuntimeError("Il file del VOD non si trova piu': " + src)
    fps_str, fps = fps_string(src)
    SW, SH = proj["width"], proj["height"]
    vert = VT.is_vertical(proj)
    OW, OH = VT.out_size(proj, proj["settings"].get("quality")) if vert else out_size(proj)
    vset = VT.settings(proj) if vert else None
    gpu = nvenc_ok()
    E = export_opts(proj)
    # frequenza fotogrammi: mai sopra quella del VOD
    out_fps_str, out_fps = fps_str, fps
    if str(E.get("fps")) not in ("source", "", "None"):
        try:
            f = float(E["fps"])
            if f < fps - 0.5:
                out_fps_str, out_fps = str(int(f)) if f == int(f) else f"{f:.3f}", f
        except (TypeError, ValueError):
            pass
    enc = export_encoder_args(gpu, E.get("codec"), video_bitrate(E, OW, OH, out_fps))
    with_audio = bool(E.get("audio", True))
    log("Encoder: " + (gpu_name() if gpu else "CPU"))
    try:
        log("Sorgente: " + source_info(src) + f" · uso {fps_str}")
    except Exception:
        pass
    live_src = seekable_source(src, log, progress=(lambda x: progress(0.0, f"Preparo il video della live ({int(x * 100)}%)")) if progress else None,
                               check=(lambda: (_ for _ in ()).throw(Cancelled()) if cancel and cancel() else None))
    cam = (proj.get("webcam") or {}).get("box")
    # verticale: la webcam segue il viso (se attivo e gia' analizzato)
    fdata = FACE.load(FACE.path_for(proj.get("id") or "")) if vert and cam and proj.get("faceOn") else None
    if fdata and (fdata.get("cam") != list(cam) or not fdata.get("pts")):
        fdata = None
    # zoom sulla webcam (serve la webcam) + zoom personalizzati (inquadratura scelta a mano)
    zooms = [z for z in proj.get("zooms", []) if z.get("on", True)
             and ((z.get("kind") == "custom" and z.get("rect")) or cam)]
    keep = P.keep_segments(proj)
    if not keep:
        raise RuntimeError("Hai tagliato tutto il video: non resta niente da esportare.")
    P.ensure_segs(proj)
    keep_frames = []
    for a, b, sp in P.split_by_speed(proj, keep):
        fa, fb = int(round(a * fps)), int(round(b * fps))
        if fb - fa >= 2:
            keep_frames.append((fa, fb, sp))
    total_frames = sum(k[1] - k[0] for k in keep_frames)
    work = tempdir("export_")
    procs = []
    S = proj["settings"]
    has_tr = bool(proj.get("transcript", {}).get("segments"))
    src_chunks = []
    if has_tr and S.get("showSubs", True):
        if has_libass():
            src_chunks = subtitle_chunks(proj, lambda t: t)  # tempo del VOD: i pezzi partono da li'
            # in verticale i sottotitoli si disegnano sullo schermo verticale
            write_ass(src_chunks, os.path.join(work, "subs.ass"), OW if vert else SW, OH if vert else SH, sub_style(proj))
        else:
            log("Questo ffmpeg non sa disegnare i sottotitoli: esporto senza")
    fonts = copy_fonts(work, sub_style(proj).get("font")) if src_chunks else False
    below, above = layer_items(proj, src_chunks)
    if vert:
        # in verticale: i filtri lavorano sulla live, tutto il resto (testi, immagini, sottotitoli) sullo schermo verticale
        allk = below + above
        below = [x for x in allk if x[0] == "fx"]
        above = [x for x in allk if x[0] != "fx"]
    ov_cache = {}

    def check():
        if cancel and cancel():
            for p in procs:
                try:
                    p.kill()
                except Exception:
                    pass
            raise Cancelled()

    pre = {"k": 0.0}   # parte della barra gia' usata per preparare le immagini animate

    def prog(x, msg):
        if progress:
            progress(pre["k"] + (1 - pre["k"]) * x if msg != "_pre" else x, msg if msg != "_pre" else "Preparo le immagini animate")

    try:
        # ---------------- audio (in parallelo al video)
        dur = proj["duration"]
        audio_state = {"err": None, "done": not with_audio}

        def audio_job():
            try:
                render_audio(proj, keep_frames, fps, dur, work, E.get("abr"), procs, check, live_src)
            except Cancelled:
                pass
            except Exception as e:
                audio_state["err"] = e
            finally:
                audio_state["done"] = True
        if with_audio:
            threading.Thread(target=audio_job, daemon=True).start()

        # ---------------- immagini animate: preparate prima, con la barra che avanza
        ov_jobs = [(it, OW, OH) for k, it in above if k == "img" and it.get("kind") != "video"] + \
                  [(it, SW, SH) for k, it in below if k == "img" and it.get("kind") != "video"]
        ov_jobs = [(it, w_, h_) for it, w_, h_ in ov_jobs if OV.moving_spans(it)]
        tot_mv = sum(OV.moving_frames(it, fps) for it, _, _ in ov_jobs)
        if tot_mv > fps * 3:
            share = min(0.5, 0.1 + tot_mv / (tot_mv + total_frames * 1.5))
            done_mv = 0
            for it, w_, h_ in ov_jobs:
                check()
                nf = OV.moving_frames(it, fps)
                OV.sources(it, w_, h_, fps, work, ov_cache,
                           progress=lambda q, d0=done_mv, nf=nf: (check(), prog(share * (d0 + q * nf) / tot_mv, "_pre")))
                done_mv += nf
                prog(share * done_mv / tot_mv, "_pre")
            pre["k"] = share

        # ---------------- video a pezzi
        pieces = plan_pieces(keep_frames, zooms, fps)
        # filtri: i pezzi si dividono ai loro bordi, cosi' in ogni pezzo i filtri attivi sono sempre gli stessi
        fxs = [f for f in P.all_filters(proj) if f.get("b", 0) > f.get("a", 0) and not f.get("off")]
        media = P.pieces(proj)
        cuts_f = sorted({int(round(x * fps)) for f in fxs for x in (f["a"], f["b"])}
                        | {int(round(m["t0"] * fps)) for m in media[1:]}
                        # verticale: ogni clip puo' avere la sua impaginazione
                        | ({int(round(x * fps)) for c in proj.get("segs") or [] if c.get("vlay") for x in (c["a"], c["b"])} if vert else set())
                        # orizzontale: ogni clip puo' essere spostata/ingrandita a mano
                        | ({int(round(x * fps)) for c in proj.get("segs") or [] if c.get("tf") or tf_has_kf(c) for x in (c["a"], c["b"])} if not vert else set())
                        # sfondo tolto su una clip della traccia principale
                        | ({int(round(x * fps)) for c in proj.get("segs") or [] if (c.get("key") or {}).get("on") for x in (c["a"], c["b"])} if not vert else set()))
        if cuts_f:
            split = []
            for kind, fa, fb, sp in pieces:
                pts = [fa] + [c for c in cuts_f if fa < c < fb] + [fb]
                split += [(kind, a, b, sp) for a, b in zip(pts, pts[1:]) if b > a]
            pieces = split
        if not vert:   # clip che si muove con i keyframe: fotogramma per fotogramma (come lo zoom)
            kfr = [(c["a"] * fps, c["b"] * fps) for c in proj.get("segs") or [] if tf_has_kf(c) and not c.get("gone")]
            if kfr:
                pieces = [("zoom" if any(a < fb and b > fa for a, b in kfr) else kind, fa, fb, sp) for kind, fa, fb, sp in pieces]
        fx_cache = {}
        R = {}
        # se l'encoder della scheda video si ferma (es. OBS lo sta gia' usando), si rifa' tutto con il processore
        for attempt in range(2):
            try:
                done = 0
                listfile = os.path.join(work, "pieces.txt")
                lf = open(listfile, "w", encoding="utf-8")
                common_out = ["-an", "-r", out_fps_str, *enc, "-video_track_timescale", "90000"]
                for i, (kind, fa, fb, sp) in enumerate(pieces):
                    check()
                    n = fb - fa
                    ppath = os.path.join(work, f"p{i:05d}.mp4")
                    ss = f"{fa / fps:.6f}"
                    t0, t1 = fa / fps, fb / fps
                    n_out = max(1, int(round(n / sp * out_fps / fps)))
                    spd = f"setpts=PTS/{sp:.6f}" if sp != 1 else ""   # velocita': si cambia alla fine, livelli compresi
                    # da quale file arriva questo pezzo (la live o un video inserito) e da che punto
                    m_ = P.piece_at(proj, (t0 + t1) / 2, media)
                    msrc = live_src if m_["live"] else m_["file"]
                    ss = f"{m_['off'] + (t0 - m_['t0']):.6f}"
                    if not os.path.exists(msrc):
                        raise RuntimeError("Il video inserito non si trova piu': " + msrc)
                    norm = None if m_["live"] else (
                        f"fps={fps:.6f},scale={SW}:{SH}:force_original_aspect_ratio=decrease,pad={SW}:{SH}:(ow-iw)/2:(oh-ih)/2:color=black,"
                        f"setsar=1,format=yuv420p,tpad=stop_mode=clone:stop_duration=2")
                    # sfondo tolto (tinta unita o AI) su questa clip: si toglie sul video originale, dietro resta il nero
                    kseg = None if vert else seg_at(proj, (t0 + t1) / 2)
                    kcut = None
                    kchain = None
                    if kseg and (kseg.get("key") or {}).get("on"):
                        src_a = float(ss)
                        kcut = OV.seg_ai_cut(kseg, proj.get("source") if m_["live"] else msrc, src_a, src_a + (t1 - t0))
                        if OV.key_of(kseg) or kcut:
                            kchain = OV.key_main_chain(kseg, fps)
                    if kchain:
                        norm = kchain if m_["live"] else (
                            f"fps={fps:.6f}," + kchain + f",scale={SW}:{SH}:force_original_aspect_ratio=decrease,pad={SW}:{SH}:(ow-iw)/2:(oh-ih)/2:color=black,"
                            f"setsar=1,format=yuv420p,tpad=stop_mode=clone:stop_duration=2")
                    mask_for = (lambda in_start, kcut=kcut: OV.mask_movie(kcut, in_start, fps)) if kcut else None
                    # clip spostata o ingrandita a mano (solo orizzontale; in verticale si spostano i pezzi)
                    tfseg = None if vert else seg_at(proj, (t0 + t1) / 2)
                    tfc = None if tf_has_kf(tfseg) else tf_chain(tfseg, SW, SH)
                    tfk = tfseg if tf_has_kf(tfseg) else None
                    # con lo zoom: prima si ingrandisce la webcam, poi la clip va al suo posto (come nell'anteprima)
                    if tfc and kind != "zoom":
                        norm = (norm + "," + tfc) if norm else tfc
                    cur0 = "nrm" if norm else "0:v"
                    face_here = bool(fdata) and m_["live"] and VT.seg_layout(proj, (t0 + t1) / 2, vset)["layout"] in ("split", "cam")
                    if vert and m_["live"] and (kind == "zoom" or face_here):
                        # verticale con zoom: la webcam si allarga a tutto schermo con l'effetto scelto (fotogramma per fotogramma)
                        imgs, glines, last = layer_graph(below, t0, t1, SW, SH, 1, fonts, fps, work, ov_cache, "0:v")
                        dargs = []
                        if glines:
                            gp = os.path.join(work, f"g{i:05d}_d.txt")
                            with open(gp, "w", encoding="utf-8") as f:
                                f.write(";\n".join(glines))
                            dargs = [a for im in imgs for a in im] + filter_script_args(gp) + ["-map", f"[{last}]"]
                        dec = FrameReader(lambda pr, ss=ss, msrc=msrc, dargs=dargs, n=n: [ffmpeg_bin(), "-nostdin", "-v", "error", *seek_args(ss, pr)[0], "-i", msrc, *seek_args(ss, pr)[1],
                                                 *dargs, *cfr_args(fps_str), "-frames:v", str(n), "-an", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                                          SW * SH * 3, work, log, f"pezzo {i}")
                        imgs, glines, last = layer_graph(above, t0, t1, OW, OH, 1, fonts, fps, work, ov_cache)
                        eargs = []
                        if glines:
                            if spd:
                                glines.append(f"[{last}]{spd}[spd]")
                                last = "spd"
                            gp = os.path.join(work, f"g{i:05d}_e.txt")
                            with open(gp, "w", encoding="utf-8") as f:
                                f.write(";\n".join(glines))
                            eargs = [a for im in imgs for a in im] + filter_script_args(gp) + ["-map", f"[{last}]"]
                        elif spd:
                            eargs = ["-vf", spd]
                        encp = popen([ffmpeg_bin(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                                      "-s", f"{OW}x{OH}", "-r", fps_str, "-i", "-", *eargs, "-frames:v", str(n_out), *common_out, ppath],
                                     stdin=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work)
                        procs += [dec, encp]
                        fsize = SW * SH * 3
                        written, ended, img = 0, False, None
                        for k in range(n):
                            check()
                            buf = dec.read()
                            if len(buf) < fsize:
                                break
                            frame = np.frombuffer(buf, np.uint8).reshape(SH, SW, 3)
                            t = (fa + k) / fps
                            lay = VT.seg_layout(proj, t, vset)
                            regs = VT.regions(lay["layout"], SW, SH, cam=cam, camH=lay["camH"], gameX=lay["gameX"], pad=lay.get("pad", 0), boxes=lay.get("boxes"))
                            if fdata:
                                regs = FACE.shift(regs, FACE.at(fdata, m_["off"] + t - m_["t0"]), cam, SW, SH)
                            for z in zooms:
                                if z["a"] <= t < z["b"]:
                                    pd = lay.get("pad", 0)
                                    bx = VT.zoom_boxes(zoom_at(z, t), SW, SH, cam, custom_rect, VT.V_ASPECT / (1 - 2 * pd))
                                    if bx:
                                        regs = VT.anim_regions(regs, bx[1], zoom_progress(t, VT.vzoom(z)), bx[0], pd)
                                    break
                            img = VT.compose(frame, regs, OW, OH)
                            try:
                                encp.stdin.write(img.tobytes())
                            except OSError:
                                if encp.wait() == 0:
                                    ended = True
                                    break
                                raise RuntimeError("Errore dell'encoder: " + encp.stderr.read().decode(errors="ignore")[-400:])
                            written += 1
                            if written % 15 == 0:
                                prog(0.85 * (done + written) / total_frames, "Creo il video (zoom)")
                        while not ended and written < n and img is not None:
                            try:
                                encp.stdin.write(img.tobytes())
                            except OSError:
                                break
                            written += 1
                        dec.stdout.close()
                        dec.kill()
                        try:
                            encp.stdin.close()
                        except OSError:
                            pass
                        encp.wait()
                        procs.remove(dec)
                        procs.remove(encp)
                        if encp.returncode != 0:
                            raise RuntimeError("Errore dell'encoder: " + encp.stderr.read().decode(errors="ignore")[-400:])
                    elif vert:
                        # schermo verticale: pezzi della live (o del video inserito) messi uno sopra l'altro
                        glines = []
                        if m_["live"]:
                            imgs_b, gl_b, last = layer_graph(below, t0, t1, SW, SH, 1, fonts, fps, work, ov_cache, "0:v")
                            glines += gl_b
                            lay = VT.seg_layout(proj, (t0 + t1) / 2, vset)
                            regs = VT.regions(lay["layout"], SW, SH, cam=cam, camH=lay["camH"], gameX=lay["gameX"], pad=lay.get("pad", 0), boxes=lay.get("boxes"))
                        else:
                            imgs_b = []
                            iw, ih = int(m_["ins"].get("w") or 0), int(m_["ins"].get("h") or 0)
                            if not iw or not ih:
                                pi = probe(msrc)
                                iw, ih = pi.get("width") or SW, pi.get("height") or SH
                            glines.append(f"[0:v]fps={fps:.6f},setsar=1,tpad=stop_mode=clone:stop_duration=2[nrm]")
                            last = "nrm"
                            regs = VT.regions("fit", iw, ih, pad=vset.get("pad", 0))
                        glines += VT.graph(regs, OW, OH, last, "vcanvas")
                        imgs_a, gl_a, last = layer_graph(above, t0, t1, OW, OH, 1 + len(imgs_b), fonts, fps, work, ov_cache, "vcanvas")
                        glines += gl_a
                        glines.append(f"[{last}]" + (spd or "null") + "[vout]")
                        gp = os.path.join(work, f"g{i:05d}.txt")
                        with open(gp, "w", encoding="utf-8") as f:
                            f.write(";\n".join(glines))
                        vf = [a for im in imgs_b + imgs_a for a in im] + filter_script_args(gp) + ["-map", "[vout]"]
                        cmd = [ffmpeg_bin(), "-v", "error", "-y", "-ss", ss, "-i", msrc, *vf, "-frames:v", str(n_out),
                               *common_out, "-progress", "pipe:1", "-nostats", ppath]
                        p = popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work)
                        procs.append(p)
                        for line in p.stdout:
                            check()
                            m = re.match(rb"frame=(\d+)", line)
                            if m:
                                prog(0.85 * (done + int(m.group(1)) * sp * fps / out_fps) / total_frames, "Creo il video")
                        p.wait()
                        procs.remove(p)
                        if p.returncode != 0:
                            raise RuntimeError("Errore ffmpeg: " + p.stderr.read().decode(errors="ignore")[-400:])
                    elif kind == "plain":
                        imgs, glines, last = layer_graph(below + above, t0, t1, SW, SH, 1, fonts, fps, work, ov_cache, cur0)
                        if norm:
                            glines.insert(0, f"[0:v]{norm}[nrm]".replace("{MASK}", mask_for(float(ss)) if mask_for else "nullsrc"))
                        post = ",".join(x for x in (spd, f"scale={OW}:{OH}:flags=lanczos" if (OW, OH) != (SW, SH) else "") if x)
                        if glines:
                            glines.append(f"[{last}]" + (post or "null") + "[vout]")
                            gp = os.path.join(work, f"g{i:05d}.txt")
                            with open(gp, "w", encoding="utf-8") as f:
                                f.write(";\n".join(glines))
                            vf = [a for im in imgs for a in im] + filter_script_args(gp) + ["-map", "[vout]"]
                        else:
                            vf = ["-vf", post] if post else []
                        cmd = [ffmpeg_bin(), "-v", "error", "-y", "-ss", ss, "-i", msrc, *vf, "-frames:v", str(n_out),
                               *common_out, "-progress", "pipe:1", "-nostats", ppath]
                        p = popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work)
                        procs.append(p)
                        for line in p.stdout:
                            check()
                            m = re.match(rb"frame=(\d+)", line)
                            if m:
                                prog(0.85 * (done + int(m.group(1)) * sp * fps / out_fps) / total_frames, "Creo il video")
                        p.wait()
                        procs.remove(p)
                        if p.returncode != 0:
                            raise RuntimeError("Errore ffmpeg: " + p.stderr.read().decode(errors="ignore")[-400:])
                    else:
                        # livelli sotto lo zoom: disegnati prima, cosi' vengono ingranditi col video
                        imgs, glines, last = layer_graph(below, t0, t1, SW, SH, 1, fonts, fps, work, ov_cache, cur0)
                        if norm:
                            glines.insert(0, f"[0:v]{norm}[nrm]")
                        dargs = []
                        dargs_p = []
                        if glines:
                            # due versioni: ricerca veloce o precisa (la maschera AI deve partire dallo stesso punto del video)
                            for pr_, nm_ in ((False, ""), (True, "p")):
                                sa = seek_args(ss, pr_)[0]
                                in_start = float(sa[1]) if sa else 0.0
                                txt = ";\n".join(glines).replace("{MASK}", mask_for(in_start) if mask_for else "nullsrc")
                                gp = os.path.join(work, f"g{i:05d}_d{nm_}.txt")
                                with open(gp, "w", encoding="utf-8") as f:
                                    f.write(txt)
                                da = [a for im in imgs for a in im] + filter_script_args(gp) + ["-map", f"[{last}]"]
                                if pr_:
                                    dargs_p = da
                                else:
                                    dargs = da
                        dec = FrameReader(lambda pr, ss=ss, msrc=msrc, dargs=dargs, dargs_p=dargs_p, n=n: [ffmpeg_bin(), "-nostdin", "-v", "error", *seek_args(ss, pr)[0], "-i", msrc, *seek_args(ss, pr)[1],
                                                 *(dargs_p if pr else dargs), *cfr_args(fps_str), "-frames:v", str(n), "-an", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                                          SW * SH * 3, work, log, f"pezzo {i}")
                        # livelli sopra lo zoom: disegnati dopo, restano fermi
                        imgs, glines, last = layer_graph(above, t0, t1, OW, OH, 1, fonts, fps, work, ov_cache)
                        eargs = []
                        if glines:
                            if spd:
                                glines.append(f"[{last}]{spd}[spd]")
                                last = "spd"
                            gp = os.path.join(work, f"g{i:05d}_e.txt")
                            with open(gp, "w", encoding="utf-8") as f:
                                f.write(";\n".join(glines))
                            eargs = [a for im in imgs for a in im] + filter_script_args(gp) + ["-map", f"[{last}]"]
                        elif spd:
                            eargs = ["-vf", spd]
                        encp = popen([ffmpeg_bin(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                                      "-s", f"{OW}x{OH}", "-r", fps_str, "-i", "-", *eargs, "-frames:v", str(n_out), *common_out, ppath],
                                     stdin=subprocess.PIPE, stderr=subprocess.PIPE, cwd=work)
                        procs += [dec, encp]
                        fsize = SW * SH * 3
                        written = 0
                        ended = False
                        for k in range(n):
                            check()
                            buf = dec.read()
                            if len(buf) < fsize:
                                break
                            frame = np.frombuffer(buf, np.uint8).reshape(SH, SW, 3)
                            t = (fa + k) / fps
                            p_ = 0.0
                            zz = None
                            for z in zooms:
                                v = zoom_progress(t, z)
                                if v > p_:
                                    p_, zz = v, z
                            if p_ > 0.001:
                                if zz.get("kf") or zz.get("pk"):
                                    zz = zoom_at(zz, t)
                                if zz.get("kind") == "custom" and zz.get("rect"):
                                    key = tuple(round(v, 1) for v in zz["rect"])
                                    if key not in R:
                                        R[key] = custom_rect(SW, SH, zz["rect"])
                                else:
                                    key = (round(float(zz.get("level") or 2.8), 3),)
                                    if key not in R:
                                        R[key] = target_rect(SW, SH, cam, key[0])
                                rx, ry, rw, rh = rect_at(p_, SW, SH, R[key])
                                sx, sy = OW / rw, OH / rh
                                M = np.array([[sx, 0, -rx * sx], [0, sy, -ry * sy]], np.float32)
                                img = cv2.warpAffine(frame, M, (OW, OH), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
                                amt = 0.6 * min(1.0, p_)
                                blur = cv2.GaussianBlur(img, (0, 0), 1.2)
                                img = cv2.addWeighted(img, 1 + amt, blur, -amt, 0)
                            elif (OW, OH) != (SW, SH):
                                img = cv2.resize(frame, (OW, OH), interpolation=cv2.INTER_LANCZOS4)
                            else:
                                img = frame
                            if tfk:
                                tq = tf_at(tfk, t)
                                if abs(tq["s"] - 1) > 1e-4 or abs(tq["x"]) > 1e-4 or abs(tq["y"]) > 1e-4:
                                    img = tf_frame(img, tq)
                            elif tfc:
                                img = tf_frame(img, tfseg["tf"])
                            try:
                                encp.stdin.write(np.ascontiguousarray(img).tobytes())
                            except OSError:
                                # l'encoder si ferma da solo quando ha tutti i fotogrammi (succede con la velocita' > 1)
                                if encp.wait() == 0:
                                    ended = True
                                    break
                                raise RuntimeError("Errore dell'encoder: " + encp.stderr.read().decode(errors="ignore")[-400:])
                            written += 1
                            if written % 15 == 0:
                                prog(0.85 * (done + written) / total_frames, "Creo il video (zoom)")
                        # se il decoder ha dato meno fotogrammi del previsto, ripeti l'ultimo (durata esatta)
                        while not ended and written < n and written > 0:
                            try:
                                encp.stdin.write(np.ascontiguousarray(img).tobytes())
                            except OSError:
                                break
                            written += 1
                        dec.stdout.close()
                        dec.kill()
                        try:
                            encp.stdin.close()
                        except OSError:
                            pass
                        encp.wait()
                        procs.remove(dec)
                        procs.remove(encp)
                        if encp.returncode != 0:
                            raise RuntimeError("Errore dell'encoder: " + encp.stderr.read().decode(errors="ignore")[-400:])
                    done += n
                    lf.write(f"file '{os.path.basename(ppath)}'\n")
                lf.close()
                break
            except RuntimeError as err:
                if attempt == 0 and gpu:
                    log("Encoder GPU non riuscito, uso il processore: " + str(err)[-300:])
                    gpu = False
                    enc = export_encoder_args(False, E.get("codec"), video_bitrate(E, OW, OH, out_fps))
                    try:
                        lf.close()
                    except Exception:
                        pass
                    for fn in os.listdir(work):
                        if re.match(r"p\d{5}\.mp4$", fn):
                            try:
                                os.remove(os.path.join(work, fn))
                            except OSError:
                                pass
                    continue
                raise

        # ---------------- controllo dei pezzi (per capire eventuali scatti nei punti di taglio/zoom)
        try:
            bad = []
            for i, (kind, fa, fb, sp) in enumerate(pieces):
                want = max(1, int(round((fb - fa) / sp * out_fps / fps)))
                got = count_frames(os.path.join(work, f"p{i:05d}.mp4"))
                if got is not None and got != want:
                    bad.append(f"{i}:{kind}@{fa / fps:.2f}s {got}/{want}")
            log(f"Controllo pezzi: {len(pieces)} pezzi, {len(bad)} con fotogrammi diversi dal previsto" + (" · " + ", ".join(bad[:15]) if bad else ""))
        except Exception as e:
            log(f"Controllo pezzi non riuscito: {e}")

        # ---------------- unione
        check()
        prog(0.87, "Unisco i pezzi")
        video_only = os.path.join(work, "video.mp4")
        r = run([ffmpeg_bin(), "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "pieces.txt",
                 "-c", "copy", "video.mp4"], cwd=work, capture_output=True)
        if r.returncode != 0:
            raise RuntimeError("Errore nell'unire i pezzi: " + r.stderr.decode(errors="ignore")[-400:])

        prog(0.9, "Sistemo l'audio")
        while not audio_state["done"]:
            check()
            time.sleep(0.2)
        if audio_state["err"]:
            raise RuntimeError(str(audio_state["err"]))

        # ---------------- sottotitoli, capitoli, file finale
        mapper, total = P.make_time_mapper([(a / fps, b / fps, sp) for a, b, sp in keep_frames])
        out_dir = E.get("dir") if E.get("dir") and os.path.isdir(E.get("dir")) else EXPORTS_DIR
        if proj.get("folder"):   # cartella della home: tutti i video della cartella finiscono insieme
            import re as _re
            fd = _re.sub(r'[\\/:*?"<>|]+', "_", proj["folder"]).strip() or "Cartella"
            if os.path.basename(os.path.normpath(out_dir)) != fd:
                out_dir = os.path.join(out_dir, fd)
            os.makedirs(out_dir, exist_ok=True)
        ext = ".mov" if E.get("format") == "mov" else ".mp4"
        out_path = unique_path(out_dir, proj["name"], ext)
        base = os.path.splitext(out_path)[0]
        chunks = subtitle_chunks(proj, mapper) if has_tr else []
        extras = {}
        if chunks and S.get("srt"):
            write_srt(chunks, base + ".srt")
            extras["srt"] = base + ".srt"
        if S.get("chapters") and write_chapters(proj, mapper, total, base + " - capitoli.txt"):
            extras["chapters"] = base + " - capitoli.txt"

        check()
        prog(0.93, "Ultimi ritocchi")
        burned = bool(src_chunks)
        final = "final" + ext
        tag = ["-tag:v", "hvc1"] if E.get("codec") == "h265" else []
        if with_audio:
            cmd = [ffmpeg_bin(), "-v", "error", "-y", "-i", "video.mp4", "-i", "audio.m4a", "-map", "0:v", "-map", "1:a",
                   "-c", "copy", *tag, "-shortest", "-movflags", "+faststart", final]
        else:
            cmd = [ffmpeg_bin(), "-v", "error", "-y", "-i", "video.mp4", "-map", "0:v", "-c", "copy", *tag, "-movflags", "+faststart", final]
        r = run(cmd, cwd=work, capture_output=True)
        if r.returncode != 0:
            raise RuntimeError("Errore nel file finale: " + r.stderr.decode(errors="ignore")[-400:])
        try:
            log("Controllo del file finale: " + timing_report(os.path.join(work, final), out_fps))
        except Exception as e:
            log(f"Controllo del file finale non riuscito: {e}")
        shutil.move(os.path.join(work, final), out_path)
        prog(1.0, "Fatto")
        return {"path": out_path, "duration": total, "width": OW, "height": OH, "gpu": gpu, "fps": out_fps,
                "codec": E.get("codec"), "size": os.path.getsize(out_path), "subsBurned": burned, **extras}
    finally:
        for p in procs:
            try:
                p.kill()
            except Exception:
                pass
        shutil.rmtree(work, ignore_errors=True)
