"""Immagini sopra il video: posizione, scala, rotazione, inclinazione 3D, profondita', keyframe.

La stessa matematica sta in web/lib.js (imgStateAt / imgQuad): l'anteprima e il video
esportato devono coincidere. Coordinate come nel CSS: y verso il basso, z verso chi guarda.
"""
import math
import os

import cv2
import numpy as np

KEYS = ("x", "y", "w", "rot", "rx", "ry", "z", "op")
PERSP = 1.2  # distanza della "camera", in larghezze del fotogramma


def ease(u, kind):
    u = max(0.0, min(1.0, u))
    if kind == "linear":
        return u
    return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2


def base_state(c):
    p = c.get("pos") or {}
    return {"x": p.get("x", 0.35), "y": p.get("y", 0.35), "w": p.get("w", 0.3), "rot": c.get("rot", 0.0),
            "rx": c.get("rx", 0.0), "ry": c.get("ry", 0.0), "z": c.get("z", 0.0), "op": c.get("opacity", 100)}


def state_at(c, tr):
    """Stato dell'immagine a tr secondi dall'inizio della clip."""
    kf = sorted(c.get("kf") or [], key=lambda k: k["t"])
    if not kf:
        return base_state(c)
    b = base_state(c)
    full = [{**{k: f.get(k, b[k]) for k in KEYS}, "t": f["t"], "ease": f.get("ease", "smooth")} for f in kf]
    if tr <= full[0]["t"]:
        return {k: full[0][k] for k in KEYS}
    if tr >= full[-1]["t"]:
        return {k: full[-1][k] for k in KEYS}
    for a, bb in zip(full, full[1:]):
        if a["t"] <= tr < bb["t"]:
            u = ease((tr - a["t"]) / max(1e-6, bb["t"] - a["t"]), a["ease"])
            return {k: a[k] + (bb[k] - a[k]) * u for k in KEYS}
    return {k: full[-1][k] for k in KEYS}


def quad(s, Wt, Ht, ar):
    """Angoli (in pixel del fotogramma) dell'immagine trasformata: alto-sx, alto-dx, basso-dx, basso-sx."""
    bw = s["w"] * Wt
    bh = bw * ar
    cx, cy = s["x"] * Wt + bw / 2, s["y"] * Ht + bh / 2
    P = PERSP * Wt
    zt = s["z"] * Wt
    a, ax, ay = math.radians(s["rot"]), math.radians(s["rx"]), math.radians(s["ry"])
    out = []
    for px, py in ((-bw / 2, -bh / 2), (bw / 2, -bh / 2), (bw / 2, bh / 2), (-bw / 2, bh / 2)):
        # rotate(rot)
        x, y, z = px * math.cos(a) - py * math.sin(a), px * math.sin(a) + py * math.cos(a), 0.0
        # rotateY(ry)
        x, z = x * math.cos(ay) + z * math.sin(ay), -x * math.sin(ay) + z * math.cos(ay)
        # rotateX(rx)
        y, z = y * math.cos(ax) - z * math.sin(ax), y * math.sin(ax) + z * math.cos(ax)
        z += zt
        wdiv = max(0.05, 1 - z / P)
        out.append((cx + x / wdiv, cy + y / wdiv))
    return out


# ------------------------------------------------------------------ animazioni pronte (come web/lib.js)
def _out_cubic(p):
    return 1 - (1 - p) ** 3


def _out_back(p):
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2


def _out_bounce(p):
    n1, d1 = 7.5625, 2.75
    if p < 1 / d1:
        return n1 * p * p
    if p < 2 / d1:
        p -= 1.5 / d1
        return n1 * p * p + 0.75
    if p < 2.5 / d1:
        p -= 2.25 / d1
        return n1 * p * p + 0.9375
    p -= 2.625 / d1
    return n1 * p * p + 0.984375


def _scale(s, k, aspect, ar):
    hf = s["w"] * aspect * ar
    nw = s["w"] * k
    s["x"] += (s["w"] - nw) / 2
    s["y"] += (hf - nw * aspect * ar) / 2
    s["w"] = nw


def anim_edge(s, typ, p, aspect, ar):
    p = max(0.0, min(1.0, p))
    hf = s["w"] * aspect * ar
    e = _out_cubic(p)
    if typ == "fade":
        s["op"] *= p
    elif typ == "pop":
        _scale(s, max(0.01, 0.3 + 0.7 * _out_back(p)), aspect, ar)
        s["op"] *= min(1, p * 3)
    elif typ == "zoom":
        _scale(s, 1.5 - 0.5 * e, aspect, ar)
        s["op"] *= e
    elif typ == "slideL":
        s["x"] -= (s["x"] + s["w"] + 0.02) * (1 - e)
    elif typ == "slideR":
        s["x"] += (1 - s["x"] + 0.02) * (1 - e)
    elif typ == "slideU":
        s["y"] += (1 - s["y"] + 0.02) * (1 - e)
    elif typ == "drop":
        s["y"] -= (s["y"] + hf + 0.02) * (1 - _out_bounce(p))
    elif typ == "spin":
        s["rot"] -= 180 * (1 - e)
        _scale(s, max(0.01, e), aspect, ar)
    elif typ == "flip":
        s["ry"] += 90 * (1 - e)
        s["op"] *= min(1, p * 2)
    elif typ == "swing":
        s["rx"] -= 90 * (1 - e)
        s["op"] *= min(1, p * 2)
    elif typ == "slam":
        _scale(s, 1 + 1.4 * (1 - e), aspect, ar)
        s["op"] *= min(1, p * 2.5)
    elif typ == "rise":
        s["y"] += 0.06 * (1 - e)
        s["op"] *= e
    elif typ == "tilt":
        b = _out_back(p)
        s["rot"] -= 14 * (1 - b)
        _scale(s, max(0.01, 0.6 + 0.4 * b), aspect, ar)
        s["op"] *= min(1, p * 2.5)
    return s


def anim_loop(s, typ, tr, aspect, ar):
    tau = math.pi * 2
    u = min(1.0, tr / 0.8)
    r = u * u * (3 - 2 * u)
    if typ == "float":
        s["y"] += 0.011 * math.sin(tau * tr / 3.4) * r
        s["x"] += 0.004 * math.sin(tau * tr / 5.1 + 1.3) * r
        s["rot"] += 1.4 * math.sin(tau * tr / 4.3 + 0.7) * r
    elif typ == "pulse":
        _scale(s, 1 + 0.035 * (0.5 - 0.5 * math.cos(tau * tr / 2.6)), aspect, ar)
    elif typ == "card":
        s["rx"] += 7 * math.sin(tau * tr / 4.1) * r
        s["ry"] += 9 * math.sin(tau * tr / 5.3 + 0.9) * r
        s["z"] += 0.02 * math.sin(tau * tr / 3.7) * r
    elif typ == "wiggle":
        s["rot"] += 5 * math.sin(tau * tr / 0.9)
    elif typ == "sway":
        s["ry"] += 14 * math.sin(tau * tr / 3)
    elif typ == "shake":
        s["x"] += 0.004 * math.sin(tau * tr * 9.1)
        s["y"] += 0.004 * math.sin(tau * tr * 7.3)
    elif typ == "spinc":
        s["rot"] += 40 * (tr - (1 - math.exp(-1.5 * tr)) / 1.5)
    elif typ == "bounce":
        s["y"] -= 0.012 * abs(math.sin(tau * tr / 1.8)) * r
    elif typ == "beat":
        _scale(s, 1 + 0.05 * max(0.0, math.sin(tau * tr / 1.1)) ** 4, aspect, ar)
    return s


def anim_motion(s, typ, q, aspect, ar):
    """Movimento lento per tutta la durata (come animMotion in web/lib.js)."""
    q = max(0.0, min(1.0, q))
    e = 0.6 * q + 0.4 * q * q * (3 - 2 * q)
    K = 1.14
    k, dx, dy = K, 0.0, 0.0
    if typ == "zoomIn":
        k = 1 + (K - 1) * e
    elif typ == "zoomOut":
        k = K - (K - 1) * e
    hf = s["w"] * aspect * ar
    mx, my = (K - 1) / 2 * s["w"] * 0.9, (K - 1) / 2 * hf * 0.9
    if typ == "panL":
        dx = mx * (1 - 2 * e)
    elif typ == "panR":
        dx = -mx * (1 - 2 * e)
    elif typ == "panU":
        dy = my * (1 - 2 * e)
    elif typ == "panD":
        dy = -my * (1 - 2 * e)
    nw = s["w"] * k
    s["x"] += (s["w"] - nw) / 2 + dx
    s["y"] += (hf - nw * aspect * ar) / 2 + dy
    s["w"] = nw
    return s


def final_state(c, tr, aspect, ar):
    """Keyframe + animazioni pronte."""
    s = dict(state_at(c, tr))
    an = c.get("anim") or {}
    dur = c["dur"]
    if an.get("motion"):
        anim_motion(s, an["motion"], tr / dur if dur else 0.0, aspect, ar)
    if an.get("loop"):
        anim_loop(s, an["loop"], tr, aspect, ar)
    if an.get("in"):
        d = min(an.get("inDur") or 0.5, dur)
        if tr < d:
            anim_edge(s, an["in"], tr / d, aspect, ar)
    if an.get("out"):
        d = min(an.get("outDur") or 0.5, dur)
        if tr > dur - d:
            anim_edge(s, an["out"], (dur - tr) / d, aspect, ar)
    return s


def moving_spans(c):
    """Intervalli (tempo nella clip) in cui l'immagine si muove; fuori resta ferma."""
    dur = c["dur"]
    an = c.get("anim") or {}
    kf = sorted(f["t"] for f in (c.get("kf") or []))
    spans = []
    if len(kf) >= 2:
        spans.append((max(0.0, kf[0]), min(dur, kf[-1])))
    if an.get("loop") or an.get("motion"):
        spans.append((0.0, dur))
    if an.get("in"):
        spans.append((0.0, min(dur, an.get("inDur") or 0.5)))
    if an.get("out"):
        spans.append((max(0.0, dur - (an.get("outDur") or 0.5)), dur))
    spans.sort()
    merged = []
    for a, b in spans:
        if b <= a:
            continue
        if merged and a <= merged[-1][1] + 1e-6:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return merged


_IMG_CACHE = {}


def load_rgba(path):
    img = _IMG_CACHE.get(path)
    if img is None:
        data = np.fromfile(path, np.uint8)  # funziona anche con accenti nel percorso (Windows)
        img = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
        if img is None:
            raise RuntimeError("Immagine non leggibile: " + os.path.basename(path))
        if img.ndim == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
        elif img.shape[2] == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
        _IMG_CACHE[path] = img
    return img


def _scaled(path, img, dw):
    """Immagine grande rimpicciolita bene (INTER_AREA) una volta sola, vicino alla grandezza a cui si vede:
    cosi' negli zoom lenti non sfarfalla (il ridimensionamento a ogni fotogramma perde dettagli a caso)."""
    ih, iw = img.shape[:2]
    if iw <= dw * 1.6:
        return img
    tw = int(math.ceil(dw * 1.3 / 64.0) * 64)
    key = (path, tw)
    out = _IMG_CACHE.get(key)
    if out is None:
        out = cv2.resize(img, (tw, max(1, int(round(ih * tw / iw)))), interpolation=cv2.INTER_AREA)
        _IMG_CACHE[key] = out
    return out


def draw(c, s, Wt, Ht):
    """Fotogramma intero trasparente con l'immagine trasformata."""
    img0 = load_rgba(c["file"])
    ar = c.get("ar") or img0.shape[0] / img0.shape[1]
    img = _scaled(c["file"], img0, max(8.0, abs(s["w"]) * Wt))
    ih, iw = img.shape[:2]
    dst = np.float32(quad(s, Wt, Ht, ar))
    src = np.float32([(0, 0), (iw, 0), (iw, ih), (0, ih)])
    M = cv2.getPerspectiveTransform(src, dst)
    out = cv2.warpPerspective(img, M, (Wt, Ht), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    op = max(0.0, min(1.0, s["op"] / 100))
    if op < 0.999:
        out[:, :, 3] = (out[:, :, 3].astype(np.float32) * op).astype(np.uint8)
    return out


def save_png(path, img):
    ok, buf = cv2.imencode(".png", img, [cv2.IMWRITE_PNG_COMPRESSION, 1])
    if not ok:
        raise RuntimeError("Non riesco a preparare l'immagine")
    buf.tofile(path)


def _covers(s, aspect, ar):
    """L'immagine copre tutto lo schermo (niente trasparenze): allora il pezzo animato si salva come video normale."""
    hf = s["w"] * aspect * ar
    return (s["x"] <= 1e-4 and s["y"] <= 1e-4 and s["x"] + s["w"] >= 1 - 1e-4 and s["y"] + hf >= 1 - 1e-4
            and abs(s.get("rot", 0)) < 1e-3 and abs(s.get("rx", 0)) < 1e-3 and abs(s.get("ry", 0)) < 1e-3
            and abs(s.get("z", 0)) < 1e-4 and s.get("op", 100) >= 99.9)


def _encode_moving(c, a, n, fps, Wt, Ht, aspect, ar, out_base, progress=None):
    """Pezzo in movimento di un'immagine: fotogrammi calcolati qui (precisione sotto il pixel, niente tremolio)
    e mandati a ffmpeg. Immagine opaca a tutto schermo -> mp4 leggero; altrimenti video con trasparenza (ffv1)."""
    import subprocess
    from .util import ffmpeg_bin, NO_WINDOW
    dur = c["dur"]
    img = load_rgba(c["file"])
    opaque_img = img.shape[2] < 4 or int(img[:, :, 3].min()) >= 250
    states = [final_state(c, min(dur, a + k / fps), aspect, ar) for k in range(n)]
    opaque = opaque_img and all(_covers(st, aspect, ar) for st in states)
    if opaque:
        path = out_base + ".mp4"
        enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "12", "-pix_fmt", "yuv420p"]
        pix = "bgr24"
    else:
        path = out_base + ".mkv"
        enc = ["-c:v", "ffv1", "-pix_fmt", "bgra"]
        pix = "bgra"
    cmd = [ffmpeg_bin(), "-nostdin", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", pix, "-s", f"{Wt}x{Ht}",
           "-r", f"{fps:.6f}", "-i", "-", *enc, path]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
    try:
        for k, st in enumerate(states):
            fr = draw(c, st, Wt, Ht)
            if opaque:
                fr = fr[:, :, :3]
            p.stdin.write(np.ascontiguousarray(fr).tobytes())
            if progress and k % 10 == 0:
                progress(k / n)
    finally:
        try:
            p.stdin.close()
        except OSError:
            pass
    if p.wait() != 0:
        raise RuntimeError("Non riesco a preparare l'immagine animata: " + p.stderr.read().decode(errors="ignore")[-300:])
    return path


def moving_frames(c, fps):
    return sum(int(math.ceil((b - a) * fps)) for a, b in moving_spans(c))


def sources(c, Wt, Ht, fps, work, cache, progress=None):
    """Pezzi da sovrapporre per una clip: fermi (png) o in movimento (video).
    Ritorna [(tipo, percorso, inizio, fine)] in tempo del VOD."""
    key = (c["id"], Wt, Ht)
    if key in cache:
        return cache[key]
    img = load_rgba(c["file"])
    ar = c.get("ar") or img.shape[0] / img.shape[1]
    aspect = Wt / Ht
    dur = c["dur"]
    d = os.path.join(work, "ov_%s_%d" % (c["id"], Ht))
    os.makedirs(d, exist_ok=True)
    out = []
    cur, i = 0.0, 0

    def still(t0, t1, at):
        nonlocal i
        p = os.path.join(d, "s%03d.png" % i)
        i += 1
        save_png(p, draw(c, final_state(c, at, aspect, ar), Wt, Ht))
        out.append(("png", p, c["a"] + t0, c["a"] + t1))

    for a, b in moving_spans(c):
        if a > cur + 1e-3:
            still(cur, a, (cur + a) / 2)
        n = max(1, int(math.ceil((b - a) * fps)))
        path = _encode_moving(c, a, n, fps, Wt, Ht, aspect, ar, os.path.join(d, "m%03d" % i), progress)
        i += 1
        out.append(("vid", path, c["a"] + a, c["a"] + a + n / fps))
        cur = a + n / fps
    if cur < dur - 1e-3:
        still(cur, dur, (cur + dur) / 2)
    cache[key] = out
    return out
