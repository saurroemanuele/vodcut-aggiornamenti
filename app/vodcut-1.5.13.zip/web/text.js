// VODcut - testi liberi: il testo viene disegnato in un'immagine (PNG) che poi si comporta
// come le altre immagini (posizione, 3D, keyframe, animazioni). Cosi' anteprima ed esportazione
// usano esattamente gli stessi pixel.

export const TEXT_DEFAULT = {
  content: 'Il tuo testo', font: 'Arial', size: 0.08, color: '#FFFFFF', bold: true, italic: false, upper: false, align: 'center',
  stroke: false, strokeColor: '#000000', strokeW: 0.08, box: false, boxColor: '#000000', boxOp: 80, boxR: 0.25, shadow: true, lineH: 1.15,
};

export const TEXT_PRESETS = [
  ['Titolo', { font: 'Arial', bold: true, italic: false, upper: false, color: '#FFFFFF', stroke: false, box: false, shadow: true }],
  ['Contorno', { font: 'Arial', bold: true, italic: false, upper: false, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: false }],
  ['Meme', { font: 'Impact', bold: false, italic: false, upper: true, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.12, box: false, shadow: false }],
  ['Etichetta', { font: 'Segoe UI', bold: true, italic: false, upper: false, color: '#111114', stroke: false, box: true, boxColor: '#FFFFFF', boxOp: 100, boxR: 0.3, shadow: false }],
  ['Giallo', { font: 'Arial', bold: true, italic: false, upper: true, color: '#FFD60A', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: true }],
  ['Elegante', { font: 'Georgia', bold: false, italic: true, upper: false, color: '#FFFFFF', stroke: false, box: false, shadow: true }],
];

function hexA(hex, a) {
  let x = (hex || '#000').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
}

// parole evidenziate: *cosi'* nel testo -> pezzi [{s, hl}]
function runsOf(line) {
  const out = [];
  const re = /\*([^*]+)\*/g;
  let last = 0, m;
  while ((m = re.exec(line))) {
    if (m.index > last) out.push({ s: line.slice(last, m.index), hl: false });
    out.push({ s: m[1], hl: true });
    last = m.index + m[0].length;
  }
  if (last < line.length || !out.length) out.push({ s: line.slice(last), hl: false });
  return out;
}
export const hasHighlight = (content) => /\*[^*]+\*/.test(String(content || ''));

// disegna il testo alla risoluzione del video (H = altezza del VOD)
// Stili in piu' (per i titoli pronti): parole *evidenziate* (colore e/o riquadro), sfumatura, doppio contorno,
// alone (neon), ombra piena spostata (effetto 3D), riquadro per ogni riga, spaziatura tra le lettere.
export function drawText(t0, H, logo) {
  if (t0 && t0.badge) return drawBadge(t0, H, logo);
  const t = { ...TEXT_DEFAULT, ...(t0 || {}) };
  const px = Math.max(8, Math.round(t.size * H));
  const font = `${t.italic ? 'italic ' : ''}${t.weight || (t.bold ? '700' : '400')} ${px}px "${t.font}", Arial, sans-serif`;
  const useHl = !!(t.hlColor || t.hlBox);   // *parole* evidenziate solo negli stili che lo prevedono
  const lines = String(t.content || ' ').split('\n').map((l) => { const u = t.upper ? l.toUpperCase() : l; return useHl ? runsOf(u) : [{ s: u, hl: false }]; });
  const m = document.createElement('canvas').getContext('2d');
  m.font = font;
  const ls = (t.spacing || 0) * px;
  if (ls && 'letterSpacing' in m) m.letterSpacing = ls + 'px';
  const wOf = (str) => m.measureText(str || '').width;
  lines.forEach((runs) => runs.forEach((r) => { r.w = wOf(r.s); }));
  const widths = lines.map((runs) => Math.max(runs.reduce((a, r) => a + r.w, 0), wOf(' ')));
  const lh = px * t.lineH;
  const sw = t.stroke ? t.strokeW * px : 0;
  const sw2 = t.stroke2 ? (t.stroke2W || 0.1) * px : 0;
  const hard = t.hard ? (t.hardD || 0.08) * px : 0;
  const glow = t.glow ? (t.glowR || 0.35) * px : 0;
  const hlPad = t.hlBox ? 0.14 * px : 0;
  const pad = Math.ceil((t.box || t.lineBox ? 0.35 * px : 0) + sw + sw2 + hard + glow + hlPad + (t.shadow ? 0.08 * px : 0) + 2);
  const tw = Math.max(...widths, 1), th = lh * lines.length;
  const c = document.createElement('canvas');
  c.width = Math.ceil(tw + pad * 2); c.height = Math.ceil(th + pad * 2);
  const g = c.getContext('2d');
  g.font = font; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.miterLimit = 2;
  if (ls && 'letterSpacing' in g) g.letterSpacing = ls + 'px';
  if (t.box) {
    const r = Math.min(c.height / 2, t.boxR * px);
    g.fillStyle = hexA(t.boxColor, (t.boxOp ?? 80) / 100);
    g.beginPath(); g.roundRect(0.5, 0.5, c.width - 1, c.height - 1, r); g.fill();
  }
  const xAt = (i) => (t.align === 'left' ? pad : t.align === 'right' ? c.width - pad - widths[i] : (c.width - widths[i]) / 2);
  const yAt = (i) => pad + lh * i + lh / 2;
  // riquadro dietro ogni riga (stile didascalie)
  if (t.lineBox) {
    g.fillStyle = hexA(t.boxColor, (t.boxOp ?? 100) / 100);
    const bp = 0.28 * px, r = (t.boxR ?? 0.25) * px;
    lines.forEach((runs, i) => { g.beginPath(); g.roundRect(xAt(i) - bp, yAt(i) - lh / 2 + px * 0.04, widths[i] + bp * 2, lh - px * 0.08, r); g.fill(); });
  }
  // riquadro colorato dietro le parole evidenziate (leggermente inclinato, stile "guru")
  if (t.hlBox) {
    lines.forEach((runs, i) => {
      let x = xAt(i);
      for (const r of runs) {
        if (r.hl && r.s.trim()) {
          g.save();
          g.translate(x + r.w / 2, yAt(i));
          g.rotate(((t.hlTilt ?? -2) * Math.PI) / 180);
          g.fillStyle = t.hlBoxColor || '#FFD60A';
          g.beginPath(); g.roundRect(-r.w / 2 - hlPad, -px * 0.52, r.w + hlPad * 2, px * 1.04, px * 0.14); g.fill();
          g.restore();
        }
        x += r.w;
      }
    });
  }
  const fillFor = (i, hl) => {
    if (hl && t.hlColor) return t.hlColor;
    if (t.grad && t.grad.length > 1) {
      const y = yAt(i), gr = g.createLinearGradient(0, y - px * 0.5, 0, y + px * 0.5);
      t.grad.forEach((col, k) => gr.addColorStop(k / (t.grad.length - 1), col));
      return gr;
    }
    return t.color;
  };
  // passate: prima tutto cio' che sta sotto (ombra piena, alone, contorni), poi il riempimento
  const each = (fn) => lines.forEach((runs, i) => { let x = xAt(i); for (const r of runs) { if (r.s) fn(r, x, yAt(i), i); x += r.w; } });
  if (hard) { g.fillStyle = t.hardColor || '#000000'; each((r, x, y) => { if (sw2) { g.strokeStyle = t.hardColor || '#000'; g.lineWidth = (sw + sw2) * 2; g.strokeText(r.s, x + hard, y + hard); } g.fillText(r.s, x + hard, y + hard); }); }
  if (sw2) { g.strokeStyle = t.stroke2Color || '#000000'; g.lineWidth = (sw + sw2) * 2; each((r, x, y) => g.strokeText(r.s, x, y)); }
  if (glow) {
    g.save(); g.shadowColor = t.glowColor || t.color; g.shadowBlur = glow;
    each((r, x, y, i) => { g.fillStyle = fillFor(i, r.hl); g.fillText(r.s, x, y); g.fillText(r.s, x, y); });
    g.restore();
  }
  each((r, x, y, i) => {
    if (t.shadow && !glow && !hard) { g.shadowColor = 'rgba(0,0,0,.55)'; g.shadowOffsetX = g.shadowOffsetY = Math.max(1, 0.05 * px); g.shadowBlur = 0.06 * px; }
    if (sw > 0) { g.strokeStyle = r.hl && t.hlStroke ? t.hlStroke : t.strokeColor; g.lineWidth = sw * 2; g.strokeText(r.s, x, y); g.shadowColor = 'transparent'; }
    g.fillStyle = fillFor(i, r.hl); g.fillText(r.s, x, y);
    g.shadowColor = 'transparent';
  });
  return c;
}

// ---------------------------------------------------------------- badge social
// Targhetta con piattaforma e nome (Kick, Twitch, Instagram…). Diventa un'immagine come i testi,
// quindi posizione, 3D, keyframe e animazioni funzionano uguale.
// Loghi in web/badges: <id>-free.png (a colori, su fondo scuro) e <id>-on.png (sopra il colore della piattaforma).
export const PLATFORMS = [
  // id, nome, colore, colore del testo sopra il colore, tipo (per la scritta proposta)
  ['kick', 'Kick', '#53FC18', '#0B0B0D', 'live'],
  ['twitch', 'Twitch', '#9146FF', '#FFFFFF', 'live'],
  ['youtube', 'YouTube', '#FF0033', '#FFFFFF', 'live'],
  ['tiktok', 'TikTok', '#111114', '#FFFFFF', 'at'],
  ['instagram', 'Instagram', '#E1306C', '#FFFFFF', 'at'],
  ['x', 'X', '#111114', '#FFFFFF', 'at'],
  ['custom', 'Tuo logo', '#FFFFFF', '#0B0B0D', 'at'],   // il logo lo sceglie l'utente
];
const LOGO_FILES = {
  kick: { free: 'kick-free', on: 'kick-on' }, twitch: { free: 'twitch-free', on: 'twitch-on' },
  youtube: { free: 'youtube-free', on: 'youtube-on' }, tiktok: { free: 'tiktok-free', on: 'tiktok-free' },
  instagram: { free: 'instagram-free', on: 'instagram-on' }, x: { free: 'x-on', on: 'x-on' },
};
export const logoUrl = (pid, v = 'free') => (LOGO_FILES[pid] ? '/web/badges/' + LOGO_FILES[pid][v] + '.png' : null);
const LOGOS = new Map();
// carica i loghi una volta; onload viene chiamata quando uno e' pronto (per ridisegnare i badge)
export function preloadBadgeLogos(onload) {
  for (const pid of Object.keys(LOGO_FILES)) for (const v of ['free', 'on']) {
    const u = logoUrl(pid, v);
    if (LOGOS.has(u)) continue;
    const im = new Image(); LOGOS.set(u, im);
    im.onload = () => onload && onload(pid);
    im.src = u;
  }
}
const builtin = (pid, v) => { if (!LOGO_FILES[pid]) return null; const im = LOGOS.get(logoUrl(pid, v)); return im && im.complete && im.naturalWidth ? im : null; };
export const platformOf = (id) => PLATFORMS.find((p) => p[0] === id) || PLATFORMS[0];
export const BADGE_STYLES = [['pill', 'Pillola'], ['solid', 'Pieno'], ['outline', 'Bordo'], ['minimal', 'Minimal'], ['tag', 'Etichetta']];
export function badgeLabel(pid) {
  const p = platformOf(pid);
  if (pid === 'custom') return 'Seguimi';
  return (p[4] === 'live' ? 'Live su ' : 'Seguimi su ') + p[1];
}
export const BADGE_DEFAULT = { platform: 'kick', style: 'pill', handle: 'iltuonome', label: 'Live su Kick', accent: '', logo: '' };

const luma = (hex) => { const x = (hex || '#000').replace('#', ''); const n = (i) => parseInt(x.slice(i, i + 2), 16) / 255; return 0.2126 * n(0) + 0.7152 * n(2) + 0.0722 * n(4); };

// own: un logo scelto dall'utente (immagine gia' caricata) o null = logo della piattaforma
export function drawBadge(t0, H, own) {
  const t = { ...TEXT_DEFAULT, ...(t0 || {}) }, b = { ...BADGE_DEFAULT, ...(t.badge || {}) };
  const p = platformOf(b.platform), accent = b.accent || p[2];
  const onAccent = luma(accent) > 0.6 ? '#0B0B0D' : '#FFFFFF';
  const px = Math.max(8, Math.round(t.size * H));
  const fam = `"${t.font}", Arial, sans-serif`;
  const fMain = `${t.italic ? 'italic ' : ''}${t.bold ? '800' : '500'} ${px}px ${fam}`, lpx = Math.round(px * 0.5);
  const fLab = `700 ${lpx}px ${fam}`;
  const handle = (t.upper ? String(b.handle || '').toUpperCase() : String(b.handle || '')) || ' ';
  const label = String(b.label || '').toUpperCase();
  const m = document.createElement('canvas').getContext('2d');
  m.font = fMain; const hw = m.measureText(handle).width;
  m.font = fLab; m.letterSpacing = '1px'; const lw = label ? m.measureText(label).width + label.length * 1 : 0;
  const two = !!label;
  const inner = two ? px * 1.02 + lpx * 1.25 : px * 1.2;   // altezza del testo
  const Hh = Math.round(inner + px * 0.62);                // altezza della targhetta
  const boxed = b.style === 'pill' || b.style === 'solid' || b.style === 'tag';   // logo dentro un riquadro colorato
  const logo = own || builtin(b.platform, boxed ? 'on' : 'free');
  const la = logo ? logo.naturalWidth / logo.naturalHeight : 1;   // i loghi larghi (Kick) hanno un riquadro piu' largo
  const icH = b.style === 'minimal' ? Hh * 0.86 : b.style === 'tag' ? Hh : Hh - px * 0.24;
  const noIcon = !logo && !LOGO_FILES[b.platform];   // logo personalizzato non ancora scelto: solo le scritte
  const icW = noIcon ? 0 : la > 1.6 ? icH * Math.min(2.1, 0.7 + la * 0.42) : icH;
  const gap = px * 0.42, padR = px * 0.62, sh = t.shadow ? Math.ceil(px * 0.18) : 0;
  const tw = Math.max(hw, lw);
  const icX = b.style === 'tag' || b.style === 'minimal' ? 0 : (Hh - icH) / 2;
  const txX = noIcon ? (b.style === 'minimal' ? 0 : padR) : icX + icW + gap;
  const W = Math.ceil(txX + tw + (b.style === 'minimal' ? px * 0.1 : padR));
  const c = document.createElement('canvas');
  c.width = W + sh * 2; c.height = Hh + sh * 2;
  const g = c.getContext('2d');
  g.translate(sh, sh);
  const R = Hh / 2;
  const shadowOn = () => { if (t.shadow) { g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = px * 0.22; g.shadowOffsetY = px * 0.06; } };
  const shadowOff = () => { g.shadowColor = 'transparent'; g.shadowBlur = 0; g.shadowOffsetY = 0; };
  // fondo
  let txtCol = '#FFFFFF', labCol = 'rgba(255,255,255,.62)', icBg = accent;
  shadowOn();
  if (b.style === 'pill') { g.fillStyle = 'rgba(14,14,18,.92)'; g.beginPath(); g.roundRect(0, 0, W, Hh, R); g.fill(); }
  else if (b.style === 'solid') { g.fillStyle = accent; g.beginPath(); g.roundRect(0, 0, W, Hh, R); g.fill(); txtCol = onAccent; labCol = onAccent === '#FFFFFF' ? 'rgba(255,255,255,.75)' : 'rgba(11,11,13,.62)'; icBg = onAccent === '#FFFFFF' ? 'rgba(255,255,255,.18)' : 'rgba(11,11,13,.12)'; }
  else if (b.style === 'outline') { g.fillStyle = 'rgba(14,14,18,.86)'; g.beginPath(); g.roundRect(0, 0, W, Hh, R); g.fill(); shadowOff(); g.strokeStyle = accent === '#111114' ? '#FFFFFF' : accent; g.lineWidth = Math.max(2, px * 0.09); g.beginPath(); g.roundRect(g.lineWidth / 2, g.lineWidth / 2, W - g.lineWidth, Hh - g.lineWidth, R - g.lineWidth / 2); g.stroke(); }
  else if (b.style === 'tag') { g.fillStyle = 'rgba(14,14,18,.92)'; g.beginPath(); g.roundRect(0, 0, W, Hh, px * 0.16); g.fill(); }
  shadowOff();
  // riquadro del logo
  const icY = (Hh - icH) / 2;
  if (boxed && !noIcon) {
    g.fillStyle = icBg; g.beginPath();
    if (b.style === 'tag') g.roundRect(0, 0, icW, Hh, [px * 0.16, 0, 0, px * 0.16]); else g.roundRect(icX, icY, icW, icH, icH / 2);
    g.fill();
  }
  if (logo) {
    if (b.style === 'minimal') shadowOn();
    const fill = boxed ? (la > 1.6 ? 0.74 : b.platform === 'tiktok' && !own ? 1 : 0.56) : b.style === 'outline' ? (la > 1.6 ? 0.8 : 0.66) : (la > 1.6 ? 0.96 : 0.84);
    const k = Math.min(icW * fill / logo.naturalWidth, icH * (la > 1.6 ? 0.9 : fill) / logo.naturalHeight);
    const lw2 = logo.naturalWidth * k, lh2 = logo.naturalHeight * k;
    g.drawImage(logo, icX + (icW - lw2) / 2, icY + (icH - lh2) / 2, lw2, lh2);
    shadowOff();
  }
  // testo
  if (b.style === 'minimal') shadowOn();
  g.textBaseline = 'middle';
  const cy = Hh / 2;
  if (two) {
    const top = cy - inner / 2;
    g.font = fLab; g.letterSpacing = '1px'; g.fillStyle = b.style === 'minimal' ? 'rgba(255,255,255,.8)' : labCol; g.fillText(label, txX, top + lpx * 0.62);
    g.letterSpacing = '0px'; g.font = fMain; g.fillStyle = txtCol; g.fillText(handle, txX, top + lpx * 1.25 + px * 0.54);
  } else {
    g.font = fMain; g.fillStyle = txtCol; g.fillText(handle, txX, cy + px * 0.04);
  }
  return c;
}

// ---------------------------------------------------------------- titoli animati pronti
// Stili nostri (font inclusi in VODcut, licenza libera) con l'animazione gia' scelta.
// [id, nome, categoria, stile, animazione, testo di esempio]
const OFF = { bold: true, weight: null, italic: false, upper: false, stroke: false, stroke2: false, box: false, lineBox: false, shadow: false,
  glow: false, hard: false, hlColor: '', hlBox: false, hlStroke: '', grad: null, spacing: 0, lineH: 1.1, align: 'center' };
export const TITLE_CATS = [['social', 'Social'], ['titoli', 'Titoli'], ['neon', 'Neon e tech'], ['eleganti', 'Eleganti']];
export const TITLE_PRESETS = [
  ['guru', 'Guru', 'social', { font: 'Montserrat', weight: 900, upper: true, color: '#FFFFFF', hlBox: true, hlBoxColor: '#FFD60A', hlColor: '#111111', shadow: true },
    { in: 'slam', inDur: 0.35, out: 'fade', outDur: 0.25 }, 'Il *segreto* che\nnessuno ti dice'],
  ['hormozi', 'Parole gialle', 'social', { font: 'Montserrat', weight: 900, upper: true, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.13, hlColor: '#FFD60A', hard: true, hardD: 0.06, hardColor: '#000000' },
    { in: 'pop', inDur: 0.3 }, 'Fai *questo*\nogni giorno'],
  ['verde', 'Evidenziato verde', 'social', { font: 'Poppins', color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.11, hlColor: '#3DDC84', shadow: true },
    { in: 'rise', inDur: 0.4 }, 'Ecco *come*\nho fatto'],
  ['caption', 'Didascalia', 'social', { font: 'TikTok Sans', weight: 700, color: '#111111', lineBox: true, boxColor: '#FFFFFF', boxOp: 100, boxR: 0.22, lineH: 1.28 },
    { in: 'pop', inDur: 0.3, out: 'pop', outDur: 0.25 }, 'Aspetta\nla fine…'],
  ['punch', 'Colpo rosso', 'social', { font: 'Anton', bold: false, upper: true, color: '#FFFFFF', hlBox: true, hlBoxColor: '#FF2D3D', hlColor: '#FFFFFF', hlTilt: -3, shadow: true, spacing: 0.01 },
    { in: 'slam', inDur: 0.3, loop: 'beat' }, '*Stop* a questo\nerrore'],
  ['iscriviti', 'Iscriviti', 'social', { font: 'Poppins', color: '#FFFFFF', box: true, boxColor: '#FF0033', boxOp: 100, boxR: 1 },
    { in: 'pop', inDur: 0.35, loop: 'beat', out: 'pop', outDur: 0.25 }, 'Iscriviti al canale'],
  ['3d', 'Titolo 3D', 'titoli', { font: 'Luckiest Guy', bold: false, upper: true, color: '#FFE14D', stroke: true, strokeColor: '#1A1A1A', strokeW: 0.09, hard: true, hardD: 0.1, hardColor: '#1A1A1A' },
    { in: 'tilt', inDur: 0.45, loop: 'bounce' }, 'Incredibile!'],
  ['fumetto', 'Fumetto', 'titoli', { font: 'Bangers', bold: false, upper: true, color: '#FFFFFF', stroke: true, strokeColor: '#111111', strokeW: 0.1, stroke2: true, stroke2W: 0.09, stroke2Color: '#FFD60A', spacing: 0.03 },
    { in: 'slam', inDur: 0.3, loop: 'shake' }, 'Boom!'],
  ['sfumato', 'Sfumato', 'titoli', { font: 'Archivo Black', bold: false, upper: true, grad: ['#FFE259', '#FF7A2F'], stroke: true, strokeColor: '#111111', strokeW: 0.07, hard: true, hardD: 0.07, hardColor: '#111111' },
    { in: 'pop', inDur: 0.35 }, 'Nuovo video'],
  ['breaking', 'Ultim\'ora', 'titoli', { font: 'Bebas Neue', bold: false, upper: true, color: '#FFFFFF', box: true, boxColor: '#E11D2E', boxOp: 100, boxR: 0.06, spacing: 0.05 },
    { in: 'slideL', inDur: 0.45, out: 'slideR', outDur: 0.4 }, 'Ultim\'ora'],
  ['pennarello', 'Pennarello', 'titoli', { font: 'Permanent Marker', bold: false, color: '#FFFFFF', hard: true, hardD: 0.05, hardColor: '#000000' },
    { in: 'tilt', inDur: 0.4 }, 'Da non perdere!'],
  ['neon', 'Neon rosa', 'neon', { font: 'Righteous', bold: false, color: '#FFFFFF', glow: true, glowColor: '#FF2BD6', glowR: 0.4 },
    { in: 'fade', inDur: 0.5, loop: 'pulse', out: 'fade', outDur: 0.4 }, 'Live stasera'],
  ['neonblu', 'Neon blu', 'neon', { font: 'Orbitron', weight: 800, upper: true, color: '#E6FBFF', glow: true, glowColor: '#22D3EE', glowR: 0.4, spacing: 0.06 },
    { in: 'rise', inDur: 0.5, out: 'fade', outDur: 0.4 }, 'Gameplay'],
  ['pixel', 'Pixel', 'neon', { font: 'Press Start 2P', bold: false, upper: true, color: '#7CFF6B', hard: true, hardD: 0.1, hardColor: '#0B3D0B', lineH: 1.5 },
    { in: 'pop', inDur: 0.3, loop: 'bounce' }, 'Level up'],
  ['elegante', 'Elegante', 'eleganti', { font: 'Playfair Display', weight: 600, italic: true, color: '#FFFFFF', shadow: true, spacing: 0.01 },
    { in: 'rise', inDur: 0.7, out: 'fade', outDur: 0.5 }, 'Capitolo uno'],
  ['cinema', 'Cinematico', 'eleganti', { font: 'Cinzel', weight: 600, upper: true, color: '#F5F1E8', shadow: true, spacing: 0.22 },
    { in: 'zoom', inDur: 0.9, out: 'fade', outDur: 0.6 }, 'Il viaggio'],
  ['firma', 'Firma', 'eleganti', { font: 'Great Vibes', bold: false, color: '#FFFFFF', shadow: true, lineH: 1.2 },
    { in: 'fade', inDur: 0.8, out: 'fade', outDur: 0.6 }, 'con amore'],
];
// stile completo di un titolo (azzera quello che il titolo non usa)
export const titleStyle = (p) => ({ ...OFF, ...p[3] });
