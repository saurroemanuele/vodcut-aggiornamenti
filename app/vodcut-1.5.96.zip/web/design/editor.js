// Grafica: l'editor (tela, strumenti, livelli, proprieta'). Il disegno e' in render.js, il documento in doc.js.
import { h, icon, toast, get, post, TOKEN, confirmBox, promptBox, pollJob, IS_MAC } from '../lib.js';
import { fontPicker, ensureFont } from '../fonts.js';
import { uid, clone, BLENDS, FX_DEFAULT, FILTER_DEFAULT, ADJUST_KINDS, textLayer, shapeLayer, imageLayer, paintLayer, adjustLayer,
  groupLayer, walk, findLayer, corners, bounds, toLocal, fromLocal, moveBy, scaleAround, flatVisible } from './doc.js';
import { Assets, renderPage, renderLayers, layerBitmap, curveLut, compactLut, warpMap as warpMapOf, pageCanvas, hitLayer, textHeight, textNaturalWidth, fontOf, dropCache, fillColor, pathTrace, pathPad } from './render.js';
import { colorButton } from './color.js';
import { readPsd, writePsdBuffer } from './psd.js';
import { brandPanel, loadBrands, logoUrl } from './brand.js';
import { PRESETS } from './doc.js';
import { Selection, magicWand, mapToLayer } from './select.js';
import { mediaUrl } from '../lib.js';
import { LANG, t as tr } from '../i18n.js';

// replaceChildren senza i null (altrimenti diventano il testo "null")
const rc = (el, ...kids) => el.replaceChildren(...kids.flat().filter((x) => x != null && x !== false));

const MOD = IS_MAC ? '⌘' : 'Ctrl+';
const TOOLS = [
  ['move', 'cursor', 'Sposta e trasforma', 'V'], ['select', 'marquee', 'Selezione', 'M'], ['text', 'type', 'Testo', 'T'], ['shape', 'square', 'Forme', 'U'], ['pen', 'pen', 'Penna (tracciati)', 'P'],
  ['brush', 'brush', 'Pennello', 'B'], ['eraser', 'eraser', 'Gomma', 'E'], ['clone', 'stamp', 'Timbro clone', 'S'], ['heal', 'bandage', 'Pennello correttivo', 'J'], ['eyedrop', 'pipette', 'Contagocce', 'I'],
  ['crop', 'crop', 'Ritaglia la tela', 'C'], ['hand', 'hand', 'Mano (sposta la vista)', 'H'],
];
const SELS = [['rect', 'marquee', 'Rettangolo'], ['ellipse', 'marqueeE', 'Ellisse'], ['lasso', 'lasso', 'Lazo'], ['wand', 'wand', 'Bacchetta magica']];
const SHAPES = [['rect', 'square', 'Rettangolo'], ['ellipse', 'circle', 'Ellisse'], ['triangle', 'triangle', 'Triangolo'], ['poly', 'hexagon', 'Poligono'], ['star', 'star', 'Stella'], ['line', 'line', 'Linea']];
const HANDLE = 9;

export async function mountDesign(root, gid, { onTitle, topRight, autoCut }) {
  let doc = await get('/api/d/' + gid);
  let alive = true;
  const S = {
    page: 0, sel: [], tool: 'move', zoom: 1, panX: 0, panY: 0, hover: null,
    color: '#111111', brush: { size: 40, hard: 0.8, opacity: 1 }, shape: 'rect', maskEdit: false, snap: true,
    editing: null, crop: null, guides: [], busy: null,
    selMode: 'rect', selOp: 'new', tol: 32, contig: true, cloneSrc: null, cloneOff: null, cloneAligned: true,
    view: (() => { try { return { rulers: false, grid: false, guides: true, gridSize: 50, ...JSON.parse(localStorage.getItem('nf.dz.view') || '{}') }; } catch (e) { return { rulers: false, grid: false, guides: true, gridSize: 50 }; } })(),
  };
  const RUL = 20;   // spessore dei righelli (px dello schermo)
  const sel = new Selection(doc.w, doc.h);
  let wandCache = null;   // l'immagine per la bacchetta: si rifa' quando cambia qualcosa
  const assets = new Assets((n) => `/api/d/${gid}/file/${n}?token=${TOKEN}`, () => { dropAllForSrc(); draw(); paintLayersSoon(); });
  const page = () => doc.pages[Math.min(S.page, doc.pages.length - 1)];
  const layers = () => page().layers;
  const selLayers = () => S.sel.map((id) => findLayer(layers(), id)).filter(Boolean).map((r) => r.layer);
  const one = () => (S.sel.length === 1 ? selLayers()[0] || null : null);
  function dropAllForSrc() { /* la chiave della cache contiene la versione dell'immagine: niente da fare */ }

  // ------------------------------------------------------------ cronologia (Annulla / Ripeti)
  const hist = { stack: [], labels: [], idx: -1, key: '', t: 0 };
  const snap = () => JSON.stringify({ w: doc.w, h: doc.h, pages: doc.pages, page: S.page });
  function commit(key) {
    const s = snap(), now = Date.now();
    if (hist.stack[hist.idx] === s) return;
    if (key && hist.key === key && now - hist.t < 900 && hist.idx === hist.stack.length - 1 && hist.idx > 0) { hist.stack[hist.idx] = s; hist.labels[hist.idx] = null; }
    else { hist.stack.splice(hist.idx + 1); hist.labels.splice(hist.idx + 1); hist.stack.push(s); hist.labels.push(null); if (hist.stack.length > 150) { hist.stack.shift(); hist.labels.shift(); } hist.idx = hist.stack.length - 1; }
    if (lTab === 'hist') histSoon();
    hist.key = key || ''; hist.t = now;
    scheduleSave(); draw();
    // modifiche continue (cursori, colori, testo): il pannello resta com'e', si aggiornano solo lista e pagine
    if (key && key !== 'nudge') { paintLayersSoon(); pagesSoon(); } else refresh();
  }
  function restore(i) {
    if (i < 0 || i >= hist.stack.length) return;
    hist.idx = i; hist.key = '';
    const o = JSON.parse(hist.stack[i]);
    doc.w = o.w; doc.h = o.h; doc.pages = o.pages; S.page = Math.min(o.page || 0, doc.pages.length - 1);
    S.sel = S.sel.filter((id) => findLayer(layers(), id));
    stopEdit(false);
    scheduleSave(); draw(); refresh(true);
    if (lTab === 'hist') histSoon();
  }
  const undo = () => restore(hist.idx - 1), redo = () => restore(hist.idx + 1);
  // che cosa e' cambiato tra due stati (per la cronologia)
  function describe(a, b) {
    const A = JSON.parse(a), B = JSON.parse(b);
    if (A.w !== B.w || A.h !== B.h) return ['frame', tr('Dimensione della tela')];
    if (A.pages.length !== B.pages.length) return ['pages', tr(B.pages.length > A.pages.length ? 'Nuova pagina' : 'Pagina eliminata')];
    const flat = (o) => { const m = new Map(); o.pages.forEach((p, pi) => walk(p.layers, (l) => { m.set(l.id, l); }, null)); return m; };
    const ma = flat(A), mb = flat(B), nm = (l) => l.name || tr({ text: 'Testo', shape: 'Forma', path: 'Tracciato', image: 'Immagine', paint: 'Pittura', group: 'Gruppo', adjust: 'Regolazione' }[l.type] || 'Livello');
    const added = [...mb.keys()].filter((id) => !ma.has(id)), removed = [...ma.keys()].filter((id) => !mb.has(id));
    if (added.length && removed.length) return ['layers', tr('Unisci i livelli')];
    for (const [id, l] of mb) if (!ma.has(id)) return ['plus', tr('Nuovo livello') + ': ' + nm(l)];
    for (const [id, l] of ma) if (!mb.has(id)) return ['trash', tr('Elimina') + ': ' + nm(l)];
    for (const [id, l] of mb) {
      const o = ma.get(id), { children: c1, ...x1 } = o, { children: c2, ...x2 } = l;
      if (JSON.stringify(x1) === JSON.stringify(x2)) continue;
      const ch = Object.keys({ ...x1, ...x2 }).filter((k) => JSON.stringify(x1[k]) !== JSON.stringify(x2[k]));
      const only = (...ks) => ch.every((k) => ks.includes(k));
      const n = nm(l);
      if (only('x', 'y')) return ['cursor', tr('Sposta') + ' ' + n];
      if (only('x', 'y', 'w', 'h', 'size', 'letter')) return ['frame', tr('Ridimensiona') + ' ' + n];
      if (only('x', 'y', 'rot')) return ['refresh', tr('Ruota') + ' ' + n];
      if (only('visible')) return ['eye', (l.visible ? tr('Mostra') : tr('Nascondi')) + ' ' + n];
      if (only('text', 'w', 'h', 'x', 'y')) return ['type', tr('Testo') + ': ' + n];
      if (ch.includes('warp')) return ['grid', tr('Deforma') + ' ' + n];
      if (ch.includes('src') || ch.includes('mask')) return ['brush', tr('Pittura') + ': ' + n];
      if (ch.includes('fx')) return ['sparkle', tr('Effetti') + ': ' + n];
      if (ch.includes('p') || ch.includes('filters')) return ['adjust', tr('Regolazione') + ': ' + n];
      if (ch.includes('clip')) return ['clipArrow', tr('Maschera di ritaglio') + ': ' + n];
      if (only('name')) return ['type', tr('Rinomina') + ' ' + n];
      return ['adjust', tr('Modifica') + ' ' + n];
    }
    const order = (o) => JSON.stringify(o.pages.map((p) => { const ids = []; walk(p.layers, (l) => { ids.push(l.id); }, null); return ids; }));
    if (order(A) !== order(B)) return ['layers', tr('Ordine dei livelli')];
    const bgA = JSON.stringify(A.pages.map((p) => [p.bg, p.guides])), bgB = JSON.stringify(B.pages.map((p) => [p.bg, p.guides]));
    if (bgA !== bgB) return ['palette', tr('Sfondo o guide')];
    return ['adjust', tr('Modifica')];
  }
  let histT = 0;
  function histSoon() { clearTimeout(histT); histT = setTimeout(() => alive && paintHist(), 120); }
  function paintHist() {
    if (lTab !== 'hist') return;
    const rows = hist.stack.map((st, i) => {
      if (i > 0 && !hist.labels[i]) { try { hist.labels[i] = describe(hist.stack[i - 1], st); } catch (e) { hist.labels[i] = ['adjust', tr('Modifica')]; } }
      const [ic, txt] = i === 0 ? ['image', tr('Apertura')] : hist.labels[i];
      return h('button', { class: 'dz-hrow' + (i === hist.idx ? ' on' : '') + (i > hist.idx ? ' future' : ''), 'data-notr': '', onclick: () => restore(i) }, icon(ic, 14, 'currentColor', 1.8), h('span', null, txt));
    });
    rc(histList, ...rows);
    const on = histList.querySelector('.on'); if (on) on.scrollIntoView({ block: 'nearest' });
  }

  // ------------------------------------------------------------ salvataggio (da solo, dopo ogni modifica)
  const memMap = new Map(), pending = new Map();   // nome in memoria -> nome sul disco
  let saveT = 0, saving = null, coverT = 0;
  const saveDot = h('span', { class: 'dz-save' });
  let firstDirty = 0;
  function scheduleSave() {
    // dopo l'ultima modifica, ma mai piu' di 2 secondi dalla prima non salvata (anche se si continua a lavorare)
    const now = Date.now(); if (!firstDirty) firstDirty = now;
    clearTimeout(saveT); saveDot.className = 'dz-save on'; saveDot.dataset.tip = 'Salvataggio…';
    saveT = setTimeout(save, Math.max(0, Math.min(450, 2000 - (now - firstDirty))));
    clearTimeout(coverT); coverT = setTimeout(saveCover, 2500);
  }
  async function save() {
    if (saving) { await saving; }
    saveT = 0; firstDirty = 0;
    saving = (async () => {
      await Promise.all([...pending.values()]);
      let raw = JSON.stringify(doc);
      for (const [m, f] of memMap) raw = raw.split(m).join(f);
      const r = await fetch(`/api/d/${gid}?token=${TOKEN}`, { method: 'PUT', body: raw });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'Salvataggio non riuscito');
      saveDot.className = 'dz-save'; saveDot.dataset.tip = 'Salvato';
    })().catch((e) => { saveDot.className = 'dz-save err'; saveDot.dataset.tip = e.message; }).finally(() => { saving = null; });
    return saving;
  }
  async function saveCover() {
    try {
      const k = Math.min(1, 480 / Math.max(doc.w, doc.h));
      const c = await pageCanvas(doc, doc.pages[0], k, assets);
      const b = await new Promise((r) => c.toBlob(r, 'image/png'));
      await fetch(`/api/d/${gid}/cover?token=${TOKEN}`, { method: 'PUT', body: b });
    } catch (e) { /* anteprima: non importa */ }
  }
  // una tela (pittura, maschera) diventa un file della grafica: subito in memoria, il file arriva dopo
  function storeCanvas(cv, kind) {
    const mem = 'mem' + uid('_') + '.png';
    assets.put(mem, cv);
    const p = new Promise((res) => cv.toBlob(res, 'image/png'))
      .then((b) => fetch(`/api/d/${gid}/file?kind=${kind}&token=${TOKEN}`, { method: 'PUT', body: b }))
      .then((r) => r.json()).then((j) => { if (j.file) { memMap.set(mem, j.file); assets.alias(mem, j.file); } })
      .catch(() => toast('Non riesco a salvare la pittura', true)).finally(() => pending.delete(mem));
    pending.set(mem, p);
    return mem;
  }
  async function uploadBlob(blob, kind = 'img') {
    const r = await fetch(`/api/d/${gid}/file?kind=${kind}&token=${TOKEN}`, { method: 'PUT', body: blob });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Immagine non valida');
    return j.file;
  }

  // ------------------------------------------------------------ interfaccia
  const cv = h('canvas', { class: 'dz-cv' }), ov = h('canvas', { class: 'dz-ov' });
  const stage = h('div', { class: 'dz-stage', tabindex: '0' }, cv, ov);
  const opts = h('div', { class: 'dz-opts' });
  const toolsBar = h('div', { class: 'dz-tools' });
  const props = h('div', { class: 'dz-props' });
  const layerList = h('div', { class: 'dz-llist' });
  const histList = h('div', { class: 'dz-llist dz-hlist', style: { display: 'none' } });
  let lTab = 'layers';
  function setLTab(t) {
    lTab = t; layerList.style.display = t === 'layers' ? '' : 'none'; histList.style.display = t === 'hist' ? '' : 'none';
    side.querySelectorAll('.dz-ltab').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
    side.querySelectorAll('.dz-lhead .dz-ib').forEach((b) => { b.style.visibility = t === 'layers' ? '' : 'hidden'; });
    if (t === 'hist') paintHist();
  }
  const pagesBar = h('div', { class: 'dz-pages' });
  const zoomLbl = h('button', { class: 'dz-zoom', 'data-tip': 'Adatta alla finestra (' + MOD + '0)', onclick: () => fit() });
  const busyEl = h('div', { class: 'dz-busy', style: { display: 'none' } });
  const side = h('aside', { class: 'dz-side' },
    h('div', { class: 'dz-ptitle' }, 'Proprietà'), props,
    h('div', { class: 'dz-lhead' }, h('div', { class: 'dz-ltabs' },
      h('button', { class: 'dz-ltab on', 'data-tab': 'layers', onclick: () => setLTab('layers') }, 'Livelli'),
      h('button', { class: 'dz-ltab', 'data-tab': 'hist', onclick: () => setLTab('hist') }, 'Cronologia')), h('div', { class: 'grow' }),
      ib('plus', 'Nuovo livello di pittura', () => addLayer(paintLayer(doc))),
      ib('adjust', 'Livello di regolazione', (e) => adjustMenu(e.currentTarget)),
      ib('group', 'Raggruppa (' + MOD + 'G)', () => groupSel()),
      ib('mask', 'Maschera di livello', () => toggleMask()),
      ib('duplicate', 'Duplica (' + MOD + 'J)', () => duplicateSel()),
      ib('trash', 'Elimina (Canc)', () => deleteSel())),
    layerList, histList);
  const root2 = h('div', { class: 'dz' },
    opts,
    h('div', { class: 'dz-main' }, toolsBar, h('div', { class: 'dz-center' }, h('div', { class: 'dz-stagewrap' }, stage, busyEl), pagesBar), side));
  root.append(root2);
  const undoB = ib('undo', 'Annulla (' + MOD + 'Z)', () => undo()), redoB = ib('redo', 'Ripeti (' + MOD + 'Shift+Z)', () => redo());
  const moreB = h('button', { class: 'dz-ib', 'aria-label': 'Altro', 'data-tip': 'Altro', onclick: (e) => menu(e.currentTarget, [
    ['Crea in altri formati…', () => resizeAllDialog()],
    [doc.template ? 'Togli dai modelli' : 'Salva come modello', async () => { doc.template = !doc.template; try { await post(`/api/d/${gid}/meta`, { template: doc.template }); toast(doc.template ? 'Salvata nei modelli: la trovi in Grafica, nella home' : 'Tolta dai modelli'); } catch (er) { toast(er.message, true); } }],
    ['Usa in un video…', () => toVideoDialog()],
    '-',
    [S.view.rulers ? 'Nascondi i righelli' : 'Mostra i righelli', () => toggleView('rulers')],
    [S.view.grid ? 'Nascondi la griglia' : 'Mostra la griglia', () => toggleView('grid')],
    ['Dimensione della griglia…', async () => { const v = await promptBox('Griglia', 'Distanza tra le linee (px)', String(S.view.gridSize), 'OK'); if (v && +v >= 2) { S.view.gridSize = Math.round(+v); S.view.grid = true; saveView(); draw(); } }],
    [S.view.guides ? 'Nascondi le guide' : 'Mostra le guide', () => toggleView('guides')],
    ['Nuova guida…', () => newGuideDialog()],
    ['Cancella le guide', () => { page().guides = { v: [], h: [] }; commit(); }, !(page().guides && (page().guides.v.length || page().guides.h.length))],
    '-',
    ['Esporta…', () => exportDialog()],
  ]) }, icon('dots', 16, 'currentColor', 2));
  if (topRight) topRight.append(saveDot, undoB, redoB, zoomLbl, moreB,
    h('button', { class: 'btn primary sm dz-expbtn', onclick: () => exportDialog() }, icon('download', 14, '#fff', 2), 'Esporta'));
  function ib(name, tip, fn, cls) { return h('button', { class: 'dz-ib' + (cls ? ' ' + cls : ''), 'aria-label': tip, 'data-tip': tip, onclick: fn }, icon(name, 16, 'currentColor', 1.9)); }

  // ------------------------------------------------------------ vista
  const dpr = () => window.devicePixelRatio || 1;
  const toDoc = (sx, sy) => [(sx - S.panX) / S.zoom, (sy - S.panY) / S.zoom];
  const toScr = (x, y) => [S.panX + x * S.zoom, S.panY + y * S.zoom];
  function fit() {
    const r = stage.getBoundingClientRect();
    const z = Math.min((r.width - 80) / doc.w, (r.height - 80) / doc.h);
    S.zoom = Math.max(0.02, Math.min(8, z || 1));
    S.panX = (r.width - doc.w * S.zoom) / 2; S.panY = (r.height - doc.h * S.zoom) / 2;
    draw();
  }
  function zoomAt(z, sx, sy) {
    const r = stage.getBoundingClientRect();
    if (sx == null) { sx = r.width / 2; sy = r.height / 2; }
    const [dx, dy] = toDoc(sx, sy);
    S.zoom = Math.max(0.02, Math.min(32, z));
    S.panX = sx - dx * S.zoom; S.panY = sy - dy * S.zoom;
    draw();
  }

  // ------------------------------------------------------------ righelli, griglia, guide
  const saveView = () => { try { localStorage.setItem('nf.dz.view', JSON.stringify(S.view)); } catch (e) { /* */ } };
  function toggleView(k) { S.view[k] = !S.view[k]; if (k === 'guides' && S.view.guides) { /* */ } saveView(); draw(); toast({ rulers: S.view.rulers ? 'Righelli visibili' : 'Righelli nascosti', grid: S.view.grid ? 'Griglia visibile' : 'Griglia nascosta', guides: S.view.guides ? 'Guide visibili' : 'Guide nascoste' }[k]); }
  const pguides = () => { const p = page(); if (!p.guides) p.guides = { v: [], h: [] }; return p.guides; };
  async function newGuideDialog() {
    const v = await promptBox('Nuova guida', 'Posizione in pixel. Scrivi un numero per una guida verticale, oppure "o" davanti per orizzontale (es. o540).', String(Math.round(doc.w / 2)), 'Aggiungi');
    if (!v) return;
    const m = /^\s*([oOhH])?\s*(-?\d+(?:[.,]\d+)?)\s*$/.exec(v); if (!m) { toast('Scrivi un numero', true); return; }
    const n = parseFloat(m[2].replace(',', '.'));
    pguides()[m[1] ? 'h' : 'v'].push(n); S.view.guides = true; saveView(); commit();
  }
  function guideAt(sx, sy) {
    if (!S.view.guides) return null;
    const G = page().guides; if (!G) return null;
    for (let i = 0; i < G.v.length; i++) if (Math.abs(toScr(G.v[i], 0)[0] - sx) < 4) return { ax: 'v', i };
    for (let i = 0; i < G.h.length; i++) if (Math.abs(toScr(0, G.h[i])[1] - sy) < 4) return { ax: 'h', i };
    return null;
  }
  function startGuide(ax, i) {
    const G = pguides();
    if (i == null) { G[ax].push(ax === 'v' ? 0 : 0); i = G[ax].length - 1; S.view.guides = true; }
    S.drag = {
      move(x, y, ev) {
        let v = ax === 'v' ? x : y;
        if (!ev.shiftKey) { const r = Math.round(v); v = Math.abs(v - r) * S.zoom < 3 ? r : v; }
        // magnetica sui bordi e sul centro della tela
        for (const t of ax === 'v' ? [0, doc.w / 2, doc.w] : [0, doc.h / 2, doc.h]) if (Math.abs(v - t) * S.zoom < 6) v = t;
        G[ax][i] = Math.round(v * 10) / 10;
        S.drag.label = (ax === 'v' ? 'X ' : 'Y ') + Math.round(G[ax][i]);
        S.guideLabel = { ax, v: G[ax][i] };
      },
      end(ev) {
        S.guideLabel = null;
        const r = stage.getBoundingClientRect(), sx = ev.clientX - r.left, sy = ev.clientY - r.top;
        // trascinata fuori (sul righello o fuori dalla vista): si toglie
        if ((S.view.rulers && (ax === 'v' ? sx < RUL : sy < RUL)) || sx < 0 || sy < 0 || sx > r.width || sy > r.height) G[ax].splice(i, 1);
        commit();
      },
    };
  }
  function drawRulers(g, W, H) {
    const d = dpr();
    if (S.view.grid) {
      const gs = S.view.gridSize || 50;
      if (gs * S.zoom >= 6) {
        g.save(); const [x0, y0] = toScr(0, 0), [x1, y1] = toScr(doc.w, doc.h);
        g.beginPath(); g.rect(x0, y0, x1 - x0, y1 - y0); g.clip();
        g.strokeStyle = 'rgba(80,140,255,.28)'; g.lineWidth = 1; g.beginPath();
        for (let x = gs; x < doc.w; x += gs) { const sx = Math.round(toScr(x, 0)[0]) + 0.5; g.moveTo(sx, y0); g.lineTo(sx, y1); }
        for (let y = gs; y < doc.h; y += gs) { const sy = Math.round(toScr(0, y)[1]) + 0.5; g.moveTo(x0, sy); g.lineTo(x1, sy); }
        g.stroke(); g.restore();
      }
    }
    const G = page().guides;
    if (S.view.guides && G) {
      g.save(); g.strokeStyle = '#00C2FF'; g.lineWidth = 1;
      for (const v of G.v) { const x = Math.round(toScr(v, 0)[0]) + 0.5; g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
      for (const v of G.h) { const y = Math.round(toScr(0, v)[1]) + 0.5; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
      g.restore();
    }
    if (!S.view.rulers) return;
    // passo delle tacche: il piu' piccolo "bello" con almeno 50 px sullo schermo
    const steps = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000];
    const step = steps.find((x) => x * S.zoom >= 56) || 10000;
    g.save();
    g.fillStyle = 'rgba(18,20,26,.94)'; g.fillRect(0, 0, W, RUL); g.fillRect(0, 0, RUL, H);
    g.strokeStyle = 'rgba(160,170,190,.45)'; g.fillStyle = 'rgba(190,200,215,.8)'; g.font = '500 9.5px -apple-system, "Segoe UI", sans-serif'; g.lineWidth = 1;
    const [ax0] = toDoc(RUL, 0), [ax1] = toDoc(W, 0), [, ay0] = toDoc(0, RUL), [, ay1] = toDoc(0, H);
    g.beginPath();
    for (let x = Math.floor(ax0 / step) * step; x <= ax1; x += step / 5) {
      const sx = Math.round(toScr(x, 0)[0]) + 0.5; if (sx < RUL) continue;
      const major = Math.abs(x / step - Math.round(x / step)) < 1e-6;
      g.moveTo(sx, RUL); g.lineTo(sx, major ? 4 : RUL - 5);
      if (major) g.fillText(String(Math.round(x)), sx + 3, 10);
    }
    for (let y = Math.floor(ay0 / step) * step; y <= ay1; y += step / 5) {
      const sy = Math.round(toScr(0, y)[1]) + 0.5; if (sy < RUL) continue;
      const major = Math.abs(y / step - Math.round(y / step)) < 1e-6;
      g.moveTo(RUL, sy); g.lineTo(major ? 4 : RUL - 5, sy);
      if (major) { g.save(); g.translate(10, sy + 3); g.rotate(-Math.PI / 2); g.fillText(String(Math.round(y)), 0, 0); g.restore(); }
    }
    g.stroke();
    // dove sta il mouse
    if (S.mouse) { g.strokeStyle = '#2F8BFF'; g.beginPath(); g.moveTo(Math.round(S.mouse[0]) + 0.5, 0); g.lineTo(Math.round(S.mouse[0]) + 0.5, RUL); g.moveTo(0, Math.round(S.mouse[1]) + 0.5); g.lineTo(RUL, Math.round(S.mouse[1]) + 0.5); g.stroke(); }
    g.fillStyle = 'rgba(18,20,26,1)'; g.fillRect(0, 0, RUL, RUL);
    g.strokeStyle = 'rgba(160,180,220,.12)'; g.beginPath(); g.moveTo(0, RUL + 0.5); g.lineTo(W, RUL + 0.5); g.moveTo(RUL + 0.5, 0); g.lineTo(RUL + 0.5, H); g.stroke();
    g.restore();
    void d;
  }

  // ------------------------------------------------------------ disegno
  let raf = 0, checker = null;
  function draw() { if (!raf && alive) raf = requestAnimationFrame(render); }
  function render() {
    raf = 0;
    const r = stage.getBoundingClientRect(), d = dpr();
    const W = Math.max(1, Math.round(r.width * d)), H = Math.max(1, Math.round(r.height * d));
    for (const c of [cv, ov]) if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
    const g = cv.getContext('2d');
    g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H);
    const k = S.zoom * d, ox = S.panX * d, oy = S.panY * d;
    // ombra della tela e scacchiera (trasparenza)
    g.save(); g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 30 * d; g.fillStyle = '#fff'; g.fillRect(ox, oy, doc.w * k, doc.h * k); g.restore();
    if (!page().bg) {
      if (!checker) { const c = document.createElement('canvas'); c.width = c.height = 16; const cg = c.getContext('2d'); cg.fillStyle = '#fff'; cg.fillRect(0, 0, 16, 16); cg.fillStyle = '#E6E8EC'; cg.fillRect(0, 0, 8, 8); cg.fillRect(8, 8, 8, 8); checker = g.createPattern(c, 'repeat'); }
      g.fillStyle = checker; g.fillRect(ox, oy, doc.w * k, doc.h * k);
    }
    if (sel.W !== doc.w || sel.H !== doc.h) sel.resize(doc.w, doc.h);
    const hide = new Set(S.editing ? [S.editing.id] : []);
    const ok = renderPage(g, doc, page(), { k, ox, oy }, assets, { hide });
    if (!ok) setTimeout(draw, 120);
    zoomLbl.textContent = Math.round(S.zoom * 100) + '%';
    renderOverlay();
  }

  function selBox() {
    const ls = selLayers();
    if (!ls.length) return null;
    if (ls.length === 1 && ls[0].type !== 'group' && ls[0].type !== 'adjust') return { l: ls[0], cs: corners(ls[0]), rot: ls[0].rot || 0 };
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const l of ls) { if (l.type === 'adjust') continue; const b = bounds(l); x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y); x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h); }
    if (!isFinite(x0)) return null;
    return { l: null, cs: [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], rot: 0, box: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 } };
  }
  function handles(sb) {
    // 8 maniglie + rotazione, in coordinate dello schermo
    const s = sb.cs.map(([x, y]) => toScr(x, y));
    const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const out = { nw: s[0], n: mid(s[0], s[1]), ne: s[1], e: mid(s[1], s[2]), se: s[2], s: mid(s[2], s[3]), sw: s[3], w: mid(s[3], s[0]) };
    const isText = sb.l && sb.l.type === 'text';
    if (isText) { delete out.n; delete out.s; }
    const a = sb.rot * Math.PI / 180;
    out.rot = [out.n ? out.n[0] + Math.sin(a) * 26 : mid(s[0], s[1])[0] + Math.sin(a) * 26, (out.n ? out.n[1] : mid(s[0], s[1])[1]) - Math.cos(a) * 26];
    return out;
  }
  function renderOverlay() {
    const d = dpr(), g = ov.getContext('2d');
    g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, ov.width, ov.height);
    const poly = (cs, color, w = 1, dash) => { g.beginPath(); cs.forEach(([x, y], i) => { const [a, b] = toScr(x, y); if (i) g.lineTo(a, b); else g.moveTo(a, b); }); g.closePath(); g.strokeStyle = color; g.lineWidth = w; g.setLineDash(dash || []); g.stroke(); g.setLineDash([]); };
    // passaggio del mouse
    if (S.hover && !S.sel.includes(S.hover) && S.tool === 'move' && !S.drag) {
      const r = findLayer(layers(), S.hover);
      if (r) { const b = r.layer.type === 'group' ? bounds(r.layer) : null; poly(b ? [[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]] : corners(r.layer), '#4F9BFF', 1); }
    }
    // guide magnetiche
    for (const gd of S.guides) {
      g.beginPath(); g.strokeStyle = '#FF3D9A'; g.lineWidth = 1;
      if (gd.x != null) { const [x] = toScr(gd.x, 0); g.moveTo(Math.round(x) + 0.5, 0); g.lineTo(Math.round(x) + 0.5, ov.height); }
      else { const [, y] = toScr(0, gd.y); g.moveTo(0, Math.round(y) + 0.5); g.lineTo(ov.width, Math.round(y) + 0.5); }
      g.stroke();
    }
    // selezione
    if (S.xf) drawXfOverlay(g);
    const sb = S.tool === 'move' && !S.editing && !S.xf ? selBox() : null;
    if (sb) {
      if (!sb.l) for (const l of selLayers()) if (l.type !== 'adjust') poly(l.type === 'group' ? (() => { const b = bounds(l); return [[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]]; })() : corners(l), 'rgba(79,155,255,.55)', 1);
      poly(sb.cs, '#2F8BFF', 1.5);
      const locked = selLayers().some((l) => l.locked);
      if (!locked && !S.drag) {
        const hs = handles(sb);
        const top = hs.n || [(toScr(...sb.cs[0])[0] + toScr(...sb.cs[1])[0]) / 2, (toScr(...sb.cs[0])[1] + toScr(...sb.cs[1])[1]) / 2];
        g.beginPath(); g.moveTo(top[0], top[1]); g.lineTo(hs.rot[0], hs.rot[1]); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1; g.stroke();
        for (const [k2, [x, y]] of Object.entries(hs)) {
          g.beginPath();
          if (k2 === 'rot') g.arc(x, y, 5.5, 0, Math.PI * 2);
          else if (k2.length === 1) { g.save(); g.translate(x, y); g.rotate(sb.rot * Math.PI / 180 + (k2 === 'e' || k2 === 'w' ? Math.PI / 2 : 0)); g.roundRect(-7, -3, 14, 6, 3); g.restore(); }
          else g.roundRect(x - 5, y - 5, 10, 10, 2.5);
          g.fillStyle = '#fff'; g.fill(); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1.5; g.stroke();
        }
      }
      // misure durante il trascinamento
      if (S.drag && S.drag.label) {
        const [x, y] = toScr(sb.cs[2][0], sb.cs[2][1]);
        g.font = '600 11px -apple-system, "Segoe UI", sans-serif';
        const tw = g.measureText(S.drag.label).width + 14;
        g.fillStyle = '#2F8BFF'; g.beginPath(); g.roundRect(x + 8, y + 8, tw, 20, 6); g.fill();
        g.fillStyle = '#fff'; g.fillText(S.drag.label, x + 15, y + 22);
      }
    }
    // selezione: il bordo (bianco e nero, si vede su tutto) e quella che si sta disegnando
    if (sel.on) {
      const o = sel.outline(), d0 = dpr();
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.imageSmoothingEnabled = false;
      const x = S.panX * d0, y = S.panY * d0, w = doc.w * S.zoom * d0, hh = doc.h * S.zoom * d0;
      g.globalAlpha = 0.9; g.filter = 'invert(1)'; g.drawImage(o, x + 1, y + 1, w, hh); g.filter = 'none'; g.globalAlpha = 1;
      g.drawImage(o, x, y, w, hh);
      g.restore();
    }
    if (S.selDraft) {
      const sd = S.selDraft;
      g.save(); g.strokeStyle = '#fff'; g.lineWidth = 1; g.setLineDash([5, 4]); g.shadowColor = 'rgba(0,0,0,.8)'; g.shadowBlur = 2;
      g.beginPath();
      if (sd.pts) sd.pts.forEach(([x0, y0], i) => { const [a, b] = toScr(x0, y0); if (i) g.lineTo(a, b); else g.moveTo(a, b); });
      else {
        const [a, b] = toScr(Math.min(sd.x0, sd.x1), Math.min(sd.y0, sd.y1)), [c, d1] = toScr(Math.max(sd.x0, sd.x1), Math.max(sd.y0, sd.y1));
        if (sd.kind === 'ellipse') g.ellipse((a + c) / 2, (b + d1) / 2, (c - a) / 2, (d1 - b) / 2, 0, 0, Math.PI * 2); else g.rect(a, b, c - a, d1 - b);
      }
      g.stroke(); g.restore();
    }
    // riquadro di selezione (trascinando sul vuoto)
    if (S.marq) {
      const [a, b] = toScr(S.marq.x0, S.marq.y0), [c, e] = toScr(S.marq.x1, S.marq.y1);
      g.fillStyle = 'rgba(47,139,255,.08)'; g.fillRect(Math.min(a, c), Math.min(b, e), Math.abs(c - a), Math.abs(e - b));
      g.strokeStyle = '#2F8BFF'; g.lineWidth = 1; g.strokeRect(Math.min(a, c) + 0.5, Math.min(b, e) + 0.5, Math.abs(c - a), Math.abs(e - b));
    }
    // ritaglio
    if (S.crop) {
      const c = S.crop, [x0, y0] = toScr(c.x, c.y), [x1, y1] = toScr(c.x + c.w, c.y + c.h);
      g.fillStyle = 'rgba(8,10,14,.62)';
      g.beginPath(); g.rect(0, 0, ov.width / d, ov.height / d); g.rect(x0, y0, x1 - x0, y1 - y0); g.fill('evenodd');
      g.strokeStyle = '#fff'; g.lineWidth = 1; g.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0);
      g.strokeStyle = 'rgba(255,255,255,.35)';
      for (let i = 1; i < 3; i++) { g.beginPath(); g.moveTo(x0 + (x1 - x0) * i / 3, y0); g.lineTo(x0 + (x1 - x0) * i / 3, y1); g.moveTo(x0, y0 + (y1 - y0) * i / 3); g.lineTo(x1, y0 + (y1 - y0) * i / 3); g.stroke(); }
      g.fillStyle = '#fff';
      for (const [x, y] of [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]) { g.fillRect(x - 5, y - 5, 10, 10); }
      g.font = '600 11px -apple-system, "Segoe UI", sans-serif'; const lab = Math.round(c.w) + ' × ' + Math.round(c.h);
      g.fillStyle = 'rgba(0,0,0,.6)'; g.beginPath(); g.roundRect(x0, y1 + 8, g.measureText(lab).width + 14, 20, 6); g.fill(); g.fillStyle = '#fff'; g.fillText(lab, x0 + 7, y1 + 22);
    }
    // pennello: il cerchio della punta
    if (S.tool === 'clone' && S.cloneSrc) {
      const [x, y] = toScr(...(S.cloneOff && S.drag ? [S.mouse ? toDoc(...S.mouse)[0] + S.cloneOff[0] : S.cloneSrc[0], S.mouse ? toDoc(...S.mouse)[1] + S.cloneOff[1] : S.cloneSrc[1]] : S.cloneSrc));
      g.strokeStyle = '#fff'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x - 8, y); g.lineTo(x + 8, y); g.moveTo(x, y - 8); g.lineTo(x, y + 8); g.stroke();
      g.strokeStyle = 'rgba(0,0,0,.6)'; g.beginPath(); g.arc(x, y, 5, 0, Math.PI * 2); g.stroke();
    }
    if (S.tool === 'pen') drawPenOverlay(g);
    if (S.healMask) {
      const d0 = dpr();
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 0.45;
      g.drawImage(S.healMask, S.panX * d0, S.panY * d0, doc.w * S.zoom * d0, doc.h * S.zoom * d0); g.restore();
    }
    if ((S.tool === 'brush' || S.tool === 'eraser' || S.tool === 'clone' || S.tool === 'heal') && S.mouse) {
      const r = S.brush.size / 2 * S.zoom;
      g.beginPath(); g.arc(S.mouse[0], S.mouse[1], Math.max(1, r), 0, Math.PI * 2); g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 2; g.stroke();
      g.beginPath(); g.arc(S.mouse[0], S.mouse[1], Math.max(1, r), 0, Math.PI * 2); g.strokeStyle = '#fff'; g.lineWidth = 1; g.stroke();
    }
    // forma che si sta disegnando
    if (S.drag && S.drag.kind === 'newshape') { const b = S.drag.box; poly([[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]], '#2F8BFF', 1, [4, 3]); }
    drawRulers(g, ov.width / d, ov.height / d);
    if (S.guideLabel) {
      const gl = S.guideLabel, [x, y] = toScr(gl.ax === 'v' ? gl.v : 0, gl.ax === 'h' ? gl.v : 0), lab2 = (gl.ax === 'v' ? 'X ' : 'Y ') + Math.round(gl.v);
      const px2 = gl.ax === 'v' ? x + 8 : (S.mouse ? S.mouse[0] + 12 : 40), py2 = gl.ax === 'h' ? y + 8 : (S.mouse ? S.mouse[1] + 12 : 40);
      g.font = '600 11px -apple-system, "Segoe UI", sans-serif'; const tw = g.measureText(lab2).width + 14;
      g.fillStyle = '#00A6DB'; g.beginPath(); g.roundRect(px2, py2, tw, 20, 6); g.fill(); g.fillStyle = '#fff'; g.fillText(lab2, px2 + 7, py2 + 14);
    }
  }

  // ------------------------------------------------------------ selezione dei livelli
  function select(ids, add) {
    if (S.xf && !(ids.length === 1 && ids[0] === S.xf.id && !add)) endFree(true);
    if (add) { for (const id of ids) { const i = S.sel.indexOf(id); if (i >= 0) S.sel.splice(i, 1); else S.sel.push(id); } } else S.sel = [...ids];
    S.maskEdit = S.maskEdit && !!(one() && one().mask);
    draw(); refresh();
  }
  // livello sotto il punto (dall'alto). deep = dentro i gruppi
  function hitAt(px, py, deep) {
    const ls = layers();
    for (let i = ls.length - 1; i >= 0; i--) {
      const l = ls[i];
      if (!l.visible || l.locked || l.type === 'adjust') continue;
      if (l.type === 'group') {
        const inner = hitIn(l.children || [], px, py);
        if (inner) return deep ? inner : l;
        continue;
      }
      if (hitLayer(l, px, py, toLocal, assets) && clipOk(ls, i, px, py)) return l;
    }
    return null;
  }
  // un livello ritagliato si vede (e si prende) solo dove c'e' il suo livello base
  function clipBase(list, i) { if (!list[i] || !list[i].clip) return null; let j = i - 1; while (j >= 0 && list[j].clip) j--; return j >= 0 ? list[j] : null; }
  function clipOk(list, i, px, py) { const b = clipBase(list, i); return !b || b.type === 'group' || b.type === 'adjust' || hitLayer(b, px, py, toLocal, assets); }
  function toggleClip(force) {
    const ls = selLayers(); if (!ls.length) return;
    const on = force != null ? force : !ls.every((l) => l.clip);
    let n = 0;
    for (const l of ls) { const f = findLayer(layers(), l.id); if (!f) continue; if (on && f.i === 0) continue; if (on) l.clip = true; else delete l.clip; n++; }
    if (!n) { toast('Serve un livello sotto a cui agganciarlo', true); return; }
    commit();
  }
  function hitIn(list, px, py) {
    for (let i = list.length - 1; i >= 0; i--) {
      const l = list[i];
      if (!l.visible || l.locked || l.type === 'adjust') continue;
      if (l.type === 'group') { const r = hitIn(l.children || [], px, py); if (r) return r; continue; }
      if (hitLayer(l, px, py, toLocal, assets) && clipOk(list, i, px, py)) return l;
    }
    return null;
  }
  function handleAt(sx, sy) {
    if (S.tool !== 'move' || selLayers().some((l) => l.locked)) return null;
    const sb = selBox(); if (!sb) return null;
    const hs = handles(sb);
    for (const [k, [x, y]] of Object.entries(hs)) if (Math.hypot(sx - x, sy - y) <= HANDLE) return { k, sb };
    return null;
  }

  // ------------------------------------------------------------ trascinamenti sulla tela
  let spaceDown = false;
  stage.addEventListener('pointerdown', (e) => {
    stage.focus({ preventScroll: true });
    if (S.editing) { if (e.target === cv || e.target === ov) stopEdit(true); else return; }
    const r = stage.getBoundingClientRect(), sx = e.clientX - r.left, sy = e.clientY - r.top;
    const [px, py] = toDoc(sx, sy);
    if (e.button === 1 || spaceDown || S.tool === 'hand') return startPan(e, sx, sy);
    if (e.button !== 0) return;
    (() => { try { stage.setPointerCapture(e.pointerId); } catch (er) { /* puntatore gia' rilasciato */ } })();
    // dal righello si tira fuori una guida
    if (S.view.rulers && (sx < RUL || sy < RUL)) { if (sx < RUL && sy < RUL) return; S.view.guides = true; startGuide(sy < RUL ? 'h' : 'v'); S.drag.move(px, py, e); draw(); return; }
    if (S.tool === 'move' || S.tool === 'select' || S.tool === 'shape' || S.tool === 'text') { const gd = guideAt(sx, sy); if (gd && !S.xf && !handleAt(sx, sy)) return startGuide(gd.ax, gd.i); }
    if (S.tool === 'crop') return startCrop(e, px, py, sx, sy);
    if (S.tool === 'eyedrop') return eyedrop(sx, sy);
    if ((S.tool === 'brush' || S.tool === 'eraser') && e.altKey) return eyedrop(sx, sy);
    if (S.tool === 'clone' && e.altKey) { S.cloneSrc = [px, py]; S.cloneOff = null; toast('Punto da copiare scelto: ora dipingi'); draw(); return; }
    if (S.tool === 'brush' || S.tool === 'eraser' || S.tool === 'clone') return startPaint(e, px, py);
    if (S.tool === 'select') return startSelect(e, px, py);
    if (S.tool === 'heal') return startHeal(e, px, py);
    if (S.tool === 'pen') return penDown(e, px, py, sx, sy);
    if (S.tool === 'shape') { S.drag = { kind: 'newshape', x0: px, y0: py, box: { x: px, y: py, w: 0, h: 0 }, move: (x, y, ev) => shapeMove(x, y, ev) }; return; }
    if (S.tool === 'text') {
      e.preventDefault();   // il fuoco resta al testo che si apre (non alla tela)
      const hit = hitAt(px, py, true);
      if (hit && hit.type === 'text') { select([hit.id]); startEdit(hit); return; }
      const l = textLayer(doc, { text: '', color: S.color, auto: true, align: 'left' });
      l.w = 20; l.x = px; l.y = py - l.size * 0.6;
      addLayer(l, true);
      setTool('move', true);
      startEdit(l, true);
      return;
    }
    // trasformazione libera in corso: si prendono i punti; fuori dal livello si applica
    if (S.xf) {
      const i = xfHit(sx, sy);
      if (i >= 0) return startXfDrag(e, i, px, py);
      const xl = xfLayer();
      if (xl && hitLayer(xl, px, py, toLocal, assets)) return startMove(e, px, py, false);
      endFree(true);
    }
    // sposta
    const hd = handleAt(sx, sy);
    if (hd) return startTransform(e, hd, px, py);
    const hit = hitAt(px, py, e.ctrlKey || e.metaKey);
    if (hit) {
      if (e.shiftKey) { select([hit.id], true); return; }
      if (!S.sel.includes(hit.id)) select([hit.id]);
      if (e.detail === 2 && hit.type === 'text') { startEdit(hit); return; }
      return startMove(e, px, py, e.altKey);
    }
    if (!e.shiftKey) select([]);
    S.marq = { x0: px, y0: py, x1: px, y1: py, add: e.shiftKey, base: [...S.sel] };
  });
  stage.addEventListener('dblclick', (e) => {
    const r = stage.getBoundingClientRect(); const [px, py] = toDoc(e.clientX - r.left, e.clientY - r.top);
    if (S.tool !== 'move') return;
    const hit = hitAt(px, py, true);
    if (hit && hit.type === 'text') { select([hit.id]); startEdit(hit); }
  });
  stage.addEventListener('pointermove', (e) => {
    const r = stage.getBoundingClientRect(), sx = e.clientX - r.left, sy = e.clientY - r.top;
    S.mouse = [sx, sy];
    const [px, py] = toDoc(sx, sy);
    if (S.pan) { S.panX = S.pan.x + (e.clientX - S.pan.cx); S.panY = S.pan.y + (e.clientY - S.pan.cy); draw(); return; }
    if (S.drag) { S.drag.move(px, py, e); draw(); return; }
    if (S.marq) {
      S.marq.x1 = px; S.marq.y1 = py;
      const x0 = Math.min(S.marq.x0, px), x1 = Math.max(S.marq.x0, px), y0 = Math.min(S.marq.y0, py), y1 = Math.max(S.marq.y0, py);
      const ids = layers().filter((l) => l.visible && !l.locked && l.type !== 'adjust').filter((l) => { const b = bounds(l); return b.x < x1 && b.x + b.w > x0 && b.y < y1 && b.y + b.h > y0; }).map((l) => l.id);
      S.sel = S.marq.add ? [...new Set([...S.marq.base, ...ids])] : ids;
      draw(); return;
    }
    if (S.cropDrag) { S.cropDrag(px, py, e); draw(); return; }
    if (S.tool === 'shape' && S.drag === undefined) { /* niente */ }
    if (S.tool === 'shape' && S.drag && S.drag.kind === 'newshape') return;
    // cursore e passaggio
    let cur = '';
    if (S.tool === 'move' && S.xf) cur = xfHit(sx, sy) >= 0 ? 'pointer' : '';
    else if (S.tool === 'move') {
      const hd = handleAt(sx, sy);
      if (hd) cur = hd.k === 'rot' ? 'grab' : cursorFor(hd.k, hd.sb.rot);
      const hit = hd ? null : hitAt(px, py, e.ctrlKey || e.metaKey);
      const hv = hit ? hit.id : null;
      if (hv !== S.hover) { S.hover = hv; draw(); }
      if (!cur && hit) cur = 'move';
    } else if (S.tool === 'hand' || spaceDown) cur = 'grab';
    else if (S.tool === 'text') cur = 'text';
    else if (S.tool === 'brush' || S.tool === 'eraser' || S.tool === 'clone' || S.tool === 'heal') { cur = 'none'; draw(); }
    else if (S.tool === 'select') cur = S.selMode === 'wand' ? 'pointer' : 'crosshair';
    else if (S.tool === 'pen') { cur = penHit(sx, sy) ? 'pointer' : 'crosshair'; if (S.pen) draw(); }
    else if (S.tool === 'shape' || S.tool === 'crop' || S.tool === 'eyedrop') cur = 'crosshair';
    if (S.view.rulers && (sx < RUL || sy < RUL)) { cur = sy < RUL && sx >= RUL ? 'row-resize' : sx < RUL && sy >= RUL ? 'col-resize' : 'default'; draw(); }
    else if (!S.drag && (S.tool === 'move' || S.tool === 'select' || S.tool === 'shape' || S.tool === 'text')) { const gd = guideAt(sx, sy); if (gd && !(cur && cur !== 'move')) cur = gd.ax === 'v' ? 'col-resize' : 'row-resize'; }
    if (S.view.rulers) draw();
    stage.style.cursor = cur;
  });
  const endDrag = (e) => {
    if (S.pan) { S.pan = null; stage.style.cursor = spaceDown || S.tool === 'hand' ? 'grab' : ''; return; }
    if (S.drag) {
      const d = S.drag; S.drag = null; S.guides = [];
      if (d.kind === 'newshape') finishShape(d, e);
      else if (d.end) d.end(e);
      draw(); return;
    }
    if (S.marq) { S.marq = null; draw(); refresh(); return; }
    if (S.cropDrag) { S.cropDrag = null; draw(); }
  };
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);
  stage.addEventListener('pointerleave', () => { S.mouse = null; if (S.hover) { S.hover = null; } draw(); });
  stage.addEventListener('wheel', (e) => {
    e.preventDefault();
    const r = stage.getBoundingClientRect();
    if (e.ctrlKey || e.metaKey) { zoomAt(S.zoom * Math.exp(-e.deltaY * 0.0022), e.clientX - r.left, e.clientY - r.top); return; }
    S.panX -= e.shiftKey ? e.deltaY : e.deltaX; S.panY -= e.shiftKey ? 0 : e.deltaY; draw();
  }, { passive: false });

  function cursorFor(k, rot) {
    const dirs = ['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'];
    const i = (dirs.indexOf(k) + Math.round(((rot % 360) + 360) % 360 / 45)) % 8;
    return ['ns-resize', 'nesw-resize', 'ew-resize', 'nwse-resize', 'ns-resize', 'nesw-resize', 'ew-resize', 'nwse-resize'][i];
  }
  function startPan(e, sx, sy) { S.pan = { x: S.panX, y: S.panY, cx: e.clientX, cy: e.clientY }; (() => { try { stage.setPointerCapture(e.pointerId); } catch (er) { /* puntatore gia' rilasciato */ } })(); stage.style.cursor = 'grabbing'; }

  // magnetismo: bordi e centri della tela e degli altri livelli
  function snapMove(box, dx, dy) {
    S.guides = [];
    if (!S.snap) return [dx, dy];
    const th = 6 / S.zoom;
    const xs = [0, doc.w / 2, doc.w], ys = [0, doc.h / 2, doc.h];
    for (const l of flatVisible(layers())) {
      if (S.sel.includes(l.id) || l.type === 'adjust') continue;
      const b = bounds(l); xs.push(b.x, b.x + b.w / 2, b.x + b.w); ys.push(b.y, b.y + b.h / 2, b.y + b.h);
    }
    const G = page().guides;
    if (S.view.guides && G) { xs.push(...G.v); ys.push(...G.h); }
    if (S.view.grid && S.view.gridSize >= 2) {
      const gs = S.view.gridSize, near = (v) => Math.round(v / gs) * gs;
      xs.push(near(box.x + dx), near(box.x + dx + box.w)); ys.push(near(box.y + dy), near(box.y + dy + box.h));
    }
    const mx = [box.x + dx, box.x + dx + box.w / 2, box.x + dx + box.w], my = [box.y + dy, box.y + dy + box.h / 2, box.y + dy + box.h];
    let bx = null, by = null;
    for (const a of mx) for (const t of xs) if (Math.abs(a - t) < th && (!bx || Math.abs(a - t) < Math.abs(bx.d))) bx = { d: t - a, t };
    for (const a of my) for (const t of ys) if (Math.abs(a - t) < th && (!by || Math.abs(a - t) < Math.abs(by.d))) by = { d: t - a, t };
    if (bx) { dx += bx.d; S.guides.push({ x: bx.t }); }
    if (by) { dy += by.d; S.guides.push({ y: by.t }); }
    return [dx, dy];
  }

  function startMove(e, px, py, dup) {
    let ls = selLayers().filter((l) => !l.locked);
    if (!ls.length) return;
    if (dup) { duplicateSel(true); ls = selLayers(); }
    const orig = ls.map((l) => clone(l));
    const sb = selBox(); const box = sb.box || bounds(ls[0]);
    let moved = false;
    S.drag = {
      move(x, y, ev) {
        let dx = x - px, dy = y - py;
        if (ev.shiftKey) { if (Math.abs(dx) > Math.abs(dy)) dy = 0; else dx = 0; }
        [dx, dy] = snapMove(box, dx, dy);
        if (Math.abs(dx) + Math.abs(dy) > 0) moved = true;
        ls.forEach((l, i) => { const o = orig[i]; const cur = clone(o); moveBy(cur, dx, dy); Object.assign(l, cur.type === 'group' ? { children: cur.children } : { x: cur.x, y: cur.y }); });
        S.drag.label = 'X ' + Math.round(box.x + dx) + '  Y ' + Math.round(box.y + dy);
      },
      end() { if (moved || dup) commit(); },
    };
  }

  function startTransform(e, hd, px, py) {
    const ls = selLayers().filter((l) => !l.locked);
    const orig = ls.map((l) => clone(l));
    const sb = hd.sb, single = sb.l;
    if (hd.k === 'rot') {
      const c = single ? [single.x + single.w / 2, single.y + single.h / 2] : [sb.box.x + sb.box.w / 2, sb.box.y + sb.box.h / 2];
      const a0 = Math.atan2(py - c[1], px - c[0]);
      S.drag = {
        move(x, y, ev) {
          let da = (Math.atan2(y - c[1], x - c[0]) - a0) * 180 / Math.PI;
          ls.forEach((l, i) => {
            const o = orig[i];
            let r = ((o.rot || 0) + da);
            if (ev.shiftKey) r = Math.round(r / 15) * 15; else if (Math.abs(((r % 90) + 90) % 90) < 2.5 || Math.abs(((r % 90) + 90) % 90) > 87.5) r = Math.round(r / 90) * 90;
            const dr = r - (o.rot || 0);
            const rotOne = (t, src) => {
              if (t.type === 'group') { t.children.forEach((ch, j) => rotOne(ch, src.children[j])); return; }
              if (t.type === 'adjust') return;
              const a = dr * Math.PI / 180, cx = src.x + src.w / 2 - c[0], cy = src.y + src.h / 2 - c[1];
              const nx = c[0] + cx * Math.cos(a) - cy * Math.sin(a), ny = c[1] + cx * Math.sin(a) + cy * Math.cos(a);
              t.x = nx - t.w / 2; t.y = ny - t.h / 2; t.rot = ((((src.rot || 0) + dr) % 360) + 360) % 360; if (t.rot > 180) t.rot -= 360;
            };
            rotOne(l, o);
          });
          S.drag.label = Math.round(single ? single.rot : da) + '°';
        },
        end() { commit(); },
      };
      return;
    }
    // ridimensionamento: l'angolo opposto resta fermo
    const k = hd.k;
    const ax = k.includes('w') ? 1 : k.includes('e') ? -1 : 0, ay = k.includes('n') ? 1 : k.includes('s') ? -1 : 0;   // da dove si tira
    const R = single ? (single.rot || 0) * Math.PI / 180 : 0, cs = Math.cos(R), sn = Math.sin(R);
    const ob = single ? { x: single.x, y: single.y, w: single.w, h: single.h } : { ...sb.box };
    const ctr = [ob.x + ob.w / 2, ob.y + ob.h / 2];
    const anchorLocal = [ax * ob.w / 2, ay * ob.h / 2];
    const anchor = [ctr[0] + anchorLocal[0] * cs - anchorLocal[1] * sn, ctr[1] + anchorLocal[0] * sn + anchorLocal[1] * cs];
    const isText = single && single.type === 'text';
    const keepRatio = (ev) => (single && (single.type === 'image' || single.type === 'group' || (isText && ax && ay))) || !single ? !ev.shiftKey : ev.shiftKey;
    S.drag = {
      move(x, y, ev) {
        // punto del mouse nelle coordinate del riquadro (ruotato), rispetto all'angolo fermo
        const dx = x - anchor[0], dy = y - anchor[1];
        let lx = dx * cs + dy * sn, ly = -dx * sn + dy * cs;
        let nw = ax ? Math.abs(lx) : ob.w, nh = ay ? Math.abs(ly) : ob.h;
        if (ax && Math.sign(lx) === ax) nw = 1;
        if (ay && Math.sign(ly) === ay) nh = 1;
        if (keepRatio(ev) && ax && ay) { const kk = Math.max(nw / ob.w, nh / ob.h); nw = ob.w * kk; nh = ob.h * kk; }
        if (ev.altKey) { /* dal centro */ }
        nw = Math.max(1, nw); nh = Math.max(1, nh);
        const kx = nw / ob.w, ky = nh / ob.h;
        // nuovo centro
        const nlx = -ax * nw / 2, nly = -ay * nh / 2;
        const ncx = anchor[0] + nlx * cs - nly * sn, ncy = anchor[1] + nlx * sn + nly * cs;
        if (single) {
          const l = ls[0], o = orig[0];
          if (single.type === 'group') {
            Object.assign(l, clone(o)); scaleAround(l, ob.x + (ax === 1 ? ob.w : ax === -1 ? 0 : ob.w / 2), ob.y + (ay === 1 ? ob.h : ay === -1 ? 0 : ob.h / 2), kx, ky);
          } else if (isText) {
            if (ax && ay) { const kk = nw / ob.w; l.size = Math.max(4, o.size * kk); l.w = Math.max(10, o.w * kk); l.letter = (o.letter || 0) * kk; if (o.onPath) l.h = Math.max(10, o.h * kk); }
            else { l.w = Math.max(10, nw); l.auto = false; }
            l.h = o.onPath ? (ax && ay ? l.h : o.h) : textHeight(l);
            // l'angolo (o il lato) da cui non si tira resta fermo; sui lati resta fermo anche il bordo in alto
            const lx2 = -ax * l.w / 2, ly2 = ay ? -ay * l.h / 2 : (l.h - o.h) / 2;
            const c2x = anchor[0] + lx2 * cs - ly2 * sn, c2y = anchor[1] + lx2 * sn + ly2 * cs;
            l.x = c2x - l.w / 2; l.y = c2y - l.h / 2;
          } else {
            l.w = nw; l.h = nh; l.x = ncx - nw / 2; l.y = ncy - nh / 2;
            if (o.fx && o.fx.stroke) { /* il contorno resta della stessa misura */ }
          }
          S.drag.label = Math.round(l.w) + ' × ' + Math.round(isText ? l.h : l.h);
        } else {
          const ox = ax === 1 ? ob.x + ob.w : ax === -1 ? ob.x : ob.x + ob.w / 2, oy = ay === 1 ? ob.y + ob.h : ay === -1 ? ob.y : ob.y + ob.h / 2;
          ls.forEach((l, i) => { const c = clone(orig[i]); scaleAround(c, ox, oy, kx, ky); Object.assign(l, c); });
          S.drag.label = Math.round(nw) + ' × ' + Math.round(nh);
        }
      },
      end() { commit(); },
    };
  }

  function finishShape(d, e) {
    let b = d.box;
    if (b.w < 3 && b.h < 3) {   // un clic: forma di misura standard
      const s = Math.round(Math.min(doc.w, doc.h) * 0.3);
      b = { x: d.x0 - s / 2, y: d.y0 - s / 2, w: s, h: S.shape === 'line' ? Math.max(4, s / 40) : s };
    }
    const l = shapeLayer(S.shape, b.x, b.y, Math.max(1, b.w), Math.max(1, b.h), { fill: S.colorSet ? S.color : '#2F8BFF' });
    if (S.shape === 'line') { l.h = Math.max(2, Math.round(Math.min(doc.w, doc.h) / 150)); l.y = b.y + b.h / 2 - l.h / 2; l.w = Math.max(10, Math.hypot(b.w, b.h)); }
    addLayer(l);
    setTool('move');
    void e;
  }
  // forma: aggiorna il riquadro mentre si trascina
  const shapeMove = (px, py, ev) => {
    const d = S.drag; let w = px - d.x0, hh = py - d.y0;
    if (ev.shiftKey) { const m = Math.max(Math.abs(w), Math.abs(hh)); w = Math.sign(w || 1) * m; hh = Math.sign(hh || 1) * m; }
    d.box = { x: Math.min(d.x0, d.x0 + w), y: Math.min(d.y0, d.y0 + hh), w: Math.abs(w), h: Math.abs(hh) };
    if (ev.altKey) d.box = { x: d.x0 - Math.abs(w), y: d.y0 - Math.abs(hh), w: Math.abs(w) * 2, h: Math.abs(hh) * 2 };
  };

  // ------------------------------------------------------------ pennello e gomma (pittura o maschera del livello)
  function paintTarget() {
    let l = one();
    if (S.tool === 'clone') {
      if (l && l.type === 'paint') return { l, mask: false };
      l = paintLayer(doc); l.name = tr('Timbro clone'); addLayer(l, true);
      return { l, mask: false };
    }
    if (S.tool === 'eraser' && l && l.type !== 'paint' && l.type !== 'group' && l.type !== 'adjust') return { l, mask: true };
    if (l && S.maskEdit && l.mask) return { l, mask: true };
    if (l && l.type === 'paint') return { l, mask: false };
    if (S.tool === 'eraser') { toast('Scegli un livello da cancellare', true); return null; }
    // nuovo livello di pittura sopra quello scelto
    l = paintLayer(doc);
    addLayer(l, true);
    return { l, mask: false };
  }
  function startPaint(e, px, py) {
    const cloning = S.tool === 'clone';
    if (cloning && !S.cloneSrc) { toast('Alt + clic sul punto da copiare, poi dipingi dove vuoi', true); return; }
    const t = paintTarget(); if (!t) return;
    const l = t.l;
    if (l.locked) { toast('Il livello è bloccato', true); return; }
    let base;
    if (t.mask) {
      if (!l.mask) {
        const iw = Math.min(2048, Math.round(l.type === 'image' && l.iw ? l.iw : l.w)), ihh = Math.max(1, Math.round(iw * l.h / l.w));
        base = document.createElement('canvas'); base.width = iw; base.height = ihh;
        const g0 = base.getContext('2d'); g0.fillStyle = '#fff'; g0.fillRect(0, 0, iw, ihh);
        l.mask = { src: storeCanvas(base, 'mask'), on: true };
      } else {
        const a = assets.get(l.mask.src); if (!a) { toast('Maschera non ancora pronta', true); return; }
        base = document.createElement('canvas'); base.width = a.w; base.height = a.h; base.getContext('2d').drawImage(a.el, 0, 0);
      }
    } else {
      base = document.createElement('canvas'); base.width = Math.max(1, Math.round(l.w)); base.height = Math.max(1, Math.round(l.h));
      const a = l.src ? assets.get(l.src) : null;
      if (a) base.getContext('2d').drawImage(a.el, 0, 0, base.width, base.height);
    }
    const sx = base.width / l.w, sy = base.height / l.h;
    const stroke = document.createElement('canvas'); stroke.width = base.width; stroke.height = base.height;
    const out = document.createElement('canvas'); out.width = base.width; out.height = base.height;
    const sg = stroke.getContext('2d'), og = out.getContext('2d');
    const erase = S.tool === 'eraser';
    const color = t.mask || cloning ? '#fff' : S.color;
    const rad = Math.max(0.5, S.brush.size / 2 * sx);
    // il tratto si ridisegna intero a ogni movimento: bordi lisci, niente "perline" tra un punto e l'altro
    const pts = [];
    const hard = S.brush.hard;
    const strokePath = () => {
      sg.clearRect(0, 0, stroke.width, stroke.height);
      if (!pts.length) return;
      sg.save();
      sg.lineCap = 'round'; sg.lineJoin = 'round';
      const far = 100000, soft = hard < 0.98;
      sg.strokeStyle = color; sg.fillStyle = color;
      sg.lineWidth = soft ? 2 * rad * (0.3 + 0.7 * hard) : 2 * rad;
      if (soft) { sg.shadowColor = color; sg.shadowBlur = rad * (1 - hard) * 1.6 + 1; sg.shadowOffsetX = far; sg.translate(-far, 0); }
      // tavoletta grafica: lo spessore segue la pressione della penna
      if (pts.some((q) => q[2] != null && q[2] < 0.99) && pts.length > 1) {
        const bw = sg.lineWidth;
        for (let i = 1; i < pts.length; i++) {
          const a = pts[i - 1], b = pts[i];
          sg.lineWidth = Math.max(0.5, bw * (((a[2] == null ? 1 : a[2]) + (b[2] == null ? 1 : b[2])) / 2));
          sg.beginPath(); sg.moveTo(a[0], a[1]); sg.lineTo(b[0], b[1]); sg.stroke();
        }
        sg.restore();
        return;
      }
      sg.beginPath();
      if (pts.length === 1) { sg.arc(pts[0][0], pts[0][1], sg.lineWidth / 2, 0, Math.PI * 2); sg.fill(); }
      else {
        sg.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length - 1; i++) { const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2; sg.quadraticCurveTo(pts[i][0], pts[i][1], mx, my); }
        sg.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
        sg.stroke();
      }
      sg.restore();
    };
    const mem = 'live_' + l.id + '.png';
    // dentro la selezione (se c'e'): il tratto fuori non conta
    const selClip = sel.on ? sel.toLayer(l, base.width, base.height) : null;
    // timbro clone: l'immagine (tutti i livelli) spostata dal punto scelto con Alt
    let cloneImg = null;
    if (cloning) {
      if (S.cloneOff == null || !S.cloneAligned) S.cloneOff = [S.cloneSrc[0] - px, S.cloneSrc[1] - py];
      const ks = Math.min(1, 4096 / Math.max(doc.w, doc.h));
      const src = document.createElement('canvas'); src.width = Math.round(doc.w * ks); src.height = Math.round(doc.h * ks);
      renderPage(src.getContext('2d'), doc, page(), { k: ks, ox: 0, oy: 0 }, assets, { store: new Map(), hide: new Set([l.id]) });
      const [ox, oy] = S.cloneOff;
      cloneImg = mapToLayer(l, base.width, base.height, (g) => g.drawImage(src, -ox, -oy, doc.w, doc.h));
    }
    const tmp = selClip || cloneImg ? document.createElement('canvas') : null;
    if (tmp) { tmp.width = base.width; tmp.height = base.height; }
    const compose = () => {
      og.globalCompositeOperation = 'copy'; og.globalAlpha = 1; og.drawImage(base, 0, 0);
      let s = stroke;
      if (tmp) {
        const tg = tmp.getContext('2d');
        tg.globalCompositeOperation = 'copy';
        if (cloneImg) { tg.drawImage(cloneImg, 0, 0); tg.globalCompositeOperation = 'destination-in'; tg.drawImage(stroke, 0, 0); }
        else tg.drawImage(stroke, 0, 0);
        if (selClip) { tg.globalCompositeOperation = 'destination-in'; tg.drawImage(selClip, 0, 0); }
        tg.globalCompositeOperation = 'source-over';
        s = tmp;
      }
      og.globalAlpha = S.brush.opacity;
      // gomma: toglie (sulla maschera: nasconde); pennello sulla maschera: rimette
      og.globalCompositeOperation = erase ? 'destination-out' : (!t.mask && l.lockAlpha ? 'source-atop' : 'source-over');
      og.drawImage(s, 0, 0);
      og.globalAlpha = 1; og.globalCompositeOperation = 'source-over';
      assets.put(mem, out);
    };
    if (erase && !t.mask && l.lockAlpha) { toast('La trasparenza del livello è bloccata: la gomma non può cancellare', true); return; }
    const origSrc = t.mask ? l.mask.src : l.src;
    if (t.mask) l.mask.src = mem; else l.src = mem;
    const pen = e.pointerType === 'pen';
    const dab = (x, y, straight, pr) => {
      const [lx, ly] = toLocal(l, x, y);
      if (straight && pts.length > 1) pts.length = 1;
      pts.push([lx * sx, ly * sy, pen && pr > 0 ? Math.min(1, pr * 1.25) : null]);
      strokePath();
    };
    dab(px, py, false, e.pressure); compose(); draw();
    S.drag = {
      move(x, y, ev) { dab(x, y, ev.shiftKey, ev.pressure); compose(); },
      end() {
        const name = storeCanvas(out, t.mask ? 'mask' : 'paint');
        if (t.mask) l.mask.src = name; else { l.src = name; l.iw = out.width; }
        void origSrc;
        commit();
      },
    };
  }

  // ------------------------------------------------------------ penna: tracciati di Bezier (forme libere, sempre modificabili)
  const localToDoc = (l, lx, ly) => {
    const cx = l.x + l.w / 2, cy = l.y + l.h / 2, a = (l.rot || 0) * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
    let x = lx - l.w / 2, y = ly - l.h / 2; if (l.flipX) x = -x; if (l.flipY) y = -y;
    return [cx + x * c - y * s, cy + x * s + y * c];
  };
  const penLayer = () => { const l = one(); return l && (l.type === 'path' || (l.type === 'text' && l.onPath)) && !l.locked ? l : null; };
  // punto 0..1 del tracciato -> coordinate locali del livello (dentro il margine)
  const pin = (l, u, v) => { const m = pathPad(l); return [m + u * (l.w - 2 * m), m + v * (l.h - 2 * m)]; };
  // punti del tracciato scelto, sullo schermo: [{k:'a'|'i'|'o', i, x, y}]
  function penHandles() {
    const l = penLayer(); if (!l || S.pen) return [];
    const out = [];
    l.pts.forEach((p, i) => {
      const A = toScr(...localToDoc(l, ...pin(l, p.x, p.y)));
      out.push({ k: 'a', i, x: A[0], y: A[1] });
      if (S.penSel === i) {
        if (p.ix || p.iy) { const H = toScr(...localToDoc(l, ...pin(l, p.x + p.ix, p.y + p.iy))); out.push({ k: 'i', i, x: H[0], y: H[1], ax: A[0], ay: A[1] }); }
        if (p.ox || p.oy) { const H = toScr(...localToDoc(l, ...pin(l, p.x + p.ox, p.y + p.oy))); out.push({ k: 'o', i, x: H[0], y: H[1], ax: A[0], ay: A[1] }); }
      }
    });
    return out;
  }
  function penHit(sx, sy) {
    if (S.pen && S.pen.pts.length > 1) { const [x, y] = toScr(S.pen.pts[0].x, S.pen.pts[0].y); if (Math.hypot(sx - x, sy - y) < 9) return { k: 'close' }; }
    return penHandles().reverse().find((p) => Math.hypot(sx - p.x, sy - p.y) < 8) || null;
  }
  function drawPenOverlay(g) {
    const dot = (x, y, on, round) => { g.beginPath(); if (round) g.arc(x, y, 4, 0, Math.PI * 2); else g.rect(x - 4, y - 4, 8, 8); g.fillStyle = on ? '#2F8BFF' : '#fff'; g.fill(); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1.5; g.stroke(); };
    if (S.pen) {
      const P = S.pen.pts;
      g.save(); g.beginPath();
      P.forEach((p, i) => {
        const [x, y] = toScr(p.x, p.y);
        if (!i) { g.moveTo(x, y); return; }
        const a = P[i - 1];
        const c1 = toScr(a.x + (a.ox || 0), a.y + (a.oy || 0)), c2 = toScr(p.x + (p.ix || 0), p.y + (p.iy || 0));
        g.bezierCurveTo(c1[0], c1[1], c2[0], c2[1], x, y);
      });
      if (S.mouse && !S.drag && P.length) { const a = P[P.length - 1], c1 = toScr(a.x + (a.ox || 0), a.y + (a.oy || 0)); g.quadraticCurveTo(c1[0], c1[1], S.mouse[0], S.mouse[1]); }
      g.strokeStyle = '#2F8BFF'; g.lineWidth = 1.5; g.stroke(); g.restore();
      P.forEach((p, i) => {
        const [x, y] = toScr(p.x, p.y);
        if (i === P.length - 1 && (p.ox || p.oy)) {
          for (const [hx, hy] of [[p.x + p.ox, p.y + p.oy], [p.x + (p.ix || 0), p.y + (p.iy || 0)]]) { const [a, b] = toScr(hx, hy); g.beginPath(); g.moveTo(x, y); g.lineTo(a, b); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1; g.stroke(); dot(a, b, false, true); }
        }
        dot(x, y, i === 0 && P.length > 1, false);
      });
      return;
    }
    const l = penLayer(); if (!l) return;
    // contorno del tracciato e i suoi punti
    g.save();
    const [cx, cy] = toScr(l.x + l.w / 2, l.y + l.h / 2);
    g.translate(cx, cy); g.rotate((l.rot || 0) * Math.PI / 180); g.scale(l.flipX ? -1 : 1, l.flipY ? -1 : 1);
    { const m = pathPad(l) * S.zoom; pathTrace(g, l, -l.w * S.zoom / 2 + m, -l.h * S.zoom / 2 + m, l.w * S.zoom - 2 * m, l.h * S.zoom - 2 * m); }
    g.restore(); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1; g.stroke();
    for (const p of penHandles()) {
      if (p.k !== 'a') { g.beginPath(); g.moveTo(p.ax, p.ay); g.lineTo(p.x, p.y); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1; g.stroke(); dot(p.x, p.y, false, true); }
      else dot(p.x, p.y, S.penSel === p.i, false);
    }
  }
  function penDown(e, px, py, sx, sy) {
    const hit = penHit(sx, sy);
    if (hit && hit.k === 'close') { finishPen(true); return; }
    // modifica di un tracciato esistente: punti e maniglie
    if (hit && !S.pen) {
      const l = penLayer(), p = l.pts[hit.i];
      if (hit.k === 'a' && e.detail === 2) {   // doppio clic su un punto: angolo <-> curva
        if (p.ix || p.iy || p.ox || p.oy) { p.ix = p.iy = p.ox = p.oy = 0; }
        else { const n = l.pts[(hit.i + 1) % l.pts.length], q = l.pts[(hit.i - 1 + l.pts.length) % l.pts.length]; const dx = (n.x - q.x) / 4, dy = (n.y - q.y) / 4; p.ox = dx; p.oy = dy; p.ix = -dx; p.iy = -dy; }
        commit(); return;
      }
      S.penSel = hit.i;
      const orig = clone(l);
      S.drag = {
        move(x, y, ev) {
          const [lx, ly] = toLocal(orig, x, y);
          const m0 = pathPad(orig), nx = (lx - m0) / (orig.w - 2 * m0), ny = (ly - m0) / (orig.h - 2 * m0), q = l.pts[hit.i], o = orig.pts[hit.i];
          if (hit.k === 'a') { const dx = nx - o.x, dy = ny - o.y; q.x = o.x + dx; q.y = o.y + dy; }
          else if (hit.k === 'o') { q.ox = nx - o.x; q.oy = ny - o.y; if (!ev.altKey) { q.ix = -q.ox; q.iy = -q.oy; } }
          else { q.ix = nx - o.x; q.iy = ny - o.y; if (!ev.altKey) { q.ox = -q.ix; q.oy = -q.iy; } }
          dropCache(l.id);
        },
        end() { refitPath(l); commit(); },
      };
      draw(); return;
    }
    // disegno di un tracciato nuovo
    if (!S.pen) { S.pen = { pts: [] }; S.penSel = null; }
    const p = { x: px, y: py, ix: 0, iy: 0, ox: 0, oy: 0 };
    S.pen.pts.push(p);
    S.drag = {
      move(x, y) { const dx = x - p.x, dy = y - p.y; if (Math.hypot(dx, dy) * S.zoom < 3) { p.ox = p.oy = p.ix = p.iy = 0; return; } p.ox = dx; p.oy = dy; p.ix = -dx; p.iy = -dy; },
      end() { draw(); },
    };
    if (e.detail === 2 && S.pen.pts.length > 2) { S.pen.pts.pop(); finishPen(false); S.drag = null; }
    paintOpts(); draw();
  }
  // riquadro attorno alla curva (anche dove esce dai punti)
  function curveBox(pts, closed) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    const add = (x, y) => { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); };
    const segs = pts.map((a, i) => [a, pts[i + 1]]).slice(0, closed ? pts.length : pts.length - 1).map(([a, b]) => [a, b || pts[0]]);
    if (!segs.length) pts.forEach((p) => add(p.x, p.y));
    for (const [a, b] of segs) {
      const P0 = [a.x, a.y], P1 = [a.x + (a.ox || 0), a.y + (a.oy || 0)], P2 = [b.x + (b.ix || 0), b.y + (b.iy || 0)], P3 = [b.x, b.y];
      for (let t = 0; t <= 1.0001; t += 0.05) {
        const u = 1 - t;
        add(u * u * u * P0[0] + 3 * u * u * t * P1[0] + 3 * u * t * t * P2[0] + t * t * t * P3[0], u * u * u * P0[1] + 3 * u * u * t * P1[1] + 3 * u * t * t * P2[1] + t * t * t * P3[1]);
      }
    }
    return { x: x0, y: y0, w: Math.max(1, x1 - x0), h: Math.max(1, y1 - y0) };
  }
  function finishPen(closed) {
    const pen = S.pen; S.pen = null;
    if (!pen || pen.pts.length < 2) { paintOpts(); draw(); return; }
    const color = S.colorSet ? S.color : '#2F8BFF';
    const sw = closed ? 0 : Math.max(2, Math.round(Math.min(doc.w, doc.h) / 200));
    const b = curveBox(pen.pts, closed), m = sw / 2;
    const B = { x: b.x - m, y: b.y - m, w: b.w + 2 * m, h: b.h + 2 * m };
    // punti 0..1 dentro il riquadro senza il margine del bordo
    const pts = pen.pts.map((p) => ({ x: (p.x - b.x) / b.w, y: (p.y - b.y) / b.h, ix: (p.ix || 0) / b.w, iy: (p.iy || 0) / b.h, ox: (p.ox || 0) / b.w, oy: (p.oy || 0) / b.h }));
    const l = { id: uid(), type: 'path', name: tr('Tracciato'), visible: true, locked: false, opacity: 1, blend: 'normal', rot: 0, flipX: false, flipY: false,
      pts, closed, fill: closed ? color : '', stroke: closed ? '' : color, strokeW: sw, x: B.x, y: B.y, w: B.w, h: B.h };
    addLayer(l);
    S.penSel = null;
    paintOpts();
  }
  // dopo aver spostato i punti: il riquadro torna attorno alla curva (la forma non si muove)
  function refitPath(l) {
    const m = pathPad(l);
    const iw = l.w - 2 * m, ih = l.h - 2 * m;
    const abs = l.pts.map((p) => ({ x: p.x * iw, y: p.y * ih, ix: p.ix * iw, iy: p.iy * ih, ox: p.ox * iw, oy: p.oy * ih }));
    const b = curveBox(abs, l.closed);
    if (Math.abs(b.x) < 0.5 && Math.abs(b.y) < 0.5 && Math.abs(b.w - iw) < 0.5 && Math.abs(b.h - ih) < 0.5) return;
    // nuovo centro (coordinate del documento) e punti di nuovo 0..1
    const [ncx, ncy] = localToDoc(l, m + b.x + b.w / 2, m + b.y + b.h / 2);
    l.pts = abs.map((p) => ({ x: (p.x - b.x) / b.w, y: (p.y - b.y) / b.h, ix: p.ix / b.w, iy: p.iy / b.h, ox: p.ox / b.w, oy: p.oy / b.h }));
    l.w = b.w + 2 * m; l.h = b.h + 2 * m; l.x = ncx - l.w / 2; l.y = ncy - l.h / 2;
  }
  function pathToSel(l, op = 'new') {
    sel.drawWith((g) => {
      g.save(); g.translate(l.x + l.w / 2, l.y + l.h / 2); g.rotate((l.rot || 0) * Math.PI / 180); g.scale(l.flipX ? -1 : 1, l.flipY ? -1 : 1);
      const m = pathPad(l);
      pathTrace(g, l, -l.w / 2 + m, -l.h / 2 + m, l.w - 2 * m, l.h - 2 * m); g.fill(); g.restore();
    }, op);
    S.selMode = 'rect'; setTool('select'); selChanged();
  }

  // ------------------------------------------------------------ pennello correttivo: si dipinge sulla macchia, si ricostruisce da intorno
  function startHeal(e, px, py) {
    if (S.busy) return;
    const k = Math.min(1, 3000 / Math.max(doc.w, doc.h));
    const m = document.createElement('canvas'); m.width = Math.round(doc.w * k); m.height = Math.round(doc.h * k);
    const mg = m.getContext('2d');
    const pts = [[px, py]];
    const paintMask = () => {
      mg.clearRect(0, 0, m.width, m.height);
      mg.save(); mg.scale(k, k); mg.strokeStyle = mg.fillStyle = 'rgba(255,60,90,1)'; mg.lineCap = mg.lineJoin = 'round'; mg.lineWidth = S.brush.size;
      mg.beginPath();
      if (pts.length === 1) { mg.arc(pts[0][0], pts[0][1], S.brush.size / 2, 0, Math.PI * 2); mg.fill(); }
      else { pts.forEach(([x, y], i) => (i ? mg.lineTo(x, y) : mg.moveTo(x, y))); mg.stroke(); }
      mg.restore();
    };
    paintMask(); S.healMask = m; draw();
    S.drag = {
      move(x, y) { pts.push([x, y]); paintMask(); },
      async end() {
        if (sel.on) { mg.globalCompositeOperation = 'destination-in'; mg.drawImage(sel.mask, 0, 0, m.width, m.height); mg.globalCompositeOperation = 'source-over'; }
        setBusy('Correggo…', 0.1);
        try {
          const comp = composite(k);
          const toBlob = (c) => new Promise((r) => c.toBlob(r, 'image/png'));
          const img = await uploadBlob(await toBlob(comp), 'tmp');
          const mask = await uploadBlob(await toBlob(m), 'tmp');
          const j = await post(`/api/d/${gid}/heal`, { img, mask, radius: Math.max(3, S.brush.size * k / 4) });
          const r = await pollJob(j.id, (x) => setBusy('Correggo…', x.progress));
          if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
          const res = new Image(); res.src = `/api/d/${gid}/file/${r.result.file}?token=${TOKEN}`; await res.decode();
          // le correzioni vanno in un livello a parte, sopra tutto (si possono togliere)
          let l = one();
          if (!l || l.type !== 'paint') {
            l = layers().slice().reverse().find((x) => x.type === 'paint' && x.heal);
            if (!l) { l = paintLayer(doc); l.name = tr('Correzioni'); l.heal = true; layers().push(l); }
            S.sel = [l.id];
          }
          const c = layerCanvas(l, false), g = c.getContext('2d');
          g.drawImage(mapToLayer(l, c.width, c.height, (gg) => gg.drawImage(res, 0, 0, doc.w, doc.h)), 0, 0);
          l.src = storeCanvas(c, 'paint');
          S.healMask = null;
          commit();
        } catch (er) { toast(er.message, true); S.healMask = null; draw(); }
        setBusy(null);
      },
    };
  }
  function eyedrop(sx, sy) {
    const d = dpr();
    try {
      const px = cv.getContext('2d').getImageData(Math.round(sx * d), Math.round(sy * d), 1, 1).data;
      const hex = '#' + [px[0], px[1], px[2]].map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase();
      setColor(hex, true);
      toast('Colore preso: ' + hex);
    } catch (e) { /* */ }
  }
  function setColor(c, apply) {
    S.color = c; S.colorSet = true;
    if (apply) {
      const ls = selLayers().filter((l) => l.type === 'text' || l.type === 'shape' || l.type === 'path');
      if (ls.length) { ls.forEach((l) => { if (l.type === 'text') { l.color = c; delete l.fill; } else if (l.type === 'path' && !l.closed) l.stroke = c; else l.fill = c; }); commit(); }
    }
    paintTools(); paintOpts();
  }

  // ------------------------------------------------------------ ritaglio della tela
  function startCropMode() { S.crop = { x: 0, y: 0, w: doc.w, h: doc.h, ratio: 0 }; draw(); paintOpts(); }
  function startCrop(e, px, py, sx, sy) {
    if (!S.crop) startCropMode();
    const c = S.crop, o = { ...c };
    const near = (x, y) => { const [a, b] = toScr(x, y); return Math.hypot(a - sx, b - sy) < 12; };
    let mode = null;
    if (near(c.x, c.y)) mode = 'nw'; else if (near(c.x + c.w, c.y)) mode = 'ne'; else if (near(c.x + c.w, c.y + c.h)) mode = 'se'; else if (near(c.x, c.y + c.h)) mode = 'sw';
    else if (px > c.x && px < c.x + c.w && py > c.y && py < c.y + c.h) mode = 'move';
    else mode = 'new';
    S.cropDrag = (x, y) => {
      const dx = x - px, dy = y - py;
      if (mode === 'move') { c.x = o.x + dx; c.y = o.y + dy; return; }
      let x0 = o.x, y0 = o.y, x1 = o.x + o.w, y1 = o.y + o.h;
      if (mode === 'new') { x0 = px; y0 = py; x1 = x; y1 = y; }
      if (mode.includes('w')) x0 = o.x + dx; if (mode.includes('e')) x1 = o.x + o.w + dx;
      if (mode.includes('n')) y0 = o.y + dy; if (mode.includes('s')) y1 = o.y + o.h + dy;
      let w = Math.max(1, Math.abs(x1 - x0)), hh = Math.max(1, Math.abs(y1 - y0));
      if (c.ratio) { hh = w / c.ratio; if (mode === 'new' || mode.includes('n')) y0 = mode === 'new' ? Math.min(y0, y1) : y1 - hh; }
      c.x = Math.min(x0, x1); c.y = Math.min(y0, mode === 'new' && c.ratio ? y0 : y1); c.w = w; c.h = hh;
      if (!c.ratio) c.y = Math.min(y0, y1);
    };
  }
  // ------------------------------------------------------------ selezioni
  const selOpOf = (ev) => (ev.shiftKey && ev.altKey ? 'int' : ev.shiftKey ? 'add' : ev.altKey ? 'sub' : S.selOp);
  function selChanged() { paintOpts(); draw(); }
  function startSelect(e, px, py) {
    const op = selOpOf(e);
    if (S.selMode === 'wand') { wand(px, py, op); return; }
    if (S.selMode === 'lasso') {
      S.selDraft = { pts: [[px, py]] };
      S.drag = { move(x, y) { const p = S.selDraft.pts, q = p[p.length - 1]; if (Math.hypot(x - q[0], y - q[1]) * S.zoom > 2) p.push([x, y]); },
        end() { const pts = S.selDraft.pts; S.selDraft = null; if (pts.length > 2) sel.poly(pts, op); else if (op === 'new') sel.clear(); selChanged(); } };
      return;
    }
    S.selDraft = { kind: S.selMode, x0: px, y0: py, x1: px, y1: py };
    S.drag = {
      move(x, y, ev) {
        const d = S.selDraft; let w = x - d.x0, hh = y - d.y0;
        if (ev.shiftKey && op === 'new') { const m = Math.max(Math.abs(w), Math.abs(hh)); w = Math.sign(w || 1) * m; hh = Math.sign(hh || 1) * m; }
        d.x1 = d.x0 + w; d.y1 = d.y0 + hh;
        S.drag.label = Math.round(Math.abs(w)) + ' × ' + Math.round(Math.abs(hh));
      },
      end() {
        const d = S.selDraft; S.selDraft = null;
        const x = Math.min(d.x0, d.x1), y = Math.min(d.y0, d.y1), w = Math.abs(d.x1 - d.x0), hh = Math.abs(d.y1 - d.y0);
        if (w * S.zoom < 3 && hh * S.zoom < 3) { if (op === 'new') sel.clear(); }   // un clic: toglie la selezione
        else if (d.kind === 'ellipse') sel.ellipse(x, y, w, hh, op); else sel.rect(x, y, w, hh, op);
        selChanged();
      },
    };
  }
  // l'immagine com'e' adesso (tutti i livelli), alla risoluzione della selezione
  function composite(k) {
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(doc.w * k)); c.height = Math.max(1, Math.round(doc.h * k));
    const g = c.getContext('2d');
    if (page().bg) { g.fillStyle = typeof page().bg === 'string' ? page().bg : '#fff'; g.fillRect(0, 0, c.width, c.height); }
    renderPage(g, doc, page(), { k, ox: 0, oy: 0 }, assets, { store: new Map() });
    return c;
  }
  function wand(px, py, op) {
    if (!wandCache || wandCache.idx !== hist.idx || wandCache.page !== S.page) wandCache = { idx: hist.idx, page: S.page, img: composite(sel.k) };
    const m = magicWand(wandCache.img, px * sel.k, py * sel.k, S.tol, S.contig);
    sel.fromCanvas(m, op);
    selChanged();
  }
  async function selectSubject() {
    setBusy('Cerco il soggetto…', 0.05);
    try {
      const k = Math.min(1, 1600 / Math.max(doc.w, doc.h));
      const c = composite(k);
      const file = await uploadBlob(await new Promise((r) => c.toBlob(r, 'image/png')), 'sel');
      const j = await post(`/api/d/${gid}/removebg`, { file, mode: 'oggetto' });
      const r = await pollJob(j.id, (x) => setBusy(x.message === 'Rimuovo lo sfondo' ? 'Cerco il soggetto…' : x.message || 'Cerco il soggetto…', x.progress));
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      const im = new Image(); im.src = `/api/d/${gid}/file/${r.result.file}?token=${TOKEN}`;
      await im.decode();
      sel.fromCanvas(im, 'new');
      if (!sel.on) toast('Non trovo un soggetto chiaro in questa immagine', true);
      setTool('select');
    } catch (e) { toast(e.message, true); }
    setBusy(null); selChanged();
  }
  // tela del livello (pittura) o della sua maschera, pronta da modificare
  function layerCanvas(l, mask) {
    let w, hh, a;
    if (mask) { a = l.mask && assets.get(l.mask.src); w = a ? a.w : Math.min(2048, Math.round(l.type === 'image' && l.iw ? l.iw : l.w)); hh = a ? a.h : Math.max(1, Math.round(w * l.h / l.w)); }
    else { a = l.src && assets.get(l.src); w = Math.max(1, Math.round(l.w)); hh = Math.max(1, Math.round(l.h)); }
    const c = document.createElement('canvas'); c.width = w; c.height = hh;
    const g = c.getContext('2d');
    if (a) g.drawImage(a.el, 0, 0, w, hh); else if (mask) { g.fillStyle = '#fff'; g.fillRect(0, 0, w, hh); }
    return c;
  }
  function needSel() { if (!sel.on) { toast('Prima fai una selezione (M)', true); return false; } return true; }
  // Canc: sulla pittura toglie i pixel, sugli altri livelli li nasconde con la maschera (si possono riavere)
  function clearInSel() {
    if (!needSel()) return;
    const l = one();
    if (!l || l.type === 'group' || l.type === 'adjust') { toast('Scegli il livello da cui togliere la parte selezionata', true); return; }
    if (l.locked) { toast('Il livello è bloccato', true); return; }
    const mask = l.type !== 'paint';
    const c = layerCanvas(l, mask), g = c.getContext('2d');
    g.globalCompositeOperation = 'destination-out'; g.drawImage(sel.toLayer(l, c.width, c.height), 0, 0);
    const name = storeCanvas(c, mask ? 'mask' : 'paint');
    if (mask) l.mask = { ...(l.mask || {}), src: name, on: true }; else l.src = name;
    commit();
  }
  function fillSel(color) {
    if (!needSel()) return;
    let l = one();
    if (!l || l.type !== 'paint') { l = paintLayer(doc); l.name = tr('Riempimento'); addLayer(l, true); }
    const c = layerCanvas(l, false), g = c.getContext('2d');
    const m = sel.toLayer(l, c.width, c.height), mg = m.getContext('2d');
    mg.globalCompositeOperation = 'source-in'; mg.fillStyle = color; mg.fillRect(0, 0, m.width, m.height);
    g.drawImage(m, 0, 0);
    l.src = storeCanvas(c, 'paint');
    commit();
  }
  // nuovo livello con quello che c'e' nella selezione (del livello scelto, o di tutta l'immagine)
  async function layerFromSel(cut) {
    if (!needSel()) return;
    const b = sel.bounds(); if (!b) return;
    const l = one();
    const ks = Math.min(1, 4096 / Math.max(doc.w, doc.h));
    const c = document.createElement('canvas'); c.width = Math.round(doc.w * ks); c.height = Math.round(doc.h * ks);
    const g = c.getContext('2d');
    const single = l && l.type !== 'group' && l.type !== 'adjust';
    if (single) renderPage(g, doc, { bg: null, layers: [{ ...l, visible: true }] }, { k: ks, ox: 0, oy: 0 }, assets, { store: new Map() });
    else g.drawImage(composite(ks), 0, 0);
    g.globalCompositeOperation = 'destination-in'; g.drawImage(sel.mask, 0, 0, c.width, c.height);
    const x0 = Math.max(0, Math.floor(b.x)), y0 = Math.max(0, Math.floor(b.y)), x1 = Math.min(doc.w, Math.ceil(b.x + b.w)), y1 = Math.min(doc.h, Math.ceil(b.y + b.h));
    if (x1 <= x0 || y1 <= y0) return;
    const o = document.createElement('canvas'); o.width = Math.max(1, Math.round((x1 - x0) * ks)); o.height = Math.max(1, Math.round((y1 - y0) * ks));
    o.getContext('2d').drawImage(c, x0 * ks, y0 * ks, o.width, o.height, 0, 0, o.width, o.height);
    setBusy('Creo il livello…');
    try {
      const file = await uploadBlob(await new Promise((r) => o.toBlob(r, 'image/png')), 'img');
      const nl = imageLayer(file, o.width, o.height, doc, tr(cut ? 'Livello tagliato' : 'Livello da selezione'));
      nl.x = x0; nl.y = y0; nl.w = x1 - x0; nl.h = y1 - y0;
      if (cut && single) { clearInSel(); }
      addLayer(nl);
    } catch (e) { toast(e.message, true); }
    setBusy(null);
  }
  function maskFromSel() {
    if (!needSel()) return;
    const l = one();
    if (!l || l.type === 'group' || l.type === 'adjust') { toast('Scegli il livello a cui dare la maschera', true); return; }
    const w = Math.min(2048, Math.round(l.type === 'image' && l.iw ? l.iw : l.w)), hh = Math.max(1, Math.round(w * l.h / l.w));
    l.mask = { src: storeCanvas(sel.toLayer(l, w, hh), 'mask'), on: true };
    sel.clear(); commit(); selChanged();
    toast('Maschera creata dalla selezione');
  }
  function applyCrop() {
    const c = S.crop; if (!c) return;
    const x = Math.round(c.x), y = Math.round(c.y), w = Math.max(1, Math.round(c.w)), hh = Math.max(1, Math.round(c.h));
    for (const p of doc.pages) for (const l of p.layers) moveBy(l, -x, -y);
    doc.w = w; doc.h = hh; S.crop = null;
    commit(); fit(); setTool('move');
  }
  function resizeCanvas(w, hh, scaleContent) {
    w = Math.max(1, Math.min(16000, Math.round(w))); hh = Math.max(1, Math.min(16000, Math.round(hh)));
    if (scaleContent) { const kx = w / doc.w, ky = hh / doc.h, k = Math.min(kx, ky); for (const p of doc.pages) for (const l of p.layers) { scaleAround(l, 0, 0, k, k); moveBy(l, (w - doc.w * k) / 2, (hh - doc.h * k) / 2); } }
    else { const dx = (w - doc.w) / 2, dy = (hh - doc.h) / 2; for (const p of doc.pages) for (const l of p.layers) moveBy(l, dx, dy); }
    doc.w = w; doc.h = hh; commit(); fit();
  }

  // ------------------------------------------------------------ testo: si scrive direttamente sulla tela
  function startEdit(l, fresh) {
    if (l.locked) return;
    stopEdit(false);
    ensureFont(l.font);
    const ta = h('textarea', { class: 'dz-tedit', spellcheck: 'false', 'aria-label': 'Testo' });
    ta.value = l.text || '';
    S.editing = { id: l.id, ta, fresh, before: l.text };
    const place = () => {
      const lines = Math.max(1, (ta.value.match(/\n/g) || []).length + 1);
      const z = S.zoom;
      Object.assign(ta.style, {
        left: S.panX + l.x * z + 'px', top: S.panY + l.y * z + 'px', width: Math.max(20, l.w * z + 4) + 'px', height: Math.max(l.size * l.lineH * z, l.h * z) + 'px',
        font: fontOf(l, z), lineHeight: (l.size * (l.lineH || 1.2) * z) + 'px', color: fillColor(l.fill || l.color), textAlign: l.align || 'center',
        letterSpacing: (l.letter || 0) * z + 'px', textTransform: l.upper ? 'uppercase' : 'none', transform: `rotate(${l.rot || 0}deg)`,
      });
      void lines;
    };
    ta.addEventListener('input', () => {
      l.text = ta.value;
      if (l.auto) { const cx = l.x + l.w / 2; l.w = Math.max(20, textNaturalWidth(l)); if (!S.editing.fresh) l.x = cx - l.w / 2; }
      l.h = textHeight(l); place(); draw();
    });
    ta.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape' || (e.key === 'Enter' && (e.ctrlKey || e.metaKey))) { e.preventDefault(); stopEdit(true); } });
    ta.addEventListener('blur', () => setTimeout(() => { if (S.editing && S.editing.ta === ta) stopEdit(true); }, 0));
    stage.append(ta); place();
    S.editing.place = place;
    ta.focus(); if (!fresh) ta.select();
    setTimeout(() => { if (document.activeElement !== ta && S.editing && S.editing.ta === ta) ta.focus(); }, 0);
    draw();
  }
  function stopEdit(save) {
    const ed = S.editing; if (!ed) return;
    S.editing = null; ed.ta.remove();
    const r = findLayer(layers(), ed.id);
    if (r) {
      const l = r.layer;
      if (!String(l.text || '').trim()) { r.arr.splice(r.i, 1); S.sel = S.sel.filter((id) => id !== l.id); }
      else if (l.text !== ed.before || ed.fresh) l.name = String(l.text).split('\n')[0].slice(0, 40);
    }
    if (save) commit(); else { draw(); refresh(); }
  }

  // ------------------------------------------------------------ operazioni sui livelli
  function container() {
    // i livelli nuovi vanno sopra quello scelto (nello stesso gruppo)
    const l = one(); if (!l) return { arr: layers(), i: layers().length };
    const r = findLayer(layers(), l.id);
    return { arr: r.arr, i: r.i + 1 };
  }
  function addLayer(l, noCommit) {
    const c = container();
    c.arr.splice(c.i, 0, l);
    S.sel = [l.id];
    if (!noCommit) commit(); else { draw(); refresh(); }
    return l;
  }
  function deleteSel() {
    if (!S.sel.length) return;
    for (const id of [...S.sel]) { const r = findLayer(layers(), id); if (r) r.arr.splice(r.i, 1); }
    S.sel = []; commit();
  }
  const reId = (l) => { l.id = uid(); if (l.children) l.children.forEach(reId); return l; };
  function duplicateSel(inPlace) {
    const ids = [];
    for (const l of selLayers()) {
      const r = findLayer(layers(), l.id);
      const c = reId(clone(l)); c.name = (l.name || '') + (inPlace ? '' : ' copia');
      if (!inPlace) moveBy(c, 20, 20);
      r.arr.splice(r.i + 1, 0, c); ids.push(c.id);
    }
    S.sel = ids; if (!inPlace) commit(); else { draw(); refresh(); }
  }
  function groupSel() {
    const ls = selLayers(); if (!ls.length) return;
    const first = findLayer(layers(), ls[0].id);
    const arr = first.arr;
    const inSame = ls.filter((l) => arr.includes(l));
    if (!inSame.length) return;
    const idx = Math.max(...inSame.map((l) => arr.indexOf(l)));
    const kids = arr.filter((l) => inSame.includes(l));
    const g = groupLayer(kids.map((l) => l));
    for (const l of kids) arr.splice(arr.indexOf(l), 1);
    arr.splice(Math.min(idx - kids.length + 1, arr.length), 0, g);
    S.sel = [g.id]; commit();
  }
  function ungroup() {
    const l = one(); if (!l || l.type !== 'group') return;
    const r = findLayer(layers(), l.id);
    r.arr.splice(r.i, 1, ...(l.children || []));
    S.sel = (l.children || []).map((c) => c.id); commit();
  }
  function arrange(dir) {
    for (const l of (dir > 0 ? [...selLayers()].reverse() : selLayers())) {
      const r = findLayer(layers(), l.id); const a = r.arr;
      a.splice(r.i, 1);
      const ni = dir === 2 ? a.length : dir === -2 ? 0 : Math.max(0, Math.min(a.length, r.i + dir));
      a.splice(ni, 0, l);
    }
    commit();
  }
  function align(how) {
    const ls = selLayers().filter((l) => l.type !== 'adjust'); if (!ls.length) return;
    const multi = ls.length > 1;
    const sb = selBox(); const B = multi ? sb.box : { x: 0, y: 0, w: doc.w, h: doc.h };
    for (const l of ls) {
      const b = bounds(l); let dx = 0, dy = 0;
      if (how === 'l') dx = B.x - b.x; if (how === 'r') dx = B.x + B.w - (b.x + b.w); if (how === 'ch') dx = B.x + B.w / 2 - (b.x + b.w / 2);
      if (how === 't') dy = B.y - b.y; if (how === 'b') dy = B.y + B.h - (b.y + b.h); if (how === 'cv') dy = B.y + B.h / 2 - (b.y + b.h / 2);
      moveBy(l, dx, dy);
    }
    commit();
  }
  function toggleMask() {
    const l = one();
    if (!l || l.type === 'group' || l.type === 'adjust') { toast('Scegli un livello per aggiungere la maschera', true); return; }
    if (l.mask) { delete l.mask; S.maskEdit = false; commit(); return; }
    const iw = Math.min(2048, Math.round(l.type === 'image' && l.iw ? l.iw : l.w)), ihh = Math.max(1, Math.round(iw * l.h / l.w));
    const c = document.createElement('canvas'); c.width = iw; c.height = ihh; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, iw, ihh);
    l.mask = { src: storeCanvas(c, 'mask'), on: true };
    S.maskEdit = true; setTool('eraser');
    toast('Maschera aggiunta: la gomma nasconde, il pennello fa riapparire');
    commit();
  }
  // ------------------------------------------------------------ livelli: rasterizza, unisci, distribuisci, copia in un'altra pagina
  const canRaster = (l) => l && (l.type === 'text' || l.type === 'shape' || l.type === 'path' || ((l.type === 'image' || l.type === 'paint') && l.warp));
  // il contenuto del livello diventa un'immagine (stili, maschera e filtri restano modificabili)
  function rasterize(l, quiet) {
    if (!canRaster(l)) return null;
    if (l.type === 'text' && !l.onPath) { const hh = textHeight(l); if (hh > l.h) { l.y -= 0; l.h = hh; } }
    const rs = Math.min(2, 4096 / Math.max(1, l.w, l.h));
    const bm = layerBitmap({ ...l, id: 'r_' + l.id, fx: null, filters: null, mask: null }, rs, assets, new Map());
    const c = document.createElement('canvas'); c.width = bm.cv.width - bm.pad * 2; c.height = bm.cv.height - bm.pad * 2;
    c.getContext('2d').drawImage(bm.cv, -bm.pad, -bm.pad);
    const keep = { id: l.id, name: l.name, visible: l.visible, locked: l.locked, opacity: l.opacity, blend: l.blend, x: l.x, y: l.y, w: l.w, h: l.h, rot: l.rot || 0, flipX: !!l.flipX, flipY: !!l.flipY };
    for (const k of ['fx', 'filters', 'mask', 'clip', 'lockAlpha']) if (l[k]) keep[k] = l[k];
    for (const k of Object.keys(l)) delete l[k];
    Object.assign(l, keep, { type: 'image', src: storeCanvas(c, 'img'), iw: c.width, ih: c.height });
    if (!quiet) { toast('Livello trasformato in immagine'); commit(); }
    return l;
  }
  // disegna dei livelli (della pagina) su una tela grande quanto il riquadro b
  function renderList(list, b, k = 1) {
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(b.w * k)); c.height = Math.max(1, Math.round(b.h * k));
    renderLayers(c.getContext('2d'), list, { k, ox: -b.x * k, oy: -b.y * k }, assets, { store: new Map(), clip: [0, 0, c.width, c.height] });
    return c;
  }
  function imageFrom(c, b, name) {
    return { id: uid(), type: 'image', name, visible: true, locked: false, opacity: 1, blend: 'normal', x: b.x, y: b.y, w: b.w, h: b.h, rot: 0, flipX: false, flipY: false,
      src: storeCanvas(c, 'img'), iw: c.width, ih: c.height };
  }
  function unionBox(list) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const l of list) { if (l.type === 'adjust') continue; const b = bounds(l); x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y); x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h); }
    if (!isFinite(x0)) return { x: 0, y: 0, w: doc.w, h: doc.h };
    // dentro la tela (oltre il bordo non si vede comunque)
    x0 = Math.max(0, Math.floor(x0)); y0 = Math.max(0, Math.floor(y0)); x1 = Math.min(doc.w, Math.ceil(x1)); y1 = Math.min(doc.h, Math.ceil(y1));
    return { x: x0, y: y0, w: Math.max(1, x1 - x0), h: Math.max(1, y1 - y0) };
  }
  function mergeDown() {
    const l = one(); if (!l) { toast('Scegli il livello da unire a quello sotto', true); return; }
    const r = findLayer(layers(), l.id);
    if (r.i === 0) { toast('Non c\'è un livello sotto', true); return; }
    const below = r.arr[r.i - 1];
    const pair = [{ ...below, clip: false }, l.clip ? l : { ...l }];
    const b = unionBox(pair.filter((x) => x.type !== 'adjust').length ? pair : [{ x: 0, y: 0, w: doc.w, h: doc.h, type: 'shape' }]);
    const c = renderList(pair, b);
    const img = imageFrom(c, b, below.name || tr('Livello'));
    if (below.clip) img.clip = true;
    r.arr.splice(r.i - 1, 2, img);
    S.sel = [img.id]; commit();
  }
  function mergeVisible(stamp) {
    const list = layers().filter((x) => x.visible);
    if (!list.length) return;
    const c = renderList(list, { x: 0, y: 0, w: doc.w, h: doc.h });
    const img = imageFrom(c, { x: 0, y: 0, w: doc.w, h: doc.h }, stamp ? tr('Unione dei visibili') : tr('Livelli uniti'));
    if (stamp) layers().push(img);
    else { const arr = layers(); for (const x of list) arr.splice(arr.indexOf(x), 1); arr.push(img); }
    S.sel = [img.id]; commit();
  }
  function distribute(axis) {
    const ls = selLayers().filter((l) => l.type !== 'adjust');
    if (ls.length < 3) { toast('Scegli almeno 3 livelli', true); return; }
    const bs = ls.map((l) => ({ l, b: bounds(l) })).sort((a, b) => (axis === 'h' ? a.b.x - b.b.x : a.b.y - b.b.y));
    const first = bs[0].b, last = bs[bs.length - 1].b;
    const span = axis === 'h' ? last.x + last.w - first.x : last.y + last.h - first.y;
    const tot = bs.reduce((a, x) => a + (axis === 'h' ? x.b.w : x.b.h), 0);
    const gap = (span - tot) / (bs.length - 1);
    let pos = axis === 'h' ? first.x : first.y;
    for (const { l, b } of bs) { if (axis === 'h') moveBy(l, pos - b.x, 0); else moveBy(l, 0, pos - b.y); pos += (axis === 'h' ? b.w : b.h) + gap; }
    commit();
  }
  function toPage(anchor, move) {
    const items = doc.pages.map((p, i) => [tr('Pagina') + ' ' + (i + 1), () => {
      const ls = selLayers().map((l) => reId(clone(l)));
      doc.pages[i].layers.push(...ls);
      if (move) for (const id of [...S.sel]) { const r = findLayer(layers(), id); if (r) r.arr.splice(r.i, 1); }
      S.page = i; S.sel = ls.map((l) => l.id); commit();
      toast(move ? 'Spostato nella pagina ' + (i + 1) : 'Copiato nella pagina ' + (i + 1));
    }, i === S.page]);
    items.push('-', [tr('Nuova pagina'), () => { const np = { id: uid('p'), name: '', bg: page().bg, layers: [] }; doc.pages.push(np); const i = doc.pages.length - 1; const ls = selLayers().map((l) => reId(clone(l))); np.layers.push(...ls); if (move) for (const id of [...S.sel]) { const r = findLayer(layers(), id); if (r) r.arr.splice(r.i, 1); } S.page = i; S.sel = ls.map((l) => l.id); commit(); }]);
    menu(anchor, items);
  }

  // ------------------------------------------------------------ trasformazione libera: distorci, prospettiva, inclina, altera
  const XF_MODES = [['distort', 'Distorci'], ['persp', 'Prospettiva'], ['skew', 'Inclina'], ['warp', 'Altera']];
  const QUAD0 = () => [[0, 0], [1, 0], [1, 1], [0, 1]];
  const MESH0 = () => { const o = []; for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) o.push([i / 3, j / 3]); return o; };
  async function startFree(mode) {
    let l = one();
    if (!l || !['image', 'paint', 'shape', 'path', 'text'].includes(l.type)) { toast('Scegli un livello (immagine, forma o testo) da deformare', true); return; }
    if (l.locked) { toast('Il livello è bloccato', true); return; }
    if (l.type === 'text') {
      if (!(await confirmBox('Trasformare il testo in immagine?', 'Per deformarlo il testo diventa un\'immagine: non potrai più cambiare le parole (puoi sempre annullare).', 'Continua'))) return;
      rasterize(l, true);
    }
    S.xf = { id: l.id, mode, orig: clone(l) };
    setXfMode(mode, true);
    if (S.tool !== 'move') setTool('move');
    draw(); refresh();
  }
  function setXfMode(mode, init) {
    const l = xfLayer(); if (!l) return;
    S.xf.mode = mode;
    if (!l.warp) l.warp = { kind: mode === 'warp' ? 'mesh' : 'quad', sw: l.w, sh: l.h, pts: mode === 'warp' ? MESH0() : QUAD0() };
    else if (mode === 'warp' && l.warp.kind !== 'mesh') { const f = warpMapOf(l.warp); l.warp = { ...l.warp, kind: 'mesh', pts: MESH0().map(([u, v]) => f(u, v)) }; }
    else if (mode !== 'warp' && l.warp.kind === 'mesh') { const p = l.warp.pts; l.warp = { ...l.warp, kind: 'quad', pts: [p[0], p[3], p[15], p[12]].map((q) => q.slice()) }; }
    if (!init) { draw(); paintOpts(); }
  }
  const xfLayer = () => (S.xf ? (findLayer(layers(), S.xf.id) || {}).layer || null : null);
  function xfPoints(l) { return l.warp.pts.map(([u, v]) => toScr(...fromLocal(l, u * l.w, v * l.h))); }
  function endFree(apply) {
    const l = xfLayer(); const xf = S.xf; S.xf = null;
    if (!l) { draw(); refresh(); return; }
    if (!apply) { Object.keys(l).forEach((k) => delete l[k]); Object.assign(l, xf.orig); draw(); refresh(); return; }
    normalizeWarp(l);
    commit();
  }
  // il riquadro del livello torna a contenere esattamente la forma deformata
  function normalizeWarp(l) {
    const wp = l.warp; if (!wp) return;
    const f = warpMapOf(wp); let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    const n = wp.kind === 'mesh' ? 16 : 1;
    for (let j = 0; j <= n; j++) for (let i = 0; i <= n; i++) { const [u, v] = f(i / n, j / n); x0 = Math.min(x0, u); y0 = Math.min(y0, v); x1 = Math.max(x1, u); y1 = Math.max(y1, v); }
    if (wp.kind !== 'mesh') for (const [u, v] of wp.pts) { x0 = Math.min(x0, u); y0 = Math.min(y0, v); x1 = Math.max(x1, u); y1 = Math.max(y1, v); }
    const W0 = l.w, H0 = l.h, nw = Math.max(1, (x1 - x0) * W0), nh = Math.max(1, (y1 - y0) * H0);
    const c = fromLocal(l, (x0 + x1) / 2 * W0, (y0 + y1) / 2 * H0);
    wp.pts = wp.pts.map(([u, v]) => [(u - x0) * W0 / nw, (v - y0) * H0 / nh]);
    l.w = nw; l.h = nh; l.x = c[0] - nw / 2; l.y = c[1] - nh / 2;
    // nessuna deformazione rimasta: si torna al livello normale
    const flat = wp.kind === 'quad' && wp.pts.every((q, i) => Math.abs(q[0] - QUAD0()[i][0]) < 1e-4 && Math.abs(q[1] - QUAD0()[i][1]) < 1e-4);
    if (flat) delete l.warp;
  }
  function xfHit(sx, sy) {
    const l = xfLayer(); if (!l) return -1;
    const P = xfPoints(l); let best = -1, bd = 11;
    P.forEach(([x, y], i) => { const d = Math.hypot(x - sx, y - sy); if (d < bd) { bd = d; best = i; } });
    return best;
  }
  function startXfDrag(e, i, px, py) {
    const l = xfLayer(); const wp = l.warp, o = wp.pts.map((q) => q.slice());
    const [lx0, ly0] = toLocal(l, px, py);
    const NEIGH = { 0: [1, 4], 3: [2, 7], 12: [8, 13], 15: [11, 14] };
    S.drag = {
      move(x, y, ev) {
        const [lx, ly] = toLocal(l, x, y); const du = (lx - lx0) / l.w, dv = (ly - ly0) / l.h;
        const pts = o.map((q) => q.slice());
        if (wp.kind === 'mesh') {
          pts[i] = [o[i][0] + du, o[i][1] + dv];
          if (NEIGH[i] && !ev.altKey) for (const n of NEIGH[i]) pts[n] = [o[n][0] + du, o[n][1] + dv];
        } else if (S.xf.mode === 'distort' || ev.ctrlKey || ev.metaKey) pts[i] = [o[i][0] + du, o[i][1] + dv];
        else {
          const hn = [1, 0, 3, 2][i], vn = [3, 2, 1, 0][i];   // vicino sullo stesso lato orizzontale / verticale
          const horiz = Math.abs(du * l.w) >= Math.abs(dv * l.h);
          if (S.xf.mode === 'skew') {
            if (horiz) { pts[i][0] = o[i][0] + du; pts[hn][0] = o[hn][0] + du; } else { pts[i][1] = o[i][1] + dv; pts[vn][1] = o[vn][1] + dv; }
          } else {   // prospettiva: il vicino si muove al contrario (simmetrico)
            if (horiz) { pts[i][0] = o[i][0] + du; pts[hn][0] = o[hn][0] - du; } else { pts[i][1] = o[i][1] + dv; pts[vn][1] = o[vn][1] - dv; }
          }
        }
        wp.pts = pts;
      },
      end() { draw(); paintLayersSoon(); },
    };
  }
  function drawXfOverlay(g) {
    const l = xfLayer(); if (!l) return;
    const wp = l.warp, f = warpMapOf(wp);
    const sc = (u, v) => toScr(...fromLocal(l, u * l.w, v * l.h));
    g.save(); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1;
    const line = (fn) => { g.beginPath(); for (let k = 0; k <= 24; k++) { const [u, v] = fn(k / 24); const [x, y] = sc(u, v); if (k) g.lineTo(x, y); else g.moveTo(x, y); } g.stroke(); };
    const n = wp.kind === 'mesh' ? 3 : 1;
    for (let a = 0; a <= n; a++) { line((t) => f(a / n, t)); line((t) => f(t, a / n)); }
    if (wp.kind === 'mesh') {
      // maniglie delle curve
      g.strokeStyle = 'rgba(47,139,255,.55)'; g.setLineDash([3, 3]);
      const P = xfPoints(l);
      for (const [c, ns] of [[0, [1, 4]], [3, [2, 7]], [12, [8, 13]], [15, [11, 14]]]) for (const k of ns) { g.beginPath(); g.moveTo(P[c][0], P[c][1]); g.lineTo(P[k][0], P[k][1]); g.stroke(); }
      g.setLineDash([]);
    }
    xfPoints(l).forEach(([x, y], i) => {
      const corner = wp.kind !== 'mesh' || [0, 3, 12, 15].includes(i);
      g.beginPath(); if (corner) g.roundRect(x - 5, y - 5, 10, 10, 2.5); else g.arc(x, y, 4.5, 0, 7);
      g.fillStyle = corner ? '#fff' : '#2F8BFF'; g.fill(); g.strokeStyle = corner ? '#2F8BFF' : '#fff'; g.lineWidth = 1.5; g.stroke();
    });
    g.restore();
  }
  // stili pronti per "Altera" (come in Photoshop: arco, bandiera, onda...)
  function warpPreset(kind, amt) {
    const l = xfLayer(); if (!l) return;
    const b = amt / 100, k = b * 0.5 * 4 / 3, P = MESH0();
    const add = (i, j, du, dv) => { const q = P[j * 4 + i]; q[0] += du; q[1] += dv; };
    for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) {
      const mid = i === 1 || i === 2, midR = j === 1 || j === 2;
      if (kind === 'arc' && mid) add(i, j, 0, -k);
      if (kind === 'arcUp' && mid) add(i, j, 0, -k * (1 - j / 3));
      if (kind === 'arcDown' && mid) add(i, j, 0, k * (j / 3));
      if (kind === 'flag') add(i, j, 0, i === 1 ? -k * 0.8 : i === 2 ? k * 0.8 : 0);
      if (kind === 'wave') add(i, j, 0, (i === 1 ? -k : i === 2 ? k : 0) * (j < 2 ? 1 : -1) * 0.8);
      if (kind === 'bulge') { if (mid) add(i, j, 0, j === 0 ? -k : j === 3 ? k : 0); if (midR) add(i, j, i === 0 ? -k : i === 3 ? k : 0, 0); }
      if (kind === 'squeeze' && midR) add(i, j, i === 0 ? k : i === 3 ? -k : 0, 0);
      if (kind === 'rise') add(i, j, 0, -k * 0.6 * (i / 3 - 0.5) * 2 * (i === 0 || i === 3 ? 1 : 0.6));
    }
    l.warp = { kind: 'mesh', sw: l.warp ? l.warp.sw : l.w, sh: l.warp ? l.warp.sh : l.h, pts: P };
    S.xf.preset = kind; S.xf.amt = amt;
    draw();
  }

  function unwarp(l) {
    if (!l || !l.warp) return;
    const cx = l.x + l.w / 2, cy = l.y + l.h / 2;
    l.w = l.warp.sw; l.h = l.warp.sh; l.x = cx - l.w / 2; l.y = cy - l.h / 2; delete l.warp;
  }
  function transformMenu(anchor) {
    menu(anchor, XF_MODES.map(([k, n]) => [n, () => startFree(k)]).concat(one() && one().warp ? ['-', ['Togli la deformazione', () => { unwarp(one()); commit(); }]] : []));
  }
  function adjustMenu(anchor) {
    menu(anchor, ADJUST_KINDS.map(([k, n]) => [n, () => addLayer(adjustLayer(k))]));
  }
  function menu(anchor, items) {
    document.querySelectorAll('.dz-menu').forEach((x) => x.remove());
    const r = anchor.getBoundingClientRect();
    const m = h('div', { class: 'dz-menu', style: { left: Math.min(window.innerWidth - 240, r.left) + 'px', top: r.bottom + 6 + 'px' } },
      ...items.filter(Boolean).map((it) => (it === '-' ? h('hr') : h('button', { onclick: () => { m.remove(); it[1](); }, disabled: it[2] ? true : null }, it[0]))));
    document.body.append(m);
    const rr = m.getBoundingClientRect(); if (rr.bottom > window.innerHeight - 8) m.style.top = Math.max(8, r.top - rr.height - 6) + 'px';
    const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  }

  // ------------------------------------------------------------ immagini: dal computer, trascinate, incollate
  // PSD: i livelli arrivano in un gruppo con il nome del file
  async function addPsd(buf, name) {
    setBusy('Apro il PSD…', 0);
    try {
      const res = await readPsd(buf, async (cv) => uploadBlob(await new Promise((r) => cv.toBlob(r, 'image/png')), 'psd'), (p) => setBusy('Apro il PSD…', p));
      if (!res.layers.length) { toast('Il PSD non ha livelli da importare', true); return; }
      const g = groupLayer(res.layers); g.name = (name || 'PSD').slice(0, 60); g.open = false;
      if (res.w !== doc.w || res.h !== doc.h) { const k = Math.min(doc.w / res.w, doc.h / res.h); scaleAround(g, 0, 0, k, k); moveBy(g, (doc.w - res.w * k) / 2, (doc.h - res.h * k) / 2); }
      addLayer(g);
    } catch (e) { toast(e.message, true); } finally { setBusy(null); }
  }
  async function addImagesFromPaths(paths) {
    for (const p of paths.filter((x) => /\.psd$/i.test(x))) {
      try { const r = await fetch(mediaUrl(p)); await addPsd(await r.arrayBuffer(), p.split(/[\\/]/).pop().replace(/\.psd$/i, '')); } catch (e) { toast(e.message, true); }
    }
    paths = paths.filter((x) => !/\.psd$/i.test(x));
    if (!paths.length) return;
    setBusy('Importo le immagini…');
    try {
      const r = await post(`/api/d/${gid}/import`, { paths });
      let n = 0;
      for (const f of r.files) { const l = imageLayer(f.file, f.w, f.h, doc, f.name); moveBy(l, n * 24, n * 24); addLayer(l, true); n++; }
      if (r.skipped && r.skipped.length) toast('Non importate: ' + r.skipped.join(', '), true);
      if (n) commit();
    } catch (e) { toast(e.message, true); }
    setBusy(null);
  }
  async function pickImages() {
    try {
      const r = await post('/api/pick', { kind: 'images' });
      if (r.fallback) { toast('Trascina le immagini sulla tela', true); return; }
      const paths = Array.isArray(r) ? r : r.path ? (Array.isArray(r.path) ? r.path : [r.path]) : r.paths || [];
      await addImagesFromPaths(paths);
    } catch (e) { toast(e.message, true); }
  }
  async function addImageBlob(blob, name, at) {
    let bm;
    try { bm = await createImageBitmap(blob); } catch (e) { toast('Immagine non leggibile', true); return; }
    let up = blob;
    if (!/image\/(png|jpeg|webp)/.test(blob.type)) {
      const c = document.createElement('canvas'); c.width = bm.width; c.height = bm.height; c.getContext('2d').drawImage(bm, 0, 0);
      up = await new Promise((r) => c.toBlob(r, 'image/png'));
    }
    const file = await uploadBlob(up, 'img');
    const l = imageLayer(file, bm.width, bm.height, doc, (name || 'Immagine').replace(/\.[a-z0-9]+$/i, '').slice(0, 60));
    if (at) { l.x = at[0] - l.w / 2; l.y = at[1] - l.h / 2; }
    addLayer(l);
  }
  stage.addEventListener('dragover', (e) => { e.preventDefault(); stage.classList.add('over'); });
  stage.addEventListener('dragleave', () => stage.classList.remove('over'));
  stage.addEventListener('drop', async (e) => {
    e.preventDefault(); stage.classList.remove('over');
    const r = stage.getBoundingClientRect(); const at = toDoc(e.clientX - r.left, e.clientY - r.top);
    for (const f of [...e.dataTransfer.files].filter((x) => /\.psd$/i.test(x.name))) await addPsd(await f.arrayBuffer(), f.name.replace(/\.psd$/i, ''));
    const files = [...e.dataTransfer.files].filter((f) => /^image\//.test(f.type) && !/\.psd$/i.test(f.name));
    if (!files.length) { if (![...e.dataTransfer.files].some((x) => /\.psd$/i.test(x.name))) toast('Trascina immagini (PNG, JPG, WebP, PSD…)', true); return; }
    setBusy('Importo le immagini…');
    try { for (const f of files) await addImageBlob(f, f.name, files.length === 1 ? at : null); } catch (er) { toast(er.message, true); }
    setBusy(null);
  });
  let clip = null;
  const onPaste = async (e) => {
    if (!alive || isTyping(e.target)) return;
    const it = [...(e.clipboardData ? e.clipboardData.items : [])].find((x) => /^image\//.test(x.type));
    if (it) { e.preventDefault(); setBusy('Incollo l\'immagine…'); try { await addImageBlob(it.getAsFile(), 'Immagine incollata'); } catch (er) { toast(er.message, true); } setBusy(null); return; }
    if (clip) { e.preventDefault(); pasteLayers(); }
  };
  function copyLayers() { const ls = selLayers(); if (ls.length) { clip = ls.map((l) => clone(l)); try { localStorage.setItem('nf.dzclip', JSON.stringify({ gid, layers: clip })); } catch (e) { /* */ } } }
  function pasteLayers() {
    if (!clip) return;
    const ids = [];
    for (const l of clip) { const c = reId(clone(l)); moveBy(c, 20, 20); layers().push(c); ids.push(c.id); }
    clip = clip.map((l) => { const c = clone(l); moveBy(c, 20, 20); return c; });
    S.sel = ids; commit();
  }
  document.addEventListener('paste', onPaste);
  // finestra chiusa subito dopo una modifica: l'ultimo salvataggio parte lo stesso
  const onHide = () => {
    if (!saveT || pending.size) return;
    let raw = JSON.stringify(doc);
    for (const [m, f] of memMap) raw = raw.split(m).join(f);
    try { fetch(`/api/d/${gid}?token=${TOKEN}`, { method: 'PUT', body: raw, keepalive: raw.length < 60000 }); } catch (e) { /* */ }
  };
  window.addEventListener('pagehide', onHide);
  window.addEventListener('beforeunload', onHide);

  // ------------------------------------------------------------ rimuovi sfondo (AI, sul computer)
  async function removeBg(l, mode) {
    setBusy(mode === 'persona' ? 'Ritaglio la persona…' : 'Rimuovo lo sfondo…', 0);
    try {
      const src = memMap.get(l.src) || l.src;
      if (pending.has(l.src)) await pending.get(l.src);
      const j = await post(`/api/d/${gid}/removebg`, { file: memMap.get(l.src) || src, mode });
      const r = await pollJob(j.id, (x) => setBusy(x.message || 'Rimuovo lo sfondo…', x.progress));
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      l.src = r.result.file; l.name = (l.name || 'Immagine').replace(/ \(senza sfondo\)$/, '') + ' (senza sfondo)';
      commit();
      toast('Sfondo rimosso');
    } catch (e) { toast(e.message, true); }
    setBusy(null);
  }
  // ------------------------------------------------------------ brand kit
  function openBrand(anchor) {
    brandPanel(anchor, {
      getColor: () => S.color,
      onColor: (c) => setColor(c, true),
      onFont: (f) => {
        const ts = selLayers().filter((l) => l.type === 'text');
        if (!ts.length) { toast('Scegli un testo per usare il font', true); return; }
        ensureFont(f).then(() => { for (const l of ts) { l.font = f; dropCache(l.id); if (l.auto) { const cx = l.x + l.w / 2; l.w = Math.max(20, textNaturalWidth(l)); l.x = cx - l.w / 2; } l.h = textHeight(l); } commit(); });
      },
      onLogo: async (n) => {
        setBusy('Aggiungo il logo…');
        try {
          const r = await fetch(logoUrl(n)); const blob = await r.blob();
          const bm = await createImageBitmap(blob);
          const file = await uploadBlob(blob, 'img');
          const l = imageLayer(file, bm.width, bm.height, doc, tr('Logo'));
          const k = Math.min(1, (Math.min(doc.w, doc.h) * 0.22) / Math.max(l.w, l.h)); l.w *= k; l.h *= k;
          l.x = doc.w - l.w - doc.w * 0.05; l.y = doc.h - l.h - doc.h * 0.05;
          addLayer(l);
        } catch (e) { toast(e.message, true); }
        setBusy(null);
      },
    });
  }
  loadBrands();

  // ------------------------------------------------------------ la grafica nei Media di un progetto video
  async function toVideoDialog() {
    let list = [];
    try { list = await get('/api/projects'); } catch (e) { /* */ }
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const send = async (p) => {
      close(); setBusy('Preparo la grafica…');
      try {
        await save();
        const c = await pageCanvas(doc, page(), 1, assets);
        const b = await new Promise((r) => c.toBlob(r, 'image/png'));
        const r = await fetch(`/api/d/${gid}/tomedia?pid=${encodeURIComponent(p.id)}&name=${encodeURIComponent(doc.name)}&token=${TOKEN}`, { method: 'PUT', body: b });
        const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Non riuscito');
        const el = h('div', { class: 'dz-done' }, icon('check', 15, '#34D399', 2.6),
          h('div', null, h('b', null, 'Aggiunta ai Media'), h('small', { 'data-notr': '' }, p.name)),
          h('button', { class: 'btn sm', onclick: () => { el.remove(); window.dispatchEvent(new CustomEvent('nf-nav', { detail: ['editor', p.id] })); } }, 'Apri il video'),
          h('button', { class: 'dz-ib', 'aria-label': 'Chiudi', onclick: () => el.remove() }, icon('x', 14)));
        document.body.append(el); setTimeout(() => el.remove(), 9000);
      } catch (e) { toast(e.message, true); }
      setBusy(null);
    };
    bg.append(h('div', { class: 'modal', style: { width: 'min(520px, 94vw)' } }, h('h2', null, 'Usa in un video'),
      h('p', { class: 'dz-note' }, 'La pagina che vedi va nei Media del progetto, come un\'immagine: la metti nella timeline quando vuoi.'),
      list.length ? h('div', { class: 'dz-vlist' }, ...list.slice(0, 60).map((p) => h('button', { class: 'dz-vrow', onclick: () => send(p) }, icon('film', 14), h('span', { 'data-notr': '' }, p.name), h('small', null, p.kind === 'blank' ? 'Progetto' : 'Video'))))
        : h('p', null, 'Non hai ancora progetti video.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  // ------------------------------------------------------------ altri formati in un clic (stessa grafica, misure diverse)
  function resizeAllDialog() {
    const picked = new Set();
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const grid = h('div', { class: 'dz-mrgrid' });
    const go = h('button', { class: 'btn primary', disabled: true }, 'Crea');
    const paint = () => {
      rc(grid, ...PRESETS.filter((p) => !(p[3] === doc.w && p[4] === doc.h)).map((p) => h('button', { class: 'dz-mrt' + (picked.has(p[0]) ? ' on' : ''), onclick: () => { if (picked.has(p[0])) picked.delete(p[0]); else picked.add(p[0]); paint(); } },
        h('span', { class: 'dz-mrchk' }, picked.has(p[0]) ? icon('check', 11, '#fff', 3) : null), h('b', null, p[1]), h('small', null, p[2].split(' · ')[0]))));
      go.disabled = !picked.size; go.textContent = picked.size ? tr('Crea') + ' ' + picked.size : tr('Crea');
    };
    go.addEventListener('click', async () => {
      go.disabled = true;
      await save();
      const made = [];
      for (const id of picked) {
        const p = PRESETS.find((x) => x[0] === id);
        go.textContent = tr('Creo') + ' ' + (made.length + 1) + '/' + picked.size + '…';
        try {
          const d = await post(`/api/d/${gid}/duplicate`, { name: doc.name + ' – ' + tr(p[1]) });
          adaptDoc(d, p[3], p[4]); d.preset = p[0];
          const r = await fetch(`/api/d/${d.id}?token=${TOKEN}`, { method: 'PUT', body: JSON.stringify(d) });
          if (r.ok) made.push(d);
        } catch (e) { toast(e.message, true); }
      }
      close();
      if (made.length) {
        const el = h('div', { class: 'dz-done' }, icon('check', 15, '#34D399', 2.6),
          h('div', null, h('b', null, made.length === 1 ? tr('1 formato creato') : made.length + ' ' + tr('formati creati')), h('small', null, 'Li trovi in Grafica, nella home')),
          h('button', { class: 'dz-ib', 'aria-label': 'Chiudi', onclick: () => el.remove() }, icon('x', 14)));
        document.body.append(el); setTimeout(() => el.remove(), 8000);
      }
    });
    paint();
    bg.append(h('div', { class: 'modal dz-mrmodal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Altri formati' },
      h('h2', null, 'Crea in altri formati'),
      h('p', { class: 'dz-note' }, 'Ogni formato diventa una grafica nuova: gli sfondi riempiono la tela, il resto si adatta e resta al suo posto. Poi ritocchi quello che vuoi.'),
      grid, h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }
  // adatta un documento a nuove misure: sfondi a tutta tela "coprono", il resto si scala e mantiene la posizione relativa
  function adaptDoc(d, nw, nh) {
    const W0 = d.w, H0 = d.h, fit = Math.min(nw / W0, nh / H0), cover = Math.max(nw / W0, nh / H0);
    // gli elementi si scalano con l'area (non solo con il lato corto), poi restano dentro la tela
    const kEl = Math.min(Math.sqrt((nw * nh) / (W0 * H0)), fit * 1.5);
    for (const p of d.pages) for (const l of p.layers) {
      if (l.type === 'adjust') continue;
      const b = bounds(l);
      const full = b.w >= W0 * 0.9 && b.h >= H0 * 0.9;
      let k = full ? cover : kEl;
      if (!full) k = Math.min(k, (nw * 0.96) / Math.max(1, b.w), (nh * 0.96) / Math.max(1, b.h), Math.max(k, fit));
      const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
      scaleAround(l, cx, cy, k, k);
      if (l.type === 'text') l.h = textHeight(l);
      let ncx = full ? nw / 2 + (cx - W0 / 2) * k : (cx / W0) * nw, ncy = full ? nh / 2 + (cy - H0 / 2) * k : (cy / H0) * nh;
      if (!full) {
        const hw = b.w * k / 2, hh = b.h * k / 2;
        if (hw * 2 <= nw) ncx = Math.max(hw, Math.min(nw - hw, ncx));
        if (hh * 2 <= nh) ncy = Math.max(hh, Math.min(nh - hh, ncy));
      }
      moveBy(l, ncx - cx, ncy - cy);
    }
    d.w = nw; d.h = nh;
  }

  // ------------------------------------------------------------ immagini create dall'AI
  async function aiDialog() {
    let info = { ready: false };
    try { info = await get('/api/designs/ai-info'); } catch (e) { /* */ }
    const st = { kind: 'image', prompt: '' };
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const ta = h('textarea', { class: 'input dz-aita', rows: 4, placeholder: 'Es. "Un tramonto sul mare in stile fotografico, colori caldi"' });
    ta.addEventListener('input', () => { st.prompt = ta.value; });
    ta.addEventListener('keydown', (e) => e.stopPropagation());
    const kinds = h('div', { class: 'dz-fmts two' });
    const paintK = () => rc(kinds, ...[['image', 'Immagine', 'A tutta tela, nelle proporzioni della grafica'], ['sticker', 'Elemento', 'Oggetto o icona con lo sfondo trasparente']].map(([k, n, d]) =>
      h('button', { class: 'dz-fmt' + (st.kind === k ? ' on' : ''), onclick: () => { st.kind = k; paintK(); } }, h('b', null, n), h('small', null, d))));
    paintK();
    const r = doc.w / doc.h, ratio = r > 1.3 ? '16:9' : r < 0.77 ? '9:16' : '1:1';
    const go = h('button', { class: 'btn primary', disabled: info.ready ? null : true, onclick: async () => {
      if (!st.prompt.trim()) { ta.focus(); return; }
      close(); setBusy('L\'AI crea l\'immagine…', 0.05);
      try {
        const j = await post(`/api/d/${gid}/ai`, { prompt: st.prompt, kind: st.kind, ratio });
        const res = await pollJob(j.id, (x) => setBusy(x.message || 'L\'AI crea l\'immagine…', x.progress));
        if (res.status !== 'done') throw new Error(res.error || 'Non riuscito');
        const f = res.result;
        const l = imageLayer(f.file, f.w, f.h, doc, st.prompt.slice(0, 40));
        if (st.kind === 'image') { const k = Math.max(doc.w / f.w, doc.h / f.h); l.w = f.w * k; l.h = f.h * k; l.x = (doc.w - l.w) / 2; l.y = (doc.h - l.h) / 2; }
        if (st.kind === 'image' && !one()) { layers().unshift(l); S.sel = [l.id]; commit(); } else addLayer(l);
        toast('Immagine creata');
      } catch (er) { toast(er.message, true); }
      setBusy(null);
    } }, icon('sparkle', 14, '#fff', 2), 'Crea');
    bg.append(h('div', { class: 'modal dz-aimodal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Crea con l\'AI' },
      h('div', { class: 'dz-aih' }, h('span', { class: 'dz-aiic' }, icon('sparkle', 14, '#fff', 2)), h('div', null, h('b', null, 'Crea un\'immagine con l\'AI'), h('small', null, 'Descrivila: arriva come livello nuovo, la modifichi come le altre'))),
      ta, kinds,
      info.ready ? h('p', { class: 'dz-note' }, 'Costo circa $' + (+info.usd || 0.08).toFixed(2) + ' a immagine, con la tua chiave AI.')
        : h('p', { class: 'dz-note warn' }, info.error || 'Serve una chiave AI per le immagini: aggiungila in Storie AI → Chiavi AI.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
    setTimeout(() => ta.focus(), 30);
  }
  function setBusy(msg, p) {
    S.busy = msg;
    if (!msg) { busyEl.style.display = 'none'; return; }
    busyEl.style.display = '';
    rc(busyEl, h('div', { class: 'spinner' }), h('span', null, msg + (p ? ' · ' + Math.round(p * 100) + '%' : '')));
  }

  // ------------------------------------------------------------ strumenti
  function setTool(t, quiet) {
    if (S.xf && t !== 'move') endFree(true);
    if (S.editing && t !== 'move') stopEdit(true);
    if (S.pen && t !== 'pen') finishPen(false);
    if (S.crop && t !== 'crop') { S.crop = null; }
    S.tool = t;
    if (t === 'crop') startCropMode();
    stage.style.cursor = t === 'hand' ? 'grab' : '';
    paintTools(); paintOpts(); draw();
    void quiet;
  }
  function paintTools() {
    rc(toolsBar, 
      ...TOOLS.map(([id, ic, tip, key]) => h('button', { class: 'dz-tool' + (S.tool === id ? ' on' : ''), 'aria-label': tip, 'data-tip': tip + ' (' + key + ')', onclick: () => setTool(id) },
        icon(id === 'shape' ? (SHAPES.find((s) => s[0] === S.shape) || SHAPES[0])[1] : id === 'select' ? (SELS.find((s) => s[0] === S.selMode) || SELS[0])[1] : ic, 18, 'currentColor', 1.8))),
      h('div', { class: 'dz-tsep' }),
      h('button', { class: 'dz-tool', 'aria-label': 'Aggiungi immagini', 'data-tip': 'Aggiungi immagini dal computer', onclick: pickImages }, icon('image', 18, 'currentColor', 1.8)),
      h('button', { class: 'dz-tool brand', 'aria-label': 'Brand kit', 'data-tip': 'Brand kit: i tuoi colori, font e loghi', onclick: (e) => openBrand(e.currentTarget) }, icon('palette', 18, 'currentColor', 1.8)),
      h('button', { class: 'dz-tool ai', 'aria-label': 'Crea con l\'AI', 'data-tip': 'Crea un\'immagine con l\'AI', onclick: aiDialog }, icon('sparkle', 18, 'currentColor', 1.8)),
      h('div', { class: 'grow' }),
      colorButton(S.color, (c) => setColor(c, true), { cls: 'dz-tcolor', tip: 'Colore (pennello, testo e forme)' }));
  }
  function paintOpts() {
    const t = S.tool;
    const kids = [];
    const lab = (s) => h('span', { class: 'dz-olab' }, s);
    const rng = (v, min, max, step, fn, w = 110) => { const i = h('input', { type: 'range', min, max, step, value: v, style: { width: w + 'px' } }); i.addEventListener('input', () => fn(+i.value)); return i; };
    if (S.xf && t === 'move') {
      kids.push(...XF_MODES.map(([k, n]) => h('button', { class: 'dz-ochip txt' + (S.xf.mode === k ? ' on' : ''), onclick: () => setXfMode(k) }, n)));
      if (S.xf.mode === 'warp') {
        const PRE = [['', 'Personalizzato'], ['arc', 'Arco'], ['arcUp', 'Arco in alto'], ['arcDown', 'Arco in basso'], ['flag', 'Bandiera'], ['wave', 'Onda'], ['bulge', 'Gonfia'], ['squeeze', 'Comprimi'], ['rise', 'Sali']];
        const amt = S.xf.amt == null ? 50 : S.xf.amt;
        const av = h('b', { class: 'dz-oval' }, amt + '%');
        kids.push(h('span', { class: 'dz-osep' }), lab('Stile'), selectEl(PRE, S.xf.preset || '', (v) => { if (v) warpPreset(v, S.xf.amt == null ? 50 : S.xf.amt); else S.xf.preset = ''; paintOpts(); }),
          S.xf.preset ? lab('Curvatura') : null, S.xf.preset ? rng(amt, -100, 100, 1, (v) => { av.textContent = v + '%'; warpPreset(S.xf.preset, v); }, 110) : null, S.xf.preset ? av : null);
      }
      kids.push(h('span', { class: 'dz-ohint' }, S.xf.mode === 'warp' ? 'Trascina i punti e le maniglie · Alt: angolo senza maniglie' : S.xf.mode === 'distort' ? 'Trascina gli angoli dove vuoi' : MOD + 'trascina: angolo libero'),
        h('span', { class: 'grow' }),
        h('button', { class: 'btn sm ghost', onclick: () => { const l = xfLayer(); if (l) { unwarp(l); S.xf.preset = ''; setXfMode(S.xf.mode); } } }, 'Ripristina'),
        h('button', { class: 'btn sm ghost', onclick: () => endFree(false) }, 'Annulla'),
        h('button', { class: 'btn sm primary', onclick: () => endFree(true) }, icon('check', 13, '#fff', 2.4), 'Applica'));
      rc(opts, ...kids); return;
    }
    if (t === 'select') {
      kids.push(...SELS.map(([k, ic, n]) => h('button', { class: 'dz-ochip' + (S.selMode === k ? ' on' : ''), 'data-tip': n, 'aria-label': n, onclick: () => { S.selMode = k; paintOpts(); paintTools(); } }, icon(ic, 15, 'currentColor', 1.9))),
        h('span', { class: 'dz-osep' }),
        ...[['new', 'Nuova'], ['add', 'Aggiungi'], ['sub', 'Togli'], ['int', 'Interseca']].map(([k, n]) => h('button', { class: 'dz-ochip txt' + (S.selOp === k ? ' on' : ''), 'data-tip': { new: 'Nuova selezione', add: 'Aggiungi (Shift)', sub: 'Togli (Alt)', int: 'Interseca (Shift+Alt)' }[k], onclick: () => { S.selOp = k; paintOpts(); } }, n)));
      if (S.selMode === 'wand') {
        const tv = h('b', { class: 'dz-oval' }, String(S.tol));
        kids.push(h('span', { class: 'dz-osep' }), lab('Tolleranza'), rng(S.tol, 0, 128, 1, (v) => { S.tol = v; tv.textContent = String(v); }, 90), tv,
          h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.contig ? true : null, onchange: (ev) => { S.contig = ev.target.checked; } }), 'Solo vicini'));
      }
      kids.push(h('span', { class: 'dz-osep' }), h('button', { class: 'btn sm dz-subj', disabled: S.busy ? true : null, onclick: selectSubject }, icon('sparkle', 13, 'currentColor', 2), 'Seleziona soggetto'));
      if (sel.on) {
        const act = (ic, n, fn, tip) => h('button', { class: 'dz-ochip txt', 'data-tip': tip || n, onclick: fn }, ic ? icon(ic, 14, 'currentColor', 1.9) : null, n);
        kids.push(h('span', { class: 'dz-osep' }),
          act('swap', 'Inverti', () => { sel.invert(); selChanged(); }, 'Inverti la selezione (' + MOD + 'Shift+I)'),
          act(null, 'Sfuma', async () => { const v = await promptBox('Sfuma i bordi', 'Quanti pixel di bordo morbido?', '10', 'Sfuma'); if (v && +v > 0) { sel.feather(+v); selChanged(); } }, 'Bordi morbidi'),
          act('palette', 'Riempi', () => fillSel(S.color), 'Riempi con il colore (Alt+Canc)'),
          act('trash', 'Cancella', clearInSel, 'Togli dal livello scelto (Canc)'),
          act('duplicate', 'Nuovo livello', () => layerFromSel(false), 'Copia in un livello nuovo (' + MOD + 'J)'),
          act('mask', 'Maschera', maskFromSel, 'Maschera del livello scelto'),
          act('x', 'Deseleziona', () => { sel.clear(); selChanged(); }, 'Deseleziona (' + MOD + 'D)'));
      } else kids.push(h('span', { class: 'dz-ohint' }, 'Shift: aggiungi · Alt: togli'));
    } else if (t === 'pen') {
      kids.push(h('span', { class: 'dz-ohint' }, S.pen ? 'Clic: punto · trascina: curva · clic sul primo punto: chiudi · Invio: finisci · ⌫: togli l\'ultimo punto'
        : penLayer() ? 'Trascina i punti e le maniglie · doppio clic su un punto: angolo o curva · Alt: maniglie separate' : 'Clic per i punti, trascina per le curve: disegni forme libere che restano modificabili'));
      if (penLayer()) kids.push(h('span', { class: 'grow' }), h('button', { class: 'btn sm', onclick: () => pathToSel(penLayer()) }, icon('marquee', 13), 'Selezione dal tracciato'));
    } else if (t === 'heal') {
      const sv = h('b', { class: 'dz-oval' }, S.brush.size + ' px');
      kids.push(lab('Dimensione'), rng(S.brush.size, 2, 300, 1, (v) => { S.brush.size = v; sv.textContent = v + ' px'; }), sv,
        h('span', { class: 'dz-ohint' }, 'Dipingi sopra la macchia o il piccolo oggetto da togliere: viene ricostruito da quello che c\'è intorno'));
    } else if (t === 'clone') {
      const sv = h('b', { class: 'dz-oval' }, S.brush.size + ' px');
      kids.push(lab('Dimensione'), rng(S.brush.size, 1, 400, 1, (v) => { S.brush.size = v; sv.textContent = v + ' px'; }), sv,
        lab('Durezza'), rng(Math.round(S.brush.hard * 100), 0, 100, 1, (v) => { S.brush.hard = v / 100; }, 90),
        lab('Opacità'), rng(Math.round(S.brush.opacity * 100), 1, 100, 1, (v) => { S.brush.opacity = v / 100; }, 90),
        h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.cloneAligned ? true : null, onchange: (ev) => { S.cloneAligned = ev.target.checked; S.cloneOff = null; } }), 'Allineato'),
        h('span', { class: 'dz-ohint' }, S.cloneSrc ? 'Dipingi: copia da dove hai scelto · Alt + clic per cambiare punto' : 'Alt + clic sul punto da copiare, poi dipingi dove vuoi'));
    } else if (t === 'brush' || t === 'eraser') {
      const sv = h('b', { class: 'dz-oval' }, S.brush.size + ' px');
      kids.push(lab('Dimensione'), rng(S.brush.size, 1, 400, 1, (v) => { S.brush.size = v; sv.textContent = v + ' px'; }), sv,
        lab('Durezza'), rng(Math.round(S.brush.hard * 100), 0, 100, 1, (v) => { S.brush.hard = v / 100; }, 90),
        lab('Opacità'), rng(Math.round(S.brush.opacity * 100), 1, 100, 1, (v) => { S.brush.opacity = v / 100; }, 90));
      const l = one();
      if (l && l.mask) kids.push(h('span', { class: 'dz-osep' }), h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.maskEdit ? true : null, onchange: (e) => { S.maskEdit = e.target.checked; refresh(); } }), 'Dipingi sulla maschera'));
      kids.push(h('span', { class: 'dz-ohint' }, t === 'eraser' ? (l && l.type !== 'paint' ? 'Sui livelli non di pittura la gomma usa la maschera: niente si perde' : '') : 'Tieni premuto Alt per il contagocce · [ ] cambia la dimensione'));
    } else if (t === 'shape') {
      kids.push(...SHAPES.map(([k, ic, n]) => h('button', { class: 'dz-ochip' + (S.shape === k ? ' on' : ''), 'data-tip': n, 'aria-label': n, onclick: () => { S.shape = k; paintOpts(); paintTools(); } }, icon(ic, 15, 'currentColor', 1.9))),
        h('span', { class: 'dz-ohint' }, 'Trascina sulla tela · Shift: proporzioni fisse · Alt: dal centro'));
    } else if (t === 'text') {
      kids.push(h('span', { class: 'dz-ohint' }, 'Clic sulla tela per scrivere · doppio clic su un testo per modificarlo'));
    } else if (t === 'crop') {
      const ratios = [[0, 'Libero'], [1, '1:1'], [4 / 5, '4:5'], [9 / 16, '9:16'], [16 / 9, '16:9']];
      kids.push(...ratios.map(([r, n]) => h('button', { class: 'dz-ochip txt' + ((S.crop && S.crop.ratio) === r ? ' on' : ''), onclick: () => {
        if (!S.crop) startCropMode(); S.crop.ratio = r;
        if (r) { const c = S.crop; let w = c.w, hh = w / r; if (hh > doc.h) { hh = doc.h; w = hh * r; } c.w = w; c.h = hh; c.x = (doc.w - w) / 2; c.y = (doc.h - hh) / 2; }
        draw(); paintOpts();
      } }, n)),
      h('span', { class: 'grow' }),
      h('button', { class: 'btn sm ghost', onclick: () => setTool('move') }, 'Annulla'),
      h('button', { class: 'btn sm primary', onclick: applyCrop }, icon('check', 13, '#fff', 2.4), 'Applica'));
    } else if (t === 'eyedrop') {
      kids.push(h('span', { class: 'dz-ohint' }, 'Clic sulla tela per prendere un colore: va al testo o alla forma scelti'));
    } else if (t === 'hand') {
      kids.push(h('span', { class: 'dz-ohint' }, 'Trascina per spostare la vista · rotellina + ' + MOD.replace('+', '') + ' per lo zoom'));
    } else {
      kids.push(h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.snap ? true : null, onchange: (e) => { S.snap = e.target.checked; } }), 'Allineamento magnetico'),
        h('span', { class: 'dz-osep' }),
        ...[['alignL', 'l', 'Allinea a sinistra'], ['alignCH', 'ch', 'Centra in orizzontale'], ['alignR', 'r', 'Allinea a destra'], ['alignT', 't', 'Allinea in alto'], ['alignCV', 'cv', 'Centra in verticale'], ['alignB', 'b', 'Allinea in basso']]
          .map(([ic, k, n]) => h('button', { class: 'dz-ochip', 'data-tip': n + (S.sel.length > 1 ? '' : ' (alla tela)'), 'aria-label': n, disabled: S.sel.length ? null : true, onclick: () => align(k) }, icon(ic, 15, 'currentColor', 1.8))),
        S.sel.length > 2 ? h('span', { class: 'dz-osep' }) : null,
        ...(S.sel.length > 2 ? [['distH', 'h', 'Distribuisci in orizzontale'], ['distV', 'v', 'Distribuisci in verticale']].map(([ic, k, n]) => h('button', { class: 'dz-ochip', 'data-tip': n, 'aria-label': n, onclick: () => distribute(k) }, icon(ic, 15, 'currentColor', 1.8))) : []),
        one() && ['image', 'paint', 'shape', 'path', 'text'].includes(one().type) ? h('span', { class: 'dz-osep' }) : null,
        one() && ['image', 'paint', 'shape', 'path', 'text'].includes(one().type) ? h('button', { class: 'dz-ochip txt', 'data-tip': 'Distorci, prospettiva, inclina, altera (' + MOD + 'T)', onclick: (e) => transformMenu(e.currentTarget) }, icon('grid', 14, 'currentColor', 1.8), 'Trasforma') : null,
        h('span', { class: 'dz-ohint' }, S.sel.length ? 'Alt + trascina: duplica · Shift: blocca la direzione' : 'Clic su un livello per sceglierlo · ' + MOD + 'clic: dentro i gruppi'));
    }
    rc(opts, ...kids);
  }

  // ------------------------------------------------------------ pannello proprieta'
  let refreshT = 0;
  function refresh(full) { clearTimeout(refreshT); refreshT = setTimeout(() => { if (!alive) return; paintProps(); paintLayers(); paintPages(); paintOpts(); undoB.disabled = hist.idx <= 0; redoB.disabled = hist.idx >= hist.stack.length - 1; }, full ? 0 : 16); }
  const sec = (title, kids, opt = {}) => {
    const key = 'nf.dz.sec.' + title;
    let open = opt.open != null ? opt.open : (() => { try { return localStorage.getItem(key) !== '0'; } catch (e) { return true; } })();
    const body = h('div', { class: 'dz-secb' }, ...kids);
    const el = h('section', { class: 'dz-sec' + (open ? ' open' : '') },
      h('button', { class: 'dz-sech', onclick: () => { open = !open; el.classList.toggle('open', open); try { localStorage.setItem(key, open ? '1' : '0'); } catch (e) { /* */ } } },
        icon('chev', 12, 'currentColor', 2.2), h('span', null, title), opt.right || null), body);
    return el;
  };
  // campo numerico: si scrive, si usano le frecce, o si trascina l'etichetta
  function num(label, val, set, o = {}) {
    const inp = h('input', { class: 'dz-num', value: fmtN(val, o.dec), inputmode: 'decimal', 'aria-label': o.aria || label });
    const done = (v, key) => { if (!isFinite(v)) return; if (o.min != null) v = Math.max(o.min, v); if (o.max != null) v = Math.min(o.max, v); set(v); inp.value = fmtN(v, o.dec) ; commit(key); };
    inp.addEventListener('change', () => done(parseFloat(inp.value.replace(',', '.'))));
    inp.addEventListener('keydown', (e) => { if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); const v = parseFloat(inp.value.replace(',', '.')) || 0; done(v + (e.key === 'ArrowUp' ? 1 : -1) * (e.shiftKey ? 10 : o.step || 1), 'num' + label); } else if (e.key === 'Enter') inp.blur(); });
    const lab = h('label', { class: 'dz-nlab' }, label);
    lab.addEventListener('pointerdown', (e) => {
      e.preventDefault(); const x0 = e.clientX, v0 = parseFloat(inp.value.replace(',', '.')) || 0; (() => { try { lab.setPointerCapture(e.pointerId); } catch (er) { /* puntatore gia' rilasciato */ } })();
      const mv = (ev) => { const v = v0 + Math.round((ev.clientX - x0) / 2) * (o.step || 1) * (ev.shiftKey ? 10 : 1); done(v, 'drag' + label); };
      const up = () => { lab.removeEventListener('pointermove', mv); lab.removeEventListener('pointerup', up); };
      lab.addEventListener('pointermove', mv); lab.addEventListener('pointerup', up);
    });
    return h('div', { class: 'dz-field' + (o.wide ? ' wide' : '') }, lab, inp, o.unit ? h('span', { class: 'dz-unit' }, o.unit) : null);
  }
  const fmtN = (v, dec = 0) => (v == null || !isFinite(v) ? '' : String(+(+v).toFixed(dec)));
  function slider(label, val, min, max, step, set, unit = '', key) {
    const out = h('b', null, fmtN(val, step < 1 ? 2 : 0) + unit);
    const i = h('input', { type: 'range', min, max, step, value: val });
    i.addEventListener('input', () => { set(+i.value); out.textContent = fmtN(+i.value, step < 1 ? 2 : 0) + unit; draw(); commit(key || 'sl' + label); });
    i.addEventListener('dblclick', () => { const d = min < 0 ? 0 : min; i.value = d; set(d); out.textContent = fmtN(d) + unit; commit(); });
    return h('div', { class: 'dz-slider' }, h('span', null, label), i, out);
  }
  const row = (...k) => h('div', { class: 'dz-row' }, ...k);
  const chipBtn = (ic, tip, on, fn) => h('button', { class: 'dz-ochip' + (on ? ' on' : ''), 'aria-label': tip, 'data-tip': tip, onclick: fn }, typeof ic === 'string' && ic.length > 2 ? icon(ic, 15, 'currentColor', 1.9) : h('b', null, ic));
  function selectEl(items, cur, fn) {
    const s = h('select', { class: 'dz-select' }, ...items.map(([v, n]) => h('option', { value: v, selected: v === cur ? true : null }, n)));
    s.addEventListener('change', () => fn(s.value));
    return s;
  }

  function paintProps() {
    const ls = selLayers();
    const l = ls.length === 1 ? ls[0] : null;
    const kids = [];
    if (!ls.length) {
      const p = page();
      kids.push(h('div', { class: 'dz-phead' }, h('span', { class: 'dz-pic' }, icon('frame', 14, 'currentColor', 2)), h('div', null, h('b', null, 'Tela'), h('small', null, doc.w + ' × ' + doc.h + ' px'))));
      kids.push(sec('Dimensioni', [
        row(num(LANG === 'en' ? 'W' : 'L', doc.w, (v) => { resizeCanvas(v, doc.h, false); }, { min: 1, max: 16000, unit: 'px' }), num(LANG === 'en' ? 'H' : 'A', doc.h, (v) => { resizeCanvas(doc.w, v, false); }, { min: 1, max: 16000, unit: 'px' })),
        h('div', { class: 'dz-btnrow' },
          h('button', { class: 'btn sm', onclick: () => resizeDialog() }, 'Ridimensiona…'),
          h('button', { class: 'btn sm', onclick: () => setTool('crop') }, icon('crop', 13), 'Ritaglia')),
      ]));
      kids.push(sec('Sfondo della pagina', [
        row(colorButton(p.bg || '#FFFFFF', (c) => { p.bg = c; commit('bg'); }, { gradient: true, label: p.bg ? null : 'Trasparente' }),
          h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: p.bg ? null : true, onchange: (e) => { p.bg = e.target.checked ? null : '#FFFFFF'; commit(); } }), 'Trasparente')),
      ]));
      kids.push(h('div', { class: 'dz-empty' }, icon('cursor', 18, 'currentColor', 1.6), h('span', null, 'Scegli un livello sulla tela o nella lista per modificarlo')));
      rc(props, ...kids);
      return;
    }
    if (!l) {
      kids.push(h('div', { class: 'dz-phead' }, h('span', { class: 'dz-pic' }, icon('layers', 14, 'currentColor', 2)), h('div', null, h('b', null, ls.length + ' livelli'), h('small', null, 'Selezione multipla'))));
      kids.push(sec('Allinea', [h('div', { class: 'dz-btnrow' },
        ...[['alignL', 'l'], ['alignCH', 'ch'], ['alignR', 'r'], ['alignT', 't'], ['alignCV', 'cv'], ['alignB', 'b']].map(([ic, k]) => chipBtn(ic, 'Allinea', false, () => align(k))))]));
      kids.push(sec('Opacità', [slider('Opacità', Math.round(ls[0].opacity * 100), 0, 100, 1, (v) => ls.forEach((x) => { x.opacity = v / 100; }), '%')]));
      kids.push(h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: groupSel }, icon('group', 13), 'Raggruppa'), h('button', { class: 'btn sm', onclick: () => duplicateSel() }, icon('duplicate', 13), 'Duplica'), h('button', { class: 'btn sm danger', onclick: deleteSel }, icon('trash', 13), 'Elimina')));
      rc(props, ...kids);
      return;
    }
    const TYPE = { path: ['pen', 'Tracciato'], text: ['type', 'Testo'], shape: ['square', 'Forma'], image: ['image', 'Immagine'], paint: ['brush', 'Pittura'], group: ['group', 'Gruppo'], adjust: ['adjust', 'Regolazione'] }[l.type];
    const nameIn = h('input', { class: 'dz-pname', value: l.name || TYPE[1], 'aria-label': 'Nome del livello', 'data-notr': '' });
    nameIn.addEventListener('change', () => { l.name = nameIn.value.trim() || TYPE[1]; commit(); });
    nameIn.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') nameIn.blur(); });
    kids.push(h('div', { class: 'dz-phead' }, h('span', { class: 'dz-pic' }, icon(TYPE[0], 14, 'currentColor', 2)), h('div', null, nameIn, h('small', null, TYPE[1] + (l.locked ? ' · bloccato' : ''))),
      ib(l.locked ? 'lock' : 'unlock', l.locked ? 'Sblocca' : 'Blocca', () => { l.locked = !l.locked; commit(); })));
    // posizione e misure
    if (l.type !== 'adjust') {
      const tr = [];
      if (l.type === 'group') {
        const b = bounds(l);
        tr.push(row(num('X', b.x, (v) => moveBy(l, v - b.x, 0)), num('Y', b.y, (v) => moveBy(l, 0, v - b.y))));
      } else {
        let ratio = l.w / l.h;
        tr.push(row(num('X', l.x, (v) => { l.x = v; }), num('Y', l.y, (v) => { l.y = v; })),
          row(num(LANG === 'en' ? 'W' : 'L', l.w, (v) => { if (l.type === 'text') { l.w = v; l.auto = false; l.h = textHeight(l); } else { const lock = l.type === 'image'; l.w = v; if (lock) l.h = v / ratio; } }, { min: 1 }),
            l.type === 'text' ? h('div', { class: 'dz-field ro' }, h('label', { class: 'dz-nlab' }, LANG === 'en' ? 'H' : 'A'), h('span', { class: 'dz-num ro' }, fmtN(l.h))) : num(LANG === 'en' ? 'H' : 'A', l.h, (v) => { const lock = l.type === 'image'; l.h = v; if (lock) l.w = v * ratio; }, { min: 1 })),
          row(num('Rotazione', l.rot || 0, (v) => { l.rot = ((v % 360) + 540) % 360 - 180; }, { unit: '°', dec: 1, wide: true }),
            h('div', { class: 'dz-btnrow tight' }, chipBtn('flipH', 'Rifletti in orizzontale', l.flipX, () => { l.flipX = !l.flipX; commit(); }), chipBtn('flipV', 'Rifletti in verticale', l.flipY, () => { l.flipY = !l.flipY; commit(); }))));
      }
      tr.push(h('div', { class: 'dz-btnrow' }, ...[['alignL', 'l'], ['alignCH', 'ch'], ['alignR', 'r'], ['alignT', 't'], ['alignCV', 'cv'], ['alignB', 'b']].map(([ic, k]) => chipBtn(ic, 'Allinea alla tela', false, () => align(k)))));
      kids.push(sec('Posizione', tr));
    }
    kids.push(sec('Livello', [slider('Opacità', Math.round((l.opacity == null ? 1 : l.opacity) * 100), 0, 100, 1, (v) => { l.opacity = v / 100; }, '%'),
      row(h('span', { class: 'dz-flab' }, 'Fusione'), selectEl(BLENDS, l.blend || 'normal', (v) => { l.blend = v; commit(); }))]));
    // per tipo
    if (l.type === 'text') kids.push(textProps(l));
    if (l.type === 'shape') kids.push(shapeProps(l));
    if (l.type === 'path') kids.push(pathProps(l));
    if (l.type === 'image') kids.push(imageProps(l));
    if (l.type === 'adjust') kids.push(adjustProps(l));
    if (l.type === 'group') kids.push(sec('Gruppo', [h('p', { class: 'dz-note' }, (l.children || []).length + ' livelli dentro'), h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: ungroup }, 'Separa il gruppo'))]));
    if (l.type === 'paint') kids.push(sec('Pittura', [h('p', { class: 'dz-note' }, 'Dipingi con il pennello (B), cancella con la gomma (E).')]));
    if (l.type === 'image' || l.type === 'paint') kids.push(filterProps(l));
    if (l.type !== 'group' && l.type !== 'adjust') { kids.push(fxProps(l)); kids.push(maskProps(l)); }
    rc(props, ...kids);
  }

  function textProps(l) {
    const ta = h('textarea', { class: 'dz-ta', rows: 2, 'data-notr': '' }); ta.value = l.text || '';
    ta.addEventListener('input', () => { l.text = ta.value; if (l.auto) { const cx = l.x + l.w / 2; l.w = Math.max(20, textNaturalWidth(l)); l.x = cx - l.w / 2; } l.h = textHeight(l); l.name = l.text.split('\n')[0].slice(0, 40) || 'Testo'; draw(); commit('text'); });
    ta.addEventListener('keydown', (e) => e.stopPropagation());
    const refit = () => { if (l.auto) { const cx = l.x + l.w / 2; l.w = Math.max(20, textNaturalWidth(l)); l.x = cx - l.w / 2; } l.h = textHeight(l); };
    const fp = fontPicker(l.font, (f) => { l.font = f; ensureFont(f).then(() => { dropCache(l.id); refit(); commit(); }); });
    const W = [[300, 'Leggero'], [400, 'Normale'], [500, 'Medio'], [600, 'Semi'], [700, 'Grassetto'], [800, 'Extra'], [900, 'Nero']];
    return sec('Testo', [ta, fp,
      row(num('Dim.', l.size, (v) => { l.size = v; refit(); }, { min: 4, max: 2000, unit: 'px' }), selectEl(W.map(([v, n]) => [String(v), n]), String(l.weight || 400), (v) => { l.weight = +v; refit(); commit(); })),
      h('div', { class: 'dz-btnrow' },
        chipBtn('tAlignL', 'A sinistra', l.align === 'left', () => { l.align = 'left'; commit(); }),
        chipBtn('tAlignC', 'Al centro', !l.align || l.align === 'center', () => { l.align = 'center'; commit(); }),
        chipBtn('tAlignR', 'A destra', l.align === 'right', () => { l.align = 'right'; commit(); }),
        h('span', { class: 'dz-vsep' }),
        chipBtn('italic', 'Corsivo', l.italic, () => { l.italic = !l.italic; refit(); commit(); }),
        chipBtn('AA', 'Tutto maiuscolo', l.upper, () => { l.upper = !l.upper; refit(); commit(); })),
      l.onPath ? h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: () => setTool('pen') }, icon('pen', 13), 'Modifica il tracciato'),
        h('button', { class: 'btn sm ghost', onclick: () => { l.onPath = false; delete l.pts; l.auto = true; l.w = Math.max(20, textNaturalWidth(l)); l.h = textHeight(l); commit(); } }, 'Togli dal tracciato')) : null,
      l.onPath ? slider('Inizio', Math.round((l.pathStart || 0) * 100), -50, 50, 1, (v) => { l.pathStart = v / 100; }, '%', 'pstart') : null,
      l.onPath ? null : slider('Curva', l.curve || 0, -100, 100, 1, (v) => { const cx = l.x + l.w / 2, cy = l.y + l.h / 2; l.curve = v; l.auto = true; l.w = Math.max(20, textNaturalWidth(l)); l.h = textHeight(l); l.x = cx - l.w / 2; l.y = cy - l.h / 2; }, '', 'curve'),
      row(num('Interl.', l.lineH || 1.2, (v) => { l.lineH = v; refit(); }, { step: 0.05, dec: 2, min: 0.5, max: 4 }), num('Spazio', l.letter || 0, (v) => { l.letter = v; refit(); }, { min: -50, max: 200, unit: 'px' })),
      row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(l.fill || l.color, (c) => { if (typeof c === 'string') { l.color = c; delete l.fill; } else l.fill = c; commit('tcolor'); }, { gradient: true })),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: l.auto ? true : null, onchange: (e) => { l.auto = e.target.checked; refit(); commit(); } }), 'Larghezza automatica'),
    ]);
  }
  function shapeProps(l) {
    return sec('Forma', [
      h('div', { class: 'dz-btnrow' }, ...SHAPES.map(([k, ic, n]) => chipBtn(ic, n, l.kind === k, () => { l.kind = k; l.name = n; commit(); }))),
      row(h('span', { class: 'dz-flab' }, l.kind === 'line' ? 'Colore' : 'Riempimento'), colorButton(l.fill || '', (c) => { l.fill = c; commit('fill'); }, { gradient: l.kind !== 'line', none: l.kind !== 'line' })),
      l.kind !== 'line' ? row(h('span', { class: 'dz-flab' }, 'Bordo'), colorButton(l.stroke || '', (c) => { l.stroke = c; if (c && !l.strokeW) l.strokeW = Math.max(2, Math.round(Math.min(l.w, l.h) / 40)); commit('stroke'); }, { none: true }), num('Spess.', l.strokeW || 0, (v) => { l.strokeW = v; }, { min: 0, max: 500, unit: 'px' })) : null,
      l.kind === 'rect' ? slider('Angoli', l.radius || 0, 0, Math.round(Math.min(l.w, l.h) / 2), 1, (v) => { l.radius = v; }, ' px') : null,
      l.kind === 'poly' || l.kind === 'star' ? slider(l.kind === 'star' ? 'Punte' : 'Lati', l.sides || (l.kind === 'star' ? 5 : 6), 3, 16, 1, (v) => { l.sides = v; }) : null,
      l.kind === 'star' ? slider('Interno', Math.round((l.inner || 0.45) * 100), 10, 95, 1, (v) => { l.inner = v / 100; }, '%') : null,
    ]);
  }
  function pathProps(l) {
    return sec('Tracciato', [
      row(h('span', { class: 'dz-flab' }, 'Riempimento'), colorButton(l.fill || '', (c) => { l.fill = c; if (c) l.closed = true; commit('pfill'); }, { gradient: true, none: true })),
      row(h('span', { class: 'dz-flab' }, 'Bordo'), colorButton(l.stroke || '', (c) => { const old = (l.stroke && l.strokeW) || 0; l.stroke = c; if (c && !l.strokeW) l.strokeW = 4; adjustPathPad(l, old); commit('pstroke'); }, { none: true }),
        num('Spess.', l.strokeW || 0, (v) => { const old = (l.stroke && l.strokeW) || 0; l.strokeW = v; adjustPathPad(l, old); }, { min: 0, max: 400, unit: 'px' })),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: l.closed ? true : null, onchange: (ev) => { l.closed = ev.target.checked; commit(); } }), 'Tracciato chiuso'),
      h('div', { class: 'dz-btnrow' },
        h('button', { class: 'btn sm', onclick: () => setTool('pen') }, icon('pen', 13), 'Modifica i punti'),
        h('button', { class: 'btn sm', onclick: () => pathToSel(l) }, icon('marquee', 13), 'Selezione dal tracciato'),
        h('button', { class: 'btn sm', onclick: () => textOnPath(l) }, icon('type', 13), 'Scrivi sul tracciato')),
    ]);
  }
  // testo che segue il tracciato: un livello di testo con la stessa curva (il tracciato si nasconde, resta li')
  function textOnPath(p) {
    const size = Math.round(Math.max(24, Math.min(doc.w, doc.h) * 0.05));
    const mp = pathPad(p), tp = size * 0.75;
    const t = textLayer(doc, { text: tr('Il tuo testo sul tracciato'), color: S.colorSet ? S.color : '#111111', size, auto: false, onPath: true, align: 'center',
      pts: clone(p.pts), closed: !!p.closed, rot: p.rot || 0, flipX: !!p.flipX, flipY: !!p.flipY });
    t.x = p.x + mp - tp; t.y = p.y + mp - tp; t.w = p.w - 2 * mp + 2 * tp; t.h = p.h - 2 * mp + 2 * tp;
    t.name = tr('Testo sul tracciato');
    p.visible = false;
    const r = findLayer(layers(), p.id); r.arr.splice(r.i + 1, 0, t);
    S.sel = [t.id]; commit();
  }
  // il margine del riquadro segue lo spessore del bordo (la forma resta ferma)
  function adjustPathPad(l, oldW) {
    const nw = (l.stroke && l.strokeW) || 0, d = (nw - oldW) / 2;
    if (!d) return;
    l.x -= d; l.y -= d; l.w += 2 * d; l.h += 2 * d;
  }
  function imageProps(l) {
    const a = assets.get(l.src);
    return sec('Immagine', [
      h('div', { class: 'dz-aibox' },
        h('div', { class: 'dz-aih' }, h('span', { class: 'dz-aiic' }, icon('cutout', 14, '#fff', 2)), h('div', null, h('b', null, 'Rimuovi sfondo'), h('small', null, 'Con l\'AI, sul tuo computer · gratis'))),
        h('div', { class: 'dz-btnrow' },
          h('button', { class: 'btn sm primary', disabled: S.busy ? true : null, onclick: () => removeBg(l, 'oggetto') }, icon('sparkle', 13, '#fff', 2), 'Oggetto o prodotto'),
          h('button', { class: 'btn sm', disabled: S.busy ? true : null, onclick: () => removeBg(l, 'persona') }, icon('user', 13), 'Persona'))),
      h('div', { class: 'dz-btnrow' },
        h('button', { class: 'btn sm', onclick: () => { if (!a) return; const cx = l.x + l.w / 2, cy = l.y + l.h / 2; l.w = a.w; l.h = a.h; l.x = cx - a.w / 2; l.y = cy - a.h / 2; commit(); } }, 'Dimensione originale'),
        h('button', { class: 'btn sm', onclick: () => { const k = Math.max(doc.w / l.w, doc.h / l.h); l.w *= k; l.h *= k; l.rot = 0; l.x = (doc.w - l.w) / 2; l.y = (doc.h - l.h) / 2; commit(); } }, 'Riempi la tela'),
        h('button', { class: 'btn sm', onclick: () => { const k = Math.min(doc.w / l.w, doc.h / l.h); l.w *= k; l.h *= k; l.rot = 0; l.x = (doc.w - l.w) / 2; l.y = (doc.h - l.h) / 2; commit(); } }, 'Adatta')),
      a ? h('p', { class: 'dz-note' }, 'Originale ' + a.w + ' × ' + a.h + ' px') : null,
    ]);
  }
  function adjustProps(l) {
    const p = l.p || (l.p = {});
    const kids = [row(h('span', { class: 'dz-flab' }, 'Tipo'), selectEl(ADJUST_KINDS, l.kind, (v) => { const n = adjustLayer(v); l.kind = v; l.p = n.p; l.name = n.name; commit(); }))];
    if (l.kind === 'bc') kids.push(slider('Luminosità', p.brightness || 0, -100, 100, 1, (v) => { p.brightness = v; }), slider('Contrasto', p.contrast || 0, -100, 100, 1, (v) => { p.contrast = v; }));
    if (l.kind === 'hsl') kids.push(slider('Tonalità', p.hue || 0, -180, 180, 1, (v) => { p.hue = v; }, '°'), slider('Saturazione', p.saturation || 0, -100, 100, 1, (v) => { p.saturation = v; }), slider('Luminosità', p.lightness || 0, -100, 100, 1, (v) => { p.lightness = v; }));
    if (l.kind === 'bw') kids.push(slider('Intensità', p.amount == null ? 100 : p.amount, 0, 100, 1, (v) => { p.amount = v; }, '%'));
    if (l.kind === 'warm') kids.push(slider('Temperatura', p.amount || 0, -100, 100, 1, (v) => { p.amount = v; }));
    if (l.kind === 'blur') kids.push(slider('Sfocatura', p.amount || 0, 0, 60, 0.5, (v) => { p.amount = v; }, ' px'));
    if (l.kind === 'curves') kids.push(curvesEditor(l));
    if (l.kind === 'levels') {
      kids.push(histogram(l, 'rgb'),
        slider('Nero', p.inBlack || 0, 0, 254, 1, (v) => { p.inBlack = Math.min(v, (p.inWhite == null ? 255 : p.inWhite) - 1); }),
        slider('Toni medi', p.gamma || 1, 0.1, 3, 0.01, (v) => { p.gamma = v; }),
        slider('Bianco', p.inWhite == null ? 255 : p.inWhite, 1, 255, 1, (v) => { p.inWhite = Math.max(v, (p.inBlack || 0) + 1); }),
        slider('Nero uscita', p.outBlack || 0, 0, 255, 1, (v) => { p.outBlack = v; }),
        slider('Bianco uscita', p.outWhite == null ? 255 : p.outWhite, 0, 255, 1, (v) => { p.outWhite = v; }),
        h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: () => autoLevels(l) }, icon('wand', 13), 'Automatico')));
    }
    if (l.kind === 'exposure') kids.push(slider('Esposizione', p.exposure || 0, -5, 5, 0.01, (v) => { p.exposure = v; }), slider('Scostamento', p.offset || 0, -50, 50, 0.5, (v) => { p.offset = v; }), slider('Gamma', p.gamma || 1, 0.1, 3, 0.01, (v) => { p.gamma = v; }));
    if (l.kind === 'vibrance') kids.push(slider('Vividezza', p.vibrance || 0, -100, 100, 1, (v) => { p.vibrance = v; }), slider('Saturazione', p.saturation || 0, -100, 100, 1, (v) => { p.saturation = v; }));
    if (l.kind === 'colorbal') kids.push(slider('Ciano ↔ Rosso', p.cr || 0, -100, 100, 1, (v) => { p.cr = v; }), slider('Magenta ↔ Verde', p.mg || 0, -100, 100, 1, (v) => { p.mg = v; }), slider('Giallo ↔ Blu', p.yb || 0, -100, 100, 1, (v) => { p.yb = v; }));
    if (l.kind === 'shadhigh') kids.push(slider('Ombre', p.shadows || 0, -100, 100, 1, (v) => { p.shadows = v; }), slider('Luci', p.highlights || 0, -100, 100, 1, (v) => { p.highlights = v; }));
    if (l.kind === 'photo') kids.push(row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(p.color || '#EC8A00', (c) => { if (typeof c === 'string') { p.color = c; commit('phc'); } })),
      slider('Densità', p.density == null ? 25 : p.density, 0, 100, 1, (v) => { p.density = v; }, '%'),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: p.keepLum !== false ? true : null, onchange: (e) => { p.keepLum = e.target.checked; commit(); } }), 'Mantieni la luminosità'));
    if (l.kind === 'gradmap') {
      const g0 = { type: 'linear', angle: 90, stops: p.stops || [[0, '#000000'], [1, '#FFFFFF']] };
      kids.push(row(h('span', { class: 'dz-flab' }, 'Sfumatura'), colorButton(g0, (v) => { p.stops = typeof v === 'string' ? [[0, '#000000'], [1, v]] : (v && v.stops) || p.stops; commit('gm'); }, { gradient: true, cls: 'wide' })),
        h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: () => { p.stops = (p.stops || []).map(([o, c]) => [1 - o, c]).reverse(); commit(); } }, icon('flipH', 13), 'Inverti')),
        h('p', { class: 'dz-note' }, 'Le zone scure prendono il colore a sinistra, quelle chiare il colore a destra.'));
    }
    if (l.kind === 'lut') {
      kids.push(h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: () => pickLut(l) }, icon('upload', 13), p.lut ? 'Cambia il file .cube' : 'Carica un file .cube')),
        p.lut ? h('p', { class: 'dz-note', 'data-notr': '' }, p.name || 'LUT') : h('p', { class: 'dz-note' }, 'Le LUT sono i "look" da film usati da fotografi e videomaker (file .cube).'),
        p.lut ? slider('Intensità', p.amount == null ? 100 : p.amount, 0, 100, 1, (v) => { p.amount = v; }, '%') : null);
    }
    kids.push(h('p', { class: 'dz-note' }, l.clip ? 'Cambia solo il livello subito sotto (maschera di ritaglio).' : 'Cambia tutti i livelli che stanno sotto. I livelli restano intatti: la togli quando vuoi.'));
    return sec('Regolazione', kids);
  }
  // immagine sotto la regolazione (piccola), per istogramma e livelli automatici
  function belowCanvas(l, size = 256) {
    // nascondi la regolazione e tutto quello che viene disegnato dopo
    const flat = []; (function rec(list) { for (const x of list || []) { if (x.type === 'group') rec(x.children); else flat.push(x); } })(layers());
    const hide = new Set(flat.slice(Math.max(0, flat.indexOf(l))).map((x) => x.id));
    const k = Math.min(1, size / Math.max(doc.w, doc.h));
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(doc.w * k)); c.height = Math.max(1, Math.round(doc.h * k));
    try { renderPage(c.getContext('2d'), doc, page(), { k, ox: 0, oy: 0 }, assets, { store: new Map(), hide }); } catch (e) { /* */ }
    return c;
  }
  function histData(l) {
    const c = belowCanvas(l), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    const H = { rgb: new Uint32Array(256), r: new Uint32Array(256), g: new Uint32Array(256), b: new Uint32Array(256) };
    for (let i = 0; i < d.length; i += 4) { if (d[i + 3] < 8) continue; H.r[d[i]]++; H.g[d[i + 1]]++; H.b[d[i + 2]]++; H.rgb[Math.round(0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2])]++; }
    return H;
  }
  function drawHist(g, W, Hh, arr, color) {
    if (!arr) return;
    let mx = 1; const s = [...arr].sort((a, b) => a - b); mx = Math.max(1, s[Math.floor(s.length * 0.98)] * 1.2);
    g.fillStyle = color; g.beginPath(); g.moveTo(0, Hh);
    for (let i = 0; i < 256; i++) g.lineTo(i / 255 * W, Hh - Math.min(1, arr[i] / mx) * Hh);
    g.lineTo(W, Hh); g.closePath(); g.fill();
  }
  function histogram(l, ch) {
    const c = h('canvas', { class: 'dz-hist', width: 512, height: 140 });
    requestAnimationFrame(() => { const g = c.getContext('2d'); drawHist(g, 512, 140, histData(l)[ch], 'rgba(140,150,170,.55)'); });
    return c;
  }
  function autoLevels(l) {
    const H = histData(l).rgb; let tot = 0; for (const v of H) tot += v;
    if (!tot) return;
    const cut = tot * 0.005; let a = 0, b = 255, acc = 0;
    for (; a < 254; a++) { acc += H[a]; if (acc > cut) break; }
    acc = 0; for (; b > a + 1; b--) { acc += H[b]; if (acc > cut) break; }
    Object.assign(l.p, { inBlack: a, inWhite: b, gamma: 1, outBlack: 0, outWhite: 255 }); commit();
  }
  function curvesEditor(l) {
    const p = l.p; let ch = S.curveCh || 'rgb';
    const W = 512, Hh = 512;
    const cv = h('canvas', { class: 'dz-curve', width: W, height: Hh, 'aria-label': 'Curve' });
    let hist = null;
    const col = { rgb: '#E9ECF2', r: '#FF5A5A', g: '#3DDC84', b: '#4F8CFF' };
    const paint = () => {
      const g = cv.getContext('2d'); g.clearRect(0, 0, W, Hh);
      if (hist) drawHist(g, W, Hh, hist[ch], ch === 'rgb' ? 'rgba(140,150,170,.35)' : col[ch] + '44');
      g.strokeStyle = 'rgba(150,160,180,.25)'; g.lineWidth = 1;
      for (let i = 1; i < 4; i++) { g.beginPath(); g.moveTo(i * W / 4, 0); g.lineTo(i * W / 4, Hh); g.moveTo(0, i * Hh / 4); g.lineTo(W, i * Hh / 4); g.stroke(); }
      g.setLineDash([6, 6]); g.beginPath(); g.moveTo(0, Hh); g.lineTo(W, 0); g.stroke(); g.setLineDash([]);
      // le altre curve, deboli
      for (const k of ['r', 'g', 'b', 'rgb']) {
        if (k === ch) continue; const pts = p[k]; if (!pts || (pts.length === 2 && pts[0][1] === 0 && pts[1][1] === 255)) continue;
        const L = curveLut(pts); g.strokeStyle = col[k] + '55'; g.lineWidth = 2; g.beginPath(); for (let x = 0; x < 256; x++) g.lineTo(x / 255 * W, Hh - L[x] / 255 * Hh); g.stroke();
      }
      const L = curveLut(p[ch]); g.strokeStyle = col[ch]; g.lineWidth = 3; g.beginPath(); for (let x = 0; x < 256; x++) g.lineTo(x / 255 * W, Hh - L[x] / 255 * Hh); g.stroke();
      for (const [x, y] of p[ch]) { g.fillStyle = '#111'; g.strokeStyle = col[ch]; g.lineWidth = 3; g.beginPath(); g.arc(x / 255 * W, Hh - y / 255 * Hh, 9, 0, 7); g.fill(); g.stroke(); }
    };
    requestAnimationFrame(() => { hist = histData(l); paint(); });
    const at = (e) => { const r = cv.getBoundingClientRect(); return [Math.max(0, Math.min(255, (e.clientX - r.left) / r.width * 255)), Math.max(0, Math.min(255, 255 - (e.clientY - r.top) / r.height * 255))]; };
    cv.addEventListener('pointerdown', (e) => {
      e.preventDefault(); const pts = p[ch] = (p[ch] || [[0, 0], [255, 255]]).map((q) => q.slice());
      const [x, y] = at(e), r = cv.getBoundingClientRect(), tol = 14 * 255 / r.width;
      let i = pts.findIndex((q) => Math.hypot(q[0] - x, q[1] - y) < tol * 1.4);
      if (i < 0) { pts.push([Math.round(x), Math.round(curveLut(pts)[Math.round(x)])]); pts.sort((a, b) => a[0] - b[0]); i = pts.findIndex((q) => q[0] === Math.round(x)); }
      if (e.detail >= 2 && i > 0 && i < pts.length - 1) { pts.splice(i, 1); paint(); draw(); commit(); return; }
      try { cv.setPointerCapture(e.pointerId); } catch (er) { /* */ }
      const end = i === 0 || i === pts.length - 1;
      const mv = (ev) => {
        let [nx, ny] = at(ev);
        const lo = i > 0 ? pts[i - 1][0] + 1 : 0, hi = i < pts.length - 1 ? pts[i + 1][0] - 1 : 255;
        const out = !end && (ev.clientY - cv.getBoundingClientRect().bottom > 30 || cv.getBoundingClientRect().top - ev.clientY > 30);
        pts[i] = [Math.round(Math.max(lo, Math.min(hi, nx))), Math.round(ny)]; pts[i].out = out;
        p[ch] = pts.filter((q) => !q.out).map((q) => [q[0], q[1]]); paint(); draw(); commit('curve');
      };
      const up = () => { cv.removeEventListener('pointermove', mv); cv.removeEventListener('pointerup', up); p[ch] = pts.filter((q) => !q.out).map((q) => [q[0], q[1]]); paint(); commit(); };
      cv.addEventListener('pointermove', mv); cv.addEventListener('pointerup', up);
    });
    const chips = h('div', { class: 'dz-seg' }, ...[['rgb', 'RGB'], ['r', 'R'], ['g', 'G'], ['b', 'B']].map(([k, n]) => {
      const b = h('button', { class: k === ch ? 'on' : '', 'data-notr': '', onclick: () => { ch = S.curveCh = k; [...chips.children].forEach((x) => x.classList.toggle('on', x === b)); paint(); } }, n);
      return b;
    }));
    const presets = selectEl([['', 'Preimpostazioni…'], ['s', 'Più contrasto (S)'], ['s2', 'Contrasto forte'], ['soft', 'Meno contrasto'], ['fade', 'Neri sbiaditi'], ['light', 'Più luminoso'], ['dark', 'Più scuro'], ['reset', 'Ripristina']], '', (v) => {
      const P = { s: [[0, 0], [64, 52], [192, 204], [255, 255]], s2: [[0, 0], [64, 40], [192, 216], [255, 255]], soft: [[0, 0], [64, 76], [192, 180], [255, 255]], fade: [[0, 36], [80, 82], [255, 250]], light: [[0, 0], [128, 160], [255, 255]], dark: [[0, 0], [128, 100], [255, 255]], reset: [[0, 0], [255, 255]] }[v];
      if (!P) return; p[ch] = P.map((q) => q.slice()); if (v === 'reset' && ch === 'rgb') { p.r = [[0, 0], [255, 255]]; p.g = [[0, 0], [255, 255]]; p.b = [[0, 0], [255, 255]]; } commit();
    });
    return h('div', { class: 'dz-curvebox' }, row(chips, presets), cv, h('p', { class: 'dz-note' }, 'Clic per aggiungere un punto, trascina per muoverlo. Doppio clic o trascina fuori per toglierlo.'));
  }
  function pickLut(l) {
    const inp = h('input', { type: 'file', accept: '.cube', style: { display: 'none' } });
    inp.addEventListener('change', async () => {
      const f = inp.files[0]; inp.remove(); if (!f) return;
      if (f.size > 30 * 1024 * 1024) { toast('File .cube troppo grande', true); return; }
      const c = compactLut(await f.text());
      if (!c) { toast('Questo file .cube non è valido (serve una LUT 3D)', true); return; }
      l.p.lut = c; l.p.name = f.name.replace(/\.cube$/i, '').slice(0, 60); if (l.p.amount == null) l.p.amount = 100;
      if (!l.name || /^LUT/.test(l.name)) l.name = 'LUT · ' + l.p.name;
      commit();
    });
    document.body.append(inp); inp.click();
  }
  function filterProps(l) {
    const f = l.filters || {};
    const set = (k) => (v) => { l.filters = { ...FILTER_DEFAULT, ...(l.filters || {}), [k]: v }; };
    const any = Object.values(f).some((v) => v);
    return sec('Filtri', [
      slider('Luminosità', f.brightness || 0, -100, 100, 1, set('brightness')),
      slider('Contrasto', f.contrast || 0, -100, 100, 1, set('contrast')),
      slider('Saturazione', f.saturation || 0, -100, 100, 1, set('saturation')),
      slider('Tonalità', f.hue || 0, -180, 180, 1, set('hue'), '°'),
      slider('Sfocatura', f.blur || 0, 0, 50, 0.5, set('blur'), ' px'),
      slider('Bianco e nero', f.grayscale || 0, 0, 100, 1, set('grayscale'), '%'),
      any ? h('button', { class: 'btn sm ghost', onclick: () => { delete l.filters; commit(); } }, 'Togli i filtri') : null,
    ], { open: any ? true : undefined, right: any ? h('i', { class: 'dz-dot' }) : null });
  }
  function fxProps(l) {
    const fx = l.fx || {};
    const get2 = (k) => ({ ...FX_DEFAULT[k], ...(fx[k] || {}) });
    const setFx = (k, patch) => { l.fx = { ...(l.fx || {}), [k]: { ...get2(k), ...patch } }; };
    const block = (k, title, body) => {
      const on = !!(fx[k] && fx[k].on);
      return h('div', { class: 'dz-fx' + (on ? ' on' : '') },
        h('div', { class: 'dz-fxh' }, h('b', null, title), h('div', { class: 'grow' }),
          h('button', { class: 'toggle', 'aria-pressed': on ? 'true' : 'false', 'aria-label': title, onclick: () => { setFx(k, { on: !on }); commit(); } })),
        on ? h('div', { class: 'dz-fxb' }, ...body(get2(k))) : null);
    };
    const flat = l.type === 'text' || l.type === 'shape' || l.type === 'path';
    const blur = (l.filters && l.filters.blur) || 0;
    const anyOn = ['shadow', 'stroke', 'glow', 'colorOverlay', 'gradOverlay', 'innerShadow', 'bevel'].some((k) => fx[k] && fx[k].on) || (flat && blur > 0);
    return sec('Effetti', [
      // forme e testi: dei filtri serve solo la sfocatura (il resto lo fa gia' il colore)
      flat ? slider('Sfocatura', blur, 0, 100, 0.5, (v) => { l.filters = { ...(l.filters || {}), blur: v }; }, ' px') : null,
      block('shadow', 'Ombra', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { setFx('shadow', { color: c }); commit('shc'); })),
        slider('Opacità', Math.round(s.opacity * 100), 0, 100, 1, (v) => setFx('shadow', { opacity: v / 100 }), '%'),
        slider('Sfumatura', s.blur, 0, 200, 1, (v) => setFx('shadow', { blur: v }), ' px'),
        slider('Distanza X', s.x, -200, 200, 1, (v) => setFx('shadow', { x: v }), ' px'),
        slider('Distanza Y', s.y, -200, 200, 1, (v) => setFx('shadow', { y: v }), ' px')]),
      block('stroke', 'Contorno', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { setFx('stroke', { color: c }); commit('stc'); })),
        slider('Spessore', s.width, 1, 100, 1, (v) => setFx('stroke', { width: v }), ' px')]),
      block('glow', 'Bagliore', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { setFx('glow', { color: c }); commit('glc'); })),
        slider('Intensità', Math.round(s.opacity * 100), 0, 100, 1, (v) => setFx('glow', { opacity: v / 100 }), '%'),
        slider('Ampiezza', s.blur, 1, 200, 1, (v) => setFx('glow', { blur: v }), ' px')]),
      block('innerShadow', 'Ombra interna', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { if (typeof c === 'string') { setFx('innerShadow', { color: c }); commit('isc'); } })),
        slider('Opacità', Math.round(s.opacity * 100), 0, 100, 1, (v) => setFx('innerShadow', { opacity: v / 100 }), '%'),
        slider('Sfumatura', s.blur, 0, 150, 1, (v) => setFx('innerShadow', { blur: v }), ' px'),
        slider('Distanza X', s.x, -100, 100, 1, (v) => setFx('innerShadow', { x: v }), ' px'),
        slider('Distanza Y', s.y, -100, 100, 1, (v) => setFx('innerShadow', { y: v }), ' px')]),
      block('bevel', 'Smusso e rilievo', (s) => [slider('Dimensione', s.size, 1, 100, 1, (v) => setFx('bevel', { size: v }), ' px'),
        slider('Direzione della luce', s.angle, 0, 360, 1, (v) => setFx('bevel', { angle: v }), '°'),
        slider('Luce', Math.round(s.highlight * 100), 0, 100, 1, (v) => setFx('bevel', { highlight: v / 100 }), '%'),
        slider('Ombra', Math.round(s.shadow * 100), 0, 100, 1, (v) => setFx('bevel', { shadow: v / 100 }), '%')]),
      block('colorOverlay', 'Sovrapposizione colore', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { if (typeof c === 'string') { setFx('colorOverlay', { color: c }); commit('coc'); } })),
        slider('Opacità', Math.round(s.opacity * 100), 0, 100, 1, (v) => setFx('colorOverlay', { opacity: v / 100 }), '%')]),
      block('gradOverlay', 'Sovrapposizione sfumatura', (s) => [row(h('span', { class: 'dz-flab' }, 'Sfumatura'), colorButton(s.fill, (c) => { setFx('gradOverlay', { fill: typeof c === 'string' ? { type: 'linear', angle: 90, stops: [[0, c], [1, c]] } : c }); commit('goc'); }, { gradient: true })),
        slider('Opacità', Math.round(s.opacity * 100), 0, 100, 1, (v) => setFx('gradOverlay', { opacity: v / 100 }), '%')]),
    ], { open: anyOn ? true : undefined, right: anyOn ? h('i', { class: 'dz-dot' }) : null });
  }
  function maskProps(l) {
    if (!l.mask) return sec('Maschera', [h('p', { class: 'dz-note' }, 'Nasconde parti del livello senza cancellarle: la gomma nasconde, il pennello fa riapparire.'),
      h('button', { class: 'btn sm', onclick: toggleMask }, icon('mask', 13), 'Aggiungi maschera')], { open: false });
    return sec('Maschera', [
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.maskEdit ? true : null, onchange: (e) => { S.maskEdit = e.target.checked; if (S.maskEdit && S.tool !== 'brush' && S.tool !== 'eraser') setTool('eraser'); refresh(); } }), 'Modifica la maschera con pennello e gomma'),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: l.mask.on !== false ? true : null, onchange: (e) => { l.mask.on = e.target.checked; commit(); } }), 'Maschera attiva'),
      h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm ghost', onclick: toggleMask }, 'Togli la maschera')),
    ], { open: true, right: h('i', { class: 'dz-dot' }) });
  }

  // ------------------------------------------------------------ lista dei livelli
  let dragRow = null, layersT = 0;
  function paintLayersSoon() { clearTimeout(layersT); layersT = setTimeout(() => alive && paintLayers(), 200); }
  let pagesT = 0;
  function pagesSoon() { clearTimeout(pagesT); pagesT = setTimeout(() => alive && paintPages(), 300); }
  const thumbStore = new Map(), pageStore = new Map();
  function thumb(l) {
    const c = h('canvas', { class: 'dz-lthumb', width: 36, height: 36 });
    const g = c.getContext('2d');
    if (l.type === 'adjust') { return h('span', { class: 'dz-lthumb ic' }, icon('adjust', 15, 'currentColor', 1.8)); }
    if (l.type === 'group') { return h('span', { class: 'dz-lthumb ic' }, icon('group', 15, 'currentColor', 1.8)); }
    try {
      const bm = layerBitmap(l, Math.min(36 / Math.max(1, l.w), 36 / Math.max(1, l.h)) * 2, assets, thumbStore);
      const w = bm.cv.width - bm.pad * 2, hh = bm.cv.height - bm.pad * 2, k = Math.min(32 / w, 32 / hh);
      g.drawImage(bm.cv, bm.pad, bm.pad, w, hh, 18 - w * k / 2, 18 - hh * k / 2, w * k, hh * k);
    } catch (e) { /* */ }
    return c;
  }
  function paintLayers() {
    const rows = [];
    const rowFor = (l, depth, parent) => {
      const on = S.sel.includes(l.id);
      const eye = h('button', { class: 'dz-leye' + (l.visible ? '' : ' off'), 'aria-label': l.visible ? 'Nascondi' : 'Mostra', onclick: (e) => { e.stopPropagation(); l.visible = !l.visible; commit(); } }, icon(l.visible ? 'eye' : 'eyeOff', 14, 'currentColor', 1.9));
      const nm = h('span', { class: 'dz-lname', 'data-notr': '' }, l.name || ({ text: 'Testo', shape: 'Forma', path: 'Tracciato', image: 'Immagine', paint: 'Pittura', group: 'Gruppo', adjust: 'Regolazione' })[l.type]);
      nm.addEventListener('dblclick', async (e) => { e.stopPropagation(); const v = await promptBox('Rinomina il livello', null, l.name, 'Rinomina'); if (v) { l.name = v; commit(); } });
      const arr = parent ? parent.children : layers(), idx = arr.indexOf(l);
      const clipped = !!(l.clip && idx > 0), isBase = !!(arr[idx + 1] && arr[idx + 1].clip && !l.clip);
      const r = h('div', { class: 'dz-lrow' + (on ? ' on' : '') + (l.visible ? '' : ' hidden') + (parent ? ' child' : '') + (clipped ? ' clipped' : '') + (isBase ? ' cbase' : ''), draggable: 'true', style: { paddingLeft: 6 + depth * 16 + 'px' } },
        l.type === 'group' ? h('button', { class: 'dz-lfold' + (l.open !== false ? ' open' : ''), onclick: (e) => { e.stopPropagation(); l.open = l.open === false; paintLayers(); } }, icon('chev', 11, 'currentColor', 2.4)) : h('span', { class: 'dz-lfold sp' }),
        eye, clipped ? h('span', { class: 'dz-lclip', 'data-tip': 'Maschera di ritaglio: si vede solo dentro il livello sotto' }, icon('clipArrow', 13, 'currentColor', 2)) : null, thumb(l), nm,
        l.mask ? h('span', { class: 'dz-lbadge', 'data-tip': 'Maschera' }, icon('mask', 11, 'currentColor', 2)) : null,
        l.fx && Object.values(l.fx).some((x) => x && x.on) ? h('span', { class: 'dz-lbadge', 'data-tip': 'Effetti' }, 'fx') : null,
        l.blend && l.blend !== 'normal' ? h('span', { class: 'dz-lbadge', 'data-tip': 'Fusione' }, '◐') : null,
        l.locked ? h('span', { class: 'dz-lbadge' }, icon('lock', 11, 'currentColor', 2)) : null);
      r.addEventListener('click', (e) => { if (e.altKey && !e.shiftKey) { select([l.id]); toggleClip(); return; } if (e.shiftKey || e.ctrlKey || e.metaKey) select([l.id], true); else select([l.id]); });
      r.addEventListener('contextmenu', (e) => { e.preventDefault(); if (!S.sel.includes(l.id)) select([l.id]); layerMenu(r); });
      r.addEventListener('dragstart', (e) => { dragRow = l.id; e.dataTransfer.effectAllowed = 'move'; r.classList.add('drag'); });
      r.addEventListener('dragend', () => { dragRow = null; r.classList.remove('drag'); layerList.querySelectorAll('.dz-lrow').forEach((x) => x.classList.remove('dt', 'db', 'di')); });
      r.addEventListener('dragover', (e) => {
        if (!dragRow || dragRow === l.id) return; e.preventDefault();
        const rr = r.getBoundingClientRect(), y = (e.clientY - rr.top) / rr.height;
        r.classList.toggle('dt', y < 0.33 || (l.type !== 'group' && y < 0.5)); r.classList.toggle('db', y > 0.66 || (l.type !== 'group' && y >= 0.5)); r.classList.toggle('di', l.type === 'group' && y >= 0.33 && y <= 0.66);
      });
      r.addEventListener('dragleave', () => r.classList.remove('dt', 'db', 'di'));
      r.addEventListener('drop', (e) => {
        e.preventDefault();
        const where = r.classList.contains('di') ? 'in' : r.classList.contains('dt') ? 'above' : 'below';
        r.classList.remove('dt', 'db', 'di');
        moveLayer(dragRow, l.id, where);
      });
      rows.push(r);
      if (l.type === 'group' && l.open !== false) for (let i = (l.children || []).length - 1; i >= 0; i--) rowFor(l.children[i], depth + 1, l);
    };
    const ls = layers();
    for (let i = ls.length - 1; i >= 0; i--) rowFor(ls[i], 0, null);
    const p = page();
    rows.push(h('div', { class: 'dz-lrow bgrow' + (S.sel.length ? '' : ' on'), onclick: () => select([]) },
      h('span', { class: 'dz-lfold sp' }), h('span', { class: 'dz-leye sp' }),
      h('span', { class: 'dz-lthumb sw', style: { background: p.bg ? (typeof p.bg === 'string' ? p.bg : '#888') : 'repeating-conic-gradient(#ddd 0 25%, #fff 0 50%) 0 0/10px 10px' } }),
      h('span', { class: 'dz-lname' }, 'Sfondo')));
    rc(layerList, ...rows);
  }
  function moveLayer(id, targetId, where) {
    if (id === targetId) return;
    const src = findLayer(layers(), id), tgt = findLayer(layers(), targetId);
    if (!src || !tgt) return;
    // non dentro se stesso
    let bad = false; if (src.layer.type === 'group') walk(src.layer.children || [], (c) => { if (c.id === targetId) bad = true; });
    if (bad) return;
    src.arr.splice(src.i, 1);
    const t2 = findLayer(layers(), targetId);
    if (where === 'in') { t2.layer.children = t2.layer.children || []; t2.layer.children.push(src.layer); t2.layer.open = true; }
    else t2.arr.splice(where === 'above' ? t2.i + 1 : t2.i, 0, src.layer);   // la lista e' al contrario: "sopra" = indice piu' alto
    commit();
  }
  function layerMenu(anchor) {
    const l = one();
    menu(anchor, [
      ['Duplica', () => duplicateSel()],
      ['Porta in primo piano', () => arrange(2)], ['Porta avanti', () => arrange(1)], ['Porta indietro', () => arrange(-1)], ['Porta in fondo', () => arrange(-2)],
      '-',
      ['Raggruppa', groupSel], l && l.type === 'group' ? ['Separa il gruppo', ungroup] : null,
      l && l.type !== 'group' && l.type !== 'adjust' ? [l.mask ? 'Togli la maschera' : 'Aggiungi maschera', toggleMask] : null,
      [selLayers().every((x) => x.clip) ? 'Togli la maschera di ritaglio' : 'Crea maschera di ritaglio', () => toggleClip()],
      l && l.type === 'paint' ? [l.lockAlpha ? 'Sblocca la trasparenza' : 'Blocca la trasparenza', () => { if (l.lockAlpha) delete l.lockAlpha; else l.lockAlpha = true; commit(); }] : null,
      '-',
      l && ['image', 'paint', 'shape', 'path', 'text'].includes(l.type) ? ['Trasformazione libera…', () => transformMenu(anchor)] : null,
      canRaster(l) ? ['Trasforma in immagine', () => rasterize(l)] : null,
      l ? ['Unisci con il livello sotto', mergeDown] : null,
      ['Unisci i livelli visibili', () => mergeVisible(false)],
      ['Nuovo livello dai visibili', () => mergeVisible(true)],
      ['Copia in un\'altra pagina…', () => toPage(anchor, false)],
      doc.pages.length > 1 ? ['Sposta in un\'altra pagina…', () => toPage(anchor, true)] : null,
      l ? [l.locked ? 'Sblocca' : 'Blocca', () => { l.locked = !l.locked; commit(); }] : null,
      l ? [l.visible ? 'Nascondi' : 'Mostra', () => { l.visible = !l.visible; commit(); }] : null,
      '-',
      ['Elimina', deleteSel],
    ]);
  }

  // ------------------------------------------------------------ pagine (caroselli, versioni)
  async function paintPages() {
    const els = doc.pages.map((p, i) => {
      const c = h('canvas', { class: 'dz-pgcv' });
      const b = h('button', { class: 'dz-pg' + (i === S.page ? ' on' : ''), 'aria-label': 'Pagina ' + (i + 1), onclick: () => { if (S.page !== i) { stopEdit(true); S.page = i; S.sel = []; draw(); refresh(); } } }, c, h('span', null, String(i + 1)));
      b.addEventListener('contextmenu', (e) => { e.preventDefault(); menu(b, [['Duplica la pagina', () => dupPage(i)], ['Sposta a sinistra', () => movePage(i, -1), i === 0], ['Sposta a destra', () => movePage(i, 1), i === doc.pages.length - 1], '-', ['Elimina la pagina', () => delPage(i), doc.pages.length < 2]]); });
      pageThumb(p, c);
      return b;
    });
    rc(pagesBar, h('span', { class: 'dz-pgl' }, icon('pages', 14, 'currentColor', 1.8), 'Pagine'), ...els,
      h('button', { class: 'dz-pg add', 'data-tip': 'Nuova pagina', 'aria-label': 'Nuova pagina', onclick: () => { doc.pages.splice(S.page + 1, 0, { id: uid('p'), name: tr('Pagina'), bg: page().bg, layers: [] }); S.page++; S.sel = []; commit(); } }, icon('plus', 16, 'currentColor', 2)),
      h('div', { class: 'grow' }),
      h('span', { class: 'dz-docsize' }, doc.w + ' × ' + doc.h + ' px'));
  }
  let thumbT = 0;
  function pageThumb(p, c) {
    const k = Math.min(64 / doc.w, 44 / doc.h);
    c.width = Math.max(1, Math.round(doc.w * k * 2)); c.height = Math.max(1, Math.round(doc.h * k * 2));
    c.style.width = c.width / 2 + 'px'; c.style.height = c.height / 2 + 'px';
    clearTimeout(thumbT);
    const g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
    try { renderPage(g, doc, p, { k: k * 2, ox: 0, oy: 0 }, assets, { store: pageStore }); } catch (e) { /* */ }
  }
  function dupPage(i) { const p = clone(doc.pages[i]); p.id = uid('p'); p.layers.forEach(reId); doc.pages.splice(i + 1, 0, p); S.page = i + 1; S.sel = []; commit(); }
  function movePage(i, d) { const [p] = doc.pages.splice(i, 1); doc.pages.splice(i + d, 0, p); S.page = i + d; commit(); }
  async function delPage(i) { if (doc.pages.length < 2) return; if (!(await confirmBox('Eliminare la pagina?', 'Puoi tornare indietro con Annulla.', 'Elimina', true))) return; doc.pages.splice(i, 1); S.page = Math.max(0, Math.min(S.page, doc.pages.length - 1)); S.sel = []; commit(); }

  // ------------------------------------------------------------ ridimensiona ed esporta
  function resizeDialog() {
    let w = doc.w, hh = doc.h, lock = true, scale = true;
    const ratio = doc.w / doc.h;
    const wi = h('input', { class: 'input', value: w, inputmode: 'numeric' }), hi = h('input', { class: 'input', value: hh, inputmode: 'numeric' });
    wi.addEventListener('input', () => { w = +wi.value || 1; if (lock) { hh = Math.round(w / ratio); hi.value = hh; } });
    hi.addEventListener('input', () => { hh = +hi.value || 1; if (lock) { w = Math.round(hh * ratio); wi.value = w; } });
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    bg.append(h('div', { class: 'modal', style: { width: 'min(420px, 94vw)' } }, h('h2', null, 'Ridimensiona la tela'),
      h('div', { class: 'row' }, h('label', { class: 'dz-mlab' }, 'Larghezza', wi), h('label', { class: 'dz-mlab' }, 'Altezza', hi)),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: true, onchange: (e) => { lock = e.target.checked; } }), 'Mantieni le proporzioni'),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: true, onchange: (e) => { scale = e.target.checked; } }), 'Ridimensiona anche il contenuto'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'),
        h('button', { class: 'btn primary', onclick: () => { close(); resizeCanvas(w, hh, scale); } }, 'Applica'))));
    document.body.append(bg);
  }
  function exportDialog() {
    stopEdit(true);
    const st = { fmt: 'png', scale: 1, q: 92, cmyk: false, dpi: 150, pages: doc.pages.length > 1 ? 'all' : 'cur', busy: false };
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const body = h('div', { class: 'dz-exp-b' });
    const paint = () => {
      const FM = [['png', 'PNG', 'Qualità piena, trasparenza'], ['jpg', 'JPG', 'Leggero, per i social'], ['webp', 'WebP', 'Leggerissimo, per il web'], ['pdf', 'PDF', 'Da stampare o inviare'], ['psd', 'PSD', 'Con i livelli, per Photoshop']];
      const pxW = Math.round(doc.w * st.scale), pxH = Math.round(doc.h * st.scale);
      rc(body, 
        h('label', { class: 'dz-mlab' }, 'Formato'),
        h('div', { class: 'dz-fmts' }, ...FM.map(([k, n, d]) => h('button', { class: 'dz-fmt' + (st.fmt === k ? ' on' : ''), onclick: () => { st.fmt = k; paint(); } }, h('b', null, n), h('small', null, d)))),
        h('label', { class: 'dz-mlab' }, 'Dimensione'),
        h('div', { class: 'dz-btnrow' }, ...[[0.5, '0,5×'], [1, '1×'], [2, '2×'], [3, '3×']].map(([k, n]) => h('button', { class: 'dz-ochip txt' + (st.scale === k ? ' on' : ''), onclick: () => { st.scale = k; paint(); } }, n)),
          h('span', { class: 'dz-note' }, pxW + ' × ' + pxH + ' px')),
        st.fmt === 'pdf' ? h('div', null, h('label', { class: 'dz-mlab' }, 'Colori'),
          h('div', { class: 'dz-btnrow' }, h('button', { class: 'dz-ochip txt' + (!st.cmyk ? ' on' : ''), onclick: () => { st.cmyk = false; paint(); } }, 'Schermo (RGB)'),
            h('button', { class: 'dz-ochip txt' + (st.cmyk ? ' on' : ''), onclick: () => { st.cmyk = true; paint(); } }, 'Stampa (CMYK)'))) : null,
        st.fmt === 'pdf' ? h('div', null, h('label', { class: 'dz-mlab' }, 'Risoluzione di stampa'),
          h('div', { class: 'dz-btnrow' }, ...[72, 150, 300].map((d) => h('button', { class: 'dz-ochip txt' + (st.dpi === d ? ' on' : ''), onclick: () => { st.dpi = d; paint(); } }, d + ' dpi')),
            h('span', { class: 'dz-note' }, (pxW / st.dpi * 2.54).toFixed(1).replace('.', ',') + ' × ' + (pxH / st.dpi * 2.54).toFixed(1).replace('.', ',') + ' cm'))) : null,
        st.fmt === 'pdf' && st.cmyk ? h('p', { class: 'dz-note' }, 'Conversione CMYK standard, senza perdite. Per lavori importanti chiedi sempre una prova colore alla tipografia.') : null,
        (st.fmt === 'jpg' || st.fmt === 'webp' || (st.fmt === 'pdf' && !st.cmyk)) ? slider('Qualità', st.q, 40, 100, 1, (v) => { st.q = v; }, '%', 'noop') : null,
        doc.pages.length > 1 ? h('div', null, h('label', { class: 'dz-mlab' }, 'Pagine'),
          h('div', { class: 'dz-btnrow' }, h('button', { class: 'dz-ochip txt' + (st.pages === 'all' ? ' on' : ''), onclick: () => { st.pages = 'all'; paint(); } }, 'Tutte (' + doc.pages.length + ')'),
            h('button', { class: 'dz-ochip txt' + (st.pages === 'cur' ? ' on' : ''), onclick: () => { st.pages = 'cur'; paint(); } }, 'Solo la pagina ' + (S.page + 1)))) : null,
        st.fmt === 'png' && doc.pages.some((p) => !p.bg) ? h('p', { class: 'dz-note' }, 'Lo sfondo trasparente resta trasparente.') : null,
        st.fmt !== 'png' && st.fmt !== 'webp' && doc.pages.some((p) => !p.bg) ? h('p', { class: 'dz-note' }, 'Il JPG e il PDF non hanno trasparenza: lo sfondo diventa bianco.') : null);
    };
    const go = h('button', { class: 'btn primary', onclick: async () => {
      if (st.busy) return; st.busy = true; go.disabled = true; go.textContent = 'Preparo…';
      try {
        await save();
        const list = st.pages === 'all' ? doc.pages : [page()];
        const parts = [], head = new DataView(new ArrayBuffer(4)); head.setUint32(0, list.length); parts.push(head.buffer);
        const mime = st.fmt === 'pdf' && st.cmyk ? 'image/png' : { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', pdf: 'image/jpeg', psd: 'psd' }[st.fmt];
        for (const p of list) {
          if (st.fmt === 'psd') {
            const k = st.scale;
            const only = (ls) => { const c = document.createElement('canvas'); c.width = Math.round(doc.w * k); c.height = Math.round(doc.h * k); renderPage(c.getContext('2d'), doc, { bg: null, layers: ls }, { k, ox: 0, oy: 0 }, assets, { store: new Map() }); return c; };
            const comp = await pageCanvas(doc, p, k, assets, { bg: p.bg ? null : null });
            const buf = await writePsdBuffer({ w: Math.round(doc.w * k), h: Math.round(doc.h * k) }, p, only, comp);
            const ln = new DataView(new ArrayBuffer(4)); ln.setUint32(0, buf.byteLength); parts.push(ln.buffer, buf);
            continue;
          }
          const c = await pageCanvas(doc, p, st.scale, assets, { bg: mime === 'image/jpeg' || st.fmt === 'pdf' ? '#FFFFFF' : null });
          const b = await new Promise((r) => c.toBlob(r, mime, st.q / 100));
          const buf = await b.arrayBuffer();
          const ln = new DataView(new ArrayBuffer(4)); ln.setUint32(0, buf.byteLength); parts.push(ln.buffer, buf);
        }
        const fmtQ = st.fmt === 'pdf' && st.cmyk ? 'pdfcmyk' : st.fmt;
        const r = await fetch(`/api/d/${gid}/export?fmt=${fmtQ}&dpi=${st.dpi}&name=${encodeURIComponent(doc.name)}&token=${TOKEN}`, { method: 'PUT', body: new Blob(parts) });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error || 'Esportazione non riuscita');
        close();
        doneToast(j.paths);
      } catch (e) { toast(e.message, true); st.busy = false; go.disabled = false; go.textContent = 'Esporta'; }
    } }, 'Esporta');
    paint();
    bg.append(h('div', { class: 'modal dz-exp', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Esporta' },
      h('h2', null, 'Esporta la grafica'), body,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '6px' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }
  function doneToast(paths) {
    const el = h('div', { class: 'dz-done' }, icon('check', 15, '#34D399', 2.6),
      h('div', null, h('b', null, paths.length > 1 ? paths.length + ' immagini esportate' : 'Esportata'), h('small', { 'data-notr': '' }, paths[0].split(/[\\/]/).pop())),
      h('button', { class: 'btn sm', onclick: () => { post(`/api/d/${gid}/reveal`, { path: paths[0] }).catch(() => {}); el.remove(); } }, icon('folder', 13), 'Mostra nella cartella'),
      h('button', { class: 'dz-ib', 'aria-label': 'Chiudi', onclick: () => el.remove() }, icon('x', 14)));
    document.body.append(el);
    setTimeout(() => el.remove(), 9000);
  }

  // ------------------------------------------------------------ tastiera
  const isTyping = (t) => t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
  const onKey = (e) => {
    if (!alive || document.querySelector('.modal-bg')) return;
    if (isTyping(e.target)) return;
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    if (k === ' ' && !spaceDown) { spaceDown = true; stage.style.cursor = 'grab'; e.preventDefault(); return; }
    if (mod && k === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if (mod && k === 'y') { e.preventDefault(); redo(); return; }
    if (mod && k === 'd') { e.preventDefault(); if (sel.on) { sel.clear(); selChanged(); } return; }
    if (mod && k === 'j') { e.preventDefault(); if (sel.on) layerFromSel(e.shiftKey); else duplicateSel(); return; }
    if (mod && e.shiftKey && k === 'i') { e.preventDefault(); if (sel.on) { sel.invert(); selChanged(); } return; }
    if (mod && k === 'g' && e.altKey) { e.preventDefault(); toggleClip(); return; }
    if (mod && k === 'g') { e.preventDefault(); if (e.shiftKey) ungroup(); else groupSel(); return; }
    if (mod && k === 'a') { e.preventDefault(); if (S.tool === 'select') { sel.all(); selChanged(); } else select(layers().filter((l) => !l.locked).map((l) => l.id)); return; }
    if (mod && k === 'c') { copyLayers(); return; }
    if (mod && k === 'x') { copyLayers(); deleteSel(); return; }
    if (S.xf && (k === 'enter' || k === 'escape')) { e.preventDefault(); endFree(k === 'enter'); return; }
    if (mod && k === 'e' && e.altKey) { e.preventDefault(); if (e.shiftKey) mergeVisible(true); else mergeDown(); return; }
    if (mod && k === 't') { e.preventDefault(); startFree(e.shiftKey ? 'warp' : 'distort'); return; }
    if (mod && k === 'r') { e.preventDefault(); toggleView('rulers'); return; }
    if (mod && (k === "'" || e.code === 'Backslash' || k === 'ù')) { e.preventDefault(); toggleView('grid'); return; }
    if (mod && (k === ';' || k === 'ò')) { e.preventDefault(); toggleView('guides'); return; }
    if (mod && k === 'e') { e.preventDefault(); exportDialog(); return; }
    if (mod && k === 's') { e.preventDefault(); save(); toast('Salvato'); return; }
    if (mod && (k === '0')) { e.preventDefault(); fit(); return; }
    if (mod && (k === '1')) { e.preventDefault(); zoomAt(1); return; }
    if (mod && (k === '=' || k === '+')) { e.preventDefault(); zoomAt(S.zoom * 1.25); return; }
    if (mod && k === '-') { e.preventDefault(); zoomAt(S.zoom / 1.25); return; }
    if (mod && k === ']') { e.preventDefault(); arrange(e.shiftKey ? 2 : 1); return; }
    if (mod && k === '[') { e.preventDefault(); arrange(e.shiftKey ? -2 : -1); return; }
    if (mod) return;
    if ((k === 'delete' || k === 'backspace') && sel.on) { e.preventDefault(); if (e.altKey) fillSel(S.color); else clearInSel(); return; }
    if (k === 'delete' || k === 'backspace') { e.preventDefault(); deleteSel(); return; }
    if (S.pen && (k === 'enter' || k === 'escape')) { e.preventDefault(); finishPen(false); return; }
    if (S.pen && k === 'backspace') { e.preventDefault(); S.pen.pts.pop(); if (!S.pen.pts.length) S.pen = null; draw(); return; }
    if (k === 'escape') { if (S.crop) setTool('move'); else if (sel.on && S.tool === 'select') { sel.clear(); selChanged(); } else select([]); return; }
    if (k === 'enter' && S.crop) { applyCrop(); return; }
    if (k === 'enter' && one() && one().type === 'text') { e.preventDefault(); startEdit(one()); return; }
    if (k.startsWith('arrow') && S.sel.length) {
      e.preventDefault(); const d = e.shiftKey ? 10 : 1;
      for (const l of selLayers()) if (!l.locked) moveBy(l, k === 'arrowleft' ? -d : k === 'arrowright' ? d : 0, k === 'arrowup' ? -d : k === 'arrowdown' ? d : 0);
      commit('nudge'); return;
    }
    if (k === '[' ) { S.brush.size = Math.max(1, Math.round(S.brush.size / 1.2)); paintOpts(); draw(); return; }
    if (k === ']') { S.brush.size = Math.min(400, Math.round(S.brush.size * 1.2)); paintOpts(); draw(); return; }
    if (k === 'm') { if (S.tool === 'select' && (S.selMode === 'rect' || S.selMode === 'ellipse')) S.selMode = S.selMode === 'rect' ? 'ellipse' : 'rect'; else if (S.selMode !== 'rect' && S.selMode !== 'ellipse') S.selMode = 'rect'; setTool('select'); return; }
    if (k === 'l') { S.selMode = 'lasso'; setTool('select'); return; }
    if (k === 'w') { S.selMode = 'wand'; setTool('select'); return; }
    const map = { v: 'move', t: 'text', u: 'shape', p: 'pen', b: 'brush', e: 'eraser', s: 'clone', j: 'heal', i: 'eyedrop', c: 'crop', h: 'hand' };
    if (map[k]) { setTool(map[k]); return; }
    if (k === 'z') { zoomAt(e.altKey ? S.zoom / 1.5 : S.zoom * 1.5); }
  };
  const onKeyUp = (e) => { if (e.key === ' ') { spaceDown = false; stage.style.cursor = S.tool === 'hand' ? 'grab' : ''; } };
  document.addEventListener('keydown', onKey);
  document.addEventListener('keyup', onKeyUp);
  const ro = new ResizeObserver(() => { const first = !S.fitted; if (first) { S.fitted = true; fit(); } else draw(); });
  ro.observe(stage);

  // ------------------------------------------------------------ partenza
  // font dei testi gia' presenti, poi ridisegno
  (function scan(list) { for (const l of list) { if (l.font) ensureFont(l.font).then(() => { dropCache(l.id); draw(); paintLayersSoon(); }); if (l.children) scan(l.children); } })(doc.pages.flatMap((p) => p.layers));
  hist.stack = [snap()]; hist.labels = [null]; hist.idx = 0;
  stage.__dz = { S, get doc() { return doc; }, toScr, commit, startFree, endFree, mergeDown, mergeVisible, rasterize, distribute, toggleView, select };   // per i test automatici
  paintTools(); paintOpts(); refresh(true);
  onTitle && onTitle(doc.name);
  // aperta da "Rimuovi lo sfondo": l'immagine e' gia' scelta, si sceglie solo persona o oggetto
  if (autoCut) {
    const im = layers().find((l) => l.type === 'image');
    if (im) { S.sel = [im.id]; refresh(true); setTimeout(() => { const b = props.querySelector('.dz-aibox'); if (b) { b.classList.add('pulse'); b.scrollIntoView({ block: 'nearest' }); } }, 80); }
  }
  // nome della grafica (dalla barra in alto)
  const api = {
    rename: async (nm) => { doc.name = nm; await post(`/api/d/${gid}/meta`, { name: nm }); onTitle && onTitle(nm); },
    get name() { return doc.name; },
  };
  return {
    api,
    async cleanup() {
      alive = false;
      stopEdit(true);
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('keyup', onKeyUp);
      document.removeEventListener('paste', onPaste);
      window.removeEventListener('pagehide', onHide);
      window.removeEventListener('beforeunload', onHide);
      ro.disconnect();
      document.querySelectorAll('.dz-menu').forEach((x) => x.remove());
      clearTimeout(saveT);
      try { await save(); clearTimeout(coverT); await saveCover(); } catch (e) { /* */ }
      dropCache();
    },
  };
}
