"""Titoli dietro la persona (effetto "green screen" senza green screen).

Per il pezzo di video del titolo: si ritaglia la persona fotogramma per fotogramma (rembg, modello u2net_human_seg,
tutto sul computer), si disegna il titolo grande sul fondo e si rimette la persona sopra. Esce un video di quel
pezzo che nell'editor va su una traccia sopra la live, alla stessa ora: il testo sembra dietro chi parla.
"""
import os
import subprocess

import numpy as np

from .util import ffmpeg_bin

WEB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")
_SESSION = {}
MASK_FPS = 12.0      # maschere calcolate 12 volte al secondo, in mezzo si sfumano (piu' veloce, stesso risultato)


def _session():
    if "s" not in _SESSION:
        import rembg
        _SESSION["s"] = rembg.new_session("u2net_human_seg")
    return _SESSION["s"]


def _mask(bgr):
    """Maschera 0..1 della persona (piccola, poi si ingrandisce)."""
    from PIL import Image
    h, w = bgr.shape[:2]
    k = 320 / max(h, w)
    small = bgr[:, :, ::-1]
    import cv2
    small = cv2.resize(small, (max(8, int(w * k)), max(8, int(h * k))), interpolation=cv2.INTER_AREA)
    m = _session().predict(Image.fromarray(small))[0]
    return np.asarray(m, np.float32) / 255.0


def _font(size, weight=900):
    from PIL import ImageFont
    for name in ("Montserrat.ttf", "Inter.ttf"):
        p = os.path.join(WEB, "fonts", name)
        if os.path.exists(p):
            f = ImageFont.truetype(p, size)
            try:
                f.set_variation_by_axes([weight])
            except Exception:
                pass
            return f
    return ImageFont.load_default()


def text_layer(W, H, text, accent="#FFD34D", center_y=0.3):
    """Titolo grande (RGBA float 0..1): maiuscolo, la parola tra *asterischi* colorata, ombra morbida."""
    from PIL import Image, ImageDraw, ImageFilter
    parts = []
    for i, chunk in enumerate(str(text).split("*")):
        for wd in chunk.split():
            parts.append((wd.upper(), i % 2 == 1))
    if not parts:
        parts = [(str(text).upper(), False)]
    # righe: al massimo 2, piu' larghe possibile (fino all'86% del video)
    size = int(H * 0.2)
    lines = [parts]
    for _ in range(40):
        f = _font(size)
        sp = f.getlength(" ")
        widths = [sum(f.getlength(w) for w, _ in ln) + sp * (len(ln) - 1) for ln in lines]
        if max(widths) <= W * 0.86:
            break
        if len(lines) == 1 and len(parts) > 1:
            # due righe bilanciate
            best, bi = 1e9, 1
            for i in range(1, len(parts)):
                a = sum(f.getlength(w) for w, _ in parts[:i]); b = sum(f.getlength(w) for w, _ in parts[i:])
                if max(a, b) < best:
                    best, bi = max(a, b), i
            lines = [parts[:bi], parts[bi:]]
            continue
        size = int(size * 0.92)
    f = _font(size)
    sp = f.getlength(" ")
    lh = size * 0.98
    total_h = lh * len(lines)
    y0 = int(max(H * 0.04, min(H * 0.96 - total_h, H * center_y - total_h / 2)))
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    ac = tuple(int(accent.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)) + (255,)
    for li, ln in enumerate(lines):
        wline = sum(f.getlength(w) for w, _ in ln) + sp * (len(ln) - 1)
        x = (W - wline) / 2
        y = y0 + li * lh
        for w, hi in ln:
            d.text((x, y), w, font=f, fill=ac if hi else (255, 255, 255, 255))
            x += f.getlength(w) + sp
    # ombra morbida sotto il testo (si legge su qualsiasi sfondo)
    a = img.split()[3]
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sh.putalpha(a.filter(ImageFilter.GaussianBlur(max(2, size * 0.08))).point(lambda v: int(v * 0.55)))
    out = Image.alpha_composite(sh, img)
    arr = np.asarray(out, np.float32) / 255.0
    return arr, (y0, y0 + total_h)


def render(source, a, b, text, out_path, W, H, fps=30.0, accent="#FFD34D", center_y=None, face=None,
           progress=None, cancel=None):
    """Video del pezzo a..b (secondi della live) con il titolo dietro la persona -> out_path (mp4)."""
    import cv2
    fps = max(12.0, min(60.0, float(fps or 30.0)))
    dur = max(0.2, b - a)
    n = int(round(dur * fps))
    cmd = [ffmpeg_bin(), "-v", "error", "-ss", f"{a:.3f}", "-t", f"{dur:.3f}", "-i", source, "-vf",
           f"fps={fps:g},scale={W}:{H}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    rd = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    frames = []
    fsz = W * H * 3
    while len(frames) < n:
        buf = rd.stdout.read(fsz)
        if len(buf) < fsz:
            break
        frames.append(np.frombuffer(buf, np.uint8).reshape(H, W, 3))
    rd.wait()
    if not frames:
        raise RuntimeError("Non riesco a leggere il video in quel punto")
    n = len(frames)
    # maschere ogni tanto, in mezzo sfumate; poi levigate nel tempo (niente tremolio sui bordi)
    step = max(1, int(round(fps / MASK_FPS)))
    keys = list(range(0, n, step)) + ([n - 1] if (n - 1) % step else [])
    km = {}
    for j, i in enumerate(keys):
        if cancel and cancel():
            raise RuntimeError("annullato")
        km[i] = _mask(frames[i])
        if progress:
            progress(0.8 * (j + 1) / len(keys))
    mh, mw = next(iter(km.values())).shape
    # posizione del titolo: il centro poco sopra la testa (la testa copre un po' le lettere, come nei video "dietro")
    if center_y is None:
        if face:
            center_y = max(0.18, face[1] - face[3] * 0.55)
        else:
            m0 = km[keys[0]]
            rows = np.where(m0.max(1) > 0.5)[0]
            center_y = max(0.18, (rows.min() / mh + 0.08) if len(rows) else 0.3)
    txt, _ = text_layer(W, H, text, accent, center_y)
    trgb, ta = txt[..., :3][..., ::-1], txt[..., 3:]
    enc = subprocess.Popen([ffmpeg_bin(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", f"{fps:g}",
                            "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p",
                            "-movflags", "+faststart", out_path], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    prev = None
    try:
        for i in range(n):
            if cancel and cancel():
                raise RuntimeError("annullato")
            k0 = max(x for x in keys if x <= i)
            k1 = min((x for x in keys if x >= i), default=k0)
            m = km[k0] if k1 == k0 else km[k0] + (km[k1] - km[k0]) * ((i - k0) / (k1 - k0))
            m = cv2.resize(m, (W, H), interpolation=cv2.INTER_LINEAR)
            m = cv2.GaussianBlur(m, (0, 0), max(1.0, W / 900))
            if prev is not None:
                m = 0.6 * m + 0.4 * prev      # levigato nel tempo
            prev = m
            m3 = np.clip((m[..., None] - 0.15) / 0.7, 0, 1)
            t = i / fps
            # entrata: il titolo cresce e compare (0,35 s), uscita: sfuma (0,25 s)
            kin = min(1.0, t / 0.35)
            kout = min(1.0, (dur - t) / 0.25)
            al = max(0.0, min(kin, kout))
            fr = frames[i].astype(np.float32) / 255.0
            if al > 0:
                s = 0.86 + 0.14 * (1 - (1 - kin) ** 3)
                if s < 0.999:
                    M = cv2.getRotationMatrix2D((W / 2, H * center_y), 0, s)
                    tr = cv2.warpAffine(trgb, M, (W, H))
                    tA = cv2.warpAffine(ta[..., 0], M, (W, H))[..., None]
                else:
                    tr, tA = trgb, ta
                tA = tA * al
                bg = fr * (1 - tA) + tr * tA
                fr = bg * (1 - m3) + fr * m3
            enc.stdin.write((np.clip(fr, 0, 1) * 255).astype(np.uint8).tobytes())
            if progress:
                progress(0.8 + 0.2 * (i + 1) / n)
        enc.stdin.close()
        enc.wait()
    except Exception:
        try:
            enc.kill()
        except Exception:
            pass
        raise
    if enc.returncode != 0 or not os.path.exists(out_path):
        raise RuntimeError("Titolo dietro la persona non riuscito: " + (enc.stderr.read() or b"").decode(errors="ignore")[-200:])
    return out_path



def matte(source, a, b, out_dir, W, H, fps=30.0, progress=None, cancel=None):
    """La persona ritagliata nel pezzo a..b, per mettere i titoli DIETRO di lei restando modificabili:
    - out_dir/f00000.png ...: fotogrammi RGBA (solo la persona, il resto trasparente) per l'esportazione
    - out_dir/maschera.mp4: la maschera in bianco e nero, leggera, per l'anteprima nell'editor
    -> {"dir", "n", "fps", "mask", "first"}"""
    import cv2
    os.makedirs(out_dir, exist_ok=True)
    fps = max(12.0, min(60.0, float(fps or 30.0)))
    dur = max(0.2, b - a)
    n = int(round(dur * fps))
    cmd = [ffmpeg_bin(), "-v", "error", "-ss", f"{a:.3f}", "-t", f"{dur:.3f}", "-i", source, "-vf",
           f"fps={fps:g},scale={W}:{H}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    rd = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    frames = []
    fsz = W * H * 3
    while len(frames) < n:
        buf = rd.stdout.read(fsz)
        if len(buf) < fsz:
            break
        frames.append(np.frombuffer(buf, np.uint8).reshape(H, W, 3))
    rd.wait()
    if not frames:
        raise RuntimeError("Non riesco a leggere il video in quel punto")
    n = len(frames)
    step = max(1, int(round(fps / MASK_FPS)))
    keys = list(range(0, n, step)) + ([n - 1] if (n - 1) % step else [])
    km = {}
    for j, i in enumerate(keys):
        if cancel and cancel():
            raise RuntimeError("annullato")
        km[i] = _mask(frames[i])
        if progress:
            progress(0.7 * (j + 1) / len(keys))
    mw = 640
    mh = int(round(H * mw / W)) // 2 * 2
    webm = bool(os.environ.get("NOONFRAME_TEST_WEBM"))   # solo per i test automatici (browser senza H.264)
    mpath = os.path.join(out_dir, "maschera.webm" if webm else "maschera.mp4")
    venc = ["-c:v", "libvpx", "-b:v", "1M"] if webm else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-g", "15", "-movflags", "+faststart"]
    menc = subprocess.Popen([ffmpeg_bin(), "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "gray", "-s", f"{mw}x{mh}", "-r", f"{fps:g}",
                             "-i", "-"] + venc + [mpath], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    prev = None
    try:
        for i in range(n):
            if cancel and cancel():
                raise RuntimeError("annullato")
            k0 = max(x for x in keys if x <= i)
            k1 = min((x for x in keys if x >= i), default=k0)
            m = km[k0] if k1 == k0 else km[k0] + (km[k1] - km[k0]) * ((i - k0) / (k1 - k0))
            m = cv2.resize(m, (W, H), interpolation=cv2.INTER_CUBIC)
            # bordi piu' puliti: niente buchi dentro la persona, bordo stretto di un pelo (niente alone dello sfondo)
            kk = max(3, int(W / 320)) | 1
            m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kk * 3, kk * 3)))
            m = cv2.erode(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kk, kk)))
            m = cv2.GaussianBlur(m, (0, 0), max(1.0, W / 1100))
            if prev is not None:
                m = 0.65 * m + 0.35 * prev
            prev = m
            al = np.clip((m - 0.2) / 0.6, 0, 1)
            rgba = np.dstack([frames[i], (al * 255).astype(np.uint8)])
            cv2.imwrite(os.path.join(out_dir, "f%05d.png" % i), rgba)
            menc.stdin.write(cv2.resize((al * 255).astype(np.uint8), (mw, mh), interpolation=cv2.INTER_AREA).tobytes())
            if progress:
                progress(0.7 + 0.3 * (i + 1) / n)
        menc.stdin.close()
        menc.wait()
    except Exception:
        try:
            menc.kill()
        except Exception:
            pass
        raise
    if menc.returncode != 0:
        raise RuntimeError("Maschera della persona non riuscita")
    return {"dir": out_dir, "n": n, "fps": fps, "mask": mpath, "first": os.path.join(out_dir, "f00000.png")}
