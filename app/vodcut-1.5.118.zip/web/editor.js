// NoonFrame - editor: anteprima live, timeline, testo, proprieta'.
import { api, get, post, put, h, icon, ibtn, fmt, fmtDur, toast, confirmBox, promptBox, seg, toggle, pollJob, mediaUrl, thumbUrl, TOKEN, IS_MAC,
  zoomProgress, ZOOM_IN_FX, ZOOM_OUT_FX, vertRegions, vertSettings, vertAnimRegs, vertZoom, vertZoomBoxes, vertRect, coverRect, targetRect, rectAt, zoomTarget, zoomAt, fxAt, customRect, imgStateAt, imgCss, IMG_KEYS, SUB_DEFAULT, FONT_RATIO, ANIMS, MOTIONS, imgFinal, track, droppedPath, BIG_DROP, etaText } from './lib.js';
import { FX_LIST, fxName, loadLooks, FxRenderer, drawMask, backdropFilter, ADJ_KEYS, softFx, softBlur } from './fx.js';
import { fontPicker, ensureFont, fontReady, loadFontList } from './fonts.js';
import { drawKinetic, KINETICS, KINETIC_FPS, kineticName, isProText, setFxExtra } from './kinetic.js';
import { renderFx, testFx, setFxRedraw, fxError, fxKey, fxParams } from './fxcode.js';
import { actionFor, loadKeys, keysDialog } from './keys.js';
import { drawText, drawBadge, TEXT_DEFAULT, TEXT_PRESETS, TITLE_PRESETS, TITLE_CATS, titleStyle, hasHighlight, PLATFORMS, platformOf, BADGE_STYLES, BADGE_DEFAULT, badgeLabel, preloadBadgeLogos, logoUrl } from './text.js';
import { t as tx } from './i18n.js';
import { MOTION_TPLS, MOTION_ACCENTS, drawMotion, cleanMotion, motionName, motionSettle } from './motion.js';

const SOUND_COLORS = ['#4A8BFF', '#2F78FF', '#6EA5FF', '#A9C7FF', '#85B3FF'];
const OV_COLORS = ['#6EA5FF', '#A9C7FF', '#4A8BFF', '#2F78FF', '#85B3FF'];
// colori delle tracce dei progetti vecchi (arcobaleno) -> la nuova famiglia di blu
const OLD_COLORS = { '#E86F9B': '#6EA5FF', '#6FC3E8': '#4A8BFF', '#E8A04F': '#A9C7FF', '#9B7BFF': '#2F78FF', '#2DC2A8': '#4A8BFF',
  // colori delle tracce di prima -> palette NoonFrame (colori piatti)
  '#2DD4BF': '#4A8BFF', '#818CF8': '#2F78FF', '#38BDF8': '#6EA5FF', '#A5B4FC': '#A9C7FF', '#5EEAD4': '#85B3FF', '#60A5FA': '#6EA5FF', '#22D3EE': '#85B3FF' };
const LANE_H = { vert: 34, zoom: 48, video: 84, live: 52, subs: 48, sound: 44, overlay: 44, fx: 34 };
const LANE_MIN = { vert: 22, zoom: 12, video: 34, live: 16, subs: 16, sound: 14, overlay: 14, fx: 12 };
const IMG_RE = /\.(png|jpe?g|webp|gif|bmp)$/i, AUD_RE = /\.(mp3|wav|m4a|aac|ogg|flac|opus)$/i, VID_RE = /\.(mp4|mov|mkv|webm|m4v|avi|flv|ts)$/i;
const mthumbUrl = (path, t) => '/api/mthumb?token=' + TOKEN + '&path=' + encodeURIComponent(path) + '&t=' + (t || 1);
// catturare il puntatore puo' fallire se il pulsante e' gia' stato rilasciato o l'elemento ridisegnato: non e' un errore
function capPtr(el, id) { try { if (el && el.isConnected) el.setPointerCapture(id); } catch (e) { /* puntatore non piu' attivo */ } }
const store = { get(k, d) { try { const v = localStorage.getItem('vodcut.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('vodcut.' + k, JSON.stringify(v)); } catch (e) { /* */ } } };
const uid = (p) => p + Math.random().toString(16).slice(2, 10);

export async function mountEditor(app, proj, ctx) {
  const env = ctx.env || {};
  const pid = proj.id;
  // funzioni tolte dall'interfaccia per ora: restano spente
  Object.assign(proj.settings, { denoise: false, bleep: false, srt: false, chapters: false, burnSubs: false, norm: false });
  if (proj.settings.showSubs === undefined) proj.settings.showSubs = true;
  proj.assets = proj.assets || [];
  proj.layers = normLayers();
  proj.subStyle = { ...SUB_DEFAULT, ...(proj.subStyle || {}) };
  proj.filters = proj.filters || [];
  // tracce in piu' per filtri e zoom, nomi delle tracce principali
  if (!proj.fxTracks || !proj.fxTracks.length) proj.fxTracks = [{ id: 'fx', name: 'Filtri' }];
  if (!proj.zoomTracks || !proj.zoomTracks.length) proj.zoomTracks = [{ id: 'zoom', name: 'Zoom' }];
  proj.laneNames = proj.laneNames || {};
  proj.filters.forEach((f) => { if (!f.track) f.track = 'fx'; });
  proj.zooms.forEach((z) => { if (!z.track) z.track = 'zoom'; });
  loadLooks();
  (proj.inserts || []).forEach((i) => { delete i.words; });   // resti di una versione vecchia
  let D = proj.duration;
  const W = proj.width, H = proj.height;
  const FPS = Math.max(10, Math.min(60, proj.fps || 30));   // per spostarsi di un fotogramma con le frecce
  // clip verticale (creata dal VOD): stessa live, si modifica a parte. Il VOD ne tiene la lista
  const IS_V = !!proj.parent && !proj.timeline;
  const IS_TL = !!proj.timeline;   // un'altra timeline dello stesso progetto (come CapCut)
  const KIND = proj.kind || 'vod';   // vod | video | blank | story
  // l'audio della traccia principale si chiama "live" solo quando c'e' davvero una live
  for (const t of proj.tracks || []) if (t.type === 'live' && t.name === 'Audio live' && KIND !== 'vod') t.name = 'Audio dei video';
  const IS_VOD = KIND === 'vod';
  const BLANK = KIND === 'blank';   // progetto vuoto: il nero di base e' solo spazio libero
  (proj.tracks || []).forEach((t) => { const c = t.color && OLD_COLORS[t.color.toUpperCase()]; if (c) t.color = c; });
  if (!IS_V) proj.verticals = proj.verticals || [];
  // formato del video finale: orizzontale (come la live) o verticale 9:16. Testi e immagini stanno sullo schermo finale
  let VERT = proj.format === '9:16';
  const CW = () => (VERT ? Math.round(H * 9 / 16) : W), CH = () => H;
  const CA = () => CW() / CH();
  const cam = proj.webcam && proj.webcam.box ? proj.webcam.box : null;
  let wave = { perSec: 5, peaks: [] }, waveLive = null;
  const clipPeaks = new Map();
  get(`/api/p/${pid}/wave`).then((w) => { waveLive = w; composeWave(); }).catch(() => {});

  // ---------------------------------------------------------------- stato
  let sel = null;               // {type:'zoom'|'cut'|'lclip'|'sclip'|'track', id}
  let framing = false;          // stai scegliendo l'inquadratura di uno zoom personalizzato
  let tab = 'video';   // pannello a destra: video, audio, testo
  const LEFT_TABS = [...(proj.story ? ['story'] : []), 'project', 'media', ...(IS_V || proj.width < proj.height * 1.3 ? [] : ['clips']), 'ai'];
  let ltab = proj.story ? 'story' : store.get('ltab', 'project');   // pannello a sinistra (come CapCut): progetto, media, clip
  if (!LEFT_TABS.includes(ltab)) ltab = 'project';
  let pps = 1;                  // pixel per secondo nella timeline
  let fitPps = 1;
  let undoStack = [], redoStack = [];
  let saveTimer = null, saving = false, dirty = false;
  let alive = true;
  const liveTrack = () => proj.tracks.find((t) => t.type === 'live');
  const soundTracks = () => proj.tracks.filter((t) => t.type === 'sound');
  const ovTracks = () => proj.tracks.filter((t) => t.type === 'overlay');
  const clipTracks = () => proj.tracks.filter((t) => t.type !== 'live');
  // ordine dei livelli video dall'alto verso il basso; il video e' sempre la base
  function normLayers() {
    const ov = proj.tracks.filter((t) => t.type === 'overlay').map((t) => 'ov:' + t.id);
    const fxk = (proj.fxTracks || [{ id: 'fx' }]).map((t) => (t.id === 'fx' ? 'fx' : 'fx:' + t.id));
    const cur = (proj.layers || ['subs', 'zoom', 'fx']).filter((x) => x === 'subs' || x === 'zoom' || fxk.includes(x) || ov.includes(x));
    ['subs', 'zoom', 'fx'].forEach((k) => { if (!cur.includes(k)) cur.push(k); });
    // le tracce filtri/colori nuove vanno subito sopra quella principale dei filtri
    fxk.forEach((k) => { if (!cur.includes(k)) cur.splice(Math.max(0, cur.indexOf('fx')), 0, k); });
    ov.forEach((k) => { if (!cur.includes(k)) cur.unshift(k); });
    return cur.concat(['video']);
  }
  const allWords = () => (proj.transcript && proj.transcript.segments) || [];

  // ---------------------------------------------------------------- storico e salvataggio
  function snapshot() {
    const dels = [], cens = [], txt = {}, nos = [];
    allWords().forEach((s, si) => s.words.forEach((w, wi) => {
      const k = si + '_' + wi;
      if (w.del) dels.push(k); if (w.cens) cens.push(k); if (w.nosub) nos.push(k); if (w.ed) txt[k] = w.w;
    }));
    return JSON.stringify({ name: proj.name, markers: proj.markers || [], zooms: proj.zooms, segs: proj.segs, tracks: proj.tracks, settings: proj.settings, layers: proj.layers, subStyle: proj.subStyle, filters: proj.filters, fxTracks: proj.fxTracks, zoomTracks: proj.zoomTracks, laneNames: proj.laneNames, dels, cens, txt, nos });
  }
  function restore(snap) {
    const s = JSON.parse(snap);
    proj.name = s.name || proj.name; proj.zooms = s.zooms; proj.segs = s.segs; proj.tracks = s.tracks; proj.settings = s.settings; proj.markers = s.markers || [];
    forgetTextPreviews();
    if (s.fxTracks) proj.fxTracks = s.fxTracks; if (s.zoomTracks) proj.zoomTracks = s.zoomTracks; if (s.laneNames) proj.laneNames = s.laneNames;
    proj.layers = s.layers || proj.layers; proj.layers = normLayers(); if (s.subStyle) proj.subStyle = s.subStyle; proj.filters = s.filters || [];
    const set = new Set(s.dels), cs = new Set(s.cens || []), ns = new Set(s.nos || []), txt = s.txt || {};
    allWords().forEach((sg, si) => sg.words.forEach((w, wi) => {
      const k = si + '_' + wi;
      w.del = set.has(k); w.cens = cs.has(k) || undefined; w.nosub = ns.has(k) || undefined;
      if (k in txt) { w.w = txt[k]; w.ed = true; } else if (w.ed) { w.w = w.orig ?? w.w; w.ed = false; }
    }));
  }
  function begin() { undoStack.push(snapshot()); if (undoStack.length > 200) undoStack.shift(); redoStack = []; updateUndo(); }
  let ver = 0;   // cambia a ogni modifica (cache dei sottotitoli)
  function changed(opts = {}) {
    ver++;
    dirty = true;
    scheduleSave();
    renderTimeline();
    if (!opts.keepPanel) renderPanel();
    if (opts.transcript) renderTranscriptFlags();
    // primi tagli: si prepara la copia con i keyframe fitti per un'anteprima senza scatti
    const cutsNow = proj.segs.some((c) => c.removed && !c.gone);
    if (cutsNow !== hadCuts) { hadCuts = cutsNow; if (typeof applyQuality === 'function') applyQuality(); }
    if (editorReady) { montCheck(); updateCleanBtn(); }
  }
  let hadCuts = null, editorReady = false;
  function updateCleanBtn() {
    const n = !BLANK && proj.segs.some((c) => c.removed && !c.gone && !c.ins);
    cleanBtn.style.display = n ? '' : 'none';
  }
  function removeCutParts() {
    const list = proj.segs.filter((c) => c.removed && !c.gone && !c.ins);
    if (!list.length) return;
    begin();
    list.forEach((c) => { c.gone = true; });
    proj.settings.fluidPreview = true;
    changed({ transcript: true });
    toast('Parti tagliate rimosse dalla timeline. Preparo l\'anteprima fluida: le parole restano nella trascrizione, barrate.');
  }
  // ---- anteprima fluida: un video con solo le parti tenute, rifatto quando cambiano i tagli
  let montState = { key: '', res: null, timer: 0, job: null };
  function montKeep() {
    if (BLANK || (proj.inserts || []).length) return null;
    const out = []; let t = 0;
    for (const [a, b] of hopRanges()) { if (a > t + 1e-3) out.push([t, Math.min(a, D)]); t = Math.max(t, b); }
    if (D - t > 1e-3) out.push([t, D]);
    return out;
  }
  function montFrames(keep, fps) {
    const fr = [];
    for (const [a, b] of keep) {
      const A = Math.ceil(Math.max(0, a) * fps - 1e-6), B = Math.ceil(b * fps - 1e-6);
      if (B - A < 1) continue;
      if (fr.length && A <= fr[fr.length - 1][1]) fr[fr.length - 1][1] = Math.max(fr[fr.length - 1][1], B); else fr.push([A, B]);
    }
    return fr;
  }
  function montCheck() {
    remCache = removed();
    const keep = proj.settings.fluidPreview ? montKeep() : null;
    if (!keep || !keep.length || keep.length === 1 && keep[0][0] < 1e-3 && keep[0][1] > D - 1e-3) {   // niente da togliere: si guarda la live
      clearTimeout(montState.timer); montState.key = ''; video.setMontage(null); return;
    }
    const key = JSON.stringify(keep.map(([a, b]) => [+a.toFixed(3), +b.toFixed(3)]));
    const r = montState.res;
    if (r && JSON.stringify(montFrames(keep, r.fps)) === JSON.stringify(r.frames)) { montApply(r); return; }
    video.setMontage(null);   // i tagli sono cambiati: intanto salti normali, poi arriva la nuova anteprima
    if (key === montState.key) return;
    montState.key = key;
    clearTimeout(montState.timer);
    montState.timer = setTimeout(async () => {
      try {
        const j = await post(`/api/p/${pid}/montage`, { keep });
        const res = await pollJob(j.id, (x) => { if (montState.key === key) { badgeQ.textContent = 'Preparo l\'anteprima fluida · ' + Math.round((x.progress || 0) * 100) + '%'; badgeQ.style.display = ''; } });
        if (!alive || montState.key !== key) return;
        badgeQ.style.display = 'none';
        if (res.status !== 'done') return;
        montState.res = res.result;
        montCheck();
      } catch (e) { badgeQ.style.display = 'none'; }
    }, 1200);
  }
  function montApply(r) {
    let m0 = 0;
    const map = r.frames.map(([A, B]) => { const x = { a: A / r.fps, b: B / r.fps, m0 }; m0 += (B - A) / r.fps; return x; });
    video.setMontage({ url: mediaUrl(r.path), map });
  }
  // posizione "prima" per rimettere un video spostato dov'era (in tempi di adesso)
  function backTarget(id, oldAt) {
    const rec = (proj.inserts || []).find((x) => x.id === id);
    if (!rec) return null;
    return oldAt > rec.at ? oldAt + rec.dur : oldAt;
  }
  async function undo() {
    if (!undoStack.length) return;
    const top = undoStack[undoStack.length - 1];
    if (typeof top !== 'string') {
      undoStack.pop();
      if (top.kind === 'full') {   // spazi vuoti e spostamenti liberi: si torna allo stato di prima
        const now = fullSnap();
        await fullRestore(top.snap);
        redoStack = redoStack.filter((x) => typeof x === 'object' && x.kind === 'full'); redoStack.push({ kind: 'full', snap: now });
      } else if (top.kind === 'liveMove') {   // clip della live spostata: torna al suo posto
        await removeInsert(top.id);
        const c = proj.segs.find((x) => x.id === top.seg.id);
        if (c) Object.assign(c, { gone: !!top.seg.gone, removed: !!top.seg.removed });
        refreshGone(); renderTimeline(); changed({ transcript: true });
        undoStack = []; redoStack = [];
      } else if (top.kind === 'move') {
        const cur = (proj.inserts || []).find((x) => x.id === top.id);
        const now = cur ? cur.at : 0;
        await moveInsert(top.id, backTarget(top.id, top.back), true);
        undoStack = []; redoStack = [{ kind: 'move', id: top.id, back: now }];
      } else {   // annulla un video inserito
        const copy = await removeInsert(top.id);
        undoStack = []; redoStack = copy ? [{ kind: 'insert', rec: copy }] : [];
      }
      updateUndo(); return;
    }
    if (redoStack.length && typeof redoStack[redoStack.length - 1] !== 'string') redoStack = [];
    redoStack.push(snapshot()); restore(undoStack.pop()); fixSel(); changed({ transcript: true }); updateUndo(); applyQuality();
  }
  async function redo() {
    if (!redoStack.length) return;
    const top = redoStack[redoStack.length - 1];
    if (typeof top !== 'string') {
      redoStack.pop();
      if (top.kind === 'full') {
        const now = fullSnap();
        await fullRestore(top.snap);
        undoStack.push({ kind: 'full', snap: now });
      } else if (top.kind === 'move') {
        const cur = (proj.inserts || []).find((x) => x.id === top.id);
        const now = cur ? cur.at : 0;
        await moveInsert(top.id, backTarget(top.id, top.back), true);
        undoStack = [{ kind: 'move', id: top.id, back: now }]; redoStack = [];
      } else {
        const { own, ...rec } = top.rec;
        await applyInsert({ ...rec }, true, own);
      }
      updateUndo(); return;
    }
    undoStack.push(snapshot()); restore(redoStack.pop()); fixSel(); changed({ transcript: true }); updateUndo(); applyQuality();
  }
  function fixSel() { if (sel && !findSel()) sel = null; }
  function scheduleSave() {
    savedLabel.dataset.tip = 'Salvataggio in corso…'; savedLabel.style.opacity = '0.4';
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 600);
  }
  async function save() {
    if (saving) { scheduleSave(); return; }
    if (!dirty) return;
    saving = true; dirty = false;
    try {
      // non sovrascrivere una trascrizione arrivata nel frattempo
      await put('/api/p/' + pid, proj);
      savedLabel.dataset.tip = 'Salvato in automatico'; savedLabel.style.opacity = '1'; savedLabel.style.color = '';
    } catch (e) { dirty = true; savedLabel.dataset.tip = 'Salvataggio non riuscito'; savedLabel.style.color = '#FF7B72'; toast(e.message, true); }
    saving = false;
  }
  async function flush() { clearTimeout(saveTimer); if (dirty) await save(); }

  // ---------------------------------------------------------------- tempo tolto (tagli + parole)
  function removed() {
    const r = proj.segs.filter((c) => c.removed).map((c) => [c.a, c.b]);
    allWords().forEach((s) => s.words.forEach((w) => { if (w.del) r.push([w.a, w.b]); }));
    r.sort((a, b) => a[0] - b[0]);
    const m = [];
    for (const [a, b] of r) { if (m.length && a <= m[m.length - 1][1] + 0.05) m[m.length - 1][1] = Math.max(m[m.length - 1][1], b); else m.push([a, b]); }
    return m;
  }
  function wordCuts() {
    const r = [];
    allWords().forEach((s, si) => s.words.forEach((w, wi) => { if (w.del) r.push([w.a, w.b, si, wi]); }));
    const m = [];
    for (const x of r) { const l = m[m.length - 1]; if (l && x[0] <= l[1] + 0.12) l[1] = Math.max(l[1], x[1]); else m.push([x[0], x[1], x[2], x[3]]); }
    return m;
  }
  // durata del video finale: i pezzi tolti non contano, quelli accelerati/rallentati cambiano durata
  // progetto vuoto: il video finisce dove finisce l'ultima cosa messa (il nero dopo non si esporta)
  function contentEnd() {
    let e = 0;
    for (const c of proj.segs) if (c.ins && !c.gone && !c.removed) e = Math.max(e, c.b);
    for (const t of proj.tracks || []) if (!t.hidden && t.type !== 'live') for (const c of t.clips || []) e = Math.max(e, c.a + (c.dur != null ? c.dur : (c.b || c.a) - c.a));   // la traccia 'live' del progetto vuoto e' solo il nero di base
    return e;
  }
  function outDuration() {
    const rem = removed();
    const cap = BLANK ? contentEnd() : D;
    let tot = 0;
    for (const c of proj.segs) {
      if (c.a >= cap) continue;
      let d = Math.min(c.b, cap) - c.a;
      for (const [a, b] of rem) d -= Math.max(0, Math.min(c.b, b) - Math.max(c.a, a));
      tot += Math.max(0, d) / (c.speed || 1);
    }
    return tot;
  }
  // quanto video finale c'e' prima dell'istante t
  function outAt(t) {
    const rem = remCache;
    let tot = 0;
    for (const c of proj.segs) {
      if (c.a >= t) break;
      const e = Math.min(c.b, t);
      let d = e - c.a;
      for (const [a, b] of rem) d -= Math.max(0, Math.min(e, b) - Math.max(c.a, a));
      tot += Math.max(0, d) / (c.speed || 1);
    }
    return tot;
  }
  const speedAt = (t) => { const c = proj.segs.find((x) => t >= x.a && t < x.b); return (c && c.speed) || 1; };
  // ---------------------------------------------------------------- lettore
  // La traccia principale puo' essere fatta di piu' file: la live e i video inseriti (all'inizio, alla fine,
  // in mezzo). Non vengono uniti: questo "lettore" passa da un file all'altro e fuori sembra un video solo,
  // con il tempo della timeline. Senza video inseriti e' esattamente il <video> della live.
  function makePlayer(liveA) {
    // due lettori anche per i video inseriti: mentre uno suona, il prossimo e' gia' caricato e fermo al punto giusto
    // (niente fotogramma nero ne' scatto al cambio di clip)
    const insA = h('video', { class: 'insvid', preload: 'auto', playsinline: true, style: { display: 'none' } });
    const insB = h('video', { class: 'insvid', preload: 'auto', playsinline: true, style: { display: 'none' } });
    let ins = insA, insSp = insB, spUrl = '';
    // due elementi per la live che si danno il cambio sui tagli: mentre uno riproduce, l'altro e' gia' fermo dopo il
    // prossimo taglio, cosi' il salto e' istantaneo (niente scatti mentre il browser cerca il fotogramma)
    const twin = h('video', { class: 'livetwin', preload: 'auto', playsinline: true, style: { visibility: 'hidden' } });
    let live = liveA, spare = twin, want = null, noTwin = false;
    // anteprima fluida: un video con solo le parti tenute (preparato dal server). Quando c'e' e combacia con i tagli
    // di adesso si guarda lui: nessun salto durante la riproduzione. map: [{a, b, m0}] tempo timeline -> tempo del video
    const montEl = h('video', { class: 'livetwin', preload: 'auto', playsinline: true, style: { visibility: 'hidden' } });
    let mont = null;
    const mOf = (t) => {
      const m = mont.map;
      for (const r of m) { if (t < r.a) return r.m0; if (t < r.b) return r.m0 + (t - r.a); }
      const l = m[m.length - 1]; return l.m0 + (l.b - l.a);
    };
    const tOf = (x) => {
      const m = mont.map;
      for (const r of m) if (x < r.m0 + (r.b - r.a) - 1e-4) return r.a + Math.max(0, x - r.m0);
      const l = m[m.length - 1]; return l.b;
    };
    const fluid = () => !!(mont && mont.ready && !multi());
    montEl.addEventListener('error', () => { if (mont && !mont.ready) mont = null; });   // file non leggibile: si resta sulla live
    let pcs = [], cur = null, act = live, insUrl = '', rate = 1, vol = 1, muted = false, lastBuilt = '';
    const BOTH = new Set(['play', 'pause', 'playing', 'seeked', 'timeupdate', 'ended']);
    function build() {
      const list = (proj.inserts || []).slice().sort((x, y) => x.at - y.at);
      const key = JSON.stringify(list.map((i) => [i.id, i.at, i.dur, i.offset || 0, i.file, i.preview || ''])) + '|' + D;
      if (key === lastBuilt) return;
      lastBuilt = key;
      // dove eravamo (in tempo della timeline), per restarci dopo che i pezzi cambiano
      const prevT = cur ? Math.max(cur.t0, Math.min(cur.t1, cur.t0 + (act.currentTime - cur.off))) : 0;
      const liveD = proj.liveDuration || (D - list.reduce((s, i) => s + i.dur, 0));
      const out = [];
      let T = 0, L = 0;
      for (const i of list) {
        if (i.at > T + 1e-6) { out.push({ t0: T, t1: i.at, off: L, live: true }); L += i.at - T; T = i.at; }
        out.push({ t0: T, t1: T + i.dur, off: i.offset || 0, live: false, ins: i });
        T += i.dur;
      }
      if (liveD - L > 1e-3 || !out.length) out.push({ t0: T, t1: T + (liveD - L), off: L, live: true });
      pcs = out;
      if (!cur || !pcs.includes(cur)) { cur = pieceAt(prevT); if (pcs.length > 1) use(cur, prevT, false); }
      // tolti tutti i video inseriti: si torna alla base (nel progetto vuoto il nero), non resta l'ultimo fotogramma
      if (pcs.length <= 1 && act !== live) {
        for (const v of [insA, insB]) { v.pause(); v.style.display = 'none'; v.removeAttribute('src'); try { v.load(); } catch (e) { /* */ } }
        act = live; insUrl = ''; spUrl = '';
        live.currentTime = Math.max(0, Math.min(prevT, liveD));
      }
    }
    const multi = () => { build(); if (pcs.length > 1 && live !== liveA) home(); return pcs.length > 1; };
    const pieceAt = (t) => { for (const p of pcs) if (t < p.t1 - 1e-6) return p; return pcs[pcs.length - 1]; };
    function use(p, t, playing) {
      // una clip della live spostata altrove e' sempre la live: la legge lo stesso lettore (anche la copia leggera)
      const onLive = p.live || !!(p.ins && p.ins.live);
      if (!onLive) {
        const url = mediaUrl(p.ins.preview || p.ins.file);
        if (url !== insUrl) {
          if (url === spUrl && insSp.readyState >= 2) {
            // il prossimo video e' gia' pronto nel secondo lettore: si scambiano
            const o = ins; ins = insSp; insSp = o;
            const u = insUrl; insUrl = spUrl; spUrl = u;
          } else { insUrl = url; ins.src = url; }
        }
      }
      const el = onLive ? live : ins;
      cur = p;
      if (el !== act) {
        const old = act;
        act = el;
        old.pause();
      }
      for (const v of [insA, insB]) {
        const show = !onLive && v === ins;
        if (show) { v.style.transform = live.style.transform; v.style.clipPath = live.style.clipPath; }
        if (v.style.display !== (show ? '' : 'none')) v.style.display = show ? '' : 'none';
      }
      const lt = Math.max(0, p.off + (t - p.t0));
      if (Math.abs(el.currentTime - lt) > 0.002) el.currentTime = lt;
      el.playbackRate = rate; el.volume = vol; el.muted = muted;
      if (playing && el.paused) el.play().catch(() => {});
    }
    // riporta la live sul suo elemento principale (prima di cambiare file o aggiungere video inseriti)
    function home() {
      if (live === liveA) return;
      const t = live.currentTime, playing = !live.paused;
      live.pause();
      liveA.currentTime = t; liveA.style.visibility = ''; twin.style.visibility = 'hidden';
      if (act === live) act = liveA;
      live = liveA; spare = twin; want = null;
      if (playing) liveA.play().catch(() => {});
    }
    const api = {
      get insEl() { return ins; },
      insEls: [insA, insB],
      twinEl: twin,
      hops: [0, 0],   // salti fluidi / salti col seek (per i test)
      isLive(el) { return el === liveA || el === twin || el === montEl; },
      // prepara il salto: l'elemento di scorta va gia' dopo il taglio
      prep(b) {
        if (multi() || noTwin) return;
        const src = live.getAttribute('src');
        if (!src) return;
        if (spare.getAttribute('src') !== src) { spare.src = src; want = null; }
        if (want !== b || (spare.readyState >= 1 && !spare.seeking && Math.abs(spare.currentTime - b) > 0.05)) {
          want = b;
          if (spare.readyState >= 1) spare.currentTime = b;
        }
      },
      // salto oltre un taglio durante la riproduzione
      hop(b) {
        if (fluid()) return;
        if (multi()) { api.currentTime = b; return; }
        const ok = !noTwin && want === b && spare.readyState >= 3 && !spare.seeking && Math.abs(spare.currentTime - b) < 0.08;
        api.hops[ok ? 0 : 1]++;
        if (!ok) { live.currentTime = b; return; }
        spare.playbackRate = live.playbackRate; spare.volume = live.volume; spare.muted = live.muted;
        spare.style.transform = live.style.transform; spare.style.clipPath = live.style.clipPath;
        const old = live, nw = spare;
        nw.play().catch(() => {
          // il browser non lascia partire il secondo lettore: si torna al primo con un salto normale (e non si riprova)
          if (live !== nw) return;
          noTwin = true;
          nw.pause(); nw.style.visibility = 'hidden'; old.style.visibility = '';
          live = old; spare = nw; act = old;
          old.currentTime = b; old.play().catch(() => {});
        });
        nw.style.visibility = ''; old.style.visibility = 'hidden';
        old.pause();
        live = nw; spare = old; act = live; want = null;
      },
      pieceAt(t) { build(); return pieceAt(Math.max(0, t)); },
      montEl,
      get fluid() { return fluid(); },
      // attiva l'anteprima fluida (m = {url, map}); null = si torna alla live con i salti
      setMontage(m) {
        const was = fluid(), t = api.currentTime, playing = !api.paused;
        if (!m) {
          if (!mont) return;
          mont = null;
          if (was) {
            montEl.pause(); montEl.style.visibility = 'hidden';
            act = live; live.style.visibility = ''; live.currentTime = t;
            if (playing) live.play().catch(() => {});
          }
          montEl.removeAttribute('src'); try { montEl.load(); } catch (e) { /* */ }
          return;
        }
        if (mont && mont.url === m.url) { mont.map = m.map; return; }
        mont = { url: m.url, map: m.map, ready: false };
        montEl.src = m.url;
        montEl.addEventListener('canplay', () => {
          if (!mont || mont.url !== m.url || mont.ready) return;
          if (multi()) return;
          const t2 = api.currentTime, pl = !api.paused;
          mont.ready = true;
          montEl.currentTime = mOf(t2);
          montEl.playbackRate = rate; montEl.volume = live.volume; montEl.muted = live.muted;
          montEl.style.transform = live.style.transform; montEl.style.clipPath = live.style.clipPath;
          montEl.style.visibility = ''; live.pause(); spare.pause(); live.style.visibility = 'hidden'; spare.style.visibility = 'hidden';
          act = montEl;
          if (pl) montEl.play().catch(() => {});
        }, { once: true });
      },
      get el() { return act; },
      get currentTime() {
        if (fluid()) return tOf(montEl.currentTime);
        if (!multi()) return live.currentTime;
        const t = cur.t0 + (act.currentTime - cur.off);
        return Math.max(cur.t0, Math.min(cur.t1, t));
      },
      set currentTime(t) {
        if (fluid()) { montEl.currentTime = mOf(Math.max(0, t)); return; }
        if (!multi()) { live.currentTime = t; return; }
        use(pieceAt(Math.max(0, t)), Math.max(0, t), !act.paused);
      },
      get paused() { return act.paused; },
      play() { if (multi() && cur) use(cur, api.currentTime, false); return act.play(); },
      pause() { live.pause(); spare.pause(); insA.pause(); insB.pause(); montEl.pause(); },
      get playbackRate() { return act.playbackRate; },
      set playbackRate(r) { rate = r; live.playbackRate = r; spare.playbackRate = r; montEl.playbackRate = r; for (const v of [insA, insB]) if (v.src) v.playbackRate = r; },
      get volume() { return act.volume; },
      set volume(v) { if (!Number.isFinite(v)) return; vol = Math.max(0, Math.min(1, v)); act.volume = vol; },
      get muted() { return act.muted; },
      set muted(m) { muted = m; act.muted = m; },
      get src() { return liveA.src; },
      set src(u) { home(); liveA.src = u; twin.removeAttribute('src'); want = null; },
      get error() { return liveA.error; },
      get readyState() { return live.readyState; },
      load() { home(); liveA.load(); },
      removeAttribute(k) { home(); liveA.removeAttribute(k); twin.removeAttribute(k); for (const v of [insA, insB]) { v.removeAttribute(k); v.load(); } insUrl = ''; spUrl = ''; },
      addEventListener(ev, fn, opt) {
        if (!BOTH.has(ev)) return liveA.addEventListener(ev, fn, opt);
        // gli eventi del file che non si sta guardando non contano (cambio di file durante la riproduzione)
        const w = (e) => { if (e.target === act) fn(e); };
        liveA.addEventListener(ev, w, opt); twin.addEventListener(ev, w, opt); insA.addEventListener(ev, w, opt); insB.addEventListener(ev, w, opt); montEl.addEventListener(ev, w, opt);
      },
      // durante la riproduzione: alla fine di un pezzo si passa al file successivo
      tick() {
        if (!multi() || !cur) return;
        const end = cur.off + (cur.t1 - cur.t0);
        if (act.paused && !act.ended) return;
        // a poco dalla fine del pezzo si prepara il prossimo: caricato e fermo al suo inizio
        const nx = pcs[pcs.indexOf(cur) + 1];
        if (nx && end - act.currentTime < 2.5) {
          if (nx.live || (nx.ins && nx.ins.live)) {
            if (act !== live && live.paused && Math.abs(live.currentTime - nx.off) > 0.05 && !live.seeking) live.currentTime = nx.off;
          } else {
            const u = mediaUrl(nx.ins.preview || nx.ins.file);
            if (u !== insUrl) {
              if (u !== spUrl) { spUrl = u; insSp.src = u; insSp.preload = 'auto'; }
              if (insSp.readyState >= 1 && !insSp.seeking && Math.abs(insSp.currentTime - nx.off) > 0.05) insSp.currentTime = nx.off;
            }
          }
        }
        if (act.currentTime >= end - 0.03 || act.ended) {
          const i = pcs.indexOf(cur);
          if (i >= 0 && i < pcs.length - 1) use(pcs[i + 1], pcs[i + 1].t0, true);
          else if (!act.paused) act.pause();
        }
      },
    };
    insA.addEventListener('ended', () => api.tick());
    insB.addEventListener('ended', () => api.tick());
    liveA.addEventListener('ended', () => api.tick());
    twin.addEventListener('ended', () => api.tick());
    return api;
  }
  // velocita' in anteprima: il video (e i suoni) vanno alla velocita' del pezzo dove sta la testina
  function applySpeed() {
    const r = Math.max(0.0625, Math.min(16, speedAt(video.currentTime) * (typeof viewRate === 'number' ? viewRate : 1)));   // il browser accetta fino a 16x
    if (Math.abs(video.playbackRate - r) > 1e-3) video.playbackRate = r;
    for (const a of sounds.values()) if (Math.abs(a.playbackRate - r) > 1e-3) a.playbackRate = r;
  }

  // ---------------------------------------------------------------- DOM: anteprima
  // formati che l'anteprima non sa leggere (H.265, AV1…): si usa una copia leggera convertita una volta sola
  const PREVIEW_OK = ['h264', 'vp8', 'vp9'];
  let compat = !!(proj.vcodec && !PREVIEW_OK.includes(proj.vcodec));
  const COMPAT_H = Math.min(720, H);
  const liveVid = h('video', { src: compat ? null : mediaUrl(proj.source), preload: 'auto', playsinline: true });
  const video = makePlayer(liveVid);
  window.__nfPlayer = video;   // per i test automatici
  const veil = h('div', { class: 'cutveil', style: { display: 'none' } }, KIND === 'blank' ? 'Trascina un video nella timeline o aggiungi un testo per iniziare' : 'Questa parte verrà tagliata');
  const loadingTxt = h('span', null, compat ? 'Preparo l\'anteprima…' : 'Carico il video…');
  const loading = h('div', { class: 'cutveil', style: { gap: '10px', flexDirection: 'column', textAlign: 'center' } }, h('div', { class: 'spinner' }), loadingTxt);
  let videoReady = false, strip = null;
  function onReady() {
    if (videoReady) return;
    videoReady = true; loading.remove(); playBtn.disabled = false;
    setTimeout(loadStrip, 300);
  }
  async function loadStrip() {
    if (!alive) return;
    try {
      const s = await get(`/api/p/${pid}/strip`);
      if (s.ready) { strip = s; drawThumbs(); return; }
    } catch (e) { /* riprova */ }
    setTimeout(loadStrip, 1500);
  }
  // anteprima alla qualita' scelta: copia leggera del VOD preparata in background (piu' fluida sui PC lenti)
  let curSrc = compat ? '' : 'orig', proxyTimer = 0, proxyWant = 0, proxyRebuild = false, proxyRebuilt = false;
  async function applyQuality() {
    // qualita' dell'anteprima (separata da quella del video finale): Auto = 720p se il VOD e' piu' grande
    const pq = proj.settings.previewQ || 'auto';
    let q = pq === 'orig' ? H : pq === 'auto' ? (H > 760 ? 720 : H) : Math.min(H, parseInt(pq, 10) || H);
    if (compat) q = Math.min(q, COMPAT_H);
    if (BLANK && !compat) q = H;   // progetto vuoto: il fondo e' nero, leggero: niente copia per l'anteprima
    clearTimeout(proxyTimer);
    // con parti tagliate serve la copia con i keyframe fitti anche a piena qualita': i salti durante la riproduzione sono istantanei
    const cutsIn = !BLANK && proj.segs.some((c) => c.removed && !c.gone);
    if (pq === 'auto' && cutsIn && !compat && q >= H - 8) q = H - (H % 2);
    if (!compat && q >= H - 8 && !(pq === 'auto' && cutsIn)) { proxyWant = 0; badgeQ.style.display = 'none'; if (curSrc !== 'orig') swapSrc(mediaUrl(proj.source), 'orig'); return; }
    proxyWant = q;
    try {
      const r = await get(`/api/p/${pid}/proxy?h=${q}` + (proxyRebuild ? '&rebuild=1' : ''));
      proxyRebuild = false;
      if (!alive || proxyWant !== q) return;
      if (r.ready) { badgeQ.textContent = 'Anteprima ' + q + 'p'; badgeQ.style.display = ''; if (curSrc !== r.path) swapSrc(mediaUrl(r.path), r.path); return; }
      if (r.error) { badgeQ.style.display = 'none'; toast('Anteprima ' + q + 'p non riuscita: ' + r.error, true); return; }
      if (r.changed) {
        // stesso nome, video diverso: l'anteprima vecchia mostrava un video e l'esportazione ne avrebbe usato un altro
        if (r.changed.different) toast(`Attenzione: il file "${r.changed.name}" sul PC è diverso da quello con cui hai creato il progetto (dura ${fmtDur(r.changed.dur)} invece di ${fmtDur(r.changed.projDur)}). Forse l'hai sostituito con un altro video con lo stesso nome: l'esportazione usa il file attuale.`, true);
        else toast('Il video di questo progetto è stato modificato sul PC: rifaccio l\'anteprima.');
      }
      const pc = Math.round(((r.job && r.job.progress) || 0) * 100);
      const et = etaText(r.job && r.job.eta);
      badgeQ.textContent = `Preparo l'anteprima ${q}p · ${pc}%` + (et ? ' · ' + et : ''); badgeQ.style.display = '';
      if (compat && !videoReady) loadingTxt.replaceChildren(`Preparo l'anteprima · ${pc}%` + (et ? ' · ' + et : ''), h('br'), h('small', { style: { opacity: '.7' } }, 'Questo formato video va convertito una volta sola per vederlo qui. Intanto puoi già lavorare sulla timeline.'));
      proxyTimer = setTimeout(applyQuality, 1500);
    } catch (e) { badgeQ.style.display = 'none'; }
  }
  function swapSrc(url, key) {
    const t = video.currentTime, playing = !video.paused;
    curSrc = key;
    video.src = url;
    video.addEventListener('loadedmetadata', () => { video.currentTime = t; if (playing) video.play().catch(() => {}); frame(true); }, { once: true });
  }
  const subSpan = h('span');
  const subBox = h('div', { class: 'sub', style: { display: 'none' } }, subSpan);
  const badgeMain = h('div', { class: 'badge' }, 'Originale');
  const badgeMute = h('div', { class: 'badge red', style: { display: 'none' } }, 'Audio muto');
  const frameBox = h('div', { class: 'framebox', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }),
    h('button', { class: 'btn sm primary framedone', onclick: (ev) => { ev.stopPropagation(); framing = false; renderPanel(); frame(true); } }, 'Fatto'));
  // in verticale il riquadro e' stretto: il "Fatto" sta in basso al centro dell'anteprima
  const frameDoneBar = h('button', { class: 'btn primary framedonebar', style: { display: 'none' }, onclick: (ev) => { ev.stopPropagation(); framing = false; renderPanel(); frame(true); } }, icon('check', 14, '#fff', 2.4), 'Fatto');
  const badgeQ = h('div', { class: 'badge', style: { display: 'none' } });
  // livelli: quello che sta in "zg" viene ingrandito dallo zoom, il resto resta fermo sopra
  // filtri: disegnati sopra il video, dentro lo zoom (la maschera segue l'inquadratura)
  const fxCanvas = h('canvas', { class: 'fxcanvas', style: { display: 'none' } });
  const fxr = new FxRenderer(fxCanvas, W, H);
  const maskView = h('canvas', { class: 'maskview', style: { display: 'none' } });
  const maskBox = h('div', { class: 'maskbox', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }));
  const paintLayer = h('div', { class: 'paintlayer', style: { display: 'none' } });
  const brushCur = h('div', { class: 'brushcur', style: { display: 'none' } });
  const mainKeyCv = h('canvas', { class: 'fxcanvas keycv', style: { display: 'none' } });
  const zg = h('div', { class: 'zg' }, liveVid, video.twinEl, video.montEl, ...video.insEls, mainKeyCv, fxCanvas, maskView, maskBox, paintLayer, brushCur);
  const subLayer = h('div', { class: 'layer' }, subBox);
  // sottotitoli nell'anteprima: stessi valori del video esportato
  let subCur = null, subWordEls = [], subHi = -1;
  function applySubStyle() {
    const st = proj.subStyle, sh = screen.clientHeight || 1;
    const fs = st.size * sh, css = fs / (FONT_RATIO[st.font] || 1.15), pad = 0.18 * fs;
    Object.assign(subSpan.style, {
      fontFamily: `"${st.font}", Arial, sans-serif`, fontSize: css + 'px', fontWeight: st.bold ? '700' : '400', color: st.color,
      textTransform: st.upper ? 'uppercase' : 'none', lineHeight: '1.18',
      textShadow: textShadowFor(st, fs),
      background: st.box ? hexA(st.boxColor, (st.boxOp ?? 70) / 100) : 'transparent',
      padding: st.box ? `${pad.toFixed(1)}px` : '0', borderRadius: st.box ? '2px' : '0',
    });
    subBox.style.bottom = `calc(${((1 - st.y) * 100).toFixed(2)}% - ${st.box ? pad.toFixed(1) : 0}px)`;
    subBox.style.top = 'auto';
    subCur = null;
  }
  // contorno come ombre tutto intorno (uguale in ogni browser) + ombra
  function outlineShadow(w, color) {
    const n = Math.max(12, Math.round(w * 6)), out = [];
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; out.push(`${(Math.cos(a) * w).toFixed(2)}px ${(Math.sin(a) * w).toFixed(2)}px 0 ${color}`); }
    return out;
  }
  function textShadowFor(st, fs) {
    const parts = st.stroke ? outlineShadow(st.strokeW * fs, st.strokeColor) : [];
    if (st.shadow) { const d = 0.06 * fs + (st.stroke ? st.strokeW * fs * 0.7 : 0); parts.push(`${d.toFixed(1)}px ${d.toFixed(1)}px 0 rgba(0,0,0,.5)`); }
    return parts.length ? parts.join(',') : 'none';
  }
  // parola censurata: prima e ultima lettera, asterischi in mezzo (come nel video esportato)
  function censWord(x) { return x.length <= 1 ? x + '*' : x[0] + '*'.repeat(Math.max(1, x.length - 2)) + (x.length > 2 ? x[x.length - 1] : ''); }
  function hexA(hex, a) {
    let x = (hex || '#000').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
    return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
  }
  function showSub(t, inCut) {
    if (!proj.settings.showSubs || inCut || !allWords().length) { subBox.style.display = 'none'; subCur = null; return; }
    const list = subChunks();
    let lo = 0, hi = list.length - 1, k = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (list[m].a <= t) { k = m; lo = m + 1; } else hi = m - 1; }
    const ch = k >= 0 && t < list[k].b && !list[k].hidden ? list[k] : null;
    if (!ch) { subBox.style.display = 'none'; subCur = null; return; }
    const st = proj.subStyle;
    if (ch !== subCur) {
      subCur = ch; subHi = -1;
      subWordEls = ch.words.map((w) => h('span', null, w.cens ? censWord(w.w) : w.w));
      subSpan.replaceChildren(...subWordEls.flatMap((e, i) => (i ? [' ', e] : [e])));
      subBox.style.display = 'flex';
      if (st.effect === 'pop') { subSpan.classList.remove('pop'); void subSpan.offsetWidth; subSpan.classList.add('pop'); } else subSpan.classList.remove('pop');
    }
    if (st.effect === 'highlight') {
      let wi = 0;
      for (let i = 0; i < ch.words.length; i++) if (ch.words[i].a <= t) wi = i;
      if (wi !== subHi) { subWordEls.forEach((e, i) => { e.style.color = i === wi ? st.hiColor : ''; }); subHi = wi; }
    } else if (subHi !== -1) { subWordEls.forEach((e) => { e.style.color = ''; }); subHi = -1; }
  }
  // trascina i sottotitoli su o giu' nell'anteprima
  subSpan.addEventListener('pointerdown', (ev) => {
    ev.preventDefault(); ev.stopPropagation();
    if (!(sel && sel.type === 'subs')) select({ type: 'subs', id: 'subs' });
    capPtr(subSpan, ev.pointerId);
    begin();
    const y0 = ev.clientY, v0 = proj.subStyle.y, sh = screen.clientHeight;
    const mv = (e) => { proj.subStyle.y = +Math.max(0.12, Math.min(0.99, v0 + (e.clientY - y0) / sh)).toFixed(4); applySubStyle(); };
    const up = () => { subSpan.removeEventListener('pointermove', mv); changed(); };
    subSpan.addEventListener('pointermove', mv);
    subSpan.addEventListener('pointerup', up, { once: true });
  });
  const ovLayerEls = new Map();   // id traccia -> livello
  const ovImgs = new Map();       // id clip -> <img>
  // testi: immagine disegnata subito nel browser, poi salvata sul PC (per l'esportazione)
  const textSrc = new Map(), textUp = new Map(), textRes = new Map(), textPending = new Set();
  // aspetta che i testi siano salvati (al massimo qualche secondo: mai bloccare l'app)
  const textsSaved = () => Promise.race([Promise.all([...textPending]), new Promise((r) => setTimeout(r, 4000))]);
  // ---- testi animati lettera per lettera: fotogrammi per l'esportazione (preparati qui, uguali all'anteprima)
  const kinKey = (c) => JSON.stringify([c.text, c.kin, +(+c.dur).toFixed(2), H, KINETIC_FPS(FPS), c.kin === 'code' && c.text && c.text.fx && c.text.fx.hand ? [+(+c.a).toFixed(2), proj.zooms] : 0]);
  const kinSettle = (c) => Math.min(c.dur, c.kin === 'code' ? c.dur * 0.5 : c.kin === 'mg' && c.text && c.text.mg ? motionSettle(c.text.mg) + 0.2 : 2.2);   // l'immagine ferma (miniature, riquadro): a animazione finita
  const seqJobs = new Map(), seqTimers = new Map();
  function ensureSeq(c, now) {
    if (!c.kin) { if (c.seq) { delete c.seq; dirty = true; } return Promise.resolve(); }
    const key = kinKey(c);
    if (c.seq && c.seq.key === key) return Promise.resolve();
    const job = seqJobs.get(c.id);
    if (job && job.key === key) return job.p;
    const tm = seqTimers.get(c.id);
    if (!now) {
      // aspetta che smetti di modificare (se il timer per questa versione c'e' gia', non si ricomincia)
      if (tm && tm.key === key) return Promise.resolve();
      if (tm) clearTimeout(tm.id);
      seqTimers.set(c.id, { key, id: setTimeout(() => { seqTimers.delete(c.id); ensureSeq(c, true); }, 900) });
      return Promise.resolve();
    }
    if (tm) { clearTimeout(tm.id); seqTimers.delete(c.id); }
    const p = (async () => {
      const fps = KINETIC_FPS(FPS), n = Math.max(1, Math.ceil(c.dur * fps) + 1);
      if (c.kin === 'code') return codeSeq(c, key, fps, n);
      await ensureFont(c.text.font);
      if (c.text.sub && c.text.sub.font) await ensureFont(c.text.sub.font);
      const cv = document.createElement('canvas');
      const parts = [], head = new DataView(new ArrayBuffer(4));
      head.setUint32(0, n);
      parts.push(head.buffer);
      // animazioni che finiscono (non continue): dopo 2 s il fotogramma e' sempre uguale, si riusa
      const still = !['wave', 'rainbow', 'shine', 'glitch', 'vhs', 'type', 'karaoke', 'neon'].includes(c.kin);
      const stillAt = c.kin === 'mg' && c.text.mg ? motionSettle(c.text.mg) : 2.05;   // grafiche animate: ferme dopo l'ultimo elemento
      let last = null;
      for (let k = 0; k < n; k++) {
        if (!alive) return;
        let buf = still && k / fps > stillAt ? last : null;
        if (!buf) {
          drawKinetic(c.text, H, k / fps, c.dur, c.kin, cv);
          const b = await new Promise((r) => cv.toBlob(r, 'image/png'));
          buf = await b.arrayBuffer();
          last = buf;
        }
        const ln = new DataView(new ArrayBuffer(4)); ln.setUint32(0, buf.byteLength);
        parts.push(ln.buffer, buf);
        if (seqJobs.get(c.id) && seqJobs.get(c.id).key !== key) return;   // cambiato nel frattempo
      }
      const r = await fetch(`/api/p/${pid}/textseq?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: new Blob(parts) });
      const j = await r.json();
      if (r.ok && kinKey(c) === key) { c.seq = { dir: j.dir, n: j.n, fps, key }; dirty = true; scheduleSave(); }
    })().catch(() => {}).finally(() => { if (seqJobs.get(c.id) && seqJobs.get(c.id).key === key) seqJobs.delete(c.id); });
    seqJobs.set(c.id, { key, p });
    return p;
  }
  // effetto su misura: i fotogrammi arrivano dalla sandbox (l'AI ha scritto il codice), poi vanno al server come i testi animati
  async function codeSeq(c, key, fps, n) {
    const spec = c.text.fx, hh = Math.min(1080, H), ww = Math.round(hh * (spec.ar || W / H));
    const cv = document.createElement('canvas'); cv.width = ww; cv.height = hh;
    const g = cv.getContext('2d');
    const parts = [], head = new DataView(new ArrayBuffer(4));
    head.setUint32(0, n); parts.push(head.buffer);
    for (let k = 0; k < n; k++) {
      if (!alive) return;
      const tr = k / fps;
      const bm = await renderFx(spec, tr, c.dur, ww, hh, fxExtraAt(spec, c, tr));
      g.clearRect(0, 0, ww, hh); g.drawImage(bm, 0, 0); if (bm.close) bm.close();
      const b = await new Promise((r) => cv.toBlob(r, 'image/png'));
      const buf = await b.arrayBuffer();
      const ln = new DataView(new ArrayBuffer(4)); ln.setUint32(0, buf.byteLength);
      parts.push(ln.buffer, buf);
      if (seqJobs.get(c.id) && seqJobs.get(c.id).key !== key) return;
    }
    const r = await fetch(`/api/p/${pid}/textseq?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: new Blob(parts) });
    const j = await r.json();
    if (r.ok && kinKey(c) === key) { c.seq = { dir: j.dir, n: j.n, fps, key }; dirty = true; scheduleSave(); }
  }
  // mano che segue (se l'effetto la usa): posizione nella clip al tempo tr
  function fxExtraAt(spec, c, tr) { return spec && spec.hand ? { hand: handAt(spec, (c ? c.a : 0) + tr) } : null; }
  // la mano al tempo t della timeline (tracciata sul computer, righe [t, x, y, open, vis, tipx, tipy, size, gesto])
  function handAt(spec, t) {
    const P = spec.handTrack && spec.handTrack.pts;
    const none = { x: 0.5, y: 0.5, open: 0, visible: false, seen: 0, tip: null, size: 0, gesture: '' };
    if (!P || !P.length || t < P[0][0] - 0.25 || t > P[P.length - 1][0] + 0.25) return none;
    let lo = 0, hi = P.length - 1;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (P[m][0] <= t) lo = m; else hi = m; }
    const a = P[lo], b = P[hi];
    let r;
    if (a[4] && b[4] && b[0] > a[0]) {
      const f = Math.max(0, Math.min(1, (t - a[0]) / (b[0] - a[0])));
      r = a.map((v, i) => (i === 0 || i === 4 || i === 8 ? v : v + (b[i] - v) * f)); r[8] = f < 0.5 ? a[8] : b[8];
    } else r = a[4] && (t - a[0] <= b[0] - t || !b[4]) ? a : b[4] ? b : null;
    // visibilita' morbida (0..1): quanta mano c'e' intorno a t, cosi' l'effetto sfuma invece di sparire di colpo
    let sw = 0, sv = 0;
    for (let i = Math.max(0, lo - 6); i <= Math.min(P.length - 1, hi + 6); i++) {
      const w = Math.max(0, 1 - Math.abs(P[i][0] - t) / 0.3); sw += w; sv += w * (P[i][4] ? 1 : 0);
    }
    const seen = sw ? sv / sw : 0;
    let vis = !!r;
    if (!r) {   // mano persa: resta l'ultima posizione vicina (per sfumare li')
      let best = null;
      for (let i = Math.max(0, lo - 8); i <= Math.min(P.length - 1, hi + 8); i++) if (P[i][4] && (!best || Math.abs(P[i][0] - t) < Math.abs(best[0] - t))) best = P[i];
      if (!best || Math.abs(best[0] - t) > 0.8) return { ...none, seen };
      r = best;
    }
    // zoom della live in quel momento: la mano si sposta e si ingrandisce con l'inquadratura
    let zx = 0, zy = 0, zs = 1;
    if (!VERT) {
      let p = 0, zz = null;
      for (const z of proj.zooms || []) { if (!cam && z.kind !== 'custom') continue; const v = zoomProgress(t, z); if (v > p) { p = v; zz = z; } }
      if (p > 0.001) { const [rx, ry, rw] = rectAt(p, W, H, zoomTarget(zoomAt(zz, t), W, H, cam)); zs = W / rw; zx = rx / W; zy = ry / H; }
    }
    const mx = (v) => (v - zx) * zs, my = (v) => (v - zy) * zs;
    return { x: mx(r[1]), y: my(r[2]), open: r[3], visible: vis, seen, tip: { x: mx(r[5]), y: my(r[6]) }, size: r[7] * zs, gesture: r[8] || '' };
  }
  // tracciamento della mano sotto un effetto: i pezzi di video della traccia principale in quel tratto
  function handPieces(a, b) {
    const out = [];
    for (const s of proj.segs.filter((x) => !x.gone && x.b > a && x.a < b).sort((x, y) => x.a - y.a)) {
      const md = mainClipData(s);
      if (!md.file || md.image || md.gap) continue;
      const o0 = Math.max(a, s.a), o1 = Math.min(b, s.b);
      if (o1 - o0 < 0.05) continue;
      out.push({ file: md.file, a: +(md.offset + (o0 - s.a)).toFixed(3), b: +(md.offset + (o1 - s.a)).toFixed(3), t0: +o0.toFixed(3), box: VERT ? [0, 0, 1, 1] : segBox(s) });
    }
    return out;
  }
  const handCovers = (spec, c) => { const P = spec.handTrack && spec.handTrack.pts; return !!(P && P.length && spec.handTrack.at === +c.a.toFixed(2) && P[0][0] <= c.a + 0.2 && P[P.length - 1][0] >= c.a + c.dur - 0.25); };
  const handJobs = new Map();
  function ensureHand(c, a, dur) {
    const spec = c && c.text && c.text.fx;
    if (!spec || !spec.hand) return Promise.resolve(null);
    const A = a != null ? a : c.a, Dd = dur != null ? dur : c.dur;
    if (a == null && handCovers(spec, c)) return Promise.resolve(spec.handTrack);
    const k = (c.id || '') + ':' + A.toFixed(2) + ':' + Dd.toFixed(2);
    if (handJobs.has(k)) return handJobs.get(k);
    const pcs = handPieces(A, A + Dd);
    if (!pcs.length) return Promise.resolve(null);
    const p = (async () => {
      let cum = 0;
      const j = await post(`/api/p/${pid}/hands`, { pieces: pcs.map(({ box, ...x }) => { const t0 = +cum.toFixed(3); cum += x.b - x.a; return { ...x, t0 }; }) });
      const r = await pollJob(j.id, (x) => { handMsg = x.message || handMsg; handP = x.progress || 0; const e = document.querySelector('.fxp-hand small'); if (e) e.textContent = handMsg + ' · ' + Math.round(handP * 100) + '%'; });
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      // ogni riga: dal tempo del pezzo alla timeline, dalle coordinate del video a quelle del fotogramma
      const rows = [];
      let pi = 0;
      for (const pc of pcs) {
        const len = pc.b - pc.a, [bx, by, bw, bh] = pc.box;
        for (const q of r.result.pts) {
          if (q[0] < pi - 1e-3 || q[0] >= pi + len - 1e-3) continue;
          rows.push([+(pc.t0 + q[0] - pi).toFixed(3), +(bx + q[1] * bw).toFixed(4), +(by + q[2] * bh).toFixed(4), q[3], q[4], +(bx + q[5] * bw).toFixed(4), +(by + q[6] * bh).toFixed(4), +(q[7] * bh).toFixed(4), q[8]]);
        }
        pi += len;
      }
      return { at: +A.toFixed(2), fps: r.result.fps, pts: rows, seen: r.result.seen };
    })().finally(() => handJobs.delete(k));
    handJobs.set(k, p);
    return p;
  }
  let handMsg = '', handP = 0;
  const handBusy = new Set(), handFail = new Map(), handTried = new Map();
  // l'effetto segue la mano: tracciamento del tratto sotto la clip (anche dopo averla spostata)
  function followHand(c) {
    if (handBusy.has(c.id)) return;
    const at = c.a, dur = c.dur;
    handBusy.add(c.id); handFail.delete(c.id); handTried.set(c.id, at.toFixed(2) + ':' + dur.toFixed(2));
    ensureHand(c).then((tr) => {
      if (!tr) { handFail.set(c.id, 'Sotto l\'effetto non c\'è un video in cui cercare la mano'); return; }
      if (c.a !== at || c.dur !== dur || !c.text.fx || !c.text.fx.hand) return;   // cambiata nel frattempo
      c.text = { ...c.text, fx: { ...c.text.fx, handTrack: tr } };
      refreshText(c); dirty = true; scheduleSave();
    }).catch((err) => handFail.set(c.id, 'Mano non trovata: ' + err.message))
      .finally(() => { handBusy.delete(c.id); if (!alive) return; placeOverlays(video.currentTime); if (sel && sel.id === c.id) renderPanel(); });
    if (sel && sel.id === c.id) renderPanel();
  }
  // prima di esportare: tutti i testi animati pronti
  async function kineticReady() {
    const list = [];
    ovTracks().forEach((t) => t.clips.forEach((c) => { if (c.isText && (c.kin || c.seq)) list.push(c); }));
    if (!list.length) return;
    // effetti che seguono la mano: prima la mano (se la clip e' stata spostata)
    for (const c of list) if (c.kin === 'code' && c.text.fx && c.text.fx.hand && !handCovers(c.text.fx, c)) {
      try { const ht = await ensureHand(c); if (ht) c.text = { ...c.text, fx: { ...c.text.fx, handTrack: ht } }; } catch (e) { /* senza mano: resta dove l'ha messo l'AI */ }
    }
    if (list.some((c) => c.kin && !(c.seq && c.seq.key === kinKey(c)))) toast('Preparo i testi animati…');
    await Promise.all(list.map((c) => ensureSeq(c, true)));
  }
  // logo dei badge: immagine caricata una volta, poi il badge si ridisegna
  const logoImgs = new Map();
  preloadBadgeLogos((pid) => {
    let n = 0;
    ovTracks().forEach((t) => t.clips.forEach((x) => { if (x.text && x.text.badge && x.text.badge.platform === pid && !x.text.badge.logo) { refreshText(x); n++; } }));
    if (n) placeOverlays(video.currentTime);
  });
  function logoFor(c) {
    const path = c.text && c.text.badge && c.text.badge.logo;
    if (!path) return null;
    let im = logoImgs.get(path);
    if (!im) {
      im = new Image(); logoImgs.set(path, im);
      im.onload = () => { ovTracks().forEach((t) => t.clips.forEach((x) => { if (x.text && x.text.badge && x.text.badge.logo === path) refreshText(x); })); placeOverlays(video.currentTime); };
      im.src = mediaUrl(path);
    }
    return im.complete && im.naturalWidth ? im : null;
  }
  function refreshText(c) {
    // font non ancora caricato (incluso in NoonFrame o aggiunto dall'utente): si ridisegna appena e' pronto
    if (c.text && c.text.font && !fontReady(c.text.font)) ensureFont(c.text.font).then((ok) => { if (ok && alive) { refreshText(c); frame(true); } });
    const sf = c.text && c.text.sub && c.text.sub.font;
    if (sf && !fontReady(sf)) ensureFont(sf).then((ok) => { if (ok && alive) { refreshText(c); frame(true); } });
    const cv = (c.kin || isProText(c.text)) && !c.text.badge ? drawKinetic(c.text, H, c.kin ? kinSettle(c) : 0, c.dur, c.kin || '') : drawText(c.text, H, logoFor(c));
    ensureSeq(c);
    const natW = cv.width / CW(), ar = cv.height / cv.width;
    if (c.natW && Math.abs(natW - c.natW) > 1e-6 || (c.ar && Math.abs(ar - c.ar) > 1e-6)) {
      // stessa scala e stesso centro anche se il testo cambia lunghezza
      const k = c.natW ? natW / c.natW : 1;
      for (const o of [c.pos, ...(c.kf || [])]) {
        if (!o) continue;
        const cx = o.x + o.w / 2, cy = o.y + o.w * CA() * (c.ar || ar) / 2;
        o.w = +(o.w * k).toFixed(5); o.x = +(cx - o.w / 2).toFixed(5); o.y = +(cy - o.w * CA() * ar / 2).toFixed(5);
      }
    }
    c.natW = natW; c.ar = ar;
    c.name = c.text.badge ? (platformOf(c.text.badge.platform)[1] + ' · ' + (c.text.badge.handle || '')).slice(0, 40)
      : (String(c.text.content || '').replace(/\*/g, '').split('\n')[0] || 'Testo').slice(0, 40);
    const p = new Promise((res) => cv.toBlob((b) => {
      const u = URL.createObjectURL(b), old = textSrc.get(c.id);
      textSrc.set(c.id, u); if (old) URL.revokeObjectURL(old);
      clearTimeout(textUp.get(c.id));
      // il salvataggio precedente viene sostituito da questo: chi lo aspettava non deve restare bloccato
      const prev = textRes.get(c.id); if (prev) prev();
      textRes.set(c.id, res);
      textUp.set(c.id, setTimeout(async () => {
        try {
          const r = await fetch(`/api/p/${pid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: b });
          const j = await r.json();
          if (r.ok) { c.file = j.path; dirty = true; scheduleSave(); }
        } catch (e) { /* riprova alla prossima modifica */ }
        if (textRes.get(c.id) === res) textRes.delete(c.id);
        res();
      }, 300));
    }, 'image/png'));
    textPending.add(p); p.then(() => textPending.delete(p));
  }
  function forgetTextPreviews() { textSrc.forEach((u) => URL.revokeObjectURL(u)); textSrc.clear(); }
  const ovBox = h('div', { class: 'framebox ovbox', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }));
  // anteprima verticale: pezzi della live disegnati uno sopra l'altro (come nel video esportato)
  const vstage = h('div', { class: 'vstage', style: { display: 'none' } });
  const screen = h('div', { class: 'screen' }, zg, vstage, veil, frameBox, frameDoneBar, ovBox, h('div', { class: 'badges' }, badgeMain, badgeQ, badgeMute), loading);
  const fxLayers = new Map();   // traccia filtri -> livello
  const fxEls = new Map();   // id filtro -> elemento con backdrop-filter
  function fxLayerOf(id) {
    let el = fxLayers.get(id);
    if (!el) { el = h('div', { class: 'layer fxlayer' }); fxLayers.set(id, el); }
    return el;
  }
  function layerEl(key) {
    if (key === 'subs') return subLayer;
    if (key === 'fx' || key.startsWith('fx:')) return fxLayerOf(key === 'fx' ? 'fx' : key.slice(3));
    const id = key.slice(3);
    let el = ovLayerEls.get(id);
    if (!el) { el = h('div', { class: 'layer' }); ovLayerEls.set(id, el); }
    return el;
  }
  function arrangeLayers() {
    const order = proj.layers.filter((k) => k !== 'video').reverse();   // dal basso verso l'alto
    const zi = order.indexOf('zoom');
    const live = new Set(ovTracks().map((t) => t.id));
    for (const [id, el] of ovLayerEls) if (!live.has(id)) { el.remove(); ovLayerEls.delete(id); }
    order.forEach((k, i) => {
      if (k === 'zoom') return;
      const el = layerEl(k);
      const isFx = k === 'fx' || k.startsWith('fx:');
      if (VERT) { if (isFx) zg.append(el); else screen.insertBefore(el, veil); }   // verticale: filtri sulla live, il resto sullo schermo
      else if (i < zi) zg.append(el); else screen.insertBefore(el, veil);
    });
    // gli strumenti della maschera stanno dove sta il livello dei filtri (dentro o fuori dallo zoom)
    for (const [id, el] of fxLayers) if (!proj.fxTracks.some((t) => t.id === id)) { el.remove(); fxLayers.delete(id); }
    const sf = sel && sel.type === 'fx' ? proj.filters.find((f) => f.id === sel.id) : null;
    const host = fxLayerOf((sf && sf.track) || 'fx').parentNode || zg;
    for (const x of [maskView, maskBox, paintLayer, brushCur]) if (x.parentNode !== host || host.lastChild !== brushCur) host.append(x);
  }
  // filtri: un elemento trasparente per filtro, con backdrop-filter (+ maschera)
  let fxSeed = 1, fxTick = 0;
  const maskURLs = new Map();
  // filtro e colori messi direttamente su una clip video: come filtri sulla traccia principale, sotto gli altri
  function segFilters() {
    const r = [];
    for (const c of proj.segs) {
      if (c.gone || c.removed) continue;
      if (c.fx && c.fx.type) r.push({ id: 'sf_' + c.id, type: c.fx.type, k: c.fx.k ?? 100, a: c.a, b: c.b, track: 'fx', mask: { type: 'all' }, kf: c.fxKf });
      if ((c.adj && ADJ_KEYS.some(([k]) => c.adj[k])) || (c.adjKf || []).length) r.push({ id: 'sa_' + c.id, type: 'adjust', adj: c.adj || {}, k: 100, a: c.a, b: c.b, track: 'fx', mask: { type: 'all' }, kf: c.adjKf });
    }
    return r;
  }
  function updateFxLayer(t) {
    const on = [...segFilters(), ...proj.filters].filter((f) => !f.off && t >= f.a && t < f.b).map((f) => fxAt(f, t));
    const sw = screen.clientWidth || 1, s = sw / W;
    if (softFx()) {
      // Mac (Safari): niente filtri SVG del browser: il fotogramma filtrato si disegna in un canvas sopra il video
      for (const el of fxEls.values()) el.remove();
      const show = on.length && !VERT;
      if (show) { loadLooks(); if (fxr.render(video.el, on, video.paused ? 1280 : 800)) fxCanvas.style.display = ''; }
      else fxCanvas.style.display = 'none';
      return;
    }
    if (!video.paused && ++fxTick % 3 === 0) fxSeed = (fxSeed % 6) + 1;
    const seen = new Set(), idx = new Map();
    on.forEach((f) => {
      seen.add(f.id);
      const lay = fxLayerOf(f.track || 'fx'), i = idx.get(lay) || 0; idx.set(lay, i + 1);
      let el = fxEls.get(f.id);
      if (!el) { el = h('div', { class: 'fxel' }); fxEls.set(f.id, el); }
      if (lay.children[i] !== el) lay.insertBefore(el, lay.children[i] || null);
      const k = Math.max(0, Math.min(1, (f.k ?? 100) / 100));
      const bf = backdropFilter(f.type, k, s, W, H, fxSeed, f.adj);
      if (el.dataset.bf !== bf) { el.dataset.bf = bf; el.style.backdropFilter = bf; el.style.webkitBackdropFilter = bf; }
      const m = f.mask || { type: 'all' };
      let mk = '';
      if (m.type && m.type !== 'all') {
        const key = JSON.stringify(m) + '|' + sw;
        let u = maskURLs.get(f.id);
        if (!u || u.key !== key) {
          const cw = Math.max(2, Math.min(1280, Math.round(sw))), ch = Math.max(2, Math.round(cw * H / W));
          u = { key, url: drawMask(m, cw, ch, W, H).toDataURL('image/png') }; maskURLs.set(f.id, u);
        }
        mk = `url(${u.url})`;
      }
      if (el.dataset.mk !== mk) { el.dataset.mk = mk; el.style.maskImage = mk || 'none'; el.style.webkitMaskImage = mk || 'none'; }
    });
    for (const [id, el] of fxEls) if (!seen.has(id)) { el.remove(); if (!proj.filters.some((f) => f.id === id)) { fxEls.delete(id); maskURLs.delete(id); } }
  }
  // ---------------------------------------------------------------- formato verticale (anteprima)
  // Mentre scegli un'inquadratura o disegni la maschera di un filtro si vede la live intera (orizzontale)
  const vpool = [];
  const vMasks = new Map();
  let lastSV = null;
  const sourceView = () => !!(framing || (tab === 'video' && fxSub === 'mask' && sel && sel.type === 'fx'));
  function applyViewMode() {
    const sv = !VERT || sourceView();
    if (sv === lastSV && screen.classList.contains('vert') === (VERT && !sv)) return;
    lastSV = sv;
    zg.style.opacity = sv ? '' : '0'; zg.style.pointerEvents = sv ? '' : 'none';
    vstage.style.display = sv ? 'none' : '';
    screen.classList.toggle('vert', VERT && !sv);
    const hide = VERT && sv;   // la live intera: testi e sottotitoli (che sono sul verticale) non si vedono
    subLayer.style.visibility = hide ? 'hidden' : '';
    for (const el of ovLayerEls.values()) el.style.visibility = hide ? 'hidden' : '';
    layoutScreen();
  }
  // ---------- viso: nel verticale la webcam ritagliata segue la faccia (analisi fatta dal server)
  let faceData = null, faceJob = null;
  const FSTEP = 0.25;
  function loadFace() {
    if (!VERT || !cam) return Promise.resolve();
    return get(`/api/p/${pid}/face`).then((d) => { faceData = d && d.pts && Object.keys(d.pts).length ? d : null; frame(true); }).catch(() => {});
  }
  const faceOk = () => !!(proj.faceOn && faceData && cam && faceData.cam && faceData.cam.join() === cam.join());
  function faceAt(lt) {
    const pts = faceData.pts, k = lt / FSTEP, i0 = Math.floor(k), p0 = pts[i0], p1 = pts[i0 + 1];
    if (p0 && p1) { const f = k - i0; return [p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f]; }
    return p0 || p1 || null;
  }
  // stessa regola di engine/face.py (shift)
  function faceShift(regs, f) {
    if (!f) return regs;
    const fx = f[0] * W, fy = f[1] * H, [x0, y0, cw, ch] = cam;
    return regs.map((r) => {
      if (r.role !== 'cam' || r.blur) return r;
      const [x, y, w, hh] = r.s;
      const nx = w < cw - 0.5 ? Math.min(Math.max(x0, fx - w / 2), x0 + cw - w) : x;
      const ny = hh < ch - 0.5 ? Math.min(Math.max(y0, fy - hh * 0.45), y0 + ch - hh) : y;
      return { ...r, s: [nx, ny, w, hh] };
    });
  }
  // analisi del viso sulle parti di questa clip (le parti gia' fatte non si rifanno)
  let faceProg = 0, faceErr = '';
  function startFace() {
    if (faceJob) return faceJob;
    faceProg = 0; faceErr = '';
    faceJob = (async () => {
      try {
        const job = await post(`/api/p/${pid}/face`, {});
        const res = await pollJob(job.id, (j) => { faceProg = j.progress || 0; });
        if (res.status === 'error') faceErr = res.error || 'Tracciamento del viso non riuscito';
        await loadFace();
        if (!faceErr && !faceData) faceErr = 'Nessun viso trovato nella webcam di questa clip.';
      } catch (e) { faceErr = 'Tracciamento del viso non riuscito'; }
      finally { faceJob = null; if (alive) renderPanel(); }
    })();
    return faceJob;
  }
  function vRegsAt(t) {
    const el = video.el;
    if (!video.isLive(el)) return { regs: vertRegions('fit', el.videoWidth || W, el.videoHeight || H, { pad: vertSettings(proj).pad }), el, sx: 1, sy: 1, live: false };
    // impaginazione della clip in questo punto (o quella di tutto il progetto)
    const vs = segVert(t);
    let regs = vertRegions(vs.layout, W, H, { cam, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, boxes: vs.boxes });
    if (faceOk()) regs = faceShift(regs, faceAt(video.currentTime));
    // zoom: la webcam (o l'inquadratura scelta) si allarga a tutto schermo, con l'effetto scelto
    for (const z of proj.zooms) {
      if (z.on === false || !(t >= z.a && t < z.b)) continue;
      const bx = vertZoomBoxes(zoomAt(z, t), W, H, cam, VA(vs.pad));
      if (!bx) continue;
      regs = vertAnimRegs(regs, bx.box, zoomProgress(t, vertZoom(z)), bx.from, vs.pad);
      break;
    }
    return { regs, el, sx: (el.videoWidth || W) / W, sy: (el.videoHeight || H) / H, live: true };
  }
  function segVert(t, c0) {
    const base = vertSettings(proj);
    const c = c0 || proj.segs.find((x) => t >= x.a && t < x.b);
    if (!c || !c.vlay) return base;
    const v = { ...base, ...c.vlay };
    if ((v.layout === 'split' || v.layout === 'cam') && !cam) v.layout = 'fit';
    return v;
  }
  function drawVertical(t) {
    const { regs, el, sx, sy, live } = vRegsAt(t);
    const sw = screen.clientWidth, sh = screen.clientHeight, dpr = Math.min(2, window.devicePixelRatio || 1);
    while (vpool.length < regs.length) {
      const cv = h('canvas'), fx = h('div', { class: 'vfx' });
      const box = h('div', { class: 'vreg' }, cv, fx);
      vstage.append(box); vpool.push({ box, cv, fx, key: '' });
    }
    vpool.forEach((r, i) => { r.box.style.display = i < regs.length ? '' : 'none'; });
    const on = live ? [...segFilters(), ...proj.filters].filter((f) => !f.off && t >= f.a && t < f.b).map((f) => fxAt(f, t)) : [];
    regs.forEach((rg, i) => {
      const r = vpool[i], [dx, dy, dw, dh] = rg.d, [x, y, w, hh] = rg.s;
      const pw = dw * sw, ph = dh * sh;
      Object.assign(r.box.style, { left: dx * sw + 'px', top: dy * sh + 'px', width: pw + 'px', height: ph + 'px' });
      const cw = Math.max(2, Math.round(pw * dpr)), ch = Math.max(2, Math.round(ph * dpr));
      if (r.cv.width !== cw || r.cv.height !== ch) { r.cv.width = cw; r.cv.height = ch; }
      const g = r.cv.getContext('2d');
      const soft = softFx();
      g.filter = rg.blur && !soft ? `blur(${Math.max(3, Math.min(cw, ch) / 22 * 0.8).toFixed(1)}px) brightness(0.93)` : 'none';
      try { if (el.readyState >= 2) g.drawImage(el, x * sx, y * sy, w * sx, hh * sy, 0, 0, cw, ch); } catch (e) { /* frame non pronto */ }
      if (soft && rg.blur) { softBlur(r.cv, Math.max(3, Math.min(cw, ch) / 22 * 0.8)); g.fillStyle = 'rgba(0,0,0,.07)'; g.fillRect(0, 0, cw, ch); }
      if (soft && live && !rg.blur && on.length) {
        // Mac: filtri disegnati direttamente sul pezzo (senza maschere)
        r.tmp = r.tmp || document.createElement('canvas');
        for (const f of on) { fxr.effect(f.type, Math.max(0, Math.min(1, (f.k ?? 100) / 100)), r.cv, r.tmp, f.adj); g.save(); g.globalCompositeOperation = 'copy'; g.drawImage(r.tmp, 0, 0); g.restore(); }
        if (r.key) { r.fx.replaceChildren(); r.key = ''; }
        r.fx.style.display = 'none';
        return;
      }
      // filtri: gli stessi dell'anteprima normale, sopra questo pezzo (sulla live intera, come nell'export)
      const k = pw / w;
      const showFx = live && !rg.blur && on.length;
      Object.assign(r.fx.style, { display: showFx ? '' : 'none', left: -x * k + 'px', top: -y * k + 'px', width: W * k + 'px', height: H * k + 'px' });
      if (!showFx) { if (r.key) { r.fx.replaceChildren(); r.key = ''; } return; }
      const key = on.map((f) => f.id + f.type + (f.k ?? 100) + JSON.stringify(f.mask || 0) + JSON.stringify(f.adj || 0)).join('|') + '|' + k.toFixed(4) + '|' + fxSeed;
      if (r.key === key) return;
      r.key = key;
      r.fx.replaceChildren(...on.map((f) => {
        const d = h('div', { class: 'fxel' });
        const bf = backdropFilter(f.type, Math.max(0, Math.min(1, (f.k ?? 100) / 100)), k, W, H, fxSeed, f.adj);
        d.style.backdropFilter = bf; d.style.webkitBackdropFilter = bf;
        const m = f.mask || { type: 'all' };
        if (m.type && m.type !== 'all') {
          const mk = JSON.stringify(m);
          let u = vMasks.get(f.id);
          if (!u || u.key !== mk) { u = { key: mk, url: drawMask(m, 640, Math.round(640 * H / W), W, H).toDataURL('image/png') }; vMasks.set(f.id, u); }
          d.style.maskImage = d.style.webkitMaskImage = `url(${u.url})`;
        }
        return d;
      }));
    });
  }
  // copie leggere (720p, tanti keyframe) dei video in sovrimpressione: l'anteprima resta fluida anche con i video AI 1080p
  const lightSrc = new Map(), lightAsked = new Set();
  let lightTimer = 0, lightTries = 0;
  function askLight() {
    const want = [];
    for (const tr of ovTracks()) for (const c of tr.clips) if (c.kind === 'video' && c.file && !lightSrc.has(c.file)) want.push(c.file);
    const todo = [...new Set(want)];
    if (!todo.length) return;
    todo.forEach((f) => lightAsked.add(f));
    get('/api/media/light?' + todo.slice(0, 80).map((f) => 'path=' + encodeURIComponent(f)).join('&')).then((r) => {
      let pending = 0;
      for (const f of todo) { if (r && r[f]) lightSrc.set(f, mediaUrl(r[f])); else pending++; }
      clearTimeout(lightTimer);
      if (pending && ++lightTries < 120) lightTimer = setTimeout(askLight, 2500);
      if (!pending || lightSrc.size) placeOverlays(video.currentTime);
    }).catch(() => {});
  }
  // Mac: un video parte da solo solo se e' gia' stato avviato durante un clic. Al primo clic/tasto "sblocco" tutti
  // i video in sovrimpressione (partono e si fermano subito), cosi' poi seguono la timeline senza intoppi.
  function blessOvVideos() {
    for (const tr of ovTracks()) for (const c of tr.clips) {
      if (c.kind !== 'video' || !c.file) continue;
      let el = ovImgs.get(c.id);
      if (!el) {
        el = h('video', { class: 'ovimg ovvid', preload: 'metadata', playsinline: true, muted: true, draggable: 'false' });
        el.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); ev.preventDefault(); if (!(sel && sel.id === el.dataset.cid)) select({ type: 'sclip', id: el.dataset.cid }); startOvDrag(ev, 'move', el); });
        el.dataset.cid = c.id; el.style.display = 'none';
        const want = lightSrc.get(c.file) || mediaUrl(c.file);
        el.dataset.src = want; el.src = want;
        ovImgs.set(c.id, el);
        const lay = layerEl('ov:' + tr.id); if (lay) lay.append(el);
      }
      if (el._blessed && !el._blocked) continue;
      el.muted = true; el.defaultMuted = true;
      const wasPaused = el.paused;
      try {
        const pr = el.play();
        el._blessed = true; el._blocked = false;
        if (pr && pr.then) pr.then(() => { if (wasPaused && (video.paused || el.style.display === 'none')) el.pause(); }, () => {});
      } catch (e) { /* */ }
    }
  }
  const onBless = () => blessOvVideos();
  window.addEventListener('pointerdown', onBless, true);
  window.addEventListener('keydown', onBless, true);
  const ovShown = new Map();   // traccia -> ultimo elemento visibile (resta sull'ultimo fotogramma finche' il prossimo video non e' pronto)
  const PREROLL = 1.5;
  // ---- persona ritagliata (titoli dietro): la live vista attraverso la maschera, disegnata con la GPU
  const matteVids = new Map();
  function matteVid(c) {
    let v = matteVids.get(c.id);
    if (!v) {
      // nel documento ma invisibile (alcuni browser non aggiornano i fotogrammi dei video fuori pagina)
      v = h('video', { preload: 'auto', playsinline: true, muted: true, style: { position: 'fixed', left: '0', top: '0', width: '2px', height: '2px', opacity: '0', pointerEvents: 'none' } });
      v.muted = true; v.src = mediaUrl(c.matte.mask); document.body.append(v);
      matteVids.set(c.id, v);
    }
    return v;
  }
  let mgl = null;
  function matteGL(cv) {
    if (cv._gl) return cv._gl;
    const gl = cv.getContext('webgl', { premultipliedAlpha: false, alpha: true });
    if (!gl) return null;
    const sh = (type, src) => { const x = gl.createShader(type); gl.shaderSource(x, src); gl.compileShader(x); return x; };
    const pr = gl.createProgram();
    gl.attachShader(pr, sh(gl.VERTEX_SHADER, 'attribute vec2 p;varying vec2 uv;void main(){uv=vec2((p.x+1.)/2.,(1.-p.y)/2.);gl_Position=vec4(p,0.,1.);}'));
    gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, 'precision mediump float;varying vec2 uv;uniform sampler2D v;uniform sampler2D m;void main(){vec3 c=texture2D(v,uv).rgb;float a=texture2D(m,uv).r;gl_FragColor=vec4(c,a);}'));
    gl.linkProgram(pr); gl.useProgram(pr);
    const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const tex = (unit) => { const t2 = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t2);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); return t2; };
    const tv = tex(0), tm = tex(1);
    gl.uniform1i(gl.getUniformLocation(pr, 'v'), 0); gl.uniform1i(gl.getUniformLocation(pr, 'm'), 1);
    cv._gl = { gl, tv, tm };
    return cv._gl;
  }
  function drawMatte(c, t, cv) {
    const mv = matteVid(c), rel = Math.max(0, t - c.a);
    // la maschera segue la timeline
    if (!video.paused) { if (mv.paused) mv.play().catch(() => {}); if (Math.abs(mv.currentTime - rel) > 0.12) mv.currentTime = rel; mv.playbackRate = video.playbackRate; }
    else { if (!mv.paused) mv.pause(); if (Math.abs(mv.currentTime - rel) > 0.02) mv.currentTime = rel; }
    const el = video.el;
    if (!el || el.readyState < 2 || mv.readyState < 2) return;
    const w = Math.min(1280, Math.round(screen.clientWidth * (window.devicePixelRatio || 1))), hh = Math.round(w * H / W);
    if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
    const g = matteGL(cv);
    if (!g) return;
    const { gl, tv, tm } = g;
    gl.viewport(0, 0, w, hh);
    try {
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tv); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, el);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, tm); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, mv);
      gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    } catch (e) { /* video non ancora pronto */ }
  }
  // ---- green screen (chroma key): stesso calcolo di ffmpeg chromakey + despill usati nell'esportazione (engine/render.py)
  const KEY_DEF = { on: true, color: '#00B140', sim: 0.18, blend: 0.08, spill: true };
  const keyOf = (c) => {
    if (!(c && c.key && c.key.on && !c.isText && !(c.matte && c.matte.mask))) return null;
    const k = { ...KEY_DEF, ...c.key };
    if (k.mode === 'ai') return c.kind === 'video' && cutOk(c) ? k : null;
    return k;
  };
  // ritaglio AI di un video: vale se copre il pezzo di video usato dalla clip
  const cutOk = (c) => { const q = c.key && c.key.cut; if (!q || q.file !== c.file) return false; const o = c.offset || 0; return o >= q.off - 0.05 && o + c.dur <= q.off + q.dur + 0.15; };
  const aiImgFile = (c) => (c && c.kind === 'image' && c.key && c.key.on && c.key.mode === 'ai' && c.key.cutFile && c.key.src === c.file ? c.key.cutFile : null);
  const keyMaskVids = new Map();
  function keyMaskVid(c) {
    const q = c.key.cut; let v = keyMaskVids.get(c.id);
    if (v && v.dataset.src !== q.mask) { v.remove(); v = null; }
    if (!v) {
      v = h('video', { preload: 'auto', playsinline: true, muted: true, style: { position: 'fixed', left: '0', top: '0', width: '2px', height: '2px', opacity: '0', pointerEvents: 'none' } });
      v.muted = true; v.dataset.src = q.mask; v.src = mediaUrl(q.mask); document.body.append(v);
      v.addEventListener('seeked', () => { const el = ovImgs.get(c.id); if (el) keyDraw(c, el); });
      keyMaskVids.set(c.id, v);
    }
    return v;
  }
  const hexRgb = (x) => { const m = String(x || '').replace('#', ''); const n = parseInt(m.length === 3 ? m.split('').map((q) => q + q).join('') : m, 16) || 0; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
  const rgbHex = (r, g, b) => '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('').toUpperCase();
  const uvOf = (r, g, b) => [(-0.168736 * r - 0.331264 * g + 0.5 * b) / 255, (0.5 * r - 0.418688 * g - 0.081312 * b) / 255];
  function keyGL(cv) {
    if (cv._gl) return cv._gl;
    const gl = cv.getContext('webgl', { premultipliedAlpha: false, alpha: true, preserveDrawingBuffer: true });
    if (!gl) return null;
    const sh = (type, src) => { const x = gl.createShader(type); gl.shaderSource(x, src); gl.compileShader(x); return x; };
    const pr = gl.createProgram();
    gl.attachShader(pr, sh(gl.VERTEX_SHADER, 'attribute vec2 p;varying vec2 uv;void main(){uv=vec2((p.x+1.)/2.,(1.-p.y)/2.);gl_Position=vec4(p,0.,1.);}'));
    gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, [
      'precision mediump float;varying vec2 uv;uniform sampler2D v;uniform sampler2D mt;uniform float am;uniform vec2 k;uniform vec2 px;uniform float sim;uniform float bl;uniform float sp;uniform float gs;uniform float mk;uniform float bk;',
      'vec2 ch(vec3 c){return vec2(-0.168736*c.r-0.331264*c.g+0.5*c.b,0.5*c.r-0.418688*c.g-0.081312*c.b);}',
      'void main(){vec4 c0=texture2D(v,uv);vec2 s=vec2(0.);',
      'for(int i=-1;i<=1;i++){for(int j=-1;j<=1;j++){s+=ch(texture2D(v,uv+vec2(float(i),float(j))*px).rgb);}}',
      's/=9.;float d=distance(s,k)/1.41421356;float a=bl>0.0001?clamp((d-sim)/bl,0.,1.):step(sim,d);if(am>0.5){a=texture2D(mt,uv).r;}',
      'vec3 c=c0.rgb;if(sp>0.5&&am<0.5){if(gs>0.5){c.g-=clamp(c.g-(c.r+c.b)*0.5,0.,1.);}else{c.b-=clamp(c.b-(c.r+c.g)*0.5,0.,1.);}}',
      'gl_FragColor=mk>0.5?vec4(vec3(c0.a*a),1.):bk>0.5?vec4(c*c0.a*a,1.):vec4(c,c0.a*a);}'].join('')));
    gl.linkProgram(pr); gl.useProgram(pr);
    const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const tx = gl.createTexture(); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tx);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    const u = (n) => gl.getUniformLocation(pr, n);
    gl.uniform1i(u('v'), 0);
    const tm = gl.createTexture(); gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, tm);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.uniform1i(u('mt'), 1);
    cv._gl = { gl, tx, tm, am: u('am'), k: u('k'), px: u('px'), sim: u('sim'), bl: u('bl'), sp: u('sp'), gs: u('gs'), mk: u('mk'), bk: u('bk') };
    return cv._gl;
  }
  function keyDraw(c, el) {
    const k = keyOf(c), cv = el._ck;
    if (!k || !cv) return;
    const vid = el.tagName === 'VIDEO';
    keyRender(cv, el, k, c, vid ? el.currentTime - (k.cut ? k.cut.off : 0) : 0, vid && !el.paused, vid ? el.playbackRate : 1, false);
  }
  // disegna un video/immagine senza sfondo in una tela (clip sopra la live, o la traccia principale con il nero dietro)
  // owner: la clip (id + key.cut); rel: secondi dentro la maschera AI; fit: la tela e' grande quanto il quadro (video contenuto)
  function keyRender(cv, el, k, owner, rel, playing, rate, fit) {
    const vid = el.tagName === 'VIDEO';
    const sw = vid ? el.videoWidth : el.naturalWidth, shh = vid ? el.videoHeight : el.naturalHeight;
    if (!sw || !shh || (vid && el.readyState < 2) || (!vid && !el.complete)) return false;
    let w, hh;
    if (fit) { w = Math.max(16, Math.min(1600, Math.round(W * Math.min(1, 1280 / W)))); hh = Math.max(16, Math.round(w * H / W)); }
    else { const dpr = window.devicePixelRatio || 1; w = Math.max(16, Math.min(1600, sw, Math.round((el.offsetWidth || 320) * dpr * 1.25))); hh = Math.max(16, Math.round(w * shh / sw)); }
    if (cv.width !== w || cv.height !== hh) { cv.width = w; cv.height = hh; }
    const g = keyGL(cv); if (!g) return false;
    const { gl } = g;
    const [r, gg, bb] = hexRgb(k.color), uv = uvOf(r, gg, bb);
    const ai = k.mode === 'ai';
    let mv = null;
    if (ai) {
      // la maschera AI segue il video
      mv = keyMaskVid(owner);
      const rr = Math.max(0, rel);
      if (playing) { if (mv.paused) mv.play().catch(() => {}); if (Math.abs(mv.currentTime - rr) > 0.12) mv.currentTime = rr; mv.playbackRate = rate || 1; }
      else { if (!mv.paused) mv.pause(); if (Math.abs(mv.currentTime - rr) > 0.02) mv.currentTime = rr; }
      if (mv.readyState < 2) return false;
    }
    // dentro il quadro: il video resta intero (bande nere se ha un'altra forma), come l'elemento video
    let vx = 0, vy = 0, vw = w, vh = hh;
    if (fit) { const va = sw / shh, ca = w / hh; if (va > ca) { vh = Math.round(w / va); vy = Math.round((hh - vh) / 2); } else { vw = Math.round(hh * va); vx = Math.round((w - vw) / 2); } }
    try {
      gl.viewport(0, 0, w, hh);
      gl.clearColor(0, 0, 0, fit ? 1 : 0); gl.clear(gl.COLOR_BUFFER_BIT);
      gl.viewport(vx, vy, vw, vh);
      if (ai) { gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, g.tm); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, mv); }
      gl.uniform1f(g.am, ai ? 1 : 0);
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, g.tx); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, el);
      gl.uniform2f(g.k, uv[0], uv[1]); gl.uniform2f(g.px, 1 / sw, 1 / shh);
      gl.uniform1f(g.sim, k.sim); gl.uniform1f(g.bl, k.blend); gl.uniform1f(g.sp, k.spill ? 1 : 0); gl.uniform1f(g.gs, gg >= bb ? 1 : 0); gl.uniform1f(g.mk, keyMask === owner.id ? 1 : 0);
      gl.uniform1f(g.bk, fit ? 1 : 0);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    } catch (e) { return false; /* fotogramma non ancora pronto */ }
    return true;
  }
  // ---- traccia principale senza sfondo: dietro la persona c'e' il nero (la clip resta dove sta)
  const segKeyOf = (seg) => {
    if (!seg || VERT || !(seg.key && seg.key.on)) return null;
    const k = { ...KEY_DEF, ...seg.key };
    if (k.mode !== 'ai') return k;
    const q = seg.key.cut, d = mainClipData(seg);
    return q && q.file === d.file && d.offset >= q.off - 0.05 && d.offset + d.dur <= q.off + q.dur + 0.15 ? k : null;
  };
  let mainKeyOn = false;
  function updateMainKey(t) {
    const seg = segAtT(t), k = seg && !seg.removed ? segKeyOf(seg) : null, el = video.el;
    const els = [liveVid, video.twinEl, video.montEl, ...video.insEls].filter(Boolean);
    let ok = false;
    if (k && el) {
      const d = k.mode === 'ai' ? mainClipData(seg) : null;
      ok = keyRender(mainKeyCv, el, k, seg, d ? d.offset + (t - seg.a) - seg.key.cut.off : 0, !video.paused, video.playbackRate, true);
      if (!ok && mainKeyOn) ok = true;   // fotogramma non pronto: resta quello di prima
    }
    if (ok) {
      mainKeyCv.style.display = '';
      mainKeyCv.style.transform = el.style.transform; mainKeyCv.style.clipPath = el.style.clipPath;
      for (const e of els) if (e.style.opacity !== '0') e.style.opacity = '0';
    } else if (mainKeyOn || mainKeyCv.style.display !== 'none') {
      mainKeyCv.style.display = 'none';
      for (const e of els) e.style.opacity = '';
    }
    mainKeyOn = ok;
  }
  // la clip con il green screen si vede attraverso una tela: il video/immagine vero resta sotto, invisibile, per i clic e la sincronia
  function keySync(c, el, on) {
    const k = keyOf(c);
    let cv = el._ck;
    if (!k) { if (cv) { cv.remove(); el._ck = null; } return; }
    if (!cv) {
      cv = h('canvas', { class: 'ovimg ovkey' }); cv.style.pointerEvents = 'none'; el._ck = cv;
      const redraw = () => { const cc = findOvClip(el.dataset.cid); if (cc) keyDraw(cc, el); };
      el.addEventListener('seeked', redraw); el.addEventListener('loadeddata', redraw); el.addEventListener('load', redraw);
    }
    if (cv.parentNode !== el.parentNode || cv.previousSibling !== el) el.after(cv);
    const ar = c.ar || (el.tagName === 'VIDEO' ? (el.videoHeight / el.videoWidth) : (el.naturalHeight / el.naturalWidth)) || 9 / 16;
    const S = cv.style, E = el.style;
    S.display = on ? E.display : 'none'; S.visibility = E.visibility; S.left = E.left; S.top = E.top; S.width = E.width; S.transform = E.transform;
    S.aspectRatio = String(1 / ar);
    if (E.opacity !== '0') { el._ckOp = E.opacity || '1'; E.opacity = '0'; }
    S.opacity = el._ckOp || '1';
    if (on) keyDraw(c, el);
  }
  function findOvClip(id) { for (const tr of ovTracks()) { const x = tr.clips.find((q) => q.id === id); if (x) return x; } return null; }
  // colore del fondo: i pixel del bordo piu' saturi (di solito il telo verde/blu)
  function keyDetect(el) {
    try {
      const vid = el.tagName === 'VIDEO', sw = vid ? el.videoWidth : el.naturalWidth, shh = vid ? el.videoHeight : el.naturalHeight;
      if (!sw || !shh) return null;
      const w = 160, hh = Math.max(8, Math.round(w * shh / sw)), cv = document.createElement('canvas'); cv.width = w; cv.height = hh;
      const g = cv.getContext('2d', { willReadFrequently: true }); g.drawImage(el, 0, 0, w, hh);
      const d = g.getImageData(0, 0, w, hh).data, px = [];
      const take = (x, y) => { const i = (y * w + x) * 4; px.push([d[i], d[i + 1], d[i + 2]]); };
      for (let x = 0; x < w; x += 2) { take(x, 1); take(x, hh - 2); }
      for (let y = 0; y < hh; y += 2) { take(1, y); take(w - 2, y); }
      const green = px.filter(([r, gg, b]) => gg > r * 1.25 && gg > b * 1.15 && gg > 60), blue = px.filter(([r, gg, b]) => b > r * 1.25 && b > gg * 1.1 && b > 60);
      const best = green.length >= blue.length ? green : blue;
      if (best.length < px.length * 0.15) return null;
      const med = (i) => best.map((q) => q[i]).sort((x, y) => x - y)[best.length >> 1];
      return rgbHex(med(0), med(1), med(2));
    } catch (e) { return null; }
  }
  let keyPick = null;   // contagocce attivo: id della clip
  let keyMask = null;   // clip di cui si vede la maschera (solo anteprima)
  function keyPickAt(ev) {
    const seg = proj.segs.find((x) => x.id === keyPick);
    if (seg) return keyPickMain(ev, seg);
    const c = findOvClip(keyPick), el = c && ovImgs.get(c.id);
    if (el && el.tagName === 'VIDEO' && el.readyState < 2) return toast('Il video si sta ancora caricando: riprova tra un attimo', true);
    keyPick = null; screen.classList.remove('keypick');
    if (!c || !el) return;
    const r = (el._ck || el).getBoundingClientRect();
    const rx = (ev.clientX - r.left) / r.width, ry = (ev.clientY - r.top) / r.height;
    if (rx < 0 || rx > 1 || ry < 0 || ry > 1) return toast('Clicca dentro il video o l\'immagine', true);
    try {
      const vid = el.tagName === 'VIDEO', sw = vid ? el.videoWidth : el.naturalWidth, shh = vid ? el.videoHeight : el.naturalHeight;
      const w = 320, hh = Math.max(8, Math.round(w * shh / sw)), cv = document.createElement('canvas'); cv.width = w; cv.height = hh;
      const g = cv.getContext('2d', { willReadFrequently: true }); g.drawImage(el, 0, 0, w, hh);
      const x0 = Math.max(0, Math.min(w - 5, Math.round(rx * w) - 2)), y0 = Math.max(0, Math.min(hh - 5, Math.round(ry * hh) - 2));
      const d = g.getImageData(x0, y0, 5, 5).data; let R = 0, G = 0, Bb = 0;
      for (let i = 0; i < d.length; i += 4) { R += d[i]; G += d[i + 1]; Bb += d[i + 2]; }
      begin(); c.key = { ...KEY_DEF, ...(c.key || {}), on: true, color: rgbHex(R / 25, G / 25, Bb / 25) }; changed();
      placeOverlays(video.currentTime); renderPanel();
    } catch (e) { toast('Non riesco a leggere il colore: riprova', true); }
  }
  // contagocce sulla traccia principale: il video e' contenuto nel quadro (bande nere se ha un'altra forma)
  function keyPickMain(ev, seg) {
    const el = video.el;
    if (!el || el.readyState < 2) return toast('Il video si sta ancora caricando: riprova tra un attimo', true);
    keyPick = null; screen.classList.remove('keypick');
    const r = el.getBoundingClientRect(), sw = el.videoWidth, shh = el.videoHeight;
    if (!sw || !shh) return;
    const va = sw / shh, ra = r.width / r.height;
    let bw = r.width, bh = r.height, bx = r.left, by = r.top;
    if (va > ra) { bh = r.width / va; by += (r.height - bh) / 2; } else { bw = r.height * va; bx += (r.width - bw) / 2; }
    const rx = (ev.clientX - bx) / bw, ry = (ev.clientY - by) / bh;
    if (rx < 0 || rx > 1 || ry < 0 || ry > 1) return toast('Clicca dentro il video o l\'immagine', true);
    try {
      const w = 320, hh = Math.max(8, Math.round(w / va)), cv = document.createElement('canvas'); cv.width = w; cv.height = hh;
      const g = cv.getContext('2d', { willReadFrequently: true }); g.drawImage(el, 0, 0, w, hh);
      const x0 = Math.max(0, Math.min(w - 5, Math.round(rx * w) - 2)), y0 = Math.max(0, Math.min(hh - 5, Math.round(ry * hh) - 2));
      const d = g.getImageData(x0, y0, 5, 5).data; let R = 0, G = 0, Bb = 0;
      for (let i = 0; i < d.length; i += 4) { R += d[i]; G += d[i + 1]; Bb += d[i + 2]; }
      begin(); seg.key = { ...KEY_DEF, ...(seg.key || {}), on: true, color: rgbHex(R / 25, G / 25, Bb / 25) }; changed();
      frame(true); renderPanel();
    } catch (e) { toast('Non riesco a leggere il colore: riprova', true); }
  }
  function placeOverlays(t) {
    const seen = new Set();
    let needLight = false;
    for (const tr of ovTracks()) {
      const lay = layerEl('ov:' + tr.id);
      let onEl = null;
      for (const c of tr.clips) {
        seen.add(c.id);
        let img = ovImgs.get(c.id);
        const on = !tr.hidden && t >= c.a && t < c.a + c.dur;
        const isVid = c.kind === 'video';
        if (isVid && c.file && !lightSrc.has(c.file) && !lightAsked.has(c.file)) needLight = true;
        // il prossimo video si prepara un po' prima (caricato e gia' al punto giusto): niente nero al cambio
        const pre = isVid && !on && !tr.hidden && t >= c.a - PREROLL && t < c.a;
        if (pre) {
          if (!img) {
            img = h('video', { class: 'ovimg ovvid', preload: 'auto', playsinline: true, muted: true, draggable: 'false' });
            img.muted = true; img.defaultMuted = true;
            img.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); ev.preventDefault(); if (!(sel && sel.id === img.dataset.cid)) select({ type: 'sclip', id: img.dataset.cid }); startOvDrag(ev, 'move', img); });
            ovImgs.set(c.id, img);
          }
          img.dataset.cid = c.id;
          const want = lightSrc.get(c.file) || mediaUrl(c.file);
          if (img.dataset.src !== want) { img.dataset.src = want; img.src = want; }
          if (img.parentNode !== lay) lay.append(img);
          if (!img.paused) img.pause();
          const t0 = c.offset || 0;
          if (!img.seeking && Math.abs(img.currentTime - t0) > 0.04) { try { img.currentTime = t0; } catch (e) { /* non ancora caricato */ } }
          img.style.aspectRatio = String(1 / (c.ar || 9 / 16));
          img.style.visibility = 'hidden'; img.style.display = 'block';
          continue;
        }
        const isKin = !!(c.isText && c.kin && !(c.text && c.text.badge));
        const isMatte = !!(c.matte && c.matte.mask);
        if (img && (img.tagName === 'CANVAS') !== (isKin || isMatte)) { img.remove(); if (img._ck) img._ck.remove(); ovImgs.delete(c.id); img = null; }   // testo animato <-> fermo
        if (!img) {
          if (!on) { if (isMatte) matteVid(c); continue; }   // la maschera si prepara prima
          img = isVid ? h('video', { class: 'ovimg ovvid', preload: 'auto', playsinline: true, muted: true, draggable: 'false' })
            : isKin || isMatte ? h('canvas', { class: 'ovimg ' + (isMatte ? 'ovmatte' : 'ovkin') }) : h('img', { class: 'ovimg', alt: '', draggable: 'false' });
          img.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); ev.preventDefault(); if (!(sel && sel.id === img.dataset.cid)) select({ type: 'sclip', id: img.dataset.cid }); startOvDrag(ev, 'move', img); });
          ovImgs.set(c.id, img);
        }
        img.dataset.cid = c.id;
        if (isMatte) {
          if (on) drawMatte(c, t, img); else { const mv = matteVids.get(c.id); if (mv && !mv.paused) mv.pause(); }
        } else if (isKin) {
          ensureSeq(c);
          if (on) {
            // disegnato dal vivo, alla risoluzione che si vede (non di piu': resta leggero)
            const Hp = Math.max(160, Math.min(H, Math.round(screen.clientHeight * (window.devicePixelRatio || 1) * (() => { try { return Math.max(1, vz.s); } catch (e) { return 1; } })())));
            const tr2 = Math.round((t - c.a) * 60) / 60, k = kinKey(c) + '|' + Hp + '|' + tr2;
            if (c.kin === 'code' && c.text.fx) fxClipOf.set(c.text.fx, c);
            if (img.dataset.k !== k || c.kin === 'code') { img.dataset.k = k; drawKinetic(c.text, Hp, tr2, c.dur, c.kin, img); }
          }
        } else {
          const want = textSrc.get(c.id) || (aiImgFile(c) ? mediaUrl(aiImgFile(c)) : c.file ? (isVid && lightSrc.get(c.file)) || mediaUrl(c.file) : '');
          // la copia leggera sostituisce l'originale solo quando non si sta vedendo quel video
          if (want && img.dataset.src !== want && (!img.dataset.src || !on || video.paused)) {
            const keepT = isVid && img.dataset.src ? img.currentTime : null;
            img.dataset.src = want; img.src = want;
            if (isVid) { img.muted = true; if (keepT != null) { try { img.currentTime = keepT; } catch (e) { /* */ } } }
          }
        }
        if (img.parentNode !== lay) lay.append(img);
        img.style.display = on ? 'block' : 'none';
        if (on) {
          onEl = img;
          // video senza ancora un fotogramma: resta nascosto per un attimo (sotto si vede ancora il precedente)
          if (isVid && img.readyState < 2) { img._wait = img._wait || performance.now(); img.style.visibility = performance.now() - img._wait < 1200 ? 'hidden' : ''; }
          else { img._wait = 0; if (img.style.visibility) img.style.visibility = ''; }
        }
        if (on) {
          const st = imgFinal(c, t - c.a, CA());
          // posto fisso (quello di base) + spostamento/scala con transform: niente scatti di un pixel negli zoom lenti
          const b = c.pos && c.pos.w ? c.pos : st, sw = screen.clientWidth, sh = screen.clientHeight;
          const bl = b.x * 100 + '%', bt = b.y * 100 + '%', bw = b.w * 100 + '%';
          if (img.style.left !== bl) img.style.left = bl;
          if (img.style.top !== bt) img.style.top = bt;
          if (img.style.width !== bw) img.style.width = bw;
          const k = st.w / b.w, ar = c.ar || 1, bh = b.w * CA() * ar, hh = st.w * CA() * ar;
          const dx = ((st.x + st.w / 2) - (b.x + b.w / 2)) * sw, dy = ((st.y + hh / 2) - (b.y + bh / 2)) * sh;
          img.style.opacity = String(Math.max(0, Math.min(1, st.op / 100)));
          img.style.transform = `translate(${dx.toFixed(3)}px, ${dy.toFixed(3)}px) scale(${k.toFixed(5)}) ` + imgCss(st, sw / k);
        }
        if (isVid) syncOvVideo(img, c, tr, t, on);
        if (!isKin && !isMatte) keySync(c, img, on); else if (img._ck) { img._ck.remove(); img._ck = null; }
      }
      const rec = ovShown.get(tr.id), prev = rec && rec.el;
      if (onEl && onEl.tagName === 'VIDEO' && onEl.style.visibility === 'hidden' && prev && prev !== onEl && prev.isConnected && t >= rec.t && t - rec.t < 1) {
        prev.style.display = 'block'; prev.style.visibility = '';   // tiene l'ultimo fotogramma del precedente
        if (prev.tagName === 'VIDEO' && !prev.paused) prev.pause();
      } else if (onEl) ovShown.set(tr.id, { el: onEl, t });
    }
    if (needLight) askLight();
    for (const [id, img] of ovImgs) if (!seen.has(id)) { img.remove(); if (img._ck) img._ck.remove(); ovImgs.delete(id); }
    // riquadro per spostare/ridimensionare l'immagine selezionata
    const c = sel && sel.type === 'sclip' ? findSel() : null;
    const img = c && (c.kind === 'image' || c.kind === 'video') ? ovImgs.get(c.id) : null;
    if (img && img.style.display !== 'none' && !framing) {
      const r = img.getBoundingClientRect(), sr = screen.getBoundingClientRect();
      Object.assign(ovBox.style, { display: 'block', left: r.left - sr.left + 'px', top: r.top - sr.top + 'px', width: r.width + 'px', height: r.height + 'px' });
    } else if (ovBox.style.display !== 'none') ovBox.style.display = 'none';
  }
  // video in sovrimpressione: segue la testina (tempo, velocita', volume)
  function syncOvVideo(el, c, tr, t, on) {
    el.style.aspectRatio = String(1 / (c.ar || 9 / 16));
    if (!on) { if (!el.paused) el.pause(); return; }
    const target = (c.offset || 0) + (t - c.a);
    const v = tr.mute || c.mute || !c.hasAudio ? 0 : Math.max(0, Math.min(1, ((tr.vol ?? 100) / 100) * ((c.vol ?? 100) / 100)));
    el.volume = v; el.muted = v === 0;
    const rate = video.playbackRate;
    if (video.paused) {
      if (!el.paused) el.pause();
      if (el.playbackRate !== rate) el.playbackRate = rate;
      if (!el.seeking && Math.abs(el.currentTime - target) > 0.04) el.currentTime = target;
      return;
    }
    if (el.paused) {
      if (el._playing) return;   // play() gia' chiesto: aspetto
      if (el._blocked) { if (!el.seeking && Math.abs(el.currentTime - target) > 0.2) el.currentTime = target; return; }
      if (!el.seeking && Math.abs(el.currentTime - target) > 0.05) el.currentTime = target;
      el.playbackRate = rate; el._playing = true;
      const pr = el.play();
      if (pr && pr.then) pr.then(() => { el._playing = false; el._blocked = false; }, (e) => {
        el._playing = false;
        // il sistema non lo lascia partire (Mac): niente tentativi a ogni fotogramma (scatti e salti), riprovo al prossimo clic
        if (e && e.name === 'NotAllowedError') el._blocked = true;
        if (!el._playErr) { el._playErr = true; post('/api/clientlog', { msg: 'video in sovrimpressione non parte: ' + (e && e.name) + ' ' + (e && e.message) }).catch(() => {}); }
      });
      else el._playing = false;
      return;
    }
    // in riproduzione: piccoli scarti si recuperano con la velocita' (senza salti), grandi con un salto
    const d = el.currentTime - target;
    if (Math.abs(d) > 0.5) { if (!el.seeking) el.currentTime = target; }
    else if (Math.abs(d) > 0.08) { const r2 = rate * (d > 0 ? 0.92 : 1.08); if (Math.abs(el.playbackRate - r2) > 1e-3) el.playbackRate = r2; }
    else if (Math.abs(el.playbackRate - rate) > 1e-3) el.playbackRate = rate;
  }
  let ovDrag = null;
  function startOvDrag(ev, mode, img) {
    const c = findSel(); if (!c || (c.kind !== 'image' && c.kind !== 'video')) return;
    const target = ev.currentTarget;
    capPtr(target, ev.pointerId);
    begin();
    const s0 = imgStateAt(c, Math.max(0, Math.min(c.dur, video.currentTime - c.a)));
    const sw = screen.clientWidth, sh = screen.clientHeight;
    // quanto e' ingrandita l'anteprima in questo momento (zoom attivo)
    const zs = zg.contains(img) ? Math.max(0.2, zg.getBoundingClientRect().width / sw) : 1;
    const ar = c.ar || 9 / 16;
    ovDrag = { mode, x: ev.clientX, y: ev.clientY, s0 };
    const mv = (e) => {
      if (!ovDrag) return;
      const it = findSel(); if (!it) return;
      const dx = (e.clientX - ovDrag.x) / (sw * zs), dy = (e.clientY - ovDrag.y) / (sh * zs);
      const p = ovDrag.s0;
      if (ovDrag.mode === 'move') {
        const nx = p.x + dx, ny = p.y + dy;
        const [sx2, sy2] = snapRect([nx, ny, p.w, p.w * CA() * ar], e.altKey, it.id);
        setProps(it, { x: nx + sx2, y: ny + sy2 });
      }
      else {
        const sx = ovDrag.mode.includes('w') ? -1 : 1;
        const nw = Math.max(0.02, Math.min(3, p.w + sx * dx));
        const hf0 = p.w * CA() * ar, hf1 = nw * CA() * ar;
        setProps(it, { w: nw, x: ovDrag.mode.includes('w') ? p.x + p.w - nw : p.x, y: ovDrag.mode.includes('n') ? p.y + hf0 - hf1 : p.y });
      }
      placeOverlays(video.currentTime);
    };
    const up = () => { target.removeEventListener('pointermove', mv); ovDrag = null; hideSnap(); changed(); };
    target.addEventListener('pointermove', mv);
    target.addEventListener('pointerup', up, { once: true });
  }

  // ---------------------------------------------------------------- guide, calamite, clip spostate a mano
  // guide: linee sull'anteprima (non finiscono nel video), una lista per il formato orizzontale e una per il verticale
  const guideLayer = h('div', { class: 'guides' });
  const snapV = h('div', { class: 'snapline v' }), snapH = h('div', { class: 'snapline h' });
  const tfLayer = h('div', { class: 'tflayer' });
  proj.guides = proj.guides || {};
  let guidesOn = true, snapObj = store.get('snapObj', true);
  const fmtKey = () => (VERT ? 'v' : 'h');
  const guidesOf = () => (proj.guides[fmtKey()] = proj.guides[fmtKey()] || []);
  let guideKey = '';
  let guideDrag = false;
  function drawGuides(force) {
    if (guideDrag && !force) return;
    const key = fmtKey() + JSON.stringify(guidesOf()) + guidesOn + sourceView() + proj.guides.grid + proj.guides.safe;
    if (!force && key === guideKey) return;
    guideKey = key;
    guideLayer.replaceChildren();
    guideLayer.style.display = guidesOn && !sourceView() ? '' : 'none';
    // griglia dei terzi e zone coperte dalle app (TikTok, Reels, Shorts): solo da vedere, non escono nel video
    if (proj.guides.grid) guideLayer.append(h('div', { class: 'gridthirds' }, h('i', { class: 'v1' }), h('i', { class: 'v2' }), h('i', { class: 'h1' }), h('i', { class: 'h2' })));
    const sz = isVertOut() && SAFE_ZONES[proj.guides.safe];
    if (sz) guideLayer.append(h('div', { class: 'safezone', html: `<svg viewBox="0 0 1080 1920" preserveAspectRatio="none" fill="#fff">${sz.svg.join('')}</svg>` }));
    guidesOf().forEach((g) => {
      const el = h('div', { class: 'guide ' + g.o, style: g.o === 'v' ? { left: g.p * 100 + '%' } : { top: g.p * 100 + '%' }, 'data-tip': 'Trascinala dove vuoi (al centro si aggancia) · fuori dall\'anteprima per toglierla' });
      if (g.p === 0.5) el.classList.add('mid');
      el.addEventListener('pointerdown', (e) => {
        e.preventDefault(); e.stopPropagation(); capPtr(el, e.pointerId); begin();
        const r = screen.getBoundingClientRect();
        let out = false;
        guideDrag = true; el.classList.add('drag');
        const mv = (ev) => {
          const q = g.o === 'v' ? (ev.clientX - r.left) / r.width : (ev.clientY - r.top) / r.height;
          out = q < -0.03 || q > 1.03;
          g.p = +Math.max(0, Math.min(1, q)).toFixed(4);
          // la guida va dove vuoi, ma vicino al centro la calamita la rimette esatta al centro
          const snapped = !ev.altKey && Math.abs(g.p - 0.5) < 10 / (g.o === 'v' ? r.width : r.height);
          if (snapped) g.p = 0.5;
          el.classList.toggle('mid', snapped);
          el.style[g.o === 'v' ? 'left' : 'top'] = g.p * 100 + '%';
          el.classList.toggle('out', out);
        };
        const up = () => {
          el.removeEventListener('pointermove', mv);
          guideDrag = false;
          if (out) { const L = guidesOf(); L.splice(L.indexOf(g), 1); }
          dirty = true; scheduleSave(); drawGuides(true);
        };
        el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up, { once: true });
      });
      guideLayer.append(el);
    });
  }
  // zone che le app coprono con pulsanti e scritte (video 9:16). [x, y, larghezza, altezza] da 0 a 1
  // come appare l'app sopra il video (TikTok, Reels, Shorts): sagoma bianca leggera, solo da guardare.
  // Disegnata su 1080x1920: pulsanti a destra, nome e didascalia in basso, intestazione in alto
  const heart = (x, y, r) => `<path d="M${x} ${y + r * 0.9} C${x - r * 1.6} ${y - r * 0.1} ${x - r * 0.9} ${y - r * 1.2} ${x} ${y - r * 0.45} C${x + r * 0.9} ${y - r * 1.2} ${x + r * 1.6} ${y - r * 0.1} ${x} ${y + r * 0.9}Z"/>`;
  const bubble = (x, y, r) => `<path d="M${x - r} ${y - r * 0.7} h${r * 2} a${r * 0.3} ${r * 0.3} 0 0 1 ${r * 0.3} ${r * 0.3} v${r * 0.9} a${r * 0.3} ${r * 0.3} 0 0 1 -${r * 0.3} ${r * 0.3} h-${r * 1.1} l-${r * 0.6} ${r * 0.55} v-${r * 0.55} h-${r * 0.3} a${r * 0.3} ${r * 0.3} 0 0 1 -${r * 0.3} -${r * 0.3} v-${r * 0.9} a${r * 0.3} ${r * 0.3} 0 0 1 ${r * 0.3} -${r * 0.3}Z"/>`;
  const arrow = (x, y, r) => `<path d="M${x + r} ${y} L${x} ${y - r * 0.8} V${y - r * 0.35} C${x - r * 0.9} ${y - r * 0.35} ${x - r * 1.1} ${y + r * 0.3} ${x - r} ${y + r * 0.8} C${x - r * 0.6} ${y + r * 0.2} ${x - r * 0.2} ${y + r * 0.1} ${x} ${y + r * 0.1} V${y + r * 0.8}Z"/>`;
  const count = (x, y) => `<rect x="${x - 34}" y="${y}" width="68" height="18" rx="9"/>`;
  const bar = (x, y, w, hh = 26) => `<rect x="${x}" y="${y}" width="${w}" height="${hh}" rx="${hh / 2}"/>`;
  const txt = (x, y, t, size = 40, anchor = 'middle', w = 600) => `<text x="${x}" y="${y}" font-size="${size}" font-weight="${w}" text-anchor="${anchor}" font-family="Arial, sans-serif">${t}</text>`;
  const SAFE_ZONES = {
    tiktok: { name: 'TikTok', svg: [
      txt(470, 138, 'Seguiti', 38, 'end', 500), txt(610, 138, 'Per te', 40, 'start', 700), bar(612, 158, 90, 6),
      `<circle cx="990" cy="126" r="26" fill="none" stroke="#fff" stroke-width="7"/>`,
      `<circle cx="985" cy="880" r="54"/>`, `<circle cx="985" cy="940" r="17"/>`,
      heart(985, 1060, 44), count(985, 1112), bubble(985, 1240, 42), count(985, 1286), `<rect x="955" y="1370" width="60" height="70" rx="8"/>`, count(985, 1456),
      arrow(985, 1560, 44), count(985, 1606), `<circle cx="985" cy="1735" r="46"/>`,
      bar(40, 1590, 280, 34), bar(40, 1648, 720), bar(40, 1692, 560), bar(40, 1756, 420, 22)] },
    reels: { name: 'Instagram Reels', svg: [
      txt(48, 140, 'Reels', 48, 'start', 700), `<rect x="964" y="100" width="68" height="54" rx="12" fill="none" stroke="#fff" stroke-width="7"/>`,
      heart(990, 1180, 44), count(990, 1232), bubble(990, 1350, 42), count(990, 1396), arrow(990, 1500, 42), count(990, 1546),
      `<circle cx="990" cy="1640" r="8"/><circle cx="990" cy="1665" r="8"/><circle cx="990" cy="1690" r="8"/>`, `<rect x="954" y="1740" width="72" height="72" rx="14"/>`,
      `<circle cx="78" cy="1622" r="38"/>`, bar(130, 1606, 240, 32), `<rect x="390" y="1600" width="120" height="44" rx="12" fill="none" stroke="#fff" stroke-width="5"/>`,
      bar(40, 1686, 740), bar(40, 1734, 480), bar(40, 1790, 380, 22)] },
    shorts: { name: 'YouTube Shorts', svg: [
      `<circle cx="880" cy="120" r="26" fill="none" stroke="#fff" stroke-width="7"/>`, `<circle cx="1000" cy="98" r="7"/><circle cx="1000" cy="122" r="7"/><circle cx="1000" cy="146" r="7"/>`,
      `<path d="M955 1070 h26 v-40 l24 -40 c14 0 20 10 18 22 l-6 18 h38 c14 0 22 12 18 24 l-18 50 c-4 10 -12 16 -22 16 h-78z"/>`, count(985, 1102),
      `<path transform="translate(0 200) rotate(180 992 1030)" d="M955 1070 h26 v-40 l24 -40 c14 0 20 10 18 22 l-6 18 h38 c14 0 22 12 18 24 l-18 50 c-4 10 -12 16 -22 16 h-78z"/>`, count(985, 1330),
      bubble(985, 1420, 42), count(985, 1466), arrow(985, 1560, 42), count(985, 1606), `<circle cx="985" cy="1695" r="38" fill="none" stroke="#fff" stroke-width="7"/>`, `<rect x="950" y="1765" width="70" height="70" rx="12"/>`,
      `<circle cx="74" cy="1640" r="34"/>`, bar(124, 1624, 230, 32), `<rect x="380" y="1614" width="190" height="52" rx="26"/>`,
      bar(40, 1706, 760), bar(40, 1754, 520)] },
  };
  const isVertOut = () => VERT || H > W;
  function setGuideOpt(k, v) { proj.guides[k] = v; dirty = true; scheduleSave(); guidesOn = true; drawGuides(true); }
  function addGuide(o) { begin(); guidesOf().push({ o, p: 0.5 }); guidesOn = true; dirty = true; scheduleSave(); drawGuides(true); toast('Guida aggiunta al centro: trascinala dove ti serve'); }
  const layoutBtn = ibtn('layoutV', 'Layout per video verticali: anteprima alta a destra', () => setLayout(!vLayout), { size: 16 });
  const guideBtn = ibtn('guides', 'Guide e calamite dell\'anteprima', (e) => popMenu(e.currentTarget, [
    ['guides', 'Aggiungi una guida verticale', 'Una linea dall\'alto in basso', () => addGuide('v')],
    ['guides', 'Aggiungi una guida orizzontale', 'Una linea da sinistra a destra', () => addGuide('h')],
    [guidesOn ? 'eyeOff' : 'eye', guidesOn ? 'Nascondi le guide' : 'Mostra le guide', null, () => { guidesOn = !guidesOn; drawGuides(true); }],
    ['trash', 'Togli tutte le guide', null, () => { begin(); proj.guides[fmtKey()] = []; dirty = true; scheduleSave(); drawGuides(true); }],
    ['guides', proj.guides.grid ? 'Griglia: accesa' : 'Griglia: spenta', 'Le linee dei terzi, per comporre l\'inquadratura', () => setGuideOpt('grid', !proj.guides.grid)],
    ...(isVertOut() ? [['phone', 'Zone coperte dalle app', proj.guides.safe && SAFE_ZONES[proj.guides.safe] ? 'Ora: ' + SAFE_ZONES[proj.guides.safe].name : 'Dove finiscono pulsanti e didascalia', [
      ...Object.entries(SAFE_ZONES).map(([k, z]) => [proj.guides.safe === k ? 'check' : 'phone', z.name, 'Come appare l\'app sopra il tuo video: tieni testi e grafiche fuori dai pulsanti e dalla didascalia', () => setGuideOpt('safe', k)]),
      ['eyeOff', 'Nessuna', null, () => setGuideOpt('safe', null)]]]] : []),
    ['magnet', snapObj ? 'Calamite: accese' : 'Calamite: spente', 'Gli oggetti si agganciano al centro, ai bordi e alle guide (Alt per staccarli)', () => { snapObj = !snapObj; store.set('snapObj', snapObj); toast(snapObj ? 'Calamite accese' : 'Calamite spente'); }],
  ]), { size: 18 });
  // calamite: r = [x, y, w, h] (0..1 dello schermo) -> spostamento per agganciarsi a centro, bordi e guide
  // calamite: bordi e centro dell'anteprima, guide e gli altri elementi visibili. Una volta agganciato resta
  // agganciato finche' non ti allontani un po' di piu' (niente aggancia/sgancia continuo)
  const snapMem = { x: null, y: null };
  function snapRect(r, off, selfId) {
    snapV.style.display = snapH.style.display = 'none';
    if (!snapObj || off) { snapMem.x = snapMem.y = null; return [0, 0]; }
    const sw = screen.clientWidth || 1, sh = screen.clientHeight || 1, tx = 8 / sw, ty = 8 / sh;
    const gs = guidesOn ? guidesOf() : [];
    const xs = [0, 0.5, 1, ...gs.filter((g) => g.o === 'v').map((g) => g.p)], ys = [0, 0.5, 1, ...gs.filter((g) => g.o === 'h').map((g) => g.p)];
    const tc = video.currentTime;
    for (const t of clipTracks()) {
      if (t.hidden) continue;
      for (const c of t.clips || []) {
        if (c.id === selfId || (c.kind !== 'image' && c.kind !== 'video') || tc < c.a || tc >= c.a + (c.dur || 0)) continue;
        const s0 = imgStateAt(c, tc - c.a), hh = s0.w * CA() * (c.ar || 9 / 16);
        xs.push(s0.x, s0.x + s0.w / 2, s0.x + s0.w); ys.push(s0.y, s0.y + hh / 2, s0.y + hh);
      }
    }
    const best = (vals, pts, th) => { let b = null; for (const v of vals) for (const q of pts) { const d = v - q; if (Math.abs(d) < th && (!b || Math.abs(d) < Math.abs(b.d))) b = { d, v }; } return b; };
    const pick = (vals, pts, th, k) => {
      const m = snapMem[k];
      if (m) { const keep = best([m.v], pts, th * 1.8); if (keep) return keep; }
      return (snapMem[k] = best(vals, pts, th));
    };
    const bx = pick(xs, [r[0], r[0] + r[2] / 2, r[0] + r[2]], tx, 'x'), by = pick(ys, [r[1], r[1] + r[3] / 2, r[1] + r[3]], ty, 'y');
    if (bx) { snapV.style.display = 'block'; snapV.style.left = bx.v * 100 + '%'; }
    if (by) { snapH.style.display = 'block'; snapH.style.top = by.v * 100 + '%'; }
    return [bx ? bx.d : 0, by ? by.d : 0];
  }
  const hideSnap = () => { snapV.style.display = snapH.style.display = 'none'; snapMem.x = snapMem.y = null; };

  // clip spostata/ingrandita a mano: orizzontale c.tf = {s, x, y}; verticale c.vlay.boxes[pezzo] = [x, y, w]
  const segAtT = (t) => proj.segs.find((c) => !c.gone && t >= c.a && t < c.b);
  const tfOf = (c) => ({ s: 1, x: 0, y: 0, ...((c && c.tf) || {}) });
  let tfKey = '';
  let zoomNow = null;   // zoom della webcam in corso (trasformazione di .zg)
  function applyTf(t) {
    const tf = VERT ? { s: 1, x: 0, y: 0 } : tfOf(segAtT(t));
    const sw = screen.clientWidth, sh = screen.clientHeight;
    const bx = ((1 - tf.s) / 2 + tf.x) * sw, by = ((1 - tf.s) / 2 + tf.y) * sh;   // dove sta la clip (angolo in alto a sinistra)
    let ox = bx, oy = by, clip = '';
    // con lo zoom: prima si ingrandisce la webcam, poi la clip va al suo posto (come nel video esportato).
    // .zg e' gia' ingrandito, quindi qui si compensa (Z^-1 · T · Z) e si ritaglia al riquadro della clip
    if (zoomNow && !VERT && (tf.s !== 1 || tf.x || tf.y)) {
      const S = zoomNow.s, tx = zoomNow.tx, ty = zoomNow.ty;
      ox = ((tf.s - 1) * tx + bx) / S; oy = ((tf.s - 1) * ty + by) / S;
      const lx0 = ((bx - tx) / S - ox) / tf.s, lx1 = ((bx + tf.s * sw - tx) / S - ox) / tf.s;
      const ly0 = ((by - ty) / S - oy) / tf.s, ly1 = ((by + tf.s * sh - ty) / S - oy) / tf.s;
      clip = `inset(${ly0.toFixed(1)}px ${(sw - lx1).toFixed(1)}px ${(sh - ly1).toFixed(1)}px ${lx0.toFixed(1)}px)`;
    }
    const tr = tf.s === 1 && !tf.x && !tf.y ? '' : `translate(${ox.toFixed(2)}px, ${oy.toFixed(2)}px) scale(${tf.s})`;
    if (tr + clip === tfKey) return;
    tfKey = tr + clip;
    for (const el of [liveVid, video.twinEl, video.montEl, ...video.insEls, fxCanvas]) if (el) { el.style.transform = tr; el.style.clipPath = clip; }
  }
  const tfPool = [];
  let tfDrag = null, tfActive = null;   // nel verticale si lavora su un pezzo alla volta (webcam o gioco)
  // il riquadro disegnato resta dentro lo schermo: gli angoli si possono sempre prendere anche se il pezzo esce
  const clipR = (r) => { const x0 = Math.max(0, r[0]), y0 = Math.max(0, r[1]), x1 = Math.min(1, r[0] + r[2]), y1 = Math.min(1, r[1] + r[3]); return [x0, y0, Math.max(0.02, x1 - x0), Math.max(0.02, y1 - y0)]; };
  function placeBox(b, r) {
    const q = clipR(r);
    Object.assign(b.style, { left: q[0] * 100 + '%', top: q[1] * 100 + '%', width: q[2] * 100 + '%', height: q[3] * 100 + '%' });
    b.classList.toggle('cut', q[0] !== r[0] || q[1] !== r[1] || Math.abs(q[2] - r[2]) > 1e-6 || Math.abs(q[3] - r[3]) > 1e-6);
    b.classList.toggle('edge', q[0] < 0.005 || q[1] < 0.005 || q[0] + q[2] > 0.995 || q[1] + q[3] > 0.995);
  }
  // la clip selezionata, se la testina e' dentro (si modifica quella che vedi)
  function editTarget() {
    if (!sel || !isSeg(sel.type) || framing || sourceView()) return null;
    const c = findSel(), t = video.currentTime;
    if (!c || c.gone || c.removed || (BLANK && !c.ins) || !(t >= c.a - 1e-3 && t < c.b)) return null;
    return c;
  }
  // parte del quadro occupata davvero dalla clip (una foto quadrata in un video 9:16 non e' tutto il quadro):
  // il riquadro per spostarla/ingrandirla e' quello, non tutto lo schermo
  function contentFrac(c) {
    const rec = c && c.ins ? insById(c.ins) : null;
    const ar = rec ? (rec.image ? rec.iar : (rec.w && rec.h ? rec.w / rec.h : 0)) : 0;
    if (!ar || !W || !H) return [1, 1];
    const A = W / H;
    return Math.abs(ar - A) < 0.01 ? [1, 1] : ar > A ? [1, A / ar] : [ar / A, 1];
  }
  function segBox(c) {
    const tf = tfOf(c), [fw, fh] = contentFrac(c);
    return [(1 - fw * tf.s) / 2 + tf.x, (1 - fh * tf.s) / 2 + tf.y, fw * tf.s, fh * tf.s];
  }
  function tfBoxes(t) {
    const c = editTarget(); if (!c) return [];
    if (!VERT) return [{ key: 'tf', r: segBox(c) }];
    if (!video.isLive(video.el)) return [];
    if (proj.zooms.some((z) => z.on !== false && t >= z.a && t < z.b && zoomProgress(t, vertZoom(z)) > 0.001)) return [];   // durante lo zoom si muovono da soli
    const vs = segVert(t, c);
    return vertRegions(vs.layout, W, H, { cam, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, boxes: vs.boxes })
      .filter((r) => !r.blur && r.role).map((r) => ({ key: r.role, r: r.d }));
  }
  const TF_NAME = { tf: '', cam: 'Webcam', game: 'Gioco', main: 'Video' };
  function updateTfUI(t) {
    if (tfDrag) return;
    const list = tfBoxes(t);
    while (tfPool.length < list.length) {
      const b = h('div', { class: 'tfbox' }, h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
        h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }), h('span', { class: 'tflbl' }));
      b.addEventListener('pointerdown', (e) => startTfDrag(e, b, b.dataset.key, e.target.dataset.h || 'move'));
      tfLayer.append(b); tfPool.push(b);
    }
    if (tfActive && !list.some((x) => x.key === tfActive)) tfActive = null;
    if (list.length === 1) tfActive = list[0].key;
    tfPool.forEach((b, i) => {
      const it = list[i];
      if (!it) { b.style.display = 'none'; return; }
      b.dataset.key = it.key; b.style.display = '';
      placeBox(b, it.r);
      b.classList.toggle('idle', it.key !== tfActive);
      b.lastChild.textContent = TF_NAME[it.key] || '';
    });
  }
  function setBox(c, key, r) {
    if (key === 'tf') { const [fw, fh] = contentFrac(c), s2 = Math.max(0.05, Math.min(30, r[2] / fw)); c.tf = { s: +s2.toFixed(4), x: +(r[0] - (1 - fw * s2) / 2).toFixed(4), y: +(r[1] - (1 - fh * s2) / 2).toFixed(4) }; if (Math.abs(c.tf.s - 1) < 1e-3 && Math.abs(c.tf.x) < 1e-3 && Math.abs(c.tf.y) < 1e-3) delete c.tf; return; }
    const vs = segVert(0, c);
    const boxes = { ...(vs.boxes || {}), [key]: [+r[0].toFixed(4), +r[1].toFixed(4), +r[2].toFixed(4)] };
    c.vlay = { layout: vs.layout, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, ...(c.vlay || {}), boxes };
  }
  function startTfDrag(e, el, key, mode) {
    if (e.button !== 0) return;
    // sopra c'e' un'immagine o un testo: si prende quello
    if (mode === 'move') {
      const under = document.elementsFromPoint(e.clientX, e.clientY).find((x) => x.classList && x.classList.contains('ovimg'));
      if (under && under.dataset.cid) { e.preventDefault(); e.stopPropagation(); select({ type: 'sclip', id: under.dataset.cid }); startOvDrag(e, 'move', under); return; }
    }
    e.preventDefault(); e.stopPropagation();
    const c = editTarget(); if (!c) return;
    const box = tfBoxes(video.currentTime).find((b) => b.key === key); if (!box) return;
    if (tfActive !== key) { tfActive = key; mode = 'move'; tfPool.forEach((b) => b.classList.toggle('idle', b.dataset.key !== key)); }
    capPtr(el, e.pointerId);
    begin();
    const sw = screen.clientWidth, sh = screen.clientHeight, r0 = box.r.slice();
    tfDrag = { x: e.clientX, y: e.clientY };
    const mv = (ev) => {
      const dx = (ev.clientX - tfDrag.x) / sw, dy = (ev.clientY - tfDrag.y) / sh;
      let r;
      if (mode === 'move') {
        r = [r0[0] + dx, r0[1] + dy, r0[2], r0[3]];
        const [sx2, sy2] = snapRect(r, ev.altKey); r[0] += sx2; r[1] += sy2;
      } else {
        // angolo: si ingrandisce tenendo fermo l'angolo opposto, stessa forma
        const ax = mode.includes('w') ? r0[0] + r0[2] : r0[0], ay = mode.includes('n') ? r0[1] + r0[3] : r0[1];
        const k = Math.max(0.08, (mode.includes('w') ? r0[2] - dx : r0[2] + dx) / r0[2]);
        const nw = r0[2] * k, nh = r0[3] * k;
        r = [mode.includes('w') ? ax - nw : ax, mode.includes('n') ? ay - nh : ay, nw, nh];
      }
      setBox(c, key, r);
      placeBox(el, r);
      frame(true);
    };
    const up = () => { el.removeEventListener('pointermove', mv); tfDrag = null; hideSnap(); changed(); frame(true); };
    el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up, { once: true });
  }
  // rotellina sull'anteprima: ingrandisce la clip selezionata (o il pezzo sotto il mouse)
  let wheelT = 0;
  // zoom dell'anteprima solo per guardare (pizzico sul trackpad o Ctrl + rotella con niente selezionato): il video non cambia
  let vz = { s: 1, x: 0, y: 0 }, vzT = 0, vzRaf = 0;
  const vzBadge = h('button', { class: 'vzbadge', type: 'button', style: { display: 'none' }, 'data-tip': 'Zoom dell\'anteprima (solo per guardare) · clic per tornare al 100%', onclick: () => { vzTween = null; setViewZoom(1); } });
  function setViewZoom(s2, cx = 0.5, cy = 0.5) {
    const s0 = vz.s, ns = Math.max(1, Math.min(8, s2));
    // il punto sotto il mouse resta fermo
    const px = (cx - 0.5) * (1 - ns / s0), py = (cy - 0.5) * (1 - ns / s0);
    vz = ns <= 1.001 ? { s: 1, x: 0, y: 0 } : { s: ns, x: vz.x * ns / s0 + px * ns, y: vz.y * ns / s0 + py * ns };
    const lim = (ns - 1) / 2;
    vz.x = Math.max(-lim, Math.min(lim, vz.x)); vz.y = Math.max(-lim, Math.min(lim, vz.y));
    // si disegna una volta per fotogramma (il trackpad manda molti eventi): niente scatti
    if (!vzRaf) vzRaf = requestAnimationFrame(() => {
      vzRaf = 0;
      screen.style.transform = vz.s === 1 ? '' : `translate3d(${(vz.x * 100).toFixed(3)}%, ${(vz.y * 100).toFixed(3)}%, 0) scale(${vz.s.toFixed(4)})`;
    });
    screenWrap.classList.toggle('vzoomed', vz.s > 1);
    vzBadge.style.display = vz.s > 1 ? '' : 'none';
    vzBadge.textContent = tx('Vista') + ' ' + Math.round(vz.s * 100) + '% · ✕';
  }
  // rotella del mouse: lo scatto diventa un piccolo movimento morbido
  let vzTween = null;
  function tweenVz(to, cx, cy) {
    to = Math.max(1, Math.min(8, to));
    const from = vz.s, t0 = performance.now(), my = vzTween = { to };
    const step = (now) => {
      if (vzTween !== my) return;
      const k = Math.min(1, (now - t0) / 140), e2 = 1 - Math.pow(1 - k, 3);
      setViewZoom(from + (to - from) * e2, cx, cy);
      if (k < 1) requestAnimationFrame(step); else vzTween = null;
    };
    requestAnimationFrame(step);
  }
  const noEditSel = () => !editTarget() && !(sel && ['sclip', 'zoom'].includes(sel.type));
  function onScreenWheel(e) {
    // Ctrl/Cmd + rotella e pizzico: sempre e solo lo zoom della vista (mai la clip). La clip si ingrandisce con le maniglie
    if (e.ctrlKey || e.metaKey || (vz.s > 1 && noEditSel())) {
      e.preventDefault();
      if (vzG && (e.ctrlKey || e.metaKey)) return;   // Mac: il pizzico arriva gia' come gesto, non contarlo due volte
      const r = screenWrap.getBoundingClientRect(), sr = screen.getBoundingClientRect();
      // rotella del mouse: scatti del 20%; trackpad (pizzico): segue le dita
      const cx = (e.clientX - sr.left) / sr.width, cy = (e.clientY - sr.top) / sr.height;
      if ((e.ctrlKey || e.metaKey) && Math.abs(e.deltaY) >= 40) tweenVz((vzTween ? vzTween.to : vz.s) * (e.deltaY < 0 ? 1.25 : 1 / 1.25), cx, cy);
      else if (e.ctrlKey || e.metaKey) { vzTween = null; setViewZoom(vz.s * Math.exp(-e.deltaY * 0.01), cx, cy); }
      else { vz.x -= e.deltaX / r.width; vz.y -= e.deltaY / r.height; setViewZoom(vz.s); }   // due dita: ci si sposta
      return;
    }
    const c = editTarget(); if (!c) return;
    const r = screen.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    const boxes = tfBoxes(video.currentTime);
    const hit = boxes.find((b) => b.key === tfActive) || boxes.slice().reverse().find((b) => px >= b.r[0] && px <= b.r[0] + b.r[2] && py >= b.r[1] && py <= b.r[1] + b.r[3]) || (boxes.length === 1 ? boxes[0] : null);
    if (!hit) return;
    e.preventDefault();
    if (Date.now() - wheelT > 700) begin();
    wheelT = Date.now();
    const k = e.deltaY < 0 ? 1.05 : 1 / 1.05, b = hit.r, cx = b[0] + b[2] / 2, cy = b[1] + b[3] / 2;
    setBox(c, hit.key, [cx - b[2] * k / 2, cy - b[3] * k / 2, b[2] * k, b[3] * k]);
    dirty = true; scheduleSave(); frame(true);
    clearTimeout(onScreenWheel.tm); onScreenWheel.tm = setTimeout(() => { renderTimeline(); renderPanel(); }, 400);
  }
  // clic sul video nell'anteprima: seleziona la clip che si vede e si puo' trascinare subito
  function onScreenDown(e) {
    if (e.button !== 0 || framing || sourceView()) return;
    if (e.target.closest('.tfbox, .ovimg, .framebox, .guide, .badges, button, .maskbox, .paintlayer, .framedonebar')) return;
    const t = video.currentTime, c = segAtT(t);
    if (!c || c.removed || (BLANK && !c.ins)) return;   // progetto vuoto: il nero di base e' lo sfondo, non una clip
    if (!VERT) {   // clic sul nero intorno alla foto/al video: non e' la clip
      const r0 = screen.getBoundingClientRect(), qx = (e.clientX - r0.left) / r0.width, qy = (e.clientY - r0.top) / r0.height, b0 = segBox(c);
      if (qx < b0[0] || qx > b0[0] + b0[2] || qy < b0[1] || qy > b0[1] + b0[3]) return;
    }
    if (!(sel && sel.type === 'seg' && sel.id === c.id)) { sel = { type: 'seg', id: c.id }; multi = []; tab = 'video'; renderTimeline(); renderPanel(); }
    updateTfUI(t);
    const r = screen.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    const boxes = tfBoxes(t);
    const hit = boxes.slice().reverse().find((b) => px >= b.r[0] && px <= b.r[0] + b.r[2] && py >= b.r[1] && py <= b.r[1] + b.r[3]);
    if (!hit) { if (tfActive && boxes.length > 1) { tfActive = null; updateTfUI(t); } return; }
    const el = tfPool.find((b) => b.dataset.key === hit.key && b.style.display !== 'none');
    if (el) startTfDrag(e, el, hit.key, 'move');
  }
  screen.append(tfLayer, guideLayer, snapV, snapH);
  // contagocce del green screen: il clic sull'anteprima sceglie il colore (e non seleziona/sposta niente)
  screen.addEventListener('pointerdown', (e) => { if (!keyPick) return; e.stopPropagation(); e.preventDefault(); keyPickAt(e); }, true);
  screen.addEventListener('pointerdown', onScreenDown);
  screen.addEventListener('wheel', onScreenWheel, { passive: false });
  let vzG = 0;
  screen.addEventListener('gesturestart', (e) => { e.preventDefault(); vzG = vz.s; });
  screen.addEventListener('gesturechange', (e) => {
    if (!vzG) return; e.preventDefault();
    const sr = screen.getBoundingClientRect();
    setViewZoom(vzG * e.scale, (e.clientX - sr.left) / sr.width, (e.clientY - sr.top) / sr.height);
  });
  screen.addEventListener('gestureend', () => { vzG = 0; });
  // ---------- maschera dei filtri: rettangolo/ellisse da trascinare o pennello a pixel
  let fxSub = 'filter', fxDirty = false, fxKey = '';
  let brushMode = 'paint', brushR = 0.04;
  const selFx = () => (sel && sel.type === 'fx' ? proj.filters.find((f) => f.id === sel.id) : null);
  const zgPt = (e) => { const r = (maskBox.parentNode || zg).getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; };
  let mvKey = '';
  function updateMaskUI() {
    const f = selFx();
    const m = f && f.mask;
    const editing = m && tab === 'video' && fxSub === 'mask' && m.type && m.type !== 'all' && video.currentTime >= f.a - 0.01 && video.currentTime < f.b;
    if (!editing) {
      if (maskView.style.display !== 'none' || paintLayer.style.display !== 'none' || maskBox.style.display !== 'none') { maskView.style.display = maskBox.style.display = paintLayer.style.display = brushCur.style.display = 'none'; }
      mvKey = ''; return;
    }
    const key = JSON.stringify(m) + '|' + zg.clientWidth;
    if (key !== mvKey) {
      mvKey = key;
      const cw = Math.max(2, Math.min(960, zg.clientWidth)), ch = Math.max(2, Math.round(cw * H / W));
      const mc = drawMask(m, cw, ch, W, H);
      maskView.width = cw; maskView.height = ch;
      const g = maskView.getContext('2d');
      g.clearRect(0, 0, cw, ch); g.fillStyle = 'rgba(255,69,58,0.4)'; g.fillRect(0, 0, cw, ch);
      g.globalCompositeOperation = 'destination-in'; g.drawImage(mc, 0, 0); g.globalCompositeOperation = 'source-over';
    }
    maskView.style.display = 'block';
    if (m.type === 'rect' || m.type === 'ellipse') {
      Object.assign(maskBox.style, { display: 'block', left: m.x * 100 + '%', top: m.y * 100 + '%', width: m.w * 100 + '%', height: m.h * 100 + '%', borderRadius: m.type === 'ellipse' ? '50%' : '2px' });
      paintLayer.style.display = 'none'; brushCur.style.display = 'none';
    } else { maskBox.style.display = 'none'; paintLayer.style.display = 'block'; }
  }
  maskBox.addEventListener('pointerdown', (ev) => {
    const f = selFx(); if (!f) return;
    ev.preventDefault(); ev.stopPropagation(); capPtr(maskBox, ev.pointerId);
    begin();
    const mode = ev.target.dataset.h || 'move', p0 = zgPt(ev), m0 = { ...f.mask };
    const mv = (e) => {
      const [px, py] = zgPt(e), dx = px - p0[0], dy = py - p0[1], m = f.mask;
      if (mode === 'move') { m.x = +(m0.x + dx).toFixed(4); m.y = +(m0.y + dy).toFixed(4); }
      else {
        let { x, y, w, h: hh } = m0;
        if (mode.includes('w')) { const nw = Math.max(0.02, w - dx); x += w - nw; w = nw; } else w = Math.max(0.02, w + dx);
        if (mode.includes('n')) { const nh = Math.max(0.02, hh - dy); y += hh - nh; hh = nh; } else hh = Math.max(0.02, hh + dy);
        Object.assign(m, { x: +x.toFixed(4), y: +y.toFixed(4), w: +w.toFixed(4), h: +hh.toFixed(4) });
      }
      fxDirty = true;
    };
    const up = () => { maskBox.removeEventListener('pointermove', mv); changed({ keepPanel: true }); };
    maskBox.addEventListener('pointermove', mv);
    maskBox.addEventListener('pointerup', up, { once: true });
  });
  paintLayer.addEventListener('pointermove', (e) => {
    const [px, py] = zgPt(e);
    Object.assign(brushCur.style, { display: 'block', left: (px - brushR) * 100 + '%', top: `calc(${py * 100}% - ${brushR * zg.clientWidth}px)`, width: brushR * 200 + '%', height: brushR * 2 * zg.clientWidth + 'px' });
    brushCur.classList.toggle('erase', brushMode === 'erase');
  });
  paintLayer.addEventListener('pointerleave', () => { brushCur.style.display = 'none'; });
  paintLayer.addEventListener('pointerdown', (ev) => {
    const f = selFx(); if (!f) return;
    ev.preventDefault(); ev.stopPropagation(); capPtr(paintLayer, ev.pointerId);
    begin();
    const st = { pts: [zgPt(ev).map((v) => +v.toFixed(4))], r: brushR, erase: brushMode === 'erase' };
    f.mask.strokes = f.mask.strokes || [];
    f.mask.strokes.push(st);
    fxDirty = true;
    const mv = (e) => {
      const p = zgPt(e).map((v) => +v.toFixed(4)), l = st.pts[st.pts.length - 1];
      if (Math.hypot(p[0] - l[0], (p[1] - l[1]) * H / W) > brushR * 0.3) { st.pts.push(p); fxDirty = true; }
    };
    const up = () => { paintLayer.removeEventListener('pointermove', mv); changed({ keepPanel: true }); };
    paintLayer.addEventListener('pointermove', mv);
    paintLayer.addEventListener('pointerup', up, { once: true });
  });
  ovBox.addEventListener('pointerdown', (ev) => {
    ev.preventDefault(); ev.stopPropagation();
    const c = findSel(); const img = c && ovImgs.get(c.id); if (!img) return;
    startOvDrag(ev, ev.target.dataset.h || 'move', img);
  });
  // trascina / ridimensiona l'inquadratura (sempre nel formato del video: 16:9 o, in verticale, 9:16)
  // in verticale ogni zoom (anche quello sulla webcam) ha la sua inquadratura finale: z.vrect
  // forma dell'inquadratura verticale: 9:16, un po' piu' larga se ci sono le barre nere
  const VA = (pad) => 9 / 16 / (1 - 2 * (pad || 0));
  const zA = (z) => VA(segVert(z.a + 0.01).pad);
  const vBoxOf = (z) => {
    const a = zA(z);
    if (z.vrect) return vertRect(W, H, z.vrect, a);
    const bx = vertZoomBoxes(z, W, H, cam, a);
    if (!bx) return null;
    const c = coverRect(bx.from, a);
    return vertRect(W, H, c, a);
  };
  // keyframe dell'inquadratura dello zoom (lo zoom si sposta mentre e' attivo)
  const zKfKey = () => (VERT ? 'vrect' : 'rect');
  const zTr = (z) => Math.max(0, Math.min(z.b - z.a, video.currentTime - z.a));
  const zKfs = (z) => (z.kf || []).filter((k) => Array.isArray(k[zKfKey()]));
  const zKfOn = (z) => zKfs(z).find((k) => Math.abs(k.t - zTr(z)) < KF_EPS);
  // inquadratura di adesso (con i keyframe, quella alla testina): [x, y, w, h]
  const zRectNow = (z) => { const zz = zoomAt(z, video.currentTime); return VERT ? vBoxOf(zz) : zz.rect ? customRect(W, H, zz.rect) : null; };
  // cambia l'inquadratura: senza keyframe vale per tutto lo zoom, con i keyframe crea/aggiorna quello alla testina
  function setZoomRect(z, val) {
    const key = zKfKey();
    if (!zKfs(z).length) { z[key] = val; return; }
    let k = zKfOn(z);
    if (!k) { k = { t: +zTr(z).toFixed(3), ease: 'smooth' }; z.kf.push(k); z.kf.sort((a, b) => a.t - b.t); }
    k[key] = val;
  }
  function toggleZoomKf(z) {
    const key = zKfKey(), on = zKfOn(z);
    begin();
    if (on) {
      z.kf = z.kf.filter((x) => x !== on);
      if (!zKfs(z).length) z[key] = on[key];   // tolto l'ultimo: resta quell'inquadratura per tutto lo zoom
      if (!z.kf.length) delete z.kf;
    } else {
      const r = zRectNow(z); if (!r) return;
      const v = r.slice(0, 3).map(Math.round), tr = +zTr(z).toFixed(3);
      z.kf = z.kf || [];
      if (!zKfs(z).length && tr > KF_EPS) z.kf.push({ t: 0, ease: 'smooth', [key]: v.slice() });
      z.kf.push({ t: tr, ease: 'smooth', [key]: v });
      z.kf.sort((a, b) => a.t - b.t);
    }
    changed(); frame(true);
  }
  function jumpZoomKf(z, dir) {
    const ts = zKfs(z).map((k) => k.t), cur = zTr(z);
    const nx = dir > 0 ? ts.find((t) => t > cur + KF_EPS) : ts.slice().reverse().find((t) => t < cur - KF_EPS);
    if (nx != null) { seek(z.a + nx + 0.001); renderPanel(); }
  }
  // riga dei keyframe dell'inquadratura (come per le immagini): rombo alla testina, precedente/successivo, striscia
  function zoomKfRow(z) {
    const len = Math.max(0.01, z.b - z.a), on = zKfOn(z);
    const strip = h('div', { class: 'kfs-track', 'data-tip': 'Clic per spostarti nello zoom' });
    for (const k of zKfs(z)) {
      const d = h('i', { class: 'kfs-d' + (k === on ? ' on' : ''), style: { left: (k.t / len * 100) + '%' } });
      d.addEventListener('pointerdown', (e) => { e.stopPropagation(); seek(z.a + k.t + 0.001); renderPanel(); });
      strip.append(d);
    }
    const ph = h('i', { class: 'kfs-ph' });
    strip.append(ph);
    strip.addEventListener('pointerdown', (e) => { const r = strip.getBoundingClientRect(); seek(z.a + Math.max(0, Math.min(len - 0.01, (e.clientX - r.left) / r.width * len))); renderPanel(); });
    liveCtls.push(() => { ph.style.left = (zTr(z) / len * 100) + '%'; });
    liveCtls.push(() => { if (!!zKfOn(z) !== !!on && !document.activeElement?.matches?.('input')) renderPanel(); });
    const n = zKfs(z).length;
    return h('div', { class: 'kfbox', style: { marginTop: '10px' } },
      h('div', { class: 'kfrow' },
        ibtn('left', 'Keyframe precedente', () => jumpZoomKf(z, -1), { size: 13 }),
        h('button', { class: 'kfbtn' + (on ? ' on' : ''), 'data-tip': on ? 'Togli questo keyframe' : 'Aggiungi un keyframe qui: poi sposta l\'inquadratura in un altro punto e lo zoom la segue', 'aria-label': 'Keyframe', onclick: () => toggleZoomKf(z) }, icon('diamond', 13, 'currentColor', 2)),
        ibtn('chev', 'Keyframe successivo', () => jumpZoomKf(z, 1), { size: 13 }), strip),
      on && n > 1 ? h('div', { class: 'kfease' }, h('span', null, 'Verso il prossimo'),
        seg(['Lineare', 'Morbido'], on.ease === 'linear' ? 0 : 1, (i) => { begin(); on.ease = i ? 'smooth' : 'linear'; changed(); }, 'mini')) : null,
      n ? null : h('div', { class: 'kfhint', style: { margin: '6px 0 0' } }, 'Con i keyframe l\'inquadratura si sposta durante lo zoom: metti un rombo, vai avanti, sposta il riquadro.'));
  }
  let fdrag = null;
  frameBox.addEventListener('pointerdown', (ev) => {
    if (ev.target.closest('.framedone')) return;
    const z = findSel(); if (!z) return;
    const r = zRectNow(z);
    if (!r) return;
    ev.preventDefault(); capPtr(frameBox, ev.pointerId);
    begin();
    fdrag = { mode: ev.target.dataset.h || 'move', x: ev.clientX, y: ev.clientY, r, v: VERT };
  });
  frameBox.addEventListener('pointermove', (ev) => {
    if (!fdrag) return;
    const z = findSel(); if (!z) return;
    const k = W / screen.clientWidth;
    const dx = (ev.clientX - fdrag.x) * k, dy = (ev.clientY - fdrag.y) * k;
    let [x, y, w, hh] = fdrag.r;
    const za = fdrag.v ? zA(z) : 0;
    const ar = fdrag.v ? 1 / za : H / W;   // altezza / larghezza del riquadro
    if (fdrag.mode === 'move') { x += dx; y += dy; }
    else {
      const sgnx = fdrag.mode.includes('w') ? -1 : 1;
      const nw = fdrag.v ? Math.max(W / 16, Math.min(H * za, w + sgnx * dx)) : Math.max(W / 8, Math.min(W / 1.05, w + sgnx * dx));
      const nh = nw * ar;
      if (fdrag.mode.includes('w')) x += w - nw;
      if (fdrag.mode.includes('n')) y += hh - nh;
      w = nw; hh = nh;
    }
    setZoomRect(z, fdrag.v ? vertRect(W, H, [x, y, w], za).slice(0, 3).map(Math.round) : customRect(W, H, [x, y, w]).slice(0, 3).map(Math.round));
    frame(true);
  });
  frameBox.addEventListener('pointerup', () => {
    if (!fdrag) return;
    fdrag = null;
    changed(); frame(true);
  });
  const screenWrap = h('div', { class: 'screen-wrap' }, screen, vzBadge);
  const timeLbl = h('div', { class: 'time' }, '0:00');
  const playBtn = h('button', { class: 'playbtn', disabled: true, 'aria-label': 'Riproduci', 'data-tip': 'Riproduci / pausa', 'data-key': 'Spazio', onclick: () => togglePlay() }, icon('play', 13, '#0B0E13'));
  // velocita' di riproduzione dell'anteprima (solo per guardare: il video finale non cambia)
  const RATES = [0.5, 0.75, 1, 1.25, 1.5, 2, 4, 8, 16];
  let viewRate = 1;
  const rateBtn = h('button', { class: 'ratebtn', 'data-tip': 'Velocità dell\'anteprima, fino a 16× (solo per guardare, il video finale non cambia)', 'data-key': 'Maiusc + < >', 'aria-label': 'Velocità dell\'anteprima' }, '1×');
  function setViewRate(r) {
    viewRate = r; rateBtn.textContent = (r + '×').replace('.', ','); rateBtn.classList.toggle('on', r !== 1); applySpeed();
  }
  const stepRate = (d) => { const i = RATES.indexOf(viewRate); setViewRate(RATES[Math.max(0, Math.min(RATES.length - 1, i + d))]); };
  // menu delle velocita' dentro il lettore (cosi' si vede anche a schermo intero)
  const rateMenu = h('div', { class: 'ratemenu', style: { display: 'none' } });
  const rateWrap = h('div', { class: 'ratewrap' }, rateBtn, rateMenu);
  function openRateMenu() {
    rateMenu.replaceChildren(...RATES.slice().reverse().map((r) => h('button', { class: r === viewRate ? 'on' : '', onclick: (e) => { e.stopPropagation(); setViewRate(r); rateMenu.style.display = 'none'; } }, (r + '×').replace('.', ','))));
    rateMenu.style.display = '';
    const off = (e) => { if (!rateWrap.contains(e.target)) { rateMenu.style.display = 'none'; document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  }
  rateBtn.addEventListener('click', (e) => { e.stopPropagation(); if (rateMenu.style.display === 'none') openRateMenu(); else rateMenu.style.display = 'none'; });
  rateBtn.addEventListener('contextmenu', (e) => { e.preventDefault(); setViewRate(1); });
  const ccBtn = ibtn('cc', 'Sottotitoli nel video (mostra / nascondi)', () => toggleSubs(), { pressed: true, size: 18, cls: 'ccbtn' });
  function toggleSubs() {
    if (!allWords().length) { sel = null; tab = 'text'; openSec.set('t.subs', true); renderTimeline(); renderPanel(); return; }
    begin(); proj.settings.showSubs = !proj.settings.showSubs; changed();
  }
  function syncCc() { ccBtn.setAttribute('aria-pressed', String(!!proj.settings.showSubs)); ccBtn.style.display = ''; }
  const fsBtn = ibtn('expand', 'Schermo intero', () => toggleFull(), { key: 'F', size: 17 });
  const outLbl = h('div', { class: 'xs', style: { width: '150px', textAlign: 'right' } });
  // barra del tempo (a schermo intero): trascina per spostarti, le parti tolte sono a righe
  const fsFill = h('div', { class: 'fs-fill' }), fsKnob = h('div', { class: 'fs-knob' }), fsCuts = h('div', { class: 'fs-cuts' });
  const fsBar = h('div', { class: 'fs-bar', role: 'slider', 'aria-label': 'Posizione nel video' }, h('div', { class: 'fs-track' }, fsCuts, fsFill), fsKnob);
  let fsDrag = false, fsCutsKey = '';
  const fsT = (e) => { const r = fsBar.getBoundingClientRect(); return Math.max(0, Math.min(D - 0.05, T(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * viewEnd))); };
  fsBar.addEventListener('pointerdown', (e) => { fsDrag = true; capPtr(fsBar, e.pointerId); fsBar.classList.add('drag'); seek(fsT(e)); });
  fsBar.addEventListener('pointermove', (e) => { if (fsDrag) seekQuiet(fsT(e)); });
  fsBar.addEventListener('pointerup', () => { fsDrag = false; fsBar.classList.remove('drag'); });
  // schermo intero: quello del browser se c'e', altrimenti (Mac) il riquadro a tutta finestra + finestra a schermo intero
  const fsNow = () => document.fullscreenElement || document.webkitFullscreenElement || (fakeFs ? viewer : null);
  let fakeFs = false;
  function updateFsBar(t) {
    if (!fsNow()) return;
    const E = Math.max(0.01, viewEnd), p = (V(t) / E * 100) + '%';
    fsFill.style.width = p; fsKnob.style.left = p;
    const rem = removed(), key = rem.map((r) => r.join(',')).join(';') + '|' + E;
    if (key !== fsCutsKey) {
      fsCutsKey = key;
      fsCuts.replaceChildren(...rem.filter(([a, b]) => V(b) - V(a) > 0.01).map(([a, b]) => h('i', { style: { left: V(a) / E * 100 + '%', width: Math.max(0.15, (V(Math.min(D, b)) - V(a)) / E * 100) + '%' } })));
    }
  }
  // a schermo intero un clic in mezzo al video fa partire o ferma la riproduzione
  screenWrap.addEventListener('click', (e) => { if (fsNow() && !e.target.closest('button, input')) togglePlay(); });
  const viewer = h('section', { class: 'viewer', 'aria-label': 'Anteprima' }, screenWrap, fsBar,
    h('div', { class: 'transport' }, timeLbl,
      h('div', { class: 'mid' },
        ibtn('back5', 'Indietro di 5 secondi', () => seek(video.currentTime - 5), { key: 'Maiusc ←' }),
        playBtn,
        ibtn('fwd5', 'Avanti di 5 secondi', () => seek(video.currentTime + 5), { key: 'Maiusc →' })),
      h('div', { class: 'end' }, layoutBtn, guideBtn, rateWrap, ccBtn, fsBtn)));
  function setFakeFs(on) {
    fakeFs = on; viewer.classList.toggle('fsfake', on); document.body.classList.toggle('has-fsfake', on);
    post('/api/window/fullscreen', { on }).catch(() => {});
    onFs();
  }
  function exitFull() {
    if (fakeFs) return setFakeFs(false);
    if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {});
    else if (document.webkitFullscreenElement && document.webkitExitFullscreen) document.webkitExitFullscreen();
  }
  function toggleFull() {
    if (fsNow()) return exitFull();
    // sul Mac la finestra dell'app non ha lo schermo intero del browser: uso il riquadro a tutta finestra
    const req = !IS_MAC && (viewer.requestFullscreen || viewer.webkitRequestFullscreen);
    if (!req) return setFakeFs(true);
    try {
      const r = req.call(viewer);
      if (r && r.catch) r.catch(() => setFakeFs(true));
    } catch (e) { setFakeFs(true); }
  }
  const onFsKey = (e) => { if (fakeFs && e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); setFakeFs(false); } };
  window.addEventListener('keydown', onFsKey, true);
  const onFs = () => {
    const on = fsNow() === viewer;
    fsBtn.replaceChildren(icon(on ? 'shrink' : 'expand', 17));
    fsBtn.dataset.tip = on ? 'Esci da schermo intero' : 'Schermo intero';
    fsBtn.setAttribute('aria-label', fsBtn.dataset.tip);
    setTimeout(layoutScreen, 50);
  };
  document.addEventListener('fullscreenchange', onFs);
  document.addEventListener('webkitfullscreenchange', onFs);

  function layoutScreen() {
    const aw = screenWrap.clientWidth, ah = screenWrap.clientHeight;
    const A = VERT && !sourceView() ? 9 / 16 : W / H;   // proporzione di quello che si vede
    let w = aw, hh = aw / A;
    if (hh > ah) { hh = ah; w = ah * A; }
    screen.style.width = Math.floor(w) + 'px'; screen.style.height = Math.floor(hh) + 'px';
    applySubStyle();
  }

  // ---------------------------------------------------------------- DOM: pannello
  const panelTabs = h('div');
  const panelBody = h('div', { class: 'body' });
  const panel = h('aside', { class: 'panel', 'aria-label': 'Testo e proprietà' }, panelTabs, panelBody);
  const lTabs = h('div');
  const lBody = h('div', { class: 'body' });
  const leftPanel = h('aside', { class: 'panel lpanel', 'aria-label': 'Progetto, media e clip' }, lTabs, lBody);
  let curBody = panelBody;

  // ---------------------------------------------------------------- DOM: timeline
  const undoBtn = ibtn('undo', 'Annulla', undo, { key: 'Ctrl+Z' });
  const redoBtn = ibtn('redo', 'Ripeti', redo, { key: 'Ctrl+Y' });
  function updateUndo() { undoBtn.disabled = !undoStack.length; redoBtn.disabled = !redoStack.length; }
  const zoomSlider = h('input', { type: 'range', min: '0', max: '1000', value: '0', 'aria-label': 'Zoom della timeline' });
  const magnetBtn = ibtn('magnet', 'Magnete: la testina e i blocchi si agganciano ai bordi', () => {
    snapOn = !snapOn; store.set('snap', snapOn); magnetBtn.setAttribute('aria-pressed', String(snapOn));
    toast(snapOn ? 'Magnete attivo' : 'Magnete spento');
  }, { key: 'N', pressed: store.get('snap', true) });
  // barra della timeline: poche azioni, con il nome; il resto sta nel menu "Altro"
  const tbtn = (name, label, tip, fn, key) => {
    const b = h('button', { class: 'iconbtn lbl', 'aria-label': tip, 'data-tip': tip, 'data-key': key || null, onclick: fn }, icon(name, 15, 'currentColor', 1.9), h('span', null, label));
    return b;
  };
  const moreMenu = (e) => popMenu(e.currentTarget, [
    allWords().length || trRunning() ? null : ['cc', 'Crea i sottotitoli', 'Dalla voce del video, in automatico', () => startTranscribe(true)],
    ['sparkle', 'Effetto su misura (AI)', 'Descrivi l\'effetto: l\'AI lo crea da zero', () => fxDialog()],
    ['crop', 'Zoom personalizzato', 'Scegli tu cosa inquadrare · C', addCustomZoom],
    ['wand', 'Filtro o effetto', 'Dalla testina, anche solo su una parte', () => { sel = null; tab = 'video'; renderTimeline(); renderPanel(); }],
    ['trimL', 'Taglia prima della testina', 'Q', () => trimAt('left')],
    ['trimR', 'Taglia dopo la testina', 'W', () => trimAt('right')],
    ['magnet', snapOn ? 'Aggancio ai bordi: attivo' : 'Aggancio ai bordi: spento', 'La testina e i blocchi si attaccano ai bordi vicini · N', () => magnetBtn.click()],
    ['upload', 'Importa file nei Media', 'Video, immagini e suoni', () => { setTab('media'); importMedia(); }],
    IS_V ? null : ['timeline', 'Nuova timeline', 'Un\'altra timeline in questo progetto, stessi Media', () => newTimeline(null)],
    ['type', 'Scorciatoie da tastiera', 'Guarda e cambia i tasti', () => keysDialog()],
    ['addTrack', 'Aggiungi una traccia', null, [
      ['addVideo', 'Traccia video', 'Per immagini e testi, va sopra', () => addLaneTrack('overlay')],
      ['addAudio', 'Traccia audio', 'Per suoni e musica, va sotto', () => addLaneTrack('sound')],
      ['wand', 'Traccia filtri', 'Filtri ed effetti su un livello a parte', () => addLaneTrack('fx')],
      ['sliders', 'Traccia colori', 'Luminosità, contrasto, saturazione…', () => addLaneTrack('adjust')],
      ['magnify', 'Traccia zoom', 'Altri zoom, per organizzarli', () => addLaneTrack('zoom')]]]]);
  // toglie dalla timeline tutte le parti tagliate (restano nella trascrizione, barrate) e prepara l'anteprima fluida
  const cleanBtn = h('button', { class: 'btn sm tl-clean', style: { display: 'none' }, 'data-tip': 'Le parti tagliate spariscono dalla timeline e l\'anteprima diventa fluida. Nella trascrizione restano barrate: le rimetti quando vuoi.',
    onclick: () => removeCutParts() }, icon('scissors', 13, 'currentColor', 2), 'Rimuovi le parti tagliate');
  const mainMagBtn = ibtn('magnet', 'Calamita della traccia principale: accesa, le clip stanno attaccate senza spazi vuoti; spenta, le puoi mettere dove vuoi', () => setMainMagnet(!magnetOn()), { pressed: magnetOn() });
  const tools = h('div', { class: 'tl-tools' }, undoBtn, redoBtn, h('div', { class: 'sep' }),
    ibtn('scissors', 'Dividi nel punto della testina', splitSeg, { key: 'S' }),
    ibtn('trash', 'Elimina il selezionato', () => deleteSel(), { key: 'Canc' }),
    h('div', { class: 'sep' }),
    cam ? tbtn('magnify', 'Zoom', 'Aggiungi uno zoom sulla webcam qui', addZoom, 'Z') : null,
    tbtn('type', 'Testo', 'Aggiungi un testo', () => addText(), 'T'),
    tbtn('sparkle', 'Effetto AI', 'Descrivi un effetto: l\'AI lo crea da zero (anche agganciato alla tua mano)', () => fxDialog()),
    tbtn('diamond', 'Marcatore', 'Aggiungi un marcatore alla testina (tasto destro sul marcatore per nome, blocco e altro)', () => toggleMarker(), 'M'),
    IS_V || proj.width < proj.height * 1.3 ? null : tbtn('phone', 'Clip verticale', 'Crea una clip verticale dalle clip selezionate', () => vertFromSelection(), 'V'),
    tbtn('plus', 'Altro', 'Zoom personalizzato, filtri, tracce, importa…', moreMenu),
    h('div', { class: 'sep' }),
    ibtn('toStart', 'Seleziona tutto a sinistra della testina', () => selectSide(-1)),
    ibtn('toEnd', 'Seleziona tutto a destra della testina (poi trascina per fare spazio)', () => selectSide(1)),
    IS_V ? magnetBtn : mainMagBtn,
    h('div', { class: 'grow' }),
    cleanBtn,
    h('div', { class: 'tl-zoom', 'data-tip': 'Zoom della timeline', 'data-key': 'Ctrl + rotella' }, icon('zoomout', 14), zoomSlider, icon('zoomin', 14)));
  const heads = h('div', { class: 'tl-heads' });
  const ruler = h('div', { class: 'ruler' });
  const lanes = h('div', { class: 'lanes' });
  const playhead = h('div', { class: 'playhead' });
  const inner = h('div', { class: 'tl-inner' }, ruler, lanes, playhead);
  const scroller = h('div', { class: 'tl-scroll' }, inner);
  const tlMain = h('div', { class: 'tl-main' }, heads, scroller);
  const tlTabs = h('div', { class: 'tl-tabs', role: 'tablist', 'aria-label': 'Timeline del progetto', style: { display: 'none' } });
  const tl = h('section', { class: 'tl', 'aria-label': 'Timeline' }, tlTabs, tools, tlMain);

  const savedLabel = h('span', { class: 'saved', 'data-tip': 'Salvato in automatico' }, icon('cloudok', 17));
  const exportBtn = h('button', { class: 'btn primary sm', 'data-tip': 'Crea il video finale', onclick: () => openExport() }, icon('download', 14, '#fff', 2.2), 'Esporta');

  function popMenuAt(x, y, items) {
    const fake = { getBoundingClientRect: () => ({ left: x, top: y, bottom: y, right: x }) };
    popMenu(fake, items, true);
  }
  // ---------------------------------------------------------------- piu' timeline nello stesso progetto (come CapCut)
  // Ogni timeline e' un progetto figlio (stesso formato, stessi Media): si passa dall'una all'altra con le schede.
  let timelines = [];
  async function loadTimelines() {
    if (IS_V) return;
    try { timelines = await get(`/api/p/${pid}/timelines`); } catch (e) { timelines = []; }
    if (alive) drawTlTabs();
  }
  function drawTlTabs() {
    tlTabs.style.display = timelines.length > 1 ? '' : 'none';
    if (timelines.length < 2) return;
    tlTabs.replaceChildren(...timelines.map((t) => {
      const on = t.id === pid;
      const b = h('button', { class: 'tl-tab' + (on ? ' on' : ''), role: 'tab', 'aria-selected': String(on), type: 'button', 'data-notr': '',
        'data-tip': on ? 'Doppio clic per rinominare' : 'Apri ' + t.name, onclick: () => { if (!on) switchTimeline(t.id); } },
        icon('timeline', 13, 'currentColor', 1.9), h('span', null, t.name));
      b.addEventListener('dblclick', () => renameTimeline(t));
      b.addEventListener('contextmenu', (e) => { e.preventDefault(); popMenuAt(e.clientX, e.clientY, [
        on ? null : ['film', 'Apri', null, () => switchTimeline(t.id)],
        ['type', 'Rinomina', null, () => renameTimeline(t)],
        t.main ? null : ['trash', 'Elimina questa timeline', 'Va nel cestino con il progetto per 30 giorni', () => removeTimeline(t)],
      ].filter(Boolean)); });
      return b;
    }), h('button', { class: 'tl-tab add', type: 'button', 'aria-label': 'Nuova timeline', 'data-tip': 'Nuova timeline', onclick: () => newTimeline(null) }, icon('plus', 13, 'currentColor', 2.2)));
  }
  async function switchTimeline(id) {
    video.pause();
    await textsSaved(); dirty = true; await flush();
    ctx.nav('editor', id);
  }
  async function newTimeline(a) {
    if (IS_V) return;
    try {
      await textsSaved(); dirty = true; await flush();
      toast('Creo la timeline…');
      const asset = a ? { path: a.path, name: a.name, kind: a.kind, duration: a.duration, w: a.w, h: a.h, hasAudio: a.hasAudio } : null;
      const r = await post(`/api/p/${pid}/timeline`, { asset });
      toast(`${r.name} creata: passi da una timeline all'altra con le schede sopra la timeline`);
      ctx.nav('editor', r.id);
    } catch (e) { toast(e.message, true); }
  }
  async function renameTimeline(t) {
    const name = await promptBox('Rinomina la timeline', 'È anche il nome del file quando la esporti.', t.name, 'Rinomina');
    if (!name || name === t.name) return;
    try { await post(`/api/p/${pid}/timeline-rename`, { id: t.id, name }); } catch (e) { return toast(e.message, true); }
    if (t.id === pid && IS_TL) proj.name = name;
    t.name = name; drawTlTabs();
  }
  async function removeTimeline(t) {
    if (!await confirmBox('Eliminare la timeline?', `"${t.name}" va nel cestino. Le altre timeline restano come sono.`, 'Elimina', true)) return;
    try { await post(`/api/p/${pid}/timeline-remove`, { id: t.id }); } catch (e) { return toast(e.message, true); }
    if (t.id === pid) { const main = timelines.find((x) => x.main); ctx.nav('editor', main ? main.id : proj.parent); return; }
    timelines = timelines.filter((x) => x.id !== t.id); drawTlTabs();
  }

  // ---------------------------------------------------------------- clip verticali
  let lastVDown = { id: null, t: 0 };
  // clip verticali che si sovrappongono: una sotto l'altra
  function vertRows() {
    const end = [], rows = new Map();
    for (const v of [...(proj.verticals || [])].sort((x, y) => x.a - y.a)) {
      let r = end.findIndex((e) => e <= v.a + 0.001);
      if (r < 0) { r = end.length; end.push(0); }
      end[r] = v.b; rows.set(v.id, r);
    }
    return { rows, n: Math.max(1, end.length) };
  }
  // pezzi della clip verticale: le clip scelte, anche lontane tra loro (quelle vicine diventano un pezzo solo)
  function vertRun(segs) {
    const list = proj.segs.filter((c) => !c.gone).sort((x, y) => x.a - y.a);
    const idx = segs.map((c) => list.indexOf(c)).filter((i) => i >= 0).sort((x, y) => x - y);
    if (!idx.length) return null;
    const ranges = [];
    for (const i of idx) {
      const c = list[i], last = ranges[ranges.length - 1];
      if (last && last.i === i - 1) { last.b = c.b; last.i = i; } else ranges.push({ a: c.a, b: c.b, i });
    }
    const out = ranges.map((r) => [r.a, r.b]);
    return out.reduce((s2, [a, b]) => s2 + b - a, 0) >= 0.5 ? out : null;
  }
  // dal pulsante (o dal tasto V): usa le clip video selezionate, anche se insieme ad altro
  function vertFromSelection() {
    const list = (multi.length ? multi : sel ? [sel] : []).filter((m) => isSeg(m.type)).map((m) => findSel(m)).filter(Boolean);
    if (!list.length) return toast('Seleziona nella traccia Video le clip da usare (con Maiusc per prenderne più di una), poi premi di nuovo');
    const run = vertRun(list);
    if (!run) return toast('La clip è troppo corta', true);
    createVertical(run);
  }
  async function createVertical(ranges) {
    const n = proj.verticals.length + 1;
    const name = await promptBox('Nome della clip verticale', 'Lo ritrovi nella timeline e diventa il nome del file quando la esporti.', tx('Clip verticale') + ' ' + n, 'Crea');
    if (!name) return;
    try {
      await textsSaved(); dirty = true; await flush();
      const r = await post(`/api/p/${pid}/vertical`, { ranges, name });
      proj.verticals.push(r);
      dirty = true; scheduleSave();
      multi = []; sel = { type: 'vclip', id: r.id }; tab = 'clips'; renderTimeline(); renderPanel();
      toast('Clip verticale creata: la trovi nella tab Clip');
    } catch (e) { toast(e.message, true); }
  }
  async function openVertical(v) {
    video.pause();
    try { sessionStorage.setItem('vodcut.seek.' + pid, String(video.currentTime)); } catch (e) { /* */ }
    await textsSaved(); await flush();
    ctx.nav('editor', v.id);
  }
  async function renameVertical(v) {
    const name = await promptBox('Rinomina la clip verticale', null, v.name, 'Rinomina');
    if (!name || name === v.name) return;
    try { await post(`/api/p/${v.id}/rename`, { name }); } catch (e) { return toast(e.message, true); }
    v.name = name; dirty = true; scheduleSave(); renderTimeline(); renderPanel();
  }
  async function deleteVertical(v) {
    if (!await confirmBox('Eliminare la clip verticale?', `"${v.name}" e le sue modifiche spariscono. Il video orizzontale resta com'è.`, 'Elimina', true)) return;
    if (sel && sel.id === v.id) sel = null;
    try { await api('DELETE', '/api/p/' + v.id); } catch (e) { /* gia' tolta */ }
    proj.verticals = proj.verticals.filter((x) => x.id !== v.id);
    sel = null; dirty = true; scheduleSave(); renderTimeline(); renderPanel();
  }
  function vclipMenu(v) {
    return [['phone', 'Modifica la clip verticale', 'Anche con doppio clic', () => openVertical(v)],
      ['type', 'Rinomina', null, () => renameVertical(v)],
      ['trash', 'Elimina la clip verticale', 'Il video orizzontale resta com\'è', () => deleteVertical(v)]];
  }
  const vRanges = (v) => v.ranges || [[v.a, v.b]];
  const vDur = (v) => vRanges(v).reduce((s2, [a, b]) => s2 + b - a, 0);
  // tab Clip: tutte le clip verticali di questo video, in ordine
  function renderClipsTab() {
    const list = proj.verticals.slice().sort((x, y) => vRanges(x)[0][0] - vRanges(y)[0][0]);
    const cur = sel && sel.type === 'vclip' ? sel.id : null;
    const segSel = [...(multi.length ? multi : sel ? [sel] : [])].filter((m) => isSeg(m.type)).map((m) => findSel(m)).filter(Boolean);
    const run = segSel.length ? vertRun(segSel) : null;
    B.append(h('div', { class: 'vc-top' },
      h('div', { class: 'vc-top-t' }, h('b', null, 'Clip verticali'), h('span', null, list.length ? String(list.length) : '')),
      h('button', { class: 'btn sm primary', disabled: run ? null : true, onclick: () => run && createVertical(run),
        'data-tip': run ? 'Con le clip selezionate nella traccia Video' : 'Seleziona prima una o più clip nella traccia Video (Ctrl o Maiusc per sceglierne più d\'una)', 'data-key': 'V' },
        icon('plus', 13, '#fff', 2.4), 'Nuova')));
    if (!list.length) { B.append(h('div', { class: 'vc-empty' }, icon('phone', 22, 'currentColor', 1.6), h('span', null, 'Seleziona i pezzi nella traccia Video e premi Nuova (o V).'))); return; }
    B.append(h('div', { class: 'vc-list' }, ...list.map((v) => {
      const rs = vRanges(v), t0 = rs[0][0];
      const card = h('div', { class: 'vc-item' + (cur === v.id ? ' on' : '') },
        h('img', { class: 'vc-thumb', src: thumbUrl(pid, Math.min(D - 0.5, t0 + Math.min(1, vDur(v) / 2)), 160), alt: '', loading: 'lazy' }),
        h('div', { class: 'vc-info' },
          h('b', { 'data-notr': '' }, v.name),
          h('span', null, fmtLong(vDur(v)) + (rs.length > 1 ? ` · ${rs.length} pezzi` : '') + ' · da ' + fmt(t0)),
          h('div', { class: 'vc-acts' },
            h('button', { class: 'btn sm', onclick: (e) => { e.stopPropagation(); openVertical(v); } }, 'Modifica'),
            ibtn('type', 'Rinomina', (e) => { e.stopPropagation(); renameVertical(v); }, { size: 14 }),
            ibtn('trash', 'Elimina la clip verticale', (e) => { e.stopPropagation(); deleteVertical(v); }, { size: 14 }))));
      // un clic la mostra sulla timeline (i pezzi si colorano), doppio clic la apre
      card.addEventListener('click', () => { sel = { type: 'vclip', id: v.id }; multi = []; seekQuiet(t0 + 0.05); renderTimeline(); renderPanel(); frame(true); });
      card.addEventListener('dblclick', () => openVertical(v));
      card.addEventListener('contextmenu', (e) => { e.preventDefault(); popMenuAt(e.clientX, e.clientY, vclipMenu(v)); });
      return card;
    })));
  }
  // menu del tasto destro sui blocchi della timeline
  // stesso ingrandimento per tutti gli zoom sulla webcam (o solo per quelli scelti)
  function setAllZoomLevels(v, list) {
    begin();
    const zs = (list || proj.zooms).filter((z) => z.kind !== 'custom');
    zs.forEach((z) => { z.level = v; });
    proj.settings.zoomLevel = v;
    changed();
    toast(tx('Zoom a') + ' ' + (v + '×').replace('.', ',') + ' · ' + zs.length);
  }
  function blockMenu(it) {
    const list = multi.length > 1 ? multi.slice() : [it];
    const items = list.map((m) => ({ m, o: findSel(m) })).filter((x) => x.o);
    const segs = items.filter((x) => isSeg(x.m.type)).map((x) => x.o);
    const n = items.length, one = n === 1 ? items[0] : null;
    const menu = [];
    const subs = items.filter((x) => x.m.type === 'sub').map((x) => x.o);
    if (subs.length === n && n) {
      const hid = subs.every((x) => x.hidden);
      menu.push([hid ? 'eye' : 'eyeOff', hid ? (n > 1 ? `Mostra queste ${n} frasi` : 'Mostra questa frase') : (n > 1 ? `Nascondi queste ${n} frasi` : 'Nascondi questa frase'), 'Solo nei sottotitoli, l\'audio resta',
        () => { begin(); subs.forEach((x) => wordsIn(x.a, x.b).forEach((w) => { w.nosub = hid ? undefined : true; })); ver++; multi = []; sel = null; changed(); }]);
      if (one) {
        menu.push(['eyeOff', 'Nascondi da qui alla fine', null, () => setNoSub(one.o.a, D, true)], ['eye', 'Mostra da qui alla fine', null, () => setNoSub(one.o.a, D, false)],
          ['type', 'Correggi il testo', null, () => fixSub(one.o)]);
      }
      return menu;
    }
    if (segs.length === n && n) {
      const t = video.currentTime;
      if (!IS_V) {
        const run = vertRun(segs);
        menu.push(['phone', 'Crea clip verticale', run ? (segs.length > 1 ? 'Con i pezzi scelti, uno dopo l\'altro' : 'Una clip 9:16 da modificare a parte') : 'Troppo corta', run ? () => createVertical(run) : null, '#818CF8']);
      }
      if (one && t > one.o.a + 0.1 && t < one.o.b - 0.1) menu.push(['scissors', 'Dividi qui', 'Nel punto della testina', () => splitSeg()]);
      if (one && t >= one.o.a && t < one.o.b && !one.o.removed) menu.push(['pause', 'Fermo immagine', 'Il fotogramma alla testina resta fermo 2 secondi', () => freezeFrame()]);
      const anyOut = segs.some((x) => x.removed);
      menu.push([anyOut ? 'restore' : 'scissors', anyOut ? 'Rimetti nel video' : 'Togli dal video', anyOut ? null : 'Resta sulla timeline, a righe', () => { begin(); segs.forEach((x) => { x.removed = !anyOut; if (anyOut) x.gone = false; }); changed(); }]);
      menu.push(['trash', 'Elimina dalla timeline', 'Sparisce del tutto (Ctrl+Z per annullare)', () => deleteMany(items.map((x) => x.m), true)]);
      const anyMute = segs.some((x) => x.mute);
      menu.push([anyMute ? 'speaker' : 'mute', anyMute ? 'Riattiva l\'audio' : 'Silenzia l\'audio', null, () => { begin(); segs.forEach((x) => { x.mute = !anyMute; }); changed(); }]);
      if (allWords().length) {
        const hid = segs.every((x) => wordsIn(x.a, x.b).every((w) => w.nosub));
        menu.push([hid ? 'eye' : 'eyeOff', hid ? 'Mostra i sottotitoli qui' : 'Nascondi i sottotitoli qui', null, () => { begin(); segs.forEach((x) => wordsIn(x.a, x.b).forEach((w) => { w.nosub = hid ? undefined : true; })); ver++; changed(); }]);
      }
      if (ENV_WHISPER() && !(proj.transcript && proj.transcript.status === 'running')) {
        const has = segs.some((x) => wordsIn(x.a, x.b).length);
        const lbl = n > 1 ? (has ? `Rifai i sottotitoli di queste ${n} clip` : `Crea i sottotitoli di queste ${n} clip`) : (has ? 'Rifai i sottotitoli di questa clip' : 'Crea i sottotitoli di questa clip');
        menu.push(['cc', lbl, has ? 'Si ritrascrive solo questo pezzo' : 'Si trascrive solo questo pezzo, il resto non cambia', subRangeJob ? null : () => regenSubs(segs)]);
      }
      menu.push(['duplicate', n > 1 ? `Copia le clip (${n})` : 'Copia la clip', 'Ctrl+C · poi Ctrl+V: alla fine si mette di fianco, in mezzo va su un\'altra traccia', () => copySel()]);
      if (clipBoard && clipBoard.kind === 'main') menu.push(['duplicate', 'Incolla alla testina', 'Ctrl+V', () => pasteClip()]);
      menu.push(['sliders', 'Copia le impostazioni', 'Velocità, filtro, colori, audio e impaginazione', () => copyAttrs(one ? one.o : segs[0])]);
      if (clipBoard && clipBoard.kind === 'attrs') menu.push(['duplicate', n > 1 ? `Incolla le impostazioni (${n})` : 'Incolla le impostazioni', 'Ctrl+V', () => pasteClip()]);
      menu.push(['speed', 'Velocità', segs.length === 1 && (one.o.speed || 1) !== 1 ? (one.o.speed + '×').replace('.', ',') : 'Normale',
        [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4].map((v) => ['speed', (v + '×').replace('.', ','), v === 1 ? 'Normale' : v < 1 ? 'Rallentato' : 'Accelerato', () => { begin(); segs.forEach((x) => { x.speed = v === 1 ? undefined : v; }); changed(); applySpeed(); }])]);
      return menu;
    }
    // selezione mista (clip video + altro, es. col rettangolo): la clip verticale si fa con le clip video
    if (!IS_V && segs.length && segs.length < n) {
      const run = vertRun(segs);
      menu.push(['phone', 'Crea clip verticale', run ? 'Con le clip video selezionate' : 'Troppo corta', run ? () => createVertical(run) : null]);
    }
    const zsel = items.filter((x) => x.m.type === 'zoom' && x.o.kind !== 'custom').map((x) => x.o);
    if (zsel.length) menu.push(['magnify', zsel.length > 1 ? `Ingrandimento di questi ${zsel.length} zoom` : 'Ingrandimento', null,
      [2, 2.4, 2.8, 3.4, 4].map((v) => ['magnify', (v + '×').replace('.', ','), null, () => setAllZoomLevels(v, zsel)])]);
    if (items.some((x) => COPY_TYPES.includes(x.m.type))) menu.push(['duplicate', 'Copia', 'Ctrl+C · poi Ctrl+V per incollare alla testina', () => copySel()]);
    if (clipBoard && clipBoard.kind === 'items') menu.push(['duplicate', 'Incolla alla testina', 'Ctrl+V', () => pasteClip()]);
    if (one && ['zoom', 'fx', 'sclip'].includes(one.m.type)) menu.push(['duplicate', 'Duplica', 'Una copia subito dopo', () => duplicateItem(one.m, one.o)]);
    if (one && one.m.type === 'sclip' && !one.o.isText) menu.push(['swap', 'Sostituisci…', 'Stessa posizione e stessi effetti, file nuovo', () => replaceClip(one.o)]);
    if (one && one.m.type === 'sclip' && one.o.kind === 'image' && !one.o.isText) menu.push(['cutout', 'Rimuovi lo sfondo', 'Automatico, sul tuo PC', () => removeBg(one.o)]);
    if (items.some((x) => x.m.type === 'sclip' && x.o.kind !== 'image')) {
      const snd = items.filter((x) => x.m.type === 'sclip' && x.o.kind !== 'image').map((x) => x.o), anyMute = snd.some((x) => x.mute);
      menu.push([anyMute ? 'speaker' : 'mute', anyMute ? 'Riattiva' : 'Muta', null, () => { begin(); snd.forEach((x) => { x.mute = !anyMute; }); changed(); }]);
    }
    menu.push(['trash', n > 1 ? `Elimina (${n})` : 'Elimina', null, () => deleteMany(items.map((x) => x.m), true)]);
    return menu;
  }
  const wordsIn = (a, b) => { const r = []; allWords().forEach((sg) => sg.words.forEach((w) => { const m = (w.a + w.b) / 2; if (m >= a && m < b) r.push(w); })); return r; };
  function setNoSub(a, b, on) { begin(); wordsIn(a, b).forEach((w) => { w.nosub = on || undefined; }); ver++; changed(); }
  function deleteMany(list, fromTimeline) {
    begin();
    for (const m of list) {
      const o = findSel(m); if (!o) continue;
      if (isSeg(m.type)) { o.removed = true; if (fromTimeline) o.gone = true; }
      else if (m.type === 'sub') { wordsIn(o.a, o.b).forEach((w) => { w.nosub = true; }); ver++; }
      else if (m.type === 'zoom') proj.zooms = proj.zooms.filter((z) => z !== o);
      else if (m.type === 'fx') proj.filters = proj.filters.filter((f) => f !== o);
      else if (m.type === 'sclip') { const tr = trackOfClip(o.id); if (tr) tr.clips = tr.clips.filter((c) => c !== o); }
    }
    multi = []; if (sel && !findSel(sel)) sel = null; if (sel && isSeg(sel.type) && fromTimeline) sel = null;
    changed();
  }
  // ---------------------------------------------------------------- copia e incolla (Ctrl+C / Ctrl+V)
  // zoom, filtri, immagini, testi, video e suoni: si incollano alla testina con gli stessi valori.
  // Clip del video: si copiano le impostazioni (velocita', filtro, colori, audio, impaginazione) e si incollano su altre clip
  let clipBoard = null;
  const COPY_TYPES = ['zoom', 'fx', 'sclip'];
  const SEG_ATTRS = ['speed', 'fx', 'adj', 'vol', 'mute', 'fin', 'fout', 'vlay'];
  const selList = () => (multi.length ? multi : sel ? [sel] : []).map((m) => ({ type: m.type, o: findSel(m) })).filter((x) => x.o);
  const deep = (o) => JSON.parse(JSON.stringify(o));
  function copySel() {
    const list = selList().filter((x) => COPY_TYPES.includes(x.type) || isSeg(x.type));
    if (!list.length) return false;
    const items = list.filter((x) => COPY_TYPES.includes(x.type));
    if (!items.length) {
      // clip della traccia principale: si copia tutta la clip (Ctrl+V la rimette alla testina)
      const segs = list.filter((x) => isSeg(x.type) && !x.o.gone).map((x) => x.o).sort((x, y) => x.a - y.a);
      if (!segs.length) return false;
      clipBoard = { kind: 'main', o: deep(segs[0]), clips: segs.map((c) => mainClipData(c)) };
      toast(segs.length > 1 ? `Copiate ${segs.length} clip: Ctrl+V per incollarle alla testina` : 'Clip copiata: Ctrl+V per incollarla alla testina');
      return true;
    }
    clipBoard = { kind: 'items', t0: Math.min(...items.map((x) => x.o.a)),
      items: items.map((x) => ({ type: x.type, o: deep(x.o), track: x.type === 'sclip' ? (trackOfClip(x.o.id) || {}).id : null })) };
    toast(items.length > 1 ? `Copiati ${items.length} elementi: Ctrl+V per incollarli alla testina` : 'Copiato: Ctrl+V per incollarlo alla testina');
    return true;
  }
  // tutto quello che serve per rimettere una clip principale altrove (file, punto di partenza, impostazioni, parole)
  function mainClipData(c) {
    const rec = c.ins && insById(c.ins);
    const dur = +(c.b - c.a).toFixed(4);
    const rel = (x) => +(x - c.a).toFixed(4);
    const words = allWords().filter((sg) => sg.a >= c.a - 1e-6 && sg.b <= c.b + 1e-6)
      .map((sg) => ({ ...sg, a: rel(sg.a), b: rel(sg.b), words: (sg.words || []).map((w2) => ({ ...w2, a: rel(w2.a), b: rel(w2.b) })) }));
    const base = rec ? { file: rec.file, offset: +((rec.offset || 0) + (c.a - rec.at)).toFixed(4), live: !!rec.live, gap: !!rec.gap, name: rec.name, w: rec.w, h: rec.h,
      hasAudio: rec.hasAudio, vcodec: rec.vcodec, preview: rec.preview, ...(rec.image ? { image: true, fileDur: rec.fileDur, src: rec.src, iar: rec.iar } : {}) }
      : { file: proj.source, offset: +liveOffAt(c.a).toFixed(4), live: true, name: 'Clip della live', w: W, h: H, hasAudio: proj.hasAudio !== false };
    return { ...base, dur, seg: deep(c), words };
  }
  async function pasteMain() {
    const t = video.currentTime;
    const main = proj.segs.filter((c) => !c.gone && !(BLANK && !c.ins));
    const end = main.length ? Math.max(...main.map((c) => c.b)) : 0;
    const cl = clipBoard.clips;
    if (t >= end - 0.15) {
      // alla fine: le clip si mettono di fianco, una dopo l'altra
      let at = end;
      for (const d of cl) {
        const { seg, words, preview, ...src } = d;
        const rec = { id: uid('v'), at, ...src, words: deep(words) };
        if (preview) rec.preview = preview;
        await applyInsert(rec, null, [{ ...seg, id: uid('s'), a: 0, b: d.dur, removed: false, gone: false, auto: false, ins: undefined }]);
        at = rec.at + d.dur;
      }
      toast(cl.length > 1 ? 'Clip incollate alla fine' : 'Clip incollata alla fine');
      return true;
    }
    // in mezzo la traccia principale e' occupata: la clip va sopra, in una traccia video libera
    begin();
    let at = t;
    const made = [];
    for (const d of cl) {
      const sp = d.seg.speed || 1, len = +(d.dur / sp).toFixed(3);
      const ar = d.w && d.h ? d.h / d.w : 1 / CA();
      const w = Math.min(1, (1 / CA()) / ar), hf = w * CA() * ar;
      const c = { id: uid('c'), kind: 'video', file: d.live ? proj.source : d.file, name: (d.name || 'Clip').replace(/\.[^.]+$/, ''), a: +at.toFixed(2), dur: len, offset: d.offset,
        fileDur: d.offset + d.dur, pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, ar, opacity: 100,
        vol: d.seg.vol ?? 100, mute: !!d.seg.mute, hasAudio: !!d.hasAudio && !d.gap };
      if (d.preview) c.preview = d.preview;
      const free = (tr) => !tr.clips.some((x) => x.a < c.a + c.dur - 1e-3 && x.a + x.dur > c.a + 1e-3);
      const tr = proj.tracks.find((x) => x.type === 'overlay' && free(x)) || newTrack('overlay');
      tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
      made.push({ type: 'sclip', id: c.id });
      at += len;
    }
    multi = made.length > 1 ? made : []; sel = { ...made[made.length - 1] };
    changed(); frame(true);
    toast('La traccia principale qui è occupata: incollata sopra, in una traccia video');
    return true;
  }
  function copyAttrs(o) {
    clipBoard = { kind: 'attrs', o: deep(o) };
    toast('Impostazioni della clip copiate: seleziona altre clip e premi Ctrl+V');
  }
  function pasteClip() {
    if (!clipBoard) return false;
    if (clipBoard.kind === 'main') { pasteMain(); return true; }
    if (clipBoard.kind === 'attrs') {
      const targets = selList().filter((x) => isSeg(x.type)).map((x) => x.o);
      if (!targets.length) { toast('Seleziona le clip su cui incollare le impostazioni', true); return true; }
      begin();
      for (const c of targets) for (const k of SEG_ATTRS) { if (clipBoard.o[k] === undefined) delete c[k]; else c[k] = deep(clipBoard.o[k]); }
      changed(); applySpeed(); frame(true);
      toast(targets.length > 1 ? `Impostazioni incollate su ${targets.length} clip` : 'Impostazioni incollate');
      return true;
    }
    begin();
    const dt = video.currentTime - clipBoard.t0, made = [];
    for (const it of clipBoard.items) {
      const c = deep(it.o);
      c.id = uid(it.type === 'zoom' ? 'z' : it.type === 'fx' ? 'f' : 'c');
      if (c.b !== undefined) {
        const len = c.b - c.a;
        c.a = +Math.max(0, Math.min(D - len, c.a + dt)).toFixed(2); c.b = +(c.a + len).toFixed(2);
      } else c.a = +Math.max(0, Math.min(D - c.dur, c.a + dt)).toFixed(2);
      if (it.type === 'zoom') {
        if (!proj.zoomTracks.some((t) => t.id === (c.track || 'zoom'))) c.track = 'zoom';
        proj.zooms.push(c); proj.zooms.sort((x, y) => x.a - y.a);
      } else if (it.type === 'fx') {
        if (!proj.fxTracks.some((t) => t.id === (c.track || 'fx'))) c.track = 'fx';
        proj.filters.push(c);
      } else {
        // stessa traccia se c'e' posto, se no un'altra dello stesso tipo (o una nuova)
        const kind = c.kind === 'image' || c.kind === 'video' ? 'overlay' : 'sound';
        const free = (t) => !t.clips.some((x) => x.a < c.a + c.dur - 1e-3 && x.a + x.dur > c.a + 1e-3);
        let tr = proj.tracks.find((t) => t.id === it.track && t.type === kind);
        if (!tr || !free(tr)) tr = proj.tracks.find((t) => t.type === kind && free(t)) || newTrack(kind);
        tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
        if (c.isText) refreshText(c);
      }
      made.push({ type: it.type, id: c.id });
    }
    multi = made.length > 1 ? made : [];
    sel = { ...made[made.length - 1] };
    changed(); frame(true);
    return true;
  }
  function duplicateItem(m, o) {
    begin();
    const c = JSON.parse(JSON.stringify(o));
    c.id = uid(m.type === 'zoom' ? 'z' : m.type === 'fx' ? 'f' : 'c');
    if (o.b !== undefined) { const len = o.b - o.a; c.a = +Math.min(D - len, o.b).toFixed(2); c.b = +(c.a + len).toFixed(2); }
    else c.a = +Math.min(D - o.dur, o.a + o.dur).toFixed(2);
    if (m.type === 'zoom') { proj.zooms.push(c); proj.zooms.sort((x, y) => x.a - y.a); }
    else if (m.type === 'fx') proj.filters.push(c);
    else { const tr = trackOfClip(o.id); tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a); if (c.isText) refreshText(c); }
    sel = { type: m.type, id: c.id }; multi = [];
    changed();
  }
  async function replaceClip(c) {
    try {
      const r = await post('/api/pick', { kind: 'media' });
      const f = r.files && r.files[0];
      if (!f) { if (r.skipped && r.skipped.length) toast('Formato non supportato', true); return; }
      if ((f.kind === 'image') !== (c.kind === 'image')) return toast(c.kind === 'image' ? 'Scegli un\'immagine' : 'Scegli un suono', true);
      begin();
      c.file = f.path; c.name = f.name.replace(/\.[^.]+$/, '');
      if (f.kind === 'image' && f.w && f.h) c.ar = f.h / f.w;
      if (f.kind === 'audio') { c.fileDur = f.duration; c.offset = 0; c.dur = +Math.min(c.dur, f.duration).toFixed(2); }
      addAssets([f]);
      changed();
      toast('Sostituito');
    } catch (e) { toast(e.message, true); }
  }
  async function removeBg(c) {
    let job;
    try { job = await post('/api/removebg', { path: c.file }); } catch (e) { return toast(e.message, true); }
    const msg = h('span', { class: 'xs' }, 'Preparo…'), bar = h('div', { class: 'progress' }, h('div', { style: { width: '0%' } }));
    const bg = h('div', { class: 'modal-bg' }, h('div', { class: 'modal' }, h('h2', null, 'Rimuovo lo sfondo'), msg, bar));
    document.body.append(bg);
    const res = await pollJob(job.id, (j) => { bar.firstChild.style.width = (j.progress * 100).toFixed(0) + '%'; if (j.message) msg.textContent = j.message; });
    bg.remove();
    if (res.status !== 'done') return toast('Non sono riuscito a rimuovere lo sfondo: ' + (res.error || 'annullato'), true);
    begin(); c.file = res.result.path; c.name = (c.name || 'immagine') + ' (senza sfondo)'; addAssets([res.result]); changed();
    toast('Sfondo rimosso');
  }

  // menu a comparsa sotto un tasto
  function popMenu(anchor, items, atPoint) {
    items = items.filter(Boolean);
    document.querySelectorAll('.popmenu').forEach((m) => m.remove());
    const m = h('div', { class: 'popmenu', role: 'menu' }, ...items.map(([ic, label, sub, fn, color]) =>
      h('button', { class: 'pm-it' + (Array.isArray(fn) ? ' sub' : ''), role: 'menuitem', disabled: fn ? null : true, onclick: () => {
        m.remove();
        if (!fn) return;
        if (Array.isArray(fn)) popMenu({ getBoundingClientRect: () => ({ left: parseFloat(m.style.left), top: parseFloat(m.style.top), bottom: parseFloat(m.style.top), right: 0 }) }, fn, true);
        else fn();
      } },
        h('span', { class: 'pm-ic' }, icon(ic, 16, color || 'currentColor')),
        h('span', { class: 'pm-tx' }, h('b', null, label), sub ? h('span', null, sub) : null))));
    document.body.append(m);
    const r = anchor.getBoundingClientRect();
    m.style.left = Math.max(8, Math.min(window.innerWidth - m.offsetWidth - 8, r.left)) + 'px';
    // mai fuori dalla finestra: si apre dove c'e' piu' spazio e, se non basta, si scorre dentro il menu
    const ih = window.innerHeight, need = m.offsetHeight;
    if (atPoint) {
      const room = ih - 16;
      if (need > room) m.style.maxHeight = room + 'px';
      m.style.top = Math.max(8, Math.min(ih - Math.min(need, room) - 8, r.top)) + 'px';
    } else {
      const above = r.top - 14, below = ih - r.bottom - 14;
      if (need <= above || above >= below) { const hh = Math.min(need, above); m.style.maxHeight = hh + 'px'; m.style.top = (r.top - 6 - hh) + 'px'; }
      else { const hh = Math.min(need, below); m.style.maxHeight = hh + 'px'; m.style.top = (r.bottom + 6) + 'px'; }
    }
    const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  }

  // ---------------------------------------------------------------- aggiungere un altro video prima o dopo
  // ---------------------------------------------------------------- video nella traccia principale
  // Come in CapCut: il video entra tra due clip (mai a meta' di una), subito, e si puo' annullare.
  // Il server lo prepara soltanto (durata, audio, copia leggera se serve): il progetto lo cambia l'editor.
  let pendingIns = null;   // {at, dur, name, el} mentre il server lo prepara
  function drawPendingIns() {
    if (!pendingIns) return;
    const lane = tl.querySelector('.lane.video');
    if (!lane) return;
    // clip "in arrivo": larga al massimo quanto la parte visibile, con la barra di avanzamento
    const w = Math.max(90, Math.min((pendingIns.dur || 3) * pps, scroller.clientWidth - Math.max(0, X(pendingIns.at) - scroller.scrollLeft) - 8));
    if (!pendingIns.el) {
      pendingIns.bar = h('i', { class: 'ig-bar' });
      pendingIns.el = h('div', { class: 'insghost' }, h('div', { class: 'ig-body' }, h('div', { class: 'spinner sm' }), h('span', { class: 'ig-txt' }, 'Preparo il video…')), h('div', { class: 'ig-track' }, pendingIns.bar));
    }
    Object.assign(pendingIns.el.style, { left: X(pendingIns.at) + 'px', width: w + 'px' });
    if (pendingIns.el.parentNode !== lane) lane.append(pendingIns.el);
    lane.classList.add('pending');
  }
  async function insertVideo(path, at, known, opts = {}) {
    if (pendingIns) return toast('Un attimo: sto ancora aggiungendo l\'altro video.', true);
    video.pause();
    pendingIns = { at, dur: known && known.duration, name: known && known.name };
    drawPendingIns(); frame(true);
    let res;
    try {
      const job = await post(`/api/p/${pid}/prepinsert`, { path });
      res = await pollJob(job.id, (j) => {
        if (!pendingIns || !pendingIns.el) return;
        if (j.message) pendingIns.el.querySelector('.ig-txt').textContent = j.message + (j.progress > 0.02 ? ' · ' + Math.round(j.progress * 100) + '%' : '');
        pendingIns.bar.style.width = Math.round(Math.max(0.04, j.progress || 0) * 100) + '%';
      });
    } catch (e) { res = { status: 'error', error: e.message }; }
    if (pendingIns && pendingIns.el) { const ln = pendingIns.el.parentNode; pendingIns.el.remove(); if (ln) ln.classList.remove('pending'); }
    pendingIns = null;
    if (!alive) return;
    frame(true);
    if (res.status !== 'done') { toast('Non sono riuscito ad aggiungere il video: ' + (res.error || 'annullato'), true); return false; }
    const info = res.result;
    const rec = { id: uid('v'), at, dur: info.dur, offset: 0, file: info.file, name: opts.name || info.name, w: info.w, h: info.h, hasAudio: info.hasAudio, vcodec: info.vcodec };
    if (info.preview) rec.preview = info.preview;
    if (info.image) { rec.image = true; rec.fileDur = info.fileDur; rec.src = info.src; rec.iar = info.iar; }
    // arriva da una traccia sopra: stesso pezzo e stessa durata
    if (opts.offset && !info.image) rec.offset = Math.max(0, Math.min(info.dur - 0.2, opts.offset));
    if (opts.dur) rec.dur = +Math.max(0.2, Math.min((info.image ? info.fileDur : info.dur) - rec.offset, opts.dur)).toFixed(4);   // immagine: video fermo, si allunga quanto vuoi
    clipPeaks.set(rec.file, info.peaks || []);
    await applyInsert(rec, null);
    if (!opts.quiet) toast(info.image ? 'Immagine aggiunta: tira il bordo destro per farla durare di più' : 'Video aggiunto');
    // la trascrizione del video nuovo arriva dopo, senza bloccare
    if (proj.transcript && proj.transcript.status === 'done' && ENV_WHISPER()) transcribeInsert(rec);
    return true;
  }
  // fermo immagine: il fotogramma alla testina diventa una foto di 2 s in timeline (il resto scorre dopo)
  async function freezeFrame() {
    if (pendingIns) return toast('Un attimo: sto ancora aggiungendo l\'altro video.', true);
    video.pause();
    const t = +video.currentTime.toFixed(3);
    try {
      const r = await post(`/api/p/${pid}/freezeframe`, { t });
      if (await insertVideo(r.path, t, null, { dur: 2, quiet: true, name: 'Fermo immagine' })) toast('Fermo immagine aggiunto: tira il bordo destro per farlo durare di più');
    } catch (e) { toast(e.message, true); }
  }
  const ENV_WHISPER = () => !!(ctx.env && ctx.env.whisper);
  async function transcribeInsert(rec) {
    try {
      const job = await post(`/api/p/${pid}/inserttranscript`, { path: rec.file, dur: rec.dur, offset: rec.offset || 0 });
      const res = await pollJob(job.id, () => {});
      if (!alive || res.status !== 'done') return;
      const cur = (proj.inserts || []).find((x) => x.id === rec.id);
      if (!cur) return;
      const segs = (res.result.segments || []).map((sg) => ({ ...sg, a: sg.a + cur.at, b: sg.b + cur.at, words: (sg.words || []).map((w) => ({ ...w, a: w.a + cur.at, b: w.b + cur.at })) }));
      if (!segs.length) return;
      await flush();
      proj.transcript.segments = allWords().concat(segs).sort((x, y) => x.a - y.a);
      undoStack = undoStack.filter((x) => typeof x !== 'string'); redoStack = redoStack.filter((x) => typeof x !== 'string'); updateUndo();
      changed({ transcript: true });
      if (tab === 'text') renderPanel();
    } catch (e) { /* la trascrizione e' un di piu' */ }
  }
  // come CapCut: si spostano solo le clip della traccia principale (e le parole della live, che sono il suo audio);
  // tutto quello che sta sulle altre tracce (testi, immagini, video sopra, suoni, filtri, zoom) resta dov'e'
  function shiftAfter(t0, dt) {
    const sh = (x) => (x >= t0 - 1e-6 ? +(x + dt).toFixed(4) : x);
    for (const sg of allWords()) { sg.a = sh(sg.a); sg.b = sh(sg.b); for (const w of sg.words || []) { w.a = sh(w.a); w.b = sh(w.b); } }
    for (const i of proj.inserts || []) if (i.at >= t0 - 1e-6) i.at = +(i.at + dt).toFixed(4);
    const shV = (x, strict) => ((strict ? x > t0 + 1e-6 : x >= t0 - 1e-6) ? +(x + dt).toFixed(4) : x);
    for (const v of proj.verticals || []) { v.a = shV(v.a); v.b = shV(v.b, true); if (v.ranges) v.ranges = v.ranges.map(([a, b]) => [shV(a), shV(b, true)]); }
    const segs = [];
    for (const c of proj.segs) {
      if (c.b <= t0 + 1e-6) segs.push(c);
      else if (c.a >= t0 - 1e-6) { c.a = +(c.a + dt).toFixed(4); c.b = +(c.b + dt).toFixed(4); segs.push(c); }
      else { segs.push({ ...c, b: t0 }, { ...c, id: uid('s'), a: +(t0 + dt).toFixed(4), b: +(c.b + dt).toFixed(4) }); }
    }
    proj.segs = segs;
  }
  // il contrario: toglie il tratto [t0, t0+dt] e riporta indietro quello che segue
  function shiftBack(t0, dt) {
    const t1 = t0 + dt;
    const sh = (x) => (x >= t1 - 1e-6 ? +(x - dt).toFixed(4) : Math.min(x, t0));
    if (proj.transcript) {
      proj.transcript.segments = allWords().filter((sg) => !(sg.a >= t0 - 1e-6 && sg.b <= t1 + 1e-6)).map((sg) => {
        sg.words = (sg.words || []).filter((w) => !(w.a >= t0 - 1e-6 && w.b <= t1 + 1e-6));
        sg.a = sh(sg.a); sg.b = sh(sg.b); sg.words.forEach((w) => { w.a = sh(w.a); w.b = sh(w.b); });
        return sg;
      });
    }
    for (const i of proj.inserts || []) if (i.at >= t1 - 1e-6) i.at = +(i.at - dt).toFixed(4);
    for (const v of proj.verticals || []) { v.a = sh(v.a); v.b = sh(v.b); if (v.ranges) v.ranges = v.ranges.map(([a, b]) => [sh(a), sh(b)]).filter(([a, b]) => b - a > 0.05); }
    proj.verticals && (proj.verticals = proj.verticals.filter((v) => v.b - v.a > 0.2));
    proj.segs = proj.segs.map((c) => ({ ...c, a: sh(c.a), b: sh(c.b) })).filter((c) => c.b - c.a > 0.02);
  }
  const liveDur = () => proj.liveDuration || (D - (proj.inserts || []).reduce((s, i) => s + i.dur, 0));
  // mette il video in timeline (rec.at = dove). undoEntry: se e' un "ripeti"
  // --- parte "dati": mette / toglie un video inserito (niente disegno, niente salvataggio)
  function insertCore(rec, ownSegs) {
    let at = Math.max(0, Math.min(D, rec.at));
    for (const i of proj.inserts || []) if (i.at < at && at < i.at + i.dur) at = at - i.at < i.at + i.dur - at ? i.at : i.at + i.dur;
    if (at < 0.3) at = 0; else if (at > D - 0.3) at = D;
    rec.at = +at.toFixed(4);
    proj.liveDuration = liveDur();
    shiftAfter(rec.at, rec.dur);
    proj.inserts = (proj.inserts || []).concat([rec]).sort((a, b) => a.at - b.at);
    // le clip del video (se era stato diviso, velocizzato, spento… resta com'era)
    const segs = ownSegs && ownSegs.length
      ? ownSegs.map((c) => ({ ...c, a: +(rec.at + c.a).toFixed(4), b: +(rec.at + c.b).toFixed(4), ins: rec.id }))
      : [{ id: uid('s'), a: rec.at, b: +(rec.at + rec.dur).toFixed(4), removed: false, auto: false, vol: 100, mute: false, fin: false, fout: false, ins: rec.id }];
    proj.segs.push(...segs); proj.segs.sort((a, b) => a.a - b.a);
    if (rec.words && rec.words.length) proj.transcript.segments = allWords().concat(rec.words.map((sg) => ({ ...sg, a: sg.a + rec.at, b: sg.b + rec.at, words: (sg.words || []).map((w) => ({ ...w, a: w.a + rec.at, b: w.b + rec.at })) }))).sort((x, y) => x.a - y.a);
    delete rec.words;
    D = proj.liveDuration + proj.inserts.reduce((s2, i) => s2 + i.dur, 0);
    proj.duration = D;
    return segs;
  }
  function removeCore(id) {
    const rec = (proj.inserts || []).find((x) => x.id === id);
    if (!rec) return null;
    const words = allWords().filter((sg) => sg.a >= rec.at - 1e-6 && sg.b <= rec.at + rec.dur + 1e-6);
    const own = proj.segs.filter((c) => c.ins === id).map((c) => ({ ...c, a: +(c.a - rec.at).toFixed(4), b: +(c.b - rec.at).toFixed(4) }));
    const copy = { ...rec, words: words.map((sg) => ({ ...sg, a: sg.a - rec.at, b: sg.b - rec.at, words: (sg.words || []).map((w) => ({ ...w, a: w.a - rec.at, b: w.b - rec.at })) })) };
    proj.segs = proj.segs.filter((c) => c.ins !== id);
    proj.inserts = proj.inserts.filter((x) => x.id !== id);
    shiftBack(rec.at, rec.dur);
    D = proj.liveDuration + proj.inserts.reduce((s2, i) => s2 + i.dur, 0);
    proj.duration = D;
    return { copy, own };
  }
  // l'inserimento, lo spostamento e la loro storia (Ctrl+Z / Ctrl+Y): la storia di prima non vale piu' (i tempi cambiano)
  // ---------------------------------------------------------------- calamita della traccia principale e spazi vuoti
  // Calamita accesa (come prima): le clip principali stanno attaccate. Spenta: si possono lasciare spazi vuoti (neri)
  function magnetOn() { return IS_V || proj.settings.magnet !== false; }
  const insById = (id) => (proj.inserts || []).find((x) => x.id === id);
  const isGapSeg = (c) => !!(c && c.ins && (insById(c.ins) || {}).gap);
  let gapInfo = null;
  async function getGap() { if (!gapInfo) gapInfo = await post(`/api/p/${pid}/gapfile`, {}); return gapInfo; }
  function fullSnap() {
    return JSON.stringify({ inserts: proj.inserts || [], segs: proj.segs, tracks: proj.tracks, zooms: proj.zooms, filters: proj.filters, verticals: proj.verticals || [],
      tr: proj.transcript ? proj.transcript.segments : null, duration: proj.duration, liveDuration: proj.liveDuration });
  }
  async function fullRestore(snap) {
    const s2 = JSON.parse(snap);
    Object.assign(proj, { inserts: s2.inserts, segs: s2.segs, tracks: s2.tracks, zooms: s2.zooms, filters: s2.filters, verticals: s2.verticals, duration: s2.duration, liveDuration: s2.liveDuration });
    if (s2.tr && proj.transcript) proj.transcript.segments = s2.tr;
    D = proj.duration; sel = null; multi = [];
    await afterDurationChange();
    changed({ transcript: true });
  }
  // passi "completi" (cambiano i tempi della timeline): si annullano uno alla volta
  function pushFull(snap) { undoStack = undoStack.filter((x) => typeof x === 'object' && x.kind === 'full'); undoStack.push({ kind: 'full', snap }); redoStack = []; updateUndo(); }
  const segById = (id) => proj.segs.find((x) => x.id === id);
  const gapBefore = (c) => proj.segs.find((x) => !x.gone && isGapSeg(x) && Math.abs(x.b - c.a) < 2e-3);
  const gapAfter = (c) => proj.segs.find((x) => !x.gone && isGapSeg(x) && Math.abs(x.a - c.b) < 2e-3);
  function addGapCore(g, at, dur) {
    insertCore({ id: uid('v'), at: +at.toFixed(4), dur: +dur.toFixed(4), offset: 0, file: g.file, name: 'Spazio vuoto', w: g.w, h: g.h, hasAudio: false, vcodec: 'h264', gap: true });
  }
  function shrinkGapCore(g, seg, by) {
    const rec = insById(seg.ins);
    if (!rec) return;
    const at = rec.at, len = rec.dur;
    removeCore(rec.id);
    if (len - by > 0.03) addGapCore(g, at, len - by);
  }
  // sposta una clip della traccia principale di dt secondi, lasciando (o chiudendo) spazio vuoto.
  // Da sola: le clip dopo restano ferme finche' c'e' spazio. In gruppo ("seleziona a destra"): si sposta tutto insieme.
  // ---- calamita spenta: la traccia principale diventa una semplice fila di clip (ognuna un pezzo di un file) e
  // spazi vuoti. Ogni operazione cambia la fila e la ricostruisce: niente pezzi nascosti, tempi sempre giusti.
  function mainItems() {
    return proj.segs.filter((c) => !c.gone && !(BLANK && !c.ins)).sort((x, y) => x.a - y.a).map((c) => {
      const d = mainClipData(c);
      const rec = c.ins && insById(c.ins);
      // la clip e' ancora un video inserito intero: tiene il suo id (forma d'onda e miniature gia' pronte)
      const whole = rec && Math.abs(rec.at - c.a) < 1e-3 && Math.abs(rec.at + rec.dur - c.b) < 1e-3;
      return { ...d, keepId: whole ? rec.id : null, segId: c.id };
    });
  }
  const gapItem = (g, dur) => ({ file: g.file, offset: 0, live: false, gap: true, name: 'Spazio vuoto', w: g.w, h: g.h, hasAudio: false, vcodec: 'h264', dur: +dur.toFixed(4),
    seg: { removed: false, auto: false, vol: 100, mute: false, fin: false, fout: false }, words: [] });
  function tidyItems(items, g) {
    const out = [];
    for (const it of items) {
      if (it.dur < 0.02) continue;
      const last = out[out.length - 1];
      if (it.gap && last && last.gap) { last.dur = +(last.dur + it.dur).toFixed(4); continue; }   // spazi attaccati: uno solo
      out.push(it.gap ? { ...gapItem(g, it.dur) } : it);
    }
    while (out.length && out[out.length - 1].gap) out.pop();   // spazio vuoto in fondo: non serve
    return out;
  }
  // tempo di adesso -> tempo senza i pezzi nascosti (per rimettere testi, zoom, filtri al loro posto a vista)
  function goneMapper() {
    const gr = proj.segs.filter((c) => c.gone && !(BLANK && !c.ins)).map((c) => [c.a, c.b]).sort((x, y) => x[0] - y[0]);
    if (!gr.length) return null;
    return (t) => { let d = 0; for (const [a, b] of gr) { if (t >= b) d += b - a; else if (t > a) d += t - a; } return +(t - d).toFixed(4); };
  }
  function rebuildMain(items) {
    const G = goneMapper();
    if (G) {   // la prima volta: testi, immagini, suoni, zoom, filtri e clip verticali seguono le clip a vista
      for (const tr of proj.tracks || []) if (tr.type !== 'live') (tr.clips || []).forEach((c) => { c.a = G(c.a); });
      (proj.zooms || []).forEach((z) => { z.a = G(z.a); z.b = Math.max(z.a + 0.1, G(z.b)); });
      (proj.filters || []).forEach((f) => { f.a = G(f.a); f.b = Math.max(f.a + 0.1, G(f.b)); });
      for (const v of proj.verticals || []) { v.a = G(v.a); v.b = G(v.b); if (v.ranges) v.ranges = v.ranges.map(([a, b]) => [G(a), G(b)]); }
    }
    const liveD = liveDur();
    const ins = [], segs = [], words = [];
    let at = 0;
    for (const it of items) {
      const id = it.keepId || uid('v');
      const rec = { id, at: +at.toFixed(4), dur: it.dur, offset: it.offset || 0, file: it.file, name: it.name, w: it.w, h: it.h, hasAudio: it.hasAudio, vcodec: it.vcodec };
      if (it.live) rec.live = true;
      if (it.gap) rec.gap = true;
      if (it.preview) rec.preview = it.preview;
      if (it.image) { rec.image = true; rec.fileDur = it.fileDur; rec.src = it.src; rec.iar = it.iar; }
      ins.push(rec);
      segs.push({ ...it.seg, id: it.segId || uid('s'), a: rec.at, b: +(at + it.dur).toFixed(4), ins: id, gone: false, fill: undefined });
      for (const sg of it.words || []) words.push({ ...sg, a: sg.a + at, b: sg.b + at, words: (sg.words || []).map((w2) => ({ ...w2, a: w2.a + at, b: w2.b + at })) });
      at += it.dur;
    }
    // la live (o il nero del progetto vuoto) resta in fondo, nascosta: e' solo la base da cui si leggono le clip
    const tail = { id: uid('s'), a: +at.toFixed(4), b: +(at + liveD).toFixed(4), removed: !BLANK, gone: !BLANK, auto: false, vol: 100, mute: false, fin: false, fout: false };
    proj.inserts = ins;
    proj.segs = segs.concat([tail]);
    proj.liveDuration = liveD;
    proj.duration = +(at + liveD).toFixed(4);
    D = proj.duration;
    if (proj.transcript && proj.transcript.segments) proj.transcript.segments = words.sort((x, y) => x.a - y.a);
  }
  // una clip sola: si sposta solo lei. Al suo posto resta spazio vuoto; nel punto scelto entra nello spazio vuoto
  // (se ci sta) senza muovere le altre, se no si mette al bordo della clip piu' vicina
  function freeMoveSingle(cid, dv, g, grab = 0) {
    const items = mainItems();
    const k = items.findIndex((it) => it.segId === cid);
    if (k < 0) return false;
    const c = segById(cid);
    const t = T(Math.max(0, V(c.a) + dv));   // dove la vuoi (tempo di adesso)
    const X_ = items[k];
    let acc = 0;
    const G = goneMapper(), tt = G ? G(t) : t;   // stessa scala della fila
    items[k] = gapItem(g, X_.dur);
    let list = tidyItems(items, g);
    const st2 = []; acc = 0;
    for (const it of list) { st2.push(acc); acc += it.dur; }
    const end = acc;
    if (tt >= end - 1e-3) {
      if (tt - end > 0.03) list.push(gapItem(g, tt - end));
      list.push(X_);
    } else {
      const j = st2.findIndex((s0, i) => tt >= s0 - 1e-3 && tt < s0 + list[i].dur);
      const it = list[j];
      // dove c'e' il puntatore (non l'inizio della clip): e' li' che l'utente la vuole
      const tp = Math.min(end - 1e-3, tt + Math.max(0, Math.min(X_.dur, grab)));
      const jp = st2.findIndex((s0, i) => tp >= s0 - 1e-3 && tp < s0 + list[i].dur);
      const want = it ? tt - st2[j] : 0, fitB = it ? Math.max(0, Math.min(it.dur - X_.dur, want)) : 0;
      if (it && it.gap && it.dur >= X_.dur - 1e-3 && Math.abs(fitB - want) <= Math.max(0.5, X_.dur * 0.3)) {
        // lo spazio vuoto basta: la clip ci entra (se sborda di poco, si aggancia dentro)
        const before = fitB, after = it.dur - before - X_.dur;
        list.splice(j, 1, gapItem(g, before), X_, gapItem(g, after));
      } else {
        // sopra un'altra clip: prima o dopo di lei, secondo dove sta il puntatore
        const ip = jp >= 0 ? jp : list.length - 1, pi = list[ip];
        if (pi && pi.gap && pi.dur >= X_.dur - 1e-3) {
          const before = Math.max(0, Math.min(pi.dur - X_.dur, tp - grab - st2[ip]));
          list.splice(ip, 1, gapItem(g, before), X_, gapItem(g, pi.dur - before - X_.dur));
        } else list.splice(pi && tp - st2[ip] < pi.dur / 2 ? ip : ip + 1, 0, X_);
      }
    }
    rebuildMain(tidyItems(list, g));
    return true;
  }
  // gruppo ("seleziona a destra"): si sposta tutto insieme, aggiungendo o togliendo spazio vuoto prima della prima clip
  function freeMoveGroup(cid, dt, g, groupItems) {
    const items = mainItems();
    const k = items.findIndex((it) => it.segId === cid);
    if (k < 0) return false;
    let eff = 0;
    const prev = items[k - 1];
    if (dt > 0.02) {
      if (prev && prev.gap) prev.dur = +(prev.dur + dt).toFixed(4); else items.splice(k, 0, gapItem(g, dt));
      eff = dt;
    } else if (dt < -0.02) {
      if (!prev || !prev.gap) { toast('Prima di queste clip non c\'è spazio vuoto da togliere'); return false; }
      const take = Math.min(-dt, prev.dur);
      prev.dur = +(prev.dur - take).toFixed(4);
      eff = -take;
    } else return false;
    rebuildMain(tidyItems(items, g));
    for (const it of groupItems) {
      const o = findSel(it);
      if (!o) continue;
      if (o.b !== undefined) { const len = o.b - o.a; o.a = +Math.max(0, o.a + eff).toFixed(3); o.b = +(o.a + len).toFixed(3); }
      else o.a = +Math.max(0, o.a + eff).toFixed(3);
    }
    return true;
  }
  async function freeMove(cid, dv, isGroup, groupItems, grab = 0) {
    let g;
    try { g = await getGap(); } catch (e) { toast('Non riesco a preparare lo spazio vuoto: ' + e.message, true); return; }
    const snap = fullSnap();
    const ok = isGroup ? freeMoveGroup(cid, dv, g, groupItems) : freeMoveSingle(cid, dv, g, grab);
    if (!ok) return;
    sel = null; multi = [];
    pushFull(snap);
    lightRefresh();
  }
  // dopo uno spostamento: si ridisegna la timeline e basta (le miniature restano, niente ricaricamenti)
  function lightRefresh() {
    refreshGone(); lastViewEnd = NaN; refit();   // lo zoom della timeline resta quello scelto
    composeWave();
    dirty = true; scheduleSave();
    changed({ transcript: true });
  }
  function startFreeMove(e, seg, el) {
    const x0 = e.clientX, y0 = e.clientY;
    const isGroup = multi.length > 1 && multi.some((m) => isSeg(m.type) && m.id === seg.id);
    const group = isGroup ? multi.filter((m) => ['sclip', 'zoom', 'fx'].includes(m.type)) : [];
    // cosa si muove a vista: la clip (o tutte quelle dopo, se e' un gruppo) e gli elementi del gruppo
    const moving = [];
    lanes.querySelectorAll('.blk').forEach((b) => {
      const id = b.dataset.id, ty = b.dataset.type;
      if (!id) return;
      if (isSeg(ty) && (id === seg.id || (isGroup && (segById(id) || {}).a >= seg.a - 1e-3))) moving.push(b);
      else if (group.some((m) => m.id === id && m.type === ty)) moving.push(b);
    });
    let moved = false, dx = 0, lift = null, xLane = null;
    const grab = Math.max(0, tAt(e) - seg.a);   // dove l'hai presa, dentro la clip
    capPtr(el, e.pointerId);
    const mv = (ev) => {
      if (!moved && Math.abs(ev.clientX - x0) < 5 && Math.abs(ev.clientY - y0) < 5) return;
      if (!moved) lift = liftVisual(moving.filter((b) => isSeg(b.dataset.type)).map((b) => b.dataset.id));
      moved = true;
      dx = ev.clientX - x0;
      if (isGroup) {   // il gruppo va a sinistra solo se prima c'e' spazio vuoto
        const gb = gapBefore(seg);
        dx = Math.max(dx, gb ? -(gb.b - gb.a) * pps : 0);
      } else dx = Math.max(dx, -X(seg.a));
      moving.forEach((b) => { b.style.transform = `translateX(${dx}px)`; b.classList.add('lifted'); });
      if (lift) lift.move(dx, !isGroup && canLeaveMain(seg) ? ev.clientY - y0 : 0);
      xLane = !isGroup && canLeaveMain(seg) ? upTarget(ev) : null;
      markLane(xLane && xLane.lane);
    };
    const up = async (ev) => {
      el.removeEventListener('pointermove', mv);
      moving.forEach((b) => { b.style.transform = ''; b.classList.remove('lifted'); });
      if (!moved) { tapSeek(ev, Math.max(seg.a, Math.min(seg.b - 0.05, tAt(ev)))); return; }
      markLane(null); hideUpLine();
      if (xLane) { if (lift) lift.done(); await mainToOverlay(seg, xLane, tAt(ev) - grab); return; }
      if (Math.abs(dx) >= 2) await freeMove(seg.id, dx / pps, isGroup, group, grab);
      if (lift) lift.done();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }
  async function setMainMagnet(on) {
    if (on === magnetOn()) return;
    if (on) {
      // calamita accesa: gli spazi vuoti si chiudono
      const gaps = proj.segs.filter((c) => !c.gone && isGapSeg(c));
      if (gaps.length) {
        const snap = fullSnap();
        rebuildMain(mainItems().filter((it) => !it.gap));
        pushFull(snap);
        lightRefresh();
      }
    }
    proj.settings.magnet = on;
    mainMagBtn.setAttribute('aria-pressed', String(on));
    changed();
    toast(on ? 'Calamita accesa: le clip principali restano attaccate' : 'Calamita spenta: puoi lasciare spazi vuoti tra le clip');
  }
  // seleziona tutto quello che c'e' a destra (o a sinistra) della testina: poi si sposta insieme
  function selectSide(dir) {
    const t = video.currentTime, out = [];
    const ok = (a, b) => (dir > 0 ? a >= t - 1e-3 : b <= t + 1e-3);
    for (const c of proj.segs) if (!c.gone && !(BLANK && !c.ins) && ok(c.a, c.b)) out.push({ type: 'seg', id: c.id });
    for (const tr of proj.tracks || []) if (tr.type !== 'live') for (const c of tr.clips || []) if (ok(c.a, c.a + (c.dur || 0))) out.push({ type: 'sclip', id: c.id });
    for (const z of proj.zooms || []) if (ok(z.a, z.b)) out.push({ type: 'zoom', id: z.id });
    for (const f of proj.filters || []) if (ok(f.a, f.b)) out.push({ type: 'fx', id: f.id });
    if (!out.length) { toast(dir > 0 ? 'Non c\'è niente dopo la testina' : 'Non c\'è niente prima della testina'); return; }
    multi = out.length > 1 ? out : []; sel = { ...out[dir > 0 ? 0 : out.length - 1] };
    renderTimeline(); renderPanel();
    toast(`${out.length} elementi selezionati: trascinali per spostarli insieme` + (magnetOn() && out.some((m) => m.type === 'seg') ? ' (per spostare anche le clip principali spegni la calamita)' : ''));
  }
  // progetto vuoto: un video messo nella traccia principale prende il posto del nero (dalla fine), cosi' la durata non cresce
  function consumeBlack(d) {
    const cand = proj.segs.filter((c) => !c.ins && !c.gone).sort((x, y) => y.a - x.a);
    for (const c of cand) {
      if (d <= 1e-3) break;
      const take = Math.min(d, c.b - c.a);
      if (take >= c.b - c.a - 1e-3) Object.assign(c, { gone: true, removed: true, fill: true });
      else { const nb = +(c.b - take).toFixed(4); proj.segs.push({ ...c, id: uid('s'), a: nb, b: c.b, gone: true, removed: true, fill: true }); c.b = nb; }
      d -= take;
    }
    proj.segs.sort((x, y) => x.a - y.a);
  }
  function restoreBlack(d) {
    const cand = proj.segs.filter((c) => !c.ins && c.fill).sort((x, y) => x.a - y.a);
    for (const c of cand) {
      if (d <= 1e-3) break;
      const take = Math.min(d, c.b - c.a);
      if (take >= c.b - c.a - 1e-3) { c.gone = false; c.removed = false; delete c.fill; }
      else { const na = +(c.a + take).toFixed(4); proj.segs.push({ ...c, id: uid('s'), a: c.a, b: na, gone: false, removed: false, fill: undefined }); c.a = na; }
      d -= take;
    }
    proj.segs.sort((x, y) => x.a - y.a);
  }
  async function applyInsert(rec, again, ownSegs) {
    const segs = insertCore(rec, ownSegs);
    undoStack = [{ kind: 'insert', id: rec.id }]; if (!again) redoStack = [];
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id }; tab = 'video';
    changed({ transcript: true });
    seek(rec.at + 0.05);
  }
  async function removeInsert(id) {
    const r = removeCore(id);
    if (!r) return null;
    sel = null;
    await afterDurationChange();
    changed({ transcript: true });
    seek(Math.max(0, r.copy.at - 0.05));
    return { ...r.copy, own: r.own };
  }
  // sposta un video inserito in un altro punto della traccia principale (target = tempo prima dello spostamento)
  async function moveInsert(id, target, fromHistory) {
    const rec = (proj.inserts || []).find((x) => x.id === id);
    if (!rec) return false;
    if (target >= rec.at - 1e-3 && target <= rec.at + rec.dur + 1e-3) return false;   // stesso posto
    const from = rec.at;
    const r = removeCore(id);
    const at = target > from ? target - r.copy.dur : target;
    const segs = insertCore({ ...r.copy, at }, r.own);
    if (!fromHistory) { undoStack = [{ kind: 'move', id, back: from }]; redoStack = []; }
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id };
    changed({ transcript: true });
    seek(segs[0].a + 0.05);
    return true;
  }
  async function afterDurationChange() {
    // la scala (zoom della timeline) resta quella scelta: si ricalcola solo quanto vale "tutto"
    refreshGone(); lastViewEnd = NaN; refit();
    composeWave();
    dirty = true; await flush();   // il server deve sapere dei file nuovi prima che l'anteprima li chieda
    drawThumbs();   // le miniature sono legate ai file, non alla posizione: si riusano quelle che ci sono
  }
  // forma d'onda della timeline: la live a pezzi + quella dei video inseriti
  function composeWave() {
    if (!waveLive) return;
    const ps = waveLive.perSec || 5, lp = waveLive.peaks || [];
    const list = (proj.inserts || []).slice().sort((a, b) => a.at - b.at);
    if (!list.length) { wave = waveLive; drawWave(); return; }
    const out = [];
    let T0 = 0, L = 0;
    const put = (src, a0, n) => { for (let k = 0; k < n; k++) out.push(src[a0 + k] || 0); };
    for (const i of list) {
      if (i.at > T0 + 1e-6) { const n = Math.round((i.at - T0) * ps); put(lp, Math.round(L * ps), n); L += i.at - T0; T0 = i.at; }
      if (i.live) { put(lp, Math.round((i.offset || 0) * ps), Math.round(i.dur * ps)); T0 += i.dur; continue; }
      if (i.gap) { put([], 0, Math.round(i.dur * ps)); T0 += i.dur; continue; }
      const cp = clipPeaks.get(i.file);   // per file: le clip spostate o divise usano la stessa forma d'onda
      if (!cp && i.image) clipPeaks.set(i.file, []);   // foto: niente audio da leggere
      else if (!cp) { clipPeaks.set(i.file, []); get(`/api/p/${pid}/clipwave?path=${encodeURIComponent(i.file)}`).then((w) => { clipPeaks.set(i.file, w.peaks || []); composeWave(); }).catch(() => {}); }
      put(cp || [], Math.round((i.offset || 0) * ps), Math.round(i.dur * ps));
      T0 += i.dur;
    }
    put(lp, Math.round(L * ps), Math.round((liveDur() - L) * ps) + 1);
    wave = { perSec: ps, peaks: out };
    drawWave();
  }

  // ---------------------------------------------------------------- finestra di esportazione
  const EXPORT_DEFAULT = { dir: '', format: 'mp4', codec: 'h264', bitrate: 'rec', fps: 'source', audio: true, abr: 192 };
  const BPP = { low: 0.05, rec: 0.1, high: 0.18 };   // uguale a engine/render.py
  function fmtSize(b) { return b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB'; }
  function fmtLong(t) { t = Math.round(t); const hh = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60; return (hh ? hh + 'h ' : '') + (hh || m ? m + 'm ' : '') + s + 's'; }
  async function openExport() {
    if (outDuration() < 1) return toast(BLANK ? 'Il progetto è vuoto: trascina un video nella timeline o aggiungi un testo.' : 'Hai tagliato tutto il video.', true);
    video.pause();
    const S = proj.settings;
    const E = { ...EXPORT_DEFAULT, ...(S.export || {}) };
    let quality = S.quality, name = proj.name;
    const srcFps = proj.fps || 30;
    const resOpts = [2160, 1440, 1080, 720, 480].filter((x) => x <= H + 8).map((x) => [x + 'p', x === 2160 ? '4K' : x + 'p']);
    if (!resOpts.some(([v]) => v === quality)) quality = resOpts[0][0];
    const fpsOpts = [['source', `Originale (${Math.round(srcFps)} fps)`], ...[60, 50, 30, 25, 24].filter((f) => f < srcFps - 0.5).map((f) => [String(f), f + ' fps'])];
    const sel_ = (opts, cur, onCh) => {
      const s2 = h('select', { class: 'input xsel' }, ...opts.map(([v, l]) => h('option', { value: v, selected: String(v) === String(cur) ? true : null }, l)));
      s2.addEventListener('change', () => { onCh(s2.value); update(); });
      return s2;
    };
    const row = (label, ctl, tip) => h('div', { class: 'xrow', 'data-tip': tip || null }, h('span', { class: 'xl' }, label), ctl);
    // anteprima: il fotogramma che stai guardando
    const cover = VERT ? h('canvas', { class: 'xcover vert', width: '360', height: '640' }) : h('canvas', { class: 'xcover', width: '640', height: String(Math.round(640 * H / W)) });
    try {
      const g = cover.getContext('2d');
      if (VERT) {
        // come sara' il video verticale in questo punto
        const { regs, el, sx, sy } = vRegsAt(video.currentTime);
        for (const rg of regs) {
          const [dx, dy, dw, dh] = rg.d, [x, y, w, hh] = rg.s;
          g.filter = rg.blur && !softFx() ? 'blur(10px) brightness(0.93)' : 'none';
          g.drawImage(el, x * sx, y * sy, w * sx, hh * sy, dx * 360, dy * 640, dw * 360, dh * 640);
        }
      } else g.drawImage(video.el, 0, 0, cover.width, cover.height);
    } catch (e) { /* */ }
    const nameInp = h('input', { class: 'input', value: name, maxlength: '120', 'aria-label': 'Nome' });
    nameInp.addEventListener('input', () => { name = nameInp.value; update(); });
    const dirLbl = h('span', { class: 'xpath' });
    const dirBtn = ibtn('folder', 'Scegli la cartella', async () => {
      try {
        const r = await post('/api/pick', { kind: 'folder' });
        if (r.fallback) { const v = prompt('Cartella dove salvare il video:', E.dir || env.exportsDir || ''); if (v) E.dir = v.trim().replace(/^"|"$/g, ''); }
        else if (r.path) E.dir = r.path;
        update();
      } catch (e) { toast(e.message, true); }
    }, { size: 16 });
    // cosa esportare: questa timeline, le sue clip verticali e le altre timeline del progetto
    const VL = IS_V ? [] : proj.verticals;
    const OT = IS_V ? [] : timelines.filter((t) => t.id !== pid);   // le altre timeline
    const MANY = VL.length + OT.length > 0;
    const want = { vod: true, verticals: [], tls: [] };
    if (S.exportWant && MANY) {
      want.vod = S.exportWant.vod !== false;
      want.verticals = (S.exportWant.verticals || []).filter((id) => VL.some((v) => v.id === id));
      want.tls = (S.exportWant.tls || []).filter((id) => OT.some((t) => t.id === id));
    }
    const nSel = () => (want.vod ? 1 : 0) + want.verticals.length + want.tls.length;
    const whatBox = h('div', { class: 'xgroup xwhat' });
    function drawWhat() {
      const ck = (on, label, sub, fn, ic) => h('label', { class: 'xck' + (on ? ' on' : '') },
        h('input', { type: 'checkbox', checked: on ? true : null, onchange: (e) => { fn(e.target.checked); drawWhat(); update(); } }),
        h('span', { class: 'xck-ic' }, icon(ic, 14, 'currentColor', 2)), h('span', { class: 'xck-nm', 'data-notr': '' }, label), h('span', { class: 'xck-sub' }, sub));
      const all = want.vod && want.verticals.length === VL.length && want.tls.length === OT.length;
      const only = want.vod && nSel() === 1;
      const fmtTxt = VERT ? '9:16' : proj.width < proj.height ? '9:16' : Math.abs(W / H - 1) < 0.05 ? '1:1' : '16:9';
      whatBox.replaceChildren(
        h('div', { class: 'xwhat-q' },
          h('button', { class: 'pchip' + (only ? ' on' : ''), onclick: () => { want.vod = true; want.verticals = []; want.tls = []; drawWhat(); update(); } }, OT.length ? 'Solo questa timeline' : 'Solo il video'),
          h('button', { class: 'pchip' + (all ? ' on' : ''), onclick: () => { want.vod = true; want.verticals = VL.map((v) => v.id); want.tls = OT.map((t) => t.id); drawWhat(); update(); } }, 'Tutto'),
          VL.length ? h('button', { class: 'pchip' + (!want.vod && !want.tls.length && want.verticals.length === VL.length ? ' on' : ''), onclick: () => { want.vod = false; want.tls = []; want.verticals = VL.map((v) => v.id); drawWhat(); update(); } }, 'Solo le verticali') : null),
        ck(want.vod, name.trim() || proj.name, fmtTxt + ' · ' + fmtLong(outDuration()) + (OT.length ? ' · questa timeline' : ''), (v) => { want.vod = v; }, OT.length ? 'timeline' : 'film'),
        ...VL.map((v) => ck(want.verticals.includes(v.id), v.name, '9:16 · clip verticale', (on) => { want.verticals = on ? [...want.verticals, v.id] : want.verticals.filter((x) => x !== v.id); }, 'phone')),
        ...OT.map((t) => ck(want.tls.includes(t.id), t.name, 'altra timeline del progetto', (on) => { want.tls = on ? [...want.tls, t.id] : want.tls.filter((x) => x !== t.id); }, 'timeline')));
    }
    const audioOpts = h('div', { class: 'xgroup' });
    const audioTgl = toggle(E.audio, (v) => { E.audio = v; audioTgl.setAttribute('aria-pressed', String(v)); update(); }, 'Audio');
    const info = h('span', { class: 'xinfo' });
    const warn = h('span', { class: 'xwarn' });
    const vgroup = h('div', { class: 'xgroup' },
      row('Risoluzione', sel_(resOpts, quality, (v) => { quality = v; })),
      row('Bitrate', sel_([['low', 'Più leggero'], ['rec', 'Consigliato'], ['high', 'Alta qualità']], E.bitrate, (v) => { E.bitrate = v; }), 'Più alto = più qualità ma file più pesante'),
      row('Codec', sel_([['h264', 'H.264 · funziona ovunque'], ['h265', 'HEVC (H.265) · file più leggero']], E.codec, (v) => { E.codec = v; })),
      row('Formato', sel_([['mp4', 'mp4'], ['mov', 'mov']], E.format, (v) => { E.format = v; })),
      row('Fotogrammi', sel_(fpsOpts, E.fps, (v) => { E.fps = v; })));
    audioOpts.append(row('Qualità audio', sel_([['128', '128 kbps'], ['192', '192 kbps'], ['320', '320 kbps']], E.abr, (v) => { E.abr = +v; })));
    function update() {
      const qh = Math.min(parseInt(quality, 10) || H, H);
      let oh = Math.floor(qh / 2) * 2, ow = Math.round(oh * W / H / 2) * 2;
      if (VERT) { ow = Math.max(2, Math.round(qh / 2) * 2); oh = Math.max(2, Math.round(ow * 16 / 9 / 2) * 2); }   // come engine/vertical.py
      const f = E.fps === 'source' ? srcFps : Math.min(srcFps, +E.fps);
      const vbr = (BPP[E.bitrate] || 0.1) * ow * oh * f * (E.codec === 'h265' ? 0.6 : 1);
      const bytes = outDuration() * (vbr + (E.audio ? E.abr * 1000 : 0)) / 8;
      info.textContent = `Durata: ${fmtLong(outDuration())}  ·  ${ow}×${oh}  ·  Dimensioni: circa ${fmtSize(bytes)}`;
      const dir = E.dir || env.exportsDir || '';
      const sep = dir.includes('\\') ? '\\' : '/';
      const nOut = nSel();
      const safe = (x) => (x.trim() || 'video').replace(/[\\/:*?"<>|]+/g, '_');
      let full = dir + sep + safe(name) + '.' + E.format;
      if (want.tls.length) {
        full = nOut > 1 ? dir + sep + safe(IS_TL ? proj.parentName || name : name) + sep : dir + sep + safe(OT.find((t) => t.id === want.tls[0]).name) + '.' + E.format;
        go.disabled = !nOut;
        info.textContent = nOut > 1 ? `${nOut} video in una cartella` : '1 video';
      } else if (VL.length) {
        if (want.vod && want.verticals.length) full = dir + sep + safe(name) + sep;
        else if (!want.vod && want.verticals.length > 1) full = dir + sep + safe(name) + ' - Clip verticali' + sep;
        else if (!want.vod && want.verticals.length === 1) full = dir + sep + safe(VL.find((v) => v.id === want.verticals[0]).name) + '.' + E.format;
        go.disabled = !nOut;
        if (nOut > 1) info.textContent = `${nOut} video` + (want.vod ? ` · orizzontale ${fmtLong(outDuration())} + ${want.verticals.length} ${want.verticals.length === 1 ? 'clip verticale' : 'clip verticali'} in "Clip verticali"` : ' verticali in una cartella');
        else if (!want.vod) info.textContent = '1 clip verticale';
      } else if (OT.length) go.disabled = !nOut;
      dirLbl.textContent = full.length > 46 ? '…' + full.slice(-45) : full;
      dirLbl.dataset.tip = full;
      audioOpts.style.display = E.audio ? '' : 'none';
      warn.textContent = E.codec === 'h265' ? 'HEVC: su alcuni PC Windows vecchi serve un\'estensione per vederlo. YouTube lo accetta.' : '';
    }
    const bg = h('div', { class: 'modal-bg xbg' });
    const close = () => { bg.remove(); document.removeEventListener('keydown', onK, true); };
    const onK = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onK, true);
    const go = h('button', { class: 'btn primary', onclick: async () => {
      const nm = name.trim(); if (!nm) { nameInp.focus(); return; }
      go.disabled = true;
      begin(); proj.name = nm; S.quality = quality; S.export = { ...E };
      if (MANY) S.exportWant = { vod: want.vod, verticals: want.verticals.slice(), tls: want.tls.slice() };
      dirty = true;
      await textsSaved(); await kineticReady(); dirty = true; await flush();
      close();
      if (want.tls.length) {
        // piu' timeline: l'esportazione parte dal progetto principale, che le conosce tutte
        const main = timelines.find((t) => t.main);
        const rootSel = IS_TL ? want.tls.includes(main.id) : want.vod;
        const tls = want.tls.filter((id) => id !== main.id).concat(IS_TL && want.vod ? [pid] : []);
        ctx.nav('export', main.id, { vod: rootSel, timelines: tls, verticals: want.verticals.slice(), back: pid, export: { ...E }, quality });
      } else ctx.nav('export', pid, VL.length && (want.verticals.length || !want.vod) ? { vod: want.vod, verticals: want.verticals.slice() } : undefined);
    } }, 'Esporta');
    bg.append(h('div', { class: 'xmodal', role: 'dialog', 'aria-label': 'Esporta' },
      h('div', { class: 'xhead' }, h('span', null, 'Esporta'), ibtn('x', 'Chiudi', close, { size: 16 })),
      h('div', { class: 'xbody' },
        h('div', { class: 'xleft' }, cover),
        h('div', { class: 'xright' },
          row('Nome', nameInp),
          row('Esporta su', h('div', { class: 'xdir' }, dirLbl, dirBtn)),
          MANY ? h('div', { class: 'xsec' }, h('span', null, 'Cosa esporti')) : null, MANY ? whatBox : null,
          h('div', { class: 'xsec' }, h('span', null, 'Video')), vgroup,
          h('div', { class: 'xsec' }, h('span', null, 'Audio'), audioTgl), audioOpts,
          warn)),
      h('div', { class: 'xfoot' }, icon('film', 16), info, h('div', { class: 'grow' }), h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
    if (MANY) drawWhat();
    update();
  }
  // scorciatoia sempre in vista: passa il progetto a un altro PC (file .vodcut)
  const shareBtn = ibtn('share', 'Passa il progetto a un altro PC (file .vodcut)', () => saveProjectFile(), { key: 'Ctrl+Maiusc+S', size: 16 });
  ctx.topRight.append(savedLabel, exportBtn);

  // divisori trascinabili: pannello a destra (larghezza) e timeline (altezza), come CapCut/Premiere
  let panelW = store.get('panelW', 350), tlH = store.get('tlH', null), leftW = store.get('leftW', 300);
  const splitV = h('div', { class: 'split-v', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': 'Ridimensiona il pannello', title: 'Trascina per ridimensionare · doppio clic per ripristinare' });
  const splitH = h('div', { class: 'split-h', role: 'separator', 'aria-orientation': 'horizontal', 'aria-label': 'Ridimensiona la timeline', title: 'Trascina per ridimensionare · doppio clic per ripristinare' });
  const splitL = h('div', { class: 'split-v', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': 'Ridimensiona il pannello a sinistra', title: 'Trascina per ridimensionare · doppio clic per ripristinare' });
  const edTop = h('div', { class: 'ed-top' }, leftPanel, splitL, viewer, splitV, panel);
  const root = h('main', { class: 'editor' }, edTop, splitH, tl);
  // layout per i video verticali (come CapCut): anteprima alta a destra, pannelli e timeline a sinistra
  const vlCol = h('div', { class: 'vl-col' });
  const LKEY = 'vlayout.' + (proj.width < proj.height || VERT ? 'v' : 'h');
  let vLayout = store.get(LKEY, false), viewW = store.get('viewW', null);
  function setLayout(on, quiet) {
    vLayout = !!on; store.set(LKEY, vLayout);
    if (vLayout) { edTop.replaceChildren(leftPanel, splitL, panel); vlCol.replaceChildren(edTop, splitH, tl); root.replaceChildren(vlCol, splitV, viewer); }
    else { vlCol.replaceChildren(); edTop.replaceChildren(leftPanel, splitL, viewer, splitV, panel); root.replaceChildren(edTop, splitH, tl); }
    root.classList.toggle('vlayout', vLayout);
    layoutBtn.setAttribute('aria-pressed', String(vLayout));
    layoutBtn.replaceChildren(icon(vLayout ? 'layoutH' : 'layoutV', 16));
    layoutBtn.dataset.tip = vLayout ? 'Torna al layout classico' : 'Layout per video verticali: anteprima alta a destra';
    layoutBtn.setAttribute('aria-label', layoutBtn.dataset.tip);
    applySizes();
    if (!quiet) requestAnimationFrame(() => { layoutScreen(); renderTimeline(); });
  }
  function applySizes() {
    panel.style.width = vLayout ? '' : panelW + 'px';
    viewer.style.width = vLayout ? (viewW ? viewW + 'px' : '') : '';
    leftPanel.style.width = leftW + 'px';
    if (tlH) { tl.style.height = tlH + 'px'; tl.style.flex = '0 0 auto'; } else { tl.style.height = ''; }
    // con tante tracce la timeline non spinge via l'anteprima: resta alta al massimo cosi' e le tracce si scorrono
    tl.style.maxHeight = tlH ? 'calc(100vh - 330px)' : '44vh';
  }
  function dragSplit(el, onMove, onEnd) {
    el.addEventListener('pointerdown', (e) => {
      e.preventDefault(); capPtr(el, e.pointerId); el.classList.add('on');
      const mv = (ev) => onMove(ev);
      const up = () => { el.classList.remove('on'); el.removeEventListener('pointermove', mv); onEnd(); };
      el.addEventListener('pointermove', mv);
      el.addEventListener('pointerup', up, { once: true });
    });
  }
  dragSplit(splitV, (e) => {
    if (vLayout) {
      const r = root.getBoundingClientRect();
      viewW = Math.round(Math.max(260, Math.min(r.width - 620, r.right - 8 - e.clientX - 4)));
      applySizes(); return;
    }
    const r = edTop.getBoundingClientRect();
    panelW = Math.round(Math.max(280, Math.min(Math.min(700, r.width - leftW - 380), r.right - 16 - e.clientX - 5)));
    applySizes();
  }, () => { store.set('panelW', panelW); store.set('viewW', viewW); });
  dragSplit(splitH, (e) => {
    const r = root.getBoundingClientRect();
    tlH = Math.round(Math.max(170, Math.min(r.height - 250, r.bottom - 12 - e.clientY - 4)));
    applySizes();
  }, () => store.set('tlH', tlH));
  splitV.addEventListener('dblclick', () => { if (vLayout) { viewW = null; store.set('viewW', null); } else { panelW = 350; store.set('panelW', panelW); } applySizes(); });
  dragSplit(splitL, (e) => {
    const r = edTop.getBoundingClientRect();
    leftW = Math.round(Math.max(230, Math.min(Math.min(560, r.width - (vLayout ? 290 : panelW + 380)), e.clientX - r.left - 8 - 4)));
    applySizes();
  }, () => store.set('leftW', leftW));
  splitL.addEventListener('dblclick', () => { leftW = 300; store.set('leftW', leftW); applySizes(); });
  splitH.addEventListener('dblclick', () => { tlH = null; store.set('tlH', null); applySizes(); });
  if (vLayout) setLayout(true, true); else applySizes();
  app.append(root);

  // ---------------------------------------------------------------- timeline: disegno
  // pezzi eliminati dalla timeline: spariscono e la timeline si accorcia (V: tempo del VOD -> tempo della timeline)
  // e i pezzi accelerati/rallentati si accorciano/allungano come nel video finale
  let goneR = [], vmap = [], viewEnd = D;
  // progetto vuoto: la durata segue quello che metti. Il nero di base sta tutto in coda: se ne vede solo la parte che
  // serve a immagini/testi/suoni messi oltre l'ultima clip; il resto e' nascosto ma resta "spazio" dove appoggiare cose
  let blankVisEnd = Infinity;
  function blankFit() {
    const black = proj.segs.filter((c) => !c.ins);
    if (!black.length) return;
    const bs = Math.min(...black.map((c) => c.a));
    let need = 0;
    for (const t of proj.tracks || []) if (t.type !== 'live') for (const c of t.clips || []) need = Math.max(need, c.a + (c.dur != null ? c.dur : (c.b || c.a) - c.a));
    const ve = +Math.max(bs, Math.min(D, need)).toFixed(4);
    const vis = black.find((c) => !c.gone), hid = black.find((c) => c.gone);
    // il nero visibile e' solo sfondo: niente tolto, spostato, ingrandito o accelerato (anche se un vecchio progetto l'aveva)
    const clean = (c) => !c.removed && !c.tf && !c.speed && !(c.filters && c.filters.length) && !c.color;
    const ok = black.length <= 2 && (!vis || clean(vis)) && (ve - bs < 0.01 ? !vis : vis && Math.abs(vis.a - bs) < 1e-4 && Math.abs(vis.b - ve) < 1e-4)
      && (D - ve < 0.01 ? !hid : hid && Math.abs(hid.a - ve) < 1e-4 && Math.abs(hid.b - D) < 1e-4);
    if (!ok) {
      const tpl = { removed: false, auto: false, vol: 100, mute: false, fin: false, fout: false };
      proj.segs = proj.segs.filter((c) => c.ins);
      if (ve - bs >= 0.01) proj.segs.push({ ...tpl, id: uid('s'), a: bs, b: ve });
      if (D - ve >= 0.01) proj.segs.push({ ...tpl, id: uid('s'), a: ve, b: D, gone: true, removed: true, fill: true });
      proj.segs.sort((x, y) => x.a - y.a);
    }
    blankVisEnd = ve;
  }
  function refreshGone() {
    if (BLANK) blankFit();
    const r = proj.segs.filter((x) => x.gone && !(BLANK && x.fill)).map((x) => [x.a, x.b]).sort((a, b) => a[0] - b[0]);
    const m = [];
    for (const [a, b] of r) { if (m.length && a <= m[m.length - 1][1] + 1e-6) m[m.length - 1][1] = Math.max(m[m.length - 1][1], b); else m.push([a, b]); }
    goneR = m;
    vmap = []; let v = 0;
    for (const c of [...proj.segs].sort((x, y) => x.a - y.a)) {
      const sp = c.gone ? Infinity : (c.speed || 1);
      vmap.push({ a: c.a, b: c.b, v0: v, sp });
      if (!c.gone) v += (c.b - c.a) / sp;
    }
    viewEnd = vmap.length ? v : D;
  }
  const V = (t) => {
    if (BLANK && t > blankVisEnd) return viewEnd + (t - blankVisEnd);   // spazio libero dopo la fine
    if (!vmap.length) return t;
    if (t >= D) return viewEnd;
    let lo = 0, hi = vmap.length - 1;
    while (lo < hi) { const md = (lo + hi + 1) >> 1; if (vmap[md].a <= t) lo = md; else hi = md - 1; }
    const p = vmap[lo];
    return p.sp === Infinity ? p.v0 : p.v0 + Math.max(0, Math.min(p.b, t) - p.a) / p.sp;
  };
  const T = (v) => {
    if (BLANK && v >= viewEnd) return Math.min(D, blankVisEnd + (v - viewEnd));
    if (!vmap.length) return Math.min(D, Math.max(0, v));
    if (v <= 0) { const f = vmap.find((p) => p.sp !== Infinity); return f ? f.a : 0; }
    for (const p of vmap) {
      if (p.sp === Infinity) continue;
      if (v < p.v0 + (p.b - p.a) / p.sp) return p.a + (v - p.v0) * p.sp;
    }
    const last = [...vmap].reverse().find((p) => p.sp !== Infinity);
    return last ? Math.max(last.a, last.b - 0.04) : D;
  };
  const isGone = (a, b) => goneR.some(([ga, gb]) => a >= ga - 1e-6 && b <= gb + 1e-6);
  // quanta timeline si vede tutta insieme (progetto vuoto: quello che c'e' piu' un po' di spazio libero)
  const fitSpan = () => Math.max(1, BLANK ? Math.max(20, viewEnd * 1.25) : V(D));
  const X = (t) => V(t) * pps;
  const XW = (a, b) => X(b) - X(a);
  // se la timeline e' piu' alta del necessario, le tracce si ingrandiscono (fino a 2x)
  // altezza di ogni traccia: si cambia trascinando il bordo sotto il nome (salvata)
  let laneH = store.get('laneH', {});
  const lh = (k, key) => laneH[key || k] || LANE_H[k];
  function updateLaneScale() { return false; }
  // le tracce vuote spariscono da sole; restano visibili solo quelle appena aggiunte (finche' non ricarichi)
  const freshTracks = new Set();
  const showTrack = (t) => { if (t.clips.length) { freshTracks.delete(t.id); return true; } return freshTracks.has(t.id); };
  // tracce filtri/colori rimaste vuote: si tolgono da sole (la principale resta, solo nascosta)
  function pruneFxTracks() {
    const used = new Set(proj.filters.map((f) => f.track || 'fx'));
    used.forEach((id) => freshTracks.delete(id));
    const keep = proj.fxTracks.filter((t) => t.id === 'fx' || used.has(t.id) || freshTracks.has(t.id));
    if (keep.length !== proj.fxTracks.length) { proj.fxTracks = keep; proj.layers = normLayers(); }
  }
  const trRunning = () => { try { return !!trJob; } catch (e) { return false; } };
  const subsLaneNeeded = () => allWords().length > 0 || trRunning() || ['running', 'error'].includes((proj.transcript || {}).status);
  const zoomLaneNeeded = (t) => freshTracks.has(t.id) || proj.zooms.some((z) => (z.track || 'zoom') === t.id) || (framing && sel && sel.type === 'zoom');
  function laneList() {
    pruneFxTracks();
    const L = [];
    // livelli video, dall'alto verso il basso (l'ordine decide cosa copre cosa e cosa viene zoomato)
    for (const k of proj.layers) {
      // sottotitoli e zoom: la traccia c'e' solo quando contiene qualcosa (o l'hai appena aggiunta)
      if (k === 'subs') { if (subsLaneNeeded()) L.push({ kind: 'subs', key: 'subs', h: lh('subs'), group: 'v', layer: k }); }
      else if (k === 'zoom') {
        // la prima traccia zoom decide la posizione; le altre stanno subito sotto
        proj.zoomTracks.forEach((t, i) => {
          if (!zoomLaneNeeded(t)) return;
          L.push({ kind: 'zoom', key: i ? 'zoom:' + t.id : 'zoom', h: lh('zoom', i ? 'zoom:' + t.id : 'zoom'), group: i ? 'zx' : 'v', layer: i ? null : k, ztrack: t });
        });
      } else if (k === 'fx' || k.startsWith('fx:')) {
        const t = proj.fxTracks.find((x) => (x.id === 'fx' ? 'fx' : 'fx:' + x.id) === k);
        // le tracce dei filtri compaiono solo quando servono (o se le hai aggiunte tu)
        if (t && (freshTracks.has(t.id) || proj.filters.some((f) => (f.track || 'fx') === t.id))) L.push({ kind: 'fx', key: k, h: lh('fx', k), group: 'v', layer: k, fxtrack: t });
      }
      else if (k === 'video') L.push({ kind: 'video', key: 'video', h: lh('video'), group: 'base' });
      else { const t = proj.tracks.find((x) => 'ov:' + x.id === k); if (t && showTrack(t)) L.push({ kind: 'overlay', key: k, h: lh('overlay', k), track: t, group: 'v', layer: k }); }
    }
    // clip verticali create da questo VOD: in cima, sopra tutto
    // (le clip verticali stanno nella tab Clip, non in una traccia)
    // audio sotto
    // l'audio della live sta dentro la clip video (come CapCut): niente traccia a parte
    soundTracks().filter(showTrack).forEach((t) => L.push({ kind: 'sound', key: 'sound:' + t.id, h: lh('sound', 'sound:' + t.id), track: t, group: 'a' }));
    return L;
  }

  function renderHeads() {
    heads.replaceChildren();
    const INFO = { zoom: ['magnify', 'Zoom', 'Zoom: ingrandisce tutto quello che sta sotto questa traccia'], video: ['film', 'Video', 'Video della live con il suo audio: i pezzi a righe vengono tolti'], fx: ['wand', 'Filtri', 'Filtri sul video: aggiungili dalla tab Video'] };
    const list = laneList();
    list.forEach((L, idx) => {
      let el;
      const movable = L.group === 'v' || L.group === 'a';
      if (INFO[L.kind]) {
        let [ic, , tip] = INFO[L.kind];
        const lt = L.ztrack || L.fxtrack;
        if (lt && lt.kind === 'adjust') { ic = 'sliders'; tip = 'Colori: luminosità, contrasto, saturazione… su tutto quello che sta sotto'; }
        const emptyFx = L.fxtrack && lt.id === 'fx' && !proj.filters.some((f) => (f.track || 'fx') === 'fx');
        const extra = lt && ((lt.id !== 'zoom' && lt.id !== 'fx') || emptyFx);
        const nm = lt ? lt.name : (proj.laneNames.video || 'Video');
        el = h('div', { class: 'head', style: { height: L.h + 'px' }, 'data-tip': tip + (movable ? ' · trascina per spostarla su o giù' : '') + ' · doppio clic sul nome per rinominare' },
          h('span', { class: 'lico' }, icon(ic, 14)),
          renameable(nm, (v) => { if (lt) lt.name = v; else proj.laneNames.video = v; }),
          L.kind === 'video' ? (() => { const t = liveTrack(); return h('button', { class: 'mb', 'aria-pressed': String(!!t.mute), 'aria-label': t.mute ? 'Riattiva l\'audio della live' : 'Muta l\'audio della live', 'data-tip': t.mute ? 'Riattiva l\'audio della live' : 'Muta l\'audio della live',
            onclick: () => { begin(); t.mute = !t.mute; changed(); } }, icon(t.mute ? 'mute' : 'speaker', 13, t.mute ? '#FF7B72' : 'currentColor', 2)); })() : null,
          extra ? h('button', { class: 'mb hdel', 'aria-label': 'Elimina la traccia', 'data-tip': 'Elimina la traccia (quello che c\'è dentro torna nella traccia principale)',
            onclick: () => removeLaneTrack(L.kind, lt.id) }, icon('x', 12, 'currentColor', 2.2)) : null);
      } else if (L.kind === 'vert') {
        el = h('div', { class: 'head', style: { height: L.h + 'px' }, 'data-tip': 'Clip verticali create da questo video: doppio clic su una per modificarla' },
          h('span', { class: 'lico' }, icon('phone', 14)), h('span', { class: 'nm static' }, 'Verticali'));
      } else if (L.kind === 'subs') {
        const on = !!proj.settings.showSubs;
        el = h('div', { class: 'head', style: { height: L.h + 'px' }, 'data-tip': 'Sottotitoli · trascina per spostarli su o giù' },
          h('button', { class: 'mb', 'aria-pressed': String(on), 'aria-label': on ? 'Nascondi i sottotitoli' : 'Mostra i sottotitoli', 'data-tip': on ? 'Nascondi i sottotitoli (anche nel video finale)' : 'Mostra i sottotitoli',
            onclick: () => toggleSubs() }, icon(on ? 'eye' : 'eyeOff', 14, on ? 'currentColor' : '#FF7B72')),
          renameable(proj.laneNames.subs || 'Testo', (v) => { proj.laneNames.subs = v; }, on ? null : 'var(--text3)'));
      } else if (L.kind === 'overlay') {
        const t = L.track;
        const isSel = sel && sel.type === 'track' && sel.id === t.id;
        el = h('div', { class: 'head', style: { height: L.h + 'px' } },
          h('button', { class: 'mb', 'aria-pressed': String(!t.hidden), 'aria-label': (t.hidden ? 'Mostra ' : 'Nascondi ') + t.name, 'data-tip': t.hidden ? 'Mostra la traccia' : 'Nascondi la traccia',
            onclick: () => { begin(); t.hidden = !t.hidden; changed(); } }, icon(t.hidden ? 'eyeOff' : 'eye', 14, t.hidden ? '#FF7B72' : 'currentColor')),
          renameable(t.name, (v) => { t.name = v; }, null, () => select({ type: 'track', id: t.id }), isSel));
      } else {
        const t = L.track;
        const isSel = sel && sel.type === 'track' && sel.id === t.id;
        el = h('div', { class: 'head', style: { height: L.h + 'px' } },
          h('button', { class: 'mb', 'aria-pressed': String(!!t.mute), 'aria-label': (t.mute ? 'Riattiva ' : 'Muta ') + t.name, 'data-tip': t.mute ? 'Riattiva la traccia' : 'Muta la traccia',
            onclick: () => { begin(); t.mute = !t.mute; changed(); } }, icon(t.mute ? 'mute' : 'speaker', 13, t.mute ? '#FF7B72' : 'currentColor', 2)),
          renameable(t.name, (v) => { t.name = v; }, null, () => select({ type: 'track', id: t.id }), isSel),
          t.vol !== 100 && !t.mute ? h('span', { class: 'v' }, t.vol + '%') : null);
      }
      if (movable) { el.classList.add('movable'); el.addEventListener('pointerdown', (ev) => startLaneMove(ev, L, idx, el)); }
      // maniglia per cambiare l'altezza di questa sola traccia
      const grip = h('div', { class: 'lresize', 'data-tip': 'Trascina per cambiare l\'altezza (con Alt: tutte uguali) · doppio clic per ripristinare' });
      grip.addEventListener('pointerdown', (ev) => {
        ev.preventDefault(); ev.stopPropagation(); capPtr(grip, ev.pointerId);
        const y0 = ev.clientY, h0 = L.h, laneEl = lanes.children[idx], all = ev.altKey;
        const mv = (e2) => {
          const nh = Math.round(Math.max(LANE_MIN[L.kind], Math.min(220, h0 + e2.clientY - y0)));
          if (all || e2.altKey) {
            // Alt: tutte le tracce alla stessa altezza
            list.forEach((x, j) => { laneH[x.key] = nh; if (heads.children[j]) heads.children[j].style.height = nh + 'px'; if (lanes.children[j]) lanes.children[j].style.height = nh + 'px'; });
          } else { laneH[L.key] = nh; el.style.height = nh + 'px'; if (laneEl) laneEl.style.height = nh + 'px'; }
        };
        const up = () => { grip.removeEventListener('pointermove', mv); store.set('laneH', laneH); renderTimeline(); };
        grip.addEventListener('pointermove', mv);
        grip.addEventListener('pointerup', up, { once: true });
      });
      grip.addEventListener('dblclick', () => { delete laneH[L.key]; store.set('laneH', laneH); renderTimeline(); });
      el.append(grip);
      heads.append(el);
    });
  }

  // nome della traccia: doppio clic per rinominarla
  function renameable(text, set, color, onclick, isSel) {
    const b = h('button', { class: 'nm' + (isSel ? ' sel' : ''), style: color ? { color } : null, 'data-tip': 'Doppio clic per rinominare' }, text);
    let clickT = 0;
    b.addEventListener('click', () => { clearTimeout(clickT); if (onclick) clickT = setTimeout(onclick, 220); });
    b.addEventListener('dblclick', (e) => {
      e.stopPropagation(); clearTimeout(clickT);
      const inp = h('input', { class: 'nmedit', value: text, maxlength: '40', 'aria-label': 'Nome della traccia' });
      b.replaceWith(inp); inp.focus(); inp.select();
      let done = false;
      const fin = (ok) => {
        if (done) return; done = true;
        const v = inp.value.trim();
        if (ok && v && v !== text) { begin(); set(v); changed(); } else inp.replaceWith(b);
      };
      inp.addEventListener('keydown', (ev) => { ev.stopPropagation(); if (ev.key === 'Enter') fin(true); else if (ev.key === 'Escape') fin(false); });
      inp.addEventListener('blur', () => fin(true));
      inp.addEventListener('pointerdown', (ev) => ev.stopPropagation());
    });
    return b;
  }
  function removeLaneTrack(kind, id) {
    begin();
    if (kind === 'fx' && id === 'fx') { const t = proj.fxTracks.find((x) => x.id === 'fx'); freshTracks.delete('fx'); }
    else if (kind === 'zoom') { proj.zooms.forEach((z) => { if (z.track === id) z.track = 'zoom'; }); proj.zoomTracks = proj.zoomTracks.filter((t) => t.id !== id); }
    else { proj.filters.forEach((f) => { if (f.track === id) f.track = 'fx'; }); proj.fxTracks = proj.fxTracks.filter((t) => t.id !== id); proj.layers = normLayers(); }
    changed();
  }
  function addLaneTrack(kind) {
    if (kind === 'adjust') return addFilter('adjust', true);
    begin();
    if (kind === 'zoom') {
      // la traccia zoom principale e' nascosta finche' e' vuota: prima si mostra quella
      const main = proj.zoomTracks[0];
      if (main && !zoomLaneNeeded(main)) freshTracks.add(main.id);
      else { const n = proj.zoomTracks.length + 1, id = uid('zt'); proj.zoomTracks.push({ id, name: 'Zoom ' + n }); freshTracks.add(id); }
    }
    else if (kind === 'fx') {
      const main = proj.fxTracks.find((x) => x.id === 'fx');
      // la traccia principale dei filtri e' nascosta finche' non serve: prima si mostra quella
      if (main && !freshTracks.has('fx') && !proj.filters.some((f) => (f.track || 'fx') === 'fx')) freshTracks.add('fx');
      else { const n = proj.fxTracks.filter((t) => t.kind !== 'adjust').length + 1, id = uid('ft'); proj.fxTracks.push({ id, name: 'Filtri ' + n }); freshTracks.add(id); }
      proj.layers = normLayers();
    }
    else newTrack(kind);
    changed();
  }

  // sposta una traccia su o giu' trascinandone il nome (video con video, audio con audio)
  function startLaneMove(ev, L, idx, el) {
    if (ev.button !== 0 || ev.target.closest('button, .lresize')) return;
    const list = laneList();
    const group = list.map((x, i) => ({ x, i })).filter((o) => o.x.group === L.group);
    if (group.length < 2) return;
    ev.preventDefault();
    capPtr(el, ev.pointerId);
    const y0 = ev.clientY;
    let moved = false, target = group.findIndex((o) => o.i === idx);
    const line = h('div', { class: 'lane-drop' });
    const mv = (e) => {
      if (!moved && Math.abs(e.clientY - y0) < 4) return;
      if (!moved) { moved = true; el.classList.add('moving'); tlMain.append(line); }
      // posizione di arrivo: tra quali tracce del gruppo cade il puntatore
      let k = 0;
      group.forEach((o, j) => { const r = heads.children[o.i].getBoundingClientRect(); if (e.clientY > r.top + r.height / 2) k = j + 1; });
      target = k;
      const ref = k < group.length ? heads.children[group[k].i].getBoundingClientRect() : heads.children[group[group.length - 1].i].getBoundingClientRect();
      const mr = tlMain.getBoundingClientRect();
      line.style.top = (k < group.length ? ref.top - 5 : ref.bottom + 3) - mr.top + 'px';
    };
    const up = () => {
      el.removeEventListener('pointermove', mv);
      line.remove(); el.classList.remove('moving');
      if (!moved) return;
      const from = group.findIndex((o) => o.i === idx);
      let to = target > from ? target - 1 : target;
      if (to === from) return;
      begin();
      if (L.group === 'v') {
        const keys = group.map((o) => o.x.layer);
        const [k] = keys.splice(from, 1); keys.splice(to, 0, k);
        // i livelli non mostrati (es. sottotitoli senza trascrizione) restano al loro posto
        const rest = proj.layers.filter((x) => x !== 'video' && !keys.includes(x));
        const out = keys.slice();
        rest.forEach((x) => out.splice(Math.min(out.length, proj.layers.indexOf(x)), 0, x));
        proj.layers = out.concat(['video']);
        proj.layers = normLayers();
      } else {
        const st = soundTracks();
        const [t] = st.splice(from, 1); st.splice(to, 0, t);
        proj.tracks = proj.tracks.filter((x) => x.type !== 'sound').concat(st);
      }
      changed();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }

  function tickStep() {
    const steps = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600];
    return steps.find((s) => s * pps >= 70) || 3600;
  }
  function renderRuler() {
    ruler.replaceChildren();
    const st = tickStep();
    const v0 = scroller.scrollLeft / pps - st, v1 = (scroller.scrollLeft + scroller.clientWidth) / pps + st;
    for (let t = Math.max(0, Math.floor(v0 / st) * st); t <= Math.min(V(D), v1); t += st) {
      ruler.append(h('span', { style: { left: t * pps + 3 + 'px' } }, fmt(t)), h('i', { style: { left: t * pps + 'px' } }));
    }
    // marcatori (M): clic = vai li', trascina = sposta (se non e' bloccato), tasto destro = menu
    for (const m of proj.markers || []) {
      const x = X(m.t);
      if (x < scroller.scrollLeft - 20 || x > scroller.scrollLeft + scroller.clientWidth + 200) continue;
      const tip = (m.name ? m.name + ' · ' : 'Marcatore ') + fmt(m.t) + (m.locked ? ' · bloccato' : ' · trascina per spostarlo') + ' · tasto destro per le opzioni';
      const mk = h('b', { class: 'tmark' + (m.locked ? ' locked' : ''), style: { left: x + 'px' }, 'data-tip': tip, 'data-notr': '' },
        m.name ? h('span', { class: 'tm-name' }, m.name) : null);
      mk.addEventListener('pointerdown', (e) => {
        e.stopPropagation(); e.preventDefault();
        if (e.button !== 0) return;
        if (m.locked) { seek(m.t); return; }
        const x0 = e.clientX; let moved = false, started = false;
        capPtr(mk, e.pointerId);
        const mv = (ev) => {
          if (!moved && Math.abs(ev.clientX - x0) < 3) return;
          if (!started) { begin(); started = true; }
          moved = true;
          let t = Math.max(0, Math.min(D, tAt(ev)));
          const [st, dx] = snapFind(t, m.id, true);
          if (dx < SNAP_PX) { t = st; showSnap(st); } else showSnap(null);
          m.t = +t.toFixed(3);
          mk.style.left = X(m.t) + 'px';
        };
        const up = () => {
          mk.removeEventListener('pointermove', mv); showSnap(null);
          if (!moved) { seek(m.t); return; }
          proj.markers.sort((a, b) => a.t - b.t);
          changed(); renderRuler();
        };
        mk.addEventListener('pointermove', mv);
        mk.addEventListener('pointerup', up, { once: true });
      });
      mk.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); popMenuAt(e.clientX, e.clientY, markerMenu(m)); });
      ruler.append(mk);
    }
  }
  function markerMenu(m) {
    return [
      ['diamond', 'Vai al marcatore', fmt(m.t), () => seek(m.t)],
      ['type', m.name ? 'Rinomina' : 'Dai un nome', m.name || null, async () => {
        const n = await promptBox(m.name ? 'Rinomina il marcatore' : 'Nome del marcatore', 'Si vede sopra la timeline.', m.name || '', 'Salva');
        if (n === null || n === undefined || n === false) return;
        begin(); m.name = String(n).trim().slice(0, 40) || undefined; changed(); renderRuler();
      }],
      [m.locked ? 'unlock' : 'lock', m.locked ? 'Sblocca' : 'Blocca', m.locked ? 'Potrai spostarlo trascinandolo' : 'Non si sposta più finché non lo sblocchi', () => { begin(); m.locked = !m.locked || undefined; changed(); renderRuler(); }],
      ['trash', 'Rimuovi il marcatore', null, () => { begin(); proj.markers = proj.markers.filter((x2) => x2 !== m); changed(); renderRuler(); }, '#FF7B72'],
    ];
  }
  function toggleMarker() {
    const t = video.currentTime;
    proj.markers = proj.markers || [];
    const near = proj.markers.find((m) => Math.abs(X(m.t) - X(t)) < 5);
    begin();
    if (near) proj.markers = proj.markers.filter((m) => m !== near);
    else { proj.markers.push({ id: uid('k'), t: +t.toFixed(3) }); track('marker.add'); }
    proj.markers.sort((a, b) => a.t - b.t);
    changed(); renderRuler();
    toast(near ? 'Marcatore tolto' : 'Marcatore aggiunto');
  }
  // frecce su/giu': al taglio, alla clip o al marcatore precedente / successivo
  function editPoints() {
    const pts = new Set([0]);
    for (const c of proj.segs) if (!c.gone && !(BLANK && !c.ins)) { pts.add(+c.a.toFixed(3)); pts.add(+c.b.toFixed(3)); }
    for (const tr of clipTracks()) for (const c of tr.clips) { pts.add(+c.a.toFixed(3)); pts.add(+(c.a + c.dur).toFixed(3)); }
    for (const m of proj.markers || []) pts.add(m.t);
    if (BLANK) pts.add(+contentEnd().toFixed(3));
    return [...pts].filter((x) => x >= 0 && x <= D).sort((a, b) => a - b);
  }
  function jumpEdit(dir) {
    // si ragiona sul video che esce (senza le parti tolte o nascoste): due punti ai lati di un taglio sono lo stesso
    // punto del video finale, e la freccia sembrerebbe non muoversi
    const tol = Math.max(0.05, 3 / FPS);
    const o0 = outAt(video.currentTime);
    const byOut = new Map();   // tempo nel video finale -> punto della timeline (quello visibile dopo il taglio)
    for (const p of editPoints()) {
      const t = visT(Math.min(D - 0.01, p)), o = +outAt(t).toFixed(3);
      if (!byOut.has(o) || t > byOut.get(o)) byOut.set(o, t);
    }
    const os = [...byOut.keys()].sort((a, b) => a - b);
    const o = dir > 0 ? os.find((x) => x > o0 + tol) : [...os].reverse().find((x) => x < o0 - tol);
    if (o === undefined) return;
    stopReverse(); if (!video.paused) video.pause();
    seek(byOut.get(o));
  }
  // J / K / L come nei programmi di montaggio: indietro e avanti a 1x, 2x, 4x
  let revSpeed = 0, revRaf = 0, revLast = 0;
  function stopReverse() {
    const was = revSpeed;
    revSpeed = 0; cancelAnimationFrame(revRaf); revRaf = 0;
    if (was) { rateBtn.textContent = (viewRate + '×').replace('.', ','); rateBtn.classList.toggle('on', viewRate !== 1); }
  }
  function reverseStep(ts) {
    if (!revSpeed || !alive) return;
    const dt = revLast ? Math.min(0.1, (ts - revLast) / 1000) : 0; revLast = ts;
    const t = video.currentTime - dt * revSpeed;
    if (t <= 0) { seek(0); stopReverse(); return; }
    video.currentTime = visT(t); frame(true); ensureVisible(video.currentTime);
    revRaf = requestAnimationFrame(reverseStep);
  }
  function shuttle(dir) {
    if (!videoReady) return;
    if (dir === 0) { stopReverse(); video.pause(); if (viewRate !== 1) setViewRate(1); return; }
    if (dir > 0) {
      stopReverse();
      if (video.paused) { if (viewRate !== 1) setViewRate(1); togglePlay(); }
      else setViewRate(viewRate < 2 ? 2 : viewRate < 4 ? 4 : viewRate);
      return;
    }
    if (!video.paused) video.pause();
    revSpeed = revSpeed < 1 ? 1 : revSpeed < 2 ? 2 : 4;
    rateBtn.textContent = '◀ ' + revSpeed + '×'; rateBtn.classList.add('on');   // la velocita' si vede nel pulsante, niente avvisi
    if (!revRaf) { revLast = 0; revRaf = requestAnimationFrame(reverseStep); }
  }

  let waveCanvas = null, thumbsBox = null, waveH = 24, clipBox = null, waveBg = null;
  // clip presa col mouse: si stacca e si sposta tutta (miniature e onda), non solo il bordo
  let liftedIds = null;
  function liftVisual(ids) {
    const lane = clipBox && clipBox.parentNode;
    const segs = ids.map((id) => segById(id)).filter(Boolean);
    if (!lane || !segs.length) return null;
    const x0 = Math.min(...segs.map((c) => X(c.a))), x1 = Math.max(...segs.map((c) => X(c.b)));
    const tb = h('div', { class: 'thumbs', style: { bottom: waveH + 'px' } });
    const dpr = window.devicePixelRatio || 1, gw = Math.max(1, x1 - x0);
    if (thumbCv && thumbCv.width) {   // le miniature della clip presa: copiate dal canvas della traccia
      const th = parseFloat(thumbCv.style.height) || 40, tc = document.createElement('canvas');
      tc.width = Math.round(gw * dpr); tc.height = Math.round(th * dpr);
      Object.assign(tc.style, { position: 'absolute', left: '0', top: '0', width: gw + 'px', height: th + 'px', opacity: '.95' });
      try { tc.getContext('2d').drawImage(thumbCv, (x0 - (parseFloat(thumbCv.style.left) || 0)) * dpr, 0, gw * dpr, th * dpr, 0, 0, tc.width, tc.height); } catch (e) { /* */ }
      tb.append(tc);
    }
    const wc = document.createElement('canvas');
    wc.width = Math.round(gw * dpr); wc.height = Math.round(waveH * dpr);
    Object.assign(wc.style, { position: 'absolute', left: '0', bottom: '0', width: gw + 'px', height: waveH + 'px' });
    try { if (waveCanvas) wc.getContext('2d').drawImage(waveCanvas, (x0 - (parseFloat(waveCanvas.style.left) || 0)) * dpr, 0, gw * dpr, waveH * dpr, 0, 0, wc.width, wc.height); } catch (e) { /* */ }
    const ghost = h('div', { class: 'clipghost', style: { left: x0 + 'px', width: gw + 'px' } }, tb, wc);
    lane.append(ghost);
    liftedIds = new Set(segs.map((c) => c.id));
    drawWave(); drawThumbs();
    return { el: ghost, x0, move(dx, dy = 0) { const up = Math.abs(dy) > 12; ghost.style.transform = `translate(${dx}px, ${up ? dy : 0}px)`; ghost.classList.toggle('up', up); lane.style.overflow = up ? 'visible' : ''; }, done() { lane.style.overflow = ''; ghost.remove(); liftedIds = null; drawWave(); drawThumbs(); } };
  }
  // maschera delle clip: solo la parte visibile della timeline (leggera anche con video lunghi)
  // le clip (angoli arrotondati, 2 px di stacco) si ritagliano dentro i canvas di miniature e onda. Prima era una
  // maschera CSS rifatta a ogni scorrimento: il Mac la ricaricava in ritardo e la traccia diventava nera per un attimo
  function updateClipMask() {
    if (clipBox && clipBox.style.maskImage) Object.assign(clipBox.style, { maskImage: '', webkitMaskImage: '' });
  }
  // zona disegnata: lo schermo piu' mezzo schermo per lato, cosi' scorrendo veloce non si vede mai il bordo
  const tlSpan = () => { const vw = scroller.clientWidth, pad = Math.round(vw * 0.5); return { l: Math.max(0, scroller.scrollLeft - pad), w: vw + pad * 2 }; };
  function clipRects(l, w) {
    const out = [];
    for (const c of proj.segs) {
      if (c.gone || (BLANK && !c.ins) || isGapSeg(c) || (liftedIds && liftedIds.has(c.id))) continue;   // nel nero niente miniature ne' onda; la clip presa si vede nel fantasma
      const xa = X(c.a) + 1 - l, xb = X(c.b) - 1 - l;
      if (xb < 0 || xa > w || xb - xa < 1) continue;
      out.push([xa, xb]);
    }
    return out;
  }
  function clipPath(g, rects, hh, radii) {
    g.beginPath();
    for (const [xa, xb] of rects) { if (g.roundRect) g.roundRect(xa, 0, xb - xa, hh, radii); else g.rect(xa, 0, xb - xa, hh); }
    g.clip();
  }
  // se la durata della timeline cambia (clip eliminate, velocita'), la vista si riadatta
  let lastViewEnd = null;
  function refit() {
    if (lastViewEnd !== null && Math.abs(viewEnd - lastViewEnd) < 1e-6) return;
    if (drag && isSeg(drag.type)) return;   // mentre trascini il bordo la scala resta ferma
    const first = lastViewEnd === null;
    lastViewEnd = viewEnd;
    fitPps = Math.max(0.005, (scroller.clientWidth - 2) / fitSpan());
    // come CapCut: la scala resta quella scelta anche se la durata cambia (spostando una clip lontano non si rimpicciolisce
    // tutto); si adatta solo all'apertura. Per rivedere tutto: zoom al minimo
    if (first) pps = fitPps;
    zoomSlider.value = String(Math.round(1000 * Math.log(pps / fitPps) / Math.log(Math.max(1.0001, 200 / fitPps))));
  }
  function renderTimeline() {
    updateLaneScale();
    arrangeLayers(); syncCc(); applySubStyle();
    refreshGone();
    refit();
    inner.style.width = Math.max(scroller.clientWidth, BLANK ? (viewEnd + Math.max(20, viewEnd * 0.3)) * pps : X(D)) + 'px';
    renderHeads();
    lanes.replaceChildren();
    // pezzi della clip verticale scelta nella tab Clip: segnati sotto il righello
    inner.querySelectorAll('.vc-mark').forEach((m) => m.remove());
    const vsel = !IS_V && sel && sel.type === 'vclip' && findSel();
    if (vsel) for (const [a, b] of vRanges(vsel)) inner.append(h('div', { class: 'vc-mark', style: { left: X(a) + 'px', width: Math.max(3, XW(a, b)) + 'px' } }));
    for (const L of laneList()) {
      const lane = h('div', { class: 'lane ' + L.kind, style: { height: L.h + 'px' }, 'data-kind': L.kind, 'data-track': L.track && L.kind !== 'live' ? L.track.id : null, 'data-layer': L.layer || null });
      lanes.append(lane);
      if (L.kind === 'vert') {
        const { rows, n } = vertRows(), rh = L.h / n;
        for (const v of proj.verticals) {
          const on = sel && sel.type === 'vclip' && sel.id === v.id;
          const b = h('div', { class: 'blk vclipb' + (on ? ' sel' : ''), style: { left: X(v.a) + 'px', width: Math.max(6, XW(v.a, v.b)) + 'px', top: (rows.get(v.id) * rh + 3) + 'px', height: (rh - 6) + 'px', bottom: 'auto' }, 'data-tip': v.name + ' · doppio clic per modificarla' },
            icon('phone', 12, 'currentColor', 2), h('span', null, v.name));
          // doppio clic: la timeline si ridisegna al primo clic, quindi lo si riconosce qui
          b.addEventListener('pointerdown', (e) => {
            e.stopPropagation(); if (e.button !== 0) return;
            const now = Date.now(), dbl = lastVDown.id === v.id && now - lastVDown.t < 450;
            lastVDown = { id: v.id, t: dbl ? 0 : now };
            if (dbl) { openVertical(v); return; }
            multi = []; select({ type: 'vclip', id: v.id });
          });
          b.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); select({ type: 'vclip', id: v.id }); popMenuAt(e.clientX, e.clientY, vclipMenu(v)); });
          lane.append(b);
        }
      } else if (L.kind === 'zoom') {
        lane.dataset.zt = L.ztrack.id;
        for (const z of proj.zooms.filter((x) => (x.track || 'zoom') === L.ztrack.id)) {
          const b = block('zoom', z.id, z.a, z.b, 'blk zoom' + (z.kind === 'custom' ? ' custom' : ''), zoomLabel(z));
          b.title = `Zoom ${fmt(z.a)} → ${fmt(z.b)}`;
          lane.append(b);
        }
      } else if (L.kind === 'fx') {
        lane.dataset.fxt = L.fxtrack.id;
        const mine = proj.filters.filter((f) => (f.track || 'fx') === L.fxtrack.id);
        if (L.fxtrack.kind === 'adjust') lane.classList.add('adj');
        if (!mine.length) {
          if (L.fxtrack.kind === 'adjust') lane.append(h('button', { class: 'lane-cta', onclick: (e) => { e.stopPropagation(); addFilter('adjust'); } }, icon('plus', 12, 'currentColor', 2.4), 'Regola i colori qui'));
          else lane.append(h('div', { class: 'lane-hint' }, L.fxtrack.id === 'fx' ? 'Aggiungi un filtro dalla tab Video' : 'Trascina qui un filtro'));
        }
        // filtri sovrapposti: uno sotto l'altro nella stessa traccia
        const rowEnd = [], rowOf = new Map();
        for (const f of mine.slice().sort((x, y) => x.a - y.a)) {
          let r = rowEnd.findIndex((e) => e <= f.a + 0.001);
          if (r < 0) { r = rowEnd.length; rowEnd.push(0); }
          rowEnd[r] = f.b; rowOf.set(f.id, r);
        }
        const nr = Math.max(1, rowEnd.length), rh = (L.h - 4) / nr;
        for (const f of mine) {
          const b = block('fx', f.id, f.a, f.b, 'blk fxb' + (f.off ? ' off' : ''), fxName(f.type) + (f.mask && f.mask.type && f.mask.type !== 'all' ? ' · maschera' : ''));
          b.title = `${fxName(f.type)} ${fmt(f.a)} → ${fmt(f.b)}`;
          if (nr > 1) Object.assign(b.style, { top: 2 + rowOf.get(f.id) * rh + 'px', height: rh - 1 + 'px', bottom: 'auto', fontSize: rh < 16 ? '9px' : '' });
          lane.append(b);
        }
      } else if (L.kind === 'video') {
        // clip video con il suo audio: miniature sopra, forma d'onda sotto
        waveH = Math.max(14, Math.round(L.h * 0.3));
        // le miniature restano le stesse tra un ridisegno e l'altro (niente sfarfallio mentre trascini o allunghi)
        if (!thumbsBox) thumbsBox = h('div', { class: 'thumbs' });
        thumbsBox.style.bottom = waveH + 'px';
        waveCanvas = h('canvas', { class: 'wave', style: { top: 'auto', bottom: '0' } });
        waveBg = h('div', { class: 'wavebg', style: { height: waveH + 'px' } });
        // miniature e audio sono ritagliati clip per clip (angoli arrotondati, 2 px di stacco tra una clip e l'altra)
        clipBox = h('div', { class: 'vclips' }, thumbsBox, waveBg, waveCanvas);
        lane.append(clipBox);
        const lt = liveTrack();
        if (BLANK && !proj.segs.some((c) => c.ins && !c.gone)) lane.append(h('div', { class: 'lane-hint main-empty' }, icon('addVideo', 13, 'currentColor', 2), 'Trascina qui i tuoi video: si mettono uno dopo l\'altro'));
        for (const c of proj.segs) {
          if (BLANK && !c.ins) {   // il nero di base: spazio libero, non una clip
            if (!c.gone) lane.append(h('div', { class: 'blk seg blankfill', style: { left: X(c.a) + 1 + 'px', width: Math.max(2, XW(c.a, c.b) - 2) + 'px' } }));
            continue;
          }
          if (isGapSeg(c)) {   // spazio vuoto (nero) lasciato a calamita spenta
            const b = block('seg', c.id, c.a, c.b, 'blk seg gapfill', '');
            b.style.left = X(c.a) + 1 + 'px'; b.style.width = Math.max(2, XW(c.a, c.b) - 2) + 'px';
            lane.append(b);
            continue;
          }
          const tags = [];
          if (c.speed && c.speed !== 1) tags.push((c.speed + '×').replace('.', ','));
          if (!c.removed && (c.mute || lt.mute)) tags.push('muto');
          else if (!c.removed && c.vol !== 100) tags.push(c.vol + '%');
          const b = block('seg', c.id, c.a, c.b, 'blk seg' + (c.removed ? ' removed' : '') + (c.mute || lt.mute ? ' muted' : ''), XW(c.a, c.b) > 34 ? tags.join(' · ') : '');
          b.style.left = X(c.a) + 1 + 'px'; b.style.width = Math.max(2, XW(c.a, c.b) - 2) + 'px';
          if (tags.length) b.classList.add('spd');
          if (sel && sel.type === 'aseg' && sel.id === c.id) b.classList.add('sel');
          lane.append(b);
        }
        drawWave();
        for (const [a, b2, si, wi] of wordCuts()) {
          const b = h('div', { class: 'blk tcut', style: { left: X(a) + 'px', width: Math.max(3, XW(a, b2)) + 'px' }, title: 'Tolto dal testo', 'data-a': a, 'data-b': b2 });
          b.addEventListener('pointerdown', (e) => { e.stopPropagation(); setTab('text'); seek(a); setTimeout(() => scrollToWord(si, wi), 50); });
          lane.append(b);
        }
        drawThumbs();
      } else if (L.kind === 'subs') {
        if (!allWords().length) { lane.append(subsStatus('lane')); continue; }
        if (!proj.settings.showSubs) { lane.classList.add('off'); lane.append(h('div', { class: 'lane-hint' }, 'Sottotitoli nascosti')); continue; }
        // frasi vicine che a questo zoom non ci stanno: un'unica barra (niente blocchetti uno sopra l'altro)
        const vis = subChunks().filter((ch) => !isGone(ch.a, ch.b));
        const runs = [];
        for (const ch of vis) {
          const l = X(ch.a), r = X(ch.b);
          const last = runs[runs.length - 1];
          if (last && l - last.r < 3 && (r - l < 16 || last.r - last.l0 < 16 || last.items.length > 1 && last.tight)) { last.items.push(ch); last.r = Math.max(last.r, r); last.tight = true; }
          else runs.push({ l0: l, r, items: [ch], tight: false });
        }
        for (let k = 0; k < runs.length; k++) {
          const run = runs[k], next = runs[k + 1];
          const right = Math.min(run.r, next ? next.l0 - 2 : Infinity);
          const width = Math.max(3, right - run.l0);
          if (run.items.length === 1) {
            // ogni frase si seleziona come le altre clip (anche col rettangolo o Ctrl+clic)
            const ch = run.items[0], id = subKey(ch);
            const isS = (sel && sel.type === 'sub' && sel.id === id) || multi.some((m) => m.type === 'sub' && m.id === id);
            const b = h('div', { class: 'blk subblk' + (isS ? ' sel' : '') + (ch.hidden ? ' hid' : ''), style: { left: run.l0 + 'px', width: width + 'px' },
              'data-tip': ch.text + ' · doppio clic per correggere', 'data-type': 'sub', 'data-id': id, 'data-notr': '1', 'data-a': ch.a, 'data-b': ch.b },
              width > 26 ? h('span', { style: { pointerEvents: 'none', overflow: 'hidden', textOverflow: 'ellipsis' } }, ch.text) : null);
            b.addEventListener('pointerdown', (ev) => startDrag(ev, 'sub', id, b));
            b.addEventListener('dblclick', () => fixSub(ch));
            lane.append(b);
            continue;
          }
          // tante frasi fitte: si clicca quella sotto il mouse (ingrandisci la timeline per vederle una per una)
          const ids = run.items.map(subKey);
          const isSel = (id) => (sel && sel.type === 'sub' && sel.id === id) || multi.some((m) => m.type === 'sub' && m.id === id);
          const allHid = run.items.every((ch) => ch.hidden);
          const b = h('div', { class: 'blk subblk subrun' + (allHid ? ' hid' : ''), style: { left: run.l0 + 'px', width: width + 'px' },
            'data-tip': run.items.length + ' frasi · ingrandisci la timeline per vederle una per una', 'data-type': 'sub', 'data-id': ids[0], 'data-a': run.items[0].a, 'data-b': run.items[run.items.length - 1].b });
          // dentro la barra: una tacca per ogni frase, e solo quella selezionata evidenziata (non tutto il gruppo)
          run.items.forEach((ch, k) => {
            const l = X(ch.a) - run.l0, w = Math.max(3, Math.min(width - l, XW(ch.a, ch.b)));
            if (isSel(subKey(ch))) b.append(h('i', { class: 'subsel', style: { left: l + 'px', width: w + 'px' } }));
            else if (k) b.append(h('i', { class: 'subtick', style: { left: l + 'px' } }));
          });
          const pick = (ev) => { const t = tAt(ev); return run.items.find((ch) => t >= ch.a && t < ch.b) || run.items.reduce((m, ch) => (Math.abs(ch.a - t) < Math.abs(m.a - t) ? ch : m)); };
          b.addEventListener('pointerdown', (ev) => { const ch = pick(ev); b.dataset.id = subKey(ch); startDrag(ev, 'sub', subKey(ch), b); });
          b.addEventListener('dblclick', (ev) => fixSub(pick(ev)));
          lane.append(b);
        }
      } else if (L.kind === 'live') {
        waveCanvas = h('canvas', { class: 'wave', height: String(L.h) });
        lane.append(waveCanvas);
        for (const c of proj.segs) {
          const b = block('aseg', c.id, c.a, c.b, 'blk aseg' + (c.mute || L.track.mute ? ' muted' : '') + (c.removed ? ' removed' : ''), (XW(c.a, c.b) > 60 && !c.removed ? (c.mute ? 'muto' : (c.vol !== 100 ? c.vol + '%' : '')) : ''));
          lane.append(b);
        }
        drawWave();
      } else {
        const t = L.track;
        if (!t.clips.length) lane.append(h('div', { class: 'lane-hint' }, L.kind === 'overlay' ? 'Trascina qui un video o un\'immagine dai Media' : 'Trascina qui un suono dai Media'));
        for (const c of t.clips) {
          const img = c.kind === 'image', vclip = c.kind === 'video';
          const b = block('sclip', c.id, c.a, c.a + c.dur, 'blk sclip' + (img || vclip ? ' oclip' : '') + (c.mute || t.mute ? ' muted' : ''), c.name + (c.mute ? ' · muto' : ''));
          b.style.background = t.color || '#4A8BFF';
          if (c.isText) b.prepend(h('span', { class: 'tglyph' }, 'T'));
          else if (img && XW(c.a, c.a + c.dur) > 30) b.prepend(othumb(c.id, mediaUrl(c.file)));
          else if (vclip && XW(c.a, c.a + c.dur) > 30) b.prepend(othumb(c.id, mthumbUrl(c.file, (c.offset || 0) + Math.min(1, c.dur / 2))));
          if (t.mute || t.hidden) b.style.opacity = '0.4';
          if (img && c.anim) {
            if (c.anim.in) b.append(h('i', { class: 'anr in', style: { width: XW(c.a, c.a + Math.min(c.anim.inDur || 0.5, c.dur)) + 'px' } }));
            if (c.anim.out) b.append(h('i', { class: 'anr out', style: { width: XW(c.a + c.dur - Math.min(c.anim.outDur || 0.5, c.dur), c.a + c.dur) + 'px' } }));
            if (c.anim.loop || c.anim.motion) b.append(h('i', { class: 'anr loop' }));
          }
          if (img) for (const k of c.kf || []) {
            const d = h('i', { class: 'kfd', style: { left: XW(c.a, c.a + k.t) + 'px' }, 'data-tip': 'Keyframe · ' + fmt(c.a + k.t, 1) });
            d.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); if (!(sel && sel.id === c.id)) select({ type: 'sclip', id: c.id }); seek(c.a + k.t + 0.001); renderPanel(); });
            b.append(d);
          }
          b.title = `${c.name} · ${fmt(c.a)} → ${fmt(c.a + c.dur)}`;
          lane.append(b);
        }
      }
    }
    renderRuler();
    updatePlayhead(video.currentTime);
    drawPendingIns();
  }

  // sottotitoli come appaiono nel video: frasi brevi, senza parole tolte
  let subCache = null;
  const subKey = (ch) => ch.a.toFixed(3);
  // correggi il testo di una frase: apre la trascrizione sulla parola giusta
  function fixSub(ch) {
    trMode = 'fix'; openSec.set('t.tr', true); sel = null; multi = []; tab = 'text'; renderTimeline(); renderPanel();
    setTimeout(() => { scrollToWord(ch.si, ch.wi); const el = wordEls[ch.si] && wordEls[ch.si][ch.wi]; if (el) editWord(el); }, 80);
  }
  function subChunks() {
    const maxC = proj.subStyle.maxChars || 38;
    if (subCache && subCache.ver === ver && subCache.maxC === maxC && subCache.n === allWords().length) return subCache.list;
    const rem = removed(), out = [];
    let ri = 0;
    allWords().forEach((s, si) => {
      let cur = null;
      s.words.forEach((w, wi) => {
        const mid = (w.a + w.b) / 2;
        while (ri < rem.length && rem[ri][1] < mid) ri++;
        if (w.del || (ri < rem.length && rem[ri][0] <= mid)) return;
        const hid = !!w.nosub;
        if (cur && ((cur.text + ' ' + w.w).length > maxC || w.a - cur.b > 0.7 || w.b - cur.a > 3.5 || cur.hidden !== hid)) { out.push(cur); cur = null; }
        if (!cur) cur = { a: w.a, b: w.b, text: w.w, si, wi, words: [w], hidden: hid };
        else { cur.b = w.b; cur.text += ' ' + w.w; cur.words.push(w); }
      });
      if (cur) out.push(cur);
    });
    // come nel video esportato: almeno 0,6 s, niente sovrapposizioni
    out.forEach((c) => { c.b = Math.max(c.b, c.a + 0.6); });
    for (let i = 0; i < out.length - 1; i++) if (out[i].b > out[i + 1].a) out[i].b = out[i + 1].a;
    subCache = { ver, maxC, n: allWords().length, list: out };
    return out;
  }
  function zoomLabel(z) {
    if (VERT) { const wpx = XW(z.a, z.b); return wpx > 44 ? (z.kind === 'custom' ? 'Inquadratura' : 'Webcam') : ''; }   // in verticale: a tutto schermo
    const lv = (z.kind === 'custom' && z.rect ? W / customRect(W, H, z.rect)[2] : (z.level || 2.8)).toFixed(1).replace('.', ',') + '×';
    const wpx = XW(z.a, z.b);
    return wpx > 70 ? (z.kind === 'custom' ? 'custom ' : 'zoom ') + lv : (wpx > 42 ? lv : '');
  }
  // miniatura di una clip: lo stesso elemento tra un ridisegno e l'altro (l'immagine resta decodificata, niente lampi)
  const othumbs = new Map();
  function othumb(id, src) {
    let im = othumbs.get(id);
    if (!im || im.dataset.src !== src) { im = h('img', { class: 'othumb', src, alt: '', draggable: 'false', decoding: 'async' }); im.dataset.src = src; othumbs.set(id, im); }
    return im;
  }
  function block(type, id, a, b, cls, label) {
    const isSel = (sel && sel.type === type && sel.id === id) || multi.some((m) => m.type === type && m.id === id);
    const el = h('div', { class: cls + (isSel ? ' sel' : ''), style: { left: X(a) + 'px', width: Math.max(4, XW(a, b)) + 'px', display: isGone(a, b) ? 'none' : '' }, 'data-type': type, 'data-id': id, 'data-a': a, 'data-b': b },
      label ? h('span', { style: { pointerEvents: 'none', overflow: 'hidden', textOverflow: 'ellipsis' } }, label) : null);
    el.append(h('div', { class: 'hdl l', 'data-edge': 'l' }), h('div', { class: 'hdl r', 'data-edge': 'r' }));
    el.addEventListener('pointerdown', (e) => startDrag(e, type, id, el));
    return el;
  }

  // miniature: si riusano quelle gia' caricate (niente sfarfallio e niente lavoro inutile mentre scorre)
  const insSig = () => (proj.inserts || []).map((x) => x.id + '@' + Math.round(x.at * 10)).join(',').replace(/[^\w@,]/g, '') || '0';
  // miniature della traccia video disegnate su un canvas (come l'onda): niente immagini che spariscono e ricompaiono
  // mentre fai zoom o scorri. Finche' la miniatura giusta non e' pronta si vede la piu' vicina gia' caricata.
  const TCACHE = new Map(), TBYSRC = new Map();
  let thumbCv = null, thumbRaf = 0;
  function thumbImg(url, srcKey, q) {
    let e = TCACHE.get(url);
    if (e) return e;
    e = { img: new Image(), ok: false, q };
    e.img.decoding = 'async';
    e.img.onload = () => {
      e.ok = true;
      let arr = TBYSRC.get(srcKey); if (!arr) TBYSRC.set(srcKey, (arr = []));
      arr.push(e);
      if (!thumbRaf) thumbRaf = requestAnimationFrame(() => { thumbRaf = 0; drawThumbs(); });
    };
    e.img.onerror = () => { e.bad = true; };
    e.img.src = url;
    TCACHE.set(url, e);
    if (TCACHE.size > 4000) { const k = TCACHE.keys().next().value; TCACHE.delete(k); }
    return e;
  }
  function nearThumb(srcKey, q) {
    const arr = TBYSRC.get(srcKey);
    if (!arr || !arr.length) return null;
    let best = null, bd = Infinity;
    for (const e of arr) { const d = Math.abs(e.q - q); if (d < bd) { bd = d; best = e; } }
    return best;
  }
  function drawThumbs() {
    if (!thumbsBox) return;
    if (!thumbCv) { thumbCv = h('canvas', { class: 'thumbcv' }); }
    if (thumbCv.parentNode !== thumbsBox) thumbsBox.replaceChildren(thumbCv);
    const { l: sx, w: vw } = tlSpan(), hgt = thumbsBox.clientHeight || Math.max(10, lh('video') - waveH);
    const dpr = window.devicePixelRatio || 1;
    if (thumbCv.width !== Math.floor(vw * dpr) || thumbCv.height !== Math.floor(hgt * dpr)) { thumbCv.width = Math.floor(vw * dpr); thumbCv.height = Math.floor(hgt * dpr); }
    Object.assign(thumbCv.style, { left: sx + 'px', width: vw + 'px', height: hgt + 'px' });
    const g = thumbCv.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, vw, hgt);
    g.save();
    clipPath(g, clipRects(sx, vw), hgt, [6, 6, 0, 0]);
    // sotto le miniature un fondo scuro della clip (mai buchi neri mentre arrivano)
    g.fillStyle = '#1B2130'; g.fillRect(0, 0, vw, hgt);
    if (!strip) { g.restore(); return; }   // le miniature arrivano dopo il video
    const tw = Math.max(16, Math.round(hgt * 16 / 9));
    const total = Math.ceil(X(D) / tw);
    const liveIv = strip.liveIv || strip.interval || 1;
    for (let i = Math.max(0, Math.floor(sx / tw)); i < Math.min(total, Math.ceil((sx + vw) / tw)); i++) {
      let t = Math.min(D - 0.05, T((i + 0.5) * tw / pps));
      let c = proj.segs.find((x) => t >= x.a && t < x.b);
      if (!c || isGapSeg(c) || (c.ins && !insById(c.ins))) {
        // il centro della miniatura cade nel vuoto ma la miniatura tocca una clip (inizio o fine di una clip dopo uno
        // spazio): si usa il fotogramma del bordo di quella clip, se no restava un buco scuro all'inizio della clip
        const ta = T(i * tw / pps), tb = T((i + 1) * tw / pps);
        c = proj.segs.find((x) => !x.gone && !isGapSeg(x) && x.b > ta && x.a < tb && !(BLANK && !x.ins));
        if (!c) continue;
        t = Math.max(c.a + 0.02, Math.min(c.b - 0.05, t));
      }
      // la miniatura e' di un punto di un file (la live o un video), calcolato dalle clip: spostando le clip resta la stessa
      const rec = c.ins ? insById(c.ins) : null;
      if (c.ins && (!rec || rec.gap)) continue;
      const onLive = !rec || !!rec.live;
      if (!rec && BLANK) continue;   // il nero di base
      const st = rec ? (rec.offset || 0) + (t - rec.at) : liveOffAt(t);
      const q = onLive ? Math.round(st / liveIv) * liveIv : Math.floor(st);
      const srcKey = onLive ? 'L' : rec.file;
      const url = `/api/p/${pid}/stile?token=${TOKEN}&` + (onLive ? 'src=live' : 'src=f&path=' + encodeURIComponent(rec.file)) + `&st=${q.toFixed(2)}`;
      let e = thumbImg(url, srcKey, q);
      if (!e.ok) e = nearThumb(srcKey, q);
      if (!e) continue;
      const im = e.img, iw = im.naturalWidth || 16, ih = im.naturalHeight || 9;
      // come object-fit: cover
      const sc = Math.max(tw / iw, hgt / ih), cw = tw / sc, ch = hgt / sc;
      try { g.drawImage(im, (iw - cw) / 2, (ih - ch) / 2, cw, ch, i * tw - sx, 0, tw, hgt); } catch (x) { /* */ }
    }
    g.restore();
  }

  function drawWave() {
    if (!waveCanvas) return;
    const { l: x0, w: vw } = tlSpan();
    const dpr = window.devicePixelRatio || 1;
    const hgt = waveH;
    if (waveCanvas.width !== Math.floor(vw * dpr) || waveCanvas.height !== Math.floor(hgt * dpr)) { waveCanvas.width = Math.floor(vw * dpr); waveCanvas.height = Math.floor(hgt * dpr); }
    waveCanvas.style.width = vw + 'px'; waveCanvas.style.height = hgt + 'px'; waveCanvas.style.left = x0 + 'px';
    const g = waveCanvas.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, vw, hgt);
    updateClipMask();
    if (waveBg) waveBg.style.display = 'none';
    clipPath(g, clipRects(x0, vw), hgt, [0, 0, 6, 6]);
    g.fillStyle = '#161A24'; g.fillRect(0, 0, vw, hgt);
    const peaks = wave.peaks || [], ps = wave.perSec || 5;
    if (!peaks.length) return;
    const lt = liveTrack();
    // forma d'onda simmetrica, centrata: piu' leggibile e pulita
    const mid = hgt / 2, maxH = hgt - 6;
    for (let x = 0; x < vw; x += 3) {
      const ta = T((x0 + x) / pps), tb = T((x0 + x + 3) / pps);
      let m = 0;
      for (let i = Math.floor(ta * ps); i <= Math.min(peaks.length - 1, Math.floor(tb * ps)); i++) m = Math.max(m, peaks[i] || 0);
      const c = proj.segs.find((cl) => ta >= cl.a && ta < cl.b);
      const off = lt.mute || (c && (c.mute || c.removed));
      const v = off ? 1 : (lt.vol / 100) * ((c ? c.vol : 100) / 100);
      const bh = Math.max(1, Math.min(maxH, m * maxH * Math.min(1.6, v)));
      g.fillStyle = off ? 'rgba(160,160,170,.35)' : 'rgba(95,138,240,.95)';
      g.fillRect(x, mid - bh / 2, 2, bh);
    }
  }

  function updatePlayhead(t) {
    playhead.style.left = X(t) + 'px';
  }

  // ---------------------------------------------------------------- timeline: interazioni
  function findSel(s = sel) {
    if (!s) return null;
    if (s.type === 'zoom') return proj.zooms.find((z) => z.id === s.id);
    if (s.type === 'seg' || s.type === 'aseg') return proj.segs.find((c) => c.id === s.id);
    if (s.type === 'subs') return proj.subStyle;
    if (s.type === 'sub') { const c = subChunks().find((x) => subKey(x) === s.id); if (c) c.id = s.id; return c || null; }
    if (s.type === 'fx') return proj.filters.find((f) => f.id === s.id);
    if (s.type === 'sclip') { for (const t of clipTracks()) { const c = t.clips.find((c) => c.id === s.id); if (c) return c; } return null; }
    if (s.type === 'track') return proj.tracks.find((t) => t.id === s.id);
    if (s.type === 'vclip') return (proj.verticals || []).find((v) => v.id === s.id);
    return null;
  }
  const isSeg = (t) => t === 'seg' || t === 'aseg';
  let multi = [];   // selezione multipla [{type,id}]
  let lastTextSel = null;
  // quale tab mostra l'elemento selezionato
  function tabFor(s) {
    if (s.type === 'aseg') return 'audio';
    if (s.type === 'sclip') { const c = findSel(s); if (c && c.isText) { if (lastTextSel !== s.id) { imgSub = 'text'; lastTextSel = s.id; } return 'text'; } return c && (c.kind === 'image' || c.kind === 'video') ? 'video' : 'audio'; }
    if (s.type === 'subs' || s.type === 'sub') return 'text';
    if (s.type === 'vclip') return 'clips';
    if (s.type === 'track') { const t = findSel(s); return t && t.type === 'overlay' ? 'video' : 'audio'; }
    return 'video';
  }
  function trackOfClip(id) { return proj.tracks.find((t) => t.clips.some((c) => c.id === id)); }
  function select(s, noTab) {
    if (!s || !sel || s.id !== sel.id) framing = false;
    if (!s) multi = [];
    sel = s;
    if (s && !noTab) tab = tabFor(s);
    renderTimeline(); renderPanel();
  }

  let drag = null;
  function startDrag(e, type, id, el) {
    e.stopPropagation();
    if (e.button !== 0) return;
    // Ctrl/Maiusc + clic: aggiunge o toglie dalla selezione multipla
    if (e.ctrlKey || e.metaKey || e.shiftKey) {
      if (!multi.length && sel && sel.type !== 'track' && sel.type !== 'subs') multi = [{ ...sel }];
      const i = multi.findIndex((m) => m.type === type && m.id === id);
      if (i >= 0) multi.splice(i, 1); else multi.push({ type, id });
      sel = multi.length === 1 ? { ...multi[0] } : (multi.length ? { ...multi[multi.length - 1] } : null);
      if (multi.length <= 1) multi = [];
      renderTimeline(); renderPanel();
      return;
    }
    if (!multi.some((m) => m.type === type && m.id === id)) multi = [];
    const item = findSel({ type, id });
    if (!item) return;
    const edge = e.target.dataset.edge || 'move';
    if (!(sel && sel.type === type && sel.id === id)) { framing = false; sel = { type, id }; tab = tabFor(sel); renderPanel(); lanes.querySelectorAll('.blk.sel').forEach((b) => b.classList.remove('sel')); el.classList.add('sel'); }
    if (type === 'sub') { startMarquee(e, { item, type, t: item.a + 0.01 }); return; }
    // calamita spenta: una clip principale si trascina liberamente (lascia o chiude spazio vuoto)
    if (!magnetOn() && edge === 'move' && !(BLANK && isSeg(type) && !item.ins)) {
      if (isSeg(type) && !item.removed) { startFreeMove(e, item, el); return; }
      // gruppo con clip principali preso da un altro elemento: si muove tutto dalla prima clip principale
      const anchor = multi.length > 1 && multi.filter((m) => isSeg(m.type)).map((m) => findSel(m)).filter(Boolean).sort((x, y) => x.a - y.a)[0];
      if (anchor && multi.some((m) => m.type === type && m.id === id)) { startFreeMove(e, anchor, el); return; }
    }
    if (isSeg(type) && edge === 'move' && item.ins && (proj.inserts || []).some((x) => x.id === item.ins)) { startInsMove(e, item, el); return; }
    // una clip della live: si prende e si sposta in un altro punto della traccia principale (come in CapCut)
    if (type === 'seg' && edge === 'move' && !item.ins && !item.removed && !BLANK && !multi.length) { startLiveMove(e, item, el); return; }
    if (isSeg(type) && edge === 'move') {
      // trascinando su un pezzo parte il rettangolo di selezione; un clic semplice lo seleziona e sposta la testina
      startMarquee(e, { item, type, t: Math.max(item.a, Math.min(item.b - 0.1, tAt(e))) });
      return;
    }
    if (isSeg(type) && edge === 'r' && item.ins && startImageStretch(e, item, el)) return;
    if (type === 'sclip' && edge === 'move' && !(multi.length > 1)) { startClipFloat(e, item, el); return; }
    drag = { type, id, edge, x0: e.clientX, y0: e.clientY, orig: JSON.parse(JSON.stringify(item)), moved: false, el, clickT: tAt(e), lane0: el.parentNode, lane: el.parentNode };
    if (isSeg(type)) {
      // bordo di un pezzo: si lavora su una copia dei pezzi iniziali, la timeline si ridisegna mentre trascini
      drag.segs0 = JSON.parse(JSON.stringify(proj.segs));
      window.addEventListener('pointermove', onDragMove);
      window.addEventListener('pointerup', onDragEnd, { once: true });
      return;
    }
    // selezione multipla: si spostano insieme (zoom, filtri, immagini, testi, suoni)
    if (edge === 'move' && multi.length > 1) {
      drag.group = multi.filter((m) => !(m.type === type && m.id === id) && ['zoom', 'fx', 'sclip'].includes(m.type))
        .map((m) => ({ it: findSel(m), m })).filter((g) => g.it).map((g) => ({ ...g, orig: { a: g.it.a, b: g.it.b } }));
    }
    capPtr(el, e.pointerId);
    el.addEventListener('pointermove', onDragMove);
    el.addEventListener('pointerup', onDragEnd, { once: true });
  }
  function onDragMove(e) {
    if (!drag) return;
    const dt = (e.clientX - drag.x0) / pps;
    // spostamento in tempo del VOD che segue il puntatore sulla timeline (salta le clip eliminate, tiene conto della velocita')
    const sh = (t) => T(V(t) + dt);
    if (drag.group && drag.group.length && (drag.moved || Math.abs(e.clientX - drag.x0) >= 3)) {
      let d = sh(drag.orig.a) - drag.orig.a;
      const all = [{ o: drag.orig }, ...drag.group.map((g) => ({ o: g.orig, it: g.it }))];
      for (const { o } of all) { const len = (o.b !== undefined ? o.b : o.a + (o.dur || 0)) - o.a; d = Math.max(d, -o.a); d = Math.min(d, D - o.a - len); }
      for (const g of drag.group) {
        const len = g.orig.b !== undefined ? g.orig.b - g.orig.a : 0;
        g.it.a = g.orig.a + d; if (g.orig.b !== undefined) g.it.b = g.it.a + len;
        lanes.querySelectorAll(`[data-id="${g.m.id}"]`).forEach((el) => { el.style.left = X(g.it.a) + 'px'; });
      }
      drag.gd = d;
    }
    if (!drag.moved && Math.abs(e.clientX - drag.x0) < 3 && Math.abs(e.clientY - drag.y0) < 6) return;
    // spostamento su un'altra traccia dello stesso tipo (immagini/testi, suoni, zoom, filtri)
    if (drag.edge === 'move' && ['sclip', 'zoom', 'fx'].includes(drag.type)) {
      drag.el.style.pointerEvents = 'none';
      const under = document.elementFromPoint(e.clientX, e.clientY);
      const ln = under && under.closest && under.closest('.lane');
      const k0 = drag.lane0.dataset.kind;
      // foto o video sopra -> traccia principale
      drag.toMain = drag.type === 'sclip' && ['image', 'video'].includes(drag.orig.kind) && ln && ln.dataset.kind === 'video' ? ln : null;
      markLane(drag.toMain);
      if (ln && ln !== drag.lane && ln.dataset.kind === k0 && (ln.dataset.track || ln.dataset.zt || ln.dataset.fxt)) {
        if (!drag.moved) { begin(); drag.moved = true; }
        ln.append(drag.el); drag.lane = ln;
        drag.el.style.top = ''; drag.el.style.height = ''; drag.el.style.bottom = '';
      }
    }
    if (!drag.moved) { begin(); drag.moved = true; }
    const it = findSel({ type: drag.type, id: drag.id });
    const o = drag.orig;
    if (isSeg(drag.type)) {
      rippleEdge(dt * (o.speed || 1));
      const cur = proj.segs.find((x) => x.id === drag.id);
      if (!drag.raf) drag.raf = requestAnimationFrame(() => { if (drag) drag.raf = 0; renderTimeline(); });
      if (cur) seekQuiet(drag.edge === 'l' ? cur.a + 0.01 : cur.b - 0.05);
      return;
    }
    // magnete sui blocchi: aggancia l'inizio o la fine a bordi vicini e alla testina
    const sn = (t) => snapFind(t, drag.id, true);
    const snapMove = (a, len) => { const [sa, da] = sn(a), [sb, db] = sn(a + len); if (da <= db && da < SNAP_PX) { showSnap(sa); return sa; } if (db < SNAP_PX) { showSnap(sb); return sb - len; } showSnap(null); return a; };
    const snapEdge = (t) => { const [st, d] = sn(t); showSnap(d < SNAP_PX ? st : null); return d < SNAP_PX ? st : t; };
    if (drag.type === 'sclip' && o.kind === 'image') {
      // immagine: nessun limite di durata
      if (drag.edge === 'move') it.a = Math.max(0, Math.min(D - 0.1, snapMove(sh(o.a), o.dur)));
      else if (drag.edge === 'l') { const d = Math.max(-o.a, Math.min(o.dur - 0.2, snapEdge(sh(o.a)) - o.a)); it.a = o.a + d; it.dur = o.dur - d; if (o.kf) it.kf = o.kf.map((k) => ({ ...k, t: +(k.t - d).toFixed(3) })); }
      else it.dur = Math.max(0.2, Math.min(D - o.a, snapEdge(sh(o.a + o.dur)) - o.a));
      drag.el.style.left = X(it.a) + 'px'; drag.el.style.width = Math.max(4, XW(it.a, it.a + it.dur)) + 'px';
      seekQuiet(drag.edge === 'r' ? it.a + it.dur - 0.05 : it.a);
    } else if (drag.type === 'sclip') {
      const fileDur = o.fileDur || (o.offset + o.dur);
      if (drag.edge === 'move') it.a = Math.max(0, Math.min(D - 0.1, snapMove(sh(o.a), o.dur)));
      else if (drag.edge === 'l') { const d = Math.max(-o.offset, Math.min(o.dur - 0.2, snapEdge(sh(o.a)) - o.a)); it.a = o.a + d; it.offset = o.offset + d; it.dur = o.dur - d; }
      else it.dur = Math.max(0.2, Math.min(fileDur - o.offset, snapEdge(sh(o.a + o.dur)) - o.a));
      drag.el.style.left = X(it.a) + 'px'; drag.el.style.width = Math.max(4, XW(it.a, it.a + it.dur)) + 'px';
    } else {
      const minLen = drag.type === 'zoom' ? 0.8 : 0.3;
      if (drag.edge === 'move') { const len = o.b - o.a; it.a = Math.max(0, Math.min(D - len, snapMove(sh(o.a), len))); it.b = it.a + len; }
      else if (drag.edge === 'l') {
        it.a = Math.max(0, Math.min(o.b - minLen, snapEdge(sh(o.a))));
        if (o.kf) it.kf = o.kf.map((k) => ({ ...k, t: +(k.t - (it.a - o.a)).toFixed(3) }));   // i keyframe restano nello stesso punto del video
      }
      else it.b = Math.min(D, Math.max(o.a + minLen, snapEdge(sh(o.b))));
      drag.el.style.left = X(it.a) + 'px'; drag.el.style.width = Math.max(4, XW(it.a, it.b)) + 'px';
      seekQuiet(drag.edge === 'r' ? it.b - 0.05 : it.a);
    }
  }
  // bordo di un pezzo, come CapCut: tirandolo dentro la parte tagliata sparisce dalla timeline,
  // tirandolo fuori torna la parte che avevi tagliato (o eliminato)
  let limitT = 0;
  const limitHint = () => { if (Date.now() - limitT > 4000) { limitT = Date.now(); toast(tx('Il video finisce qui: non si può allungare oltre la sua durata')); } };
  function rippleEdge(dS) {
    const segs = JSON.parse(JSON.stringify(drag.segs0));
    const i = segs.findIndex((x) => x.id === drag.id);
    if (i < 0) return;
    const it = segs[i], MIN = 0.1;
    // una clip si allunga solo dentro il suo video: oltre la fine (o prima dell'inizio) del file non c'e' niente
    const same = (x) => x && (x.ins || null) === (it.ins || null);
    const goneSeg = (a, b) => ({ ...it, id: uid('s'), a, b, removed: true, gone: true, auto: false, speed: undefined, fin: false, fout: false, adj: undefined, fx: undefined });
    if (drag.edge === 'r') {
      const nb = segs[i + 1], b0 = it.b;
      let x = b0 + dS;
      if (x < b0) {
        x = Math.max(it.a + MIN, x);
        if (nb && nb.gone) nb.a = x; else segs.splice(i + 1, 0, goneSeg(x, b0));
        it.b = x;
      } else if (!same(nb)) { it.b = b0; limitHint(); }
      else if (nb.gone) { x = Math.min(x, nb.b); it.b = x; nb.a = x; if (nb.b - nb.a < 0.02) { it.b = nb.b; segs.splice(i + 1, 1); } }
      else { x = Math.min(x, nb.b - MIN); it.b = x; nb.a = x; }
    } else {
      const nb = segs[i - 1], a0 = it.a;
      let x = a0 + dS;
      if (x > a0) {
        x = Math.min(it.b - MIN, x);
        if (nb && nb.gone) nb.b = x; else segs.splice(i, 0, goneSeg(a0, x));
        it.a = x;
      } else if (!same(nb)) { it.a = a0; limitHint(); }
      else if (nb.gone) { x = Math.max(x, nb.a); it.a = x; nb.b = x; if (nb.b - nb.a < 0.02) { it.a = nb.a; segs.splice(i - 1, 1); } }
      else { x = Math.max(x, nb.a + MIN); it.a = x; nb.b = x; }
    }
    proj.segs = segs;
  }
  // Q / W: taglia la parte prima / dopo la testina dell'elemento selezionato (o della clip video sotto la testina)
  function trimAt(side) {
    const t = video.currentTime, left = side === 'left';
    const within = (a, b) => t > a + 0.05 && t < b - 0.05;
    let list = (multi.length > 1 ? multi : sel ? [sel] : []).map((m) => ({ m, o: findSel(m) })).filter((x) => x.o && x.m.type !== 'track' && x.m.type !== 'subs' && x.m.type !== 'sub');
    const hadSel = list.length > 0;
    list = list.filter(({ m, o }) => (m.type === 'sclip' ? within(o.a, o.a + o.dur) : within(o.a, o.b)));
    if (hadSel && !list.length) return toast('Porta la testina dentro l\'elemento selezionato.', true);
    if (!list.length) {
      const c = proj.segs.find((x) => !x.gone && !(BLANK && !x.ins) && within(x.a, x.b));
      if (c) list = [{ m: { type: 'seg', id: c.id }, o: c }];
    }
    if (!list.length) return toast('Metti la testina dentro l\'elemento da tagliare.', true);
    begin();
    for (const { m, o } of list) {
      if (isSeg(m.type)) {
        // il pezzo tagliato sparisce dalla timeline (come CapCut); si recupera tirando il bordo
        const i = proj.segs.indexOf(o);
        const g = { ...o, id: uid('s'), removed: true, gone: true, auto: false, speed: undefined, adj: undefined, fx: undefined };
        if (left) { g.a = o.a; g.b = t; o.a = t; proj.segs.splice(i, 0, g); } else { g.a = t; g.b = o.b; o.b = t; proj.segs.splice(i + 1, 0, g); }
      } else if (m.type === 'sclip') {
        if (left) { const d = t - o.a; o.a = +t.toFixed(3); o.dur = +(o.dur - d).toFixed(3); if (o.kind !== 'image') o.offset = (o.offset || 0) + d; else if (o.kf) o.kf = o.kf.map((k) => ({ ...k, t: +(k.t - d).toFixed(3) })).filter((k) => k.t >= 0); }
        else o.dur = +(t - o.a).toFixed(3);
      } else if (left) o.a = +t.toFixed(2);
      else o.b = +t.toFixed(2);
    }
    tidySegs();
    changed();
  }
  function tidySegs() {
    proj.segs.forEach((c) => { c.a = +c.a.toFixed(2); c.b = +c.b.toFixed(2); });
    proj.segs = proj.segs.filter((c) => c.b - c.a >= 0.02);
    for (let k = 1; k < proj.segs.length; k++) proj.segs[k].a = proj.segs[k - 1].b;
    if (proj.segs.length) { proj.segs[0].a = 0; proj.segs[proj.segs.length - 1].b = D; }
    // due pezzi eliminati uno accanto all'altro diventano uno solo
    for (let k = proj.segs.length - 1; k > 0; k--) { const p = proj.segs[k - 1], c = proj.segs[k]; if (p.gone && c.gone) { p.b = c.b; proj.segs.splice(k, 1); } }
  }
  // immagine nella traccia principale: tirando il bordo destro dura di piu' (o di meno); le clip dopo scorrono
  function startImageStretch(e, seg, el) {
    const rec = insById(seg.ins);
    if (!rec || !rec.image) return false;
    const own = proj.segs.filter((c) => c.ins === rec.id);
    const last = own.filter((c) => !c.gone).sort((x, y) => y.b - x.b)[0];
    if (!last || last.id !== seg.id || own.some((c) => c.gone && c.a >= seg.b - 1e-3)) return false;   // c'e' una parte nascosta: la ritira il bordo normale
    e.preventDefault();
    const x0 = e.clientX, sp = seg.speed || 1, max = (rec.fileDur || rec.dur) - (rec.offset || 0);
    const w0 = el.offsetWidth, len0 = rec.dur;
    let len = len0;
    const mv = (ev) => {
      len = Math.max(0.2, Math.min(max, len0 + ((ev.clientX - x0) / pps) * sp));
      len = Math.max(len0 - (seg.b - seg.a) + 0.2, len);
      el.style.width = Math.max(4, w0 + ((len - len0) / sp) * pps) + 'px';
      seekQuiet(rec.at + len - 0.05);
    };
    const up = async () => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
      len = +len.toFixed(2);
      if (Math.abs(len - len0) < 0.02) { renderTimeline(); return; }
      const snap = fullSnap();
      const r = removeCore(rec.id);
      if (!r) return;
      const segs = r.own.map((c) => (c.id === seg.id ? { ...c, b: +(c.b + (len - len0)).toFixed(4) } : c));
      insertCore({ ...r.copy, dur: len, words: r.copy.words }, segs);
      pushFull(snap);
      await afterDurationChange();
      sel = { type: 'seg', id: seg.id };
      changed({ transcript: true });
    };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    return true;
  }
  // ---- trascinare una clip delle tracce (foto, video, testi, suoni) come in CapCut: la clip vera segue il mouse,
  // si appoggia sulla traccia sotto il puntatore; se li' si sovrappone a un'altra (o la lasci tra due tracce)
  // nasce da sola una traccia nuova subito sopra. Foto e video si possono lasciare anche nella traccia principale.
  function startClipFloat(e, c, el) {
    const tr0 = trackOfClip(c.id);
    if (!tr0) return;
    const kind = tr0.type === 'sound' ? 'sound' : 'overlay';
    const x0 = e.clientX, y0 = e.clientY, r0 = el.getBoundingClientRect();
    const gx = e.clientX - r0.left, gy = e.clientY - r0.top;
    const grabT = Math.max(0, tAt(e) - c.a);
    const orig = { a: c.a };
    let moved = false, fl = null, line = null, tgt = null;
    capPtr(el, e.pointerId);
    const laneAtY = (y) => [...lanes.querySelectorAll('.lane[data-kind]')].find((ln) => { const r = ln.getBoundingClientRect(); return y >= r.top && y < r.bottom; });
    const clearLine = () => { if (line) line.style.display = 'none'; };
    const showLine = (ln, where) => {
      if (!line) { line = h('div', { class: 'newtrack-line' }, h('span', null, 'Nuova traccia')); tl.append(line); }
      const r = ln.getBoundingClientRect(), tr = tl.getBoundingClientRect();
      Object.assign(line.style, { display: '', top: (where === 'above' ? r.top - 4 : r.bottom + 1) - tr.top + 'px', left: r.left - tr.left + 'px', width: r.width + 'px' });
    };
    const overlaps = (track, a, dur) => track.clips.some((o) => o !== c && o.a < a + dur - 1e-3 && o.a + o.dur > a + 1e-3);
    const mv = (ev) => {
      if (!moved && Math.abs(ev.clientX - x0) < 4 && Math.abs(ev.clientY - y0) < 4) return;
      if (!moved) {
        moved = true; begin();
        fl = el.cloneNode(true); fl.classList.add('floatclip'); fl.classList.remove('sel');
        Object.assign(fl.style, { position: 'fixed', left: r0.left + 'px', top: r0.top + 'px', width: r0.width + 'px', height: r0.height + 'px', bottom: 'auto', margin: '0' });
        document.body.append(fl);
        el.classList.add('floatsrc');
      }
      // dove andrebbe (tempo, agganciato ai bordi vicini e alla testina)
      let a = Math.max(0, tAt(ev) - grabT);
      const [sa, da] = snapFind(a, c.id, true), [sb, db] = snapFind(a + c.dur, c.id, true);
      if (da <= db && da < SNAP_PX) { a = sa; showSnap(sa); } else if (db < SNAP_PX) { a = Math.max(0, sb - c.dur); showSnap(sb); } else showSnap(null);
      a = +Math.min(D - 0.1, a).toFixed(2);
      const ln = laneAtY(ev.clientY);
      const innerL = inner.getBoundingClientRect().left;
      let fx = ev.clientX - gx, fy = ev.clientY - gy, snapped = false;
      tgt = null; clearLine(); markLane(null);
      if (ln && ln.dataset.kind === kind && ln.dataset.track) {
        const track = proj.tracks.find((x) => x.id === ln.dataset.track);
        const r = ln.getBoundingClientRect();
        const edgeZone = Math.min(9, r.height * 0.22);
        if (kind === 'overlay' && ev.clientY < r.top + edgeZone) { tgt = { newAbove: ln, a }; showLine(ln, 'above'); }
        else if (track && overlaps(track, a, c.dur)) { tgt = { newAbove: ln, a }; if (kind === 'overlay') showLine(ln, 'above'); else tgt = { newSound: true, a }; }
        else { tgt = { track, a }; fx = innerL + X(a); fy = r.top + (r.height - r0.height) / 2; snapped = true; }
      } else if (ln && ln.dataset.kind === 'video' && kind === 'overlay' && ['image', 'video'].includes(c.kind)) {
        tgt = { main: true }; markLane(ln);
      } else if (ln && kind === 'overlay') {
        // sopra testi/zoom o tra le tracce: una traccia nuova in quel punto
        tgt = { newAbove: ln, a }; showLine(ln, 'above');
      } else if (!ln && kind === 'overlay') {
        const first = lanes.querySelector('.lane[data-kind]');
        if (first && ev.clientY < first.getBoundingClientRect().top) { tgt = { newAbove: first, a }; showLine(first, 'above'); }
      }
      fl.classList.toggle('snapped', snapped);
      fl.style.left = fx + 'px'; fl.style.top = fy + 'px';
      const sr = scroller.getBoundingClientRect();   // vicino ai bordi la timeline scorre
      if (ev.clientX > sr.right - 30) scroller.scrollLeft += 12; else if (ev.clientX < sr.left + 30) scroller.scrollLeft -= 12;
    };
    const up = async (ev) => {
      el.removeEventListener('pointermove', mv);
      showSnap(null); clearLine(); markLane(null);
      if (line) line.remove();
      if (!moved) { renderTimeline(); renderPanel(); tapSeek(ev, Math.max(c.a, Math.min(c.a + c.dur - 0.02, tAt(ev)))); return; }
      if (fl) fl.remove();
      el.classList.remove('floatsrc');
      if (!tgt) { renderTimeline(); return; }   // lasciata fuori: resta dov'era
      if (tgt.main) { c.a = orig.a; await overlayToMain(c, tAt(ev) - grabT); return; }
      const from = trackOfClip(c.id);
      let to = tgt.track;
      if (tgt.newAbove || tgt.newSound) {
        to = newTrack(kind);
        if (kind === 'overlay' && tgt.newAbove) placeTrackAbove(to, tgt.newAbove);   // subito sopra quella indicata
      }
      c.a = tgt.a;
      if (from && to && from !== to) { from.clips = from.clips.filter((x) => x !== c); to.clips.push(c); }
      if (to) to.clips.sort((x, y) => x.a - y.a);
      sel = { type: 'sclip', id: c.id };
      changed();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }
  async function onDragEnd(e) {
    if (!drag) return;
    if (isSeg(drag.type)) {
      window.removeEventListener('pointermove', onDragMove);
      if (drag.raf) cancelAnimationFrame(drag.raf);
      const moved = drag.moved;
      drag = null;
      if (moved) { tidySegs(); changed(); } else { renderTimeline(); renderPanel(); }
      return;
    }
    drag.el.removeEventListener('pointermove', onDragMove);
    showSnap(null);
    const moved = drag.moved;
    const it = findSel({ type: drag.type, id: drag.id });
    const clickT = drag.clickT;
    drag.el.style.pointerEvents = '';
    const lane = drag.lane, lane0 = drag.lane0, toMain = drag.toMain, orig = drag.orig;
    drag = null;
    markLane(null);
    if (moved && toMain && it) { it.a = orig.a; if (orig.dur !== undefined) it.dur = orig.dur; await overlayToMain(it, tAt(e)); return; }
    if (moved && it && lane && lane !== lane0) {
      if (lane.dataset.zt) it.track = lane.dataset.zt;
      else if (lane.dataset.fxt) it.track = lane.dataset.fxt;
      else if (lane.dataset.track) {
        const from = trackOfClip(it.id), to = proj.tracks.find((t) => t.id === lane.dataset.track);
        if (from && to && from !== to) { from.clips = from.clips.filter((c) => c !== it); to.clips.push(it); to.clips.sort((x, y) => x.a - y.a); }
      }
    }
    if (moved) {
      if (it && it.a !== undefined && it.b !== undefined) { it.a = +it.a.toFixed(2); it.b = +it.b.toFixed(2); }
      if (sel && isSeg(sel.type)) { const i = proj.segs.indexOf(it); if (proj.segs[i - 1]) proj.segs[i - 1].b = it.a; if (proj.segs[i + 1]) proj.segs[i + 1].a = it.b; }
      if (it && it.dur !== undefined) { it.a = +it.a.toFixed(2); it.dur = +it.dur.toFixed(2); }
      if (sel && sel.type === 'zoom') proj.zooms.sort((a, b) => a.a - b.a);
      changed();
    } else {
      renderTimeline(); renderPanel();
      // clic su un blocco: solo selezione; doppio clic: la testina va li'
      if (it) {
        const a0 = it.a, b0 = it.dur !== undefined ? it.a + it.dur : it.b;
        tapSeek(e, Math.max(a0, Math.min(b0 - 0.02, clickT)));
      }
    }
  }

  // la testina si sposta solo col doppio clic (il righello invece la trascina sempre)
  let lastTap = null;
  function tapSeek(e, t) {
    const now = performance.now(), x = e ? e.clientX : 0, y = e ? e.clientY : 0;
    if (lastTap && now - lastTap.t < 380 && Math.hypot(x - lastTap.x, y - lastTap.y) < 8) { lastTap = null; seek(t); return true; }
    lastTap = { t: now, x, y }; return false;
  }
  // clic sul righello o sullo sfondo: sposta la testina
  function tAt(e) { return Math.max(0, Math.min(D, T((e.clientX - inner.getBoundingClientRect().left) / pps))); }
  let scrub = false;
  // magnete: la testina e i blocchi si agganciano ai bordi vicini (clip, zoom, filtri, immagini, suoni)
  let snapOn = store.get('snap', true);
  const SNAP_PX = 10;
  const snapLine = h('div', { class: 'snapline', style: { display: 'none' } });
  inner.append(snapLine);
  function snapTargets(exceptId) {
    const r = [0, D];
    for (const c of proj.segs) if (!c.gone) r.push(c.a, c.b);
    for (const m of proj.markers || []) if (m.id !== exceptId) r.push(m.t);
    for (const z of proj.zooms) if (z.id !== exceptId) r.push(z.a, z.b);
    for (const f of proj.filters) if (f.id !== exceptId) r.push(f.a, f.b);
    for (const tr of clipTracks()) for (const c of tr.clips) if (c.id !== exceptId) r.push(c.a, c.a + c.dur);
    if (proj.settings.showSubs) for (const ch of subChunks()) if (!ch.hidden) r.push(ch.a, ch.b);
    return r;
  }
  function showSnap(t) { if (t == null) snapLine.style.display = 'none'; else Object.assign(snapLine.style, { display: '', left: X(t) + 'px' }); }
  // ritorna [tempo agganciato, distanza in px] (se non c'e' niente vicino: tempo invariato)
  function snapFind(t, exceptId, withPlayhead) {
    if (!snapOn) return [t, Infinity];
    const xt = X(t);
    let best = t, bd = SNAP_PX;
    for (const s2 of snapTargets(exceptId)) { const d = Math.abs(X(s2) - xt); if (d < bd) { bd = d; best = s2; } }
    if (withPlayhead) { const pt = video.currentTime, d = Math.abs(X(pt) - xt); if (d < bd) { bd = d; best = pt; } }
    return [best, bd];
  }
  function snapT(t, exceptId, withPlayhead) { const [b, d] = snapFind(t, exceptId, withPlayhead); showSnap(d < SNAP_PX ? b : null); return b; }
  // clic sul righello: sposta la testina. Trascinando sulle tracce: rettangolo di selezione (come in Windows)
  let marq = null;
  inner.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('.blk, button, .lane-cta')) return;
    capPtr(inner, e.pointerId);
    if (e.target.closest('.ruler') || e.target === playhead) {
      scrub = true;
      stopReverse(); if (!video.paused) video.pause();   // sposti la testina: il video si ferma (non riparte da solo)
      if (sel && sel.type !== 'track') { sel = null; multi = []; renderTimeline(); renderPanel(); }
      seek(snapT(tAt(e))); return;
    }
    startMarquee(e);
  });
  function startMarquee(e, segClick) {
    capPtr(inner, e.pointerId);
    const r = inner.getBoundingClientRect();
    marq = { x0: e.clientX - r.left, y0: e.clientY - r.top, t: tAt(e), el: null, add: e.ctrlKey || e.shiftKey || e.metaKey, base: multi.slice(), segClick };
  }
  inner.addEventListener('pointermove', (e) => {
    if (scrub) { seekQuiet(snapT(tAt(e))); return; }
    if (!marq) return;
    const r = inner.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    if (!marq.el && Math.hypot(x - marq.x0, y - marq.y0) < 5) return;
    if (!marq.el) { marq.el = h('div', { class: 'marquee' }); inner.append(marq.el); }
    const L = Math.min(x, marq.x0), Tt = Math.min(y, marq.y0), Wd = Math.abs(x - marq.x0), Hd = Math.abs(y - marq.y0);
    Object.assign(marq.el.style, { left: L + 'px', top: Tt + 'px', width: Wd + 'px', height: Hd + 'px' });
    const box = { l: r.left + L, t: r.top + Tt, r: r.left + L + Wd, b: r.top + Tt + Hd };
    const hit = [];
    lanes.querySelectorAll('.blk[data-type][data-id]').forEach((b) => {
      if (b.style.display === 'none') return;
      const q = b.getBoundingClientRect();
      const on = q.right > box.l && q.left < box.r && q.bottom > box.t && q.top < box.b;
      b.classList.toggle('sel', on || marq.base.some((m) => m.id === b.dataset.id));
      if (on) hit.push({ type: b.dataset.type, id: b.dataset.id });
    });
    marq.hit = hit;
  });
  inner.addEventListener('pointerup', (ev) => {
    scrub = false; showSnap(null);
    if (!marq) return;
    const m = marq; marq = null;
    if (!m.el && m.segClick) {
      // clic su un pezzo: selezionato; doppio clic: la testina va dove hai cliccato
      const c = m.segClick.item;
      multi = []; framing = false; sel = { type: m.segClick.type, id: c.id };
      tab = tabFor(sel); renderTimeline(); renderPanel(); tapSeek(ev, snapT(m.segClick.t)); showSnap(null); return;
    }
    if (!m.el) { multi = []; if (sel && sel.type !== 'track') sel = null; renderTimeline(); renderPanel(); tapSeek(ev, snapT(m.t)); showSnap(null); return; }
    m.el.remove();
    const seen = new Set(), all = [];
    for (const x of [...(m.add ? m.base : []), ...(m.hit || [])]) { const k = x.type + x.id; if (!seen.has(k)) { seen.add(k); all.push(x); } }
    multi = all.length > 1 ? all : [];
    sel = all.length ? { ...all[all.length - 1] } : null;
    if (sel) tab = tabFor(sel);
    renderTimeline(); renderPanel();
  });
  // tasto destro: menu dell'app (niente menu del browser)
  lanes.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const b = e.target.closest('.blk[data-type][data-id]');
    if (!b) return;
    const it = { type: b.dataset.type, id: b.dataset.id };
    if (!multi.some((m) => m.type === it.type && m.id === it.id) && !(sel && sel.type === it.type && sel.id === it.id)) { multi = []; sel = it; tab = tabFor(it); renderTimeline(); renderPanel(); }
    popMenuAt(e.clientX, e.clientY, blockMenu(it, e));
  });

  // zoom della timeline
  // zoom fluido: tanti eventi (trackpad) -> un solo ridisegno per fotogramma
  let ppsQ = null, ppsRaf = 0;
  let ppsFull = 0;
  function setPpsSmooth(v, anchorT) {
    ppsQ = { v, anchorT };
    if (!ppsRaf) ppsRaf = requestAnimationFrame(() => { ppsRaf = 0; const q = ppsQ; ppsQ = null; if (q) setPpsFast(q.v, q.anchorT); });
  }
  // zoom veloce: niente ricostruzione della timeline, solo posizioni e larghezze (poi, fermo il gesto, il ridisegno vero)
  function setPpsFast(v, anchorT) {
    const oldX = anchorT != null ? X(anchorT) - scroller.scrollLeft : 0;
    pps = Math.max(Math.min(fitPps, pps), Math.min(200, v));
    zoomSlider.value = String(Math.round(1000 * Math.log(pps / fitPps) / Math.log(Math.max(1.0001, 200 / fitPps))));
    inner.style.width = Math.max(scroller.clientWidth, BLANK ? (viewEnd + Math.max(20, viewEnd * 0.3)) * pps : X(D)) + 'px';
    for (const el of lanes.querySelectorAll('[data-a]')) {
      const a = +el.dataset.a, b = +el.dataset.b;
      el.style.left = X(a) + 'px'; el.style.width = Math.max(4, XW(a, b)) + 'px';
    }
    if (anchorT != null) scroller.scrollLeft = X(anchorT) - oldX;
    drawWave(); drawThumbs(); renderRuler(); playhead.style.left = X(video.currentTime) + 'px';
    clearTimeout(ppsFull); ppsFull = setTimeout(() => { const t = anchorT; setPps(pps, t); }, 160);
  }
  function setPps(v, anchorT) {
    const oldX = anchorT != null ? X(anchorT) - scroller.scrollLeft : 0;
    pps = Math.max(Math.min(fitPps, pps), Math.min(200, v));
    zoomSlider.value = String(Math.round(1000 * Math.log(pps / fitPps) / Math.log(Math.max(1.0001, 200 / fitPps))));
    renderTimeline();
    if (anchorT != null) scroller.scrollLeft = X(anchorT) - oldX;
    drawWave(); drawThumbs(); renderRuler();
  }
  zoomSlider.addEventListener('input', () => {
    const k = +zoomSlider.value / 1000;
    setPps(fitPps * Math.pow(200 / fitPps, k), video.currentTime);
  });
  // trackpad del Mac: pizzico con due dita = zoom della timeline (Safari manda "gesture", Chrome la rotella con Ctrl)
  let pinch0 = 0, pinchT = 0;
  scroller.addEventListener('gesturestart', (e) => { e.preventDefault(); pinch0 = pps; pinchT = tAt(e); });
  scroller.addEventListener('gesturechange', (e) => { e.preventDefault(); if (pinch0) setPpsSmooth(pinch0 * e.scale, pinchT); });
  scroller.addEventListener('gestureend', (e) => { e.preventDefault(); pinch0 = 0; });
  scroller.addEventListener('wheel', (e) => {
    if (e.ctrlKey || e.metaKey) {
      // rotella: scatti; trackpad (tanti piccoli movimenti): continuo
      e.preventDefault();
      const cur = ppsQ ? ppsQ.v : pps;
      const k = Math.abs(e.deltaY) >= 50 ? (e.deltaY < 0 ? 1.25 : 0.8) : Math.exp(-e.deltaY * 0.012);
      setPpsSmooth(cur * k, tAt(e));
    }
    else if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      // tante tracce (non ci stanno tutte): la rotella le scorre su e giu' (Maiusc + rotella: avanti e indietro nel tempo)
      const tm = tlMain, canV = tm.scrollHeight > tm.clientHeight + 2;
      if (canV && !e.shiftKey) {
        e.preventDefault(); tm.scrollTop += e.deltaY; return;
      }
      e.preventDefault(); scroller.scrollLeft += e.deltaY;
    }
  }, { passive: false });
  let scrollRaf = 0;
  scroller.addEventListener('scroll', () => {
    cancelAnimationFrame(scrollRaf);
    scrollRaf = requestAnimationFrame(() => { drawWave(); drawThumbs(); renderRuler(); });
  });

  // trascina sulla timeline: dai Media o direttamente dal PC
  let dropLane = null, dragAsset = null;
  const EMPTY_IMG = new Image(); EMPTY_IMG.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  const insMark = h('div', { class: 'insmark', style: { display: 'none' } });
  const clearDrop = () => { if (dropLane) dropLane.classList.remove('dropping'); dropLane = null; insMark.style.display = 'none'; if (typeof dropGhost !== 'undefined') dropGhost.style.display = 'none'; if (typeof dragCard !== 'undefined') dragCard.style.display = 'none'; if (typeof dropLabel !== 'undefined') dropLabel.style.display = 'none'; };
  // la traccia sotto il mouse (anche se sopra c'e' altro: testina, miniature, bordi)
  function laneAt(e) {
    for (const ln of tl.querySelectorAll('.lane[data-kind]')) {
      const r = ln.getBoundingClientRect();
      if (e.clientY >= r.top && e.clientY < r.bottom) return ln;
    }
    return null;
  }
  const dropGhost = h('div', { class: 'dropghost', style: { display: 'none' } }, h('b'), h('span'));
  const dragCard = h('div', { class: 'dragcard', style: { display: 'none' } });
  const dropLabel = h('div', { class: 'droplabel', style: { display: 'none' } });
  // se il blocco e' stretto il nome va accanto, non schiacciato dentro
  function placeDropLabel(lane, x, text, show) {
    if (!show) { dropLabel.style.display = 'none'; return; }
    if (dropLabel.parentNode !== lane) lane.append(dropLabel);
    dropLabel.textContent = text;
    Object.assign(dropLabel.style, { display: '', left: x + 6 + 'px' });
  }
  document.body.append(dragCard);
  const assetLen = (a, t) => (a.kind === 'image' ? Math.min(5, Math.max(0.3, D - t)) : Math.max(0.2, a.duration || 3));
  tl.addEventListener('dragover', (e) => {
    e.preventDefault();
    const ln = laneAt(e);
    let ok = ln && (ln.dataset.kind === 'video' || ln.dataset.track) ? ln : null;
    // un'immagine o un suono non va nella traccia principale; un video si', e anche sopra
    if (ok && dragAsset) {
      const k = dragAsset.kind, lk = ok.dataset.kind;
      if ((lk === 'video' && k !== 'video') || (lk === 'overlay' && k === 'audio') || (lk === 'sound' && k !== 'audio')) ok = null;
    }
    if (ok !== dropLane) { if (dropLane) dropLane.classList.remove('dropping'); dropLane = ok; if (ok) ok.classList.add('dropping'); }
    if (!dragAsset) { insMark.style.display = 'none'; return; }
    dragCard.style.display = ok ? 'none' : '';
    if (!ok) { dropGhost.style.display = 'none'; insMark.style.display = 'none'; dropLabel.style.display = 'none'; return; }
    const main = ok.dataset.kind === 'video';
    const t = main ? mainDropT(tAt(e)) : tAt(e);
    const len = assetLen(dragAsset, t);
    if (dropGhost.parentNode !== ok) ok.append(dropGhost);
    dropGhost.className = 'dropghost ' + (main ? 'main' : dragAsset.kind);
    dropGhost.firstChild.textContent = dragAsset.name.replace(/\.[^.]+$/, '');
    dropGhost.lastChild.textContent = main ? 'Entra qui · ' + fmt(len) : fmt(len);
    const gw = Math.max(12, len * pps);
    Object.assign(dropGhost.style, { display: '', left: X(t) + 'px', width: gw + 'px' });
    placeDropLabel(ok, X(t) + gw, dropGhost.firstChild.textContent + ' · ' + dropGhost.lastChild.textContent, gw < 90);
    dropGhost.classList.toggle('narrow', gw < 90);
    if (main) { if (insMark.parentNode !== ok) ok.append(insMark); insMark.style.left = X(t) - 1 + 'px'; insMark.style.display = ''; }
    else insMark.style.display = 'none';
  });
  // la schedina che segue il mouse finche' non sei sopra una traccia
  document.addEventListener('dragover', (e) => {
    if (!dragAsset) return;
    Object.assign(dragCard.style, { left: e.clientX + 12 + 'px', top: e.clientY + 12 + 'px' });
    if (!tl.contains(e.target)) { dragCard.style.display = ''; dropGhost.style.display = 'none'; dropLabel.style.display = 'none'; insMark.style.display = 'none'; if (dropLane) { dropLane.classList.remove('dropping'); dropLane = null; } }
  });
  tl.addEventListener('dragleave', (e) => { if (!tl.contains(e.relatedTarget)) clearDrop(); });
  tl.addEventListener('drop', async (e) => {
    e.preventDefault();
    const laneEl = laneAt(e);
    clearDrop(); dragAsset = null;
    const t = laneEl ? tAt(e) : video.currentTime;
    const main = !!(laneEl && laneEl.dataset.kind === 'video');
    const track = main ? 'main' : laneEl && laneEl.dataset.track ? proj.tracks.find((x) => x.id === laneEl.dataset.track) : null;
    const aid = e.dataTransfer.getData('application/x-vodcut-asset');
    const onMain = (a) => main && (a.kind === 'video' || a.kind === 'image');
    if (aid) { const a = proj.assets.find((x) => x.id === aid); if (a) placeAsset(a, onMain(a) ? mainDropT(t) : t, track); return; }
    const lp = e.dataTransfer.getData('application/x-vodcut-lib');
    if (lp) { const li = libItems.find((x) => x.path === lp); if (li) { const a = addAssets([li], true)[0]; placeAsset(a, onMain(a) ? mainDropT(t) : t, track); } return; }
    const got = await uploadFiles([...e.dataTransfer.files]);
    got.forEach((a, i) => placeAsset(a, onMain(a) ? mainDropT(t) : t, i === 0 ? track : null));
  });

  // ---------------------------------------------------------------- media (immagini e suoni del progetto)
  function addAssets(list, quiet) {
    const out = [];
    for (const f of list) {
      let a = proj.assets.find((x) => x.path === f.path);
      if (!a) { a = { id: uid('m'), ...f }; proj.assets.push(a); }
      out.push(a);
    }
    if (out.length) { dirty = true; flush().then(() => { if (alive && ltab === 'media' && !quiet) renderPanel(); }); }
    return out;
  }
  let importing = 0;
  async function uploadFiles(files) {
    const ok = files.filter((f) => IMG_RE.test(f.name) || AUD_RE.test(f.name) || VID_RE.test(f.name));
    if (files.length && !ok.length) { toast('Trascina video (mp4, mov…), immagini (png, jpg…) o suoni (mp3, wav…)', true); return []; }
    const got = [];
    importing += ok.length; if (ltab === 'media') renderPanel();
    for (const f of ok) {
      try {
        // trascinato nella finestra: si usa il file dov'e' (niente copia, anche se pesa giga)
        const real = await droppedPath(f);
        if (real) { got.push(await post('/api/probe-media', { path: real })); importing--; if (ltab === 'media' && alive) renderPanel(); continue; }
        if (f.size > BIG_DROP) { toast('"' + f.name + '" è molto grande: aggiungilo con "Importa", così non viene copiato', true); importing--; continue; }
        const r = await fetch('/api/upload?kind=asset&token=' + TOKEN + '&name=' + encodeURIComponent(f.name), { method: 'PUT', body: f });
        const j = await r.json();
        if (!r.ok) { toast(j.error || 'Import non riuscito', true); continue; }
        got.push(j);
      } catch (err) { toast('Import non riuscito: ' + err.message, true); }
      importing--; if (ltab === 'media' && alive) renderPanel();
    }
    importing = 0;
    return addAssets(got);
  }
  async function importMedia() {
    try {
      const r = await post('/api/pick', { kind: 'media' });
      if (r.fallback) {
        const inp = h('input', { class: 'input', placeholder: 'C:\\...\\immagine.png', style: { width: '100%' } });
        const ok = await new Promise((res) => {
          const bg = h('div', { class: 'modal-bg' });
          const done = (v) => { bg.remove(); res(v); };
          bg.append(h('div', { class: 'modal' }, h('h2', null, 'Percorso del file'), h('p', null, 'Incolla il percorso completo dell\'immagine o del suono, oppure trascinalo qui.'), inp,
            h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: () => done(false) }, 'Annulla'), h('button', { class: 'btn primary', onclick: () => done(true) }, 'Aggiungi'))));
          document.body.append(bg); inp.focus();
          inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') done(true); });
        });
        if (!ok || !inp.value.trim()) return [];
        return addAssets([await post('/api/probe-media', { path: inp.value.trim() })]);
      }
      if (r.skipped && r.skipped.length) toast('Formato non supportato: ' + r.skipped.join(', '), true);
      return addAssets(r.files || []);
    } catch (e) { toast(e.message, true); return []; }
  }
  function newTrack(kind) {
    if (kind === 'overlay') {
      const n = ovTracks().length;
      const t = { id: uid('t'), type: 'overlay', name: 'Video ' + (n + 1), hidden: false, color: OV_COLORS[n % OV_COLORS.length], clips: [] };
      proj.tracks.push(t); proj.layers = normLayers(); freshTracks.add(t.id);
      return t;
    }
    const n = soundTracks().length;
    const t = { id: uid('t'), name: 'Audio ' + (n + 1), type: 'sound', vol: 100, mute: false, color: SOUND_COLORS[n % SOUND_COLORS.length], clips: [] };
    proj.tracks.push(t); freshTracks.add(t.id);
    return t;
  }
  // mette un elemento dei Media sulla timeline (sulla traccia giusta, o su una nuova)
  // sulla traccia principale un video entra tra due clip: si aggancia al bordo piu' vicino
  // trascinare un video inserito sulla traccia principale: lo si porta prima o dopo le altre clip
  // ---- spostare foto e video tra la traccia principale e le tracce sopra (e viceversa), trascinandoli
  function laneUnder(ev, kind) {
    const u = document.elementsFromPoint(ev.clientX, ev.clientY).find((x) => x.classList && x.classList.contains('lane'));
    return u && u.dataset.kind === kind ? u : null;
  }
  function markLane(ln) { lanes.querySelectorAll('.lane.xdrop').forEach((x) => { if (x !== ln) x.classList.remove('xdrop'); }); if (ln) ln.classList.add('xdrop'); }
  // qualsiasi clip vera della traccia principale puo' salire su una traccia sopra (anche i pezzi del video di base)
  const canLeaveMain = (seg) => {
    if (!seg || IS_V || isGapSeg(seg)) return false;
    const rec = seg.ins && insById(seg.ins);
    if (rec) return !rec.gap;
    return !BLANK;   // pezzo del video di partenza (nel progetto vuoto e' solo nero)
  };
  // clip della traccia principale portata in alto: su una traccia video sopra, oppure una traccia nuova (riga "Nuova traccia")
  let upLine = null;
  function upTarget(ev) {
    const main = lanes.querySelector('.lane[data-kind="video"]');
    if (!main || ev.clientY >= main.getBoundingClientRect().top) { hideUpLine(); return null; }
    const all = [...lanes.querySelectorAll('.lane[data-kind]')];
    const ln = all.find((l) => { const r = l.getBoundingClientRect(); return ev.clientY >= r.top && ev.clientY < r.bottom; });
    if (ln && ln.dataset.kind === 'overlay') {
      const r = ln.getBoundingClientRect();
      if (ev.clientY >= r.top + Math.min(9, r.height * 0.22)) { hideUpLine(); return { lane: ln }; }
    }
    const at = ln || all[0];
    if (!upLine) { upLine = h('div', { class: 'newtrack-line' }, h('span', null, 'Nuova traccia')); tl.append(upLine); }
    const r = at.getBoundingClientRect(), tr = tl.getBoundingClientRect();
    Object.assign(upLine.style, { display: '', top: r.top - 4 - tr.top + 'px', left: r.left - tr.left + 'px', width: r.width + 'px' });
    return { newAbove: at };
  }
  function hideUpLine() { if (upLine) upLine.style.display = 'none'; }
  // traccia nuova subito sopra la corsia indicata
  function placeTrackAbove(to, laneEl) {
    const key = 'ov:' + to.id, below = laneEl && (laneEl.dataset.layer || (laneEl.dataset.kind === 'video' ? 'video' : null));
    const rest = proj.layers.filter((k) => k !== key);
    const i = below ? rest.indexOf(below) : -1;
    if (i >= 0) { rest.splice(i, 0, key); proj.layers = rest; proj.layers = normLayers(); }
  }
  async function mainToOverlay(seg, target, t) {
    if (!canLeaveMain(seg)) return false;
    let g;
    try { g = await getGap(); } catch (e) { toast('Non riesco a preparare lo spazio vuoto: ' + e.message, true); return false; }
    const rec = (seg.ins && insById(seg.ins)) || {};
    const snap = fullSnap();
    const d = mainClipData(seg), sp = seg.speed || 1, len = +(d.dur / sp).toFixed(3);
    const b = segBox(seg);   // stesso posto e stessa grandezza che aveva nel quadro
    // la traccia principale si ricompone senza la clip: con la calamita si chiude, senza resta uno spazio vuoto.
    // Le altre tracce restano ferme (come CapCut) e la clip sale sopra, dove l'hai lasciata
    const items = mainItems();
    const k = items.findIndex((it) => it.segId === seg.id);
    if (k < 0) return false;
    let S = 0;
    for (let i = 0; i < k; i++) S += items[i].dur;
    const at = +Math.max(0, S + (t - seg.a)).toFixed(2);
    if (magnetOn()) items.splice(k, 1); else items[k] = gapItem(g, items[k].dur);
    rebuildMain(tidyItems(items, g));
    let c;
    if (rec.image) {
      c = { id: uid('c'), kind: 'image', file: rec.src || rec.file, name: (rec.name || 'Immagine').replace(/\.[^.]+$/, ''), a: at, dur: len,
        pos: { x: +b[0].toFixed(4), y: +b[1].toFixed(4), w: +b[2].toFixed(4) }, ar: +(1 / (rec.iar || 1)).toFixed(5), opacity: 100 };
    } else {
      const ar = d.w && d.h ? d.h / d.w : 1 / CA();
      c = { id: uid('c'), kind: 'video', file: d.file, name: (d.name && d.name !== 'Clip della live' ? d.name : 'Clip').replace(/\.[^.]+$/, ''), a: at, dur: len, offset: d.offset,
        fileDur: d.offset + d.dur, pos: { x: +b[0].toFixed(4), y: +b[1].toFixed(4), w: +b[2].toFixed(4) }, ar, opacity: 100,
        vol: seg.vol ?? 100, mute: !!seg.mute, hasAudio: !!d.hasAudio };
      if (d.preview) c.preview = d.preview;
    }
    const laneEl = target && target.lane;
    let tr = laneEl && laneEl.dataset.track ? proj.tracks.find((x) => x.id === laneEl.dataset.track) : null;
    const free = (x) => !x.clips.some((o) => o.a < c.a + c.dur - 1e-3 && o.a + o.dur > c.a + 1e-3);
    if (target && target.newAbove) { tr = newTrack('overlay'); placeTrackAbove(tr, target.newAbove); }
    else if (!tr || tr.type !== 'overlay' || !free(tr)) { const ln = tr ? lanes.querySelector(`.lane[data-track="${tr.id}"]`) : null; tr = newTrack('overlay'); if (ln) placeTrackAbove(tr, ln); }
    tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
    pushFull(snap);
    await afterDurationChange();
    sel = { type: 'sclip', id: c.id }; multi = []; tab = 'video';
    changed({ transcript: true });
    toast(rec.image ? 'Foto spostata su una traccia sopra' : 'Video spostato su una traccia sopra');
    return true;
  }
  async function overlayToMain(c, t) {
    const snap = fullSnap();
    const tr = trackOfClip(c.id);
    if (tr) tr.clips = tr.clips.filter((x) => x !== c);
    renderTimeline();
    const ok = await insertVideo(c.file, mainDropT(t), { name: c.name, duration: c.dur }, { dur: c.dur, offset: c.kind === 'video' ? c.offset || 0 : 0, quiet: true });
    if (!ok) { if (tr) { tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a); } changed(); return; }
    undoStack = []; pushFull(snap);
    toast(c.kind === 'image' ? 'Foto spostata nella traccia principale' : 'Video spostato nella traccia principale');
  }
  function startInsMove(e, seg, el) {
    const rec = proj.inserts.find((x) => x.id === seg.ins);
    const own = proj.segs.filter((c) => c.ins === rec.id && !c.gone);
    if (own.length > 1) {   // video diviso: si sposta solo il pezzo preso, non tutto il video
      startMainMove(e, seg, el, { own: [seg], name: (rec.name || 'Video').replace(/\.[^.]+$/, ''), dur: (seg.b - seg.a) / (seg.speed || 1), skip: null,
        drop: (target) => moveInsPiece(seg, target) });
      return;
    }
    startMainMove(e, seg, el, { own, name: (rec.name || 'Video').replace(/\.[^.]+$/, ''), dur: rec.dur, skip: rec.id,
      drop: (target) => moveInsert(rec.id, target) });
  }
  function startLiveMove(e, seg, el) {
    startMainMove(e, seg, el, { own: [seg], name: 'Clip', dur: (seg.b - seg.a) / (seg.speed || 1), skip: null, live: true,
      drop: (target) => moveLiveSeg(seg, target) });
  }
  // trascinamento di una clip della traccia principale: fantasma che segue il mouse, riga dove entra
  function startMainMove(e, seg, el, o) {
    const lane = el.parentNode, x0 = e.clientX, y0 = e.clientY;
    const own = o.own;
    const a0 = Math.min(...own.map((c) => c.a)), b0 = Math.max(...own.map((c) => c.b));
    const innerL = () => inner.getBoundingClientRect().left;
    const grab = e.clientX - innerL() - X(a0), w = Math.max(24, X(b0) - X(a0));
    let moved = false, target = null, ghost = null, xLane = null;
    capPtr(el, e.pointerId);
    const mv = (ev) => {
      if (!moved && Math.abs(ev.clientX - x0) < 5 && Math.abs(ev.clientY - y0) < 5) return;
      if (!moved) {
        moved = true;
        ghost = liftVisual(own.map((c) => c.id));
        lane.querySelectorAll('.blk.seg').forEach((b) => { if (own.some((c) => c.id === b.dataset.id)) b.classList.add('lifted'); });
      }
      const gl = Math.max(0, ev.clientX - innerL() - grab);
      if (ghost) ghost.move(gl - ghost.x0, canLeaveMain(seg) ? ev.clientY - y0 : 0);
      xLane = canLeaveMain(seg) ? upTarget(ev) : null;
      markLane(xLane && xLane.lane);
      if (xLane) { insMark.style.display = 'none'; dropLabel.style.display = 'none'; return; }
      placeDropLabel(lane, gl + w, o.name + ' · ' + fmt(o.dur), w < 90);
      target = mainDropT(tAt(ev), o.skip);
      const same = target >= a0 - 1e-3 && target <= b0 + 1e-3;
      if (insMark.parentNode !== lane) lane.append(insMark);
      insMark.style.left = X(target) - 1 + 'px'; insMark.style.display = same ? 'none' : '';
      const r = scroller.getBoundingClientRect();   // vicino ai bordi la timeline scorre
      if (ev.clientX > r.right - 30) scroller.scrollLeft += 12; else if (ev.clientX < r.left + 30) scroller.scrollLeft -= 12;
    };
    const up = async (ev) => {
      el.removeEventListener('pointermove', mv);
      insMark.style.display = 'none'; dropLabel.style.display = 'none';
      lane.querySelectorAll('.blk.lifted').forEach((b) => b.classList.remove('lifted'));
      if (!moved) { tapSeek(ev, Math.max(seg.a, Math.min(seg.b - 0.05, tAt(ev)))); return; }
      markLane(null); hideUpLine();
      if (xLane) { if (ghost) ghost.done(); await mainToOverlay(seg, xLane, tAt(ev) - grab / pps); return; }
      if (target !== null && !(target >= a0 - 1e-3 && target <= b0 + 1e-3)) await o.drop(target);
      if (ghost) ghost.done();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }
  // istante della live che si vede al tempo t della timeline (fuori dai video inseriti)
  function liveOffAt(t) {
    let L = t;
    for (const i of proj.inserts || []) if (i.at + i.dur <= t + 1e-6) L -= i.dur;
    return Math.max(0, L);
  }
  // sposta una clip della live: al suo posto resta un buco chiuso (la clip sparisce da li') e la stessa parte della
  // live entra nel punto scelto come clip a se', che si puo' spostare ancora, dividere, eliminare
  async function moveLiveSeg(c, target) {
    const orig = { id: c.id, gone: !!c.gone, removed: !!c.removed };
    const dur = +(c.b - c.a).toFixed(4);
    const rel = (x) => +(x - c.a).toFixed(4);
    const words = allWords().filter((sg) => sg.a >= c.a - 1e-6 && sg.b <= c.b + 1e-6)
      .map((sg) => ({ ...sg, a: rel(sg.a), b: rel(sg.b), words: (sg.words || []).map((w2) => ({ ...w2, a: rel(w2.a), b: rel(w2.b) })) }));
    const rec = { id: uid('v'), at: target, dur, offset: +liveOffAt(c.a).toFixed(4), file: proj.source, live: true, name: 'Clip della live',
      w: W, h: H, hasAudio: proj.hasAudio !== false, words };
    const own = [{ ...c, id: uid('s'), a: 0, b: dur, removed: false, gone: false, auto: false }];
    c.gone = true; c.removed = true;
    // il punto scelto e' nel tempo di prima: se e' dopo la clip, non cambia (la clip resta sulla timeline, nascosta)
    const segs = insertCore(rec, own);
    undoStack = [{ kind: 'liveMove', id: rec.id, seg: orig }]; redoStack = [];
    updateUndo();
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id }; tab = 'video';
    changed({ transcript: true });
    seek(rec.at + 0.05);
    clog(`sposto clip della live: ${c.a.toFixed(2)}-${c.b.toFixed(2)} -> ${target.toFixed(2)} · durata ${D.toFixed(2)}`);
  }
  // un pezzo di un video inserito (diviso) spostato da solo: diventa una clip a se' nel punto scelto
  async function moveInsPiece(c, target) {
    const src = insById(c.ins);
    if (!src) return;
    const snap = fullSnap();
    const dur = +(c.b - c.a).toFixed(4);
    const rel = (x) => +(x - c.a).toFixed(4);
    const words = allWords().filter((sg) => sg.a >= c.a - 1e-6 && sg.b <= c.b + 1e-6)
      .map((sg) => ({ ...sg, a: rel(sg.a), b: rel(sg.b), words: (sg.words || []).map((w2) => ({ ...w2, a: rel(w2.a), b: rel(w2.b) })) }));
    const { id: _i, at: _a, dur: _d, offset: _o, words: _w, ...base } = src;
    const rec = { ...base, id: uid('v'), at: target, dur, offset: +((src.offset || 0) + (c.a - src.at)).toFixed(4), words };
    const own = [{ ...c, id: uid('s'), a: 0, b: dur, removed: false, gone: false, auto: false, ins: undefined }];
    c.gone = true; c.removed = true;
    const segs = insertCore(rec, own);
    undoStack = []; pushFull(snap);
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id }; tab = 'video';
    changed({ transcript: true });
    seek(rec.at + 0.05);
    // per capire gli spostamenti strani (segnalazione: "il pezzo sparisce e vado alla fine"): finisce nel log
    clog(`sposto pezzo: ${c.a.toFixed(2)}-${c.b.toFixed(2)} -> ${target.toFixed(2)} · durata ${D.toFixed(2)} · fine contenuto ${contentEnd().toFixed(2)} · calamita ${magnetOn() ? 'si' : 'no'} · aggancio ${snapOn ? 'si' : 'no'}`);
  }
  function mainDropT(t, skipIns) {
    if (BLANK) {
      // come in CapCut: le clip si mettono una dopo l'altra, dall'inizio (niente buchi nella traccia principale)
      const cl = proj.segs.filter((c) => c.ins && !c.gone && c.ins !== skipIns);
      if (!cl.length) { const m0 = proj.segs.filter((c) => !c.gone).reduce((m, c) => Math.min(m, c.a), Infinity); return Number.isFinite(m0) ? m0 : 0; }
      const end = Math.max(...cl.map((c) => c.b));
      if (t >= end) return end;
      let best = 0, bd = Infinity;
      for (const x of cl) for (const e2 of [x.a, x.b]) { const d2 = Math.abs(e2 - t); if (d2 < bd) { bd = d2; best = e2; } }
      return best;
    }
    const segs = proj.segs.filter((c) => !c.gone && (!skipIns || c.ins !== skipIns));
    const c = segs.find((x) => t >= x.a && t < x.b);
    if (c) return t - c.a < c.b - t ? c.a : c.b;
    let best = t, bd = Infinity;
    for (const x of segs) for (const e of [x.a, x.b]) { const d = Math.abs(e - t); if (d < bd) { bd = d; best = e; } }
    return best;
  }
  function placeAsset(a, at, track) {
    if ((a.kind === 'video' || a.kind === 'image') && track === 'main') return insertVideo(a.path, at, a);
    if (track === 'main') track = null;
    const kind = a.kind === 'image' || a.kind === 'video' ? 'overlay' : 'sound';
    if (track && track.type !== kind) track = null;
    begin();
    const fresh = !track;
    if (!track) track = newTrack(kind);
    const t = Math.max(0, Math.min(D - 0.3, at));
    const name = a.name.replace(/\.[^.]+$/, '');
    let c;
    if (a.kind === 'video') {
      // video in sovrimpressione: all'inizio grande quanto lo schermo (senza deformarlo)
      const ar = a.w && a.h ? a.h / a.w : 9 / 16;
      const w = Math.min(1, (1 / CA()) / ar), hf = w * CA() * ar;
      c = { id: uid('c'), kind: 'video', file: a.path, name, a: +t.toFixed(2), dur: +Math.max(0.2, Math.min(a.duration, D - t)).toFixed(2), offset: 0, fileDur: a.duration,
        pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, ar, opacity: 100, vol: 100, mute: false, hasAudio: !!a.hasAudio };
    } else if (a.kind === 'image') {
      const ar = a.w && a.h ? a.h / a.w : 9 / 16;
      const w = Math.min(0.35, 0.6 * (1 / CA()) / ar), hf = w * CA() * ar;
      c = { id: uid('c'), kind: 'image', file: a.path, name, a: +t.toFixed(2), dur: +Math.max(0.3, Math.min(5, D - t)).toFixed(2),
        pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, ar, opacity: 100 };
    } else {
      const long = a.duration > 20;
      if (fresh && long) { track.name = tx('Musica'); track.vol = 25; }
      c = { id: uid('s'), file: a.path, name, a: +t.toFixed(2), dur: +Math.max(0.2, Math.min(a.duration, D - t)).toFixed(2), offset: 0, fileDur: a.duration,
        vol: 100, mute: false, fin: false, fout: long, duck: long };
    }
    track.clips.push(c); track.clips.sort((x, y) => x.a - y.a);
    sel = { type: 'sclip', id: c.id };
    changed();
    if (a.kind === 'image' || a.kind === 'video') { tab = 'video'; seekQuiet(c.a + 0.05); renderPanel(); }
  }

  // ---------------------------------------------------------------- azioni
  // traccia dove aggiungere: quella dell'elemento selezionato, se no la principale
  function curZoomTrack() { const z = sel && sel.type === 'zoom' ? findSel() : null; return (z && z.track) || 'zoom'; }
  function curFxTrack() { const f = sel && sel.type === 'fx' ? findSel() : null; return (f && f.track) || 'fx'; }
  function addZoom() {
    if (!cam) return toast('Per gli zoom serve la webcam: impostala in Proprietà → Progetto.', true);
    const t = video.currentTime;
    let a = t, b = Math.min(D, t + 4);
    const zt = curZoomTrack();
    for (const z of proj.zooms.filter((x) => x.track === zt)) { if (z.a <= a && a < z.b) return select({ type: 'zoom', id: z.id }); if (z.a > a && z.a < b) b = z.a; }
    if (b - a < 0.8) return toast('Qui non c\'è spazio per un altro zoom.', true);
    begin();
    const z = { id: uid('z'), track: zt, a: +a.toFixed(2), b: +b.toFixed(2), on: true, level: proj.settings.zoomLevel || 2.8, in: 'snap', out: 'cut' };
    proj.zooms.push(z); proj.zooms.sort((x, y) => x.a - y.a);
    sel = { type: 'zoom', id: z.id }; tab = 'video';
    changed();
  }
  function addCustomZoom() {
    const t = video.currentTime;
    let a = t, b = Math.min(D, t + 4);
    const zt = curZoomTrack();
    for (const z of proj.zooms.filter((x) => x.track === zt)) { if (z.a <= a && a < z.b) return select({ type: 'zoom', id: z.id }); if (z.a > a && z.a < b) b = z.a; }
    if (b - a < 0.8) return toast('Qui non c\'è spazio per un altro zoom.', true);
    begin();
    const w = W / 2;
    const z = { id: uid('z'), track: zt, kind: 'custom', a: +a.toFixed(2), b: +b.toFixed(2), on: true, rect: [Math.round((W - w) / 2), Math.round((H - w * H / W) / 2), Math.round(w)], in: 'snap', out: 'cut' };
    proj.zooms.push(z); proj.zooms.sort((x, y) => x.a - y.a);
    sel = { type: 'zoom', id: z.id }; tab = 'video'; framing = true;
    changed();
    seekQuiet(z.a + 0.6);
    toast('Sposta e ridimensiona il riquadro sull\'anteprima per scegliere cosa inquadrare.');
  }
  function splitSeg() {
    const t = video.currentTime;
    const c = proj.segs.find((x) => t > x.a + 0.1 && t < x.b - 0.1);
    if (!c) return toast('Sposta la testina un po\' più dentro il pezzo.', true);
    begin();
    const n = { ...c, id: uid('s'), a: +t.toFixed(2), auto: false, adj: c.adj ? { ...c.adj } : undefined, fx: c.fx ? { ...c.fx } : undefined };
    c.b = +t.toFixed(2);
    proj.segs.splice(proj.segs.indexOf(c) + 1, 0, n);
    sel = { type: tab === 'audio' ? 'aseg' : 'seg', id: n.id }; if (tab !== 'audio') tab = 'video';
    changed();
  }
  function mergeSeg(it, dir) {
    const i = proj.segs.indexOf(it), o = proj.segs[i + dir];
    if (!o) return;
    begin();
    if (dir < 0) { o.b = it.b; } else { o.a = it.a; }
    o.auto = false;
    proj.segs.splice(i, 1);
    sel = { type: sel.type, id: o.id };
    changed();
  }
  // progetto vuoto (montaggio come CapCut): eliminare una clip principale la toglie davvero. Con la calamita le altre
  // si avvicinano (niente spazio), senza calamita al suo posto resta lo spazio vuoto. Prima diventava "tagliata" e
  // restava li', grigia, con lo spazio intorno
  async function deleteMainClip(c) {
    const items = mainItems(), k = items.findIndex((x) => x.segId === c.id);
    if (k < 0) return false;
    let g = null;
    if (!magnetOn()) { try { g = await getGap(); } catch (e) { toast('Non riesco a preparare lo spazio vuoto: ' + e.message, true); return true; } }
    const snap = fullSnap();
    if (g) items.splice(k, 1, gapItem(g, items[k].dur)); else items.splice(k, 1);
    rebuildMain(g ? tidyItems(items, g) : items.filter((x) => !x.gap));
    pushFull(snap);
    sel = null; multi = [];
    lightRefresh();
    return true;
  }
  function deleteSel() {
    if (multi.length > 1) return deleteMany(multi, false);
    if (!sel) return;
    const it = findSel();
    if (!it) return;
    if (BLANK && isSeg(sel.type) && it.ins && !it.removed) { deleteMainClip(it); return; }
    begin();
    if (sel.type === 'zoom') proj.zooms = proj.zooms.filter((z) => z.id !== sel.id);
    else if (isSeg(sel.type)) it.removed = !it.removed;
    else if (sel.type === 'fx') proj.filters = proj.filters.filter((f) => f.id !== sel.id);
    else if (sel.type === 'sclip') { const tr = trackOfClip(sel.id); tr.clips = tr.clips.filter((c) => c.id !== sel.id); }
    else if (sel.type === 'track' && it.type !== 'live') { proj.tracks = proj.tracks.filter((t) => t.id !== sel.id); proj.layers = normLayers(); }
    else { undoStack.pop(); return; }
    if (!isSeg(sel.type)) sel = null;
    changed();
  }

  // ---------------------------------------------------------------- pannello
  function setTab(t) { tab = t; renderPanel(); }
  // due pannelli come CapCut: a sinistra Progetto / Media / Clip, a destra Video / Audio / Testo
  const RIGHT_TABS = ['video', 'audio', 'text'];
  function renderPanel() {
    if (LEFT_TABS.includes(tab)) { if (ltab !== tab) { ltab = tab; store.set('ltab', ltab); } tab = renderPanel.lastRight || 'video'; }
    else if (!RIGHT_TABS.includes(tab)) tab = 'video';
    if (tab === 'clips') tab = 'video';
    renderPanel.lastRight = tab;
    panelTabs.className = '';
    panelTabs.replaceChildren(seg(['Video', 'Audio', 'Testo'], RIGHT_TABS.indexOf(tab), (i) => setTab(RIGHT_TABS[i]), 'tabs3'));
    panelBody.replaceChildren();
    liveCtls = [];
    curBody = panelBody;
    if (multi.length > 1) renderMulti();
    else if (tab === 'text') renderTextTab();
    else if (tab === 'audio') renderAudioTab();
    else renderVideoTab();
    renderLeft();
  }
  function renderLeft() {
    const keep = lBody.scrollTop, same = renderLeft.last === ltab;
    const labels = { story: 'Storia', project: 'Progetto', media: 'Media', clips: 'Clip', ai: 'AI' };
    lTabs.replaceChildren(seg(LEFT_TABS.map((k) => labels[k]), LEFT_TABS.indexOf(ltab), (i) => { ltab = LEFT_TABS[i]; store.set('ltab', ltab); renderLeft(); }, 'tabs3' + (LEFT_TABS.length > 4 ? ' tabs5' : '')));
    const liveR = liveCtls;
    lBody.replaceChildren();
    curBody = lBody; liveCtls = [];
    try {
      if (ltab === 'media') renderMedia();
      else if (ltab === 'clips') renderClipsTab();
      else if (ltab === 'story') renderStoryTab();
      else if (ltab === 'ai') renderAiTab();
      else renderProject();
    } finally { liveCtls = liveR.concat(liveCtls); curBody = panelBody; }
    renderLeft.last = ltab;
    if (same) lBody.scrollTop = keep;
  }

  // ---------------------------------------------------------------- AI: montaggio con l'AI (piano da confermare)
  // L'AI propone (tagli, zoom, sottotitoli, scritte, grafiche); qui si sceglie cosa tenere e si applica in un colpo (Annulla torna indietro).
  const AI_ED = { styles: null, style: store.get('aiStyle', 'p:business'), prompt: '', opts: store.get('aiOpts', { pauses: true, cuts: true, zooms: true, subs: true, texts: true, graphics: true }),
    busy: null, plan: null, sel: new Set(), graphicsJob: null, chat: [], applied: false };
  // piano salvato nel progetto: riaprendo lo ritrovi com'era (non si rifà l'analisi)
  if (proj.aiPlan && proj.aiPlan.plan) {
    AI_ED.chat = proj.aiPlan.chat || []; AI_ED.applied = !!proj.aiPlan.applied;
    if (!AI_ED.applied) { AI_ED.plan = proj.aiPlan.plan; AI_ED.sel = new Set(proj.aiPlan.sel || []); }
  }
  if (AI_ED.opts.sfx === undefined) AI_ED.opts.sfx = true;
  if (AI_ED.opts.motions === undefined) AI_ED.opts.motions = true;
  // le immagini AI sono spente di base (le grafiche animate sono piu' belle e gratis): si accendono dallo studio
  if (store.get('aiOptsV', 0) < 2) { AI_ED.opts.graphics = false; store.set('aiOpts', AI_ED.opts); store.set('aiOptsV', 2); }
  AI_ED.lv = { pauses: 'stile', cuts: 'normali', zooms: 'normali', zstyle: 'auto', texts: 'normali', graphics: 'normali', gstyle: 'pro', looks: ['clean', 'tag', 'caption', 'guru'],
    gkinds: ['icona', 'grafico', 'tabella', 'schema', 'freccia', 'emoji'], motions: 'normali', mtpls: MOTION_TPLS.map((m) => m[0]), maccent: '#4F8CFF', tmode: 'dietro', mstyle: 'pulito', ...store.get('aiLv', {}) };
  if (!Array.isArray(AI_ED.lv.looks) || !AI_ED.lv.looks.length) AI_ED.lv.looks = ['clean', 'tag', 'caption', 'guru'];
  const AI_GROUPS = [['pause', 'Pause', 'scissors'], ['cut', 'Tagli', 'scissors'], ['zoom', 'Zoom', 'zoomin'], ['text', 'Titoli', 'type'], ['motion', 'Grafiche animate', 'sparkle'], ['graphic', 'Immagini AI', 'image']];
  const AI_OPTS = [['pauses', 'Togli le pause'], ['cuts', 'Taglia errori e ripetizioni'], ['zooms', 'Zoom'], ['subs', 'Sottotitoli'], ['texts', 'Scritte'], ['graphics', 'Grafiche AI'], ['sfx', 'Effetti sonori']];
  let aiCred = false;
  const aiUsd = (x) => (x == null ? '' : aiCred ? Math.max(1, Math.ceil(x * ((aiEst && aiEst.perUsd) || 280))).toLocaleString('it-IT') + ' crediti' : '$' + (x < 0.1 ? (+x).toFixed(3) : (+x).toFixed(2)));
  let aiEst = null, aiEstKey = '';
  function aiLoadEstimate(nWords) {
    const k = nWords + '|' + AI_ED.style;
    if (aiEstKey === k) return; aiEstKey = k;
    post(`/api/p/${pid}/aiestimate`, {}).then((r) => { aiEst = r; aiCred = !!r.credits; if (ltab === 'ai' && !AI_ED.plan && !AI_ED.busy) renderLeft(); }).catch(() => {});
  }
  const outT = (t) => { remCache = removed(); return fmt(outAt(t)); };
  function aiLoadStyles() {
    if (AI_ED.styles) return;
    AI_ED.styles = [];
    get('/api/ai/editstyles').then((r) => { AI_ED.styles = r.styles || []; if (!AI_ED.styles.some((s) => s.id === AI_ED.style)) AI_ED.style = 'p:business'; if (ltab === 'ai') renderLeft(); }).catch(() => {});
  }
  // il piano resta nel progetto: riaprendo il progetto lo ritrovi (con la chat), senza pagare di nuovo
  function aiSave() {
    if (!AI_ED.plan) return;
    const was = proj.aiPlan || {};
    proj.aiPlan = { plan: AI_ED.plan, sel: [...AI_ED.sel], chat: AI_ED.chat || [], applied: !!AI_ED.applied, style: AI_ED.style, at: was.at || Date.now() };
    dirty = true; scheduleSave();
  }
  // ask: richiesta di modifica dalla chat (usa il piano attuale come base)
  async function aiPlan(ask) {
    if (typeof ask !== 'string') ask = null;   // chiamata da un pulsante (riceve l'evento)
    if (AI_ED.busy) return;
    if (ask && !AI_ED.plan && proj.aiPlan && proj.aiPlan.plan) { AI_ED.plan = proj.aiPlan.plan; AI_ED.sel = new Set(proj.aiPlan.sel || []); }
    const prev = ask && AI_ED.plan ? AI_ED.plan.items.filter((x) => AI_ED.sel.has(x.id)).map((x) => ({ type: x.type, a: x.a, b: x.b, text: x.text, title: x.mg && x.mg.title, tpl: x.mg && x.mg.tpl, prompt: x.prompt })) : null;
    const keepPlan = AI_ED.plan;
    if (ask) AI_ED.chat = [...(AI_ED.chat || []), { me: true, t: ask }];
    AI_ED.busy = { msg: ask ? 'L\'AI modifica il piano' : 'L\'AI legge il video', p: 0 }; AI_ED.plan = null; renderLeft();
    try {
      await flush();
      const j = await post(`/api/p/${pid}/aiedit`, { style: AI_ED.style, prompt: ask || AI_ED.prompt, opts: AI_ED.opts, levels: AI_ED.lv, prev });
      const r = await pollJob(j.id, (x) => { if (AI_ED.busy) { AI_ED.busy = { msg: x.message || 'L\'AI prepara il montaggio', p: x.progress || 0, eta: x.eta }; renderAiBusy(); } });
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      AI_ED.plan = r.result;
      AI_ED.sel = new Set(AI_ED.plan.items.map((x) => x.id));
      if (AI_ED.plan.subs) AI_ED.sel.add('subs');
      AI_ED.plan.sfx = !!AI_ED.opts.sfx && AI_ED.plan.items.some((x) => x.type !== 'pause');
      if (AI_ED.plan.sfx) AI_ED.sel.add('sfx');
      if (!AI_ED.plan.items.length && !AI_ED.plan.subs) toast('L\'AI non ha trovato niente da cambiare con queste scelte');
      if (ask) AI_ED.chat.push({ me: false, t: AI_ED.plan.summary || 'Ecco il piano aggiornato.' });
      else AI_ED.chat = AI_ED.plan.summary ? [{ me: false, t: AI_ED.plan.summary }] : [];
      aiSave();
    } catch (e) {
      toast(e.message, true);
      if (keepPlan) AI_ED.plan = keepPlan;   // la modifica non e' riuscita: resta il piano di prima
      if (ask) AI_ED.chat.pop();
    }
    AI_ED.busy = null; if (alive) renderLeft();
  }
  let aiBusyEl = null;
  function renderAiBusy() {
    if (!aiBusyEl || !AI_ED.busy) return;
    const sk = AI_ED.busy.skip;
    const et = etaText(AI_ED.busy.eta);
    aiBusyEl.replaceChildren(h('div', { class: 'spinner' }), h('span', null, AI_ED.busy.msg, et ? h('small', { class: 'busy-eta' }, ' · ' + et) : null), h('div', { class: 'progress' }, h('div', { style: { width: Math.round((AI_ED.busy.p || 0) * 100) + '%' } })),
      ...(sk ? [h('button', { class: 'btn sm ghost', onclick: sk.fn }, sk.label)] : []));
  }
  // taglia un pezzo della timeline [a,b]: divide i pezzi ai bordi e segna "tolto" quello che sta dentro
  function aiCutRange(a, b) {
    for (const t of [a, b]) {
      const c = proj.segs.find((x) => !x.gone && t > x.a + 0.02 && t < x.b - 0.02);
      if (!c) continue;
      const n = { ...c, id: uid('s'), a: +t.toFixed(3), auto: false, adj: c.adj ? { ...c.adj } : undefined, fx: c.fx ? { ...c.fx } : undefined };
      c.b = +t.toFixed(3);
      proj.segs.splice(proj.segs.indexOf(c) + 1, 0, n);
    }
    let n = 0;
    for (const c of proj.segs) if (!c.gone && c.a >= a - 0.02 && c.b <= b + 0.02 && !c.removed) { c.removed = true; c.ai = true; n++; }
    return n;
  }
  // scritte dell'AI = titoli animati pronti (text.js), non testo semplice uguale ai sottotitoli
  const AI_LOOKS = ['clean', 'tag', 'caption', 'minimal', 'guru', 'yellow', 'greenhl', 'breaking', 'punch', 'premium', 'orange', 'wow'];
  const AI_GKIND = { icona: 'Icona', grafico: 'Grafico', tabella: 'Tabella', schema: 'Schema', freccia: 'Freccia', emoji: 'Emoji' };
  const aiLookName = (id) => (TITLE_PRESETS.find((p) => p[0] === id) || [0, ''])[1];
  // big: titolo dietro la persona (grande, stile virale, al centro sopra la testa)
  // titoli dietro la persona: gli stili virali (luminosi, sfumati) — si possono cambiare cliccando il titolo
  const BIG_LOOKS = ['premium', 'morning', 'water', 'orange', 'healthy', 'neon'];
  function aiTextClip(tr, it, n, big) {
    let p = TITLE_PRESETS.find((x) => x[0] === it.look) || TITLE_PRESETS.find((x) => x[0] === AI_LOOKS[n % 3]);
    if (big) { const bl = (AI_ED.lv.blooks || []).filter((x) => BIG_LOOKS.includes(x)); const pool = bl.length ? bl : ['premium', 'morning', 'water', 'orange']; p = TITLE_PRESETS.find((x) => x[0] === pool[n % pool.length]) || p; }
    const hl = p[3].hlColor || p[3].hlBox;
    let content = String(it.text || '').trim();
    if (!hl) content = content.replace(/\*([^*]+)\*/g, '$1');
    else if (!/\*[^*]+\*/.test(content)) { const ws = content.split(/\s+/); ws[ws.length - 1] = '*' + ws[ws.length - 1] + '*'; content = ws.join(' '); }
    const portrait = VERT || CW() < CH();
    const text = { ...TEXT_DEFAULT, ...titleStyle(p), size: (big ? 0.17 : portrait ? 0.062 : 0.085) * (p[3].sizeK || 1), content, sub: null, upper: big ? true : titleStyle(p).upper };
    const { kin, ...anim } = p[4];
    const c = { id: uid('c'), kind: 'image', isText: true, text, titleId: p[0], name: content.replace(/\*/g, ''), file: '', a: +it.a.toFixed(2),
      dur: +Math.max(1.5, it.b - it.a).toFixed(2), opacity: 100, anim, ai: true };
    if (kin) c.kin = kin;
    const draw = () => (c.kin || isProText(c.text) ? drawKinetic(c.text, H, c.kin ? kinSettle(c) : 0, c.dur, c.kin || '') : drawText(c.text, H));
    let cv = draw();
    c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
    if (big) {   // dietro la persona: enorme, quasi tutta la larghezza (ma non piu' alto di un terzo del video)
      const k = Math.min(1.02 / c.natW, 0.3 / text.size);   // la tela ha margini per il bagliore: il testo vero e' ~85% della larghezza
      if (k > 1.02) { text.size = +(text.size * k).toFixed(4); cv = draw(); c.natW = cv.width / CW(); c.ar = cv.height / cv.width; }
    }
    const w = Math.min(portrait ? 0.9 : big ? 1.04 : 0.6, c.natW), hh = w * CA() * c.ar;
    c.pos = { w: +w.toFixed(5), x: +((1 - w) / 2).toFixed(5), y: +(portrait ? 0.18 : 0.08).toFixed(5) };
    const f = it.face;
    if (big) {   // dietro la testa: il centro del titolo poco sopra il viso
      // in alto: il centro delle lettere all'altezza della cima della testa (la tela ha margini per il bagliore: puo' uscire un po')
      const cy = f ? Math.max(0.17, Math.min(0.3, f[1] - f[3] * 0.85)) : 0.2;
      c.pos.y = +Math.max(-hh * 0.3, cy - hh / 2).toFixed(5);
    } else if (f && f[1] - f[3] * 0.8 < 0.08 + hh) { const bf = besideFace(f, Math.min(w, 0.4), hh * Math.min(w, 0.4) / w); if (bf) c.pos = { w: +bf.w.toFixed(5), x: +bf.x.toFixed(5), y: +bf.y.toFixed(5) }; }
    tr.clips.push(c); refreshText(c);
    Promise.all([ensureFont(p[3].font), p[3].sub ? ensureFont(p[3].sub.font || p[3].font) : true]).then(() => { if (alive) { refreshText(c); frame(true); } }).catch(() => {});
    return c;
  }
  // posto libero accanto al viso (l'AI ha guardato dov'e' la faccia in quel momento): mai sopra chi parla
  // w = larghezza voluta (0..1 della larghezza), hh = altezza in frazione dell'altezza -> {x, y, w}
  function besideFace(face, w, hh) {
    const port = VERT || CW() < CH();
    if (!face) return null;
    const [fx, fy, fw, fh] = face;
    if (port) {   // verticale: sopra o sotto la testa
      const top = fy - fh * 0.8 > hh + 0.06;
      return { x: (1 - w) / 2, y: top ? Math.max(0.04, fy - fh * 0.8 - hh - 0.02) : Math.min(0.96 - hh, fy + fh * 1.2), w };
    }
    const right = fx < 0.5;
    const room = right ? 0.97 - (fx + fw * 0.8) : (fx - fw * 0.8) - 0.03;
    const ww = Math.max(0.16, Math.min(w, room));
    const x = right ? Math.min(0.97 - ww, Math.max(fx + fw * 0.8, 0.5)) : Math.max(0.03, Math.min(fx - fw * 0.8 - ww, 0.5 - ww));
    const y = Math.max(0.05, Math.min(0.9 - hh * ww / w, fy - hh * (ww / w) / 2));
    return { x, y, w: ww };
  }
  // grafica animata (motion.js): clip di testo con la sua animazione disegnata, esportata a fotogrammi come i testi animati
  function aiMotionClip(tr, it) {
    const mg = cleanMotion({ ...it.mg, style: AI_ED.lv.mstyle === 'scheda' ? 'scheda' : 'pulito' });
    const c = { id: uid('c'), kind: 'image', isText: true, text: { ...TEXT_DEFAULT, font: 'Inter', content: mg.title || motionName(mg.tpl), mg }, kin: 'mg',
      name: mg.title || motionName(mg.tpl), file: '', a: +it.a.toFixed(2), dur: +Math.max(2.5, it.b - it.a).toFixed(2), opacity: 100, anim: { out: 'fade', outDur: 0.3 }, ai: true };
    placeMotion(c, it.face);
    tr.clips.push(c); refreshText(c);
    ensureFont('Inter').then(() => { if (alive) { refreshText(c); frame(true); } }).catch(() => {});
    return c;
  }
  function placeMotion(c, face) {
    const cv = drawMotion(c.text.mg, H, 2.2, c.dur);
    c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
    const port = VERT || CW() < CH();
    const w = Math.min(port ? 0.9 : 0.42, c.natW), hh = w * CA() * c.ar;
    if (c.text.mg.style !== 'scheda' && !port) {
      // stile pulito: grande in mezzo, sotto il viso (sul busto) se c'e' posto
      const ww = Math.min(0.62, c.natW), h2 = ww * CA() * c.ar;
      const fy = face ? face[1] + face[3] * 0.75 : 0.45;
      const yy = Math.max(0.04, Math.min(0.84 - h2, Math.max(fy, 0.5 - h2 / 2)));
      c.pos = { w: +ww.toFixed(5), x: +((1 - ww) / 2).toFixed(5), y: +yy.toFixed(5) };
      return;
    }
    const bf = besideFace(face, w, hh);
    c.pos = bf ? { w: +bf.w.toFixed(5), x: +bf.x.toFixed(5), y: +bf.y.toFixed(5) }
      : { w: +w.toFixed(5), x: +(port ? (1 - w) / 2 : 0.97 - w).toFixed(5), y: +(port ? 0.16 : Math.max(0.04, 0.46 - hh / 2)).toFixed(5) };
  }
  // effetti sonori inclusi (web/sfx): whoosh sulle grafiche, pop sulle scritte, swoosh/colpo sugli zoom
  let aiSfxLib = null;
  async function aiSfx() {
    if (!aiSfxLib) { const r = await get('/api/ai/sfx'); aiSfxLib = r.sfx || {}; }
    return aiSfxLib;
  }
  function aiPlaceSfx(lib, marks) {
    let tr = proj.tracks.find((t) => t.type === 'sound' && t.name === 'Effetti AI');
    if (!tr) { tr = newTrack('sound'); tr.name = 'Effetti AI'; tr.vol = 70; }
    let last = -9;
    for (const [t, k, vol] of marks.sort((x, y) => x[0] - y[0])) {
      const f = lib[k]; if (!f || t - last < 0.35) continue;
      const lead = k === 'whoosh' ? 0.22 : k === 'swoosh' ? 0.12 : k === 'riser' ? 1.2 : 0;
      const a = Math.max(0, t - lead); last = t;
      tr.clips.push({ id: uid('s'), file: f.path, name: k, a: +a.toFixed(2), dur: +Math.min(f.duration, D - a).toFixed(2), offset: 0, fileDur: f.duration, vol: vol || 100, mute: false, ai: true });
    }
    tr.clips.sort((x, y) => x.a - y.a);
    return tr.clips.length;
  }
  function aiTrack(name) {
    let tr = proj.tracks.find((t) => t.type === 'overlay' && t.name === name);
    if (!tr) { tr = newTrack('overlay'); tr.name = name; }
    return tr;
  }
  async function aiApply() {
    const P = AI_ED.plan; if (!P) return;
    const pick = P.items.filter((x) => AI_ED.sel.has(x.id));
    const gr = pick.filter((x) => x.type === 'graphic');
    const now = pick.filter((x) => x.type !== 'graphic');
    const doSubs = P.subs && AI_ED.sel.has('subs');
    if (!now.length && !gr.length && !doSubs) return toast('Seleziona almeno una modifica', true);
    let made = [];
    if (gr.length) {
      made = await aiGraphics(gr);
      if (made === null) return;   // errore: il piano resta, si puo' riprovare o togliere le grafiche
    }
    // titoli dietro la persona: si preparano prima (video del pezzo con il testo dietro chi parla), poi si applica tutto insieme
    let behind = [];
    const txts = pick.filter((x) => x.type === 'text');
    const behindOk = txts.length && AI_ED.lv.tmode !== 'sopra' && !VERT && CW() >= CH() && !BLANK && !(proj.inserts || []).length;
    if (behindOk) {
      const rem = [...removed(), ...pick.filter((x) => x.type === 'cut' || x.type === 'pause').map((x) => [x.a, x.b])].sort((p, q) => p[0] - q[0]);
      const items = [];
      for (const it of txts) {
        // solo dentro un pezzo che resta nel video (se no il titolo andrebbe fuori tempo)
        let a = it.a, b = Math.max(it.b, it.a + 2.4);
        for (const [x, y] of rem) if (a >= x && a < y) a = y;
        for (const [x] of rem) if (x > a && x < b) b = x;
        if (b - a >= 1.2) items.push({ id: it.id, a: +a.toFixed(3), b: +b.toFixed(3), text: it.text, face: it.face, accent: '#FFD34D' });
      }
      if (items.length) {
        const r = await aiBehind(items);
        if (r) behind = r.map((g) => ({ ...g, it: items.find((x) => x.id === g.id) })).filter((g) => g.it && g.n > 0);
      }
    }
    const doSfx = P.sfx && AI_ED.sel.has('sfx');
    let sfxLib = null;
    if (doSfx) { try { sfxLib = await aiSfx(); } catch (e) { toast('Effetti sonori non disponibili: ' + e.message, true); } }
    if (!alive) return;
    begin();
    // un nuovo montaggio AI sostituisce quello di prima (niente scritte o grafiche doppie)
    const clearTr = (name) => { const t = proj.tracks.find((x) => x.name === name); if (t) t.clips = []; };
    if (now.some((x) => x.type === 'text')) { clearTr('Scritte AI'); clearTr('Titoli AI'); clearTr('Persona AI'); }
    if (now.some((x) => x.type === 'motion')) clearTr('Grafiche animate');
    // piano rifatto con la chat dopo averlo gia' applicato: i tagli dell'AI di prima tornano nel video, poi si mettono i nuovi
    if (AI_ED.applied) proj.segs.forEach((c) => { if (c.ai && c.removed) { c.removed = false; c.gone = false; } });
    if (made.length) clearTr('Grafiche AI');
    if (doSfx) clearTr('Effetti AI');
    if (now.some((x) => x.type === 'zoom')) proj.zooms = proj.zooms.filter((z) => !z.ai);
    let cuts = 0, zooms = 0, texts = 0, sfx = 0;
    for (const it of now.filter((x) => x.type === 'cut' || x.type === 'pause')) cuts += aiCutRange(it.a, it.b) ? 1 : 0;
    const zt = (proj.zoomTracks || [{ id: 'zoom' }])[0].id;
    // durante un titolo dietro la persona niente zoom (il pezzo con il titolo e' gia' un video a tutto schermo)
    const bR = behind.map((g) => [g.it.a, g.it.b]);
    for (const it of now.filter((x) => x.type === 'zoom' && !bR.some(([a, b]) => x.a < b && a < x.b))) {
      if (VERT) continue;   // in verticale lo zoom e' il riquadro della webcam: si sceglie a mano
      if (proj.zooms.some((z) => z.a < it.b && it.a < z.b)) continue;
      const [fin, fout] = it.style === 'morbido' ? ['smooth', 'smooth'] : it.style === 'lento' ? ['ramp', 'cut'] : ['punch', 'cut'];
      let z;
      if (cam) z = { id: uid('z'), track: zt, a: +it.a.toFixed(2), b: +it.b.toFixed(2), on: true, level: Math.max(1.2, Math.min(3, (it.level || 1.25) * 1.6)), in: fin, out: fout, ai: true };
      else {
        const w = W / Math.max(1.05, it.level || 1.25), hh = w * H / W;
        // la persona al centro dell'inquadratura: centro sul viso (un po' sotto, per tenere anche le spalle)
        const f = it.face;
        const cx = f ? f[0] * W : W / 2, cy = f ? (f[1] + f[3] * 0.35) * H : H * 0.42;
        const rx = Math.max(0, Math.min(W - w, cx - w / 2)), ry = Math.max(0, Math.min(H - hh, cy - hh / 2));
        z = { id: uid('z'), track: zt, kind: 'custom', a: +it.a.toFixed(2), b: +it.b.toFixed(2), on: true, rect: customRect(W, H, [rx, ry, w]).slice(0, 3).map(Math.round), in: fin, out: fout, ai: true };
      }
      proj.zooms.push(z); zooms++;
    }
    proj.zooms.sort((x, y) => x.a - y.a);
    if (now.some((x) => x.type === 'text')) {
      const tr = aiTrack('Scritte AI');
      const bIds = new Set(behind.map((g) => g.id));
      for (const it of now.filter((x) => x.type === 'text' && !bIds.has(x.id))) { aiTextClip(tr, it, texts); texts++; }
      if (behind.length) {
        // titolo grande e modificabile (clic per cambiarlo) + sopra la persona ritagliata: il titolo sembra dietro di te
        const tb = aiTrack('Titoli AI');
        for (const g of behind) {
          const it = { ...g.it, b: g.it.a + Math.max(1, g.n / g.fps) };
          aiTextClip(tb, it, texts, true); texts++;
        }
        const pm = aiTrack('Persona AI');
        for (const g of behind) {
          pm.clips.push({ id: uid('c'), kind: 'image', file: g.first, name: 'Persona (titolo dietro)', a: +g.it.a.toFixed(3), dur: +(g.n / g.fps).toFixed(3),
            pos: { x: 0, y: 0, w: 1 }, ar: +(H / W).toFixed(5), opacity: 100, ai: true, matte: { mask: g.mask }, seq: { dir: g.dir, n: g.n, fps: g.fps, key: 'matte' } });
        }
        // la persona subito sopra i titoli, i sottotitoli e il resto sopra la persona
        proj.layers = normLayers();
        const L2 = proj.layers.filter((k) => k !== 'ov:' + pm.id);
        L2.splice(Math.max(0, L2.indexOf('ov:' + tb.id)), 0, 'ov:' + pm.id);
        const si = L2.indexOf('subs'), pi = L2.indexOf('ov:' + pm.id);
        if (si > pi) { L2.splice(si, 1); L2.splice(pi, 0, 'subs'); }
        proj.layers = L2;
        tb.clips.sort((x, y) => x.a - y.a); pm.clips.sort((x, y) => x.a - y.a);
      }
      tr.clips.sort((x, y) => x.a - y.a);
    }
    if (doSubs) {
      Object.assign(proj.subStyle, P.subs);
      ensureFont(P.subs.font).then(() => { ver++; frame(true); }).catch(() => {});
      proj.settings.showSubs = true;
    }
    if (made.length) aiPlaceGraphics(made, gr);
    let motions = 0;
    if (now.some((x) => x.type === 'motion')) {
      const tr = aiTrack('Grafiche animate');
      for (const it of now.filter((x) => x.type === 'motion')) { aiMotionClip(tr, it); motions++; }
      tr.clips.sort((x, y) => x.a - y.a);
    }
    if (doSfx && sfxLib) {
      const marks = [];
      for (const it of now) {
        if (it.type === 'text') marks.push([it.a, it.look === 'punch' || it.look === 'wow' ? 'impact' : ['clean', 'tag', 'minimal'].includes(it.look) ? 'click' : 'pop', 80]);
        if (it.type === 'zoom' && it.style !== 'lento') marks.push([it.a, it.style === 'morbido' ? 'swoosh' : 'impact', it.style === 'morbido' ? 70 : 55]);
      }
      for (const g of made) { const it = gr.find((x) => x.id === g.id); if (it) marks.push([it.a, it.kind === 'grafico' || it.kind === 'tabella' ? 'ding' : 'whoosh', 75]); }
      for (const it of now) if (it.type === 'motion') marks.push([it.a, 'whoosh', 65]);
      sfx = marks.length ? aiPlaceSfx(sfxLib, marks) : 0;
    }
    if (!behind.length) proj.layers = normLayers(); else { const nl = normLayers(); proj.layers = [...proj.layers.filter((k) => nl.includes(k)), ...nl.filter((k) => !proj.layers.includes(k))]; }
    AI_ED.applied = true; aiSave();
    AI_ED.plan = null;
    changed({ transcript: true }); frame(true);
    toast([cuts && cuts + ' tagli', zooms && zooms + ' zoom', texts && texts + ' scritte', made.length && made.length + ' immagini', motions && motions + ' grafiche animate', doSubs && 'sottotitoli', sfx && sfx + ' effetti sonori'].filter(Boolean).join(' · ') + '. Annulla (Ctrl/Cmd+Z) torna indietro.');
    renderLeft();
  }
  async function aiBehind(items) {
    let skipped = false, jid = null, skipRes = null;
    const skipP = new Promise((r) => { skipRes = r; });
    const skip = { label: 'Salta: metti i titoli sopra il video', fn: () => { skipped = true; skipRes({ status: 'skipped' }); if (jid) post(`/api/jobs/${jid}/cancel`, {}).catch(() => {}); } };
    AI_ED.busy = { msg: 'Preparo i titoli dietro di te', p: 0, skip }; renderLeft();
    let out = null;
    try {
      const j = await post(`/api/p/${pid}/behind`, { items });
      jid = j.id;
      const r = await Promise.race([skipP, pollJob(j.id, (x) => { if (AI_ED.busy && !skipped) { AI_ED.busy = { msg: x.message || 'Preparo i titoli dietro di te', p: x.progress || 0, skip }; renderAiBusy(); } })]);
      if (skipped) throw new Error('saltato');
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      out = r.result.items || [];
      if (r.result.errors) toast(r.result.errors + ' titoli non riusciti: li metto sopra il video', true);
    } catch (e) { if (!skipped) toast('Titoli dietro di te non riusciti (' + e.message + '): li metto sopra il video', true); }
    AI_ED.busy = null;
    if (alive) renderLeft();
    return out;
  }
  // crea le grafiche scelte (prima di applicare: cosi' Annulla toglie tutto il montaggio in un colpo)
  async function aiGraphics(items) {
    AI_ED.busy = { msg: 'Creo le grafiche', p: 0 }; renderLeft();
    let out = null;
    try {
      const j = await post(`/api/p/${pid}/aigraphics`, { items: items.map((x) => ({ id: x.id, prompt: x.prompt, style: x.style, place: x.place, kind: x.kind, label: x.label, gstyle: x.gstyle })), model: AI_ED.lv.gmodel || null });
      const r = await pollJob(j.id, (x) => { if (AI_ED.busy) { AI_ED.busy = { msg: x.message || 'Creo le grafiche', p: x.progress || 0, eta: x.eta }; renderAiBusy(); } });
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      const got = r.result.items || [];
      const assets = addAssets(got.map((x) => x.info), true);
      out = got.map((g, k) => ({ id: g.id, asset: assets[k] })).filter((x) => x.asset);
      if (r.result.errors) toast(r.result.errors + ' grafiche non riuscite: ' + (r.result.first || ''), true);
    } catch (e) { toast(e.message, true); }
    AI_ED.busy = null;
    if (alive) renderLeft();
    return out;
  }
  function aiPlaceGraphics(made, items) {
    const tr = aiTrack('Grafiche AI');
    made.forEach((g, k) => {
      const it = items.find((x) => x.id === g.id); const as = g.asset; if (!it || !as) return;
      const ar = (as.h || 1) / (as.w || 1);
      let w, x, y;
      if (it.place === 'pieno') { w = Math.max(1, 1 / (CA() * ar)); x = (1 - w) / 2; y = (1 - w * CA() * ar) / 2; }
      else {
        const port = VERT || CW() < CH();
        w = it.place === 'alto' ? (port ? 0.34 : 0.2) : it.place === 'lato' ? (port ? 0.5 : 0.3) : (port ? 0.62 : 0.34);
        const hh = w * CA() * ar;
        x = it.place === 'alto' ? (port ? 0.5 - w / 2 : 0.76 - w / 2) : it.place === 'lato' ? (port ? 0.5 - w / 2 : 0.8 - w / 2) : 0.5 - w / 2;
        y = it.place === 'alto' ? 0.06 : it.place === 'lato' ? (port ? 0.3 : 0.5) - hh / 2 : (port ? 0.4 : 0.46) - hh / 2;
      }
      if (it.face && it.place !== 'pieno') {
        const port = VERT || CW() < CH();
        const ww = port ? 0.5 : 0.24, bf = besideFace(it.face, ww, ww * CA() * ar);
        if (bf) { w = bf.w; x = bf.x; y = bf.y; }
      }
      tr.clips.push({ id: uid('c'), kind: 'image', file: as.path, name: 'AI ' + (k + 1), a: +it.a.toFixed(2), dur: +Math.max(1.2, it.b - it.a).toFixed(2), ar: +ar.toFixed(4), opacity: 100,
        pos: { x: +x.toFixed(4), y: +y.toFixed(4), w: +w.toFixed(4) }, anim: it.place === 'pieno' ? { in: 'fade', inDur: 0.15, out: 'fade', outDur: 0.15, motion: 'zoomIn' } : { in: 'pop', inDur: 0.3, out: 'fade', outDur: 0.2, loop: 'float' } });
    });
    tr.clips.sort((p, q) => p.a - q.a);
  }
  function renderAiTab() {
    aiLoadStyles();
    const nWords = allWords().reduce((n, sg) => n + (sg.words || []).length, 0);
    const hasTr = proj.transcript && proj.transcript.status === 'done' && nWords > 5;
    const box = h('div', { class: 'aie' });
    B.append(box);
    if (!hasTr) {
      const running = proj.transcript && proj.transcript.status === 'running';
      box.append(h('div', { class: 'aie-empty' }, h('span', { class: 'aie-ic' }, icon('sparkle', 20, '#fff', 2)),
        h('b', null, 'Monta con l\'AI'),
        h('p', null, 'L\'AI legge quello che dici e prepara il montaggio nello stile che scegli: tagli, zoom, sottotitoli, scritte e grafiche. Prima serve la trascrizione (gratis, sul tuo computer).'),
        running ? h('div', { class: 'aie-busy' }, h('div', { class: 'spinner' }), h('span', null, 'Trascrivo il video…'))
          : h('div', { class: 'aix-trb' },
            h('button', { class: 'btn primary', disabled: ctx.env && ctx.env.whisper === false ? true : null, onclick: () => startTranscribe(proj.settings.showSubs) }, icon('text', 14, '#fff'), 'Trascrivi il video'),
            aiTrBtn()),
        running ? null : h('button', { class: 'linkish scr-link', onclick: scriptBox }, icon('text', 12), proj.script ? 'Script aggiunto: modificalo' : 'Hai lo script? Incollalo prima (nomi scritti giusti)')));
      return;
    }
    if (AI_ED.busy) {
      aiBusyEl = h('div', { class: 'aie-busy big' }); box.append(aiBusyEl); renderAiBusy();
      return;
    }
    const P = AI_ED.plan;
    if (P) { renderAiPlan(box, P); return; }
    // pannello a sinistra: riassunto e via. Le scelte si fanno nello studio AI (finestra grande)
    const styles = AI_ED.styles || [];
    const cur = styles.find((x) => x.id === AI_ED.style);
    const O = AI_ED.opts;
    aiLoadEstimate(nWords);
    const on = AI_TASKS.filter((x) => O[x[0]]);
    if (proj.aiPlan && proj.aiPlan.plan) {
      const ap = proj.aiPlan;
      box.append(h('div', { class: 'aix-last' },
        h('div', { class: 'aix-lh' }, icon('sparkle', 13, 'currentColor', 2), h('b', null, ap.applied ? 'Montaggio AI applicato' : 'Piano AI da applicare'),
          h('button', { class: 'linkish', onclick: () => { AI_ED.plan = ap.plan; AI_ED.sel = new Set(ap.sel || []); AI_ED.chat = ap.chat || []; AI_ED.applied = !!ap.applied; renderLeft(); } }, ap.applied ? 'Rivedi il piano' : 'Apri')),
        h('small', null, 'Chiedi all\'AI di cambiarlo: non rilegge tutto da capo.'),
        aiChatBox(true)));
    }
    box.append(h('div', { class: 'aix-hero' },
      h('div', { class: 'aix-glow' }),
      h('span', { class: 'aix-ic' }, icon('sparkle', 20, '#fff', 2)),
      h('b', null, 'Monta con l\'AI'),
      h('p', null, 'Scegli uno stile e cosa deve fare. Vedi tutto prima di applicare.'),
      h('button', { class: 'aix-style', onclick: () => openAiStudio() },
        h('small', null, 'Stile'), h('span', { 'data-notr': cur && !cur.builtin ? '' : null }, cur ? cur.name : '…'), icon('chev', 14, 'currentColor', 2)),
      h('div', { class: 'aix-chips' }, ...(on.length ? on.map(([k, ic, t]) => h('span', { class: 'aix-chip' }, icon(ic, 12, 'currentColor', 2), t))
        : [h('span', { class: 'aix-none' }, 'Nessun lavoro scelto')])),
      h('button', { class: 'btn aix-custom', onclick: () => openAiStudio() }, icon('sliders', 14, 'currentColor', 2), 'Personalizza'),
      h('button', { class: 'btn primary aix-go', disabled: on.length ? null : true, onclick: aiPlan }, icon('sparkle', 15, '#fff'), 'Prepara il montaggio'),
      h('small', { class: 'aix-cost' }, aiCostLine())));
    box.append(aiTrBtn(true));
  }
  // trascrizione con l'AI (OpenAI o ElevenLabs): piu' precisa, i tagli vengono meglio
  let aiTrInfo = null;
  function aiTrBtn(small) {
    const b = h('button', { class: small ? 'linkish aix-trl' : 'btn', onclick: () => startTranscribe(undefined, true) }, small ? null : icon('sparkle', 14, 'currentColor', 2),
      small ? 'Trascrizione più precisa con l\'AI' : 'Trascrivi con l\'AI (più precisa)');
    const note = h('small', { class: 'aix-trn' });
    const fill = () => {
      if (!aiTrInfo) return;
      if (!aiTrInfo.provider) { b.disabled = true; note.textContent = 'Serve una chiave OpenAI o ElevenLabs (Storie AI → Chiavi AI)'; return; }
      note.textContent = aiTrInfo.name + ' · ~' + aiUsd(aiTrInfo.usd);
    };
    if (aiTrInfo) fill(); else post(`/api/p/${pid}/transcribeinfo`, {}).then((r) => { aiTrInfo = r; fill(); }).catch(() => {});
    return h('div', { class: 'aix-tr' + (small ? ' sm' : '') }, b, note);
  }
  // lavori dell'AI: [chiave, icona, nome, descrizione]
  const AI_TASKS = [
    ['pauses', 'scissors', 'Pause', 'Via i silenzi tra una frase e l\'altra'],
    ['cuts', 'scissors', 'Tagli', 'Errori, frasi ricominciate, parti inutili'],
    ['subs', 'cc', 'Sottotitoli', 'Nel font e nei colori dello stile'],
    ['zooms', 'zoomin', 'Zoom', 'Sulle frasi chiave'],
    ['texts', 'type', 'Titoli', 'Parole chiave animate a schermo'],
    ['motions', 'sparkle', 'Grafiche animate', 'Numeri, grafici, liste e confronti che si muovono'],
    ['graphics', 'image', 'Immagini AI', 'Icone e illustrazioni create dall\'AI'],
    ['sfx', 'speaker', 'Suoni', 'Whoosh, pop e colpi sincronizzati'],
  ];
  function aiCostLine() {
    const O = AI_ED.opts, e = aiEst;
    const aiNeeded = ['cuts', 'zooms', 'texts', 'graphics', 'motions'].some((k) => O[k]);
    if (!aiNeeded) return 'Gratis: pause, sottotitoli e suoni non usano l\'AI.';
    if (e && e.error) return e.error;
    return 'Lettura del video ' + (e && e.planUsd != null ? '~' + aiUsd(e.planUsd) : '…') + (O.graphics && e && e.imageUsd != null ? ' · grafiche ' + aiUsd(e.imageUsd) + ' l\'una, solo se le tieni' : '') + '.';
  }
  // anteprime degli stili delle grafiche (disegnate qui, nessuna immagine esterna)
  const ICON_LOOKS = [
    ['pro', 'Business', 'Sobrio, blu notte e un colore'],
    ['line', 'Linee', 'Tratto sottile, minimal'],
    ['glass', 'Vetro', 'Trasparenze, stile fintech'],
    ['flat', 'Piatto', 'Forme semplici, infografica'],
    ['3d', '3D', 'Lucido e colorato'],
    ['neon', 'Neon', 'Contorni luminosi, tech'],
  ];
  const ICON_SVG = {
    pro: '<svg viewBox="0 0 120 80"><rect x="22" y="6" width="76" height="68" rx="14" fill="#0E1B35"/><rect x="36" y="44" width="10" height="18" rx="2" fill="#fff" opacity=".55"/><rect x="52" y="34" width="10" height="28" rx="2" fill="#fff" opacity=".8"/><rect x="68" y="22" width="10" height="40" rx="2" fill="#4F8CFF"/><path d="M34 34 L52 24 L64 28 L84 14" stroke="#E9C46A" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="84" cy="14" r="3.5" fill="#E9C46A"/></svg>',
    line: '<svg viewBox="0 0 120 80" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="34" y="44" width="10" height="20" rx="2"/><rect x="52" y="32" width="10" height="32" rx="2"/><rect x="70" y="20" width="10" height="44" rx="2"/><path d="M28 64 H92"/><path d="M32 36 L50 24 L62 28 L84 12" stroke="#6CB2FF"/><path d="M76 12 H84 V20" stroke="#6CB2FF"/></svg>',
    glass: '<svg viewBox="0 0 120 80"><defs><linearGradient id="gg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8B7CFF" stop-opacity=".9"/><stop offset="1" stop-color="#3BA3FF" stop-opacity=".9"/></linearGradient><filter id="gb"><feGaussianBlur stdDeviation="6"/></filter></defs><circle cx="74" cy="30" r="20" fill="url(#gg)" filter="url(#gb)"/><rect x="24" y="10" width="72" height="60" rx="14" fill="#fff" fill-opacity=".12" stroke="#fff" stroke-opacity=".35"/><rect x="38" y="42" width="9" height="18" rx="3" fill="#fff" fill-opacity=".55"/><rect x="54" y="32" width="9" height="28" rx="3" fill="#fff" fill-opacity=".7"/><rect x="70" y="22" width="9" height="38" rx="3" fill="#fff" fill-opacity=".9"/></svg>',
    flat: '<svg viewBox="0 0 120 80"><rect x="30" y="42" width="14" height="24" fill="#FF8A3D"/><rect x="50" y="30" width="14" height="36" fill="#2EC4B6"/><rect x="70" y="16" width="14" height="50" fill="#3A86FF"/><rect x="24" y="66" width="68" height="3" fill="#fff"/><path d="M84 8 l8 10 h-16 z" fill="#FFD166"/></svg>',
    '3d': '<svg viewBox="0 0 120 80"><defs><linearGradient id="t1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7FD1FF"/><stop offset="1" stop-color="#1F6FEB"/></linearGradient><linearGradient id="t2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFB86B"/><stop offset="1" stop-color="#F0602B"/></linearGradient><linearGradient id="t3" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9BF6A6"/><stop offset="1" stop-color="#1FAA59"/></linearGradient></defs><path d="M30 46 h12 l5 -4 h-12 z" fill="#FFD2A6"/><rect x="30" y="46" width="12" height="20" fill="url(#t2)"/><path d="M42 46 l5 -4 v20 l-5 4 z" fill="#B8481F"/><path d="M52 34 h12 l5 -4 h-12 z" fill="#CFF7D4"/><rect x="52" y="34" width="12" height="32" fill="url(#t3)"/><path d="M64 34 l5 -4 v32 l-5 4 z" fill="#137A3F"/><path d="M74 20 h12 l5 -4 h-12 z" fill="#CDEEFF"/><rect x="74" y="20" width="12" height="46" fill="url(#t1)"/><path d="M86 20 l5 -4 v46 l-5 4 z" fill="#14489E"/><ellipse cx="60" cy="70" rx="36" ry="4" fill="#000" opacity=".35"/></svg>',
    neon: '<svg viewBox="0 0 120 80" fill="none" stroke-width="2.4" stroke-linecap="round"><defs><filter id="ng"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g filter="url(#ng)"><rect x="34" y="44" width="10" height="20" rx="2" stroke="#22E1FF"/><rect x="52" y="32" width="10" height="32" rx="2" stroke="#22E1FF"/><rect x="70" y="20" width="10" height="44" rx="2" stroke="#22E1FF"/><path d="M30 36 L50 22 L62 27 L86 10" stroke="#FF3DCB"/></g></svg>',
  };
  const aiSound = (k) => { try { const a = new Audio('/web/sfx/' + k + '.wav'); a.volume = 0.8; a.play().catch(() => {}); } catch (e) { /* */ } };
  // studio AI: finestra grande con tutte le scelte, anteprime vere di titoli, grafiche e suoni
  function openAiStudio() {
    aiLoadStyles();
    const O = AI_ED.opts, L = AI_ED.lv;
    const bg = h('div', { class: 'modal-bg aim-bg' });
    const close = () => { bg.remove(); document.removeEventListener('keydown', onK, true); if (alive) renderLeft(); };
    const onK = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onK, true);
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
    const box = h('div', { class: 'aim' });
    bg.append(box);
    document.body.append(bg);
    const save = () => { store.set('aiOpts', O); store.set('aiLv', L); paint(); };
    const seg = (k, opts) => h('div', { class: 'aie-seg' }, ...opts.map(([v, l]) => h('button', { class: L[k] === v ? 'on' : '', type: 'button', onclick: () => { L[k] = v; save(); } }, l)));
    const AMT = [['pochi', 'Pochi'], ['normali', 'Normali'], ['tanti', 'Tanti']];
    const sw = (k) => h('button', { class: 'aie-tsw' + (O[k] ? ' on' : ''), type: 'button', role: 'switch', 'aria-checked': O[k] ? 'true' : 'false', onclick: () => { O[k] = !O[k]; save(); } }, h('i'));
    const row = (label, ctl) => h('div', { class: 'aim-row' }, h('span', null, label), ctl);
    // sezione: intestazione con interruttore, sotto le scelte (spente se il lavoro e' spento)
    const section = (k, body) => {
      const t = AI_TASKS.find((x) => x[0] === k);
      return h('section', { class: 'aim-sec' + (O[k] ? ' on' : '') },
        h('div', { class: 'aim-sh' }, h('span', { class: 'aie-tic' }, icon(t[1], 15, 'currentColor', 2)),
          h('span', { class: 'aie-tt' }, h('b', null, t[2]), h('small', null, t[3])), sw(k)),
        body && O[k] ? h('div', { class: 'aim-sb' }, ...[].concat(body)) : null);
    };
    const stills = [];
    function titleTiles(ids = AI_LOOKS, key = 'looks') {
      if (!Array.isArray(L[key]) || !L[key].length) L[key] = key === 'blooks' ? ['premium', 'morning', 'water', 'orange'] : ['clean', 'tag', 'caption', 'guru'];
      const looks = ids.map((id) => TITLE_PRESETS.find((p) => p[0] === id)).filter(Boolean);
      Promise.all([...new Set(looks.map((p) => p[3].font))].map((f) => ensureFont(f))).then(() => requestAnimationFrame(() => stills.forEach((f) => f())));
      return h('div', { class: 'aim-looks' }, ...looks.map((p) => {
        const on = L[key].includes(p[0]);
        const st = { ...TEXT_DEFAULT, ...titleStyle(p), size: 0.16 * (p[3].sizeK || 1), content: tx(p[5]), ...(key === 'blooks' ? { sub: null } : {}) }, kin = p[4].kin;
        const cv = h('canvas', { class: 'ttl-cv' });
        const still = () => { if (kin || isProText(st)) drawKinetic(st, 200, kin ? 2.2 : 0, 3, kin || '', cv); else { const s2 = drawText(st, 200); cv.width = s2.width; cv.height = s2.height; cv.getContext('2d').drawImage(s2, 0, 0); } };
        still(); stills.push(still);
        const tile = h('button', { class: 'aim-look' + (on ? ' on' : ''), type: 'button', onclick: () => { L[key] = on ? L[key].filter((x) => x !== p[0]) : [...L[key], p[0]]; if (!L[key].length) L[key] = [p[0]]; save(); } },
          h('div', { class: 'ttl-pic' }, cv), h('span', null, p[1]), h('i', { class: 'aim-tick' }, icon('check', 11, '#fff', 3)));
        let raf = 0, t0 = 0;
        const loopT = (now) => { if (!t0) t0 = now; drawKinetic(st, 200, ((now - t0) / 1000) % 3.2, 3, kin, cv); raf = requestAnimationFrame(loopT); };
        if (kin) { tile.addEventListener('pointerenter', () => { t0 = 0; cancelAnimationFrame(raf); raf = requestAnimationFrame(loopT); }); tile.addEventListener('pointerleave', () => { cancelAnimationFrame(raf); still(); }); }
        return tile;
      }));
    }
    let mRaf = 0;
    function motionTiles() {
      const cvs = [];
      const grid = h('div', { class: 'aim-mgs' }, ...MOTION_TPLS.map(([id, nm, d, ex]) => {
        const on = L.mtpls.includes(id);
        const cv = h('canvas', { class: 'aim-mcv' });
        cvs.push([cv, { tpl: id, ...ex, accent: L.maccent, style: L.mstyle === 'scheda' ? 'scheda' : 'pulito' }]);
        return h('button', { class: 'aim-mg' + (on ? ' on' : ''), type: 'button', onclick: () => { L.mtpls = on ? L.mtpls.filter((x) => x !== id) : [...L.mtpls, id]; if (!L.mtpls.length) L.mtpls = [id]; save(); } },
          h('div', { class: 'aim-mpic' }, cv), h('b', null, nm), h('small', null, d), h('i', { class: 'aim-tick' }, icon('check', 11, '#fff', 3)));
      }));
      // anteprime sempre in movimento (ricominciano ogni 3,2 s)
      cancelAnimationFrame(mRaf);
      let t0 = 0;
      const loop = (now) => { if (!bg.isConnected) return; if (!t0) t0 = now; const tt = ((now - t0) / 1000) % 3.4; for (const [cv, sp] of cvs) if (cv.isConnected) drawMotion(sp, 360, tt, 3.4, cv); mRaf = requestAnimationFrame(loop); };
      ensureFont('Inter').finally(() => { mRaf = requestAnimationFrame(loop); });
      return grid;
    }
    const accents = () => h('div', { class: 'aim-acc' }, ...MOTION_ACCENTS.map((c) => h('button', { class: 'aim-sw' + (L.maccent === c ? ' on' : ''), type: 'button', style: { background: c }, 'aria-label': c, onclick: () => { L.maccent = c; save(); } })));
    function gmodels() {
      const box = h('div', { class: 'aim-gms' });
      const fill = (list) => {
        if (!L.gmodel || !list.some((m) => m.id === L.gmodel && m.ok)) { const f = list.find((m) => m.ok); if (f && L.gmodel !== f.id) { L.gmodel = f.id; store.set('aiLv', L); } }
        box.replaceChildren(...list.map((m) => h('button', { class: 'aim-gm' + (L.gmodel === m.id ? ' on' : ''), type: 'button', disabled: m.ok ? null : true,
          'data-tip': m.ok ? null : 'Serve la chiave di ' + ({ fal: 'fal.ai', openai: 'OpenAI', gemini: 'Gemini' }[m.provider] || m.provider) + ' (Storie AI → Chiavi AI)',
          onclick: () => { L.gmodel = m.id; save(); } },
          h('span', { class: 'aim-gmh' }, h('b', null, m.name), h('em', null, aiUsd(m.usd))), h('small', null, m.note || ''))));
      };
      if (AI_ED.gmodels) fill(AI_ED.gmodels); else get('/api/ai/graphicmodels').then((r) => { AI_ED.gmodels = r.models || []; if (bg.isConnected) fill(AI_ED.gmodels); }).catch(() => {});
      return box;
    }
    function iconTiles() {
      return h('div', { class: 'aim-icons' }, ...ICON_LOOKS.map(([id, nm, d]) => {
        const pic = h('div', { class: 'aim-ipic' }); pic.innerHTML = ICON_SVG[id];
        return h('button', { class: 'aim-icon' + (L.gstyle === id ? ' on' : ''), type: 'button', onclick: () => { L.gstyle = id; save(); } }, pic, h('b', null, nm), h('small', null, d));
      }));
    }
    const kinds = () => h('div', { class: 'aie-kinds' }, ...Object.entries(AI_GKIND).map(([k, l]) => {
      const on = L.gkinds.includes(k);
      return h('button', { class: 'aie-kc' + (on ? ' on' : ''), type: 'button', onclick: () => { L.gkinds = on ? L.gkinds.filter((x) => x !== k) : [...L.gkinds, k]; if (!L.gkinds.length) L.gkinds = [k]; save(); } }, l);
    }));
    const sounds = () => h('div', { class: 'aim-sounds' }, ...[['whoosh', 'Whoosh', 'grafiche'], ['pop', 'Pop', 'titoli'], ['click', 'Click', 'titoli sobri'], ['impact', 'Colpo', 'zoom a scatto'], ['ding', 'Ding', 'grafici e numeri']].map(([k, l, d]) =>
      h('button', { class: 'aim-snd', type: 'button', onclick: () => aiSound(k) }, icon('play', 11, 'currentColor', 2), h('b', null, l), h('small', null, d))));
    const ta = h('textarea', { class: 'input aie-ta', rows: 2, placeholder: 'Es. "taglia l\'intro", "grafica quando parlo di soldi", "niente zoom nei primi 10 secondi"' });
    ta.value = AI_ED.prompt; ta.addEventListener('input', () => { AI_ED.prompt = ta.value; });
    const costEl = h('small', { class: 'aim-cost' });
    function paint() {
      stills.length = 0;
      const styles = AI_ED.styles || [];
      const sIcon = (x) => icon(x.builtin ? ({ chart: 'sparkle', play: 'play', text: 'text', speaker: 'speaker' })[x.icon] || 'sparkle' : 'library', 14, 'currentColor', 2);
      const left = h('div', { class: 'aim-left' },
        h('div', { class: 'aim-lh' }, h('b', null, 'Stile'), h('button', { class: 'linkish', onclick: () => { close(); if (ctx.nav) ctx.nav('aiformats'); } }, '+ Dai tuoi video')),
        h('div', { class: 'aim-styles' }, ...styles.map((x) => h('button', { class: 'aie-st' + (x.id === AI_ED.style ? ' on' : ''), onclick: () => { AI_ED.style = x.id; store.set('aiStyle', x.id); paint(); } },
          h('span', { class: 'aie-sic' + (x.builtin ? '' : ' mine') }, sIcon(x)),
          h('span', { class: 'aie-stt' }, h('b', { 'data-notr': x.builtin ? null : '' }, x.name, x.niche ? h('em', { class: 'aie-niche' }, x.niche) : null,
            x.community ? h('em', { class: 'aie-niche com' + (x.pending ? ' pend' : '') }, x.pending ? 'In revisione' : 'Community') : null), h('small', null, x.summary || ''))))));
      const right = h('div', { class: 'aim-right' },
        h('div', { class: 'aim-group' }, h('div', { class: 'aim-gh' }, 'Pulizia'),
          section('pauses', row('Quanto togliere', seg('pauses', [['silenzi', 'Solo le lunghe'], ['stile', 'Come lo stile'], ['tutte', 'Tutte']]))),
          section('cuts', row('Quanto tagliare', seg('cuts', [['leggeri', 'Leggeri'], ['normali', 'Normali'], ['decisi', 'Decisi']]))),
          section('subs', null)),
        h('div', { class: 'aim-group' }, h('div', { class: 'aim-gh' }, 'Movimento e grafica'),
          section('zooms', [row('Tipo', seg('zstyle', [['auto', 'Come lo stile'], ['lento', 'Avvicina piano'], ['morbido', 'Morbido'], ['scatto', 'A scatto']])), row('Quanti', seg('zooms', AMT))]),
          section('texts', [row('Dove', seg('tmode', [['dietro', 'Dietro di te (grandi)'], ['sopra', 'Sopra il video']])), row('Quanti', seg('texts', AMT)), h('div', { class: 'aim-lbl' }, L.tmode === 'sopra' ? 'Titoli che l\'AI può usare' : 'Stili dei titoli dietro di te', h('small', null, 'passa sopra per vederli animati · dopo li cambi cliccandoci sopra')),
            L.tmode === 'sopra' ? titleTiles() : titleTiles(BIG_LOOKS, 'blooks')]),
          section('motions', [row('Stile', seg('mstyle', [['pulito', 'Pulito, senza box'], ['scheda', 'In una scheda']])), row('Quante', seg('motions', AMT)), h('div', { class: 'aim-lbl' }, 'Grafiche che l\'AI può usare', h('small', null, 'gratis, si animano da sole')), motionTiles(),
            h('div', { class: 'aim-lbl' }, 'Colore'), accents()]),
          section('graphics', [row('Quante', seg('graphics', AMT)), h('div', { class: 'aim-lbl' }, 'Modello', h('small', null, 'quale AI disegna le immagini')), gmodels(), h('div', { class: 'aim-lbl' }, 'Stile delle grafiche'), iconTiles(), h('div', { class: 'aim-lbl' }, 'Tipi'), kinds()]),
          section('sfx', [h('div', { class: 'aim-lbl' }, 'Ascoltali'), sounds()])),
        h('div', { class: 'aim-group' }, h('div', { class: 'aim-gh' }, 'Indicazioni in più'), ta));
      costEl.textContent = aiCostLine();
      body.replaceChildren(left, right);
      goBtn.disabled = AI_TASKS.some((x) => O[x[0]]) ? null : true;
    }
    const body = h('div', { class: 'aim-body' });
    const goBtn = h('button', { class: 'btn primary', onclick: () => { close(); aiPlan(); } }, icon('sparkle', 15, '#fff'), 'Prepara il montaggio');
    box.append(
      h('div', { class: 'aim-head' }, h('span', { class: 'aix-ic sm' }, icon('sparkle', 16, '#fff', 2)),
        h('div', null, h('b', null, 'Montaggio AI'), h('small', null, 'Scegli lo stile e cosa deve fare l\'AI. Niente cambia finché non premi Applica.')),
        h('button', { class: 'iconbtn aim-x', 'aria-label': 'Chiudi', onclick: close }, icon('x', 16, 'currentColor', 2))),
      body,
      h('div', { class: 'aim-foot' }, costEl, h('div', { class: 'grow' }), h('button', { class: 'btn ghost', onclick: close }, 'Chiudi'), goBtn));
    paint();
    if (!AI_ED.styles || !AI_ED.styles.length) setTimeout(() => { if (bg.isConnected) paint(); }, 800);
  }
  // chat: chiedi all'AI di cambiare il piano a parole ("meno zoom", "togli la grafica a 1:20", "taglia di più l'intro")
  function aiChatBox(compact) {
    const msgs = (AI_ED.chat || []).slice(-6);
    const ta = h('textarea', { class: 'input aic-in', rows: 1, placeholder: compact ? 'Cosa vuoi cambiare? Es. "meno zoom", "taglia di più l\'intro"' : 'Chiedi una modifica: "meno zoom", "togli la grafica a 1:20"…' });
    const send = () => { const t = ta.value.trim(); if (t) aiPlan(t); };
    ta.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
    ta.addEventListener('input', () => { ta.style.height = 'auto'; ta.style.height = Math.min(120, ta.scrollHeight) + 'px'; });
    return h('div', { class: 'aic' },
      msgs.length ? h('div', { class: 'aic-msgs' }, ...msgs.map((m) => h('div', { class: 'aic-m' + (m.me ? ' me' : ''), 'data-notr': '' }, m.t))) : null,
      h('div', { class: 'aic-row' }, ta, h('button', { class: 'btn primary aic-send', 'aria-label': 'Invia', onclick: send }, icon('send', 14, '#fff', 2))));
  }
  function renderAiPlan(box, P) {
    if (proj.aiPlan && JSON.stringify(proj.aiPlan.sel) !== JSON.stringify([...AI_ED.sel])) aiSave();
    const groups = AI_GROUPS.map(([k, l, ic]) => [k, l, ic, P.items.filter((x) => x.type === k)]).filter((g) => g[3].length);
    const nSel = P.items.filter((x) => AI_ED.sel.has(x.id)).length + (P.subs && AI_ED.sel.has('subs') ? 1 : 0) + (P.sfx && AI_ED.sel.has('sfx') ? 1 : 0);
    const nG = P.items.filter((x) => x.type === 'graphic' && AI_ED.sel.has(x.id)).length;
    const gm = (AI_ED.gmodels || []).find((m) => m.id === AI_ED.lv.gmodel);
    if (gm) P.imageUsd = gm.usd;   // prezzo del modello scelto nello studio
    const gUsd = P.imageUsd != null ? nG * P.imageUsd : null;
    const cutSec = P.items.filter((x) => (x.type === 'cut' || x.type === 'pause') && AI_ED.sel.has(x.id)).reduce((s, x) => s + (x.b - x.a), 0);
    box.append(h('div', { class: 'aie-sum' }, h('div', { class: 'aie-sumh' }, h('b', null, 'Piano di montaggio'), h('span', { class: 'aie-tag' }, P.style && P.style.name || '')),
      P.summary ? h('p', { 'data-notr': '' }, P.summary) : null,
      h('small', null, 'Clic su una riga per vederla nel video. Togli la spunta a quello che non vuoi.')));
    box.append(aiChatBox());
    if (P.subs) {
      const on = AI_ED.sel.has('subs');
      box.append(h('label', { class: 'aie-row subs' + (on ? ' on' : '') }, h('input', { type: 'checkbox', checked: on ? true : null, onchange: (e) => { if (e.target.checked) AI_ED.sel.add('subs'); else AI_ED.sel.delete('subs'); renderLeft(); } }),
        h('span', { class: 'aie-rt' }, h('b', null, 'Sottotitoli nello stile'), h('small', { 'data-notr': '' }, P.subs.font + ' · ' + (P.subs.maxChars === 1 ? 'una parola alla volta' : P.subs.maxChars < 25 ? 'poche parole' : 'frase intera') + (P.subs.upper ? ' · MAIUSCOLO' : '')),
          h('span', { class: 'aie-sw' }, h('i', { style: { background: P.subs.color } }), h('i', { style: { background: P.subs.hiColor } })))));
    }
    if (P.sfx) {
      const on = AI_ED.sel.has('sfx');
      box.append(h('label', { class: 'aie-row subs' + (on ? ' on' : '') }, h('input', { type: 'checkbox', checked: on ? true : null, onchange: (e) => { if (e.target.checked) AI_ED.sel.add('sfx'); else AI_ED.sel.delete('sfx'); renderLeft(); } }),
        h('span', { class: 'aie-rt' }, h('b', null, 'Effetti sonori'), h('small', null, 'Whoosh sulle grafiche, pop sulle scritte, colpi sugli zoom. Gratis.'))));
    }
    for (const [k, l, ic, list] of groups) {
      const all = list.every((x) => AI_ED.sel.has(x.id));
      box.append(h('div', { class: 'aie-gh' }, icon(ic, 13, 'currentColor', 2), h('b', null, l), h('span', null, list.filter((x) => AI_ED.sel.has(x.id)).length + '/' + list.length),
        h('div', { class: 'grow' }), h('button', { class: 'linkish', onclick: () => { list.forEach((x) => (all ? AI_ED.sel.delete(x.id) : AI_ED.sel.add(x.id))); renderLeft(); } }, all ? 'Togli tutti' : 'Tutti')));
      const rows = h('div', { class: 'aie-rows' });
      for (const it of list) {
        const on = AI_ED.sel.has(it.id);
        const desc = it.type === 'pause' ? 'Pausa di ' + (it.b - it.a).toFixed(1).replace('.', ',') + ' s'
          : it.type === 'cut' ? (it.why ? it.why.charAt(0).toUpperCase() + it.why.slice(1) + ': ' : '') + '“' + (it.text || '') + '”'
            : it.type === 'motion' ? motionName(it.mg.tpl) + ': ' + [it.mg.title, it.mg.value, ...(it.mg.items || []).map((x) => x.label || x.value)].filter(Boolean).join(' · ')
            : it.type === 'zoom' ? (it.why || 'Zoom') + ' · ' + (it.b - it.a).toFixed(1).replace('.', ',') + ' s' : it.type === 'text' ? '“' + it.text.replace(/\*/g, '') + '”' + (it.look ? ' · ' + aiLookName(it.look) : '') : (it.label ? '“' + it.label + '” · ' : '') + it.prompt;
        const row = h('div', { class: 'aie-row' + (on ? ' on' : ''), onclick: (e) => { if (e.target.tagName !== 'INPUT') seek(it.a); } },
          h('input', { type: 'checkbox', checked: on ? true : null, onchange: (e) => { if (e.target.checked) AI_ED.sel.add(it.id); else AI_ED.sel.delete(it.id); renderLeft(); } }),
          h('span', { class: 'aie-t' }, outT(it.a)),
          h('span', { class: 'aie-rt' }, h('span', { 'data-notr': '' }, desc), it.type === 'graphic' ? h('small', null, (AI_GKIND[it.kind] ? AI_GKIND[it.kind] + ' · ' : '') + ({ centro: 'al centro', alto: 'piccola in alto', lato: 'di lato', pieno: 'a tutto schermo' }[it.place] || '') + (P.imageUsd != null ? ' · ' + aiUsd(P.imageUsd) : '')) : null));
        rows.append(row);
      }
      box.append(rows);
    }
    aiCred = !!P.credits;
    box.append(h('div', { class: 'aie-foot' },
      h('div', { class: 'aie-cost' },
        h('div', { class: 'aie-crow' }, h('span', null, 'Lettura del video (già fatta)'), h('b', null, aiUsd(P.usd || 0))),
        h('div', { class: 'aie-crow' }, h('span', null, nG ? 'Da pagare: ' + nG + (nG === 1 ? ' grafica' : ' grafiche') : 'Nessuna grafica da creare'), h('b', null, nG ? '~' + aiUsd(gUsd || 0) : aiUsd(0))),
        cutSec > 0.5 ? h('small', null, 'Il video diventa più corto di ' + fmt(cutSec)) : null),
      h('div', { class: 'aie-fbtn' },
        h('button', { class: 'btn ghost', onclick: () => { AI_ED.plan = null; if (!AI_ED.applied) { delete proj.aiPlan; AI_ED.chat = []; dirty = true; scheduleSave(); } renderLeft(); } }, AI_ED.applied ? 'Chiudi' : 'Scarta'),
        h('button', { class: 'btn primary', disabled: nSel ? null : true, onclick: aiApply }, icon('check', 14, '#fff', 2.4), 'Applica ' + nSel))));
  }

  // --- media
  // zona di import: si clicca per scegliere i file o ci si trascinano sopra
  function dropZone(compact, lib) {
    const busy = importing > 0;
    const z = h('button', { class: 'mzone' + (compact ? ' compact' : '') + (busy ? ' busy' : ''), 'aria-label': lib ? 'Aggiungi alla libreria' : 'Importa video, immagini e suoni',
      'data-tip': compact ? (lib ? 'Aggiungi GIF, video e suoni alla tua libreria' : 'Importa video, immagini e suoni (o trascinali qui)') : null,
      onclick: async () => { if (importing) return; const got = await importMedia(); if (lib && got.length) saveToLibrary(got); } },
      h('span', { class: 'mz-ico' }, busy ? h('div', { class: 'spinner' }) : icon(compact ? 'plus' : 'upload', compact ? 20 : 24, 'currentColor', 1.8)),
      compact ? null : h('strong', null, busy ? 'Importo…' : 'Video, immagini e suoni'),
      compact ? null : h('span', { class: 'xs' }, busy ? 'Un attimo' : 'Clicca o trascina qui i file'));
    return z;
  }
  // Media: quelli di questo progetto oppure "La mia libreria" (GIF, video, suoni che riusi in tutti i progetti)
  let mediaSrc = store.get('mediaSrc', 'proj'), libItems = [], libLoaded = false, libLoading = null;
  function loadLibrary(force) {
    if (libLoading && !force) return libLoading;
    libLoading = get('/api/library').then((l) => { libItems = l || []; libLoaded = true; return libItems; }).catch(() => { libLoaded = true; return libItems; });
    return libLoading;
  }
  const inLib = (a) => libItems.some((x) => x.name === a.name.replace(/[\\/:*?"<>|]+/g, '_'));
  async function saveToLibrary(list) {
    let n = 0;
    for (const a of list) { try { await post('/api/library/add', { path: a.path }); n++; } catch (e) { toast(a.name + ': ' + e.message, true); } }
    await loadLibrary(true);
    if (n) toast(n > 1 ? `${n} elementi salvati nella tua libreria` : 'Salvato nella tua libreria: lo trovi in tutti i progetti');
    if (alive && ltab === 'media') renderLeft();
  }
  function mediaTile(a, lib) {
    const isImg = a.kind === 'image', isVid = a.kind === 'video';
    const tip = isVid ? ' · trascina sulla traccia Video per metterlo nel video, sopra per sovrapporlo' : ' · trascina sulla timeline';
    const use = () => placeAsset(lib ? addAssets([a], true)[0] : a, video.currentTime, null);
    const saved = !lib && inLib(a);
    const tile = h('div', { class: 'asset' + (lib ? ' lib' : ''), draggable: 'true', 'data-tip': a.name + (isImg ? '' : ' · ' + fmt(a.duration || 0)) + tip },
      h('div', { class: 'asset-pic' + (isImg || isVid ? '' : ' snd') },
        isImg ? h('img', { src: mediaUrl(a.path), alt: '', draggable: 'false', loading: 'lazy' })
          : isVid ? [h('img', { src: mthumbUrl(a.path, Math.min(1, (a.duration || 2) / 2)), alt: '', draggable: 'false', loading: 'lazy' }), h('span', { class: 'asset-dur' }, fmt(a.duration || 0))]
            : icon('music', 22, '#4A8BFF'),
        saved ? h('span', { class: 'asset-star', 'data-tip': 'È nella tua libreria' }, icon('star', 11, 'currentColor', 2)) : null),
      h('div', { class: 'asset-nm' }, a.name.replace(/\.[^.]+$/, '')),
      h('div', { class: 'asset-acts' },
        ibtn('plus', 'Aggiungi alla timeline qui', use, { size: 14 }),
        lib ? ibtn('x', 'Togli dalla libreria', async () => {
          try { await post('/api/library/remove', { path: a.path }); await loadLibrary(true); renderLeft(); toast('Tolto dalla libreria'); } catch (e) { toast(e.message, true); }
        }, { size: 14 })
          : [saved ? null : ibtn('star', 'Salva nella mia libreria (lo ritrovi in tutti i progetti)', () => saveToLibrary([a]), { size: 14 }),
            ibtn('x', 'Togli dai Media', () => { proj.assets = proj.assets.filter((x) => x.id !== a.id); dirty = true; scheduleSave(); renderPanel(); }, { size: 14 })]));
    tile.addEventListener('dragstart', (e) => {
      if (lib) e.dataTransfer.setData('application/x-vodcut-lib', a.path); else e.dataTransfer.setData('application/x-vodcut-asset', a.id);
      e.dataTransfer.effectAllowed = 'copy'; tile.classList.add('dragging'); dragAsset = a;
      e.dataTransfer.setDragImage(EMPTY_IMG, 0, 0);
      const pic = tile.querySelector('.asset-pic img');
      dragCard.replaceChildren(pic ? h('img', { src: pic.src, alt: '' }) : icon('music', 16, '#4A8BFF'), h('span', null, a.name.replace(/\.[^.]+$/, '')));
      Object.assign(dragCard.style, { display: '', left: e.clientX + 12 + 'px', top: e.clientY + 12 + 'px' });
    });
    tile.addEventListener('dragend', () => { tile.classList.remove('dragging'); dragAsset = null; clearDrop(); });
    tile.addEventListener('dblclick', use);
    if (!lib) tile.addEventListener('contextmenu', (e) => { e.preventDefault(); assetMenu(e, a); });
    return tile;
  }
  function renderMedia() {
    const lib = mediaSrc === 'lib';
    const src = seg(['Questo progetto', 'La mia libreria'], lib ? 1 : 0, (i) => { mediaSrc = i ? 'lib' : 'proj'; store.set('mediaSrc', mediaSrc); renderLeft(); }, 'msrc');
    curBody.append(src);
    if (!libLoaded) loadLibrary().then(() => { if (alive && ltab === 'media') renderLeft(); });
    const veil = h('div', { class: 'mdrop-veil' }, icon('upload', 22), lib ? 'Rilascia per salvare nella libreria' : 'Rilascia per importare');
    if (lib) {
      const wrap = h('div', { class: 'media' + (libItems.length ? '' : ' empty') });
      if (!libItems.length) {
        wrap.append(h('div', { class: 'lib-empty' }, h('span', { class: 'mz-ico' }, icon('library', 24, 'currentColor', 1.7)),
          h('strong', null, libLoaded ? 'La tua libreria è vuota' : 'Carico…'),
          h('span', { class: 'xs' }, 'Salva qui GIF, video e suoni che usi spesso: li ritrovi in ogni progetto. Usa la stellina su un elemento dei Media o importali qui.')),
        dropZone(false, true));
        curBody.append(wrap, veil); return;
      }
      const grid = h('div', { class: 'media-grid' }, dropZone(true, true));
      for (const a of libItems) grid.append(mediaTile(a, true));
      wrap.append(grid);
      curBody.append(wrap, veil); return;
    }
    const list = proj.assets;
    const wrap = h('div', { class: 'media' + (list.length ? '' : ' empty') });
    if (!list.length) { wrap.append(dropZone(false)); curBody.append(wrap, veil); return; }
    const grid = h('div', { class: 'media-grid' }, dropZone(true));
    for (const a of list) grid.append(mediaTile(a, false));
    wrap.append(grid);
    curBody.append(wrap, veil);
  }
  // clic destro su un elemento dei Media
  function assetMenu(e, a) {
    popMenuAt(e.clientX, e.clientY, [
      ['plus', 'Aggiungi alla timeline qui', null, () => placeAsset(a, video.currentTime, null)],
      a.kind !== 'audio' && !IS_V ? ['timeline', 'Nuova timeline con elemento selezionato', 'Una timeline nuova in questo progetto, con solo questo', () => newTimeline(a)] : null,
      inLib(a) ? null : ['star', 'Salva nella mia libreria', 'Lo ritrovi in tutti i progetti', () => saveToLibrary([a])],
      ['x', 'Togli dai Media', null, () => { proj.assets = proj.assets.filter((x) => x.id !== a.id); dirty = true; scheduleSave(); renderPanel(); }],
    ].filter(Boolean));
  }
  // file trascinati dal PC sul pannello Media: evidenziazione morbida, senza sfarfallii
  let dragDepth = 0;
  const isFileDrag = (e) => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  leftPanel.addEventListener('dragenter', (e) => { if (ltab !== 'media' || !isFileDrag(e)) return; e.preventDefault(); dragDepth++; leftPanel.classList.add('mdrag'); });
  leftPanel.addEventListener('dragover', (e) => { if (ltab !== 'media' || !isFileDrag(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
  leftPanel.addEventListener('dragleave', (e) => { if (ltab !== 'media' || !isFileDrag(e)) return; dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) leftPanel.classList.remove('mdrag'); });
  leftPanel.addEventListener('drop', async (e) => {
    if (ltab !== 'media' || !isFileDrag(e)) return;
    e.preventDefault(); dragDepth = 0; leftPanel.classList.remove('mdrag');
    const got = await uploadFiles([...e.dataTransfer.files]);
    if (mediaSrc === 'lib' && got.length) saveToLibrary(got);
  });
  window.addEventListener('dragend', () => { dragDepth = 0; leftPanel.classList.remove('mdrag'); });
  window.addEventListener('drop', () => { dragDepth = 0; leftPanel.classList.remove('mdrag'); });

  // --- controlli
  const cH = (label) => h('div', { class: 'ctl-h' }, label);
  function cSlider(label, value, min, max, step, fmtV, onInput) {
    const val = h('span', { class: 'val' }, fmtV(value));
    const id = uid('r');
    const r = h('input', { id, type: 'range', min, max, step, value });
    let started = false;
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } onInput(+r.value); val.textContent = fmtV(+r.value); dirty = true; scheduleSave(); renderTimeline(); });
    r.addEventListener('change', () => { started = false; renderHeads(); });
    return h('div', { class: 'ctl' }, h('div', { class: 'top' }, h('label', { for: id }, label), val), r);
  }
  function cToggle(label, on, onChange, hint, disabled) {
    const t = toggle(on, (v) => { begin(); onChange(v); changed(); }, label);
    if (disabled) t.disabled = true;
    return h('div', { class: 'tgl' + (disabled ? ' disabled' : ''), 'data-tip': hint || null }, h('div', { class: 'tx' }, label), t);
  }
  function cSeg(label, labels, cur, onPick) {
    return h('div', { class: 'ctl' }, label ? h('div', { class: 'lbl' }, label) : null, seg(labels, cur, (i) => { begin(); onPick(i); changed(); }));
  }
  // piu' elementi selezionati: cosa sono e cosa puoi farci tutti insieme
  function renderMulti() {
    const items = multi.map((m) => ({ m, o: findSel(m) })).filter((x) => x.o);
    const NAMES = { sub: ['frase', 'frasi'], seg: ['pezzo', 'pezzi'], aseg: ['pezzo audio', 'pezzi audio'], zoom: ['zoom', 'zoom'], fx: ['filtro', 'filtri'], sclip: ['elemento', 'elementi'] };
    const cnt = {};
    items.forEach((x) => { cnt[x.m.type] = (cnt[x.m.type] || 0) + 1; });
    const sub = Object.entries(cnt).map(([k, v]) => v + ' ' + (NAMES[k] || [k, k])[v > 1 ? 1 : 0]).join(' · ');
    B.append(head(items.length + ' elementi selezionati', sub, '#2F8BFF', true));
    const list = h('div', { class: 'mlist' });
    for (const [ic, label, note, fn, color] of blockMenu(multi[0])) {
      if (Array.isArray(fn)) {
        list.append(h('div', { class: 'mrow' }, h('span', { class: 'pm-ic' }, icon(ic, 15)), h('span', { class: 'ml' }, label),
          h('div', { class: 'mchips' }, ...fn.map(([, l, , f]) => h('button', { class: 'pchip', onclick: f }, l)))));
      } else {
        list.append(h('button', { class: 'mrow btnrow', onclick: fn }, h('span', { class: 'pm-ic' }, icon(ic, 15, color || 'currentColor')),
          h('span', { class: 'ml' }, label, note ? h('small', null, note) : null)));
      }
    }
    B.append(list);
  }
  function head(title, sub, color, back, actions) {
    return h('div', { class: 'insp-head' },
      back ? ibtn('left', 'Indietro', () => select(null, true), { size: 15 }) : null,
      color ? h('div', { class: 'dot', style: { background: color } }) : null,
      h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0', flexGrow: '1' } }, h('div', { class: 't' }, title), sub ? h('div', { class: 'xs' }, sub) : null),
      actions || null);
  }
  // riga audio compatta: [muto] ——volume—— 100%
  function cAudio(it, muteTip) {
    const val = h('span', { class: 'val' }, it.vol + '%');
    const r = h('input', { type: 'range', min: 0, max: 200, step: 5, value: it.vol, 'aria-label': 'Volume', disabled: it.mute ? true : null });
    let started = false;
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } it.vol = +r.value; val.textContent = it.vol + '%'; dirty = true; scheduleSave(); renderTimeline(); });
    r.addEventListener('change', () => { started = false; });
    const mb = ibtn(it.mute ? 'mute' : 'speaker', it.mute ? 'Riattiva l\'audio' : muteTip, () => { begin(); it.mute = !it.mute; changed(); }, { color: it.mute ? '#FF7B72' : 'currentColor', size: 16 });
    return h('div', { class: 'arow' }, mb, r, val);
  }
  // dissolvenze come due icone
  function cFades(it) {
    return h('div', { class: 'tgl' }, h('div', { class: 'tx' }, 'Dissolvenze'),
      h('div', { class: 'row', style: { gap: '2px' } },
        ibtn('fadeIn', 'Dissolvenza audio in entrata', () => { begin(); it.fin = !it.fin; changed(); }, { pressed: !!it.fin, size: 15 }),
        ibtn('fadeOut', 'Dissolvenza audio in uscita', () => { begin(); it.fout = !it.fout; changed(); }, { pressed: !!it.fout, size: 15 })));
  }
  const pct = (v) => v + '%';

  // controlli che seguono la testina (valori animati dai keyframe)
  let liveCtls = [];
  const B = { append: (...a) => curBody.append(...a.filter((x) => x != null && x !== false)) };
  const emptyTab = (ic, title, text) => h('div', { class: 'tab-empty' }, h('span', { class: 'te-ico' }, icon(ic, 20)), h('strong', null, title), h('span', null, text));
  // sezione a scomparsa (chiusa all'inizio, si apre col clic), come CapCut. Lo stato resta ricordato
  const openSec = new Map();   // tutto chiuso all'apertura; durante la sessione resta come lo lasci
  function fold(key, title, body, opt = {}) {
    let isOpen = openSec.has(key) ? openSec.get(key) : !!opt.open;
    openSec.set(key, isOpen);   // da qui in poi si apre/chiude solo quando lo decidi tu
    const inner = h('div', { class: 'fold-in' });
    let built = false;
    const build = () => { if (built) return; built = true; const b = typeof body === 'function' ? body() : body; (Array.isArray(b) ? b : [b]).filter(Boolean).forEach((x) => inner.append(x)); };
    if (isOpen) build();
    const btn = h('button', { class: 'fold-t', 'aria-expanded': String(isOpen) }, icon('chev', 11, 'currentColor', 2.4), h('span', null, title),
      opt.tip ? h('i', { class: 'fold-tip', 'data-tip': opt.tip }, icon('info', 12, 'currentColor', 2)) : null,
      opt.note ? h('span', { class: 'fold-note' }, opt.note) : null);
    const wrap = h('div', { class: 'fold' + (isOpen ? ' open' : '') }, h('div', { class: 'fold-h' }, btn, opt.right || null), h('div', { class: 'fold-b' }, inner));
    btn.addEventListener('click', () => {
      isOpen = !isOpen; if (isOpen) build();
      wrap.classList.toggle('open', isOpen); btn.setAttribute('aria-expanded', String(isOpen));
      openSec.set(key, isOpen);
    });
    return wrap;
  }
  const glRow = (label, value, onclick, tip) => h('button', { class: 'gl-row', onclick, 'data-tip': tip || null },
    h('span', { class: 'gl-l' }, label), value != null ? h('span', { class: 'gl-v' }, value) : null, icon('chev', 12, 'currentColor', 2.2));

  // ---------- tab Video
  function renderVideoTab() {
    const it = findSel();
    const vsel = sel && it && (sel.type === 'zoom' || sel.type === 'fx' || isSeg(sel.type) || (sel.type === 'sclip' && (it.kind === 'image' || it.kind === 'video')) || (sel.type === 'track' && it.type === 'overlay'));
    if (!vsel) {
      const rows = [];
      rows.push(glRow('Sottotitoli', proj.settings.showSubs ? 'Visibili' : 'Nascosti', () => select({ type: 'subs', id: 'subs' }), 'Stile dei sottotitoli'));
      ovTracks().forEach((t) => rows.push(glRow(t.name, t.clips.length + (t.clips.length === 1 ? ' immagine' : ' immagini'), () => select({ type: 'track', id: t.id }))));
      // filtri e colori: due sezioni separate, chiuse finche' non le apri
      const adjs = proj.filters.filter((f) => f.type === 'adjust'), nfx = proj.filters.length - adjs.length;
      B.append(
        fold('v.filters', 'Filtri', () => fxTiles((id) => addFilter(id)), { note: nfx ? String(nfx) : null, tip: 'Clic su un filtro per aggiungerlo dalla testina' }),
        fold('v.color', 'Regola colori', () => [
          h('button', { class: 'btn sm primary', style: { margin: '4px 0 10px' }, onclick: () => addFilter('adjust') }, icon('plus', 13, '#fff', 2.4), 'Aggiungi regolazione colori'),
          adjs.length ? h('div', { class: 'gl' }, ...adjs.map((f) => glRow('Regola colori', `${fmt(f.a)} → ${fmt(f.b)}`, () => { select({ type: 'fx', id: f.id }); seek(f.a + 0.05); }))) : null],
        { note: adjs.length ? String(adjs.length) : null, tip: 'Luminosità, contrasto, saturazione… su un tratto del video, dalla testina. Per una sola clip, selezionala.' }),
        rows.length ? fold('v.layers', 'Livelli', h('div', { class: 'gl' }, ...rows)) : null);
      return;
    }
    if (sel.type === 'fx') return renderFxProps(it);
    if (sel.type === 'subs') { tab = 'text'; return renderPanel(); }
    if (sel.type === 'zoom' && VERT) {
      const custom = it.kind === 'custom';
      B.append(head(custom ? 'Zoom personalizzato' : 'Zoom sulla webcam', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, custom ? '#A9C7FF' : '#6EA5FF', true, ibtn('trash', 'Elimina questo zoom', deleteSel, { size: 15 })),
        vFrameFold(it), zoomTime(it), zoomCurve(it));
    } else if (sel.type === 'zoom' && it.kind === 'custom') {
      const lvl = W / customRect(W, H, it.rect)[2];
      B.append(head('Zoom personalizzato', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, '#A9C7FF', true, ibtn('trash', 'Elimina questo zoom', deleteSel, { size: 15 })),
        fold('z.frame', 'Inquadratura', [
          h('button', { class: 'btn sm' + (framing ? '' : ' primary'), onclick: () => { framing = !framing; if (framing) seekQuiet(Math.min(it.b - 0.1, it.a + 0.6)); renderPanel(); frame(true); } },
            icon('frame', 14), framing ? 'Chiudi inquadratura' : 'Scegli cosa inquadrare'),
          h('div', { class: 'pgroup' }, numRow('Ingrandimento', () => +(W / zRectNow(it)[2]).toFixed(1), (v) => {
            const [x, y, w, hh] = zRectNow(it), cx = x + w / 2, cy = y + hh / 2, nw = W / v;
            setZoomRect(it, customRect(W, H, [cx - nw / 2, cy - nw * H / W / 2, nw]).slice(0, 3).map(Math.round));
          }, 1.1, 4, 0.1, '×', 2)), zoomKfRow(it)], { note: zKfs(it).length ? zKfs(it).length + ' keyframe' : lvl.toFixed(1).replace('.', ',') + '×' }),
        zoomTime(it), zoomCurve(it));
    } else if (sel.type === 'zoom') {
      B.append(head('Zoom sulla webcam', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, '#6EA5FF', true, ibtn('trash', 'Elimina questo zoom', deleteSel, { size: 15 })),
        fold('z.level', 'Zoom', [h('div', { class: 'pgroup' }, numRow('Ingrandimento', () => it.level || 2.8, (v) => { it.level = Math.round(v * 10) / 10; proj.settings.zoomLevel = it.level; }, 1.1, 4, 0.1, '×', 2.8)),
          (() => {
            const others = proj.zooms.filter((z) => z !== it && z.kind !== 'custom');
            return others.length ? h('button', { class: 'btn sm', type: 'button', style: { alignSelf: 'flex-start' }, onclick: () => setAllZoomLevels(it.level || 2.8) },
              icon('magnify', 13), `Applica a tutti gli zoom (${others.length + 1})`) : null;
          })()],
          { open: true, note: (it.level || 2.8).toFixed(1).replace('.', ',') + '×' }),
        zoomTime(it), zoomCurve(it));
    } else if (isSeg(sel.type)) {
      const i = proj.segs.indexOf(it);
      const acts = h('div', { class: 'row', style: { gap: '0' } },
        i > 0 ? ibtn('mergeL', 'Unisci al pezzo a sinistra', () => mergeSeg(it, -1), { size: 15 }) : null,
        i < proj.segs.length - 1 ? ibtn('mergeR', 'Unisci al pezzo a destra', () => mergeSeg(it, 1), { size: 15 }) : null);
      B.append(head('Clip video', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${((it.b - it.a) / (it.speed || 1)).toFixed(1).replace('.', ',')} s`, it.removed ? '#7F899C' : '#1E6BFF', true, acts),
        cToggle('Nel video finale', !it.removed, (v) => { it.removed = !v; }, it.removed && it.auto ? 'Pausa tagliata in automatico: qui non parlavi' : 'Spegni per togliere questo pezzo dal video'));
      if (!it.removed) {
        const sp = it.speed || 1, adjOn = (it.adj && ADJ_KEYS.some(([k]) => it.adj[k])) || !!(it.adjKf || []).length;
        const setSpeed = (v) => { it.speed = Math.abs(v - 1) < 1e-6 ? undefined : +v.toFixed(2); };
        if (VERT) B.append(clipLayoutFold(it));
        else B.append(clipTfFold(it));
        B.append(
          fold('c.speed', 'Velocità', [
            h('div', { class: 'mchips', style: { paddingLeft: 0, marginBottom: '8px' } }, ...[0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4].map((v) =>
              h('button', { class: 'pchip' + (Math.abs(sp - v) < 1e-6 ? ' on' : ''), onclick: () => { begin(); setSpeed(v); changed(); applySpeed(); } }, (v + '×').replace('.', ',')))),
            h('div', { class: 'pgroup' }, numRow('Velocità', () => it.speed || 1, (v) => { setSpeed(v); applySpeed(); }, 0.25, 4, 0.05, '×', 1))],
          { note: sp === 1 ? 'Normale' : (sp + '×').replace('.', ',') }),
          fold('c.fx', 'Filtri', () => [
            ...(it.fx ? (() => { const K = fxKfKit(segFxF(it)); return [K.row(), h('div', { class: 'pgroup', style: { marginBottom: '8px' } }, K.follow(numRow('Intensità', () => Math.round(K.now().k ?? 100), (v) => { K.set({ k: Math.round(v) }); }, 0, 100, 1, '%', FX_DEFAULT_K[it.fx.type] || 100), () => Math.round(K.now().k ?? 100)))]; })() : []),
            it.fx ? h('button', { class: 'btn sm', style: { marginBottom: '12px' }, onclick: () => { begin(); it.fx = undefined; delete it.fxKf; changed(); } }, 'Togli il filtro') : null,
            fxTiles((id) => { begin(); it.fx = { type: id, k: (it.fx && it.fx.type === id ? it.fx.k : FX_DEFAULT_K[id]) || 100 }; changed(); }, it.fx ? it.fx.type : null)],
          { note: it.fx ? fxName(it.fx.type) : null }),
          fold('c.color', 'Regola colori', () => {
            it.adj = it.adj || {};
            const K = fxKfKit(segColorF(it));
            return [K.row(), h('div', { class: 'pgroup' }, ...ADJ_KEYS.map(([k, label]) => K.follow(numRow(label, () => Math.round(K.now().adj[k] || 0), (v) => { K.set({ adj: { [k]: Math.round(v) } }); }, -100, 100, 1, '', 0), () => Math.round(K.now().adj[k] || 0)))),
              h('div', { class: 'row', style: { justifyContent: 'space-between', marginTop: '10px' } },
                h('span'),
                h('button', { class: 'btn sm', disabled: adjOn || it.adjKf ? null : true, onclick: () => { begin(); it.adj = {}; delete it.adjKf; changed(); } }, 'Azzera'))];
          }, { note: adjOn ? 'Modificato' : null }),
          VERT ? null : keyFold(it),
          h('div', { class: 'clipacts' },
            h('button', { class: 'btn sm', 'data-tip': 'Taglia la clip nel punto della testina', onclick: () => splitSeg() }, icon('scissors', 13), 'Dividi'),
            h('button', { class: 'btn sm', 'data-tip': 'Toglie la clip e avvicina quelle dopo', onclick: () => deleteMany([{ type: sel.type, id: it.id }], true) }, icon('trash', 13), 'Elimina')));
      }
    } else if (sel.type === 'sclip') {
      if (it.kind === 'video') renderOvVideoProps(it); else renderImageProps(it);
    } else if (sel.type === 'track') {
      const name = h('input', { class: 'input', value: it.name, 'aria-label': 'Nome traccia', style: { height: '32px' } });
      name.addEventListener('change', () => { begin(); it.name = name.value.trim() || it.name; changed(); });
      const n = it.clips.length;
      B.append(head('Traccia · ' + it.name, n + (n === 1 ? ' immagine' : ' immagini'), it.color, true, ibtn('trash', 'Elimina la traccia', async () => { if (await confirmBox('Eliminare la traccia?', 'Spariscono tutte le immagini di questa traccia.', 'Elimina', true)) deleteSel(); }, { size: 15 })),
        cToggle('Visibile nel video', !it.hidden, (v) => { it.hidden = !v; }),
        renameFold(it));
    }
  }

  // ---------- immagini: proprieta', 3D e keyframe
  const KF_EPS = 0.04;
  const clipT = (c) => Math.max(0, Math.min(c.dur, video.currentTime - c.a));
  const kfAt = (c, tr) => (c.kf || []).find((k) => Math.abs(k.t - tr) < KF_EPS);
  // cambia una proprieta': senza keyframe vale per tutta la clip, con i keyframe crea/aggiorna quello alla testina
  function setProps(c, patch) {
    if (!c.kf || !c.kf.length) {
      const p = { ...(c.pos || { x: 0.35, y: 0.35, w: 0.3 }) };
      for (const [k, v] of Object.entries(patch)) {
        if (k === 'x' || k === 'y' || k === 'w') p[k] = +(+v).toFixed(4);
        else if (k === 'op') c.opacity = v; else c[k] = +(+v).toFixed(3);
      }
      c.pos = p;
      return;
    }
    const tr = +clipT(c).toFixed(3);
    let k = kfAt(c, tr);
    if (!k) { k = { t: tr, ease: 'smooth', ...imgStateAt(c, tr) }; c.kf.push(k); c.kf.sort((a, b) => a.t - b.t); }
    for (const [kk, v] of Object.entries(patch)) k[kk] = +(+v).toFixed(4);
  }
  function toggleKf(c) {
    begin();
    const tr = +clipT(c).toFixed(3);
    const k = kfAt(c, tr);
    if (k) {
      c.kf = c.kf.filter((x) => x !== k);
      if (!c.kf.length) { const s0 = imgStateAt({ ...c, kf: [k] }, 0); c.kf = []; setProps(c, s0); }
    } else {
      c.kf = c.kf || [];
      if (!c.kf.length && tr > KF_EPS) c.kf.push({ t: 0, ease: 'smooth', ...imgStateAt(c, 0) });
      c.kf.push({ t: tr, ease: 'smooth', ...imgStateAt(c, tr) });
      c.kf.sort((a, b) => a.t - b.t);
    }
    changed();
  }
  function jumpKf(c, dir) {
    const tr = clipT(c);
    const ts = (c.kf || []).map((k) => k.t).sort((a, b) => a - b);
    const t = dir > 0 ? ts.find((x) => x > tr + KF_EPS) : ts.reverse().find((x) => x < tr - KF_EPS);
    if (t !== undefined) { seek(c.a + t + 0.001); renderPanel(); }
  }
  // riga proprieta': nome · barra · valore scrivibile (segue la testina se ci sono keyframe)
  function kRow(c, label, key, min, max, step, unit, toV = (x) => x, fromV = (x) => x, reset = 0) {
    const get = () => fromV(imgStateAt(c, clipT(c))[key]);
    const dec = step < 1 ? 1 : 0;
    const show = (v) => (+v).toFixed(dec).replace('.', ',');
    const r = h('input', { type: 'range', min, max, step, value: get(), 'aria-label': label });
    const num = h('input', { class: 'num', value: show(get()), 'aria-label': label + ' (scrivi un valore)', inputmode: 'decimal' });
    let started = false;
    const apply = (v, commit) => {
      setProps(c, { [key]: toV(v) }); dirty = true; scheduleSave(); placeOverlays(video.currentTime);
      if (commit) { renderTimeline(); renderPanel(); }
    };
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } apply(+r.value); num.value = show(r.value); });
    r.addEventListener('change', () => { started = false; renderTimeline(); renderPanel(); });
    r.addEventListener('dblclick', () => { begin(); apply(reset, true); });
    const commitNum = () => {
      const v = parseFloat(String(num.value).replace(',', '.').replace(/[^0-9.+-]/g, ''));
      if (!isFinite(v)) { num.value = show(get()); return; }
      begin(); apply(v, true);
    };
    num.addEventListener('change', commitNum);
    num.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { num.blur(); return; }
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        const k = (e.key === 'ArrowUp' ? 1 : -1) * (e.shiftKey ? 10 : 1) * step;
        const v = +(get() + k).toFixed(3); num.value = show(v); begin(); apply(v, false); r.value = v;
      }
    });
    num.addEventListener('focus', () => num.select());
    liveCtls.push(() => { const v = get(); if (document.activeElement !== r) r.value = v; if (document.activeElement !== num) num.value = show(v); });
    return h('div', { class: 'prow' }, h('span', { class: 'pl', 'data-tip': 'Doppio clic sulla barra per azzerare' }, label), r, h('label', { class: 'pv' }, num, unit ? h('span', null, unit) : null));
  }
  let imgSub = 'base';
  // video in sovrimpressione: posizione, dimensione, trasparenza e audio (niente 3D/keyframe)
  const cvar = (el, col) => { el.style.setProperty('--c', col); return el; };
  // pannello "Green screen" di un video o di un'immagine sopra la live
  let keyJob = null;   // ritaglio AI in corso: { id, jid, p, msg }
  async function keyCutout(it) {
    if (keyJob) return toast('Sto già ritagliando un altro video: aspetta che finisca', true);
    const main = proj.segs.includes(it);
    const img = it.kind === 'image';
    const md = main ? mainClipData(it) : null;
    const o = main ? md.offset : it.offset || 0, len = main ? md.dur : it.dur, file = main ? md.file : it.file;
    const body = img ? { file: it.file, image: true } : { file, a: +o.toFixed(3), b: +(o + len).toFixed(3) };
    keyJob = { id: it.id, p: 0, msg: 'Preparo il ritaglio' }; renderPanel();
    try {
      const j = await post(`/api/p/${pid}/cutout`, body);
      keyJob.jid = j.id;
      const r = await pollJob(j.id, (x) => { if (keyJob && keyJob.id === it.id) { keyJob.p = x.progress || 0; keyJob.msg = x.message || keyJob.msg; const b2 = document.querySelector('.gs-busy'); if (b2) { b2.querySelector('.gs-bar i').style.width = Math.round(keyJob.p * 100) + '%'; b2.querySelector('.gs-bmsg').textContent = keyJob.msg; b2.querySelector('.gs-bpc').textContent = Math.round(keyJob.p * 100) + '%'; } } });
      if (r.status === 'cancelled') { keyJob = null; if (alive) renderPanel(); return; }
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      begin();
      if (img) it.key = { ...KEY_DEF, ...(it.key || {}), on: true, mode: 'ai', cutFile: r.result.file, src: it.file };
      else it.key = { ...KEY_DEF, ...(it.key || {}), on: true, mode: 'ai', cut: { ...r.result, file } };
      changed();
      toast('Sfondo rimosso');
    } catch (e) { toast('Ritaglio non riuscito: ' + e.message, true); }
    keyJob = null;
    if (alive) { placeOverlays(video.currentTime); frame(true); renderPanel(); }
  }
  // pannello "Rimuovi sfondo" di un video o di un'immagine sopra la live: tinta unita (green screen) o AI (la persona)
  function keyFold(it) {
    const main = proj.segs.includes(it);   // clip della traccia principale: dietro resta il nero
    const srcEl = () => (main ? video.el : srcEl());
    const refresh = () => (main ? frame(true) : placeOverlays(video.currentTime));
    const readyAi = () => (main ? !!segKeyOf({ ...it, key: { ...(it.key || {}), on: true, mode: 'ai' } }) : it.kind === 'image' ? !!aiImgFile(it) : cutOk(it));
    const k = { ...KEY_DEF, ...(it.key || {}) }, on = !!(it.key && it.key.on), ai = k.mode === 'ai';
    const set = (patch, commit = true) => { begin(); it.key = { ...KEY_DEF, ...(it.key || {}), ...patch }; if (commit) changed(); refresh(); };
    const aiReady = readyAi();
    const enable = (v) => {
      if (!v) { if (keyMask === it.id) keyMask = null; set({ on: false }); renderPanel(); return; }
      if (ai) { set({ on: true }); if (!aiReady) keyCutout(it); renderPanel(); return; }
      const el = srcEl();
      const auto = !it.key && el ? keyDetect(el) : null;   // la prima volta trova da solo il colore del telo
      set({ on: true, ...(auto ? { color: auto } : {}) });
      renderPanel();
    };
    const setMode = (m) => {
      if (m === (ai ? 'ai' : 'color')) return;
      set({ on: true, mode: m });
      if (m === 'ai' && !readyAi()) keyCutout(it);
      renderPanel();
    };
    const modes = h('div', { class: 'gs-modes', role: 'tablist' },
      h('button', { class: 'gs-mode' + (!ai ? ' on' : ''), role: 'tab', 'aria-selected': String(!ai), onclick: () => setMode('color') },
        h('i', { class: 'gs-mi gs-mi-c' }), h('span', null, h('b', null, 'Tinta unita'), h('small', null, 'Telo verde, blu…'))),
      h('button', { class: 'gs-mode' + (ai ? ' on' : ''), role: 'tab', 'aria-selected': String(ai), onclick: () => setMode('ai') },
        h('i', { class: 'gs-mi gs-mi-a' }, icon('sparkle', 14, 'currentColor', 2)), h('span', null, h('b', null, 'AI'), h('small', null, 'Qualsiasi sfondo'))));
    const maskOpt = h('label', { class: 'gs-opt' }, h('span', null, h('b', null, 'Mostra la maschera'), h('small', null, 'Bianco resta, nero sparisce: per controllare')),
      toggle(keyMask === it.id, (v) => { keyMask = v ? it.id : null; refresh(); }, 'Mostra la maschera'));
    let content;
    if (ai) {
      const busy = keyJob && keyJob.id === it.id;
      const pc = busy ? Math.round((keyJob.p || 0) * 100) : 0;
      content = [
        busy ? h('div', { class: 'gs-card gs-busy' },
          h('div', { class: 'gs-brow' }, h('div', { class: 'spinner' }), h('span', { class: 'gs-bmsg' }, keyJob.msg), h('span', { class: 'gs-bpc' }, pc + '%')),
          h('div', { class: 'gs-bar' }, h('i', { style: { width: pc + '%' } })),
          h('div', { class: 'gs-brow' }, h('small', null, 'Sul tuo computer, gratis. Puoi continuare a lavorare.'),
            h('button', { class: 'btn sm ghost', onclick: () => { if (keyJob && keyJob.jid) post(`/api/jobs/${keyJob.jid}/cancel`, {}).catch(() => {}); } }, 'Annulla')))
        : aiReady ? h('div', { class: 'gs-card gs-done' },
          h('div', { class: 'gs-brow' }, h('span', { class: 'gs-ok' }, icon('check', 13, 'currentColor', 2.6)), h('span', null, h('b', null, 'Persona ritagliata'), h('small', null, 'Lo sfondo sparisce, resta solo chi è nel video.')),
            h('button', { class: 'gs-ib', 'data-tip': 'Rifai il ritaglio', 'aria-label': 'Rifai il ritaglio', onclick: () => keyCutout(it) }, icon('undo', 15, 'currentColor', 1.9))))
        : h('div', { class: 'gs-card gs-todo' },
          h('div', { class: 'gs-brow' }, h('span', null, h('b', null, it.key && (it.key.cut || it.key.cutFile) ? 'Il video è cambiato' : 'Ritaglia la persona'),
            h('small', null, it.key && (it.key.cut || it.key.cutFile) ? 'Hai allungato o cambiato la clip: rifai il ritaglio.' : 'L\'AI trova la persona e toglie tutto il resto.')),
            h('button', { class: 'btn sm primary', onclick: () => keyCutout(it) }, 'Ritaglia'))),
        h('div', { class: 'gs-note' }, icon('info', 12, 'currentColor', 2), h('span', null, 'Funziona con le persone. Gira sul tuo computer: gratis, e il video non esce dal tuo PC.')),
        (main || it.kind === 'video') && aiReady ? h('div', { class: 'gs-opts' }, maskOpt) : null];
    } else {
      const picking = keyPick === it.id;
      const pickBtn = h('button', { class: 'gs-ib' + (picking ? ' on' : ''), 'data-tip': picking ? 'Annulla' : 'Contagocce: clicca il colore nell\'anteprima', 'aria-label': 'Contagocce', onclick: () => {
        if (picking) { keyPick = null; screen.classList.remove('keypick'); renderPanel(); return; }
        keyPick = it.id; screen.classList.add('keypick'); toast('Clicca sull\'anteprima il colore da togliere'); renderPanel();
      } }, icon('pipette', 16, 'currentColor', 1.9));
      const autoBtn = h('button', { class: 'gs-ib', 'data-tip': 'Trova da solo il colore dello sfondo', 'aria-label': 'Rileva', onclick: () => {
        const el = srcEl(), c2 = el && keyDetect(el);
        if (c2) { set({ color: c2 }); renderPanel(); } else toast('Non trovo uno sfondo verde o blu: usa il contagocce', true);
      } }, icon('wand', 16, 'currentColor', 1.9));
      const PRE = [['Verde', '#00B140'], ['Verde acceso', '#00FF00'], ['Blu', '#0047BB']];
      const dots = h('div', { class: 'gs-dots' }, ...PRE.map(([name, col]) => cvar(h('button', { class: 'gs-dot' + (k.color.toUpperCase() === col ? ' on' : ''), 'data-tip': name, 'aria-label': name, onclick: () => { set({ color: col }); renderPanel(); } }), col)));
      const slider = (label, key, max, def, hint) => {
        const row = numRow(label, () => Math.round(((it.key || k)[key] ?? KEY_DEF[key]) * 100), (v) => { it.key = { ...KEY_DEF, ...(it.key || {}), [key]: +(v / 100).toFixed(3) }; refresh(); }, key === 'sim' ? 1 : 0, max, 1, '%', def);
        if (hint) row.firstChild.setAttribute('data-tip', hint);
        return row;
      };
      content = [
        h('div', { class: 'gs-card' },
          h('div', { class: 'gs-color' },
            cvar(h('div', { class: 'gs-well' }, picking ? h('span', { class: 'gs-pulse' }) : null), k.color),
            h('div', { class: 'gs-meta' }, h('span', { class: 'gs-lbl' }, picking ? 'Clicca il colore…' : 'Colore da togliere'), h('span', { class: 'gs-hex' }, k.color.toUpperCase())),
            h('div', { class: 'gs-tools' }, pickBtn, autoBtn)),
          dots),
        h('div', { class: 'pgroup gs-sl' },
          slider('Tolleranza', 'sim', 60, Math.round(KEY_DEF.sim * 100), 'Quanto colore togliere: alza se resta un po\' di verde, abbassa se sparisce anche la persona'),
          slider('Bordi morbidi', 'blend', 40, Math.round(KEY_DEF.blend * 100), 'Sfuma il contorno: capelli e bordi più naturali')),
        h('div', { class: 'gs-opts' },
          h('label', { class: 'gs-opt' }, h('span', null, h('b', null, 'Togli l\'alone colorato'), h('small', null, 'Niente riflessi verdi su pelle e capelli')), toggle(!!k.spill, (v) => set({ spill: v }), 'Togli l\'alone colorato')),
          maskOpt)];
    }
    const body = on ? h('div', { class: 'gs' }, modes, ...content.filter(Boolean))
      : h('div', { class: 'gs-empty' },
        h('div', { class: 'gs-empty-ic' }, h('i', { class: 'gs-empty-a' }), h('i', { class: 'gs-empty-b' })),
        h('div', null, h('b', null, 'Togli lo sfondo'), h('span', null, main ? 'Telo verde o blu, oppure qualsiasi sfondo con l\'AI: resta solo la persona, con il nero dietro.' : 'Telo verde o blu, oppure qualsiasi sfondo con l\'AI: resta solo la persona, sopra la tua live.')),
        h('div', { class: 'gs-empty-btns' },
          h('button', { class: 'btn sm primary', onclick: () => { const el = srcEl(), auto = el ? keyDetect(el) : null; set({ on: true, mode: 'color', ...(auto ? { color: auto } : {}) }); renderPanel(); } }, 'Tinta unita'),
          h('button', { class: 'btn sm', onclick: () => { set({ on: true, mode: 'ai' }); if (!aiReady) keyCutout(it); else renderPanel(); } }, icon('sparkle', 13, 'currentColor', 2), 'Con l\'AI')));
    return fold(main ? 'c.key' : 'ov.key', 'Rimuovi sfondo', body, { open: true, tip: 'Tinta unita: per un telo verde, blu o di un altro colore. AI: ritaglia la persona da qualsiasi sfondo', right: toggle(on, enable, 'Rimuovi sfondo') });
  }
  function renderOvVideoProps(it) {
    const tr = trackOfClip(it.id);
    const ar = it.ar || 9 / 16;
    B.append(head(it.name.length > 26 ? it.name.slice(0, 24) + '…' : it.name, `${tr.name} · ${fmt(it.a, 1)} → ${fmt(it.a + it.dur, 1)}`, tr.color, true, ibtn('trash', 'Elimina questo video', deleteSel, { size: 15 })));
    const place = (w, x, y) => { begin(); it.pos = { x: +x.toFixed(4), y: +y.toFixed(4), w: +w.toFixed(4) }; changed(); placeOverlays(video.currentTime); renderPanel(); };
    const fit = () => { const w = Math.min(1, (1 / CA()) / ar); place(w, (1 - w) / 2, (1 - w * CA() * ar) / 2); };
    const fill = () => { const w = Math.max(1, (1 / CA()) / ar); place(w, (1 - w) / 2, (1 - w * CA() * ar) / 2); };
    const pip = () => { const w = 0.3, hf = w * CA() * ar; place(w, 1 - w - 0.03, 1 - hf - 0.04); };
    const p = it.pos || { x: 0, y: 0, w: 1 };
    B.append(
      fold('ov.pos', 'Posizione e dimensione', [
        h('div', { class: 'mchips' },
          h('button', { class: 'pchip', onclick: fit }, 'Adatta allo schermo'),
          h('button', { class: 'pchip', onclick: fill }, 'Riempi lo schermo'),
          h('button', { class: 'pchip', onclick: pip }, 'Riquadro in basso')),
        h('div', { class: 'pgroup' },
          numRow('Dimensione', () => Math.round((it.pos || p).w * 100), (v) => { const q = it.pos || p, nw = v / 100, cx = q.x + q.w / 2, cy = q.y + q.w * CA() * ar / 2; it.pos = { w: +nw.toFixed(4), x: +(cx - nw / 2).toFixed(4), y: +(cy - nw * CA() * ar / 2).toFixed(4) }; placeOverlays(video.currentTime); }, 5, 300, 1, '%', 100),
          numRow('Opacità', () => it.opacity ?? 100, (v) => { it.opacity = Math.round(v); placeOverlays(video.currentTime); }, 0, 100, 1, '%', 100))],
      { note: Math.round(p.w * 100) + '%' }),
      keyFold(it),
      fold('ov.audio', 'Audio', it.hasAudio ? [cAudio(it, 'Muta l\'audio di questo video'), cFades(it)] : h('div', { class: 'kfhint' }, 'Questo video non ha audio'),
        { note: !it.hasAudio ? 'Nessuno' : it.mute ? 'Muto' : (it.vol ?? 100) + '%' }));
  }
  function renderImageProps(it) {
    const tr = trackOfClip(it.id);
    const ar = it.ar || 9 / 16;
    const subs = it.isText ? ['text', 'base', 'anim'] : ['base', 'anim'];
    if (!subs.includes(imgSub)) imgSub = subs[0];
    const isBadge = !!(it.isText && it.text && it.text.badge);
    B.append(head(it.name.length > 26 ? it.name.slice(0, 24) + '…' : it.name, `${tr.name} · ${fmt(it.a, 1)} → ${fmt(it.a + it.dur, 1)}`, tr.color, true, ibtn('trash', isBadge ? 'Elimina questo badge' : it.isText ? 'Elimina questo testo' : 'Elimina questa immagine', deleteSel, { size: 15 })),
      seg(it.isText ? [isBadge ? 'Badge' : it.text && it.text.fx ? 'Effetto' : 'Testo', 'Base', 'Animazione'] : ['Base', 'Animazione'], subs.indexOf(imgSub), (i) => { imgSub = subs[i]; renderPanel(); }, 'subtabs'));
    if (imgSub === 'anim') return renderImageAnim(it);
    if (imgSub === 'text') return (isBadge ? badgeBody(it) : it.text && it.text.fx ? codeBody(it) : it.text && it.text.mg ? motionBody(it) : textStyleBody(it)).forEach((x) => x && panelBody.append(x));

    // keyframe: striscia con la durata della clip, rombi e testina
    const onKf = kfAt(it, clipT(it));
    const strip = h('div', { class: 'kfs-track', 'data-tip': 'Clic per spostarti nella clip' });
    for (const k of it.kf || []) {
      const d = h('i', { class: 'kfs-d' + (Math.abs(k.t - clipT(it)) < KF_EPS ? ' on' : ''), style: { left: (k.t / it.dur * 100) + '%' } });
      d.addEventListener('pointerdown', (e) => { e.stopPropagation(); seek(it.a + k.t + 0.001); renderPanel(); });
      strip.append(d);
    }
    const ph = h('i', { class: 'kfs-ph' });
    strip.append(ph);
    strip.addEventListener('pointerdown', (e) => { const r = strip.getBoundingClientRect(); seek(it.a + Math.max(0, Math.min(it.dur - 0.01, (e.clientX - r.left) / r.width * it.dur))); renderPanel(); });
    liveCtls.push(() => { ph.style.left = (clipT(it) / it.dur * 100) + '%'; });
    liveCtls.push(() => { if (!!kfAt(it, clipT(it)) !== !!onKf && !document.activeElement?.matches?.('input')) renderPanel(); });
    const kfBtn = h('button', { class: 'kfbtn' + (onKf ? ' on' : ''), 'data-tip': onKf ? 'Togli questo keyframe' : 'Aggiungi un keyframe qui', 'aria-label': 'Keyframe', onclick: () => toggleKf(it) }, icon('diamond', 13, 'currentColor', 2));
    B.append(h('div', { class: 'kfbox' },
      h('div', { class: 'kfrow' },
        ibtn('left', 'Keyframe precedente', () => jumpKf(it, -1), { size: 13 }), kfBtn, ibtn('chev', 'Keyframe successivo', () => jumpKf(it, 1), { size: 13 }),
        strip),
      onKf && (it.kf || []).length > 1 ? h('div', { class: 'kfease' }, h('span', null, 'Verso il prossimo'),
        seg(['Lineare', 'Morbido'], onKf.ease === 'linear' ? 0 : 1, (i) => { begin(); onKf.ease = i ? 'smooth' : 'linear'; changed(); }, 'mini')) : null,
      null));
    const sizeTo = (v) => {
      const s0 = imgStateAt(it, clipT(it)), nw = v / 100, hf0 = s0.w * CA() * ar, hf1 = nw * CA() * ar;
      setProps(it, { x: s0.x + (s0.w - nw) / 2, y: s0.y + (hf0 - hf1) / 2 });
      return nw;
    };
    B.append(
      fold('img.tr', 'Trasformazione',
        h('div', { class: 'pgroup' },
          kRow(it, 'Posizione X', 'x', -50, 150, 0.5, '%', (v) => v / 100, (x) => x * 100, 35),
          kRow(it, 'Posizione Y', 'y', -50, 150, 0.5, '%', (v) => v / 100, (x) => x * 100, 35),
          kRow(it, 'Dimensione', 'w', 5, 150, 1, '%', sizeTo, (x) => x * 100, 30),
          kRow(it, 'Rotazione', 'rot', -180, 180, 1, '°'),
          kRow(it, 'Opacità', 'op', 0, 100, 1, '%', undefined, undefined, 100)), { open: true }),
      it.isText ? null : keyFold(it),
      fold('img.3d', '3D',
        h('div', { class: 'pgroup' },
          kRow(it, 'Orizzontale', 'ry', -75, 75, 1, '°'),
          kRow(it, 'Verticale', 'rx', -75, 75, 1, '°'),
          kRow(it, 'Profondità', 'z', -100, 60, 1, '', (v) => v / 100, (x) => x * 100)),
        { right: ibtn('restore', 'Togli l\'effetto 3D', () => { begin(); setProps(it, { rx: 0, ry: 0, z: 0 }); changed(); }, { size: 14 }) }),
      fold('img.al', 'Allinea',
        h('div', { class: 'aligngrid' },
          ...[[0, 0, 'In alto a sinistra'], [0.5, 0, 'In alto al centro'], [1, 0, 'In alto a destra'],
            [0, 0.5, 'A sinistra'], [0.5, 0.5, 'Al centro'], [1, 0.5, 'A destra'],
            [0, 1, 'In basso a sinistra'], [0.5, 1, 'In basso al centro'], [1, 1, 'In basso a destra']].map(([fx, fy, tip]) =>
            h('button', { class: 'alignbtn', 'data-tip': tip, 'aria-label': tip, onclick: () => {
              begin();
              const s0 = imgStateAt(it, clipT(it)), hf = s0.w * CA() * ar, m = 0.03;
              const x = fx === 0.5 ? (1 - s0.w) / 2 : (fx ? 1 - s0.w - m : m), y = fy === 0.5 ? (1 - hf) / 2 : (fy ? 1 - hf - m * CA() : m * CA());
              setProps(it, { x, y });
              changed(); seekQuiet(Math.max(it.a, Math.min(it.a + it.dur - 0.05, video.currentTime)));
            } }, h('i', { style: { left: (4 + fx * 12) + 'px', top: (4 + fy * 8) + 'px' } }))))));
  }

  // ---------- immagini: animazioni pronte, con anteprima animata al passaggio del mouse
  function renderImageAnim(it) {
    const an = it.anim || {};
    const kinds = [['motion', 'Movimento'], ['in', 'Entrata'], ['out', 'Uscita'], ['loop', 'Continua']];
    const nameOf = (k, t) => (ANIMS[k].find(([id]) => id === t) || [0, ''])[1];
    for (const [kind, label] of kinds) B.append(fold('an.' + kind, label, () => animBody(it, kind), { open: kind === 'motion' ? !!an.motion || !!(proj.story) : kind === 'in' && !an.in && !an.out && !an.loop && !an.motion, note: an[kind] ? nameOf(kind, an[kind]) : null }));
    B.append(h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, onclick: () => { seek(it.a); if (video.paused) togglePlay(); } }, icon('play', 11, 'currentColor'), 'Guarda'));
  }
  function animBody(it, animSub) {
    const out = [];
    const cur = (it.anim || {})[animSub] || null;
    const setAnim = (patch) => { begin(); it.anim = { ...(it.anim || {}), ...patch }; if (!it.anim.in && !it.anim.out && !it.anim.loop && !it.anim.motion) delete it.anim; changed(); };
    const tiles = [['', 'Nessuna'], ...ANIMS[animSub]].map(([type, label]) => {
      const box = h('i', { class: 'demo-box' });
      const tile = h('button', { class: 'atile' + ((cur || '') === type ? ' on' : ''), 'aria-label': label, onclick: () => {
        const patch = { [animSub]: type || null };
        if (type && animSub === 'in' && !it.anim?.inDur) patch.inDur = 0.5;
        if (type && animSub === 'out' && !it.anim?.outDur) patch.outDur = 0.5;
        setAnim(patch);
        if (type && it.dur) {   // si vede subito come viene sul video
          const end = it.a + it.dur, ind = (it.anim && it.anim.inDur) || 0.5, outd = (it.anim && it.anim.outDur) || 0.5;
          if (animSub === 'in') previewSpan(it.a - 0.3, Math.min(end, it.a + ind + 1));
          else if (animSub === 'out') previewSpan(Math.max(it.a, end - outd - 1), end + 0.3);
          else previewSpan(it.a, Math.min(end, it.a + 3));
        }
      } }, h('span', { class: 'demo' }, box), h('span', { class: 'al' }, label));
      let raf = 0, t0 = 0;
      const demo = { id: 'demo', dur: 1.6, ar: 0.62, pos: { x: 0.3, y: 0.19, w: 0.4 }, anim: {} };
      const paint = (tr) => {
        const s0 = imgFinal(demo, tr, 16 / 10);
        Object.assign(box.style, { left: s0.x * 100 + '%', top: s0.y * 100 + '%', width: s0.w * 100 + '%', opacity: String(Math.max(0, Math.min(1, s0.op / 100))), transform: imgCss(s0, 64) });
      };
      if (type) {
        demo.anim = { [animSub]: type, inDur: 0.6, outDur: 0.6 };
        if (animSub === 'out') demo.dur = 0.6;
        if (animSub === 'loop') demo.dur = 1000;
        if (animSub === 'motion') demo.dur = 2.4;
        const loopT = () => {
          const el = (performance.now() - t0) / 1000;
          const tr = animSub === 'motion' ? el % 2.4 : animSub === 'in' ? Math.min(el % 1.4, 0.6) + (el % 1.4 > 0.6 ? 0.01 : 0) : animSub === 'out' ? Math.min(0.6, el % 1.3) : el;
          paint(Math.min(demo.dur, tr)); raf = requestAnimationFrame(loopT);
        };
        tile.addEventListener('mouseenter', () => { t0 = performance.now(); cancelAnimationFrame(raf); loopT(); });
        tile.addEventListener('mouseleave', () => { cancelAnimationFrame(raf); paint(animSub === 'out' ? 0 : animSub === 'loop' ? 0 : demo.dur); });
      }
      paint(animSub === 'out' || animSub === 'loop' ? 0 : demo.dur);
      if (!type) box.classList.add('none');
      return tile;
    });
    out.push(h('div', { class: 'atiles' }, ...tiles));
    if (cur && animSub !== 'loop') {
      const key = animSub === 'in' ? 'inDur' : 'outDur';
      out.push(h('div', { class: 'pgroup' }, numRow('Durata', () => it.anim[key] || 0.5, (v) => { it.anim[key] = Math.round(v * 10) / 10; }, 0.2, Math.max(0.3, Math.min(3, it.dur)), 0.1, 's', 0.5)));
    }
    return out;
  }

  // ---------- tab Testo: testi, sottotitoli, trascrizione
  function renderTextTab() {
    const it = findSel();
    if (sel && sel.type === 'sclip' && it && it.isText) return renderImageProps(it);
    if (sel && sel.type === 'sub' && it) {
      B.append(head('Frase dei sottotitoli', `${fmt(it.a, 1)} → ${fmt(it.b, 1)}` + (it.hidden ? ' · nascosta' : ''), '#A9C7FF', true),
        h('div', { class: 'subq' + (it.hidden ? ' hid' : '') }, it.text),
        h('div', { class: 'row', style: { gap: '6px', margin: '10px 0 14px' } },
          h('button', { class: 'btn sm', onclick: () => fixSub(it) }, icon('type', 13), 'Correggi il testo'),
          h('button', { class: 'btn sm', onclick: () => { setNoSub(it.a, it.b, !it.hidden); sel = null; renderPanel(); } }, icon(it.hidden ? 'eye' : 'eyeOff', 13), it.hidden ? 'Mostra' : 'Nascondi')));
    }
    const texts = [];
    ovTracks().forEach((t) => t.clips.forEach((c) => { if (c.isText) texts.push(c); }));
    texts.sort((a, b) => a.a - b.a);
    const on = !!proj.settings.showSubs;
    const trDone = proj.transcript && proj.transcript.status === 'done';
    B.append(
      fold('t.titles', 'Titoli animati', () => titleGallery(), { open: true, tip: 'Testi pronti con font, colori e animazione: clicca per aggiungerne uno alla testina' }),
      fold('t.texts', 'Testi', [
        h('button', { class: 'btn sm primary addtext', onclick: () => addText() }, icon('plus', 13, '#fff', 2.4), 'Aggiungi testo'),
        texts.length ? h('div', { class: 'gl' }, ...texts.map((c) => glRow(c.name || 'Testo', fmt(c.a), () => { select({ type: 'sclip', id: c.id }); seek(c.a + 0.05); }))) : null],
      { open: true, note: texts.length ? String(texts.length) : null }),
      fold('t.badges', 'Badge social', () => [
        h('div', { class: 'bdg-add' }, ...PLATFORMS.map(([id, name]) => h('button', { class: 'bdg-p' + (id === 'custom' ? ' own' : ''), onclick: () => addBadge(id),
          'data-tip': id === 'custom' ? 'Un badge con il tuo logo: scegli l\'immagine dal PC' : null }, platIcon(id), h('span', null, name))))],
      { note: (() => { const n = texts.filter((c) => c.text && c.text.badge).length; return n ? String(n) : null; })(), tip: 'Una targhetta col tuo nome sulla piattaforma: la metti dove vuoi e la personalizzi' }),
      fold('t.subs', 'Sottotitoli', () => (allWords().length ? subStyleBody() : subsStatus('panel')), {
        open: !allWords().length,
        note: !allWords().length ? (trStatus() === 'running' ? 'In preparazione' : 'Da creare') : on ? null : 'Nascosti',
        right: allWords().length ? ibtn(on ? 'eye' : 'eyeOff', on ? 'Nascondi i sottotitoli (anche nel video finale)' : 'Mostra i sottotitoli', () => toggleSubs(), { size: 15, color: on ? 'currentColor' : '#FF7B72' }) : null }),
      fold('t.tr', 'Trascrizione', () => { const box = h('div', { class: 'trbox' }); renderTranscript(box); return box; }, { open: !trDone }));
  }
  // galleria dei titoli animati: anteprima vera (stessa immagine dell'esportazione), categorie
  let titleCat = store.get('titleCat', 'social');
  function titleGallery() {
    const wrap = h('div', { class: 'ttl-wrap' });
    const draw = () => {
      const cats = seg(TITLE_CATS.map((x) => x[1]), Math.max(0, TITLE_CATS.findIndex((x) => x[0] === titleCat)), (i) => { titleCat = TITLE_CATS[i][0]; store.set('titleCat', titleCat); draw(); }, 'mini wide ttl-cats');
      const grid = h('div', { class: 'ttl-grid' });
      const stills = [];
      const list = TITLE_PRESETS.filter((x) => x[2] === titleCat);
      // quando tutti i font della categoria sono pronti, le anteprime si ridisegnano con il font giusto
      Promise.all([...new Set(list.flatMap((p) => [p[3].font, p[3].sub && p[3].sub.font].filter(Boolean)))].map((f) => ensureFont(f))).then(() => requestAnimationFrame(() => stills.forEach((f) => f())));
      for (const p of list) {
        const pic = h('div', { class: 'ttl-pic' });
        const tile = h('button', { class: 'ttl-tile anim-' + (p[4].in || 'fade'), type: 'button', 'aria-label': p[1], 'data-tip': p[1] + ' · clicca per aggiungerlo alla testina', onclick: () => addTitle(p) },
          pic, h('span', { class: 'ttl-nm' }, p[1]));
        const st = { ...TEXT_DEFAULT, ...titleStyle(p), size: 0.16 * (p[3].sizeK || 1), content: tx(p[5]) }, kin = p[4].kin;
        const cv = h('canvas', { class: 'ttl-cv' });
        pic.append(cv);
        const still = () => {
          if (kin || isProText(st)) drawKinetic(st, 220, kin ? 2.2 : 0, 3, kin || '', cv); else { const s2 = drawText(st, 220); cv.width = s2.width; cv.height = s2.height; cv.getContext('2d').drawImage(s2, 0, 0); }
        };
        still(); stills.push(still);
        // al passaggio del mouse: l'animazione vera, in loop
        let raf = 0, t0 = 0;
        const loopT = (now) => { if (!t0) t0 = now; const tr = ((now - t0) / 1000) % 3.2; if (kin) drawKinetic(st, 220, tr, 3, kin, cv); raf = requestAnimationFrame(loopT); };
        if (kin) {
          tile.classList.add('kin');
          tile.addEventListener('pointerenter', () => { t0 = 0; cancelAnimationFrame(raf); raf = requestAnimationFrame(loopT); });
          tile.addEventListener('pointerleave', () => { cancelAnimationFrame(raf); still(); });
        }
        grid.append(tile);
      }
      wrap.replaceChildren(cats, grid);
    };
    draw();
    return wrap;
  }
  function addTitle(p) {
    track('title.add');
    begin();
    const t = Math.max(0, Math.min(D - 0.5, video.currentTime)), dur = Math.min(3.5, D - t);
    let tr = ovTracks().find((x) => !x.clips.some((o) => o.a < t + dur && o.a + o.dur > t));
    if (!tr) tr = newTrack('overlay');
    const portrait = VERT || CW() < CH();
    const text = { ...TEXT_DEFAULT, ...titleStyle(p), size: (portrait ? 0.052 : 0.075) * (p[3].sizeK || 1), content: tx(p[5]) };
    const { kin, ...anim } = p[4];
    const c = { id: uid('c'), kind: 'image', isText: true, text, titleId: p[0], name: p[1], file: '', a: +t.toFixed(2), dur: +dur.toFixed(2), opacity: 100, anim };
    if (kin) c.kin = kin;
    const place = () => {
      const cv = c.kin || isProText(c.text) ? drawKinetic(c.text, H, c.kin ? kinSettle(c) : 0, c.dur, c.kin || '') : drawText(c.text, H);
      c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
      const w = Math.min(0.9, c.natW);
      c.pos = { w: +w.toFixed(5), x: +((1 - w) / 2).toFixed(5), y: +((1 - w * CA() * c.ar) / 2).toFixed(5) };
    };
    place();
    tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
    refreshText(c);
    Promise.all([ensureFont(p[3].font), p[3].sub ? ensureFont(p[3].sub.font || p[3].font) : true]).then(() => { if (!alive) return; refreshText(c); frame(true); });
    sel = { type: 'sclip', id: c.id }; tab = 'text'; imgSub = 'text';
    changed();
    seekQuiet(c.a + 0.05);
    setTimeout(() => { const ta = panelBody.querySelector('textarea.tcontent'); if (ta) { ta.focus(); ta.select(); } }, 60);
  }
  // ---------------------------------------------------------------- effetti su misura (l'AI scrive l'animazione)
  const FX_STYLES = [['premium', 'Premium', 'Stile After Effects, pulito'], ['olografico', 'Olografico', 'Luce azzurra, HUD sci-fi'],
    ['neon', 'Neon', 'Colori accesi, scie di luce'], ['minimal', 'Minimal', 'Poche linee, elegante'], ['cinematico', 'Cinematico', 'Luci, scintille, grande']];
  const FX_ACCENTS = ['#4F8CFF', '#22D3EE', '#A78BFA', '#F472B6', '#FACC15', '#34D399', '#FFFFFF'];
  const fxClipOf = new WeakMap();
  setFxExtra((spec, tr) => fxExtraAt(spec, fxClipOf.get(spec), tr));
  setFxRedraw(() => { if (alive) placeOverlays(video.currentTime); });
  function fxDialog(clip) {
    const old = clip && clip.text && clip.text.fx;
    const st = { prompt: old ? old.prompt || '' : '', style: old ? old.style || 'premium' : 'premium', text: old ? old.text || '' : '', accent: old ? old.accent || FX_ACCENTS[0] : FX_ACCENTS[0],
      dur: clip ? clip.dur : 3, spec: old ? { ...old } : null, busy: null, err: null, usd: 0, change: '',
      hand: old ? !!old.hand : false, track: old && old.handTrack ? old.handTrack : null, t0: clip ? clip.a : +Math.max(0, Math.min(D - 0.5, video.currentTime)).toFixed(2), hjob: null, hwarn: '' };
    const trackOk = () => { const P = st.track && st.track.pts; return !!(P && P.length && st.track.at === +st.t0.toFixed(2) && P[P.length - 1][0] >= st.t0 + Math.min(st.dur, D - st.t0) - 0.25); };
    // la mano sotto l'effetto: si traccia sul computer mentre l'AI scrive il codice
    const trackHand = () => {
      if (!st.hand || trackOk() || st.hjob) return;
      const dur = Math.min(st.dur, D - st.t0);
      st.hjob = ensureHand({ id: 'dlg', text: { fx: { hand: true } } }, st.t0, dur).then((tr) => {
        st.hjob = null;
        if (!tr) { st.hwarn = 'Sotto l\'effetto non c\'è un video in cui cercare la mano'; paint(); return; }
        st.track = tr;
        st.hwarn = tr.seen < 0.15 ? 'In questo tratto non vedo bene la mano: quando manca, l\'effetto resta al centro' : '';
        if (!stop) paint();
      }).catch((err) => { st.hjob = null; st.hwarn = 'Mano non trovata: ' + err.message; if (!stop) paint(); });
      paint();
    };
    const bg = h('div', { class: 'modal-bg' });
    const body = h('div', { class: 'fxd' });
    let playing = true, loopT = 0, lastTs = 0, stop = false, drawing = false;
    const pv = h('canvas', { class: 'fxd-cv' });
    const close = () => { stop = true; bg.remove(); document.removeEventListener('keydown', onKey, true); };
    const onKey = (e) => { if (e.key === 'Escape' && !st.busy) { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onKey, true);
    // anteprima: l'effetto gira in loop sopra il fotogramma attuale del video
    const bgFrame = (() => { try { if (!video.el || video.el.readyState < 2) return null; const c = document.createElement('canvas'); c.width = 480; c.height = Math.round(480 * H / W); c.getContext('2d').drawImage(video.el, 0, 0, c.width, c.height); return c; } catch (e) { return null; } })();
    const tick = async (ts) => {
      if (stop) return;
      if (st.spec && playing && !drawing) {
        drawing = true;
        const dt = lastTs ? (ts - lastTs) / 1000 : 0; lastTs = ts;
        loopT = (loopT + dt) % (st.dur + 0.6);
        const t = Math.min(st.dur, loopT);
        try {
          const w = 480, hh = Math.round(480 * H / W);
          const bm = await renderFx(st.spec, t, st.dur, w, hh, st.hand && st.track ? { hand: handAt({ handTrack: st.track }, st.t0 + t) } : null);
          if (pv.width !== w) { pv.width = w; pv.height = hh; }
          const g = pv.getContext('2d'); g.clearRect(0, 0, w, hh);
          if (bgFrame) { g.globalAlpha = 0.9; g.drawImage(bgFrame, 0, 0, w, hh); g.globalAlpha = 1; } else { g.fillStyle = '#10141c'; g.fillRect(0, 0, w, hh); }
          g.drawImage(bm, 0, 0); if (bm.close) bm.close();
        } catch (e) { st.err = e.message; playing = false; paint(); }
        drawing = false;
      } else if (!st.spec) lastTs = ts;
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    const gen = async (change) => {
      if (!st.prompt.trim() && !change) { toast('Descrivi l\'effetto che vuoi', true); return; }
      st.busy = change ? 'Modifico l\'effetto…' : 'L\'AI disegna l\'effetto…'; st.err = null; paint();
      trackHand();
      const ask = async (extra) => {
        const j = await post(`/api/p/${pid}/fxcode`, { prompt: st.prompt + (change ? '\nChange requested: ' + change : ''), dur: st.dur, style: st.style, text: st.text, aspect: W / H, hand: st.hand, ...extra });
        const r = await pollJob(j.id, (x) => { if (x.message && st.busy) { st.busy = x.message; const m = body.querySelector('.fxd-busy span'); if (m) m.textContent = x.message; } });
        if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
        return r.result;
      };
      try {
        let out = await ask(change && st.spec ? { prev: st.spec.code } : {});
        let spec = { id: (st.spec && st.spec.id) || uid('fx'), code: out.code, name: out.name, prompt: st.prompt, style: st.style, text: st.text, accent: st.accent,
          accent2: '#A78BFA', ar: W / H, seed: Math.floor(Math.random() * 1e6), handGen: st.hand };
        st.usd += out.usd || 0;
        try { await testFx(spec, st.dur); } catch (e) {
          // il codice ha un errore: l'AI lo corregge una volta da sola
          st.busy = 'Correggo l\'effetto…'; paint();
          out = await ask({ prev: out.code, error: e.message });
          spec = { ...spec, code: out.code };
          st.usd += out.usd || 0;
          await testFx(spec, st.dur);
        }
        st.spec = spec; playing = true; loopT = 0;
      } catch (e) { st.err = e.message; }
      st.busy = null; paint();
    };
    const add = () => {
      if (!st.spec) return;
      begin();
      const spec = { ...st.spec, style: st.style, text: st.text, accent: st.accent, hand: st.hand };
      if (st.hand && st.track) spec.handTrack = st.track; else delete spec.handTrack;
      if (clip) {
        clip.text = { ...clip.text, fx: spec, content: spec.name }; clip.dur = +st.dur.toFixed(2); clip.name = spec.name;
        refreshText(clip); changed(); close(); renderPanel(); toast('Effetto aggiornato'); if (spec.hand) followHand(clip); return;
      }
      const t = Math.max(0, Math.min(D - 0.5, video.currentTime)), dur = Math.min(st.dur, D - t);
      let tr = ovTracks().find((x) => !x.clips.some((c) => c.a < t + dur && c.a + c.dur > t));
      if (!tr) tr = newTrack('overlay');
      const c = { id: uid('c'), kind: 'image', isText: true, kin: 'code', text: { ...TEXT_DEFAULT, content: spec.name, fx: spec }, name: spec.name, file: '',
        a: +t.toFixed(2), dur: +dur.toFixed(2), opacity: 100, pos: { x: 0, y: 0, w: 1 }, natW: 1, ar: +(H / W).toFixed(5) };
      tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
      refreshText(c);
      sel = { type: 'sclip', id: c.id }; tab = 'text'; imgSub = 'text'; lastTextSel = c.id;
      changed(); close(); seekQuiet(c.a + 0.05);
      toast('Effetto aggiunto: ' + spec.name);
      if (spec.hand) followHand(c);
    };
    function paint() {
      const busy = !!st.busy;
      const ta = h('textarea', { class: 'input fxd-ta', rows: 3, placeholder: 'Es. "Una Terra olografica che gira sopra la mia mano aperta, con anelli di dati intorno"', disabled: busy ? true : null });
      ta.value = st.prompt; ta.addEventListener('input', () => { st.prompt = ta.value; });
      const txt = h('input', { class: 'input', placeholder: 'Testo nell\'effetto (facoltativo)', maxlength: '60', disabled: busy ? true : null, value: st.text });
      txt.addEventListener('input', () => { st.text = txt.value; });
      const durR = h('input', { type: 'range', min: 1.5, max: 10, step: 0.5, value: st.dur, disabled: busy ? true : null });
      const durV = h('b', null, st.dur.toFixed(1).replace('.', ',') + ' s');
      durR.addEventListener('input', () => { st.dur = +durR.value; durV.textContent = st.dur.toFixed(1).replace('.', ',') + ' s'; });
      const chg = h('input', { class: 'input', placeholder: 'Cosa cambio? Es. "più grande, colori oro, entra dal basso"', disabled: busy ? true : null });
      chg.addEventListener('keydown', (e) => { if (e.key === 'Enter' && chg.value.trim()) gen(chg.value.trim()); });
      body.replaceChildren(
        h('div', { class: 'fxd-l' },
          h('label', { class: 'fxd-lbl' }, 'Descrivi l\'effetto'), ta,
          h('label', { class: 'fxd-lbl' }, 'Stile'),
          h('div', { class: 'fxd-styles' }, ...FX_STYLES.map(([k, n, d]) => h('button', { class: 'fxd-st' + (st.style === k ? ' on' : ''), disabled: busy ? true : null, onclick: () => { st.style = k; paint(); } }, h('b', null, n), h('small', null, d)))),
          h('div', { class: 'fxd-row' },
            h('div', null, h('label', { class: 'fxd-lbl' }, 'Colore'), h('div', { class: 'fxd-acc' }, ...FX_ACCENTS.map((col) => cvar(h('button', { class: 'gs-dot' + (st.accent === col ? ' on' : ''), 'aria-label': col, onclick: () => { st.accent = col; if (st.spec) st.spec = { ...st.spec, accent: col }; paint(); } }), col)))),
            h('div', null, h('label', { class: 'fxd-lbl' }, 'Durata'), h('div', { class: 'fxd-dur' }, durR, durV))),
          h('label', { class: 'fxd-lbl' }, 'Testo'), txt,
          h('div', { class: 'fxd-hand' + (st.hand ? ' on' : '') },
            h('span', { class: 'fxd-hic sm hand' }, icon('hand', 14, '#fff', 1.9)),
            h('div', null, h('b', null, 'Segui la mano'),
              h('small', null, !st.hand ? 'L\'effetto si aggancia al palmo e reagisce ai gesti (mano aperta, pugno, indice)'
                : st.hjob ? 'Cerco la mano nel video…' : st.hwarn ? st.hwarn
                : st.track ? 'Mano trovata nel ' + Math.round((st.track.seen || 0) * 100) + '% del tratto · calcolata sul tuo computer' : 'La cerco nel video sotto l\'effetto, sul tuo computer'),
              st.hand && st.spec && !st.spec.handGen && !busy ? h('small', { class: 'warn' }, 'Premi “Rifai da capo” per un effetto che usa la mano') : null),
            toggle(st.hand, (v) => { st.hand = v; if (v) trackHand(); paint(); }, 'Segui la mano')),
          h('div', { class: 'fxd-go' },
            h('button', { class: 'btn primary', disabled: busy ? true : null, onclick: () => gen() }, icon('sparkle', 14, '#fff', 2), st.spec ? 'Rifai da capo' : 'Crea l\'effetto'),
            h('small', null, 'Pochi centesimi di AI a effetto' + (st.usd ? ' · finora ' + usd4(st.usd) : '')))),
        h('div', { class: 'fxd-r' },
          h('div', { class: 'fxd-stage' + (st.spec ? '' : ' empty') }, pv,
            !st.spec && !busy ? h('div', { class: 'fxd-ph' }, icon('sparkle', 22, 'currentColor', 1.6), h('span', null, 'L\'anteprima appare qui')) : null,
            busy ? h('div', { class: 'fxd-busy' }, h('div', { class: 'spinner' }), h('span', null, st.busy)) : null),
          st.err ? h('p', { class: 'fxd-err' }, st.err) : null,
          st.spec ? h('div', { class: 'fxd-name' }, h('b', { 'data-notr': '' }, st.spec.name), h('small', null, 'Scritto dall\'AI da zero · gira sul tuo computer')) : null,
          st.spec ? h('div', { class: 'fxd-chg' }, chg, h('button', { class: 'btn sm', disabled: busy ? true : null, onclick: () => chg.value.trim() && gen(chg.value.trim()) }, 'Modifica')) : null,
          h('div', { class: 'fxd-foot' },
            h('button', { class: 'btn ghost', disabled: busy ? true : null, onclick: close }, 'Annulla'),
            h('button', { class: 'btn primary', disabled: !st.spec || busy ? true : null, onclick: add }, clip ? 'Aggiorna l\'effetto' : 'Aggiungi al video'))));
    }
    const usd4 = (v) => '$' + (+v).toFixed(v < 0.1 ? 3 : 2);
    bg.append(h('div', { class: 'modal fxd-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Effetto su misura' },
      h('div', { class: 'fxd-head' }, h('span', { class: 'fxd-hic' }, icon('sparkle', 16, '#fff', 2)), h('div', null, h('h2', null, 'Effetto su misura'),
        h('p', null, 'Descrivi l\'effetto: l\'AI scrive l\'animazione da zero, come un motion designer. Nessun template.'))),
      body));
    paint();
    document.body.append(bg);
  }
  // pannello di una clip "effetto su misura"
  function codeBody(c) {
    const spec = c.text.fx, err = fxError(spec);
    // clip spostata o allungata: la mano si ricalcola da sola (una volta per posizione)
    if (spec.hand && !handCovers(spec, c) && !handBusy.has(c.id) && handTried.get(c.id) !== c.a.toFixed(2) + ':' + c.dur.toFixed(2)) setTimeout(() => followHand(c), 0);
    return [h('div', { class: 'fxp' },
      h('div', { class: 'fxp-h' }, h('span', { class: 'fxd-hic sm' }, icon('sparkle', 13, '#fff', 2)), h('div', null, h('b', { 'data-notr': '' }, spec.name || 'Effetto'), h('small', null, 'Effetto su misura · ' + ((FX_STYLES.find(([k]) => k === spec.style) || [0, 'Premium'])[1])))),
      spec.prompt ? h('p', { class: 'fxp-p', 'data-notr': '' }, '“' + spec.prompt + '”') : null,
      err ? h('p', { class: 'fxd-err' }, 'L\'effetto ha un errore: ' + err) : null,
      spec.hand ? h('div', { class: 'fxd-hand fxp-hand on' },
        h('span', { class: 'fxd-hic sm hand' }, icon('hand', 14, '#fff', 1.9)),
        h('div', null, h('b', null, 'Segue la mano'),
          h('small', null, handBusy.has(c.id) ? (handMsg || 'Cerco la mano nel video…') : handFail.get(c.id) ? handFail.get(c.id)
            : handCovers(spec, c) ? 'Mano trovata nel ' + Math.round((spec.handTrack.seen || 0) * 100) + '% del tratto' : 'Da calcolare')),
        !handBusy.has(c.id) && !handCovers(spec, c) ? h('button', { class: 'btn sm', onclick: () => followHand(c) }, 'Trova la mano') : null,
        toggle(true, () => { begin(); const f = { ...spec, hand: false }; delete f.handTrack; c.text = { ...c.text, fx: f }; refreshText(c); changed(); renderPanel(); }, 'Segui la mano')) : null,
      h('div', { class: 'fxp-acts' },
        h('button', { class: 'btn sm primary', onclick: () => fxDialog(c) }, icon('sparkle', 13, '#fff', 2), 'Modifica con l\'AI'),
        h('div', { class: 'fxd-acc' }, ...FX_ACCENTS.map((col) => cvar(h('button', { class: 'gs-dot' + ((spec.accent || FX_ACCENTS[0]) === col ? ' on' : ''), 'aria-label': col,
          onclick: () => { begin(); c.text = { ...c.text, fx: { ...spec, accent: col } }; refreshText(c); changed(); renderPanel(); } }), col)))))];
  }
  function addText() {
    begin();
    const t = Math.max(0, Math.min(D - 0.5, video.currentTime)), dur = Math.min(4, D - t);
    let tr = ovTracks().find((x) => !x.clips.some((c) => c.a < t + dur && c.a + c.dur > t));
    if (!tr) tr = newTrack('overlay');
    const c = { id: uid('c'), kind: 'image', isText: true, text: { ...TEXT_DEFAULT, content: tx(TEXT_DEFAULT.content) }, name: tx('Testo'), file: '', a: +t.toFixed(2), dur: +dur.toFixed(2), opacity: 100 };
    const cv = drawText(c.text, H);
    c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
    c.pos = { w: +c.natW.toFixed(5), x: +((1 - c.natW) / 2).toFixed(5), y: +((1 - c.natW * CA() * c.ar) / 2).toFixed(5) };
    tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
    refreshText(c);
    sel = { type: 'sclip', id: c.id }; tab = 'text'; imgSub = 'text';
    changed();
    seekQuiet(c.a + 0.05);
    setTimeout(() => { const ta = panelBody.querySelector('textarea.tcontent'); if (ta) { ta.focus(); ta.select(); } }, 60);
  }
  // badge social: nome e logo di ogni piattaforma restano ricordati per i prossimi progetti
  let badgeMem = null;
  async function loadBadgeMem() {
    if (badgeMem) return badgeMem;
    try { badgeMem = (await get('/api/env')).badges || {}; } catch (e) { badgeMem = {}; }
    return badgeMem;
  }
  loadBadgeMem();
  function rememberBadge(b) {
    if (!badgeMem) return;
    badgeMem[b.platform] = { handle: b.handle || '', logo: b.logo || '' };
    post('/api/settings', { badges: badgeMem }).catch(() => {});
  }
  const platIcon = (id) => (id === 'custom' ? h('i', { class: 'bdg-plus' }, icon('plus', 14, 'currentColor', 2.2))
    : h('img', { src: logoUrl(id, 'free'), alt: '', class: id === 'kick' ? 'wide' : null }));
  async function pickImagePath() {
    try {
      const r = await post('/api/pick', { kind: 'relink-image' });
      let path = r.path;
      if (r.fallback) path = prompt('Percorso completo dell\'immagine:', '') || '';
      return path || '';
    } catch (e) { toast('Non riesco ad aprire l\'immagine'); return ''; }
  }
  function addBadge(pid) {
    begin();
    const t = Math.max(0, Math.min(D - 0.5, video.currentTime)), dur = Math.min(5, D - t);
    let tr = ovTracks().find((x) => !x.clips.some((c) => c.a < t + dur && c.a + c.dur > t));
    if (!tr) tr = newTrack('overlay');
    const mem = (badgeMem || {})[pid] || {};
    const badge = { ...BADGE_DEFAULT, platform: pid, label: tx(badgeLabel(pid)), handle: mem.handle || 'iltuonome', logo: mem.logo || '' };
    const c = { id: uid('c'), kind: 'image', isText: true, text: { ...TEXT_DEFAULT, size: VERT ? 0.04 : 0.05, shadow: true, badge }, name: '', file: '', a: +t.toFixed(2), dur: +dur.toFixed(2), opacity: 100,
      anim: VERT ? { in: 'pop', inDur: 0.5, out: 'fade', outDur: 0.4 } : { in: 'slideL', inDur: 0.6, out: 'slideL', outDur: 0.5 } };
    const cv = drawText(c.text, H, logoFor(c));
    c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
    const hh = c.natW * CA() * c.ar;
    c.pos = VERT ? { w: +c.natW.toFixed(5), x: +((1 - c.natW) / 2).toFixed(5), y: +(0.6 - hh / 2).toFixed(5) }
      : { w: +c.natW.toFixed(5), x: 0.035, y: +(0.93 - hh).toFixed(5) };
    tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
    refreshText(c);
    sel = { type: 'sclip', id: c.id }; tab = 'text'; imgSub = 'text';
    changed();
    seekQuiet(c.a + 0.8);
    // badge personalizzato: si sceglie subito il logo
    if (pid === 'custom' && !badge.logo) pickImagePath().then((path) => { if (!path) return; begin(); c.text.badge.logo = path; rememberBadge(c.text.badge); refreshText(c); changed(); });
  }
  function badgeBody(c) {
    const t = c.text, b = t.badge = { ...BADGE_DEFAULT, ...(t.badge || {}) };
    const p = platformOf(b.platform);
    const redraw = () => { refreshText(c); placeOverlays(video.currentTime); };
    const setB = (patch, remember) => { begin(); Object.assign(b, patch); refreshText(c); if (remember) rememberBadge(b); changed(); };
    const setT = (patch) => { begin(); Object.assign(t, patch); refreshText(c); changed(); };
    const field = (label, key, ph, remember) => {
      const inp = h('input', { class: 'input', value: b[key] || '', placeholder: ph, 'aria-label': label, spellcheck: 'false', style: { height: '32px' } });
      let typing = false, tmr = 0;
      inp.addEventListener('input', () => { if (!typing) { begin(); typing = true; } b[key] = inp.value; clearTimeout(tmr); tmr = setTimeout(() => { redraw(); dirty = true; scheduleSave(); }, 80); });
      inp.addEventListener('blur', () => { if (typing) { typing = false; redraw(); if (remember) rememberBadge(b); changed(); } });
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') inp.blur(); });
      return h('div', { class: 'ctl' }, h('label', { class: 'lbl' }, label), inp);
    };
    // piattaforma: cambiandola cambia anche la scritta sopra (se era quella proposta) e il nome ricordato
    const plats = h('div', { class: 'bdg-add small' }, ...PLATFORMS.map(([id, name]) => h('button', { class: 'bdg-p' + (id === b.platform ? ' on' : ''), onclick: () => {
      if (id === b.platform) return;
      const mem = (badgeMem || {})[id] || {};
      const patch = { platform: id, accent: '' };
      if (!b.label || b.label === tx(badgeLabel(b.platform))) patch.label = tx(badgeLabel(id));
      patch.logo = mem.logo || '';
      if (mem.handle) patch.handle = mem.handle;
      setB(patch);
    } }, platIcon(id), h('span', null, name))));
    // stili: anteprima vera del badge in ogni riquadro
    const styles = h('div', { class: 'bdg-styles' }, ...BADGE_STYLES.map(([id, name]) => {
      const cv = drawBadge({ ...t, size: 0.05, badge: { ...b, style: id } }, 400, logoFor(c));
      cv.className = 'bdg-cv';
      return h('button', { class: 'bdg-st' + (b.style === id ? ' on' : ''), 'data-tip': name, 'aria-label': name, onclick: () => setB({ style: id }) }, h('span', { class: 'bdg-stage' }, cv), h('span', { class: 'al' }, name));
    }));
    const pickLogo = async () => { const path = await pickImagePath(); if (path) setB({ logo: path }, true); };
    const own = b.platform === 'custom';
    const logoName = b.logo ? b.logo.split(/[\\/]/).pop() : '';
    for (const k of ['bd.text', 'bd.style']) if (!openSec.has(k)) openSec.set(k, true);
    if (b.platform === 'custom' && !b.logo) openSec.set('bd.logo', true);   // la prima volta: nome e stile gia' aperti
    return [
      fold('bd.plat', 'Piattaforma', plats, { open: true, note: p[1] }),
      fold('bd.text', 'Scritte', [field('Nome', 'handle', 'iltuonome', true), field('Scritta sopra', 'label', 'Niente (solo il nome)'),
        ], { open: true, note: b.handle }),
      fold('bd.style', 'Stile', styles, { open: true, note: (BADGE_STYLES.find(([id]) => id === b.style) || BADGE_STYLES[0])[1] }),
      fold('bd.color', 'Colore', [sRow('Colore', swatches(b.accent || p[2], (col) => setB({ accent: col }))),
        b.accent ? h('button', { class: 'btn sm ghost', style: { marginTop: '6px' }, onclick: () => setB({ accent: '' }) }, 'Colore di ' + p[1]) : null],
      { note: b.accent ? 'Personalizzato' : p[1] }),
      fold('bd.logo', 'Logo', [
        h('div', { class: 'row', style: { gap: '6px', flexWrap: 'wrap' } },
          h('button', { class: 'btn sm' + (own && !b.logo ? ' primary' : ''), onclick: pickLogo }, icon('upload', 13), b.logo ? 'Cambia immagine' : own ? 'Scegli il tuo logo' : 'Usa un\'immagine tua'),
          b.logo ? h('button', { class: 'btn sm ghost', onclick: () => setB({ logo: '' }, true) }, own ? 'Togli il logo' : 'Logo di ' + p[1]) : null),
        b.logo ? h('div', { class: 'kfhint', 'data-notr': '' }, logoName) : null,
        ],
      { note: b.logo ? 'Immagine tua' : own ? 'Da scegliere' : p[1] }),
      fold('bd.font', 'Carattere', [
        h('div', { class: 'row', style: { gap: '6px' } },
          fontPicker(t.font, (v) => setT({ font: v })),
          h('button', { class: 'tbtn', 'aria-pressed': String(!!t.bold), 'data-tip': 'Grassetto', onclick: () => setT({ bold: !t.bold }) }, h('b', null, 'B')),
          h('button', { class: 'tbtn', 'aria-pressed': String(!!t.upper), 'data-tip': 'Nome tutto maiuscolo', onclick: () => setT({ upper: !t.upper }) }, 'AA')),
        h('div', { class: 'pgroup' }, numRow('Dimensione', () => Math.round(t.size * 1080), (v) => { t.size = v / 1080; refreshText(c); }, 12, 200, 1, 'px', 54))],
      { note: t.font }),
      h('div', { class: 'fold-h solo' }, h('span', { class: 'fold-t static' }, h('span', null, 'Ombra')), toggle(!!t.shadow, (v) => setT({ shadow: v }), 'Ombra')),
      fold('bd.repeat', 'Ripeti nel video', () => {
        const src = c.repeatOf ? findClip(c.repeatOf) || c : c;
        const n = copiesOf(src.id).length;
        const opt = (lbl, tip, rule) => h('button', { class: 'btn sm', 'data-tip': tip, onclick: () => repeatBadge(src, rule) }, lbl);
        return [
          h('div', { class: 'kfhint' }, 'Mette copie uguali di questo badge nel video finale (i tempi contano solo le parti che restano dopo i tagli). Se cambi il badge, ripremi per aggiornare le copie.'),
          h('div', { class: 'row', style: { gap: '6px', flexWrap: 'wrap', marginTop: '6px' } },
            opt('A metà video', 'Una copia a metà del video finale', { mid: true }),
            opt('Inizio e fine', 'Una copia all\'inizio e una alla fine', { ends: true }),
            opt('Ogni 5 min', 'Una copia ogni 5 minuti', { every: 300 }),
            opt('Ogni 10 min', 'Una copia ogni 10 minuti', { every: 600 }),
            opt('Ogni 15 min', 'Una copia ogni 15 minuti', { every: 900 })),
          n ? h('button', { class: 'btn sm ghost', style: { marginTop: '6px' }, onclick: () => { begin(); removeCopies(src.id); changed(); toast('Copie tolte'); } }, 'Togli le ' + n + ' copie') : null];
      }, { note: (() => { const src = c.repeatOf ? c.repeatOf : c.id; const k = copiesOf(src).length; return k ? k + ' copie' : null; })() }),
    ];
  }
  // badge ripetuti: tempo del video finale -> tempo della timeline (salta le parti tagliate)
  function srcAtOut(o) {
    remCache = removed();
    let lo = 0, hi = D;
    for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (outAt(m) < o) lo = m; else hi = m; }
    return hi;
  }
  const findClip = (id) => { for (const tr of proj.tracks || []) for (const x of tr.clips || []) if (x.id === id) return x; return null; };
  const copiesOf = (id) => (proj.tracks || []).flatMap((tr) => (tr.clips || []).filter((x) => x.repeatOf === id));
  function removeCopies(id) { for (const tr of proj.tracks || []) tr.clips = (tr.clips || []).filter((x) => x.repeatOf !== id); }
  function repeatBadge(src, rule) {
    remCache = removed();
    const tot = outDuration(), dur = src.dur || 5, o0 = outAt(src.a);
    let outs = [];
    if (rule.mid) outs = [tot / 2 - dur / 2];
    else if (rule.ends) outs = [Math.min(5, tot * 0.05), tot - dur - 5];
    else if (rule.every) for (let o = rule.every; o < tot - dur; o += rule.every) outs.push(o);
    outs = outs.filter((o) => o >= 0 && o + dur <= tot + 0.01 && Math.abs(o - o0) > dur);
    if (!outs.length) { toast('Il video è troppo corto per queste copie', true); return; }
    begin();
    removeCopies(src.id);
    for (const o of outs) {
      const t = +Math.min(D - dur, srcAtOut(o)).toFixed(2);
      const cp = deep(src); cp.id = uid('c'); cp.a = t; cp.repeatOf = src.id;
      let tr = ovTracks().find((x) => !x.clips.some((y) => y.a < t + dur && y.a + y.dur > t));
      if (!tr) tr = newTrack('overlay');
      tr.clips.push(cp); tr.clips.sort((x, y) => x.a - y.a);
      refreshText(cp);
    }
    changed();
    toast(outs.length === 1 ? '1 copia aggiunta' : outs.length + ' copie aggiunte');
  }
  // grafica animata: modello, colore e dati (si ridisegna subito)
  function motionBody(c) {
    const mg = c.text.mg;
    const upd = (fn, re) => { begin(); fn(); c.text.mg = cleanMotion(mg); Object.assign(mg, c.text.mg); c.text = { ...c.text, mg: c.text.mg, content: mg.title || motionName(mg.tpl) }; placeMotionKeep(c); refreshText(c); changed(); if (re) renderPanel(); };
    const inp = (v, ph, set, w) => { const e = h('input', { class: 'input', value: v || '', placeholder: ph, style: w ? { width: w } : null }); e.addEventListener('change', () => upd(() => set(e.value), true)); return e; };
    const items = mg.items || [];
    const usesItems = !['numero', 'progresso'].includes(mg.tpl), usesValue = ['numero', 'progresso', 'linea'].includes(mg.tpl);
    return [
      h('div', { class: 'mgx-tpls' }, ...MOTION_TPLS.map(([id, nm]) => h('button', { class: 'pchip' + (mg.tpl === id ? ' on' : ''), type: 'button', onclick: () => upd(() => { mg.tpl = id; }, true) }, nm))),
      h('div', { class: 'aim-acc' }, ...MOTION_ACCENTS.map((col) => h('button', { class: 'aim-sw' + (mg.accent === col ? ' on' : ''), type: 'button', style: { background: col }, onclick: () => upd(() => { mg.accent = col; }, true) }))),
      h('label', { class: 'mgx-l' }, 'Titolo', inp(mg.title, 'Titolo', (v) => { mg.title = v; })),
      usesValue ? h('label', { class: 'mgx-l' }, 'Valore', inp(mg.value, 'Es. +40%', (v) => { mg.value = v; })) : null,
      usesItems ? h('div', { class: 'mgx-items' }, ...items.map((x, i) => h('div', { class: 'mgx-row' },
        mg.tpl !== 'linea' ? inp(x.label, 'Etichetta', (v) => { x.label = v; }) : null,
        ['barre', 'linea', 'confronto'].includes(mg.tpl) ? inp(x.value, mg.tpl === 'confronto' ? 'Frase' : 'Valore', (v) => { x.value = v; }) : null,
        ibtn('x', 'Togli', () => upd(() => { items.splice(i, 1); }, true), { size: 13 }))),
        items.length < 5 ? h('button', { class: 'btn sm', onclick: () => upd(() => { items.push({ label: '', value: '' }); mg.items = items; }, true) }, icon('plus', 12), 'Aggiungi') : null) : null,
    ];
  }
  function placeMotionKeep(c) {
    // stessa posizione (centro) e stessa scala quando cambiano i dati
    const cv = drawMotion(c.text.mg, H, 2.2, c.dur);
    const natW = cv.width / CW(), ar = cv.height / cv.width;
    if (c.pos && c.natW) { const k = natW / c.natW, cx = c.pos.x + c.pos.w / 2, cy = c.pos.y + c.pos.w * CA() * (c.ar || ar) / 2; c.pos.w = +(c.pos.w * k).toFixed(5); c.pos.x = +(cx - c.pos.w / 2).toFixed(5); c.pos.y = +(cy - c.pos.w * CA() * ar / 2).toFixed(5); }
    c.natW = natW; c.ar = ar;
  }
  function textStyleBody(c) {
    const t = c.text = { ...TEXT_DEFAULT, ...(c.text || {}) };
    const setT = (patch) => { begin(); Object.assign(t, patch); refreshText(c); changed(); };
    // contenuto: si aggiorna mentre scrivi
    const ta = h('textarea', { class: 'input tcontent', rows: '3', 'aria-label': 'Testo', spellcheck: 'false' });
    ta.value = t.content;
    let typing = false, tmr = 0;
    ta.addEventListener('input', () => {
      if (!typing) { begin(); typing = true; }
      t.content = ta.value;
      clearTimeout(tmr); tmr = setTimeout(() => { refreshText(c); dirty = true; scheduleSave(); }, 90);
    });
    ta.addEventListener('blur', () => { if (typing) { typing = false; refreshText(c); changed({ keepPanel: true }); } });
    const presets = h('div', { class: 'sub-presets' }, ...TEXT_PRESETS.map(([name, p]) => {
      const ps = { ...t, ...p };
      const sample = h('span', { class: 'pv' }, 'Aa');
      Object.assign(sample.style, {
        fontFamily: `"${ps.font}", Arial, sans-serif`, fontWeight: ps.bold ? '700' : '400', fontStyle: ps.italic ? 'italic' : 'normal', color: ps.color,
        textTransform: ps.upper ? 'uppercase' : 'none', textShadow: textShadowFor({ ...ps, strokeW: ps.strokeW || 0.08 }, 16),
        background: ps.box ? hexA(ps.boxColor, (ps.boxOp ?? 80) / 100) : 'transparent', padding: ps.box ? '1px 7px' : '0', borderRadius: ps.box ? '6px' : '0', fontSize: '18px',
      });
      const same = Object.entries(p).every(([k, v]) => t[k] === v);
      return h('button', { class: 'sp' + (same ? ' on' : ''), 'data-tip': name, 'aria-label': name, onclick: () => setT({ ...p }) }, sample);
    }));
    const font = fontPicker(t.font, (v) => setT({ font: v }));
    const tb = (label, key, tip, style) => h('button', { class: 'tbtn', 'aria-pressed': String(!!t[key]), 'data-tip': tip, onclick: () => setT({ [key]: !t[key], ...(key === 'bold' ? { weight: null } : {}) }) }, style ? h(style, null, label) : label);
    // titoli animati: cambiano stile e animazione, il testo resta il tuo
    const titleChips = h('div', { class: 'ttl-chips' }, ...TITLE_PRESETS.map((p) => h('button', { class: 'pchip' + (c.titleId === p[0] ? ' on' : ''), type: 'button',
      onclick: () => { begin(); const hl = p[3].hlColor || p[3].hlBox; const keep = { content: hl ? t.content : String(t.content || '').replace(/\*([^*]+)\*/g, '$1'), size: t.size }; c.text = { ...TEXT_DEFAULT, ...titleStyle(p), ...keep }; const { kin, ...an } = p[4]; c.anim = an; if (kin) c.kin = kin; else delete c.kin; c.titleId = p[0]; ensureFont(p[3].font).then(() => { refreshText(c); changed(); }); refreshText(c); changed(); } }, p[1])));
    const kinChips = h('div', { class: 'ttl-chips' },
      h('button', { class: 'pchip' + (!c.kin ? ' on' : ''), type: 'button', onclick: () => { begin(); delete c.kin; refreshText(c); changed(); } }, 'Nessuna'),
      ...KINETICS.map(([id, name, desc]) => h('button', { class: 'pchip' + (c.kin === id ? ' on' : ''), type: 'button', 'data-tip': desc,
        onclick: () => { begin(); c.kin = id; if (c.anim && ['pop', 'slam', 'tilt', 'rise', 'zoom'].includes(c.anim.in) && id !== 'slide') { c.anim = { ...c.anim }; delete c.anim.in; } refreshText(c); changed(); } }, name)));
    const hlHint = t.hlColor || t.hlBox ? h('div', { class: 'xs muted ttl-hint' }, icon('info', 12), h('span', null, 'Metti tra *asterischi* le parole da evidenziare')) : null;
    const aligns = ['left', 'center', 'right'];
    let subTa = null;
    if (t.sub) {
      subTa = h('input', { class: 'input tsub', 'aria-label': 'Seconda scritta', placeholder: 'Seconda scritta', spellcheck: 'false' });
      subTa.value = t.sub.content || '';
      let tm2 = 0, typing2 = false;
      subTa.addEventListener('input', () => { if (!typing2) { begin(); typing2 = true; } t.sub = { ...t.sub, content: subTa.value }; clearTimeout(tm2); tm2 = setTimeout(() => { refreshText(c); dirty = true; scheduleSave(); }, 90); });
      subTa.addEventListener('blur', () => { if (typing2) { typing2 = false; refreshText(c); changed({ keepPanel: true }); } });
    }
    return [
      ta, subTa ? h('div', { class: 'tsub-row' }, h('span', { class: 'xs muted' }, 'Seconda scritta'), subTa) : null, hlHint,
      fold('tx.kin', 'Animazione delle lettere', kinChips, { open: !!c.kin, note: c.kin ? kineticName(c.kin) : null, tip: 'Ogni lettera o parola si muove da sola, come nei pack professionali' }),
      fold('tx.titles', 'Titoli animati', titleChips, { open: !!c.titleId, note: c.titleId ? (TITLE_PRESETS.find((p) => p[0] === c.titleId) || [0, ''])[1] : null }),
      fold('tx.style', 'Stili pronti', presets, { open: !c.titleId }),
      fold('tx.font', 'Carattere', [
        h('div', { class: 'row', style: { gap: '6px' } }, font, tb('B', 'bold', 'Grassetto', 'b'), tb('I', 'italic', 'Corsivo', 'i'), tb('AA', 'upper', 'Tutto maiuscolo')),
        h('div', { class: 'pgroup' }, numRow('Dimensione', () => Math.round(t.size * 1080), (v) => { t.size = v / 1080; refreshText(c); }, 12, 300, 1, 'px', 86)),
        seg(['Sinistra', 'Centro', 'Destra'], Math.max(0, aligns.indexOf(t.align)), (i) => setT({ align: aligns[i] }), 'mini wide'),
        sRow('Colore', swatches(t.color, (col) => setT({ color: col })))], { open: true, note: t.font }),
      fold('tx.stroke', 'Contorno', [
        sRow('Colore', swatches(t.strokeColor, (col) => setT({ strokeColor: col }))),
        h('div', { class: 'pgroup' }, numRow('Spessore', () => Math.round(t.strokeW * 100), (v) => { t.strokeW = v / 100; refreshText(c); }, 1, 30, 1, '%', 8))],
      { right: toggle(!!t.stroke, (v) => setT({ stroke: v }), 'Contorno') }),
      // ---- parole evidenziate (le "targhette"): riquadro e colore della parola
      fold('tx.hl', 'Parole evidenziate', [
        h('button', { class: 'btn sm hlbtn', type: 'button', onmousedown: (e) => e.preventDefault(), onclick: () => {
          const a = ta.selectionStart, b = ta.selectionEnd;
          let v = ta.value, s0 = a, s1 = b;
          if (s0 === s1) { while (s0 > 0 && /[^\s*]/.test(v[s0 - 1])) s0--; while (s1 < v.length && /[^\s*]/.test(v[s1])) s1++; }   // nessuna selezione: la parola sotto il cursore
          const w = v.slice(s0, s1).replace(/\*/g, '').trim();
          if (!w) { toast(tx('Seleziona nel testo la parola da evidenziare')); ta.focus(); return; }
          begin();
          t.content = v.slice(0, s0) + '*' + w + '*' + v.slice(s1);
          if (!t.hlColor && !t.hlBox) Object.assign(t, { hlBox: true, hlBoxColor: '#FFC400', hlBoxColor2: '#FFE45C', hlColor: '#0B0B0B' });
          refreshText(c); changed();
        } }, icon('diamond', 13), 'Evidenzia la parola selezionata'),
        h('div', { class: 'xs muted ttl-hint' }, 'Oppure scrivi la parola tra *asterischi*. Per togliere l\'evidenziazione cancella gli asterischi.'),
        sRow('Parola', swatches(t.hlColor || t.color, (col) => setT({ hlColor: col }))),
        sRow('Riquadro', swatches(t.hlBoxColor || '#FFC400', (col) => setT({ hlBox: true, hlBoxColor: col, hlBoxColor2: '' }))),
        h('div', { class: 'pgroup' }, numRow('Inclinazione', () => Math.round(t.hlTilt ?? -2), (v) => { t.hlTilt = Math.round(v); refreshText(c); }, -12, 12, 1, '°', -2)),
        h('div', { class: 'tgl' }, h('div', { class: 'tx' }, 'Alone del riquadro'), toggle(!!t.hlGlow, (v) => setT({ hlGlow: v ? hexA(t.hlBoxColor || '#FFC400', 0.55) : '' }), 'Alone del riquadro'))],
      { open: hasHighlight(t.content), right: toggle(!!t.hlBox, (v) => setT(v ? { hlBox: true, hlBoxColor: t.hlBoxColor || '#FFC400', hlColor: t.hlColor || '#0B0B0B' } : { hlBox: false }), 'Riquadro') }),
      // ---- bagliore, lucido, sfumatura
      fold('tx.bloom', 'Bagliore', [
        sRow('Colore', swatches(toHex(t.bloom || t.color), (col) => setT({ bloom: col }))),
        h('div', { class: 'pgroup' }, numRow('Intensità', () => Math.round((t.bloomK || 0.35) * 100), (v) => { t.bloomK = v / 100; if (!t.bloom) t.bloom = t.color; refreshText(c); }, 10, 90, 1, '%', 35))],
      { right: toggle(!!t.bloom, (v) => setT({ bloom: v ? (t.color || '#FFFFFF') : '' }), 'Bagliore') }),
      fold('tx.grad', 'Sfumatura', [
        sRow('Sopra', swatches((t.grad && t.grad[0]) || t.color, (col) => setT({ grad: [col, (t.grad && t.grad[t.grad.length - 1]) || '#FF7A00'] }))),
        sRow('Sotto', swatches((t.grad && t.grad[t.grad.length - 1]) || '#FF7A00', (col) => setT({ grad: [(t.grad && t.grad[0]) || t.color, col] })))],
      { right: toggle(!!(t.grad && t.grad.length > 1), (v) => setT({ grad: v ? [t.color || '#FFE27A', '#FF7A00'] : null }), 'Sfumatura') }),
      h('div', { class: 'fold-h solo' }, h('span', { class: 'fold-t static' }, h('span', null, 'Effetto lucido')), toggle(!!t.gloss, (v) => setT({ gloss: v }), 'Effetto lucido')),
      // ---- seconda scritta (un altro font sovrapposto)
      fold('tx.sub', 'Seconda scritta', t.sub ? [
        h('div', { class: 'row', style: { gap: '6px' } }, fontPicker(t.sub.font || t.font, (v) => { ensureFont(v).then(() => { refreshText(c); frame(true); }); setT({ sub: { ...t.sub, font: v } }); })),
        sRow('Colore', swatches(t.sub.color || '#FFFFFF', (col) => setT({ sub: { ...t.sub, color: col, grad: null } }))),
        h('div', { class: 'pgroup' }, numRow('Grandezza', () => Math.round((t.sub.scale || 0.6) * 100), (v) => { t.sub = { ...t.sub, scale: v / 100 }; refreshText(c); }, 25, 160, 1, '%', 70)),
        seg(['In basso a destra', 'Sotto', 'Sopra', 'In basso a sinistra'], Math.max(0, ['br', 'below', 'above', 'bl'].indexOf(t.sub.pos || 'br')), (i) => setT({ sub: { ...t.sub, pos: ['br', 'below', 'above', 'bl'][i], dx: 0 } }), 'mini wide'),
        h('div', { class: 'tgl' }, h('div', { class: 'tx' }, 'Bagliore'), toggle(!!t.sub.bloom, (v) => setT({ sub: { ...t.sub, bloom: v ? (t.sub.color || '#FFFFFF') : '' } }), 'Bagliore della seconda scritta'))] : [
        h('div', { class: 'xs muted' }, 'Una seconda parola sovrapposta con un altro font, come "Morning" + routine.')],
      { open: !!t.sub, right: toggle(!!t.sub, (v) => setT({ sub: v ? { content: tx('routine'), font: 'Great Vibes', weight: 400, scale: 1, color: '#FFFFFF', pos: 'br', dy: 0.3 } : null }), 'Seconda scritta') }),
      fold('tx.box', 'Sfondo', [
        sRow('Colore', swatches(t.boxColor, (col) => setT({ boxColor: col }))),
        h('div', { class: 'pgroup' },
          numRow('Opacità', () => t.boxOp ?? 80, (v) => { t.boxOp = Math.round(v); refreshText(c); }, 5, 100, 1, '%', 80),
          numRow('Angoli', () => Math.round((t.boxR ?? 0.25) * 100), (v) => { t.boxR = v / 100; refreshText(c); }, 0, 100, 1, '%', 25))],
      { right: toggle(!!t.box, (v) => setT({ box: v }), 'Sfondo') }),
      h('div', { class: 'fold-h solo' }, h('span', { class: 'fold-t static' }, h('span', null, 'Ombra')), toggle(!!t.shadow, (v) => setT({ shadow: v }), 'Ombra')),
    ];
  }

  // ---------- sottotitoli: stile
  const SUB_PRESETS = [
    ['Classico', { font: 'Arial', bold: true, upper: false, color: '#FFFFFF', stroke: false, box: true, boxColor: '#000000', boxOp: 70, shadow: false, effect: 'none' }],
    ['Contorno', { font: 'Arial', bold: true, upper: false, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: false, effect: 'none' }],
    ['Giallo', { font: 'Arial', bold: true, upper: false, color: '#FFD60A', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: true, effect: 'none' }],
    ['Karaoke', { font: 'Arial', bold: true, upper: true, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.12, box: false, shadow: false, effect: 'highlight', hiColor: '#3DDC84' }],
    ['Pop', { font: 'Impact', bold: false, upper: true, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: true, effect: 'pop' }],
    ['Minimal', { font: 'Segoe UI', bold: true, upper: false, color: '#FFFFFF', stroke: false, box: false, shadow: true, effect: 'none' }],
  ];
  const FONTS = ['Arial', 'Impact', 'Segoe UI', 'Verdana', 'Trebuchet MS', 'Tahoma', 'Georgia', 'Comic Sans MS'];
  const SWATCHES = ['#FFFFFF', '#FFD60A', '#3DDC84', '#4FC3F7', '#FF5A5F', '#FF7AD9', '#000000'];
  function subSet(patch, rerender = true) { begin(); Object.assign(proj.subStyle, patch); applySubStyle(); if (rerender) changed(); else { ver++; dirty = true; scheduleSave(); } }
  function sSlider(label, key, min, max, step, fmtV) {
    const st = proj.subStyle;
    const val = h('span', { class: 'val' }, fmtV(st[key]));
    const r = h('input', { type: 'range', min, max, step, value: st[key], 'aria-label': label });
    let started = false;
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } st[key] = +r.value; val.textContent = fmtV(+r.value); applySubStyle(); ver++; dirty = true; scheduleSave(); });
    r.addEventListener('change', () => { started = false; renderTimeline(); });
    return h('div', { class: 'ctl' }, h('div', { class: 'top' }, h('label', null, label), val), r);
  }
  function swatches(cur, onPick) {
    const custom = h('input', { type: 'color', value: cur, 'aria-label': 'Altro colore' });
    custom.addEventListener('change', () => onPick(custom.value.toUpperCase()));
    const known = SWATCHES.includes((cur || '').toUpperCase());
    return h('div', { class: 'swatches' },
      ...SWATCHES.map((c) => h('button', { class: 'sw' + (c === (cur || '').toUpperCase() ? ' on' : ''), style: { background: c }, 'aria-label': c, onclick: () => onPick(c) })),
      h('label', { class: 'sw custom' + (known ? '' : ' on'), style: known ? {} : { background: cur }, 'data-tip': 'Altro colore' }, known ? icon('plus', 12, 'currentColor', 2.4) : null, custom));
  }
  // colore in esadecimale (per i campioni di colore): accetta anche rgba(...)
  function toHex(col) {
    const m = /^rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(col || '');
    if (!m) return col || '#FFFFFF';
    return '#' + [m[1], m[2], m[3]].map((x) => (+x).toString(16).padStart(2, '0')).join('').toUpperCase();
  }
  function sRow(label, control) { return h('div', { class: 'srow' }, h('span', null, label), control); }
  function subStyleBody() {
    const st = proj.subStyle;
    // stili pronti
    const presets = h('div', { class: 'sub-presets' }, ...SUB_PRESETS.map(([name, p]) => {
      const ps = { ...st, ...p };
      const sample = h('span', { class: 'pv' + (p.effect === 'pop' ? ' big' : '') }, ...(p.effect === 'highlight' ? [h('b', { style: { color: p.hiColor } }, 'Aa'), ' bb'] : ['Aa bb']));
      Object.assign(sample.style, {
        fontFamily: `"${ps.font}", Arial, sans-serif`, fontWeight: ps.bold ? '700' : '400', color: ps.color, textTransform: ps.upper ? 'uppercase' : 'none',
        textShadow: textShadowFor(ps, 16),
        background: ps.box ? hexA(ps.boxColor, ps.boxOp / 100) : 'transparent', padding: ps.box ? '1px 5px' : '0',
      });
      const same = Object.entries(p).every(([k, v]) => st[k] === v);
      return h('button', { class: 'sp' + (same ? ' on' : ''), 'data-tip': name, 'aria-label': name, onclick: () => subSet({ ...p }) }, sample);
    }));
    const font = fontPicker(st.font, (v) => subSet({ font: v }));
    const eff = { none: 'Nessuno', highlight: 'Parola', pop: 'Pop' };
    return [fold('s.style', 'Stili pronti', presets, { open: true }),
      fold('s.text', 'Carattere', [
        h('div', { class: 'row', style: { gap: '6px' } }, font,
          h('button', { class: 'tbtn', 'aria-pressed': String(!!st.bold), 'data-tip': 'Grassetto', onclick: () => subSet({ bold: !st.bold }) }, h('b', null, 'B')),
          h('button', { class: 'tbtn', 'aria-pressed': String(!!st.upper), 'data-tip': 'Tutto maiuscolo', onclick: () => subSet({ upper: !st.upper }) }, 'AA')),
        sSlider('Dimensione', 'size', 0.03, 0.12, 0.001, (v) => Math.round(v * 1080) + ' px'),
        sRow('Colore', swatches(st.color, (c) => subSet({ color: c })))], { note: st.font }),
      fold('s.stroke', 'Contorno', [
        sRow('Colore', swatches(st.strokeColor, (c) => subSet({ strokeColor: c }))),
        sSlider('Spessore', 'strokeW', 0.02, 0.25, 0.005, (v) => Math.round(v * 100) + '%')], { right: toggle(!!st.stroke, (v) => subSet({ stroke: v }), 'Contorno') }),
      fold('s.box', 'Sfondo', [
        sRow('Colore', swatches(st.boxColor, (c) => subSet({ boxColor: c }))),
        sSlider('Opacità', 'boxOp', 10, 100, 5, (v) => Math.round(v) + '%')], { right: toggle(!!st.box, (v) => subSet({ box: v }), 'Sfondo') }),
      h('div', { class: 'fold-h solo' }, h('span', { class: 'fold-t static' }, h('span', null, 'Ombra')), toggle(!!st.shadow, (v) => subSet({ shadow: v }), 'Ombra')),
      fold('s.fx', 'Effetto', [
        seg(['Nessuno', 'Parola', 'Pop'], st.effect === 'highlight' ? 1 : st.effect === 'pop' ? 2 : 0, (i) => subSet({ effect: ['none', 'highlight', 'pop'][i] })),
        st.effect === 'highlight' ? sRow('Parola detta', swatches(st.hiColor, (c) => subSet({ hiColor: c }))) : null], { note: eff[st.effect] || 'Nessuno' }),
      fold('s.pos', 'Posizione', [
        seg(['Alto', 'Centro', 'Basso'], st.y < 0.4 ? 0 : st.y < 0.75 ? 1 : 2, (i) => subSet({ y: [0.2, 0.62, 0.92][i] })),
        sSlider('Altezza', 'y', 0.12, 0.99, 0.005, (v) => Math.round((1 - v) * 100) + '%')]),
      fold('s.words', 'Parole per riga', seg(['Una', 'Poche', 'Medie', 'Tante'], st.maxChars <= 1 ? 0 : st.maxChars <= 20 ? 1 : st.maxChars <= 30 ? 2 : 3, (i) => subSet({ maxChars: [1, 18, 28, 38][i] })),
        { note: st.maxChars <= 1 ? 'Parola per parola' : st.maxChars <= 20 ? 'Poche' : st.maxChars <= 30 ? 'Medie' : 'Tante',
          tip: '"Una" = parola per parola: ogni parola compare da sola, a tempo con la voce (stile TikTok)' })];
  }

  // ---------- filtri
  const FX_DEFAULT_K = { blur: 50, pixel: 45, glow: 60, vignette: 70, grain: 55, glitch: 55, vhs: 80 };
  function numRow(label, get, set, min, max, step, unit, reset) {
    const dec = step < 1 ? 1 : 0, show = (v) => (+v).toFixed(dec).replace('.', ',');
    const r = h('input', { type: 'range', min, max, step, value: get(), 'aria-label': label });
    const num = h('input', { class: 'num', value: show(get()), 'aria-label': label + ' (scrivi un valore)', inputmode: 'decimal' });
    let started = false;
    const apply = (v, commit) => { set(Math.max(min, Math.min(max, v))); fxDirty = true; dirty = true; scheduleSave(); if (commit) changed(); };
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } apply(+r.value); num.value = show(r.value); });
    r.addEventListener('change', () => { started = false; renderTimeline(); });
    if (reset !== undefined) r.addEventListener('dblclick', () => { begin(); apply(reset, true); });
    num.addEventListener('change', () => { const v = parseFloat(String(num.value).replace(',', '.')); if (!isFinite(v)) { num.value = show(get()); return; } begin(); apply(v, true); });
    num.addEventListener('keydown', (e) => { if (e.key === 'Enter') num.blur(); });
    num.addEventListener('focus', () => num.select());
    return h('div', { class: 'prow' }, h('span', { class: 'pl', title: label }, label), r, h('label', { class: 'pv' }, num, unit ? h('span', null, unit) : null));
  }
  // riquadri dei filtri con l'anteprima sul fotogramma attuale
  function fxTiles(onPick, cur, noAdj) {
    const group = (kind, title) => h('div', { class: 'fxgroup' }, h('div', { class: 'fxg-t' }, title),
      h('div', { class: 'fxtiles' }, ...FX_LIST.filter((f) => f.kind === kind).map((f) => {
        const cv = h('canvas', { width: '112', height: String(Math.round(112 * H / W)) });
        const tile = h('button', { class: 'fxtile' + (cur === f.id ? ' on' : ''), 'aria-label': f.name, onclick: () => onPick(f.id) }, cv, h('span', null, f.name));
        requestAnimationFrame(() => { loadLooks().then(() => { try { fxr.thumb(video.el || video, f.id, cv); } catch (e) { /* */ } }); });
        return tile;
      })));
    return h('div', { class: 'fxpick' }, group('look', 'Look'), group('fx', 'Effetti'));
  }
  function adjustTrack(fresh) {
    let t = !fresh && proj.fxTracks.find((x) => x.kind === 'adjust');
    if (!t) {
      const n = proj.fxTracks.filter((x) => x.kind === 'adjust').length;
      t = { id: uid('ft'), name: n ? 'Colori ' + (n + 1) : 'Colori', kind: 'adjust' };
      proj.fxTracks.push(t); proj.layers = normLayers();
    }
    return t.id;
  }
  function addFilter(type, freshTrack) {
    begin();
    const t = Math.min(D - 0.5, video.currentTime);
    let track = curFxTrack();
    const tk = (proj.fxTracks.find((x) => x.id === track) || {}).kind;
    if (type === 'adjust' && (freshTrack || tk !== 'adjust')) track = adjustTrack(freshTrack);
    else if (type !== 'adjust' && tk === 'adjust') track = 'fx';
    const f = { id: uid('f'), track, type, a: +t.toFixed(2), b: +Math.min(D, t + 10).toFixed(2), k: FX_DEFAULT_K[type] || 100,
      mask: { type: 'all', x: 0.3, y: 0.3, w: 0.4, h: 0.4, feather: 0.15, invert: false, strokes: [] } };
    proj.filters.push(f);
    sel = { type: 'fx', id: f.id }; tab = 'video'; fxSub = 'filter';
    changed();
  }
  // keyframe dei filtri: intensita' e colori che cambiano nel tempo (come per immagini e zoom)
  function fxKfKit(f) {
    const len = () => Math.max(0.01, f.b - f.a), tr = () => Math.max(0, Math.min(f.b - f.a, video.currentTime - f.a));
    const kfs = () => f.kf || [], on = () => kfs().find((k) => Math.abs(k.t - tr()) < KF_EPS);
    const now = () => fxAt(f, video.currentTime);
    const snapAt = (t) => { const n = fxAt(f, f.a + t); return { t: +t.toFixed(3), ease: 'smooth', k: Math.round(n.k ?? 100), adj: Object.fromEntries(ADJ_KEYS.map(([k]) => [k, Math.round((n.adj || {})[k] || 0)])) }; };
    // senza keyframe il valore vale per tutto il filtro; con i keyframe si crea/aggiorna quello alla testina
    function set(patch) {
      if (!kfs().length) { if (patch.k != null) f.k = patch.k; if (patch.adj) f.adj = { ...(f.adj || {}), ...patch.adj }; return; }
      let k = on();
      if (!k) { k = snapAt(tr()); f.kf.push(k); f.kf.sort((a, b) => a.t - b.t); }
      if (patch.k != null) k.k = patch.k;
      if (patch.adj) k.adj = { ...(k.adj || {}), ...patch.adj };
    }
    function toggle() {
      begin();
      const k = on();
      if (k) {
        f.kf = f.kf.filter((x) => x !== k);
        if (!f.kf.length) { f.kf = undefined; if (k.k != null) f.k = k.k; if (k.adj) f.adj = { ...(f.adj || {}), ...k.adj }; }
      } else {
        f.kf = f.kf || [];
        if (!f.kf.length && tr() > KF_EPS) f.kf.push(snapAt(0));
        f.kf.push(snapAt(tr()));
        f.kf.sort((a, b) => a.t - b.t);
      }
      changed();
    }
    function jump(dir) {
      const ts = kfs().map((k) => k.t), cur = tr();
      const nx = dir > 0 ? ts.find((t) => t > cur + KF_EPS) : ts.slice().reverse().find((t) => t < cur - KF_EPS);
      if (nx != null) { seek(f.a + nx + 0.001); renderPanel(); }
    }
    function row() {
      const o = on();
      const strip = h('div', { class: 'kfs-track', 'data-tip': 'Clic per spostarti nel filtro' });
      for (const k of kfs()) {
        const d = h('i', { class: 'kfs-d' + (k === o ? ' on' : ''), style: { left: (k.t / len() * 100) + '%' } });
        d.addEventListener('pointerdown', (e) => { e.stopPropagation(); seek(f.a + k.t + 0.001); renderPanel(); });
        strip.append(d);
      }
      const ph = h('i', { class: 'kfs-ph' });
      strip.append(ph);
      strip.addEventListener('pointerdown', (e) => { const r = strip.getBoundingClientRect(); seek(f.a + Math.max(0, Math.min(len() - 0.01, (e.clientX - r.left) / r.width * len()))); renderPanel(); });
      liveCtls.push(() => { ph.style.left = (tr() / len() * 100) + '%'; });
      liveCtls.push(() => { if (!!on() !== !!o && !document.activeElement?.matches?.('input')) renderPanel(); });
      return h('div', { class: 'kfbox', style: { marginBottom: '10px' } },
        h('div', { class: 'kfrow' },
          ibtn('left', 'Keyframe precedente', () => jump(-1), { size: 13 }),
          h('button', { class: 'kfbtn' + (o ? ' on' : ''), 'data-tip': o ? 'Togli questo keyframe' : 'Aggiungi un keyframe qui: poi vai avanti e cambia i valori, il filtro passa da uno all\'altro', 'aria-label': 'Keyframe', onclick: toggle }, icon('diamond', 13, 'currentColor', 2)),
          ibtn('chev', 'Keyframe successivo', () => jump(1), { size: 13 }), strip),
        o && kfs().length > 1 ? h('div', { class: 'kfease' }, h('span', null, 'Verso il prossimo'),
          seg(['Lineare', 'Morbido'], o.ease === 'linear' ? 0 : 1, (i) => { begin(); o.ease = i ? 'smooth' : 'linear'; changed(); }, 'mini')) : null);
    }
    // con i keyframe le barre seguono la testina
    function follow(rowEl, get) {
      if (!kfs().length) return rowEl;
      const [rg, num] = rowEl.querySelectorAll('input');
      liveCtls.push(() => { if (document.activeElement === rg || document.activeElement === num) return; const v = get(); rg.value = v; num.value = String(v); });
      return rowEl;
    }
    return { now, set, row, follow };
  }
  // colori e filtro messi su una clip: stessi keyframe dei filtri (c.adjKf, c.fxKf; t dall'inizio della clip)
  const segColorF = (c) => ({ get a() { return c.a; }, get b() { return c.b; }, get k() { return 100; }, set k(v) { /* */ },
    get adj() { return c.adj || {}; }, set adj(v) { c.adj = v; }, get kf() { return c.adjKf; }, set kf(v) { if (Array.isArray(v)) c.adjKf = v; else delete c.adjKf; } });
  const segFxF = (c) => ({ get a() { return c.a; }, get b() { return c.b; }, get k() { return c.fx ? (c.fx.k ?? 100) : 100; }, set k(v) { if (c.fx) c.fx.k = v; },
    adj: {}, get kf() { return c.fxKf; }, set kf(v) { if (Array.isArray(v)) c.fxKf = v; else delete c.fxKf; } });
  function renderFxProps(f) {
    const inside = video.currentTime >= f.a && video.currentTime < f.b;
    const K = fxKfKit(f);
    B.append(head(fxName(f.type), `${fmt(f.a, 1)} → ${fmt(f.b, 1)} · ${(f.b - f.a).toFixed(1).replace('.', ',')} s`, '#4A8BFF', true,
      h('div', { class: 'row', style: { gap: '0' } },
        ibtn(f.off ? 'eyeOff' : 'eye', f.off ? 'Riattiva il filtro' : 'Spegni il filtro (resta sulla timeline)', () => { begin(); f.off = !f.off; changed(); }, { size: 15, color: f.off ? '#FF7B72' : 'currentColor' }),
        ibtn('trash', 'Elimina il filtro', deleteSel, { size: 15 }))),
      seg(['Filtro', 'Maschera'], fxSub === 'mask' ? 1 : 0, (i) => { fxSub = i ? 'mask' : 'filter'; if (i && !inside) seekQuiet(f.a + 0.05); renderPanel(); }, 'subtabs'));
    if (fxSub !== 'mask' && f.type === 'adjust') {
      f.adj = f.adj || {};
      const any = ADJ_KEYS.some(([k]) => f.adj[k]) || !!(f.kf || []).length;
      B.append(fold('fx.adj', 'Colori', [K.row(), h('div', { class: 'pgroup' }, ...ADJ_KEYS.map(([k, label]) => K.follow(numRow(label, () => Math.round(K.now().adj[k] || 0), (v) => { K.set({ adj: { [k]: Math.round(v) } }); }, -100, 100, 1, '', 0), () => Math.round(K.now().adj[k] || 0)))),
        h('div', { class: 'row', style: { justifyContent: 'space-between', marginTop: '8px' } },
          h('span'),
          h('button', { class: 'btn sm', disabled: any ? null : true, onclick: () => { begin(); f.adj = {}; f.kf = undefined; changed(); } }, 'Azzera tutto'))], { open: true, note: any ? 'Modificato' : null }));
      return;
    }
    if (fxSub !== 'mask') {
      B.append(fold('fx.k', 'Regolazioni', [K.row(), h('div', { class: 'pgroup' }, K.follow(numRow('Intensità', () => Math.round(K.now().k ?? 100), (v) => { K.set({ k: Math.round(v) }); }, 0, 100, 1, '%', FX_DEFAULT_K[f.type] || 100), () => Math.round(K.now().k ?? 100)))], { open: true, note: (f.kf || []).length ? f.kf.length + ' keyframe' : null }),
        fold('fx.pick', 'Cambia filtro', () => fxTiles((id) => { begin(); f.type = id; changed(); }, f.type), { note: fxName(f.type) }));
      return;
    }
    const m = f.mask = f.mask || { type: 'all' };
    const types = ['all', 'rect', 'ellipse', 'brush'];
    B.append(seg(['Tutto', 'Rettangolo', 'Ellisse', 'Pennello'], Math.max(0, types.indexOf(m.type || 'all')), (i) => {
      begin(); m.type = types[i];
      if (m.type !== 'all' && m.w === undefined) Object.assign(m, { x: 0.3, y: 0.3, w: 0.4, h: 0.4, feather: 0.15 });
      m.strokes = m.strokes || [];
      if (!inside) seekQuiet(f.a + 0.05);
      changed();
    }, 'mini wide'));
    if (m.type === 'all' || !m.type) { B.append(h('div', { class: 'kfhint' }, 'Il filtro vale su tutto il video. Scegli una forma o il pennello per applicarlo solo a una parte.')); return; }
    if (m.type === 'brush') {
      B.append(fold('m.brush', 'Pennello', [h('div', { class: 'row', style: { gap: '6px' } },
        seg(['Pennello', 'Gomma'], brushMode === 'erase' ? 1 : 0, (i) => { brushMode = i ? 'erase' : 'paint'; renderPanel(); }, 'mini'),
        h('div', { class: 'grow' }),
        h('button', { class: 'btn sm', disabled: (m.strokes || []).length ? null : true, onclick: () => { begin(); m.strokes = []; changed(); } }, 'Cancella tutto')),
      h('div', { class: 'pgroup' }, numRow('Dimensione', () => Math.round(brushR * 1000) / 10, (v) => { brushR = v / 100; }, 0.5, 20, 0.5, '%'))], { open: true, note: brushMode === 'erase' ? 'Gomma' : null }));
    }
    B.append(fold('m.edge', 'Bordi', [h('div', { class: 'pgroup' }, numRow('Sfumatura', () => Math.round((m.feather ?? 0.15) * 100), (v) => { m.feather = v / 100; }, 0, 100, 1, '%', 15)),
      cToggle('Inverti', !!m.invert, (v) => { m.invert = v; }, 'Applica il filtro fuori dalla forma invece che dentro')], { note: m.invert ? 'Invertita' : null }),
      h('div', { class: 'kfhint' }, !inside ? 'Porta la testina dentro il filtro per vedere la maschera.' :
        m.type === 'brush' ? 'Dipingi sull\'anteprima dove vuoi il filtro. In rosso la zona coperta.' : 'Sposta e ridimensiona la forma nell\'anteprima. In rosso la zona coperta.'));
  }

  // verticale: dove finisce lo zoom (un riquadro 9:16 sulla live), per ogni zoom
  function vFrameFold(it) {
    const own = !!it.vrect || zKfs(it).length > 0;
    const toggleFraming = () => { framing = !framing; if (framing) seekQuiet(Math.min(it.b - 0.1, it.a + 0.6)); renderPanel(); frame(true); };
    const size = () => { const r = zRectNow(it); return r ? Math.round(r[3] / H * 100) : 100; };
    return fold('z.vframe', 'Inquadratura', [
      h('div', { class: 'kfhint', style: { margin: '0 0 10px' } }, own ? 'Scelta a mano per questo zoom.' : 'Automatica: ' + (it.kind === 'custom' ? 'il centro della zona scelta.' : 'la webcam al centro.')),
      h('div', { class: 'row', style: { gap: '6px', flexWrap: 'wrap' } },
        h('button', { class: 'btn sm' + (framing ? '' : ' primary'), onclick: toggleFraming }, icon('frame', 14), framing ? 'Fatto' : 'Sposta l\'inquadratura'),
        own ? h('button', { class: 'btn sm ghost', onclick: () => { begin(); delete it.vrect; if (it.kf) { it.kf = it.kf.filter((k) => !k.vrect); if (!it.kf.length) delete it.kf; } changed(); frame(true); } }, 'Automatica') : null),
      h('div', { class: 'pgroup', style: { marginTop: '10px' } }, numRow('Dimensione', size, (v) => {
        const r = zRectNow(it); if (!r) return;
        const a = zA(it), nh = H * v / 100, nw = nh * a, cx = r[0] + r[2] / 2, cy = r[1] + r[3] / 2;
        setZoomRect(it, vertRect(W, H, [cx - nw / 2, cy - nh / 2, nw], a).slice(0, 3).map(Math.round)); frame(true);
      }, 15, 100, 1, '%')), zoomKfRow(it),
      framing ? h('div', { class: 'kfhint' }, 'Trascina il riquadro sull\'anteprima: è quello che si vede alla fine dello zoom.') : null],
    { note: own ? 'A mano' : 'Automatica' });
  }
  // durata dello zoom (e da quando parte), scritta a mano o con la barra
  function zoomTime(it) {
    const len = it.b - it.a;
    return fold('z.time', 'Durata', h('div', { class: 'pgroup' },
      numRow('Durata', () => +(it.b - it.a).toFixed(1), (v) => { it.b = +Math.min(D, it.a + v).toFixed(2); }, 0.8, Math.max(1, Math.min(60, D - it.a)), 0.1, 's', 4),
      numRow('Inizio', () => +it.a.toFixed(1), (v) => { const l = it.b - it.a; it.a = +Math.max(0, Math.min(D - l, v)).toFixed(2); it.b = +(it.a + l).toFixed(2); }, 0, Math.max(0, D - len), 0.1, 's')),
    { note: len.toFixed(1).replace('.', ',') + ' s' });
  }
  // effetti dello zoom: riquadri con l'anteprima animata (passa sopra col mouse), come le animazioni delle immagini
  // in verticale gli effetti sono a parte (la webcam che si allarga a tutto schermo), di base non a scatto
  const zKey = (kind) => (VERT ? (kind === 'in' ? 'vin' : 'vout') : kind);
  const zCur = (it, kind) => it[zKey(kind)] || (VERT ? 'fast' : (kind === 'in' ? 'snap' : 'cut'));
  // curva dell'effetto (quanto e' ingrandito nel tempo): cosi' ogni riquadro si riconosce anche da fermo
  const SVGNS = 'http://www.w3.org/2000/svg';
  const svgEl = (tag, attrs) => { const e = document.createElementNS(SVGNS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
  function zoomFxTiles(it, kind) {
    const list = kind === 'in' ? ZOOM_IN_FX : ZOOM_OUT_FX, cur = zCur(it, kind);
    const LOOP = 2.6, CW_ = 64, CH_ = 38;
    return h('div', { class: 'atiles' + (VERT ? ' v' : '') }, ...list.map(([type, label]) => {
      const fake = kind === 'in' ? { a: 0, b: 2.0, in: type, out: 'cut' } : { a: 0, b: 1.8, in: 'snap', out: type };
      // p nel tempo del giro (el da 0 a LOOP)
      const pAt = (el) => (kind === 'in' ? (el < 0.3 ? 0 : zoomProgress(el - 0.3, fake)) : (el + 0.3 < fake.b ? zoomProgress(el + 0.3, fake) : 0));
      const X = (el) => 3 + (el / LOOP) * (CW_ - 6), Y = (p) => CH_ - 5 - Math.max(-0.05, Math.min(1.25, p)) * (CH_ - 14);
      let d = '';
      for (let i = 0; i <= 90; i++) { const el = (i / 90) * LOOP; d += (i ? 'L' : 'M') + X(el).toFixed(1) + ' ' + Y(pAt(el)).toFixed(1); }
      const svg = svgEl('svg', { class: 'zf-curve', viewBox: `0 0 ${CW_} ${CH_}`, width: CW_, height: CH_ });
      svg.append(svgEl('line', { x1: 3, x2: CW_ - 3, y1: Y(0), y2: Y(0), class: 'zc-base' }), svgEl('line', { x1: 3, x2: CW_ - 3, y1: Y(1), y2: Y(1), class: 'zc-top' }),
        svgEl('path', { d, class: 'zc-line' }));
      const dot = svgEl('circle', { r: 2.6, class: 'zc-dot', cx: X(0), cy: Y(pAt(0)) });
      svg.append(dot);
      const cam0 = h('b', { class: 'zf-cam' });
      const scene = VERT ? h('i', { class: 'zf-vscene' }, h('b', { class: 'zf-vgame' }), cam0) : h('i', { class: 'zf-scene' }, cam0);
      const tile = h('button', { class: 'atile' + (cur === type ? ' on' : ''), 'aria-label': label, onclick: () => {
        begin(); it[zKey(kind)] = type; changed();
        // si vede subito come viene: l'entrata dall'inizio dello zoom, l'uscita dalla fine
        if (kind === 'in') previewSpan(it.a - 0.5, Math.min(it.b, it.a + 2.4)); else previewSpan(Math.max(it.a, it.b - 2), it.b + 0.7);
      } },
        h('span', { class: 'demo zf' + (VERT ? ' v' : '') }, scene, svg), h('span', { class: 'al' }, label));
      const Z = 2.4;
      const paint = (p) => {
        if (VERT) { const q = Math.max(0, p); cam0.style.height = (40 + 60 * Math.min(1.08, q)).toFixed(1) + '%'; return; }
        scene.style.transform = `scale(${Math.pow(Z, p).toFixed(4)})`;
      };
      let raf = 0, t0 = 0;
      const loopT = () => {
        const el = ((performance.now() - t0) / 1000) % LOOP, p = pAt(el);
        paint(p); dot.setAttribute('cx', X(el).toFixed(1)); dot.setAttribute('cy', Y(p).toFixed(1));
        raf = requestAnimationFrame(loopT);
      };
      const rest = () => { const el = kind === 'in' ? LOOP * 0.75 : 0; paint(VERT ? 0 : pAt(el)); dot.setAttribute('cx', X(el).toFixed(1)); dot.setAttribute('cy', Y(pAt(el)).toFixed(1)); };
      tile.addEventListener('mouseenter', () => { t0 = performance.now(); cancelAnimationFrame(raf); tile.classList.add('play'); loopT(); });
      tile.addEventListener('mouseleave', () => { cancelAnimationFrame(raf); tile.classList.remove('play'); rest(); });
      rest();
      return tile;
    }));
  }
  function zoomCurve(it) {
    const nm = (list, v) => (list.find(([id]) => id === v) || list[0])[1];
    const zt = it.track || 'zoom', same = proj.zooms.filter((z) => (z.track || 'zoom') === zt && z !== it);
    return fold('z.curve', 'Effetto', [
      h('div', { class: 'zf-lbl' }, 'Entrata'), zoomFxTiles(it, 'in'),
      h('div', { class: 'zf-lbl' }, 'Uscita'), zoomFxTiles(it, 'out'),
      same.length ? h('button', { class: 'btn sm', style: { marginTop: '12px' }, onclick: () => {
        begin(); same.forEach((z) => { z[zKey('in')] = zCur(it, 'in'); z[zKey('out')] = zCur(it, 'out'); }); changed();
        toast(`Effetto applicato a ${same.length + 1} zoom della traccia`);
      } }, icon('duplicate', 13), `Applica a tutti gli zoom della traccia (${same.length + 1})`) : null,
      ],
    { note: nm(ZOOM_IN_FX, zCur(it, 'in')) + ' · ' + nm(ZOOM_OUT_FX, zCur(it, 'out')) });
  }
  const renameFold = (it) => {
    const name = h('input', { class: 'input', value: it.name, 'aria-label': 'Nome traccia', style: { height: '32px' } });
    name.addEventListener('change', () => { begin(); it.name = name.value.trim() || it.name; changed(); });
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') name.blur(); });
    return fold('t.name', 'Nome', name, { note: it.name });
  };
  const fadeNote = (it) => (it.fin && it.fout ? 'Entrata e uscita' : it.fin ? 'Entrata' : it.fout ? 'Uscita' : 'Nessuna');

  // ---------- tab Audio
  function renderAudioTab() {
    const it = findSel();
    const asel = sel && it && (isSeg(sel.type) || (sel.type === 'sclip' && it.kind !== 'image') || (sel.type === 'track' && it.type !== 'overlay'));
    if (!asel) return renderMixer();
    if (isSeg(sel.type)) {
      B.append(head('Audio del pezzo', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, '#1E6BFF', true));
      if (it.removed) { B.append(emptyTab('scissors', 'Pezzo tolto', 'Questo pezzo non è nel video finale, quindi neanche il suo audio')); return; }
      B.append(fold('a.vol', 'Volume', cAudio(it, 'Silenzia l\'audio di questo pezzo (il video resta)'), { open: true, note: it.mute ? 'Muto' : it.vol + '%' }),
        fold('a.fade', 'Dissolvenze', cFades(it), { note: fadeNote(it) }));
    } else if (sel.type === 'sclip') {
      const tr = trackOfClip(it.id);
      B.append(head(it.name, `${tr.name} · ${fmt(it.a, 1)} → ${fmt(it.a + it.dur, 1)}`, tr.color, true, ibtn('trash', 'Elimina questo suono', deleteSel, { size: 15 })),
        fold('a.vol', 'Volume', [cAudio(it, 'Muta questo suono'),
          cToggle('Si abbassa quando parli', !!it.duck, (v) => { it.duck = v; }, 'Utile per la musica di sottofondo')], { open: true, note: it.mute ? 'Muto' : it.vol + '%' }),
        fold('a.fade', 'Dissolvenze', cFades(it), { note: fadeNote(it) }));
    } else {
      const isLive = it.type === 'live';
      const np = isLive ? proj.segs.length : it.clips.length;
      B.append(head('Traccia · ' + it.name, np + (np === 1 ? ' parte' : ' parti'), isLive ? '#1E6BFF' : it.color, true,
        isLive ? null : ibtn('trash', 'Elimina la traccia', async () => { if (await confirmBox('Eliminare la traccia?', 'Spariscono tutti i suoni di questa traccia.', 'Elimina', true)) deleteSel(); }, { size: 15 })),
        fold('a.vol', 'Volume', cAudio(it, 'Muta tutta la traccia'), { open: true, note: it.mute ? 'Muto' : it.vol + '%' }));
      if (!isLive) B.append(renameFold(it));
    }
  }
  // tutte le tracce audio in un colpo d'occhio
  function renderMixer() {
    const tracks = [liveTrack(), ...soundTracks()];
    const rows = tracks.map((t) => {
      const val = h('span', { class: 'val' }, t.vol + '%');
      const r = h('input', { type: 'range', min: 0, max: 200, step: 5, value: t.vol, 'aria-label': 'Volume ' + t.name, disabled: t.mute ? true : null });
      let started = false;
      r.addEventListener('input', () => { if (!started) { begin(); started = true; } t.vol = +r.value; val.textContent = t.vol + '%'; dirty = true; scheduleSave(); renderTimeline(); });
      r.addEventListener('change', () => { started = false; });
      return h('div', { class: 'mx-row' },
        h('div', { class: 'mx-top' },
          h('span', { class: 'dot', style: { background: t.type === 'live' ? '#1E6BFF' : t.color } }),
          h('button', { class: 'mx-nm', 'data-tip': 'Opzioni della traccia', onclick: () => select({ type: 'track', id: t.id }) }, t.name),
          ibtn(t.mute ? 'mute' : 'speaker', t.mute ? 'Riattiva la traccia' : 'Muta la traccia', () => { begin(); t.mute = !t.mute; changed(); }, { color: t.mute ? '#FF7B72' : 'currentColor', size: 15 })),
        h('div', { class: 'mx-bot' }, r, val));
    });
    const hasSounds = soundTracks().some((t) => t.clips.length);
    B.append(fold('mx.tracks', 'Tracce audio', h('div', { class: 'gl mx' }, ...rows), { open: true, note: String(tracks.length) }),
      hasSounds ? fold('mx.duck', 'Musica', cToggle('Abbassa la musica quando parli', proj.settings.duck, (v) => { proj.settings.duck = v; }, 'Vale per i suoni con "Si abbassa quando parli"'),
        { note: proj.settings.duck ? 'Si abbassa' : null }) : null);
  }

  // nome del video: e' anche il nome del file esportato
  function nameField() {
    const inp = h('input', { class: 'input', value: proj.name, 'aria-label': 'Nome del video', maxlength: '120', style: { height: '32px', width: '100%' } });
    inp.addEventListener('change', () => { const v = inp.value.trim(); if (!v) { inp.value = proj.name; return; } begin(); proj.name = v; changed({ keepPanel: true }); document.title = v + ' · NoonFrame'; const cc = document.querySelector('.crumb-cur span[data-notr]'); if (cc) cc.textContent = v; });
    inp.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') inp.blur(); });
    return h('div', { class: 'ctl', 'data-tip': 'Il video esportato avrà questo nome' }, h('label', { class: 'lbl' }, 'Nome del video'), inp);
  }
  let acPlay = null;
  // salta al prossimo zoom / taglio dopo la testina (poi ricomincia dall'inizio)
  function jumpNext(kind) {
    const items = kind === 'zoom' ? proj.zooms.map((z) => z.a) : proj.segs.filter((c) => c.removed).map((c) => c.a);
    if (!items.length) return;
    items.sort((x, y) => x - y);
    const t = video.currentTime;
    const n = items.find((x) => x > t + 0.3);
    seek((n === undefined ? items[0] : n) + (kind === 'zoom' ? 0.6 : 0));
  }
  // formato del video finale: orizzontale o verticale (con cosa si vede nel verticale)
  const SUB_V = { size: 0.034, y: 0.74, maxChars: 22 }, SUB_H = { size: 0.055, y: 0.92, maxChars: 38 };
  function setFormat(v) {
    if (v === VERT) return;
    begin();
    const oldK = VERT ? 'subStyle_9x16' : 'subStyle_16x9', newK = v ? 'subStyle_9x16' : 'subStyle_16x9';
    const st = proj.subStyle;
    proj[oldK] = { size: st.size, y: st.y, maxChars: st.maxChars };
    proj.subStyle = { ...st, ...(proj[newK] || (v ? SUB_V : SUB_H)) };
    proj.format = v ? '9:16' : '16:9';
    VERT = v; lastSV = null;
    arrangeLayers(); applyViewMode(); subCur = null; applySubStyle();
    changed(); frame(true);
  }
  const LAYOUTS = [
    ['split', 'Diviso', 'Webcam e gioco: la webcam sopra, il gioco sotto'],
    ['fit', 'Intero', 'Tutto il video al centro, sopra lo stesso video sfocato'],
    ['game', 'Gioco', 'Solo il gioco, a tutto schermo'],
    ['cam', 'Webcam', 'Solo la webcam, a tutto schermo'],
    ['free', 'Libero', 'Tutto il video e la webcam da spostare e ingrandire come vuoi (trascinali nell\'anteprima)']];
  // impaginazione verticale di una clip: si cambia solo lei, finche' non la usi per tutte
  function layoutTiles(cur, onPick) {
    return h('div', { class: 'vlay' }, ...LAYOUTS.map(([k, name, tip]) => {
      const off = (k === 'split' || k === 'cam') && !cam;
      return h('button', { class: 'vlay-t' + (cur === k ? ' on' : ''), disabled: off ? true : null, 'data-tip': off ? 'Serve la webcam: impostala in Progetto, in Modifiche automatiche' : tip,
        onclick: () => onPick(k) }, h('i', { class: 'vlay-pic ' + k }, h('b'), h('b'), h('u')), h('span', null, name));
    }));
  }
  // orizzontale: la clip spostata e ingrandita a mano (si fa anche trascinandola nell'anteprima)
  function clipTfFold(c) {
    const tf = tfOf(c), on = !!c.tf;
    const upd = (patch) => { const t2 = { ...tfOf(c), ...patch }; c.tf = t2; if (Math.abs(t2.s - 1) < 1e-3 && Math.abs(t2.x) < 1e-3 && Math.abs(t2.y) < 1e-3) delete c.tf; tfKey = ''; frame(true); };
    return fold('c.tf', 'Posizione e zoom', [
      h('div', { class: 'pgroup' },
        numRow('Zoom', () => Math.round(tfOf(c).s * 100), (v) => upd({ s: v / 100 }), 5, 3000, 1, '%', 100),
        numRow('Orizzontale', () => Math.round(tfOf(c).x * 100), (v) => upd({ x: v / 100 }), -1000, 1000, 1, '%', 0),
        numRow('Verticale', () => Math.round(tfOf(c).y * 100), (v) => upd({ y: v / 100 }), -1000, 1000, 1, '%', 0)),
      on ? h('button', { class: 'btn sm ghost', style: { marginTop: '8px' }, onclick: () => { begin(); delete c.tf; tfKey = ''; changed(); frame(true); } }, 'Rimetti come prima') : null],
    { note: on ? Math.round(tf.s * 100) + '%' : null, tip: 'Trascina il video nell\'anteprima per spostarlo, gli angoli (o la rotellina) per ingrandirlo' });
  }
  function clipLayoutFold(c) {
    const vs = segVert(0, c), own = !!c.vlay;
    const base = { layout: vs.layout, camH: vs.camH, gameX: vs.gameX, pad: vs.pad };
    const setC = (patch) => { begin(); c.vlay = { ...base, ...(c.vlay || {}), ...patch }; changed(); frame(true); };
    const rows = [];
    if (vs.layout === 'split') rows.push(numRow('Altezza webcam', () => Math.round(vs.camH * 100), (v) => { c.vlay = { layout: vs.layout, camH: v / 100, gameX: vs.gameX, ...(c.vlay || {}), camH: v / 100 }; frame(true); }, 20, 70, 1, '%', 40));
    if (vs.layout === 'split' || vs.layout === 'game') rows.push(numRow('Posizione gioco', () => Math.round(vs.gameX * 100), (v) => { c.vlay = { layout: vs.layout, camH: vs.camH, gameX: v / 100, ...(c.vlay || {}), gameX: v / 100 }; frame(true); }, 0, 100, 1, '%', 50));
    const others = proj.segs.filter((x) => x !== c && !x.gone).length;
    const allSame = () => {
      begin();
      proj.vert = { layout: vs.layout, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, ...(vs.boxes ? { boxes: vs.boxes } : {}) };
      proj.segs.forEach((x) => { delete x.vlay; });
      changed(); frame(true);
      toast('Tutte le clip ora sono così');
    };
    const name = (LAYOUTS.find(([k]) => k === vs.layout) || LAYOUTS[0])[1];
    const hasCam = (vs.layout === 'split' || vs.layout === 'cam' || vs.layout === 'free') && cam;
    const setPad = (v) => { c.vlay = { ...base, ...(c.vlay || {}), pad: v }; frame(true); };
    const frag = document.createDocumentFragment();
    // 1) come e' impaginata la clip
    frag.append(fold('c.vlay', 'Impaginazione', [
      layoutTiles(vs.layout, (k) => setC({ layout: k })),
      rows.length ? h('div', { class: 'pgroup' }, ...rows) : null,
      (others || own) ? h('div', { class: 'fold-acts' },
        h('span', { class: 'fa-l' }, own ? 'Solo questa clip' : 'Uguale alle altre clip'),
        own ? h('button', { class: 'btn sm ghost', onclick: () => { begin(); delete c.vlay; changed(); frame(true); } }, 'Come le altre') : null,
        others ? h('button', { class: 'btn sm', onclick: allSame, 'data-tip': 'Tutte le clip prendono questa impaginazione' }, icon('duplicate', 13), 'Usa per tutte') : null) : null],
    { open: true, note: name }));
    // 2) ritocchi: barre nere, viso, pezzi spostati a mano
    frag.append(fold('c.vopt', 'Ritocchi', [
      h('div', { class: 'pgroup' },
        cToggle('Barre nere sopra e sotto', vs.pad > 0, (v) => setPad(v ? 0.1 : 0), 'Webcam e gioco verso il centro: l\'interfaccia di TikTok e Reels non li copre'),
        vs.pad > 0 ? numRow('Spessore barre', () => Math.round(vs.pad * 100), (v) => setPad(v / 100), 3, 20, 1, '%', 10) : null),
      hasCam ? h('div', { class: 'pgroup' }, faceRow()) : null,
      vs.boxes ? h('div', { class: 'fold-acts' }, h('span', { class: 'fa-l' }, 'Pezzi spostati a mano'),
        h('button', { class: 'btn sm ghost', onclick: () => { begin(); c.vlay = { ...(c.vlay || {}) }; delete c.vlay.boxes; changed(); frame(true); } }, icon('restore', 13), 'Rimetti a posto')) : null],
    { open: true, note: [vs.pad > 0 ? 'Barre' : null, hasCam && proj.faceOn ? 'Viso' : null].filter(Boolean).join(' · ') || null,
      tip: 'Webcam e gioco si trascinano e si ingrandiscono anche direttamente nell\'anteprima' }));
    return frag;
  }
  function fmtLabel() {
    const r = W / H, near = (x) => Math.abs(r - x) < 0.02;
    return near(16 / 9) ? 'Orizzontale 16:9' : near(9 / 16) ? 'Verticale 9:16' : near(1) ? 'Quadrato 1:1' : near(4 / 5) ? 'Verticale 4:5' : W + '×' + H;
  }
  // ---------------------------------------------------------------- storia con immagini
  const STORY_COLORS = ['#FFFFFF', '#FFD166', '#8FD3FF', '#FFA8B8', '#B9F5A2'];
  function wrapLine(t, n) {
    const out = []; let cur = '';
    for (const w of String(t).split(/\s+/)) { if (cur && (cur + ' ' + w).length > n) { out.push(cur); cur = w; } else cur = cur ? cur + ' ' + w : w; }
    if (cur) out.push(cur);
    return out.join('\n');
  }
  function storyColor(sp) {
    const st = proj.story; st.colors = st.colors || {};
    if (!st.colors[sp]) st.colors[sp] = STORY_COLORS[Object.keys(st.colors).length % STORY_COLORS.length];
    return st.colors[sp];
  }
  function storyText(l) {
    return { ...TEXT_DEFAULT, content: wrapLine(l.text, W < H ? 20 : 34), size: W < H ? 0.04 : 0.055, font: 'Arial', bold: true,
      color: storyColor(l.speaker || ''), stroke: true, strokeColor: '#000000', strokeW: 0.1, shadow: true, box: false };
  }
  // la prima volta: immagini e testi sulla timeline, uno per battuta
  // storie montate con le versioni vecchie: chiude i buchi di pochi millesimi tra le scene (fotogramma nero)
  function fixStoryGaps() {
    let n = 0;
    for (const tr of ovTracks()) {
      const cs = tr.clips.filter((c) => !c.isText).sort((a, b) => a.a - b.a);
      for (let k = 0; k + 1 < cs.length; k++) {
        const gap = cs[k + 1].a - (cs[k].a + cs[k].dur);
        if (gap > 0 && gap < 0.02) { cs[k].dur = Math.ceil((cs[k + 1].a - cs[k].a) * 1000) / 1000; n++; }
      }
    }
    if (n) { changed(); }
  }
  function buildStory() {
    const st = proj.story;
    if (!st || !st.pending) return;
    const imgT = newTrack('overlay'); imgT.name = 'Immagini';
    const txtT = st.captions === 'word' ? null : newTrack('overlay'); if (txtT) txtT.name = 'Testi';
    // battute unite nella stessa clip: l'immagine/video della prima copre anche le successive
    const gEnd = st.lines.map((l, i) => { let j = i; while (j + 1 < st.lines.length && st.lines[j + 1].join) j++; return st.lines[j].b; });
    st.lines.forEach((l, i) => {
      // per eccesso: con l'arrotondamento per difetto restava un buco di qualche millesimo tra una scena e l'altra (un fotogramma nero)
      const dur = Math.ceil(Math.max(0.3, l.b - l.a) * 1000) / 1000;
      const vdur = l.join && i > 0 ? 0 : Math.ceil(Math.max(0.3, gEnd[i] - l.a) * 1000) / 1000;
      if (!vdur) l.imgId = st.lines[i - 1].imgId;   // stessa clip della battuta prima
      // scena con video AI: il video al posto dell'immagine (se il video e' piu' corto della frase, poi riprende l'immagine)
      let vUsed = 0;
      if (vdur && l.video && l.video.file) {
        const ar = l.video.ar || l.ar || 16 / 9, w = Math.max(1, 1 / (CA() * ar)), hf = w * CA() * ar;
        vUsed = Math.min(vdur, Math.floor((l.video.dur || vdur) * 1000) / 1000);
        const c = { id: uid('c'), kind: 'video', file: l.video.file, name: 'VIDEO ' + (i + 1), a: l.a, dur: vUsed, offset: 0, fileDur: l.video.dur || vUsed,
          pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, ar, opacity: 100, vol: 100, mute: true, hasAudio: false };
        imgT.clips.push(c); l.imgId = c.id;
      }
      if (vdur && l.file && vdur - vUsed > 0.02) {   // anche un attimo: meglio l'immagine che il nero
        const ar = l.ar || 16 / 9, w = Math.max(1, 1 / (CA() * ar)), hf = w * CA() * ar;
        const c = { id: uid('c'), kind: 'image', file: l.file, name: 'IMG ' + (i + 1), a: +(l.a + vUsed).toFixed(2), dur: +(vdur - vUsed).toFixed(2), ar, opacity: 100,
          pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, anim: vUsed ? undefined : { motion: l.motion || 'zoomIn' } };
        if (!c.anim) delete c.anim;
        imgT.clips.push(c); if (!l.imgId) l.imgId = c.id;
      }
      if (l.text && st.captions !== 'word') {
        const c = { id: uid('c'), kind: 'image', isText: true, text: storyText(l), name: '', file: '', a: l.a, dur, opacity: 100, anim: { in: 'pop', inDur: 0.25 } };
        const cv = drawText(c.text, H);
        c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
        const w = Math.min(c.natW, 0.9);
        c.pos = { w: +w.toFixed(5), x: +((1 - w) / 2).toFixed(5), y: +(0.72 - w * CA() * c.ar / 2).toFixed(5) };
        txtT.clips.push(c); l.txtId = c.id;
        refreshText(c);
      }
    });
    if (st.captions === 'word') {
      // didascalie parola per parola: i sottotitoli con le parole dello script, ai tempi della voce
      proj.transcript = { status: 'done', language: 'it', segments: st.lines.filter((l) => (l.words || []).length).map((l) => ({
        a: l.words[0][1], b: l.words[l.words.length - 1][2], words: l.words.map(([w, a, b]) => ({ w, a, b, del: false })) })) };
      proj.subStyle = { ...(proj.subStyle || {}), font: 'Arial', bold: true, upper: false, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.12,
        box: false, shadow: true, effect: 'pop', size: W < H ? 0.065 : 0.08, y: 0.72, maxChars: 1 };
      proj.settings.showSubs = true;
      proj.layers = ['subs', ...normLayers().filter((x) => x !== 'subs')];   // le parole sopra le immagini
      ver++;
    }
    // musica della pagina (Storie AI): sotto la voce, si abbassa quando si parla, ripetuta fino alla fine
    if (st.music && st.music.file && st.music.dur > 0.5) {
      const mt = newTrack('sound'); mt.name = 'Musica'; mt.vol = st.music.vol || 22;
      let t0 = 0;
      while (t0 < D - 0.05) {
        const d = +Math.min(st.music.dur, D - t0).toFixed(2);
        mt.clips.push({ id: uid('s'), file: st.music.file, name: st.music.name || 'Musica', a: +t0.toFixed(2), dur: d, offset: 0, fileDur: st.music.dur,
          vol: 100, mute: false, fin: t0 === 0, fout: t0 + d >= D - 0.05, duck: true });
        t0 += d;
      }
      proj.settings.duck = true;
    }
    st.pending = false;
    ltab = 'story';
    dirty = true; scheduleSave(); renderTimeline(); renderPanel(); frame(true);
  }
  const storyClip = (id) => { for (const t of ovTracks()) { const c = t.clips.find((x) => x.id === id); if (c) return c; } return null; };
  // tab Storia: una riga per battuta, movimento dell'immagine con un clic
  function renderStoryTab() {
    const st = proj.story;
    const t = video.currentTime;
    const list = h('div', { class: 'st-list' });
    st.lines.forEach((l, i) => {
      const ic = storyClip(l.imgId), tc = storyClip(l.txtId);
      const a = l.join ? (tc ? tc.a : l.a) : ic ? ic.a : tc ? tc.a : l.a, dur = l.join ? (tc ? tc.dur : l.b - l.a) : ic ? ic.dur : tc ? tc.dur : l.b - l.a;
      const mot = ic && ic.anim && ic.anim.motion;
      const motName = (MOTIONS.find(([k]) => k === mot) || [0, 'Fermo'])[1];
      const on = t >= a && t < a + dur;
      const row = h('div', { class: 'st-row' + (on ? ' on' : ''), onclick: () => { if (ic) select({ type: 'sclip', id: ic.id }); seek(a + 0.02); } },
        h('span', { class: 'st-n' }, String(i + 1)),
        ic ? h('img', { class: 'st-img', src: mediaUrl(ic.kind === 'video' ? (l.file || ic.file) : ic.file), alt: '', loading: 'lazy' }) : h('span', { class: 'st-img none' }, icon('upload', 16)),
        h('div', { class: 'st-tx' }, l.speaker ? h('b', { style: { color: storyColor(l.speaker) } }, l.speaker) : null, h('span', null, tc ? String(tc.text.content).replace(/\n/g, ' ') : l.text)),
        ic ? h('button', { class: 'st-mot', 'data-tip': 'Clic: cambia movimento', onclick: (e) => {
          e.stopPropagation(); begin();
          const ids = ['', ...MOTIONS.map(([k]) => k)], nx = ids[(ids.indexOf(mot || '') + 1) % ids.length];
          ic.anim = { ...(ic.anim || {}), motion: nx || undefined }; if (!nx) delete ic.anim.motion;
          if (!Object.keys(ic.anim).some((k) => ic.anim[k])) delete ic.anim;
          changed(); frame(true);
        } }, icon('sparkle', 11), motName) : null);
      list.append(row);
    });
    B.append(h('div', { class: 'vc-top' }, h('div', { class: 'vc-top-t' }, h('b', null, 'Battute'), h('span', null, String(st.lines.length))),
      h('button', { class: 'btn sm', 'data-tip': 'Movimenti diversi a ogni immagine', onclick: () => {
        begin(); let k = 0;
        st.lines.forEach((l) => { const ic = storyClip(l.imgId); if (ic) { ic.anim = { ...(ic.anim || {}), motion: MOTIONS[[0, 2, 1, 4, 3, 5][k % 6]][0] }; k++; } });
        changed(); frame(true);
      } }, icon('sparkle', 13), 'Mescola'),
      st.ai ? h('button', { class: 'btn sm', 'data-tip': 'Rimonta tutto dalla storia: scene, voce e sottotitoli di nuovo allineati al millesimo', onclick: () => rebuildStory(st.ai) }, icon('refresh', 13), 'Rimonta') : null), list);
  }
  // rimonta il video dalla storia (nuovo progetto): tempi delle scene ricalcolati sulla voce vera
  async function rebuildStory(sid) {
    if (!(await confirmBox('Rimontare il video?', 'Rifaccio il montaggio dalla storia: ogni scena parte esattamente quando inizia la sua frase, con voce e sottotitoli allineati. Le modifiche fatte a mano in questo editor (tagli, testi spostati) non vengono riportate. Immagini, video AI e voci restano gli stessi: non spendi niente.', 'Rimonta'))) return;
    try {
      try { await save(); } catch (e) { /* */ }
      const job = await post('/api/ai/story/build', { story: sid });
      toast('Rimonto il video…');
      const r = await pollJob(job.id, () => {});
      if (r.status !== 'done' || !r.result || !r.result.project) throw new Error(r.error || 'Non riuscito');
      ctx.nav('editor', r.result.project);
    } catch (e) { toast(e.message, true); }
  }
  // "Segui il viso": vale per tutta la clip verticale
  function faceRow() {
    const on = !!proj.faceOn;
    const wrap = h('div', { class: 'face-row' },
      cToggle('Segui il viso', on, (v) => {
        proj.faceOn = v; frame(true);
        if (v && !faceData) startFace();
        setTimeout(renderPanel, 0);
      }, 'Se ti sposti nella webcam, il ritaglio del verticale ti segue (senza mai uscire dal riquadro della webcam)'));
    if (on && faceJob) {
      const bar = h('div', { class: 'progress', style: { marginTop: '8px' } }, h('div')), st = h('div', { class: 'kfhint', style: { margin: '6px 0 0' } });
      const upd = () => { const p = Math.round(faceProg * 100); bar.firstChild.style.width = p + '%'; st.textContent = 'Cerco il viso nella webcam… ' + p + '%'; };
      upd(); wrap.append(bar, st);
      const tm = setInterval(() => { if (!faceJob || !st.isConnected) { clearInterval(tm); return; } upd(); }, 400);
    } else if (on && !faceData && faceErr) wrap.append(h('div', { class: 'kfhint warn', style: { margin: '6px 0 0' } }, faceErr),
      h('button', { class: 'btn sm', style: { marginTop: '6px' }, onclick: () => { startFace(); renderPanel(); } }, icon('restore', 13), 'Riprova'));
    else if (on && !faceData) wrap.append(h('button', { class: 'btn sm', style: { marginTop: '6px' }, onclick: () => { startFace(); renderPanel(); } }, icon('sparkle', 13), 'Analizza il viso'));
    return wrap;
  }
  function formatFold() {
    // il formato si sceglie quando nasce il progetto e poi resta quello
    const body = [h('div', { class: 'fmt-ro' }, h('span', { class: 'fmt-ic' + (VERT ? ' v' : '') }), h('div', null, h('b', null, VERT ? 'Verticale 9:16' : 'Orizzontale 16:9'), h('small', null, 'Il formato resta quello con cui hai iniziato il progetto.')))];
    return fold('p.format', 'Formato', body, { note: VERT ? '9:16' : '16:9' });
  }
  function renderProject() {
    const S = proj.settings;
    const set = (k) => (v) => { S[k] = v; };
    const nz = proj.zooms.length, nc = proj.segs.filter((c) => c.removed).length;
    const hasSounds = soundTracks().some((t) => t.clips.length);
    // tre qualita' a partire da quella del VOD, mai sopra
    const steps = [2160, 1440, 1080, 720, 480, 360, 240];
    const top = steps.find((s) => s <= Math.min(W, H) + 8) || Math.min(W, H);
    const qOpts = steps.filter((s) => s <= top).slice(0, 3).map((s) => ({ value: s + 'p', label: s === 2160 ? '4K' : s + 'p' }));
    // solo le scelte che cambiano davvero qualcosa per questo video (su un video 720p "720p" e "Originale" sono uguali)
    const PQ = [['auto', 'Auto'], ['orig', 'Originale'], ...(H > 760 ? [['720', '720p']] : []), ...(H > 520 ? [['480', '480p']] : [])];
    if (!PQ.some((x) => x[0] === (S.previewQ || 'auto'))) S.previewQ = 'auto';
    if (!qOpts.some((q) => q.value === S.quality)) S.quality = qOpts[0].value;
    // totale a vista: senza i pezzi nascosti (la live rimasta in fondo dopo aver spostato le clip non conta)
    const hidT = proj.segs.filter((c) => c.gone).reduce((s2, c) => s2 + (c.b - c.a), 0);
    const outD = outDuration(), totD = Math.max(outD, D - hidT), gone = totD - outD;
    const fmtGone = (x) => x < 60 ? Math.round(x) + ' s' : fmt(x);
    // mappa di tutto il VOD: pezzi tenuti, pezzi tolti, zoom (clic = vai li')
    acPlay = h('i', { class: 'ac-play' });
    const map = h('div', { class: 'ac-map', 'data-tip': 'Tutto il video: gli spazi sono le parti tolte, in giallo gli zoom · clic per andarci' },
      ...removed().map(([ra, rb]) => h('span', { class: 'rm', style: { left: ra / D * 100 + '%', width: Math.max(0.3, (Math.min(D, rb) - ra) / D * 100) + '%' } })),
      ...proj.zooms.map((z) => h('span', { class: 'zm', style: { left: z.a / D * 100 + '%', width: Math.max(0.4, (z.b - z.a) / D * 100) + '%', background: z.kind === 'custom' ? '#A9C7FF' : '' } })),
      acPlay);
    map.addEventListener('pointerdown', (e) => { const r = map.getBoundingClientRect(); seek((e.clientX - r.left) / r.width * D); });
    const row = (label, n, tip, kind) => h('button', { class: 'gl-row', 'data-tip': n ? tip : null, disabled: n ? null : true, onclick: () => jumpNext(kind) },
      h('span', { class: 'gl-l' }, label), h('span', { class: 'gl-v' }, String(n)), icon('chev', 12, 'currentColor', 2.2));
    [
      head('Progetto', VERT ? 'Verticale 9:16' : fmtLabel()),
      nameField(),
      !IS_VOD ? null : fold('p.auto', 'Modifiche automatiche', h('div', { class: 'gl' },
          h('div', { class: 'gl-hero' },
            h('div', { class: 'gl-dur' },
              h('span', { class: 'gl-big' }, fmt(outD)),
              h('span', { class: 'gl-of' }, 'di ' + fmt(totD)),
              gone > 0.5 ? h('span', { class: 'gl-gone' }, '−' + fmtGone(gone)) : null),
            map),
          row('Zoom', nz, 'Vai al prossimo zoom', 'zoom'),
          row('Tagli', nc, 'Vai al prossimo taglio', 'cut')), { open: true, right: h('div', { class: 'row', style: { gap: '0' } },
          ibtn('webcam', cam ? 'Cambia il riquadro della webcam' : 'Imposta la webcam', async () => { video.pause(); await flush(); ctx.nav('webcam', pid); }, { size: 14 }),
          ibtn('restore', 'Rifai zoom e tagli con un altro stile', async () => {
            if (await confirmBox('Rifare l\'analisi?', 'Zoom e tagli automatici vengono ricalcolati con lo stile che scegli. Le tue modifiche a zoom e tagli automatici si perdono.', 'Scegli stile')) {
              video.pause(); await flush(); ctx.nav('style', pid);
            }
          }, { size: 14 })) }),
      fold('p.q', 'Qualità dell\'anteprima', [cSeg(null, PQ.map((x) => x[1]), Math.max(0, PQ.findIndex((x) => x[0] === (S.previewQ || 'auto'))), (i) => {
          S.previewQ = PQ[i][0]; dirty = true; scheduleSave(); renderPanel();
          const pq = S.previewQ, q = pq === 'orig' ? H : pq === 'auto' ? (H > 760 ? 720 : H) : Math.min(H, +pq);
          toast(q >= H - 8 && pq !== 'auto' ? 'Anteprima alla qualità originale' : 'Anteprima a ' + q + 'p: se non è pronta la preparo, intanto resta quella di prima');
          setTimeout(applyQuality, 0);
        }),
        ],
        { note: (PQ.find((x) => x[0] === (S.previewQ || 'auto')) || PQ[0])[1], tip: 'Solo per lavorare più fluido: il video finale resta alla qualità scelta in Esporta' }),
      IS_V ? null : fold('p.share', 'Passa ad un altro PC', [
        h('button', { class: 'btn sm', onclick: () => saveProjectFile() }, icon('download', 13), 'Salva come file .vodcut')], { tip: 'Un file .vodcut con tagli, zoom, testi ed effetti. Il video va copiato a parte sull\'altro PC.' }),
    ].filter(Boolean).forEach((x) => curBody.append(x));
  }
  // progetto in un file .vodcut, da aprire su un altro PC
  async function saveProjectFile() {
    if (IS_V) return toast('Per passare il progetto a un altro PC, torna al video orizzontale');
    try { await flush(); } catch (e) { /* */ } ctx.saveProject(pid, proj.name);
  }


  // --- testo
  let trJob = null, trPoll = null;
  let wordEls = [];      // [si][wi] -> span
  let segEls = [];
  function renderTranscript(target = panelBody) {
    const B = { append: (...a) => target.append(...a.filter((x) => x != null && x !== false)) };
    const tr = proj.transcript || { status: 'none' };
    wordEls = []; segEls = [];
    if (tr.status === 'running') {
      const bar = h('div', { class: 'progress' }, h('div', { style: { width: '0%' } }));
      const msg = h('p', null, 'Sto trascrivendo il video…');
      B.append(h('div', { class: 'empty' }, h('div', { class: 'row' }, h('div', { class: 'spinner' }), h('strong', null, 'Trascrizione in corso')), msg, bar,
        h('p', { class: 'xs' }, 'Intanto puoi lavorare su zoom e tagli. La prima volta scarica il modello (circa 1 GB).')));
      watchTranscript(bar, msg);
      return;
    }
    if (tr.status !== 'done') {
      const can = env.whisper;
      B.append(h('div', { class: 'empty' },
        h('strong', null, 'Taglia il video cancellando il testo'),
        h('p', null, 'Trascriviamo tutto quello che dici. Poi togli una parola o una frase e sparisce anche dal video. I sottotitoli restano spenti: li accendi quando vuoi.'),
        tr.status === 'error' ? h('p', { style: { color: 'var(--danger)' } }, 'L\'ultima trascrizione non è riuscita: ' + (tr.error || '')) : null,
        can ? h('button', { class: 'btn sm primary', style: { alignSelf: 'flex-start' }, onclick: () => startTranscribe(false) }, 'Trascrivi il video')
          : h('p', { class: 'xs' }, 'La trascrizione non è installata su questo PC: esegui di nuovo INSTALLA.bat e riapri NoonFrame.'),
        h('button', { class: 'linkish scr-link', onclick: scriptBox }, icon('text', 12), proj.script ? 'Script aggiunto: modificalo' : 'Hai lo script? Incollalo prima (nomi scritti giusti)')));
      return;
    }
    const segs = allWords();
    if (!segs.length) { B.append(h('div', { class: 'empty' }, h('p', null, 'Nella trascrizione non ci sono parole.'))); return; }
    B.append(h('div', { class: 'xs', style: { lineHeight: '1.45' } }, 'Clic su una parola per andarci, doppio clic per correggerla. Tieni premuto (o tasto destro) per tagliarla o metterci il bip. Trascina per scegliere più parole.'),
      h('button', { class: 'linkish scr-link', 'data-tip': 'Nomi e termini scritti giusti in tutti i sottotitoli', onclick: scriptBox }, icon('text', 12), proj.script ? 'Correggi con il tuo script' : 'Hai lo script? Correggi le parole'));
    const box = h('div', { class: 'transcript mode-cut' });
    const autoCuts = proj.segs.filter((c) => c.auto).slice().sort((a, b) => a.a - b.a);
    let ci = 0;
    segs.forEach((s, si) => {
      while (ci < autoCuts.length && autoCuts[ci].a < s.a) { box.append(pauseChip(autoCuts[ci])); ci++; }
      const ws = h('div', { class: 'ws' });
      const row = [];
      s.words.forEach((w, wi) => {
        const sp = h('span', { class: 'w' + (w.del ? ' del' : '') + (w.cens ? ' cens' : '') + (w.ed ? ' ed' : ''), 'data-si': si, 'data-wi': wi }, w.w);
        row.push(sp); ws.append(sp, ' ');
      });
      wordEls.push(row);
      const segEl = h('div', { class: 'tseg' }, h('button', { class: 'ts', onclick: () => seek(s.a) }, fmt(s.a)), ws);
      segEls.push(segEl);
      box.append(segEl);
    });
    while (ci < autoCuts.length) { box.append(pauseChip(autoCuts[ci])); ci++; }
    // clic: la testina va sulla parola. Tieni premuto / tasto destro: cosa fare con la parola.
    // Trascina: selezioni piu' parole e poi scegli cosa farci.
    const wAt = (sp) => allWords()[+sp.dataset.si].words[+sp.dataset.wi];
    const spans = () => [...box.querySelectorAll('.w')];
    let press = null, lastTap = null;
    const clearSel = () => box.querySelectorAll('.w.rsel').forEach((x) => x.classList.remove('rsel'));
    const rangeOf = (a, b) => { const all = spans(), i = all.indexOf(a), j = all.indexOf(b); return all.slice(Math.min(i, j), Math.max(i, j) + 1); };
    function wordMenu(list, x, y) {
      const ws = list.map(wAt), one = ws.length === 1;
      const allDel = ws.every((w) => w.del), allCens = ws.every((w) => w.cens), allHid = ws.every((w) => w.nosub);
      const setAll = (k, v) => { begin(); ws.forEach((w) => { w[k] = v || undefined; }); ver++; clearSel(); changed({ keepPanel: false }); };
      const n = one ? '' : ` (${ws.length} parole)`;
      popMenuAt(x, y, [
        ['play', 'Riproduci da qui', null, () => { clearSel(); seek(ws[0].a); video.play().catch(() => {}); }],
        [allDel ? 'restore' : 'scissors', (allDel ? 'Rimetti nel video' : 'Taglia dal video') + n, allDel ? null : 'Sparisce anche dall\'audio e dal video', () => setAll('del', !allDel)],
        ['beep', (allCens ? 'Togli il bip' : 'Metti il bip') + n, allCens ? null : 'Nei sottotitoli diventa c****', () => setAll('cens', !allCens)],
        [allHid ? 'eye' : 'eyeOff', (allHid ? 'Mostra nei sottotitoli' : 'Nascondi nei sottotitoli') + n, 'L\'audio resta', () => setAll('nosub', !allHid)],
        ...(one ? [['type', 'Correggi il testo', null, () => { clearSel(); seekQuiet(ws[0].a + 0.01); editWord(list[0]); }]] : []),
      ]);
    }
    box.addEventListener('pointerdown', (e) => {
      const sp = e.target.closest('.w'); if (!sp || sp.querySelector('input') || e.button !== 0) return;
      e.preventDefault();
      clearSel();
      press = { sp, last: sp, x: e.clientX, y: e.clientY, range: false, menu: false };
      press.timer = setTimeout(() => { if (press && !press.range) { press.menu = true; sp.classList.add('rsel'); wordMenu([sp], press.x, press.y); } }, 450);
      capPtr(box, e.pointerId);
    });
    box.addEventListener('pointermove', (e) => {
      if (!press || press.menu) return;
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const sp = el && el.closest && el.closest('.w');
      if (!sp || sp === press.last) return;
      press.last = sp; press.range = true; clearTimeout(press.timer);
      clearSel(); rangeOf(press.sp, sp).forEach((x) => x.classList.add('rsel'));
    });
    box.addEventListener('pointerup', (e) => {
      if (!press) return;
      const p0 = press; press = null; clearTimeout(p0.timer);
      if (p0.menu) return;
      if (p0.range) { wordMenu(rangeOf(p0.sp, p0.last), e.clientX, e.clientY); return; }
      // doppio clic: correggi la parola al volo
      const now = performance.now();
      if (lastTap && lastTap.sp === p0.sp && now - lastTap.t < 380) { lastTap = null; editWord(p0.sp); return; }
      lastTap = { sp: p0.sp, t: now };
      // clic semplice: esattamente all'inizio della parola
      const w = wAt(p0.sp);
      seek(w.a);
    });
    box.addEventListener('contextmenu', (e) => {
      const sp = e.target.closest('.w'); if (!sp) return;
      e.preventDefault();
      const cur = [...box.querySelectorAll('.w.rsel')];
      if (cur.includes(sp)) wordMenu(cur, e.clientX, e.clientY);
      else { clearSel(); sp.classList.add('rsel'); wordMenu([sp], e.clientX, e.clientY); }
    });
    B.append(box);
  }
  // correggere una parola sbagliata della trascrizione (cambia anche nei sottotitoli)
  let trMode = 'cut';
  function editWord(sp) {
    const w = allWords()[+sp.dataset.si].words[+sp.dataset.wi];
    const inp = h('input', { class: 'wedit', value: w.w, spellcheck: 'false', 'aria-label': 'Correggi la parola' });
    inp.style.width = Math.max(3, w.w.length + 1) + 'ch';
    sp.replaceChildren(inp); inp.focus(); inp.select();
    let done = false;
    const finish = (save, next) => {
      if (done) return; done = true;
      const v = inp.value.replace(/\s+/g, ' ').trim();
      if (save && v && v !== w.w) { begin(); if (w.orig === undefined) w.orig = w.w; w.w = v; w.ed = true; sp.classList.add('ed'); ver++; dirty = true; scheduleSave(); renderTimeline(); }
      sp.replaceChildren(w.w);
      if (next) {
        const all = [...panelBody.querySelectorAll('.transcript .w')];
        const n = all[all.indexOf(sp) + (next > 0 ? 1 : -1)];
        if (n) { const nw = allWords()[+n.dataset.si].words[+n.dataset.wi]; seekQuiet(nw.a + 0.01); editWord(n); }
      }
    };
    inp.addEventListener('input', () => { inp.style.width = Math.max(3, inp.value.length + 1) + 'ch'; });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
      else if (e.key === 'Tab') { e.preventDefault(); finish(true, e.shiftKey ? -1 : 1); }
    });
    inp.addEventListener('blur', () => finish(true));
  }
  function pauseChip(c) {
    const on = !!c.removed;
    return h('button', { class: 'pausechip' + (on ? ' cut' : ''), 'aria-pressed': String(on), 'data-tip': on ? 'Clic per rimettere questa pausa' : 'Clic per tagliarla di nuovo',
      onclick: () => { begin(); c.removed = !on; changed({ keepPanel: false }); } }, `··· pausa ${(c.b - c.a).toFixed(1).replace('.', ',')} s` + (on ? ' (tagliata)' : ''));
  }
  function renderTranscriptFlags() {
    if (tab !== 'text') return;
    allWords().forEach((s, si) => s.words.forEach((w, wi) => { const el = wordEls[si] && wordEls[si][wi]; if (el) { el.classList.toggle('del', !!w.del); el.classList.toggle('cens', !!w.cens); } }));
  }
  function scrollToWord(si, wi) {
    const el = wordEls[si] && wordEls[si][wi];
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  // stato dei sottotitoli quando non ci sono ancora: in preparazione (con %) o da creare
  let trProg = { p: 0, msg: '' };
  const trStatus = () => (proj.transcript && proj.transcript.status) || 'none';
  function subsStatus(where) {
    const st = trStatus();
    if (st === 'running') {
      const pct = Math.round(trProg.p * 100);
      if (where === 'lane') return h('div', { class: 'lane-hint subs-prog' }, h('div', { class: 'spinner' }), h('span', { class: 'trp-txt' }, (proj.settings.showSubs ? 'Creo i sottotitoli' : 'Trascrizione') + (pct ? ' · ' + pct + '%' : '…')));
      // la trascrizione e' una sola: l'avanzamento si vede in Trascrizione, qui basta una riga
      return h('div', { class: 'substat' }, h('div', { class: 'row', style: { gap: '8px' } }, h('div', { class: 'spinner' }),
        h('span', { class: 'xs trp-txt' }, (proj.settings.showSubs ? 'Pronti quando finisce la trascrizione' : 'Trascrizione in corso: poi puoi accendere i sottotitoli') + (pct ? ' · ' + pct + '%' : ''))));
    }
    if (!env.whisper) {
      const msg = 'Per i sottotitoli serve la trascrizione: esegui di nuovo INSTALLA.bat e riapri NoonFrame.';
      return where === 'lane' ? h('div', { class: 'lane-hint' }, 'Sottotitoli non disponibili') : h('div', { class: 'substat' }, h('span', { class: 'xs' }, msg));
    }
    const err = st === 'error' ? 'L\'ultima volta non è riuscita' + (proj.transcript.error ? ': ' + proj.transcript.error : '') + '. ' : '';
    if (where === 'lane') {
      const b = h('button', { class: 'lane-cta', onclick: (e) => { e.stopPropagation(); startTranscribe(true); } }, icon('plus', 12, 'currentColor', 2.4), err ? 'Riprova a creare i sottotitoli' : 'Crea i sottotitoli');
      b.addEventListener('pointerdown', (e) => e.stopPropagation());
      return b;
    }
    return h('div', { class: 'substat' }, h('span', { class: 'xs' }, err + 'Trascriviamo quello che dici e lo trasformiamo in sottotitoli, che poi puoi personalizzare.'),
      h('button', { class: 'btn sm primary', style: { alignSelf: 'flex-start' }, onclick: () => startTranscribe(true) }, icon('cc', 14, '#fff'), 'Crea i sottotitoli'));
  }
  function paintTrProgress() {
    const pct = Math.round(trProg.p * 100);
    document.querySelectorAll('.trp-bar').forEach((b) => { b.style.width = pct + '%'; });
    document.querySelectorAll('.lane.subs .trp-txt').forEach((t) => { t.textContent = (proj.settings.showSubs ? 'Creo i sottotitoli' : 'Trascrizione') + (pct ? ' · ' + pct + '%' : '…'); });
    document.querySelectorAll('.substat .trp-txt').forEach((t) => { t.textContent = (proj.settings.showSubs ? 'Pronti quando finisce la trascrizione' : 'Trascrizione in corso: poi puoi accendere i sottotitoli') + (pct ? ' · ' + pct + '%' : ''); });
  }
  // sottotitoli di un pezzo solo (tasto destro su una clip): si trascrive quel pezzo e basta
  let subRangeJob = null;
  async function regenSubs(segs) {
    const rs = segs.map((x) => [x.a, x.b]).sort((p, q) => p[0] - q[0]);
    const merged = [];
    for (const [a, b] of rs) { const l = merged[merged.length - 1]; if (l && a <= l[1] + 0.05) l[1] = Math.max(l[1], b); else merged.push([a, b]); }
    const pill = h('div', { class: 'jobpill' }, h('div', { class: 'spinner' }), h('span', null, 'Creo i sottotitoli di questa clip…'));
    document.body.append(pill);
    subRangeJob = true;
    let words = 0, fail = '';
    try {
      await flush();
      for (const [a, b] of merged) {
        const job = await post(`/api/p/${pid}/transcriberange`, { a, b });
        const res = await pollJob(job.id, (j) => { pill.lastChild.textContent = 'Creo i sottotitoli di questa clip' + (j.progress > 0.01 ? ' · ' + Math.round(j.progress * 100) + '%' : '…'); });
        if (res.status !== 'done') { fail = res.error || 'annullata'; break; }
        words += (res.result && res.result.words) || 0;
      }
    } catch (e) { fail = e.message; }
    subRangeJob = null; pill.remove();
    if (!alive) return;
    const p2 = await get('/api/p/' + pid);
    if (p2.transcript && p2.transcript.status === 'done') proj.transcript = p2.transcript;
    if (!proj.settings.showSubs && !fail && words) { proj.settings.showSubs = true; dirty = true; scheduleSave(); }
    ver++; renderPanel(); renderTimeline(); frame(true);
    if (fail) toast('Sottotitoli non riusciti: ' + fail, true);
    else toast(words ? 'Sottotitoli pronti per questa clip' : 'Nessuna parola trovata in questa clip');
  }
  // subs: accende anche i sottotitoli (se no si trascrive soltanto, per tagliare dal testo)
  // lo script del video: la trascrizione scrive nomi e termini come li hai scritti tu ("Claude", non "Cloud")
  function scriptBox() {
    const has = allWords().length > 0;
    const bg = h('div', { class: 'modal-bg' });
    const ta = h('textarea', { class: 'input scr-ta', rows: 10, placeholder: 'Incolla qui quello che dici nel video (anche solo in parte)…', 'aria-label': 'Script del video' });
    ta.value = proj.script || '';
    const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); };
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onKey, true);
    const save = async () => {
      try {
        const r = await post(`/api/p/${pid}/scriptfix`, { script: ta.value });
        proj.script = ta.value;
        if (has && r.transcript) {
          proj.transcript = r.transcript; ver++; renderPanel(); renderTimeline(); frame(true);
          toast(r.fixed ? r.fixed + (r.fixed === 1 ? ' parola corretta' : ' parole corrette') + ' con lo script' : 'Le parole erano già giuste');
        } else toast('Script salvato: lo uso nella trascrizione');
        close();
      } catch (e) { toast(e.message, true); }
    };
    bg.append(h('div', { class: 'modal scr-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Script del video' },
      h('h2', null, 'Script del video'),
      h('p', null, has ? 'Le parole dei sottotitoli prendono la grafia dello script: nomi, marchi e termini tecnici giusti. Tempi e tagli restano come sono; dove hai detto altro resta quello che hai detto.'
        : 'Lo uso durante la trascrizione: nomi, marchi e termini tecnici vengono scritti come li hai scritti tu.'),
      ta,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '14px', gap: '8px' } },
        h('button', { class: 'btn ghost', onclick: close }, 'Annulla'),
        h('button', { class: 'btn primary', onclick: save }, has ? 'Correggi i sottotitoli' : 'Salva lo script'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg); ta.focus();
  }
  async function startTranscribe(subs, ai) {
    try {
      if (subs !== undefined) { proj.settings.showSubs = !!subs; dirty = true; scheduleSave(); }
      if (ai && allWords().length && !(await confirmBox('Rifare la trascrizione con l\'AI?', 'Le parole vengono riscritte in modo più preciso. I tagli che hai già fatto restano.', 'Rifai con l\'AI'))) return;
      trJob = await post(`/api/p/${pid}/transcribe`, { ai: !!ai });
      proj.transcript = { status: 'running', segments: [] };
      trProg = { p: 0, msg: '' };
      renderPanel(); renderTimeline();
      watchTranscript();
    } catch (e) { toast(e.message, true); }
  }
  async function watchTranscript(bar, msg) {
    if (trPoll) return;
    if (!trJob) { const jobs = await get('/api/jobs'); trJob = jobs.find((j) => j.pid === pid && j.kind === 'transcribe'); }
    if (!trJob) {
      // job non piu' in corso: ricarica lo stato dal server
      const p2 = await get('/api/p/' + pid);
      proj.transcript = p2.transcript.status === 'running' ? { status: 'error', error: 'interrotta', segments: [] } : p2.transcript;
      renderPanel(); return;
    }
    trPoll = true;
    const res = await pollJob(trJob.id, (j) => {
      if (!alive) return;
      trProg = { p: j.progress || 0, msg: j.message || '' }; paintTrProgress();
      const b = panelBody.querySelector('.progress > div'); if (b) b.style.width = (j.progress * 100).toFixed(1) + '%';
      const m = panelBody.querySelector('.empty p'); if (m && j.message) m.textContent = j.message + (j.progress > 0.01 ? ' · ' + Math.round(j.progress * 100) + '%' : '');
    });
    trPoll = null; trJob = null;
    if (!alive) return;
    const p2 = await get('/api/p/' + pid);
    proj.transcript = res.status === 'done' ? p2.transcript : { status: 'error', error: res.error || 'annullata', segments: [] };
    if (res.status === 'done') toast((proj.settings.showSubs ? 'Sottotitoli pronti: ' : 'Trascrizione pronta: ') + allWords().length + ' frasi.');
    else if (res.status === 'error') toast('Trascrizione non riuscita: ' + (res.error || ''), true);
    ver++; renderPanel(); renderTimeline();
  }

  // ---------------------------------------------------------------- riproduzione
  const sounds = new Map(); // clipId -> Audio
  function soundEl(c) {
    let a = sounds.get(c.id);
    if (!a || a.dataset.file !== c.file) { a = new Audio(mediaUrl(c.file)); a.preload = 'auto'; a.dataset.file = c.file; sounds.set(c.id, a); }
    return a;
  }
  // uscita audio sempre sveglia mentre l'editor e' aperto: sul Mac (soprattutto con cuffie bluetooth) il
  // dispositivo audio si addormenta e al play ci mette qualche fotogramma a ripartire. CapCut lo tiene aperto.
  let warmCtx = null;
  function warmAudio() {
    try {
      if (!warmCtx) {
        warmCtx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'interactive' });
        const src = warmCtx.createConstantSource ? warmCtx.createConstantSource() : warmCtx.createOscillator();
        const g = warmCtx.createGain(); g.gain.value = 0;
        src.connect(g).connect(warmCtx.destination); src.start();
      }
      if (warmCtx.state === 'suspended') warmCtx.resume().catch(() => {});
    } catch (e) { /* audio non disponibile */ }
  }
  // quanto ci mette davvero a partire (finisce nel log: serve per misurare il ritardo al play sul Mac)
  let playLogs = 0;
  function logPlayLatency() {
    if (playLogs >= 6) return;
    playLogs++;
    const el = video.el, t0 = performance.now(), c0 = el.currentTime;
    let first = null;
    const chk = () => {
      const dt = performance.now() - t0;
      if (first === null && el.currentTime > c0 + 0.001) first = Math.round(dt);
      if (first !== null || dt > 2000) { clog('play: il video avanza dopo ' + (first ?? 'oltre 2000') + ' ms (readyState ' + el.readyState + ', ' + (VERT ? 'verticale' : 'orizzontale') + ')'); return; }
      requestAnimationFrame(chk);
    };
    requestAnimationFrame(chk);
  }
  // in verticale l'anteprima e' disegnata su canvas: si ridisegna appena il video mostra un fotogramma nuovo,
  // senza aspettare il giro successivo dell'animazione (un fotogramma di ritardo in meno)
  function vfcChain() {
    const el = video.el;
    if (!VERT || !el || !el.requestVideoFrameCallback || el.__nfVfc) return;
    el.__nfVfc = true;
    const cb = () => {
      if (!alive || video.paused || video.el !== el) { el.__nfVfc = false; return; }
      if (!sourceView()) drawVertical(video.currentTime);
      el.requestVideoFrameCallback(cb);
    };
    el.requestVideoFrameCallback(cb);
  }
  function togglePlay() {
    if (!videoReady) return;
    if (revSpeed) { stopReverse(); return; }
    if (video.paused) {
      // alla fine: riparte dall'inizio (come un video in loop su TikTok, per vedere se l'inizio "attacca")
      const endT = BLANK ? contentEnd() : lastKept();
      if (video.currentTime >= endT - 0.08) seek(visT(0));
    }
    if (video.paused) {
      playBtn.replaceChildren(icon('pause', 15, '#0B0E13'));
      warmAudio(); logPlayLatency();
      setTimeout(vfcChain, 0);
      video.play().catch((e) => { playBtn.replaceChildren(icon('play', 15, '#0B0E13')); if (e.name !== 'AbortError') toast('Non riesco a riprodurre: ' + e.message, true); });
    } else { video.pause(); playBtn.replaceChildren(icon('play', 15, '#0B0E13')); }
  }
  video.addEventListener('canplay', onReady);
  // diagnostica caricamento video (finisce in vodcut.log)
  const tLoad = performance.now();
  const clog = (m) => post('/api/clientlog', { msg: m + ' dopo ' + Math.round(performance.now() - tLoad) + ' ms' }).catch(() => {});
  ['loadstart', 'loadedmetadata', 'loadeddata', 'canplay', 'stalled', 'waiting', 'suspend'].forEach((ev) => video.addEventListener(ev, () => clog('video ' + ev + ' readyState=' + video.readyState), { once: ev !== 'stalled' && ev !== 'waiting' }));
  video.addEventListener('error', () => clog('video ERRORE ' + (video.error && (video.error.code + ' ' + video.error.message))));
  video.addEventListener('loadeddata', onReady);
  setTimeout(() => { if (!videoReady && video.readyState >= 2) onReady(); if (!strip) loadStrip(); }, 4000);
  video.addEventListener('play', () => { playBtn.replaceChildren(icon('pause', 15, '#0B0E13')); playBtn.setAttribute('aria-label', 'Pausa'); });
  video.addEventListener('pause', () => { playBtn.replaceChildren(icon('play', 15, '#0B0E13')); playBtn.setAttribute('aria-label', 'Riproduci'); sounds.forEach((a) => a.pause()); ovImgs.forEach((el) => { if (el.tagName === 'VIDEO') el.pause(); }); });
  video.addEventListener('error', () => {
    // il browser non legge questo video: passa da solo alla copia compatibile (nessun messaggio d'errore)
    if (curSrc === 'orig' && !compat) { compat = true; curSrc = ''; loadingTxt.textContent = 'Preparo l\'anteprima…'; applyQuality(); return; }
    // la copia per l'anteprima non si legge (es. creata da una versione vecchia): la rifaccio una volta, da sola
    if (curSrc && curSrc !== 'orig' && !proxyRebuilt) {
      proxyRebuilt = true; proxyRebuild = true; curSrc = '';
      clog('anteprima illeggibile: la rifaccio');
      if (!videoReady) loadingTxt.textContent = 'Rifaccio l\'anteprima…';
      applyQuality(); return;
    }
    if (curSrc && curSrc !== 'orig') toast('Non riesco a mostrare l\'anteprima di questo video, ma l\'esportazione funziona lo stesso.', true);
  });
  // mai fermarsi dentro una parte eliminata dalla timeline: si va al primo fotogramma dopo (o all'ultimo prima, se e' la fine)
  function visT(t) {
    t = Math.max(0, Math.min(D - 0.05, t));
    for (const [a, b] of goneR) if (t >= a && t < b) return b < D - 0.05 ? b : Math.max(0, a - 0.04);
    return t;
  }
  // ultimo istante che resta davvero nel video (le parti tolte alla fine non contano)
  function lastKept() {
    let end = D;
    for (const [a, b] of [...remCache].sort((x, y) => y[0] - x[0])) if (b >= end - 0.05 && a < end) end = a;
    return Math.max(0.05, end);
  }
  function seek(t) { video.currentTime = visT(t); frame(true); ensureVisible(video.currentTime); }
  // prova al volo: scelto un effetto, lo si vede subito sul video (parte un attimo prima e si ferma da solo dopo)
  let tryTimer = 0;
  function previewSpan(a, b) {
    if (!videoReady) return;
    clearInterval(tryTimer);
    a = Math.max(0, a); b = Math.min(D, Math.max(a + 0.4, b));
    if (!video.paused) togglePlay();
    seek(a);
    togglePlay();
    tryTimer = setInterval(() => {
      if (video.paused) { clearInterval(tryTimer); return; }   // fermato a mano: niente altro
      if (video.currentTime >= b || video.currentTime < a - 1) { clearInterval(tryTimer); togglePlay(); }
    }, 40);
  }
  function seekQuiet(t) { video.currentTime = visT(t); }
  function ensureVisible(t) {
    const x = X(t), l = scroller.scrollLeft, w = scroller.clientWidth;
    if (x < l + 20 || x > l + w - 20) scroller.scrollLeft = x - w * 0.3;
  }

  let lastSeg = -1, lastWord = null, raf = 0, lastRem = null, remCache = [], outTot = 0, hopKey = null, hopList = [];
  function hopRanges() {
    if (hopKey === remCache) return hopList;
    hopKey = remCache;
    hopList = [];
    for (const [a, b] of [...remCache].sort((x, y) => x[0] - y[0])) {
      const l = hopList[hopList.length - 1];
      if (l && a <= l[1] + 0.08) l[1] = Math.max(l[1], b); else hopList.push([a, b]);
    }
    return hopList;
  }
  function frame(force) {
    video.tick();
    const t = video.currentTime;
    if (force || !lastRem || Date.now() - lastRem > 400) { remCache = removed(); lastRem = Date.now(); outTot = outDuration(); }
    // salta le parti tagliate mentre riproduce
    if (!video.paused && !video.fluid) {
      // parti tolte vicine unite in un salto solo; il salto si prepara un attimo prima (vedi makePlayer)
      let nextPrep = false;
      for (const [a, b] of hopRanges()) {
        if (t >= a - 0.02 && t < b - 0.03) {
          // se la parte tolta arriva fino alla fine, il video finisce qui: resta l'ultimo fotogramma vero
          if (b >= D - 0.06) { video.pause(); video.currentTime = Math.max(0, lastKept() - 0.04); frame(true); return; }
          video.hop(b); return;
        }
        if (!nextPrep && t < a) { nextPrep = true; if (a - t < 1.5) video.prep(b); }
      }
    }
    let inCut = remCache.some(([a, b]) => t >= a && t < b);
    if (BLANK) {   // progetto vuoto: il nero non e' "tagliato", e' solo che li' non c'e' ancora niente
      const ce = contentEnd();
      const empty = ce < 0.05 || outTot < 0.05;
      const msg = pendingIns ? 'Preparo il video…' : empty ? 'Aggiungi un video o una foto per iniziare' : (t >= ce - 0.02 ? 'Fine del video' : 'Questa parte verrà tagliata');
      if (veil.textContent !== msg) veil.textContent = msg;
      if (empty || t >= ce - 0.02) inCut = true;
      // dove non c'e' nessuna clip si vede nero (non l'ultimo fotogramma di un video tolto)
      const covered = !empty && proj.segs.some((c) => c.ins && !c.gone && t >= c.a - 1e-3 && t < c.b && !(insById(c.ins) || {}).gap);
      const vis = covered ? '' : 'hidden';
      for (const v of video.insEls) if (v.style.visibility !== vis) v.style.visibility = vis;
      veil.classList.toggle('solid', empty);
    }
    veil.style.display = inCut && video.paused ? 'flex' : 'none';
    // zoom
    let p = 0, zz = null;
    for (const z of proj.zooms) { if (!cam && z.kind !== 'custom') continue; const v = zoomProgress(t, z); if (v > p) { p = v; zz = z; } }
    const sw = screen.clientWidth;
    const fz = framing && sel && sel.type === 'zoom' ? findSel() : null;
    const fr = fz ? (VERT || (fz.kind === 'custom' && fz.rect) ? zRectNow(fz) : null) : null;
    if (fr) {
      // modalita' inquadratura: video intero + riquadro da spostare (in verticale alto 9:16)
      const [fx, fy, fw, fh] = fr, k = sw / W;
      Object.assign(frameBox.style, { display: 'block', left: fx * k + 'px', top: fy * k + 'px', width: fw * k + 'px', height: fh * k + 'px' });
      frameBox.classList.toggle('v', VERT); frameBox.classList.toggle('narrow', VERT || fw * k < 96);
      frameDoneBar.style.display = VERT ? '' : 'none';
      zg.style.transform = ''; badgeMain.textContent = VERT ? 'Inquadratura verticale' : 'Scegli cosa inquadrare';
    } else if (frameBox.style.display !== 'none') { frameBox.style.display = 'none'; frameDoneBar.style.display = 'none'; }
    if (fr) { /* gia' gestito */ } else if (p > 0.001) {
      const [rx, ry, rw] = rectAt(p, W, H, zoomTarget(zoomAt(zz, t), W, H, cam));
      const s = W / rw, k = sw / W;
      zg.style.transform = `translate(${-rx * k * s}px, ${-ry * k * s}px) scale(${s})`;
      zoomNow = { s, tx: -rx * k * s, ty: -ry * k * s * (1) };
      badgeMain.textContent = 'Zoom attivo';
    } else { zg.style.transform = ''; zoomNow = null; badgeMain.textContent = inCut ? 'Taglio' : 'Originale'; }
    if (fr) zoomNow = null;
    // verticale: niente ingrandimento della live, la si disegna a pezzi sullo schermo verticale
    applyViewMode();
    if (VERT && !sourceView()) {
      zg.style.transform = '';
      const inZ = proj.zooms.some((z) => z.on !== false && t >= z.a && t < z.b && (cam || z.kind === 'custom'));
      badgeMain.textContent = inZ ? 'Webcam' : inCut ? 'Taglio' : 'Verticale';
      drawVertical(t);
    }
    applyTf(t); updateTfUI(t); drawGuides();
    // filtri attivi (a video fermo si ridisegnano solo se cambia qualcosa)
    updateFxLayer(t);
    updateMainKey(t);
    updateMaskUI();
    placeOverlays(t);
    applySpeed();
    // audio live
    const lt = liveTrack();
    const c = proj.segs.find((x) => t >= x.a && t < x.b) || proj.segs[proj.segs.length - 1];
    let v = lt.mute || c.mute ? 0 : (lt.vol / 100) * (c.vol / 100);
    if (c.fin) v *= Math.min(1, (t - c.a) / 0.5);
    if (c.fout) v *= Math.min(1, (c.b - t) / 0.5);
    // parole censurate: niente voce, bip al suo posto
    const bleep = !video.paused && censAt(t);
    if (bleep) v = 0;
    beep(bleep);
    video.volume = Math.max(0, Math.min(1, v)); video.muted = v === 0;
    badgeMute.style.display = v === 0 && !inCut ? '' : 'none';
    // suoni importati
    for (const tr of soundTracks()) {
      for (const sc of tr.clips) {
        const on = !video.paused && !tr.mute && !sc.mute && t >= sc.a && t < sc.a + sc.dur;
        const a = on || sounds.has(sc.id) ? soundEl(sc) : null;
        if (!a) continue;
        if (on) {
          const target = sc.offset + (t - sc.a);
          a.volume = Math.max(0, Math.min(1, (tr.vol / 100) * (sc.vol / 100)));
          if (a.paused) { a.currentTime = target; a.play().catch(() => {}); } else if (Math.abs(a.currentTime - target) > 0.3) a.currentTime = target;
        } else if (!a.paused) a.pause();
      }
    }
    // sottotitoli + testo attivo
    const segs = allWords();
    let si = -1;
    if (segs.length) {
      let lo = 0, hi = segs.length - 1;
      while (lo <= hi) { const m = (lo + hi) >> 1; if (segs[m].a <= t) { si = m; lo = m + 1; } else hi = m - 1; }
      if (si >= 0 && t > segs[si].b + 0.6) si = -1;
    }
    showSub(t, inCut);
    if (tab === 'text' && si !== lastSeg) {
      if (segEls[lastSeg]) segEls[lastSeg].classList.remove('active');
      if (segEls[si]) { segEls[si].classList.add('active'); if (!video.paused) segEls[si].scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
      lastSeg = si;
    }
    if (tab === 'text' && si >= 0 && wordEls[si]) {
      const wi = segs[si].words.findIndex((w) => t >= w.a && t < w.b);
      const el = wi >= 0 ? wordEls[si][wi] : null;
      if (el !== lastWord) { if (lastWord) lastWord.classList.remove('cur'); if (el) el.classList.add('cur'); lastWord = el; }
    }
    // tempo come nel video finale: le parti tolte (anche a righe) non contano, la velocita' si'
    timeLbl.textContent = fmt(outAt(t), true) + ' / ' + fmt(outTot);
    updateFsBar(t);
    if (acPlay && acPlay.isConnected) acPlay.style.left = t / D * 100 + '%';
    if (liveCtls.length && !ovDrag) liveCtls.forEach((f) => f());
    updatePlayhead(t);
    if (!video.paused && !scrub && !drag) {
      const x = X(t), l = scroller.scrollLeft, w = scroller.clientWidth;
      if (x > l + w - 40) scroller.scrollLeft = x - 60;
    }
  }
  let censCache = null;
  function censAt(t) {
    if (!censCache || censCache.ver !== ver || censCache.n !== allWords().length) {
      const r = [];
      allWords().forEach((s) => s.words.forEach((w) => { if (w.cens && !w.del) r.push([w.a - 0.03, w.b + 0.03]); }));
      censCache = { ver, n: allWords().length, r };
    }
    return censCache.r.some(([a, b]) => t >= a && t < b);
  }
  let actx = null, bgain = null;
  function beep(on) {
    if (!on && !bgain) return;
    try {
      if (!actx) {
        actx = new AudioContext(); const o = actx.createOscillator(); bgain = actx.createGain();
        o.frequency.value = 1000; bgain.gain.value = 0; o.connect(bgain).connect(actx.destination); o.start();
      }
      bgain.gain.setTargetAtTime(on ? 0.18 : 0, actx.currentTime, 0.005);
    } catch (e) { /* audio non disponibile */ }
  }
  // a video fermo e senza mani sul mouse/tastiera l'anteprima si ridisegna poco: il computer non si scalda per niente
  let lastAct = Date.now(), idleT = -1, idleAt = 0;
  const bump = () => { lastAct = Date.now(); if (!warmCtx || warmCtx.state === 'suspended') warmAudio(); };
  for (const ev of ['pointermove', 'pointerdown', 'keydown', 'wheel', 'dragover']) window.addEventListener(ev, bump, { passive: true, capture: true });
  function loop() {
    if (!alive) { for (const ev of ['pointermove', 'pointerdown', 'keydown', 'wheel', 'dragover']) window.removeEventListener(ev, bump, { capture: true }); return; }
    const now = Date.now(), t = video.currentTime;
    const idle = video.paused && !revRaf && !pendingIns && t === idleT && now - lastAct > 1200;
    if (!idle || now - idleAt > 500) { frame(); idleAt = now; }
    // fermo da 3 minuti senza toccare niente: l'audio si riposa (alla prima mossa si risveglia)
    if (warmCtx && warmCtx.state === 'running' && video.paused && now - lastAct > 180000) warmCtx.suspend().catch(() => {});
    idleT = t;
    raf = requestAnimationFrame(loop);
  }

  // ---------------------------------------------------------------- tastiera
  function onKey(e) {
    if (document.querySelector('.modal-bg')) return;
    const tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' && e.target.type !== 'range' || tag === 'textarea') return;
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); redo(); return; }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === 's') { e.preventDefault(); saveProjectFile(); return; }
    if ((e.ctrlKey || e.metaKey) && k === 's') { e.preventDefault(); flush(); return; }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === 'c') { if (copySel()) e.preventDefault(); return; }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === 'v') { if (pasteClip()) e.preventDefault(); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === '>' || (e.shiftKey && e.key === '.')) { e.preventDefault(); stepRate(1); return; }
    if (e.key === '<' || (e.shiftKey && e.key === ',')) { e.preventDefault(); stepRate(-1); return; }
    // i tasti si possono cambiare (Altro → Scorciatoie da tastiera)
    const act = actionFor(k);
    if (!act) return;
    if (act === 'play') { e.preventDefault(); if (tag === 'button') e.target.blur(); if (!e.repeat) { stopReverse(); togglePlay(); } }   // mai "ripremere" un pulsante
    else if (act === 'delete') { e.preventDefault(); deleteSel(); }
    else if (act === 'zoom') addZoom();
    else if (act === 'customZoom') addCustomZoom();
    else if (act === 'trimL') { e.preventDefault(); trimAt('left'); }
    else if (act === 'trimR') { e.preventDefault(); trimAt('right'); }
    else if (act === 'snap') magnetBtn.click();
    else if (act === 'text') addText();
    else if (act === 'vertical') { if (!IS_V) vertFromSelection(); }
    else if (act === 'full') toggleFull();
    else if (act === 'split') splitSeg();
    else if (act === 'back') { e.preventDefault(); stopReverse(); if (!video.paused) video.pause(); seek(video.currentTime - (e.shiftKey ? 1 : 1 / FPS)); }   // un fotogramma (Maiusc: 1 s)
    else if (act === 'fwd') { e.preventDefault(); stopReverse(); if (!video.paused) video.pause(); seek(video.currentTime + (e.shiftKey ? 1 : 1 / FPS)); }
    else if (act === 'prevEdit') { e.preventDefault(); jumpEdit(-1); }
    else if (act === 'nextEdit') { e.preventDefault(); jumpEdit(1); }
    else if (act === 'shuttleBack') { if (!e.repeat) shuttle(-1); }
    else if (act === 'shuttleStop') shuttle(0);
    else if (act === 'shuttleFwd') { if (!e.repeat) shuttle(1); }
    else if (act === 'marker') { if (!e.repeat) toggleMarker(); }
    else if (act === 'deselect') select(null, true);
  }
  loadKeys();
  document.addEventListener('keydown', onKey);
  const onKeyUp = (e) => { if (e.key === ' ' && (e.target.tagName || '').toLowerCase() === 'button') e.preventDefault(); };
  document.addEventListener('keyup', onKeyUp, true);
  window.addEventListener('beforeunload', flush);

  // ---------------------------------------------------------------- avvio
  const ro = new ResizeObserver(() => {
    layoutScreen();
    const oldFit = fitPps;
    fitPps = Math.max(0.005, (scroller.clientWidth - 2) / fitSpan());
    if (pps === oldFit || pps < fitPps) pps = fitPps;
    renderTimeline();
  });
  ro.observe(root); ro.observe(screenWrap); ro.observe(tl);
  refreshGone();
  fitPps = Math.max(0.005, (scroller.clientWidth - 2) / fitSpan()); pps = fitPps;
  layoutScreen();
  renderTimeline(); renderPanel(); updateUndo();
  // font usati nel progetto (sottotitoli e testi): si caricano subito, cosi' l'anteprima e' giusta
  loadFontList().then(() => {
    const used = new Set([(proj.subStyle || {}).font]);
    for (const tr of proj.tracks || []) for (const c of tr.clips || []) if (c.text && c.text.font) used.add(c.text.font);
    used.forEach((f) => { if (f) ensureFont(f).then(() => { if (alive) frame(true); }); });
  });
  let seek0 = null;
  try { seek0 = sessionStorage.getItem('vodcut.seek.' + pid); sessionStorage.removeItem('vodcut.seek.' + pid); } catch (e) { /* */ }
  if (VERT && cam) loadFace().then(() => { if (proj.faceOn && !faceJob) startFace(); });
  if (proj.story && proj.story.pending) setTimeout(buildStory, 0);
  else if (proj.story) setTimeout(fixStoryGaps, 0);
  video.addEventListener('loadedmetadata', () => { seek(seek0 !== null ? +seek0 + 0.05 : IS_V && proj.range ? proj.range[0] + 0.05 : proj.zooms.length ? Math.max(0, proj.zooms[0].a + 0.8) : 0); }, { once: true });
  loadTimelines();
  // timeline nuova creata da un elemento dei Media: l'elemento va subito nella traccia principale
  if (proj.startWith) {
    const sw = proj.startWith;
    delete proj.startWith; dirty = true;
    setTimeout(() => { if (alive) insertVideo(sw.path, 0, sw); }, 400);
  }
  if (proj.repairNote) {
    // progetto della versione vecchia (video unito alla live): tornato alla live originale
    delete proj.repairNote; dirty = true; scheduleSave();
    setTimeout(() => toast('Abbiamo sistemato questo progetto: il video che avevi aggiunto è stato tolto. Rimettilo trascinandolo dai Media sulla traccia Video.'), 800);
  }
  applyQuality();
  editorReady = true; montCheck(); updateCleanBtn();
  // progetti vuoti salvati prima della 1.5.118: le clip "eliminate" restavano grigie sulla traccia principale e con la
  // calamita accesa lasciavano spazi. Si tolgono una volta sola (si puo' annullare)
  if (BLANK && magnetOn() && proj.segs.some((c) => c.ins && c.removed && !c.gone)) {
    const snap = fullSnap();
    rebuildMain(mainItems().filter((x) => !(x.seg && x.seg.removed) && !x.gap));
    pushFull(snap); lightRefresh();
    toast('Ho tolto dalla traccia principale le clip eliminate che lasciavano spazi (puoi annullare)');
  }
  // nome del video modificabile direttamente dal titolo in alto (clic)
  (() => {
    const cc = document.querySelector('.crumb-cur');
    const sp = cc && cc.querySelector('span[data-notr]');
    if (!sp) return;
    cc.classList.add('editable'); cc.dataset.tip = 'Clic per rinominare';
    cc.addEventListener('click', () => {
      if (cc.querySelector('input')) return;
      const inp = h('input', { class: 'crumb-in', value: proj.name, maxlength: '120', 'aria-label': 'Nome del video' });
      sp.style.display = 'none'; cc.append(inp); inp.focus(); inp.select();
      const done = (ok) => {
        const v = inp.value.trim(); inp.remove(); sp.style.display = '';
        if (ok && v && v !== proj.name) { begin(); proj.name = v; changed({ keepPanel: true }); sp.textContent = v; document.title = v + ' · NoonFrame'; toast('Rinominato'); }
      };
      inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') done(true); else if (e.key === 'Escape') done(false); });
      inp.addEventListener('blur', () => done(true));
    });
  })();
  loop();
  dirty = true; scheduleSave();  // salva subito le impostazioni aggiornate
  if (proj.transcript && proj.transcript.status === 'running') watchTranscript();
  else get('/api/jobs').then((jobs) => {
    const j = jobs.find((x) => x.pid === pid && x.kind === 'transcribe');
    if (j && alive && !allWords().length) { trJob = j; proj.transcript = { status: 'running', segments: [] }; renderTimeline(); renderPanel(); watchTranscript(); }
  }).catch(() => {});

  return async () => {
    alive = false;
    try { if (warmCtx) warmCtx.close(); } catch (e) { /* */ }
    dragCard.remove();
    matteVids.forEach((v) => { v.pause(); v.remove(); });
    keyMaskVids.forEach((v) => { v.pause(); v.remove(); });
    cancelAnimationFrame(raf);
    ro.disconnect();
    document.removeEventListener('keydown', onKey);
    document.removeEventListener('keyup', onKeyUp, true);
    document.removeEventListener('fullscreenchange', onFs);
    document.removeEventListener('webkitfullscreenchange', onFs);
    window.removeEventListener('keydown', onFsKey, true);
    window.removeEventListener('pointerdown', onBless, true);
    window.removeEventListener('keydown', onBless, true);
    if (fakeFs) setFakeFs(false);
    else if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    window.removeEventListener('beforeunload', flush);
    video.pause(); sounds.forEach((a) => a.pause());
    if (actx) actx.close().catch(() => {});
    video.removeAttribute('src'); video.load();
    await flush();
  };
}
