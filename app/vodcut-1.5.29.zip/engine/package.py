"""Progetto in un file .vodcut: per portarlo da un PC all'altro.

Il file e' uno zip con il progetto (tagli, zoom, testi, sottotitoli, impostazioni), le immagini dei
testi e l'analisi dell'audio. I file grandi (il VOD, le immagini e i suoni importati) NON sono dentro:
sull'altro PC si ricollegano (anche tutti insieme, indicando una cartella).
"""
import json
import os
import re
import time
import zipfile

from . import project as P
from .util import CACHE_DIR, IMPORTS_DIR, probe

FORMAT = 1
MEDIA_KINDS = {".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image", ".gif": "image", ".bmp": "image",
               ".mp4": "video", ".mov": "video", ".mkv": "video", ".webm": "video", ".m4v": "video", ".avi": "video", ".flv": "video", ".ts": "video",
               ".mp3": "audio", ".wav": "audio", ".m4a": "audio", ".aac": "audio", ".ogg": "audio", ".flac": "audio", ".opus": "audio"}


def _kind(path, is_source=False):
    if is_source:
        return "video"
    return MEDIA_KINDS.get(os.path.splitext(path or "")[1].lower(), "file")


def media_refs(proj):
    """Tutti i file esterni usati dal progetto: [{path, kind, name, source}] (senza doppioni).
    Le immagini dei testi non contano: viaggiano dentro al .vodcut."""
    out, seen = [], set()

    def add(path, source=False):
        if not path:
            return
        key = os.path.normcase(path)
        if key in seen:
            return
        seen.add(key)
        out.append({"path": path, "name": os.path.basename(path.replace("\\", "/")), "kind": _kind(path, source), "source": source})
    add(proj.get("source"), True)
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            if not c.get("isText"):
                add(c.get("file"))
    for i in proj.get("inserts") or []:
        add(i.get("file"))
    for a in proj.get("assets", []):
        add(a.get("path"))
    return out


def missing_files(proj):
    res = []
    for r in media_refs(proj):
        if not os.path.isfile(r["path"]):
            res.append(r)
    return res


def export_package(proj, dest, cache_files=()):
    """Scrive il file .vodcut. cache_files: [(percorso sul disco, nome nello zip)]."""
    tmp = dest + ".part"
    refs = media_refs(proj)
    for r in refs:
        try:
            r["size"] = os.path.getsize(r["path"])
        except OSError:
            r["size"] = None
    meta = {"format": FORMAT, "app": "VODcut", "created": time.time(), "name": proj.get("name"), "files": refs}
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("vodcut.json", json.dumps(meta, ensure_ascii=False, indent=1))
        z.writestr("progetto.json", json.dumps(proj, ensure_ascii=False))
        for t in proj.get("tracks", []):
            for c in t.get("clips", []):
                if c.get("isText") and c.get("file") and os.path.isfile(c["file"]):
                    z.write(c["file"], "testi/" + os.path.basename(c["file"]))
        for src, arc in cache_files:
            if os.path.isfile(src):
                z.write(src, arc)
    os.replace(tmp, dest)
    return dest


def import_package(path, wave_path, db_path):
    """Legge un .vodcut e crea il progetto su questo PC (con un id nuovo se serve)."""
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise ValueError("Questo file non e' un progetto Nuvora valido")
    with z:
        names = set(z.namelist())
        if "progetto.json" not in names:
            raise ValueError("Questo file non e' un progetto Nuvora valido")
        proj = json.loads(z.read("progetto.json").decode("utf-8"))
        old = str(proj.get("id") or "p")
        # l'id diventa un nome di file: da un file che arriva da fuori accettiamo solo lettere e numeri
        ok = re.fullmatch(r"p[A-Za-z0-9]{1,40}", old)
        pid = old if ok and not os.path.exists(P.path_for(old)) else P.new_id("p")
        proj["id"] = pid
        for k in ("parent", "parentName", "range"):   # da solo diventa un progetto normale
            proj.pop(k, None)
        proj.pop("verticals", None)
        # immagini dei testi
        d = os.path.join(IMPORTS_DIR, "testi")
        os.makedirs(d, exist_ok=True)
        for t in proj.get("tracks", []):
            for c in t.get("clips", []):
                if c.get("isText") and c.get("file"):
                    arc = "testi/" + os.path.basename(c["file"].replace("\\", "/"))
                    if arc in names:
                        dest = os.path.join(d, f"{pid}_{os.path.basename(arc)}")
                        with open(dest, "wb") as f:
                            f.write(z.read(arc))
                        c["file"] = dest
        # analisi dell'audio (cosi' non va rifatta)
        for arc, dest in (("cache/wave.json", wave_path(pid)), ("cache/db.npy", db_path(pid))):
            if arc in names:
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(z.read(arc))
    proj["updated"] = time.time()
    # l'id vecchio compare nei nomi delle anteprime: nessun problema, vengono rifatte
    P.save(proj)
    return proj


def _replace_paths(proj, mapping):
    """mapping: {percorso vecchio (normcase): percorso nuovo}"""
    def fix(p):
        return mapping.get(os.path.normcase(p), p) if p else p
    proj["source"] = fix(proj.get("source"))
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            if not c.get("isText"):
                c["file"] = fix(c.get("file"))
    for a in proj.get("assets", []):
        a["path"] = fix(a.get("path"))
    for i in proj.get("inserts") or []:
        old = i.get("file")
        i["file"] = fix(old)
        if i["file"] != old:
            i.pop("preview", None)   # la copia per l'anteprima era dell'altro PC


def check_source(proj, new_path):
    """Il video principale deve essere lo stesso (stessa durata, al secondo)."""
    try:
        info = probe(new_path)
    except Exception:
        raise ValueError("Non riesco a leggere questo video")
    if not info.get("has_video"):
        raise ValueError("Questo file non contiene video")
    if abs(float(info.get("duration") or 0) - float(P.live_duration(proj) or 0)) > 1.5:
        raise ValueError("Questo non sembra lo stesso video: la durata è diversa")
    return True


def relink(proj, old_path, new_path):
    if not os.path.isfile(new_path):
        raise ValueError("File non trovato")
    if os.path.normcase(old_path) == os.path.normcase(proj.get("source") or ""):
        check_source(proj, new_path)
    _replace_paths(proj, {os.path.normcase(old_path): os.path.abspath(new_path)})
    return proj


def relink_folder(proj, folder, max_files=200000):
    """Cerca nella cartella (e sottocartelle) i file mancanti con lo stesso nome. Ritorna quanti ne ha trovati."""
    miss = missing_files(proj)
    if not miss:
        return 0
    want = {}
    for r in miss:
        want.setdefault(r["name"].lower(), []).append(r)
    found = {}
    n = 0
    for root, dirs, files in os.walk(folder):
        dirs[:] = [x for x in dirs if not x.startswith(".") and x.lower() not in ("$recycle.bin", "windows", "appdata")]
        for fn in files:
            n += 1
            if n > max_files:
                break
            lst = want.get(fn.lower())
            if not lst:
                continue
            full = os.path.join(root, fn)
            for r in lst:
                if os.path.normcase(r["path"]) in found:
                    continue
                if r["source"]:
                    try:
                        check_source(proj, full)
                    except ValueError:
                        continue
                found[os.path.normcase(r["path"])] = os.path.abspath(full)
        if n > max_files or len(found) == len(miss):
            break
    _replace_paths(proj, found)
    return len(found)


def safe_name(name):
    return re.sub(r'[\\/:*?"<>|]+', "_", name or "progetto").strip() or "progetto"

