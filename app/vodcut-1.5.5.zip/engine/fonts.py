"""Font dei testi e dei sottotitoli.

- Font inclusi nell'app: web/fonts (licenza OFL/Apache, liberi anche per uso commerciale), elenco in catalog.json.
- Font personalizzati dell'utente: ~/VODcut/font (.ttf / .otf). Il nome e' quello scritto dentro il file (famiglia),
  cosi' anche i sottotitoli (libass) li trovano con lo stesso nome.
"""
import json
import os
import re
import struct

from .util import APP_DIR

WEB_FONTS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web", "fonts")
USER_FONTS = os.path.join(APP_DIR, "font")
FONT_EXT = (".ttf", ".otf")
MAX_FONT = 30 * 1024 * 1024


def catalog():
    try:
        with open(os.path.join(WEB_FONTS, "catalog.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def family_name(path):
    """Nome della famiglia scritto nel font (tabella 'name': 16 = famiglia tipografica, se no 1)."""
    with open(path, "rb") as f:
        data = f.read()
    if len(data) < 12:
        return None
    tag = data[:4]
    if tag == b"ttcf":
        off = struct.unpack(">I", data[12:16])[0]
    elif tag in (b"\x00\x01\x00\x00", b"OTTO", b"true"):
        off = 0
    else:
        return None
    n = struct.unpack(">H", data[off + 4:off + 6])[0]
    name_off = None
    for i in range(n):
        rec = data[off + 12 + i * 16: off + 28 + i * 16]
        if rec[:4] == b"name":
            name_off = struct.unpack(">I", rec[8:12])[0]
            break
    if name_off is None:
        return None
    _, count, str_off = struct.unpack(">HHH", data[name_off:name_off + 6])
    best = {}
    for i in range(count):
        pid, eid, lid, nid, ln, so = struct.unpack(">HHHHHH", data[name_off + 6 + i * 12: name_off + 18 + i * 12])
        if nid not in (1, 16):
            continue
        raw = data[name_off + str_off + so: name_off + str_off + so + ln]
        try:
            s = raw.decode("utf-16-be") if pid in (0, 3) else raw.decode("latin-1")
        except UnicodeDecodeError:
            continue
        s = s.strip()
        if not s:
            continue
        # inglese (Windows 0x409) prima di tutto
        score = (2 if (pid == 3 and lid == 0x409) else 1 if pid == 3 else 0)
        if nid not in best or score > best[nid][0]:
            best[nid] = (score, s)
    got = best.get(16) or best.get(1)
    return got[1] if got else None


def user_fonts():
    out = []
    try:
        names = sorted(os.listdir(USER_FONTS))
    except OSError:
        return out
    for fn in names:
        if not fn.lower().endswith(FONT_EXT):
            continue
        p = os.path.join(USER_FONTS, fn)
        try:
            fam = family_name(p)
        except Exception:
            fam = None
        out.append({"name": fam or os.path.splitext(fn)[0], "file": fn})
    return out


def save_user_font(name, data):
    """Salva un font caricato dall'utente. Ritorna {name, file}."""
    base = re.sub(r'[\\/:*?"<>|]+', "_", os.path.basename(name or "font.ttf"))
    if not base.lower().endswith(FONT_EXT):
        raise ValueError("Usa un font .ttf o .otf")
    if len(data) > MAX_FONT:
        raise ValueError("Il font e' troppo grande")
    os.makedirs(USER_FONTS, exist_ok=True)
    tmp = os.path.join(USER_FONTS, "_caricamento.tmp")
    with open(tmp, "wb") as f:
        f.write(data)
    try:
        fam = family_name(tmp)
    except Exception:
        fam = None
    if not fam:
        os.remove(tmp)
        raise ValueError("Questo file non sembra un font valido (.ttf o .otf)")
    if any(x.get("name") == fam for x in catalog()):
        os.remove(tmp)
        raise ValueError(f"{fam} c'e' gia' in VODcut: cercalo nell'elenco dei font")
    same = next((u for u in user_fonts() if u["name"] == fam and u["file"] != "_caricamento.tmp"), None)
    if same:
        os.remove(tmp)
        return same   # gia' aggiunto
    dest = os.path.join(USER_FONTS, base)
    stem, ext = os.path.splitext(dest)
    i = 2
    while os.path.exists(dest):
        dest = f"{stem} ({i}){ext}"
        i += 1
    os.replace(tmp, dest)
    return {"name": fam, "file": os.path.basename(dest)}


def delete_user_font(fn):
    fn = os.path.basename(fn or "")
    p = os.path.join(USER_FONTS, fn)
    if fn.lower().endswith(FONT_EXT) and os.path.isfile(p):
        os.remove(p)
        return True
    return False


def files_for(name):
    """File del font con questo nome (inclusi o dell'utente), per i sottotitoli."""
    if not name:
        return []
    for x in catalog():
        if x.get("name") == name or x.get("fam") == name:
            return [os.path.join(WEB_FONTS, f) for f in x.get("files", {}).values()]
    return [os.path.join(USER_FONTS, u["file"]) for u in user_fonts() if u["name"] == name]
