// VODcut - editor: anteprima live, timeline, testo, proprieta'.
import { api, get, post, put, h, icon, ibtn, fmt, fmtDur, toast, confirmBox, promptBox, seg, toggle, pollJob, mediaUrl, thumbUrl, TOKEN,
  zoomProgress, ZOOM_IN_FX, ZOOM_OUT_FX, vertRegions, vertSettings, vertAnimRegs, vertZoom, vertZoomBoxes, vertRect, coverRect, targetRect, rectAt, zoomTarget, customRect, imgStateAt, imgCss, IMG_KEYS, SUB_DEFAULT, FONT_RATIO, ANIMS, MOTIONS, imgFinal } from './lib.js';
import { FX_LIST, fxName, loadLooks, FxRenderer, drawMask, backdropFilter, ADJ_KEYS } from './fx.js';
import { fontPicker, ensureFont, fontReady, loadFontList } from './fonts.js';
import { drawText, drawBadge, TEXT_DEFAULT, TEXT_PRESETS, PLATFORMS, platformOf, BADGE_STYLES, BADGE_DEFAULT, badgeLabel, preloadBadgeLogos, logoUrl } from './text.js';
import { t as tx } from './i18n.js';

const SOUND_COLORS = ['#2DD4BF', '#818CF8', '#38BDF8', '#A5B4FC', '#5EEAD4'];
const OV_COLORS = ['#60A5FA', '#A5B4FC', '#38BDF8', '#818CF8', '#22D3EE'];
// colori delle tracce dei progetti vecchi (arcobaleno) -> la nuova famiglia di blu
const OLD_COLORS = { '#E86F9B': '#60A5FA', '#6FC3E8': '#38BDF8', '#E8A04F': '#A5B4FC', '#9B7BFF': '#818CF8', '#2DC2A8': '#2DD4BF' };
const LANE_H = { vert: 34, zoom: 48, video: 84, live: 52, subs: 48, sound: 44, overlay: 44, fx: 34 };
const LANE_MIN = { vert: 22, zoom: 12, video: 34, live: 16, subs: 16, sound: 14, overlay: 14, fx: 12 };
const IMG_RE = /\.(png|jpe?g|webp|gif|bmp)$/i, AUD_RE = /\.(mp3|wav|m4a|aac|ogg|flac|opus)$/i, VID_RE = /\.(mp4|mov|mkv|webm|m4v|avi|flv|ts)$/i;
const mthumbUrl = (path, t) => '/api/mthumb?token=' + TOKEN + '&path=' + encodeURIComponent(path) + '&t=' + (t || 1);
const store = { get(k, d) { try { const v = localStorage.getItem('vodcut.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('vodcut.' + k, JSON.stringify(v)); } catch (e) { /* */ } } };
const uid = (p) => p + Math.random().toString(16).slice(2, 10);

export async function mountEditor(app, proj, ctx) {
  const env = ctx.env || {};
  const pid = proj.id;
  // funzioni tolte dall'interfaccia per ora: restano spente
  Object.assign(proj.settings, { denoise: false, bleep: false, srt: false, chapters: false, burnSubs: false, norm: false });
  if (proj.settings.showSubs === undefined) proj.settings.showSubs = true;
  proj.assets = proj.assets || [];
  proj.layers = normLayers();
  proj.subStyle = { ...SUB_DEFAULT, ...(proj.subStyle || {}) };
  proj.filters = proj.filters || [];
  // tracce in piu' per filtri e zoom, nomi delle tracce principali
  if (!proj.fxTracks || !proj.fxTracks.length) proj.fxTracks = [{ id: 'fx', name: 'Filtri' }];
  if (!proj.zoomTracks || !proj.zoomTracks.length) proj.zoomTracks = [{ id: 'zoom', name: 'Zoom' }];
  proj.laneNames = proj.laneNames || {};
  proj.filters.forEach((f) => { if (!f.track) f.track = 'fx'; });
  proj.zooms.forEach((z) => { if (!z.track) z.track = 'zoom'; });
  loadLooks();
  (proj.inserts || []).forEach((i) => { delete i.words; });   // resti di una versione vecchia
  let D = proj.duration;
  const W = proj.width, H = proj.height;
  // clip verticale (creata dal VOD): stessa live, si modifica a parte. Il VOD ne tiene la lista
  const IS_V = !!proj.parent;
  const KIND = proj.kind || 'vod';   // vod | video | blank | story
  const IS_VOD = KIND === 'vod';
  const BLANK = KIND === 'blank';   // progetto vuoto: il nero di base e' solo spazio libero
  (proj.tracks || []).forEach((t) => { const c = t.color && OLD_COLORS[t.color.toUpperCase()]; if (c) t.color = c; });
  if (!IS_V) proj.verticals = proj.verticals || [];
  // formato del video finale: orizzontale (come la live) o verticale 9:16. Testi e immagini stanno sullo schermo finale
  let VERT = proj.format === '9:16';
  const CW = () => (VERT ? Math.round(H * 9 / 16) : W), CH = () => H;
  const CA = () => CW() / CH();
  const cam = proj.webcam && proj.webcam.box ? proj.webcam.box : null;
  let wave = { perSec: 5, peaks: [] }, waveLive = null;
  const clipPeaks = new Map();
  get(`/api/p/${pid}/wave`).then((w) => { waveLive = w; composeWave(); }).catch(() => {});

  // ---------------------------------------------------------------- stato
  let sel = null;               // {type:'zoom'|'cut'|'lclip'|'sclip'|'track', id}
  let framing = false;          // stai scegliendo l'inquadratura di uno zoom personalizzato
  let tab = 'video';   // pannello a destra: video, audio, testo
  const LEFT_TABS = [...(proj.story ? ['story'] : []), 'project', 'media', ...(IS_V || proj.width < proj.height * 1.3 ? [] : ['clips'])];
  let ltab = proj.story ? 'story' : store.get('ltab', 'project');   // pannello a sinistra (come CapCut): progetto, media, clip
  if (!LEFT_TABS.includes(ltab)) ltab = 'project';
  let pps = 1;                  // pixel per secondo nella timeline
  let fitPps = 1;
  let undoStack = [], redoStack = [];
  let saveTimer = null, saving = false, dirty = false;
  let alive = true;
  const liveTrack = () => proj.tracks.find((t) => t.type === 'live');
  const soundTracks = () => proj.tracks.filter((t) => t.type === 'sound');
  const ovTracks = () => proj.tracks.filter((t) => t.type === 'overlay');
  const clipTracks = () => proj.tracks.filter((t) => t.type !== 'live');
  // ordine dei livelli video dall'alto verso il basso; il video e' sempre la base
  function normLayers() {
    const ov = proj.tracks.filter((t) => t.type === 'overlay').map((t) => 'ov:' + t.id);
    const fxk = (proj.fxTracks || [{ id: 'fx' }]).map((t) => (t.id === 'fx' ? 'fx' : 'fx:' + t.id));
    const cur = (proj.layers || ['subs', 'zoom', 'fx']).filter((x) => x === 'subs' || x === 'zoom' || fxk.includes(x) || ov.includes(x));
    ['subs', 'zoom', 'fx'].forEach((k) => { if (!cur.includes(k)) cur.push(k); });
    // le tracce filtri/colori nuove vanno subito sopra quella principale dei filtri
    fxk.forEach((k) => { if (!cur.includes(k)) cur.splice(Math.max(0, cur.indexOf('fx')), 0, k); });
    ov.forEach((k) => { if (!cur.includes(k)) cur.unshift(k); });
    return cur.concat(['video']);
  }
  const allWords = () => (proj.transcript && proj.transcript.segments) || [];

  // ---------------------------------------------------------------- storico e salvataggio
  function snapshot() {
    const dels = [], cens = [], txt = {}, nos = [];
    allWords().forEach((s, si) => s.words.forEach((w, wi) => {
      const k = si + '_' + wi;
      if (w.del) dels.push(k); if (w.cens) cens.push(k); if (w.nosub) nos.push(k); if (w.ed) txt[k] = w.w;
    }));
    return JSON.stringify({ name: proj.name, zooms: proj.zooms, segs: proj.segs, tracks: proj.tracks, settings: proj.settings, layers: proj.layers, subStyle: proj.subStyle, filters: proj.filters, fxTracks: proj.fxTracks, zoomTracks: proj.zoomTracks, laneNames: proj.laneNames, dels, cens, txt, nos });
  }
  function restore(snap) {
    const s = JSON.parse(snap);
    proj.name = s.name || proj.name; proj.zooms = s.zooms; proj.segs = s.segs; proj.tracks = s.tracks; proj.settings = s.settings;
    forgetTextPreviews();
    if (s.fxTracks) proj.fxTracks = s.fxTracks; if (s.zoomTracks) proj.zoomTracks = s.zoomTracks; if (s.laneNames) proj.laneNames = s.laneNames;
    proj.layers = s.layers || proj.layers; proj.layers = normLayers(); if (s.subStyle) proj.subStyle = s.subStyle; proj.filters = s.filters || [];
    const set = new Set(s.dels), cs = new Set(s.cens || []), ns = new Set(s.nos || []), txt = s.txt || {};
    allWords().forEach((sg, si) => sg.words.forEach((w, wi) => {
      const k = si + '_' + wi;
      w.del = set.has(k); w.cens = cs.has(k) || undefined; w.nosub = ns.has(k) || undefined;
      if (k in txt) { w.w = txt[k]; w.ed = true; } else if (w.ed) { w.w = w.orig ?? w.w; w.ed = false; }
    }));
  }
  function begin() { undoStack.push(snapshot()); if (undoStack.length > 200) undoStack.shift(); redoStack = []; updateUndo(); }
  let ver = 0;   // cambia a ogni modifica (cache dei sottotitoli)
  function changed(opts = {}) {
    ver++;
    dirty = true;
    scheduleSave();
    renderTimeline();
    if (!opts.keepPanel) renderPanel();
    if (opts.transcript) renderTranscriptFlags();
  }
  // posizione "prima" per rimettere un video spostato dov'era (in tempi di adesso)
  function backTarget(id, oldAt) {
    const rec = (proj.inserts || []).find((x) => x.id === id);
    if (!rec) return null;
    return oldAt > rec.at ? oldAt + rec.dur : oldAt;
  }
  async function undo() {
    if (!undoStack.length) return;
    const top = undoStack[undoStack.length - 1];
    if (typeof top !== 'string') {
      undoStack.pop();
      if (top.kind === 'full') {   // spazi vuoti e spostamenti liberi: si torna allo stato di prima
        const now = fullSnap();
        await fullRestore(top.snap);
        redoStack = redoStack.filter((x) => typeof x === 'object' && x.kind === 'full'); redoStack.push({ kind: 'full', snap: now });
      } else if (top.kind === 'liveMove') {   // clip della live spostata: torna al suo posto
        await removeInsert(top.id);
        const c = proj.segs.find((x) => x.id === top.seg.id);
        if (c) Object.assign(c, { gone: !!top.seg.gone, removed: !!top.seg.removed });
        refreshGone(); renderTimeline(); changed({ transcript: true });
        undoStack = []; redoStack = [];
      } else if (top.kind === 'move') {
        const cur = (proj.inserts || []).find((x) => x.id === top.id);
        const now = cur ? cur.at : 0;
        await moveInsert(top.id, backTarget(top.id, top.back), true);
        undoStack = []; redoStack = [{ kind: 'move', id: top.id, back: now }];
      } else {   // annulla un video inserito
        const copy = await removeInsert(top.id);
        undoStack = []; redoStack = copy ? [{ kind: 'insert', rec: copy }] : [];
      }
      updateUndo(); return;
    }
    if (redoStack.length && typeof redoStack[redoStack.length - 1] !== 'string') redoStack = [];
    redoStack.push(snapshot()); restore(undoStack.pop()); fixSel(); changed({ transcript: true }); updateUndo(); applyQuality();
  }
  async function redo() {
    if (!redoStack.length) return;
    const top = redoStack[redoStack.length - 1];
    if (typeof top !== 'string') {
      redoStack.pop();
      if (top.kind === 'full') {
        const now = fullSnap();
        await fullRestore(top.snap);
        undoStack.push({ kind: 'full', snap: now });
      } else if (top.kind === 'move') {
        const cur = (proj.inserts || []).find((x) => x.id === top.id);
        const now = cur ? cur.at : 0;
        await moveInsert(top.id, backTarget(top.id, top.back), true);
        undoStack = [{ kind: 'move', id: top.id, back: now }]; redoStack = [];
      } else {
        const { own, ...rec } = top.rec;
        await applyInsert({ ...rec }, true, own);
      }
      updateUndo(); return;
    }
    undoStack.push(snapshot()); restore(redoStack.pop()); fixSel(); changed({ transcript: true }); updateUndo(); applyQuality();
  }
  function fixSel() { if (sel && !findSel()) sel = null; }
  function scheduleSave() {
    savedLabel.dataset.tip = 'Salvataggio in corso…'; savedLabel.style.opacity = '0.4';
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 600);
  }
  async function save() {
    if (saving) { scheduleSave(); return; }
    if (!dirty) return;
    saving = true; dirty = false;
    try {
      // non sovrascrivere una trascrizione arrivata nel frattempo
      await put('/api/p/' + pid, proj);
      savedLabel.dataset.tip = 'Salvato in automatico'; savedLabel.style.opacity = '1'; savedLabel.style.color = '';
    } catch (e) { dirty = true; savedLabel.dataset.tip = 'Salvataggio non riuscito'; savedLabel.style.color = '#FF7B72'; toast(e.message, true); }
    saving = false;
  }
  async function flush() { clearTimeout(saveTimer); if (dirty) await save(); }

  // ---------------------------------------------------------------- tempo tolto (tagli + parole)
  function removed() {
    const r = proj.segs.filter((c) => c.removed).map((c) => [c.a, c.b]);
    allWords().forEach((s) => s.words.forEach((w) => { if (w.del) r.push([w.a, w.b]); }));
    r.sort((a, b) => a[0] - b[0]);
    const m = [];
    for (const [a, b] of r) { if (m.length && a <= m[m.length - 1][1] + 0.05) m[m.length - 1][1] = Math.max(m[m.length - 1][1], b); else m.push([a, b]); }
    return m;
  }
  function wordCuts() {
    const r = [];
    allWords().forEach((s, si) => s.words.forEach((w, wi) => { if (w.del) r.push([w.a, w.b, si, wi]); }));
    const m = [];
    for (const x of r) { const l = m[m.length - 1]; if (l && x[0] <= l[1] + 0.12) l[1] = Math.max(l[1], x[1]); else m.push([x[0], x[1], x[2], x[3]]); }
    return m;
  }
  // durata del video finale: i pezzi tolti non contano, quelli accelerati/rallentati cambiano durata
  // progetto vuoto: il video finisce dove finisce l'ultima cosa messa (il nero dopo non si esporta)
  function contentEnd() {
    let e = 0;
    for (const c of proj.segs) if (c.ins && !c.gone && !c.removed) e = Math.max(e, c.b);
    for (const t of proj.tracks || []) if (!t.hidden) for (const c of t.clips || []) e = Math.max(e, c.a + (c.dur != null ? c.dur : (c.b || c.a) - c.a));
    return e;
  }
  function outDuration() {
    const rem = removed();
    const cap = BLANK ? contentEnd() : D;
    let tot = 0;
    for (const c of proj.segs) {
      if (c.a >= cap) continue;
      let d = Math.min(c.b, cap) - c.a;
      for (const [a, b] of rem) d -= Math.max(0, Math.min(c.b, b) - Math.max(c.a, a));
      tot += Math.max(0, d) / (c.speed || 1);
    }
    return tot;
  }
  // quanto video finale c'e' prima dell'istante t
  function outAt(t) {
    const rem = remCache;
    let tot = 0;
    for (const c of proj.segs) {
      if (c.a >= t) break;
      const e = Math.min(c.b, t);
      let d = e - c.a;
      for (const [a, b] of rem) d -= Math.max(0, Math.min(e, b) - Math.max(c.a, a));
      tot += Math.max(0, d) / (c.speed || 1);
    }
    return tot;
  }
  const speedAt = (t) => { const c = proj.segs.find((x) => t >= x.a && t < x.b); return (c && c.speed) || 1; };
  // ---------------------------------------------------------------- lettore
  // La traccia principale puo' essere fatta di piu' file: la live e i video inseriti (all'inizio, alla fine,
  // in mezzo). Non vengono uniti: questo "lettore" passa da un file all'altro e fuori sembra un video solo,
  // con il tempo della timeline. Senza video inseriti e' esattamente il <video> della live.
  function makePlayer(live) {
    const ins = h('video', { class: 'insvid', preload: 'auto', playsinline: true, style: { display: 'none' } });
    let pcs = [], cur = null, act = live, insUrl = '', rate = 1, vol = 1, muted = false, lastBuilt = '';
    const BOTH = new Set(['play', 'pause', 'playing', 'seeked', 'timeupdate', 'ended']);
    function build() {
      const list = (proj.inserts || []).slice().sort((x, y) => x.at - y.at);
      const key = JSON.stringify(list.map((i) => [i.id, i.at, i.dur, i.offset || 0, i.file, i.preview || ''])) + '|' + D;
      if (key === lastBuilt) return;
      lastBuilt = key;
      // dove eravamo (in tempo della timeline), per restarci dopo che i pezzi cambiano
      const prevT = cur ? Math.max(cur.t0, Math.min(cur.t1, cur.t0 + (act.currentTime - cur.off))) : 0;
      const liveD = proj.liveDuration || (D - list.reduce((s, i) => s + i.dur, 0));
      const out = [];
      let T = 0, L = 0;
      for (const i of list) {
        if (i.at > T + 1e-6) { out.push({ t0: T, t1: i.at, off: L, live: true }); L += i.at - T; T = i.at; }
        out.push({ t0: T, t1: T + i.dur, off: i.offset || 0, live: false, ins: i });
        T += i.dur;
      }
      if (liveD - L > 1e-3 || !out.length) out.push({ t0: T, t1: T + (liveD - L), off: L, live: true });
      pcs = out;
      if (!cur || !pcs.includes(cur)) { cur = pieceAt(prevT); if (pcs.length > 1) use(cur, prevT, false); }
    }
    const multi = () => { build(); return pcs.length > 1; };
    const pieceAt = (t) => { for (const p of pcs) if (t < p.t1 - 1e-6) return p; return pcs[pcs.length - 1]; };
    function use(p, t, playing) {
      // una clip della live spostata altrove e' sempre la live: la legge lo stesso lettore (anche la copia leggera)
      const onLive = p.live || !!(p.ins && p.ins.live);
      const el = onLive ? live : ins;
      if (!onLive) {
        const url = mediaUrl(p.ins.preview || p.ins.file);
        if (url !== insUrl) { insUrl = url; ins.src = url; }
      }
      cur = p;
      if (el !== act) {
        const old = act;
        act = el;
        old.pause();
        ins.style.display = onLive ? 'none' : '';
      }
      const lt = Math.max(0, p.off + (t - p.t0));
      if (Math.abs(el.currentTime - lt) > 0.002) el.currentTime = lt;
      el.playbackRate = rate; el.volume = vol; el.muted = muted;
      if (playing && el.paused) el.play().catch(() => {});
    }
    const api = {
      insEl: ins,
      pieceAt(t) { build(); return pieceAt(Math.max(0, t)); },
      get el() { return act; },
      get currentTime() {
        if (!multi()) return live.currentTime;
        const t = cur.t0 + (act.currentTime - cur.off);
        return Math.max(cur.t0, Math.min(cur.t1, t));
      },
      set currentTime(t) {
        if (!multi()) { live.currentTime = t; return; }
        use(pieceAt(Math.max(0, t)), Math.max(0, t), !act.paused);
      },
      get paused() { return act.paused; },
      play() { if (multi() && cur) use(cur, api.currentTime, false); return act.play(); },
      pause() { live.pause(); ins.pause(); },
      get playbackRate() { return act.playbackRate; },
      set playbackRate(r) { rate = r; live.playbackRate = r; if (ins.src) ins.playbackRate = r; },
      get volume() { return act.volume; },
      set volume(v) { vol = v; act.volume = v; },
      get muted() { return act.muted; },
      set muted(m) { muted = m; act.muted = m; },
      get src() { return live.src; },
      set src(u) { live.src = u; },
      get error() { return live.error; },
      get readyState() { return live.readyState; },
      load() { live.load(); },
      removeAttribute(k) { live.removeAttribute(k); ins.removeAttribute(k); ins.load(); },
      addEventListener(ev, fn, opt) {
        if (!BOTH.has(ev)) return live.addEventListener(ev, fn, opt);
        // gli eventi del file che non si sta guardando non contano (cambio di file durante la riproduzione)
        const w = (e) => { if (e.target === act) fn(e); };
        live.addEventListener(ev, w, opt); ins.addEventListener(ev, w, opt);
      },
      // durante la riproduzione: alla fine di un pezzo si passa al file successivo
      tick() {
        if (!multi() || !cur) return;
        const end = cur.off + (cur.t1 - cur.t0);
        if (act.paused && !act.ended) return;
        if (act.currentTime >= end - 0.03 || act.ended) {
          const i = pcs.indexOf(cur);
          if (i >= 0 && i < pcs.length - 1) use(pcs[i + 1], pcs[i + 1].t0, true);
          else if (!act.paused) act.pause();
        }
      },
    };
    ins.addEventListener('ended', () => api.tick());
    live.addEventListener('ended', () => api.tick());
    return api;
  }
  // velocita' in anteprima: il video (e i suoni) vanno alla velocita' del pezzo dove sta la testina
  function applySpeed() {
    const r = Math.max(0.0625, Math.min(16, speedAt(video.currentTime) * (typeof viewRate === 'number' ? viewRate : 1)));   // il browser accetta fino a 16x
    if (Math.abs(video.playbackRate - r) > 1e-3) video.playbackRate = r;
    for (const a of sounds.values()) if (Math.abs(a.playbackRate - r) > 1e-3) a.playbackRate = r;
  }

  // ---------------------------------------------------------------- DOM: anteprima
  // formati che l'anteprima non sa leggere (H.265, AV1…): si usa una copia leggera convertita una volta sola
  const PREVIEW_OK = ['h264', 'vp8', 'vp9'];
  let compat = !!(proj.vcodec && !PREVIEW_OK.includes(proj.vcodec));
  const COMPAT_H = Math.min(720, H);
  const liveVid = h('video', { src: compat ? null : mediaUrl(proj.source), preload: 'auto', playsinline: true });
  const video = makePlayer(liveVid);
  const veil = h('div', { class: 'cutveil', style: { display: 'none' } }, KIND === 'blank' ? 'Trascina un video nella timeline o aggiungi un testo per iniziare' : 'Questa parte verrà tagliata');
  const loadingTxt = h('span', null, compat ? 'Preparo l\'anteprima…' : 'Carico il video…');
  const loading = h('div', { class: 'cutveil', style: { gap: '10px', flexDirection: 'column', textAlign: 'center' } }, h('div', { class: 'spinner' }), loadingTxt);
  let videoReady = false, strip = null;
  function onReady() {
    if (videoReady) return;
    videoReady = true; loading.remove(); playBtn.disabled = false;
    setTimeout(loadStrip, 300);
  }
  async function loadStrip() {
    if (!alive) return;
    try {
      const s = await get(`/api/p/${pid}/strip`);
      if (s.ready) { strip = s; drawThumbs(); return; }
    } catch (e) { /* riprova */ }
    setTimeout(loadStrip, 1500);
  }
  // anteprima alla qualita' scelta: copia leggera del VOD preparata in background (piu' fluida sui PC lenti)
  let curSrc = compat ? '' : 'orig', proxyTimer = 0, proxyWant = 0;
  async function applyQuality() {
    // qualita' dell'anteprima (separata da quella del video finale): Auto = 720p se il VOD e' piu' grande
    const pq = proj.settings.previewQ || 'auto';
    let q = pq === 'orig' ? H : pq === 'auto' ? (H > 760 ? 720 : H) : Math.min(H, parseInt(pq, 10) || H);
    if (compat) q = Math.min(q, COMPAT_H);
    if (BLANK && !compat) q = H;   // progetto vuoto: il fondo e' nero, leggero: niente copia per l'anteprima
    clearTimeout(proxyTimer);
    if (!compat && q >= H - 8) { proxyWant = 0; badgeQ.style.display = 'none'; if (curSrc !== 'orig') swapSrc(mediaUrl(proj.source), 'orig'); return; }
    proxyWant = q;
    try {
      const r = await get(`/api/p/${pid}/proxy?h=${q}`);
      if (!alive || proxyWant !== q) return;
      if (r.ready) { badgeQ.textContent = 'Anteprima ' + q + 'p'; badgeQ.style.display = ''; if (curSrc !== r.path) swapSrc(mediaUrl(r.path), r.path); return; }
      if (r.error) { badgeQ.style.display = 'none'; toast('Anteprima ' + q + 'p non riuscita: ' + r.error, true); return; }
      if (r.changed) {
        // stesso nome, video diverso: l'anteprima vecchia mostrava un video e l'esportazione ne avrebbe usato un altro
        if (r.changed.different) toast(`Attenzione: il file "${r.changed.name}" sul PC è diverso da quello con cui hai creato il progetto (dura ${fmtDur(r.changed.dur)} invece di ${fmtDur(r.changed.projDur)}). Forse l'hai sostituito con un altro video con lo stesso nome: l'esportazione usa il file attuale.`, true);
        else toast('Il video di questo progetto è stato modificato sul PC: rifaccio l\'anteprima.');
      }
      const pc = Math.round(((r.job && r.job.progress) || 0) * 100);
      badgeQ.textContent = `Preparo l'anteprima ${q}p · ${pc}%`; badgeQ.style.display = '';
      if (compat && !videoReady) loadingTxt.replaceChildren(`Preparo l'anteprima · ${pc}%`, h('br'), h('small', { style: { opacity: '.7' } }, 'Questo formato video va convertito una volta sola per vederlo qui. Intanto puoi già lavorare sulla timeline.'));
      proxyTimer = setTimeout(applyQuality, 1500);
    } catch (e) { badgeQ.style.display = 'none'; }
  }
  function swapSrc(url, key) {
    const t = video.currentTime, playing = !video.paused;
    curSrc = key;
    video.src = url;
    video.addEventListener('loadedmetadata', () => { video.currentTime = t; if (playing) video.play().catch(() => {}); frame(true); }, { once: true });
  }
  const subSpan = h('span');
  const subBox = h('div', { class: 'sub', style: { display: 'none' } }, subSpan);
  const badgeMain = h('div', { class: 'badge' }, 'Originale');
  const badgeMute = h('div', { class: 'badge red', style: { display: 'none' } }, 'Audio muto');
  const frameBox = h('div', { class: 'framebox', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }),
    h('button', { class: 'btn sm primary framedone', onclick: (ev) => { ev.stopPropagation(); framing = false; renderPanel(); frame(true); } }, 'Fatto'));
  // in verticale il riquadro e' stretto: il "Fatto" sta in basso al centro dell'anteprima
  const frameDoneBar = h('button', { class: 'btn primary framedonebar', style: { display: 'none' }, onclick: (ev) => { ev.stopPropagation(); framing = false; renderPanel(); frame(true); } }, icon('check', 14, '#fff', 2.4), 'Fatto');
  const badgeQ = h('div', { class: 'badge', style: { display: 'none' } });
  // livelli: quello che sta in "zg" viene ingrandito dallo zoom, il resto resta fermo sopra
  // filtri: disegnati sopra il video, dentro lo zoom (la maschera segue l'inquadratura)
  const fxCanvas = h('canvas', { class: 'fxcanvas', style: { display: 'none' } });
  const fxr = new FxRenderer(fxCanvas, W, H);
  const maskView = h('canvas', { class: 'maskview', style: { display: 'none' } });
  const maskBox = h('div', { class: 'maskbox', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }));
  const paintLayer = h('div', { class: 'paintlayer', style: { display: 'none' } });
  const brushCur = h('div', { class: 'brushcur', style: { display: 'none' } });
  const zg = h('div', { class: 'zg' }, liveVid, video.insEl, fxCanvas, maskView, maskBox, paintLayer, brushCur);
  const subLayer = h('div', { class: 'layer' }, subBox);
  // sottotitoli nell'anteprima: stessi valori del video esportato
  let subCur = null, subWordEls = [], subHi = -1;
  function applySubStyle() {
    const st = proj.subStyle, sh = screen.clientHeight || 1;
    const fs = st.size * sh, css = fs / (FONT_RATIO[st.font] || 1.15), pad = 0.18 * fs;
    Object.assign(subSpan.style, {
      fontFamily: `"${st.font}", Arial, sans-serif`, fontSize: css + 'px', fontWeight: st.bold ? '700' : '400', color: st.color,
      textTransform: st.upper ? 'uppercase' : 'none', lineHeight: '1.18',
      textShadow: textShadowFor(st, fs),
      background: st.box ? hexA(st.boxColor, (st.boxOp ?? 70) / 100) : 'transparent',
      padding: st.box ? `${pad.toFixed(1)}px` : '0', borderRadius: st.box ? '2px' : '0',
    });
    subBox.style.bottom = `calc(${((1 - st.y) * 100).toFixed(2)}% - ${st.box ? pad.toFixed(1) : 0}px)`;
    subBox.style.top = 'auto';
    subCur = null;
  }
  // contorno come ombre tutto intorno (uguale in ogni browser) + ombra
  function outlineShadow(w, color) {
    const n = Math.max(12, Math.round(w * 6)), out = [];
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; out.push(`${(Math.cos(a) * w).toFixed(2)}px ${(Math.sin(a) * w).toFixed(2)}px 0 ${color}`); }
    return out;
  }
  function textShadowFor(st, fs) {
    const parts = st.stroke ? outlineShadow(st.strokeW * fs, st.strokeColor) : [];
    if (st.shadow) { const d = 0.06 * fs + (st.stroke ? st.strokeW * fs * 0.7 : 0); parts.push(`${d.toFixed(1)}px ${d.toFixed(1)}px 0 rgba(0,0,0,.5)`); }
    return parts.length ? parts.join(',') : 'none';
  }
  // parola censurata: prima e ultima lettera, asterischi in mezzo (come nel video esportato)
  function censWord(x) { return x.length <= 1 ? x + '*' : x[0] + '*'.repeat(Math.max(1, x.length - 2)) + (x.length > 2 ? x[x.length - 1] : ''); }
  function hexA(hex, a) {
    let x = (hex || '#000').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
    return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
  }
  function showSub(t, inCut) {
    if (!proj.settings.showSubs || inCut || !allWords().length) { subBox.style.display = 'none'; subCur = null; return; }
    const list = subChunks();
    let lo = 0, hi = list.length - 1, k = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (list[m].a <= t) { k = m; lo = m + 1; } else hi = m - 1; }
    const ch = k >= 0 && t < list[k].b && !list[k].hidden ? list[k] : null;
    if (!ch) { subBox.style.display = 'none'; subCur = null; return; }
    const st = proj.subStyle;
    if (ch !== subCur) {
      subCur = ch; subHi = -1;
      subWordEls = ch.words.map((w) => h('span', null, w.cens ? censWord(w.w) : w.w));
      subSpan.replaceChildren(...subWordEls.flatMap((e, i) => (i ? [' ', e] : [e])));
      subBox.style.display = 'flex';
      if (st.effect === 'pop') { subSpan.classList.remove('pop'); void subSpan.offsetWidth; subSpan.classList.add('pop'); } else subSpan.classList.remove('pop');
    }
    if (st.effect === 'highlight') {
      let wi = 0;
      for (let i = 0; i < ch.words.length; i++) if (ch.words[i].a <= t) wi = i;
      if (wi !== subHi) { subWordEls.forEach((e, i) => { e.style.color = i === wi ? st.hiColor : ''; }); subHi = wi; }
    } else if (subHi !== -1) { subWordEls.forEach((e) => { e.style.color = ''; }); subHi = -1; }
  }
  // trascina i sottotitoli su o giu' nell'anteprima
  subSpan.addEventListener('pointerdown', (ev) => {
    ev.preventDefault(); ev.stopPropagation();
    if (!(sel && sel.type === 'subs')) select({ type: 'subs', id: 'subs' });
    subSpan.setPointerCapture(ev.pointerId);
    begin();
    const y0 = ev.clientY, v0 = proj.subStyle.y, sh = screen.clientHeight;
    const mv = (e) => { proj.subStyle.y = +Math.max(0.12, Math.min(0.99, v0 + (e.clientY - y0) / sh)).toFixed(4); applySubStyle(); };
    const up = () => { subSpan.removeEventListener('pointermove', mv); changed(); };
    subSpan.addEventListener('pointermove', mv);
    subSpan.addEventListener('pointerup', up, { once: true });
  });
  const ovLayerEls = new Map();   // id traccia -> livello
  const ovImgs = new Map();       // id clip -> <img>
  // testi: immagine disegnata subito nel browser, poi salvata sul PC (per l'esportazione)
  const textSrc = new Map(), textUp = new Map(), textRes = new Map(), textPending = new Set();
  // aspetta che i testi siano salvati (al massimo qualche secondo: mai bloccare l'app)
  const textsSaved = () => Promise.race([Promise.all([...textPending]), new Promise((r) => setTimeout(r, 4000))]);
  // logo dei badge: immagine caricata una volta, poi il badge si ridisegna
  const logoImgs = new Map();
  preloadBadgeLogos((pid) => {
    let n = 0;
    ovTracks().forEach((t) => t.clips.forEach((x) => { if (x.text && x.text.badge && x.text.badge.platform === pid && !x.text.badge.logo) { refreshText(x); n++; } }));
    if (n) placeOverlays(video.currentTime);
  });
  function logoFor(c) {
    const path = c.text && c.text.badge && c.text.badge.logo;
    if (!path) return null;
    let im = logoImgs.get(path);
    if (!im) {
      im = new Image(); logoImgs.set(path, im);
      im.onload = () => { ovTracks().forEach((t) => t.clips.forEach((x) => { if (x.text && x.text.badge && x.text.badge.logo === path) refreshText(x); })); placeOverlays(video.currentTime); };
      im.src = mediaUrl(path);
    }
    return im.complete && im.naturalWidth ? im : null;
  }
  function refreshText(c) {
    // font non ancora caricato (incluso in VODcut o aggiunto dall'utente): si ridisegna appena e' pronto
    if (c.text && c.text.font && !fontReady(c.text.font)) ensureFont(c.text.font).then((ok) => { if (ok && alive) { refreshText(c); frame(true); } });
    const cv = drawText(c.text, H, logoFor(c));
    const natW = cv.width / CW(), ar = cv.height / cv.width;
    if (c.natW && Math.abs(natW - c.natW) > 1e-6 || (c.ar && Math.abs(ar - c.ar) > 1e-6)) {
      // stessa scala e stesso centro anche se il testo cambia lunghezza
      const k = c.natW ? natW / c.natW : 1;
      for (const o of [c.pos, ...(c.kf || [])]) {
        if (!o) continue;
        const cx = o.x + o.w / 2, cy = o.y + o.w * CA() * (c.ar || ar) / 2;
        o.w = +(o.w * k).toFixed(5); o.x = +(cx - o.w / 2).toFixed(5); o.y = +(cy - o.w * CA() * ar / 2).toFixed(5);
      }
    }
    c.natW = natW; c.ar = ar;
    c.name = c.text.badge ? (platformOf(c.text.badge.platform)[1] + ' · ' + (c.text.badge.handle || '')).slice(0, 40)
      : (String(c.text.content || '').split('\n')[0] || 'Testo').slice(0, 40);
    const p = new Promise((res) => cv.toBlob((b) => {
      const u = URL.createObjectURL(b), old = textSrc.get(c.id);
      textSrc.set(c.id, u); if (old) URL.revokeObjectURL(old);
      clearTimeout(textUp.get(c.id));
      // il salvataggio precedente viene sostituito da questo: chi lo aspettava non deve restare bloccato
      const prev = textRes.get(c.id); if (prev) prev();
      textRes.set(c.id, res);
      textUp.set(c.id, setTimeout(async () => {
        try {
          const r = await fetch(`/api/p/${pid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: b });
          const j = await r.json();
          if (r.ok) { c.file = j.path; dirty = true; scheduleSave(); }
        } catch (e) { /* riprova alla prossima modifica */ }
        if (textRes.get(c.id) === res) textRes.delete(c.id);
        res();
      }, 300));
    }, 'image/png'));
    textPending.add(p); p.then(() => textPending.delete(p));
  }
  function forgetTextPreviews() { textSrc.forEach((u) => URL.revokeObjectURL(u)); textSrc.clear(); }
  const ovBox = h('div', { class: 'framebox ovbox', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }));
  // anteprima verticale: pezzi della live disegnati uno sopra l'altro (come nel video esportato)
  const vstage = h('div', { class: 'vstage', style: { display: 'none' } });
  const screen = h('div', { class: 'screen' }, zg, vstage, veil, frameBox, frameDoneBar, ovBox, h('div', { class: 'badges' }, badgeMain, badgeQ, badgeMute), loading);
  const fxLayers = new Map();   // traccia filtri -> livello
  const fxEls = new Map();   // id filtro -> elemento con backdrop-filter
  function fxLayerOf(id) {
    let el = fxLayers.get(id);
    if (!el) { el = h('div', { class: 'layer fxlayer' }); fxLayers.set(id, el); }
    return el;
  }
  function layerEl(key) {
    if (key === 'subs') return subLayer;
    if (key === 'fx' || key.startsWith('fx:')) return fxLayerOf(key === 'fx' ? 'fx' : key.slice(3));
    const id = key.slice(3);
    let el = ovLayerEls.get(id);
    if (!el) { el = h('div', { class: 'layer' }); ovLayerEls.set(id, el); }
    return el;
  }
  function arrangeLayers() {
    const order = proj.layers.filter((k) => k !== 'video').reverse();   // dal basso verso l'alto
    const zi = order.indexOf('zoom');
    const live = new Set(ovTracks().map((t) => t.id));
    for (const [id, el] of ovLayerEls) if (!live.has(id)) { el.remove(); ovLayerEls.delete(id); }
    order.forEach((k, i) => {
      if (k === 'zoom') return;
      const el = layerEl(k);
      const isFx = k === 'fx' || k.startsWith('fx:');
      if (VERT) { if (isFx) zg.append(el); else screen.insertBefore(el, veil); }   // verticale: filtri sulla live, il resto sullo schermo
      else if (i < zi) zg.append(el); else screen.insertBefore(el, veil);
    });
    // gli strumenti della maschera stanno dove sta il livello dei filtri (dentro o fuori dallo zoom)
    for (const [id, el] of fxLayers) if (!proj.fxTracks.some((t) => t.id === id)) { el.remove(); fxLayers.delete(id); }
    const sf = sel && sel.type === 'fx' ? proj.filters.find((f) => f.id === sel.id) : null;
    const host = fxLayerOf((sf && sf.track) || 'fx').parentNode || zg;
    for (const x of [maskView, maskBox, paintLayer, brushCur]) if (x.parentNode !== host || host.lastChild !== brushCur) host.append(x);
  }
  // filtri: un elemento trasparente per filtro, con backdrop-filter (+ maschera)
  let fxSeed = 1, fxTick = 0;
  const maskURLs = new Map();
  // filtro e colori messi direttamente su una clip video: come filtri sulla traccia principale, sotto gli altri
  function segFilters() {
    const r = [];
    for (const c of proj.segs) {
      if (c.gone || c.removed) continue;
      if (c.fx && c.fx.type) r.push({ id: 'sf_' + c.id, type: c.fx.type, k: c.fx.k ?? 100, a: c.a, b: c.b, track: 'fx', mask: { type: 'all' } });
      if (c.adj && ADJ_KEYS.some(([k]) => c.adj[k])) r.push({ id: 'sa_' + c.id, type: 'adjust', adj: c.adj, k: 100, a: c.a, b: c.b, track: 'fx', mask: { type: 'all' } });
    }
    return r;
  }
  function updateFxLayer(t) {
    const on = [...segFilters(), ...proj.filters].filter((f) => !f.off && t >= f.a && t < f.b);
    const sw = screen.clientWidth || 1, s = sw / W;
    if (!video.paused && ++fxTick % 3 === 0) fxSeed = (fxSeed % 6) + 1;
    const seen = new Set(), idx = new Map();
    on.forEach((f) => {
      seen.add(f.id);
      const lay = fxLayerOf(f.track || 'fx'), i = idx.get(lay) || 0; idx.set(lay, i + 1);
      let el = fxEls.get(f.id);
      if (!el) { el = h('div', { class: 'fxel' }); fxEls.set(f.id, el); }
      if (lay.children[i] !== el) lay.insertBefore(el, lay.children[i] || null);
      const k = Math.max(0, Math.min(1, (f.k ?? 100) / 100));
      const bf = backdropFilter(f.type, k, s, W, H, fxSeed, f.adj);
      if (el.dataset.bf !== bf) { el.dataset.bf = bf; el.style.backdropFilter = bf; el.style.webkitBackdropFilter = bf; }
      const m = f.mask || { type: 'all' };
      let mk = '';
      if (m.type && m.type !== 'all') {
        const key = JSON.stringify(m) + '|' + sw;
        let u = maskURLs.get(f.id);
        if (!u || u.key !== key) {
          const cw = Math.max(2, Math.min(1280, Math.round(sw))), ch = Math.max(2, Math.round(cw * H / W));
          u = { key, url: drawMask(m, cw, ch, W, H).toDataURL('image/png') }; maskURLs.set(f.id, u);
        }
        mk = `url(${u.url})`;
      }
      if (el.dataset.mk !== mk) { el.dataset.mk = mk; el.style.maskImage = mk || 'none'; el.style.webkitMaskImage = mk || 'none'; }
    });
    for (const [id, el] of fxEls) if (!seen.has(id)) { el.remove(); if (!proj.filters.some((f) => f.id === id)) { fxEls.delete(id); maskURLs.delete(id); } }
  }
  // ---------------------------------------------------------------- formato verticale (anteprima)
  // Mentre scegli un'inquadratura o disegni la maschera di un filtro si vede la live intera (orizzontale)
  const vpool = [];
  const vMasks = new Map();
  let lastSV = null;
  const sourceView = () => !!(framing || (tab === 'video' && fxSub === 'mask' && sel && sel.type === 'fx'));
  function applyViewMode() {
    const sv = !VERT || sourceView();
    if (sv === lastSV && screen.classList.contains('vert') === (VERT && !sv)) return;
    lastSV = sv;
    zg.style.opacity = sv ? '' : '0'; zg.style.pointerEvents = sv ? '' : 'none';
    vstage.style.display = sv ? 'none' : '';
    screen.classList.toggle('vert', VERT && !sv);
    const hide = VERT && sv;   // la live intera: testi e sottotitoli (che sono sul verticale) non si vedono
    subLayer.style.visibility = hide ? 'hidden' : '';
    for (const el of ovLayerEls.values()) el.style.visibility = hide ? 'hidden' : '';
    layoutScreen();
  }
  // ---------- viso: nel verticale la webcam ritagliata segue la faccia (analisi fatta dal server)
  let faceData = null, faceJob = null;
  const FSTEP = 0.25;
  function loadFace() {
    if (!VERT || !cam) return Promise.resolve();
    return get(`/api/p/${pid}/face`).then((d) => { faceData = d && d.pts && Object.keys(d.pts).length ? d : null; frame(true); }).catch(() => {});
  }
  const faceOk = () => !!(proj.faceOn && faceData && cam && faceData.cam && faceData.cam.join() === cam.join());
  function faceAt(lt) {
    const pts = faceData.pts, k = lt / FSTEP, i0 = Math.floor(k), p0 = pts[i0], p1 = pts[i0 + 1];
    if (p0 && p1) { const f = k - i0; return [p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f]; }
    return p0 || p1 || null;
  }
  // stessa regola di engine/face.py (shift)
  function faceShift(regs, f) {
    if (!f) return regs;
    const fx = f[0] * W, fy = f[1] * H, [x0, y0, cw, ch] = cam;
    return regs.map((r) => {
      if (r.role !== 'cam' || r.blur) return r;
      const [x, y, w, hh] = r.s;
      const nx = w < cw - 0.5 ? Math.min(Math.max(x0, fx - w / 2), x0 + cw - w) : x;
      const ny = hh < ch - 0.5 ? Math.min(Math.max(y0, fy - hh * 0.45), y0 + ch - hh) : y;
      return { ...r, s: [nx, ny, w, hh] };
    });
  }
  // analisi del viso sulle parti di questa clip (le parti gia' fatte non si rifanno)
  let faceProg = 0, faceErr = '';
  function startFace() {
    if (faceJob) return faceJob;
    faceProg = 0; faceErr = '';
    faceJob = (async () => {
      try {
        const job = await post(`/api/p/${pid}/face`, {});
        const res = await pollJob(job.id, (j) => { faceProg = j.progress || 0; });
        if (res.status === 'error') faceErr = res.error || 'Tracciamento del viso non riuscito';
        await loadFace();
        if (!faceErr && !faceData) faceErr = 'Nessun viso trovato nella webcam di questa clip.';
      } catch (e) { faceErr = 'Tracciamento del viso non riuscito'; }
      finally { faceJob = null; if (alive) renderPanel(); }
    })();
    return faceJob;
  }
  function vRegsAt(t) {
    const el = video.el;
    if (el !== liveVid) return { regs: vertRegions('fit', el.videoWidth || W, el.videoHeight || H, { pad: vertSettings(proj).pad }), el, sx: 1, sy: 1, live: false };
    // impaginazione della clip in questo punto (o quella di tutto il progetto)
    const vs = segVert(t);
    let regs = vertRegions(vs.layout, W, H, { cam, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, boxes: vs.boxes });
    if (faceOk()) regs = faceShift(regs, faceAt(liveVid.currentTime));
    // zoom: la webcam (o l'inquadratura scelta) si allarga a tutto schermo, con l'effetto scelto
    for (const z of proj.zooms) {
      if (z.on === false || !(t >= z.a && t < z.b)) continue;
      const bx = vertZoomBoxes(z, W, H, cam, VA(vs.pad));
      if (!bx) continue;
      regs = vertAnimRegs(regs, bx.box, zoomProgress(t, vertZoom(z)), bx.from, vs.pad);
      break;
    }
    return { regs, el, sx: (el.videoWidth || W) / W, sy: (el.videoHeight || H) / H, live: true };
  }
  function segVert(t, c0) {
    const base = vertSettings(proj);
    const c = c0 || proj.segs.find((x) => t >= x.a && t < x.b);
    if (!c || !c.vlay) return base;
    const v = { ...base, ...c.vlay };
    if ((v.layout === 'split' || v.layout === 'cam') && !cam) v.layout = 'fit';
    return v;
  }
  function drawVertical(t) {
    const { regs, el, sx, sy, live } = vRegsAt(t);
    const sw = screen.clientWidth, sh = screen.clientHeight, dpr = Math.min(2, window.devicePixelRatio || 1);
    while (vpool.length < regs.length) {
      const cv = h('canvas'), fx = h('div', { class: 'vfx' });
      const box = h('div', { class: 'vreg' }, cv, fx);
      vstage.append(box); vpool.push({ box, cv, fx, key: '' });
    }
    vpool.forEach((r, i) => { r.box.style.display = i < regs.length ? '' : 'none'; });
    const on = live ? [...segFilters(), ...proj.filters].filter((f) => !f.off && t >= f.a && t < f.b) : [];
    regs.forEach((rg, i) => {
      const r = vpool[i], [dx, dy, dw, dh] = rg.d, [x, y, w, hh] = rg.s;
      const pw = dw * sw, ph = dh * sh;
      Object.assign(r.box.style, { left: dx * sw + 'px', top: dy * sh + 'px', width: pw + 'px', height: ph + 'px' });
      const cw = Math.max(2, Math.round(pw * dpr)), ch = Math.max(2, Math.round(ph * dpr));
      if (r.cv.width !== cw || r.cv.height !== ch) { r.cv.width = cw; r.cv.height = ch; }
      const g = r.cv.getContext('2d');
      g.filter = rg.blur ? `blur(${Math.max(3, Math.min(cw, ch) / 22 * 0.8).toFixed(1)}px) brightness(0.93)` : 'none';
      try { if (el.readyState >= 2) g.drawImage(el, x * sx, y * sy, w * sx, hh * sy, 0, 0, cw, ch); } catch (e) { /* frame non pronto */ }
      // filtri: gli stessi dell'anteprima normale, sopra questo pezzo (sulla live intera, come nell'export)
      const k = pw / w;
      const showFx = live && !rg.blur && on.length;
      Object.assign(r.fx.style, { display: showFx ? '' : 'none', left: -x * k + 'px', top: -y * k + 'px', width: W * k + 'px', height: H * k + 'px' });
      if (!showFx) { if (r.key) { r.fx.replaceChildren(); r.key = ''; } return; }
      const key = on.map((f) => f.id + f.type + (f.k ?? 100) + JSON.stringify(f.mask || 0) + JSON.stringify(f.adj || 0)).join('|') + '|' + k.toFixed(4) + '|' + fxSeed;
      if (r.key === key) return;
      r.key = key;
      r.fx.replaceChildren(...on.map((f) => {
        const d = h('div', { class: 'fxel' });
        const bf = backdropFilter(f.type, Math.max(0, Math.min(1, (f.k ?? 100) / 100)), k, W, H, fxSeed, f.adj);
        d.style.backdropFilter = bf; d.style.webkitBackdropFilter = bf;
        const m = f.mask || { type: 'all' };
        if (m.type && m.type !== 'all') {
          const mk = JSON.stringify(m);
          let u = vMasks.get(f.id);
          if (!u || u.key !== mk) { u = { key: mk, url: drawMask(m, 640, Math.round(640 * H / W), W, H).toDataURL('image/png') }; vMasks.set(f.id, u); }
          d.style.maskImage = d.style.webkitMaskImage = `url(${u.url})`;
        }
        return d;
      }));
    });
  }
  function placeOverlays(t) {
    const seen = new Set();
    for (const tr of ovTracks()) {
      const lay = layerEl('ov:' + tr.id);
      for (const c of tr.clips) {
        seen.add(c.id);
        let img = ovImgs.get(c.id);
        const on = !tr.hidden && t >= c.a && t < c.a + c.dur;
        const isVid = c.kind === 'video';
        if (!img) {
          if (!on) continue;
          img = isVid ? h('video', { class: 'ovimg ovvid', preload: 'auto', playsinline: true, draggable: 'false' }) : h('img', { class: 'ovimg', alt: '', draggable: 'false' });
          img.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); ev.preventDefault(); if (!(sel && sel.id === img.dataset.cid)) select({ type: 'sclip', id: img.dataset.cid }); startOvDrag(ev, 'move', img); });
          ovImgs.set(c.id, img);
        }
        img.dataset.cid = c.id;
        const want = textSrc.get(c.id) || (c.file ? mediaUrl(c.file) : '');
        if (want && img.dataset.src !== want) { img.dataset.src = want; img.src = want; }
        if (img.parentNode !== lay) lay.append(img);
        img.style.display = on ? 'block' : 'none';
        if (on) {
          const st = imgFinal(c, t - c.a, CA());
          // posto fisso (quello di base) + spostamento/scala con transform: niente scatti di un pixel negli zoom lenti
          const b = c.pos && c.pos.w ? c.pos : st, sw = screen.clientWidth, sh = screen.clientHeight;
          const bl = b.x * 100 + '%', bt = b.y * 100 + '%', bw = b.w * 100 + '%';
          if (img.style.left !== bl) img.style.left = bl;
          if (img.style.top !== bt) img.style.top = bt;
          if (img.style.width !== bw) img.style.width = bw;
          const k = st.w / b.w, ar = c.ar || 1, bh = b.w * CA() * ar, hh = st.w * CA() * ar;
          const dx = ((st.x + st.w / 2) - (b.x + b.w / 2)) * sw, dy = ((st.y + hh / 2) - (b.y + bh / 2)) * sh;
          img.style.opacity = String(Math.max(0, Math.min(1, st.op / 100)));
          img.style.transform = `translate(${dx.toFixed(3)}px, ${dy.toFixed(3)}px) scale(${k.toFixed(5)}) ` + imgCss(st, sw / k);
        }
        if (isVid) syncOvVideo(img, c, tr, t, on);
      }
    }
    for (const [id, img] of ovImgs) if (!seen.has(id)) { img.remove(); ovImgs.delete(id); }
    // riquadro per spostare/ridimensionare l'immagine selezionata
    const c = sel && sel.type === 'sclip' ? findSel() : null;
    const img = c && (c.kind === 'image' || c.kind === 'video') ? ovImgs.get(c.id) : null;
    if (img && img.style.display !== 'none' && !framing) {
      const r = img.getBoundingClientRect(), sr = screen.getBoundingClientRect();
      Object.assign(ovBox.style, { display: 'block', left: r.left - sr.left + 'px', top: r.top - sr.top + 'px', width: r.width + 'px', height: r.height + 'px' });
    } else if (ovBox.style.display !== 'none') ovBox.style.display = 'none';
  }
  // video in sovrimpressione: segue la testina (tempo, velocita', volume)
  function syncOvVideo(el, c, tr, t, on) {
    el.style.aspectRatio = String(1 / (c.ar || 9 / 16));
    if (!on) { if (!el.paused) el.pause(); return; }
    const target = (c.offset || 0) + (t - c.a);
    const v = tr.mute || c.mute || !c.hasAudio ? 0 : Math.max(0, Math.min(1, ((tr.vol ?? 100) / 100) * ((c.vol ?? 100) / 100)));
    el.volume = v; el.muted = v === 0;
    if (Math.abs(el.playbackRate - video.playbackRate) > 1e-3) el.playbackRate = video.playbackRate;
    if (video.paused) { if (!el.paused) el.pause(); if (Math.abs(el.currentTime - target) > 0.04) el.currentTime = target; }
    else if (el.paused) { el.currentTime = target; el.play().catch(() => {}); }
    else if (Math.abs(el.currentTime - target) > 0.3) el.currentTime = target;
  }
  let ovDrag = null;
  function startOvDrag(ev, mode, img) {
    const c = findSel(); if (!c || (c.kind !== 'image' && c.kind !== 'video')) return;
    const target = ev.currentTarget;
    target.setPointerCapture(ev.pointerId);
    begin();
    const s0 = imgStateAt(c, Math.max(0, Math.min(c.dur, video.currentTime - c.a)));
    const sw = screen.clientWidth, sh = screen.clientHeight;
    // quanto e' ingrandita l'anteprima in questo momento (zoom attivo)
    const zs = zg.contains(img) ? Math.max(0.2, zg.getBoundingClientRect().width / sw) : 1;
    const ar = c.ar || 9 / 16;
    ovDrag = { mode, x: ev.clientX, y: ev.clientY, s0 };
    const mv = (e) => {
      if (!ovDrag) return;
      const it = findSel(); if (!it) return;
      const dx = (e.clientX - ovDrag.x) / (sw * zs), dy = (e.clientY - ovDrag.y) / (sh * zs);
      const p = ovDrag.s0;
      if (ovDrag.mode === 'move') {
        const nx = p.x + dx, ny = p.y + dy;
        const [sx2, sy2] = snapRect([nx, ny, p.w, p.w * CA() * ar], e.altKey);
        setProps(it, { x: nx + sx2, y: ny + sy2 });
      }
      else {
        const sx = ovDrag.mode.includes('w') ? -1 : 1;
        const nw = Math.max(0.02, Math.min(3, p.w + sx * dx));
        const hf0 = p.w * CA() * ar, hf1 = nw * CA() * ar;
        setProps(it, { w: nw, x: ovDrag.mode.includes('w') ? p.x + p.w - nw : p.x, y: ovDrag.mode.includes('n') ? p.y + hf0 - hf1 : p.y });
      }
      placeOverlays(video.currentTime);
    };
    const up = () => { target.removeEventListener('pointermove', mv); ovDrag = null; hideSnap(); changed(); };
    target.addEventListener('pointermove', mv);
    target.addEventListener('pointerup', up, { once: true });
  }

  // ---------------------------------------------------------------- guide, calamite, clip spostate a mano
  // guide: linee sull'anteprima (non finiscono nel video), una lista per il formato orizzontale e una per il verticale
  const guideLayer = h('div', { class: 'guides' });
  const snapV = h('div', { class: 'snapline v' }), snapH = h('div', { class: 'snapline h' });
  const tfLayer = h('div', { class: 'tflayer' });
  proj.guides = proj.guides || {};
  let guidesOn = true, snapObj = store.get('snapObj', true);
  const fmtKey = () => (VERT ? 'v' : 'h');
  const guidesOf = () => (proj.guides[fmtKey()] = proj.guides[fmtKey()] || []);
  let guideKey = '';
  let guideDrag = false;
  function drawGuides(force) {
    if (guideDrag && !force) return;
    const key = fmtKey() + JSON.stringify(guidesOf()) + guidesOn + sourceView();
    if (!force && key === guideKey) return;
    guideKey = key;
    guideLayer.replaceChildren();
    guideLayer.style.display = guidesOn && !sourceView() ? '' : 'none';
    guidesOf().forEach((g) => {
      const el = h('div', { class: 'guide ' + g.o, style: g.o === 'v' ? { left: g.p * 100 + '%' } : { top: g.p * 100 + '%' }, 'data-tip': 'Trascinala dove vuoi (al centro si aggancia) · fuori dall\'anteprima per toglierla' });
      if (g.p === 0.5) el.classList.add('mid');
      el.addEventListener('pointerdown', (e) => {
        e.preventDefault(); e.stopPropagation(); el.setPointerCapture(e.pointerId); begin();
        const r = screen.getBoundingClientRect();
        let out = false;
        guideDrag = true; el.classList.add('drag');
        const mv = (ev) => {
          const q = g.o === 'v' ? (ev.clientX - r.left) / r.width : (ev.clientY - r.top) / r.height;
          out = q < -0.03 || q > 1.03;
          g.p = +Math.max(0, Math.min(1, q)).toFixed(4);
          // la guida va dove vuoi, ma vicino al centro la calamita la rimette esatta al centro
          const snapped = !ev.altKey && Math.abs(g.p - 0.5) < 10 / (g.o === 'v' ? r.width : r.height);
          if (snapped) g.p = 0.5;
          el.classList.toggle('mid', snapped);
          el.style[g.o === 'v' ? 'left' : 'top'] = g.p * 100 + '%';
          el.classList.toggle('out', out);
        };
        const up = () => {
          el.removeEventListener('pointermove', mv);
          guideDrag = false;
          if (out) { const L = guidesOf(); L.splice(L.indexOf(g), 1); }
          dirty = true; scheduleSave(); drawGuides(true);
        };
        el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up, { once: true });
      });
      guideLayer.append(el);
    });
  }
  function addGuide(o) { begin(); guidesOf().push({ o, p: 0.5 }); guidesOn = true; dirty = true; scheduleSave(); drawGuides(true); toast('Guida aggiunta al centro: trascinala dove ti serve'); }
  const guideBtn = ibtn('guides', 'Guide e calamite dell\'anteprima', (e) => popMenu(e.currentTarget, [
    ['guides', 'Aggiungi una guida verticale', 'Una linea dall\'alto in basso', () => addGuide('v')],
    ['guides', 'Aggiungi una guida orizzontale', 'Una linea da sinistra a destra', () => addGuide('h')],
    [guidesOn ? 'eyeOff' : 'eye', guidesOn ? 'Nascondi le guide' : 'Mostra le guide', null, () => { guidesOn = !guidesOn; drawGuides(true); }],
    ['trash', 'Togli tutte le guide', null, () => { begin(); proj.guides[fmtKey()] = []; dirty = true; scheduleSave(); drawGuides(true); }],
    ['magnet', snapObj ? 'Calamite: accese' : 'Calamite: spente', 'Gli oggetti si agganciano al centro, ai bordi e alle guide (Alt per staccarli)', () => { snapObj = !snapObj; store.set('snapObj', snapObj); toast(snapObj ? 'Calamite accese' : 'Calamite spente'); }],
  ]), { size: 18 });
  // calamite: r = [x, y, w, h] (0..1 dello schermo) -> spostamento per agganciarsi a centro, bordi e guide
  function snapRect(r, off) {
    snapV.style.display = snapH.style.display = 'none';
    if (!snapObj || off) return [0, 0];
    const sw = screen.clientWidth || 1, sh = screen.clientHeight || 1, tx = 7 / sw, ty = 7 / sh;
    const gs = guidesOn ? guidesOf() : [];
    const xs = [0, 0.5, 1, ...gs.filter((g) => g.o === 'v').map((g) => g.p)], ys = [0, 0.5, 1, ...gs.filter((g) => g.o === 'h').map((g) => g.p)];
    const best = (vals, pts, th) => { let b = null; for (const v of vals) for (const q of pts) { const d = v - q; if (Math.abs(d) < th && (!b || Math.abs(d) < Math.abs(b.d))) b = { d, v }; } return b; };
    const bx = best(xs, [r[0], r[0] + r[2] / 2, r[0] + r[2]], tx), by = best(ys, [r[1], r[1] + r[3] / 2, r[1] + r[3]], ty);
    if (bx) { snapV.style.display = 'block'; snapV.style.left = bx.v * 100 + '%'; }
    if (by) { snapH.style.display = 'block'; snapH.style.top = by.v * 100 + '%'; }
    return [bx ? bx.d : 0, by ? by.d : 0];
  }
  const hideSnap = () => { snapV.style.display = snapH.style.display = 'none'; };

  // clip spostata/ingrandita a mano: orizzontale c.tf = {s, x, y}; verticale c.vlay.boxes[pezzo] = [x, y, w]
  const segAtT = (t) => proj.segs.find((c) => !c.gone && t >= c.a && t < c.b);
  const tfOf = (c) => ({ s: 1, x: 0, y: 0, ...((c && c.tf) || {}) });
  let tfKey = '';
  let zoomNow = null;   // zoom della webcam in corso (trasformazione di .zg)
  function applyTf(t) {
    const tf = VERT ? { s: 1, x: 0, y: 0 } : tfOf(segAtT(t));
    const sw = screen.clientWidth, sh = screen.clientHeight;
    const bx = ((1 - tf.s) / 2 + tf.x) * sw, by = ((1 - tf.s) / 2 + tf.y) * sh;   // dove sta la clip (angolo in alto a sinistra)
    let ox = bx, oy = by, clip = '';
    // con lo zoom: prima si ingrandisce la webcam, poi la clip va al suo posto (come nel video esportato).
    // .zg e' gia' ingrandito, quindi qui si compensa (Z^-1 · T · Z) e si ritaglia al riquadro della clip
    if (zoomNow && !VERT && (tf.s !== 1 || tf.x || tf.y)) {
      const S = zoomNow.s, tx = zoomNow.tx, ty = zoomNow.ty;
      ox = ((tf.s - 1) * tx + bx) / S; oy = ((tf.s - 1) * ty + by) / S;
      const lx0 = ((bx - tx) / S - ox) / tf.s, lx1 = ((bx + tf.s * sw - tx) / S - ox) / tf.s;
      const ly0 = ((by - ty) / S - oy) / tf.s, ly1 = ((by + tf.s * sh - ty) / S - oy) / tf.s;
      clip = `inset(${ly0.toFixed(1)}px ${(sw - lx1).toFixed(1)}px ${(sh - ly1).toFixed(1)}px ${lx0.toFixed(1)}px)`;
    }
    const tr = tf.s === 1 && !tf.x && !tf.y ? '' : `translate(${ox.toFixed(2)}px, ${oy.toFixed(2)}px) scale(${tf.s})`;
    if (tr + clip === tfKey) return;
    tfKey = tr + clip;
    for (const el of [liveVid, video.insEl, fxCanvas]) if (el) { el.style.transform = tr; el.style.clipPath = clip; }
  }
  const tfPool = [];
  let tfDrag = null, tfActive = null;   // nel verticale si lavora su un pezzo alla volta (webcam o gioco)
  // il riquadro disegnato resta dentro lo schermo: gli angoli si possono sempre prendere anche se il pezzo esce
  const clipR = (r) => { const x0 = Math.max(0, r[0]), y0 = Math.max(0, r[1]), x1 = Math.min(1, r[0] + r[2]), y1 = Math.min(1, r[1] + r[3]); return [x0, y0, Math.max(0.02, x1 - x0), Math.max(0.02, y1 - y0)]; };
  function placeBox(b, r) {
    const q = clipR(r);
    Object.assign(b.style, { left: q[0] * 100 + '%', top: q[1] * 100 + '%', width: q[2] * 100 + '%', height: q[3] * 100 + '%' });
    b.classList.toggle('cut', q[0] !== r[0] || q[1] !== r[1] || Math.abs(q[2] - r[2]) > 1e-6 || Math.abs(q[3] - r[3]) > 1e-6);
    b.classList.toggle('edge', q[0] < 0.005 || q[1] < 0.005 || q[0] + q[2] > 0.995 || q[1] + q[3] > 0.995);
  }
  // la clip selezionata, se la testina e' dentro (si modifica quella che vedi)
  function editTarget() {
    if (!sel || !isSeg(sel.type) || framing || sourceView()) return null;
    const c = findSel(), t = video.currentTime;
    if (!c || c.gone || c.removed || (BLANK && !c.ins) || !(t >= c.a - 1e-3 && t < c.b)) return null;
    return c;
  }
  // parte del quadro occupata davvero dalla clip (una foto quadrata in un video 9:16 non e' tutto il quadro):
  // il riquadro per spostarla/ingrandirla e' quello, non tutto lo schermo
  function contentFrac(c) {
    const rec = c && c.ins ? insById(c.ins) : null;
    const ar = rec ? (rec.image ? rec.iar : (rec.w && rec.h ? rec.w / rec.h : 0)) : 0;
    if (!ar || !W || !H) return [1, 1];
    const A = W / H;
    return Math.abs(ar - A) < 0.01 ? [1, 1] : ar > A ? [1, A / ar] : [ar / A, 1];
  }
  function segBox(c) {
    const tf = tfOf(c), [fw, fh] = contentFrac(c);
    return [(1 - fw * tf.s) / 2 + tf.x, (1 - fh * tf.s) / 2 + tf.y, fw * tf.s, fh * tf.s];
  }
  function tfBoxes(t) {
    const c = editTarget(); if (!c) return [];
    if (!VERT) return [{ key: 'tf', r: segBox(c) }];
    if (video.el !== liveVid) return [];
    if (proj.zooms.some((z) => z.on !== false && t >= z.a && t < z.b && zoomProgress(t, vertZoom(z)) > 0.001)) return [];   // durante lo zoom si muovono da soli
    const vs = segVert(t, c);
    return vertRegions(vs.layout, W, H, { cam, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, boxes: vs.boxes })
      .filter((r) => !r.blur && r.role).map((r) => ({ key: r.role, r: r.d }));
  }
  const TF_NAME = { tf: '', cam: 'Webcam', game: 'Gioco', main: 'Video' };
  function updateTfUI(t) {
    if (tfDrag) return;
    const list = tfBoxes(t);
    while (tfPool.length < list.length) {
      const b = h('div', { class: 'tfbox' }, h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
        h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }), h('span', { class: 'tflbl' }));
      b.addEventListener('pointerdown', (e) => startTfDrag(e, b, b.dataset.key, e.target.dataset.h || 'move'));
      tfLayer.append(b); tfPool.push(b);
    }
    if (tfActive && !list.some((x) => x.key === tfActive)) tfActive = null;
    if (list.length === 1) tfActive = list[0].key;
    tfPool.forEach((b, i) => {
      const it = list[i];
      if (!it) { b.style.display = 'none'; return; }
      b.dataset.key = it.key; b.style.display = '';
      placeBox(b, it.r);
      b.classList.toggle('idle', it.key !== tfActive);
      b.lastChild.textContent = TF_NAME[it.key] || '';
    });
  }
  function setBox(c, key, r) {
    if (key === 'tf') { const [fw, fh] = contentFrac(c), s2 = Math.max(0.05, Math.min(30, r[2] / fw)); c.tf = { s: +s2.toFixed(4), x: +(r[0] - (1 - fw * s2) / 2).toFixed(4), y: +(r[1] - (1 - fh * s2) / 2).toFixed(4) }; if (Math.abs(c.tf.s - 1) < 1e-3 && Math.abs(c.tf.x) < 1e-3 && Math.abs(c.tf.y) < 1e-3) delete c.tf; return; }
    const vs = segVert(0, c);
    const boxes = { ...(vs.boxes || {}), [key]: [+r[0].toFixed(4), +r[1].toFixed(4), +r[2].toFixed(4)] };
    c.vlay = { layout: vs.layout, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, ...(c.vlay || {}), boxes };
  }
  function startTfDrag(e, el, key, mode) {
    if (e.button !== 0) return;
    // sopra c'e' un'immagine o un testo: si prende quello
    if (mode === 'move') {
      const under = document.elementsFromPoint(e.clientX, e.clientY).find((x) => x.classList && x.classList.contains('ovimg'));
      if (under && under.dataset.cid) { e.preventDefault(); e.stopPropagation(); select({ type: 'sclip', id: under.dataset.cid }); startOvDrag(e, 'move', under); return; }
    }
    e.preventDefault(); e.stopPropagation();
    const c = editTarget(); if (!c) return;
    const box = tfBoxes(video.currentTime).find((b) => b.key === key); if (!box) return;
    if (tfActive !== key) { tfActive = key; mode = 'move'; tfPool.forEach((b) => b.classList.toggle('idle', b.dataset.key !== key)); }
    el.setPointerCapture(e.pointerId);
    begin();
    const sw = screen.clientWidth, sh = screen.clientHeight, r0 = box.r.slice();
    tfDrag = { x: e.clientX, y: e.clientY };
    const mv = (ev) => {
      const dx = (ev.clientX - tfDrag.x) / sw, dy = (ev.clientY - tfDrag.y) / sh;
      let r;
      if (mode === 'move') {
        r = [r0[0] + dx, r0[1] + dy, r0[2], r0[3]];
        const [sx2, sy2] = snapRect(r, ev.altKey); r[0] += sx2; r[1] += sy2;
      } else {
        // angolo: si ingrandisce tenendo fermo l'angolo opposto, stessa forma
        const ax = mode.includes('w') ? r0[0] + r0[2] : r0[0], ay = mode.includes('n') ? r0[1] + r0[3] : r0[1];
        const k = Math.max(0.08, (mode.includes('w') ? r0[2] - dx : r0[2] + dx) / r0[2]);
        const nw = r0[2] * k, nh = r0[3] * k;
        r = [mode.includes('w') ? ax - nw : ax, mode.includes('n') ? ay - nh : ay, nw, nh];
      }
      setBox(c, key, r);
      placeBox(el, r);
      frame(true);
    };
    const up = () => { el.removeEventListener('pointermove', mv); tfDrag = null; hideSnap(); changed(); frame(true); };
    el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up, { once: true });
  }
  // rotellina sull'anteprima: ingrandisce la clip selezionata (o il pezzo sotto il mouse)
  let wheelT = 0;
  function onScreenWheel(e) {
    const c = editTarget(); if (!c) return;
    const r = screen.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    const boxes = tfBoxes(video.currentTime);
    const hit = boxes.find((b) => b.key === tfActive) || boxes.slice().reverse().find((b) => px >= b.r[0] && px <= b.r[0] + b.r[2] && py >= b.r[1] && py <= b.r[1] + b.r[3]) || (boxes.length === 1 ? boxes[0] : null);
    if (!hit) return;
    e.preventDefault();
    if (Date.now() - wheelT > 700) begin();
    wheelT = Date.now();
    const k = e.deltaY < 0 ? 1.05 : 1 / 1.05, b = hit.r, cx = b[0] + b[2] / 2, cy = b[1] + b[3] / 2;
    setBox(c, hit.key, [cx - b[2] * k / 2, cy - b[3] * k / 2, b[2] * k, b[3] * k]);
    dirty = true; scheduleSave(); frame(true);
    clearTimeout(onScreenWheel.tm); onScreenWheel.tm = setTimeout(() => { renderTimeline(); renderPanel(); }, 400);
  }
  // clic sul video nell'anteprima: seleziona la clip che si vede e si puo' trascinare subito
  function onScreenDown(e) {
    if (e.button !== 0 || framing || sourceView()) return;
    if (e.target.closest('.tfbox, .ovimg, .framebox, .guide, .badges, button, .maskbox, .paintlayer, .framedonebar')) return;
    const t = video.currentTime, c = segAtT(t);
    if (!c || c.removed || (BLANK && !c.ins)) return;   // progetto vuoto: il nero di base e' lo sfondo, non una clip
    if (!VERT) {   // clic sul nero intorno alla foto/al video: non e' la clip
      const r0 = screen.getBoundingClientRect(), qx = (e.clientX - r0.left) / r0.width, qy = (e.clientY - r0.top) / r0.height, b0 = segBox(c);
      if (qx < b0[0] || qx > b0[0] + b0[2] || qy < b0[1] || qy > b0[1] + b0[3]) return;
    }
    if (!(sel && sel.type === 'seg' && sel.id === c.id)) { sel = { type: 'seg', id: c.id }; multi = []; tab = 'video'; renderTimeline(); renderPanel(); }
    updateTfUI(t);
    const r = screen.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    const boxes = tfBoxes(t);
    const hit = boxes.slice().reverse().find((b) => px >= b.r[0] && px <= b.r[0] + b.r[2] && py >= b.r[1] && py <= b.r[1] + b.r[3]);
    if (!hit) { if (tfActive && boxes.length > 1) { tfActive = null; updateTfUI(t); } return; }
    const el = tfPool.find((b) => b.dataset.key === hit.key && b.style.display !== 'none');
    if (el) startTfDrag(e, el, hit.key, 'move');
  }
  screen.append(tfLayer, guideLayer, snapV, snapH);
  screen.addEventListener('pointerdown', onScreenDown);
  screen.addEventListener('wheel', onScreenWheel, { passive: false });
  // ---------- maschera dei filtri: rettangolo/ellisse da trascinare o pennello a pixel
  let fxSub = 'filter', fxDirty = false, fxKey = '';
  let brushMode = 'paint', brushR = 0.04;
  const selFx = () => (sel && sel.type === 'fx' ? proj.filters.find((f) => f.id === sel.id) : null);
  const zgPt = (e) => { const r = (maskBox.parentNode || zg).getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; };
  let mvKey = '';
  function updateMaskUI() {
    const f = selFx();
    const m = f && f.mask;
    const editing = m && tab === 'video' && fxSub === 'mask' && m.type && m.type !== 'all' && video.currentTime >= f.a - 0.01 && video.currentTime < f.b;
    if (!editing) {
      if (maskView.style.display !== 'none' || paintLayer.style.display !== 'none' || maskBox.style.display !== 'none') { maskView.style.display = maskBox.style.display = paintLayer.style.display = brushCur.style.display = 'none'; }
      mvKey = ''; return;
    }
    const key = JSON.stringify(m) + '|' + zg.clientWidth;
    if (key !== mvKey) {
      mvKey = key;
      const cw = Math.max(2, Math.min(960, zg.clientWidth)), ch = Math.max(2, Math.round(cw * H / W));
      const mc = drawMask(m, cw, ch, W, H);
      maskView.width = cw; maskView.height = ch;
      const g = maskView.getContext('2d');
      g.clearRect(0, 0, cw, ch); g.fillStyle = 'rgba(255,69,58,0.4)'; g.fillRect(0, 0, cw, ch);
      g.globalCompositeOperation = 'destination-in'; g.drawImage(mc, 0, 0); g.globalCompositeOperation = 'source-over';
    }
    maskView.style.display = 'block';
    if (m.type === 'rect' || m.type === 'ellipse') {
      Object.assign(maskBox.style, { display: 'block', left: m.x * 100 + '%', top: m.y * 100 + '%', width: m.w * 100 + '%', height: m.h * 100 + '%', borderRadius: m.type === 'ellipse' ? '50%' : '2px' });
      paintLayer.style.display = 'none'; brushCur.style.display = 'none';
    } else { maskBox.style.display = 'none'; paintLayer.style.display = 'block'; }
  }
  maskBox.addEventListener('pointerdown', (ev) => {
    const f = selFx(); if (!f) return;
    ev.preventDefault(); ev.stopPropagation(); maskBox.setPointerCapture(ev.pointerId);
    begin();
    const mode = ev.target.dataset.h || 'move', p0 = zgPt(ev), m0 = { ...f.mask };
    const mv = (e) => {
      const [px, py] = zgPt(e), dx = px - p0[0], dy = py - p0[1], m = f.mask;
      if (mode === 'move') { m.x = +(m0.x + dx).toFixed(4); m.y = +(m0.y + dy).toFixed(4); }
      else {
        let { x, y, w, h: hh } = m0;
        if (mode.includes('w')) { const nw = Math.max(0.02, w - dx); x += w - nw; w = nw; } else w = Math.max(0.02, w + dx);
        if (mode.includes('n')) { const nh = Math.max(0.02, hh - dy); y += hh - nh; hh = nh; } else hh = Math.max(0.02, hh + dy);
        Object.assign(m, { x: +x.toFixed(4), y: +y.toFixed(4), w: +w.toFixed(4), h: +hh.toFixed(4) });
      }
      fxDirty = true;
    };
    const up = () => { maskBox.removeEventListener('pointermove', mv); changed({ keepPanel: true }); };
    maskBox.addEventListener('pointermove', mv);
    maskBox.addEventListener('pointerup', up, { once: true });
  });
  paintLayer.addEventListener('pointermove', (e) => {
    const [px, py] = zgPt(e);
    Object.assign(brushCur.style, { display: 'block', left: (px - brushR) * 100 + '%', top: `calc(${py * 100}% - ${brushR * zg.clientWidth}px)`, width: brushR * 200 + '%', height: brushR * 2 * zg.clientWidth + 'px' });
    brushCur.classList.toggle('erase', brushMode === 'erase');
  });
  paintLayer.addEventListener('pointerleave', () => { brushCur.style.display = 'none'; });
  paintLayer.addEventListener('pointerdown', (ev) => {
    const f = selFx(); if (!f) return;
    ev.preventDefault(); ev.stopPropagation(); paintLayer.setPointerCapture(ev.pointerId);
    begin();
    const st = { pts: [zgPt(ev).map((v) => +v.toFixed(4))], r: brushR, erase: brushMode === 'erase' };
    f.mask.strokes = f.mask.strokes || [];
    f.mask.strokes.push(st);
    fxDirty = true;
    const mv = (e) => {
      const p = zgPt(e).map((v) => +v.toFixed(4)), l = st.pts[st.pts.length - 1];
      if (Math.hypot(p[0] - l[0], (p[1] - l[1]) * H / W) > brushR * 0.3) { st.pts.push(p); fxDirty = true; }
    };
    const up = () => { paintLayer.removeEventListener('pointermove', mv); changed({ keepPanel: true }); };
    paintLayer.addEventListener('pointermove', mv);
    paintLayer.addEventListener('pointerup', up, { once: true });
  });
  ovBox.addEventListener('pointerdown', (ev) => {
    ev.preventDefault(); ev.stopPropagation();
    const c = findSel(); const img = c && ovImgs.get(c.id); if (!img) return;
    startOvDrag(ev, ev.target.dataset.h || 'move', img);
  });
  // trascina / ridimensiona l'inquadratura (sempre nel formato del video: 16:9 o, in verticale, 9:16)
  // in verticale ogni zoom (anche quello sulla webcam) ha la sua inquadratura finale: z.vrect
  // forma dell'inquadratura verticale: 9:16, un po' piu' larga se ci sono le barre nere
  const VA = (pad) => 9 / 16 / (1 - 2 * (pad || 0));
  const zA = (z) => VA(segVert(z.a + 0.01).pad);
  const vBoxOf = (z) => {
    const a = zA(z);
    if (z.vrect) return vertRect(W, H, z.vrect, a);
    const bx = vertZoomBoxes(z, W, H, cam, a);
    if (!bx) return null;
    const c = coverRect(bx.from, a);
    return vertRect(W, H, c, a);
  };
  let fdrag = null;
  frameBox.addEventListener('pointerdown', (ev) => {
    if (ev.target.closest('.framedone')) return;
    const z = findSel(); if (!z) return;
    const r = VERT ? vBoxOf(z) : z.rect ? customRect(W, H, z.rect) : null;
    if (!r) return;
    ev.preventDefault(); frameBox.setPointerCapture(ev.pointerId);
    begin();
    fdrag = { mode: ev.target.dataset.h || 'move', x: ev.clientX, y: ev.clientY, r, v: VERT };
  });
  frameBox.addEventListener('pointermove', (ev) => {
    if (!fdrag) return;
    const z = findSel(); if (!z) return;
    const k = W / screen.clientWidth;
    const dx = (ev.clientX - fdrag.x) * k, dy = (ev.clientY - fdrag.y) * k;
    let [x, y, w, hh] = fdrag.r;
    const za = fdrag.v ? zA(z) : 0;
    const ar = fdrag.v ? 1 / za : H / W;   // altezza / larghezza del riquadro
    if (fdrag.mode === 'move') { x += dx; y += dy; }
    else {
      const sgnx = fdrag.mode.includes('w') ? -1 : 1;
      const nw = fdrag.v ? Math.max(W / 16, Math.min(H * za, w + sgnx * dx)) : Math.max(W / 8, Math.min(W / 1.05, w + sgnx * dx));
      const nh = nw * ar;
      if (fdrag.mode.includes('w')) x += w - nw;
      if (fdrag.mode.includes('n')) y += hh - nh;
      w = nw; hh = nh;
    }
    if (fdrag.v) z.vrect = vertRect(W, H, [x, y, w], za).slice(0, 3).map(Math.round);
    else z.rect = customRect(W, H, [x, y, w]).slice(0, 3).map(Math.round);
    frame(true);
  });
  frameBox.addEventListener('pointerup', () => {
    if (!fdrag) return;
    fdrag = null;
    changed(); frame(true);
  });
  const screenWrap = h('div', { class: 'screen-wrap' }, screen);
  const timeLbl = h('div', { class: 'time' }, '0:00');
  const playBtn = h('button', { class: 'playbtn', disabled: true, 'aria-label': 'Riproduci', 'data-tip': 'Riproduci / pausa', 'data-key': 'Spazio', onclick: () => togglePlay() }, icon('play', 13, '#0B0E13'));
  // velocita' di riproduzione dell'anteprima (solo per guardare: il video finale non cambia)
  const RATES = [0.5, 0.75, 1, 1.25, 1.5, 2, 4, 8, 16];
  let viewRate = 1;
  const rateBtn = h('button', { class: 'ratebtn', 'data-tip': 'Velocità dell\'anteprima, fino a 16× (solo per guardare, il video finale non cambia)', 'data-key': 'Maiusc + < >', 'aria-label': 'Velocità dell\'anteprima' }, '1×');
  function setViewRate(r) {
    viewRate = r; rateBtn.textContent = (r + '×').replace('.', ','); rateBtn.classList.toggle('on', r !== 1); applySpeed();
  }
  const stepRate = (d) => { const i = RATES.indexOf(viewRate); setViewRate(RATES[Math.max(0, Math.min(RATES.length - 1, i + d))]); };
  // menu delle velocita' dentro il lettore (cosi' si vede anche a schermo intero)
  const rateMenu = h('div', { class: 'ratemenu', style: { display: 'none' } });
  const rateWrap = h('div', { class: 'ratewrap' }, rateBtn, rateMenu);
  function openRateMenu() {
    rateMenu.replaceChildren(...RATES.slice().reverse().map((r) => h('button', { class: r === viewRate ? 'on' : '', onclick: (e) => { e.stopPropagation(); setViewRate(r); rateMenu.style.display = 'none'; } }, (r + '×').replace('.', ','))));
    rateMenu.style.display = '';
    const off = (e) => { if (!rateWrap.contains(e.target)) { rateMenu.style.display = 'none'; document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  }
  rateBtn.addEventListener('click', (e) => { e.stopPropagation(); if (rateMenu.style.display === 'none') openRateMenu(); else rateMenu.style.display = 'none'; });
  rateBtn.addEventListener('contextmenu', (e) => { e.preventDefault(); setViewRate(1); });
  const ccBtn = ibtn('cc', 'Sottotitoli nel video (mostra / nascondi)', () => toggleSubs(), { pressed: true, size: 18, cls: 'ccbtn' });
  function toggleSubs() {
    if (!allWords().length) { sel = null; tab = 'text'; openSec.set('t.subs', true); renderTimeline(); renderPanel(); return; }
    begin(); proj.settings.showSubs = !proj.settings.showSubs; changed();
  }
  function syncCc() { ccBtn.setAttribute('aria-pressed', String(!!proj.settings.showSubs)); ccBtn.style.display = ''; }
  const fsBtn = ibtn('expand', 'Schermo intero', () => toggleFull(), { key: 'F', size: 17 });
  const outLbl = h('div', { class: 'xs', style: { width: '150px', textAlign: 'right' } });
  // barra del tempo (a schermo intero): trascina per spostarti, le parti tolte sono a righe
  const fsFill = h('div', { class: 'fs-fill' }), fsKnob = h('div', { class: 'fs-knob' }), fsCuts = h('div', { class: 'fs-cuts' });
  const fsBar = h('div', { class: 'fs-bar', role: 'slider', 'aria-label': 'Posizione nel video' }, h('div', { class: 'fs-track' }, fsCuts, fsFill), fsKnob);
  let fsDrag = false, fsCutsKey = '';
  const fsT = (e) => { const r = fsBar.getBoundingClientRect(); return Math.max(0, Math.min(D - 0.05, T(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * viewEnd))); };
  fsBar.addEventListener('pointerdown', (e) => { fsDrag = true; fsBar.setPointerCapture(e.pointerId); fsBar.classList.add('drag'); seek(fsT(e)); });
  fsBar.addEventListener('pointermove', (e) => { if (fsDrag) seekQuiet(fsT(e)); });
  fsBar.addEventListener('pointerup', () => { fsDrag = false; fsBar.classList.remove('drag'); });
  function updateFsBar(t) {
    if (!document.fullscreenElement) return;
    const E = Math.max(0.01, viewEnd), p = (V(t) / E * 100) + '%';
    fsFill.style.width = p; fsKnob.style.left = p;
    const rem = removed(), key = rem.map((r) => r.join(',')).join(';') + '|' + E;
    if (key !== fsCutsKey) {
      fsCutsKey = key;
      fsCuts.replaceChildren(...rem.filter(([a, b]) => V(b) - V(a) > 0.01).map(([a, b]) => h('i', { style: { left: V(a) / E * 100 + '%', width: Math.max(0.15, (V(Math.min(D, b)) - V(a)) / E * 100) + '%' } })));
    }
  }
  // a schermo intero un clic in mezzo al video fa partire o ferma la riproduzione
  screenWrap.addEventListener('click', (e) => { if (document.fullscreenElement && !e.target.closest('button, input')) togglePlay(); });
  const viewer = h('section', { class: 'viewer', 'aria-label': 'Anteprima' }, screenWrap, fsBar,
    h('div', { class: 'transport' }, timeLbl,
      h('div', { class: 'mid' },
        ibtn('back5', 'Indietro di 5 secondi', () => seek(video.currentTime - 5), { key: 'Maiusc ←' }),
        playBtn,
        ibtn('fwd5', 'Avanti di 5 secondi', () => seek(video.currentTime + 5), { key: 'Maiusc →' })),
      h('div', { class: 'end' }, guideBtn, rateWrap, ccBtn, fsBtn)));
  function toggleFull() {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else viewer.requestFullscreen().catch((e) => toast('Schermo intero non disponibile: ' + e.message, true));
  }
  const onFs = () => {
    const on = document.fullscreenElement === viewer;
    fsBtn.replaceChildren(icon(on ? 'shrink' : 'expand', 17));
    fsBtn.dataset.tip = on ? 'Esci da schermo intero' : 'Schermo intero';
    fsBtn.setAttribute('aria-label', fsBtn.dataset.tip);
    setTimeout(layoutScreen, 50);
  };
  document.addEventListener('fullscreenchange', onFs);

  function layoutScreen() {
    const aw = screenWrap.clientWidth, ah = screenWrap.clientHeight;
    const A = VERT && !sourceView() ? 9 / 16 : W / H;   // proporzione di quello che si vede
    let w = aw, hh = aw / A;
    if (hh > ah) { hh = ah; w = ah * A; }
    screen.style.width = Math.floor(w) + 'px'; screen.style.height = Math.floor(hh) + 'px';
    applySubStyle();
  }

  // ---------------------------------------------------------------- DOM: pannello
  const panelTabs = h('div');
  const panelBody = h('div', { class: 'body' });
  const panel = h('aside', { class: 'panel', 'aria-label': 'Testo e proprietà' }, panelTabs, panelBody);
  const lTabs = h('div');
  const lBody = h('div', { class: 'body' });
  const leftPanel = h('aside', { class: 'panel lpanel', 'aria-label': 'Progetto, media e clip' }, lTabs, lBody);
  let curBody = panelBody;

  // ---------------------------------------------------------------- DOM: timeline
  const undoBtn = ibtn('undo', 'Annulla', undo, { key: 'Ctrl+Z' });
  const redoBtn = ibtn('redo', 'Ripeti', redo, { key: 'Ctrl+Y' });
  function updateUndo() { undoBtn.disabled = !undoStack.length; redoBtn.disabled = !redoStack.length; }
  const zoomSlider = h('input', { type: 'range', min: '0', max: '1000', value: '0', 'aria-label': 'Zoom della timeline' });
  const magnetBtn = ibtn('magnet', 'Magnete: la testina e i blocchi si agganciano ai bordi', () => {
    snapOn = !snapOn; store.set('snap', snapOn); magnetBtn.setAttribute('aria-pressed', String(snapOn));
    toast(snapOn ? 'Magnete attivo' : 'Magnete spento');
  }, { key: 'N', pressed: store.get('snap', true) });
  // barra della timeline: poche azioni, con il nome; il resto sta nel menu "Altro"
  const tbtn = (name, label, tip, fn, key) => {
    const b = h('button', { class: 'iconbtn lbl', 'aria-label': tip, 'data-tip': tip, 'data-key': key || null, onclick: fn }, icon(name, 15, 'currentColor', 1.9), h('span', null, label));
    return b;
  };
  const moreMenu = (e) => popMenu(e.currentTarget, [
    ['crop', 'Zoom personalizzato', 'Scegli tu cosa inquadrare · C', addCustomZoom],
    ['wand', 'Filtro o effetto', 'Dalla testina, anche solo su una parte', () => { sel = null; tab = 'video'; renderTimeline(); renderPanel(); }],
    ['trimL', 'Taglia prima della testina', 'Q', () => trimAt('left')],
    ['trimR', 'Taglia dopo la testina', 'W', () => trimAt('right')],
    ['magnet', snapOn ? 'Aggancio ai bordi: attivo' : 'Aggancio ai bordi: spento', 'La testina e i blocchi si attaccano ai bordi vicini · N', () => magnetBtn.click()],
    ['upload', 'Importa file nei Media', 'Video, immagini e suoni', () => { setTab('media'); importMedia(); }],
    ['addTrack', 'Aggiungi una traccia', null, [
      ['addVideo', 'Traccia video', 'Per immagini e testi, va sopra', () => addLaneTrack('overlay')],
      ['addAudio', 'Traccia audio', 'Per suoni e musica, va sotto', () => addLaneTrack('sound')],
      ['wand', 'Traccia filtri', 'Filtri ed effetti su un livello a parte', () => addLaneTrack('fx')],
      ['sliders', 'Traccia colori', 'Luminosità, contrasto, saturazione…', () => addLaneTrack('adjust')],
      ['magnify', 'Traccia zoom', 'Altri zoom, per organizzarli', () => addLaneTrack('zoom')]]]]);
  const mainMagBtn = ibtn('magnet', 'Calamita della traccia principale: accesa, le clip stanno attaccate senza spazi vuoti; spenta, le puoi mettere dove vuoi', () => setMainMagnet(!magnetOn()), { pressed: magnetOn() });
  const tools = h('div', { class: 'tl-tools' }, undoBtn, redoBtn, h('div', { class: 'sep' }),
    ibtn('scissors', 'Dividi nel punto della testina', splitSeg, { key: 'S' }),
    ibtn('trash', 'Elimina il selezionato', () => deleteSel(), { key: 'Canc' }),
    h('div', { class: 'sep' }),
    cam ? tbtn('magnify', 'Zoom', 'Aggiungi uno zoom sulla webcam qui', addZoom, 'Z') : null,
    tbtn('type', 'Testo', 'Aggiungi un testo', () => addText(), 'T'),
    IS_V || proj.width < proj.height * 1.3 ? null : tbtn('phone', 'Clip verticale', 'Crea una clip verticale dalle clip selezionate', () => vertFromSelection(), 'V'),
    tbtn('plus', 'Altro', 'Zoom personalizzato, filtri, tracce, importa…', moreMenu),
    h('div', { class: 'sep' }),
    ibtn('toStart', 'Seleziona tutto a sinistra della testina', () => selectSide(-1)),
    ibtn('toEnd', 'Seleziona tutto a destra della testina (poi trascina per fare spazio)', () => selectSide(1)),
    IS_V ? magnetBtn : mainMagBtn,
    h('div', { class: 'grow' }),
    h('div', { class: 'tl-zoom', 'data-tip': 'Zoom della timeline', 'data-key': 'Ctrl + rotella' }, icon('zoomout', 14), zoomSlider, icon('zoomin', 14)));
  const heads = h('div', { class: 'tl-heads' });
  const ruler = h('div', { class: 'ruler' });
  const lanes = h('div', { class: 'lanes' });
  const playhead = h('div', { class: 'playhead' });
  const inner = h('div', { class: 'tl-inner' }, ruler, lanes, playhead);
  const scroller = h('div', { class: 'tl-scroll' }, inner);
  const tlMain = h('div', { class: 'tl-main' }, heads, scroller);
  const tl = h('section', { class: 'tl', 'aria-label': 'Timeline' }, tools, tlMain);

  const savedLabel = h('span', { class: 'saved', 'data-tip': 'Salvato in automatico' }, icon('cloudok', 17));
  const exportBtn = h('button', { class: 'btn primary sm', 'data-tip': 'Crea il video finale', onclick: () => openExport() }, icon('download', 14, '#fff', 2.2), 'Esporta');

  function popMenuAt(x, y, items) {
    const fake = { getBoundingClientRect: () => ({ left: x, top: y, bottom: y, right: x }) };
    popMenu(fake, items, true);
  }
  // ---------------------------------------------------------------- clip verticali
  let lastVDown = { id: null, t: 0 };
  // clip verticali che si sovrappongono: una sotto l'altra
  function vertRows() {
    const end = [], rows = new Map();
    for (const v of [...(proj.verticals || [])].sort((x, y) => x.a - y.a)) {
      let r = end.findIndex((e) => e <= v.a + 0.001);
      if (r < 0) { r = end.length; end.push(0); }
      end[r] = v.b; rows.set(v.id, r);
    }
    return { rows, n: Math.max(1, end.length) };
  }
  // pezzi della clip verticale: le clip scelte, anche lontane tra loro (quelle vicine diventano un pezzo solo)
  function vertRun(segs) {
    const list = proj.segs.filter((c) => !c.gone).sort((x, y) => x.a - y.a);
    const idx = segs.map((c) => list.indexOf(c)).filter((i) => i >= 0).sort((x, y) => x - y);
    if (!idx.length) return null;
    const ranges = [];
    for (const i of idx) {
      const c = list[i], last = ranges[ranges.length - 1];
      if (last && last.i === i - 1) { last.b = c.b; last.i = i; } else ranges.push({ a: c.a, b: c.b, i });
    }
    const out = ranges.map((r) => [r.a, r.b]);
    return out.reduce((s2, [a, b]) => s2 + b - a, 0) >= 0.5 ? out : null;
  }
  // dal pulsante (o dal tasto V): usa le clip video selezionate, anche se insieme ad altro
  function vertFromSelection() {
    const list = (multi.length ? multi : sel ? [sel] : []).filter((m) => isSeg(m.type)).map((m) => findSel(m)).filter(Boolean);
    if (!list.length) return toast('Seleziona nella traccia Video le clip da usare (con Maiusc per prenderne più di una), poi premi di nuovo');
    const run = vertRun(list);
    if (!run) return toast('La clip è troppo corta', true);
    createVertical(run);
  }
  async function createVertical(ranges) {
    const n = proj.verticals.length + 1;
    const name = await promptBox('Nome della clip verticale', 'Lo ritrovi nella timeline e diventa il nome del file quando la esporti.', tx('Clip verticale') + ' ' + n, 'Crea');
    if (!name) return;
    try {
      await textsSaved(); dirty = true; await flush();
      const r = await post(`/api/p/${pid}/vertical`, { ranges, name });
      proj.verticals.push(r);
      dirty = true; scheduleSave();
      multi = []; sel = { type: 'vclip', id: r.id }; tab = 'clips'; renderTimeline(); renderPanel();
      toast('Clip verticale creata: la trovi nella tab Clip');
    } catch (e) { toast(e.message, true); }
  }
  async function openVertical(v) {
    video.pause();
    try { sessionStorage.setItem('vodcut.seek.' + pid, String(video.currentTime)); } catch (e) { /* */ }
    await textsSaved(); await flush();
    ctx.nav('editor', v.id);
  }
  async function renameVertical(v) {
    const name = await promptBox('Rinomina la clip verticale', null, v.name, 'Rinomina');
    if (!name || name === v.name) return;
    try { await post(`/api/p/${v.id}/rename`, { name }); } catch (e) { return toast(e.message, true); }
    v.name = name; dirty = true; scheduleSave(); renderTimeline(); renderPanel();
  }
  async function deleteVertical(v) {
    if (!await confirmBox('Eliminare la clip verticale?', `"${v.name}" e le sue modifiche spariscono. Il video orizzontale resta com'è.`, 'Elimina', true)) return;
    if (sel && sel.id === v.id) sel = null;
    try { await api('DELETE', '/api/p/' + v.id); } catch (e) { /* gia' tolta */ }
    proj.verticals = proj.verticals.filter((x) => x.id !== v.id);
    sel = null; dirty = true; scheduleSave(); renderTimeline(); renderPanel();
  }
  function vclipMenu(v) {
    return [['phone', 'Modifica la clip verticale', 'Anche con doppio clic', () => openVertical(v)],
      ['type', 'Rinomina', null, () => renameVertical(v)],
      ['trash', 'Elimina la clip verticale', 'Il video orizzontale resta com\'è', () => deleteVertical(v)]];
  }
  const vRanges = (v) => v.ranges || [[v.a, v.b]];
  const vDur = (v) => vRanges(v).reduce((s2, [a, b]) => s2 + b - a, 0);
  // tab Clip: tutte le clip verticali di questo video, in ordine
  function renderClipsTab() {
    const list = proj.verticals.slice().sort((x, y) => vRanges(x)[0][0] - vRanges(y)[0][0]);
    const cur = sel && sel.type === 'vclip' ? sel.id : null;
    const segSel = [...(multi.length ? multi : sel ? [sel] : [])].filter((m) => isSeg(m.type)).map((m) => findSel(m)).filter(Boolean);
    const run = segSel.length ? vertRun(segSel) : null;
    B.append(h('div', { class: 'vc-top' },
      h('div', { class: 'vc-top-t' }, h('b', null, 'Clip verticali'), h('span', null, list.length ? String(list.length) : '')),
      h('button', { class: 'btn sm primary', disabled: run ? null : true, onclick: () => run && createVertical(run),
        'data-tip': run ? 'Con le clip selezionate nella traccia Video' : 'Seleziona prima una o più clip nella traccia Video (Ctrl o Maiusc per sceglierne più d\'una)', 'data-key': 'V' },
        icon('plus', 13, '#fff', 2.4), 'Nuova')));
    if (!list.length) { B.append(h('div', { class: 'vc-empty' }, icon('phone', 22, 'currentColor', 1.6), h('span', null, 'Seleziona i pezzi nella traccia Video e premi Nuova (o V).'))); return; }
    B.append(h('div', { class: 'vc-list' }, ...list.map((v) => {
      const rs = vRanges(v), t0 = rs[0][0];
      const card = h('div', { class: 'vc-item' + (cur === v.id ? ' on' : '') },
        h('img', { class: 'vc-thumb', src: thumbUrl(pid, Math.min(D - 0.5, t0 + Math.min(1, vDur(v) / 2)), 160), alt: '', loading: 'lazy' }),
        h('div', { class: 'vc-info' },
          h('b', { 'data-notr': '' }, v.name),
          h('span', null, fmtLong(vDur(v)) + (rs.length > 1 ? ` · ${rs.length} pezzi` : '') + ' · da ' + fmt(t0)),
          h('div', { class: 'vc-acts' },
            h('button', { class: 'btn sm', onclick: (e) => { e.stopPropagation(); openVertical(v); } }, 'Modifica'),
            ibtn('type', 'Rinomina', (e) => { e.stopPropagation(); renameVertical(v); }, { size: 14 }),
            ibtn('trash', 'Elimina la clip verticale', (e) => { e.stopPropagation(); deleteVertical(v); }, { size: 14 }))));
      // un clic la mostra sulla timeline (i pezzi si colorano), doppio clic la apre
      card.addEventListener('click', () => { sel = { type: 'vclip', id: v.id }; multi = []; seekQuiet(t0 + 0.05); renderTimeline(); renderPanel(); frame(true); });
      card.addEventListener('dblclick', () => openVertical(v));
      card.addEventListener('contextmenu', (e) => { e.preventDefault(); popMenuAt(e.clientX, e.clientY, vclipMenu(v)); });
      return card;
    })));
  }
  // menu del tasto destro sui blocchi della timeline
  function blockMenu(it) {
    const list = multi.length > 1 ? multi.slice() : [it];
    const items = list.map((m) => ({ m, o: findSel(m) })).filter((x) => x.o);
    const segs = items.filter((x) => isSeg(x.m.type)).map((x) => x.o);
    const n = items.length, one = n === 1 ? items[0] : null;
    const menu = [];
    const subs = items.filter((x) => x.m.type === 'sub').map((x) => x.o);
    if (subs.length === n && n) {
      const hid = subs.every((x) => x.hidden);
      menu.push([hid ? 'eye' : 'eyeOff', hid ? (n > 1 ? `Mostra queste ${n} frasi` : 'Mostra questa frase') : (n > 1 ? `Nascondi queste ${n} frasi` : 'Nascondi questa frase'), 'Solo nei sottotitoli, l\'audio resta',
        () => { begin(); subs.forEach((x) => wordsIn(x.a, x.b).forEach((w) => { w.nosub = hid ? undefined : true; })); ver++; multi = []; sel = null; changed(); }]);
      if (one) {
        menu.push(['eyeOff', 'Nascondi da qui alla fine', null, () => setNoSub(one.o.a, D, true)], ['eye', 'Mostra da qui alla fine', null, () => setNoSub(one.o.a, D, false)],
          ['type', 'Correggi il testo', null, () => fixSub(one.o)]);
      }
      return menu;
    }
    if (segs.length === n && n) {
      const t = video.currentTime;
      if (!IS_V) {
        const run = vertRun(segs);
        menu.push(['phone', 'Crea clip verticale', run ? (segs.length > 1 ? 'Con i pezzi scelti, uno dopo l\'altro' : 'Una clip 9:16 da modificare a parte') : 'Troppo corta', run ? () => createVertical(run) : null, '#818CF8']);
      }
      if (one && t > one.o.a + 0.1 && t < one.o.b - 0.1) menu.push(['scissors', 'Dividi qui', 'Nel punto della testina', () => splitSeg()]);
      const anyOut = segs.some((x) => x.removed);
      menu.push([anyOut ? 'restore' : 'scissors', anyOut ? 'Rimetti nel video' : 'Togli dal video', anyOut ? null : 'Resta sulla timeline, a righe', () => { begin(); segs.forEach((x) => { x.removed = !anyOut; if (anyOut) x.gone = false; }); changed(); }]);
      menu.push(['trash', 'Elimina dalla timeline', 'Sparisce del tutto (Ctrl+Z per annullare)', () => deleteMany(items.map((x) => x.m), true)]);
      const anyMute = segs.some((x) => x.mute);
      menu.push([anyMute ? 'speaker' : 'mute', anyMute ? 'Riattiva l\'audio' : 'Silenzia l\'audio', null, () => { begin(); segs.forEach((x) => { x.mute = !anyMute; }); changed(); }]);
      if (allWords().length) {
        const hid = segs.every((x) => wordsIn(x.a, x.b).every((w) => w.nosub));
        menu.push([hid ? 'eye' : 'eyeOff', hid ? 'Mostra i sottotitoli qui' : 'Nascondi i sottotitoli qui', null, () => { begin(); segs.forEach((x) => wordsIn(x.a, x.b).forEach((w) => { w.nosub = hid ? undefined : true; })); ver++; changed(); }]);
      }
      if (ENV_WHISPER() && !(proj.transcript && proj.transcript.status === 'running')) {
        const has = segs.some((x) => wordsIn(x.a, x.b).length);
        const lbl = n > 1 ? (has ? `Rifai i sottotitoli di queste ${n} clip` : `Crea i sottotitoli di queste ${n} clip`) : (has ? 'Rifai i sottotitoli di questa clip' : 'Crea i sottotitoli di questa clip');
        menu.push(['cc', lbl, has ? 'Si ritrascrive solo questo pezzo' : 'Si trascrive solo questo pezzo, il resto non cambia', subRangeJob ? null : () => regenSubs(segs)]);
      }
      menu.push(['duplicate', n > 1 ? `Copia le clip (${n})` : 'Copia la clip', 'Ctrl+C · poi Ctrl+V: alla fine si mette di fianco, in mezzo va su un\'altra traccia', () => copySel()]);
      if (clipBoard && clipBoard.kind === 'main') menu.push(['duplicate', 'Incolla alla testina', 'Ctrl+V', () => pasteClip()]);
      menu.push(['sliders', 'Copia le impostazioni', 'Velocità, filtro, colori, audio e impaginazione', () => copyAttrs(one ? one.o : segs[0])]);
      if (clipBoard && clipBoard.kind === 'attrs') menu.push(['duplicate', n > 1 ? `Incolla le impostazioni (${n})` : 'Incolla le impostazioni', 'Ctrl+V', () => pasteClip()]);
      menu.push(['speed', 'Velocità', segs.length === 1 && (one.o.speed || 1) !== 1 ? (one.o.speed + '×').replace('.', ',') : 'Normale',
        [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4].map((v) => ['speed', (v + '×').replace('.', ','), v === 1 ? 'Normale' : v < 1 ? 'Rallentato' : 'Accelerato', () => { begin(); segs.forEach((x) => { x.speed = v === 1 ? undefined : v; }); changed(); applySpeed(); }])]);
      return menu;
    }
    // selezione mista (clip video + altro, es. col rettangolo): la clip verticale si fa con le clip video
    if (!IS_V && segs.length && segs.length < n) {
      const run = vertRun(segs);
      menu.push(['phone', 'Crea clip verticale', run ? 'Con le clip video selezionate' : 'Troppo corta', run ? () => createVertical(run) : null]);
    }
    if (items.some((x) => COPY_TYPES.includes(x.m.type))) menu.push(['duplicate', 'Copia', 'Ctrl+C · poi Ctrl+V per incollare alla testina', () => copySel()]);
    if (clipBoard && clipBoard.kind === 'items') menu.push(['duplicate', 'Incolla alla testina', 'Ctrl+V', () => pasteClip()]);
    if (one && ['zoom', 'fx', 'sclip'].includes(one.m.type)) menu.push(['duplicate', 'Duplica', 'Una copia subito dopo', () => duplicateItem(one.m, one.o)]);
    if (one && one.m.type === 'sclip' && !one.o.isText) menu.push(['swap', 'Sostituisci…', 'Stessa posizione e stessi effetti, file nuovo', () => replaceClip(one.o)]);
    if (one && one.m.type === 'sclip' && one.o.kind === 'image' && !one.o.isText) menu.push(['cutout', 'Rimuovi lo sfondo', 'Automatico, sul tuo PC', () => removeBg(one.o)]);
    if (items.some((x) => x.m.type === 'sclip' && x.o.kind !== 'image')) {
      const snd = items.filter((x) => x.m.type === 'sclip' && x.o.kind !== 'image').map((x) => x.o), anyMute = snd.some((x) => x.mute);
      menu.push([anyMute ? 'speaker' : 'mute', anyMute ? 'Riattiva' : 'Muta', null, () => { begin(); snd.forEach((x) => { x.mute = !anyMute; }); changed(); }]);
    }
    menu.push(['trash', n > 1 ? `Elimina (${n})` : 'Elimina', null, () => deleteMany(items.map((x) => x.m), true)]);
    return menu;
  }
  const wordsIn = (a, b) => { const r = []; allWords().forEach((sg) => sg.words.forEach((w) => { const m = (w.a + w.b) / 2; if (m >= a && m < b) r.push(w); })); return r; };
  function setNoSub(a, b, on) { begin(); wordsIn(a, b).forEach((w) => { w.nosub = on || undefined; }); ver++; changed(); }
  function deleteMany(list, fromTimeline) {
    begin();
    for (const m of list) {
      const o = findSel(m); if (!o) continue;
      if (isSeg(m.type)) { o.removed = true; if (fromTimeline) o.gone = true; }
      else if (m.type === 'sub') { wordsIn(o.a, o.b).forEach((w) => { w.nosub = true; }); ver++; }
      else if (m.type === 'zoom') proj.zooms = proj.zooms.filter((z) => z !== o);
      else if (m.type === 'fx') proj.filters = proj.filters.filter((f) => f !== o);
      else if (m.type === 'sclip') { const tr = trackOfClip(o.id); if (tr) tr.clips = tr.clips.filter((c) => c !== o); }
    }
    multi = []; if (sel && !findSel(sel)) sel = null; if (sel && isSeg(sel.type) && fromTimeline) sel = null;
    changed();
  }
  // ---------------------------------------------------------------- copia e incolla (Ctrl+C / Ctrl+V)
  // zoom, filtri, immagini, testi, video e suoni: si incollano alla testina con gli stessi valori.
  // Clip del video: si copiano le impostazioni (velocita', filtro, colori, audio, impaginazione) e si incollano su altre clip
  let clipBoard = null;
  const COPY_TYPES = ['zoom', 'fx', 'sclip'];
  const SEG_ATTRS = ['speed', 'fx', 'adj', 'vol', 'mute', 'fin', 'fout', 'vlay'];
  const selList = () => (multi.length ? multi : sel ? [sel] : []).map((m) => ({ type: m.type, o: findSel(m) })).filter((x) => x.o);
  const deep = (o) => JSON.parse(JSON.stringify(o));
  function copySel() {
    const list = selList().filter((x) => COPY_TYPES.includes(x.type) || isSeg(x.type));
    if (!list.length) return false;
    const items = list.filter((x) => COPY_TYPES.includes(x.type));
    if (!items.length) {
      // clip della traccia principale: si copia tutta la clip (Ctrl+V la rimette alla testina)
      const segs = list.filter((x) => isSeg(x.type) && !x.o.gone).map((x) => x.o).sort((x, y) => x.a - y.a);
      if (!segs.length) return false;
      clipBoard = { kind: 'main', o: deep(segs[0]), clips: segs.map((c) => mainClipData(c)) };
      toast(segs.length > 1 ? `Copiate ${segs.length} clip: Ctrl+V per incollarle alla testina` : 'Clip copiata: Ctrl+V per incollarla alla testina');
      return true;
    }
    clipBoard = { kind: 'items', t0: Math.min(...items.map((x) => x.o.a)),
      items: items.map((x) => ({ type: x.type, o: deep(x.o), track: x.type === 'sclip' ? (trackOfClip(x.o.id) || {}).id : null })) };
    toast(items.length > 1 ? `Copiati ${items.length} elementi: Ctrl+V per incollarli alla testina` : 'Copiato: Ctrl+V per incollarlo alla testina');
    return true;
  }
  // tutto quello che serve per rimettere una clip principale altrove (file, punto di partenza, impostazioni, parole)
  function mainClipData(c) {
    const rec = c.ins && insById(c.ins);
    const dur = +(c.b - c.a).toFixed(4);
    const rel = (x) => +(x - c.a).toFixed(4);
    const words = allWords().filter((sg) => sg.a >= c.a - 1e-6 && sg.b <= c.b + 1e-6)
      .map((sg) => ({ ...sg, a: rel(sg.a), b: rel(sg.b), words: (sg.words || []).map((w2) => ({ ...w2, a: rel(w2.a), b: rel(w2.b) })) }));
    const base = rec ? { file: rec.file, offset: +((rec.offset || 0) + (c.a - rec.at)).toFixed(4), live: !!rec.live, gap: !!rec.gap, name: rec.name, w: rec.w, h: rec.h,
      hasAudio: rec.hasAudio, vcodec: rec.vcodec, preview: rec.preview, ...(rec.image ? { image: true, fileDur: rec.fileDur, src: rec.src, iar: rec.iar } : {}) }
      : { file: proj.source, offset: +liveOffAt(c.a).toFixed(4), live: true, name: 'Clip della live', w: W, h: H, hasAudio: proj.hasAudio !== false };
    return { ...base, dur, seg: deep(c), words };
  }
  async function pasteMain() {
    const t = video.currentTime;
    const main = proj.segs.filter((c) => !c.gone && !(BLANK && !c.ins));
    const end = main.length ? Math.max(...main.map((c) => c.b)) : 0;
    const cl = clipBoard.clips;
    if (t >= end - 0.15) {
      // alla fine: le clip si mettono di fianco, una dopo l'altra
      let at = end;
      for (const d of cl) {
        const { seg, words, preview, ...src } = d;
        const rec = { id: uid('v'), at, ...src, words: deep(words) };
        if (preview) rec.preview = preview;
        await applyInsert(rec, null, [{ ...seg, id: uid('s'), a: 0, b: d.dur, removed: false, gone: false, auto: false, ins: undefined }]);
        at = rec.at + d.dur;
      }
      toast(cl.length > 1 ? 'Clip incollate alla fine' : 'Clip incollata alla fine');
      return true;
    }
    // in mezzo la traccia principale e' occupata: la clip va sopra, in una traccia video libera
    begin();
    let at = t;
    const made = [];
    for (const d of cl) {
      const sp = d.seg.speed || 1, len = +(d.dur / sp).toFixed(3);
      const ar = d.w && d.h ? d.h / d.w : 1 / CA();
      const w = Math.min(1, (1 / CA()) / ar), hf = w * CA() * ar;
      const c = { id: uid('c'), kind: 'video', file: d.live ? proj.source : d.file, name: (d.name || 'Clip').replace(/\.[^.]+$/, ''), a: +at.toFixed(2), dur: len, offset: d.offset,
        fileDur: d.offset + d.dur + 1, pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, ar, opacity: 100,
        vol: d.seg.vol ?? 100, mute: !!d.seg.mute, hasAudio: !!d.hasAudio && !d.gap };
      if (d.preview) c.preview = d.preview;
      const free = (tr) => !tr.clips.some((x) => x.a < c.a + c.dur - 1e-3 && x.a + x.dur > c.a + 1e-3);
      const tr = proj.tracks.find((x) => x.type === 'overlay' && free(x)) || newTrack('overlay');
      tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
      made.push({ type: 'sclip', id: c.id });
      at += len;
    }
    multi = made.length > 1 ? made : []; sel = { ...made[made.length - 1] };
    changed(); frame(true);
    toast('La traccia principale qui è occupata: incollata sopra, in una traccia video');
    return true;
  }
  function copyAttrs(o) {
    clipBoard = { kind: 'attrs', o: deep(o) };
    toast('Impostazioni della clip copiate: seleziona altre clip e premi Ctrl+V');
  }
  function pasteClip() {
    if (!clipBoard) return false;
    if (clipBoard.kind === 'main') { pasteMain(); return true; }
    if (clipBoard.kind === 'attrs') {
      const targets = selList().filter((x) => isSeg(x.type)).map((x) => x.o);
      if (!targets.length) { toast('Seleziona le clip su cui incollare le impostazioni', true); return true; }
      begin();
      for (const c of targets) for (const k of SEG_ATTRS) { if (clipBoard.o[k] === undefined) delete c[k]; else c[k] = deep(clipBoard.o[k]); }
      changed(); applySpeed(); frame(true);
      toast(targets.length > 1 ? `Impostazioni incollate su ${targets.length} clip` : 'Impostazioni incollate');
      return true;
    }
    begin();
    const dt = video.currentTime - clipBoard.t0, made = [];
    for (const it of clipBoard.items) {
      const c = deep(it.o);
      c.id = uid(it.type === 'zoom' ? 'z' : it.type === 'fx' ? 'f' : 'c');
      if (c.b !== undefined) {
        const len = c.b - c.a;
        c.a = +Math.max(0, Math.min(D - len, c.a + dt)).toFixed(2); c.b = +(c.a + len).toFixed(2);
      } else c.a = +Math.max(0, Math.min(D - c.dur, c.a + dt)).toFixed(2);
      if (it.type === 'zoom') {
        if (!proj.zoomTracks.some((t) => t.id === (c.track || 'zoom'))) c.track = 'zoom';
        proj.zooms.push(c); proj.zooms.sort((x, y) => x.a - y.a);
      } else if (it.type === 'fx') {
        if (!proj.fxTracks.some((t) => t.id === (c.track || 'fx'))) c.track = 'fx';
        proj.filters.push(c);
      } else {
        // stessa traccia se c'e' posto, se no un'altra dello stesso tipo (o una nuova)
        const kind = c.kind === 'image' || c.kind === 'video' ? 'overlay' : 'sound';
        const free = (t) => !t.clips.some((x) => x.a < c.a + c.dur - 1e-3 && x.a + x.dur > c.a + 1e-3);
        let tr = proj.tracks.find((t) => t.id === it.track && t.type === kind);
        if (!tr || !free(tr)) tr = proj.tracks.find((t) => t.type === kind && free(t)) || newTrack(kind);
        tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
        if (c.isText) refreshText(c);
      }
      made.push({ type: it.type, id: c.id });
    }
    multi = made.length > 1 ? made : [];
    sel = { ...made[made.length - 1] };
    changed(); frame(true);
    return true;
  }
  function duplicateItem(m, o) {
    begin();
    const c = JSON.parse(JSON.stringify(o));
    c.id = uid(m.type === 'zoom' ? 'z' : m.type === 'fx' ? 'f' : 'c');
    if (o.b !== undefined) { const len = o.b - o.a; c.a = +Math.min(D - len, o.b).toFixed(2); c.b = +(c.a + len).toFixed(2); }
    else c.a = +Math.min(D - o.dur, o.a + o.dur).toFixed(2);
    if (m.type === 'zoom') { proj.zooms.push(c); proj.zooms.sort((x, y) => x.a - y.a); }
    else if (m.type === 'fx') proj.filters.push(c);
    else { const tr = trackOfClip(o.id); tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a); if (c.isText) refreshText(c); }
    sel = { type: m.type, id: c.id }; multi = [];
    changed();
  }
  async function replaceClip(c) {
    try {
      const r = await post('/api/pick', { kind: 'media' });
      const f = r.files && r.files[0];
      if (!f) { if (r.skipped && r.skipped.length) toast('Formato non supportato', true); return; }
      if ((f.kind === 'image') !== (c.kind === 'image')) return toast(c.kind === 'image' ? 'Scegli un\'immagine' : 'Scegli un suono', true);
      begin();
      c.file = f.path; c.name = f.name.replace(/\.[^.]+$/, '');
      if (f.kind === 'image' && f.w && f.h) c.ar = f.h / f.w;
      if (f.kind === 'audio') { c.fileDur = f.duration; c.offset = 0; c.dur = +Math.min(c.dur, f.duration).toFixed(2); }
      addAssets([f]);
      changed();
      toast('Sostituito');
    } catch (e) { toast(e.message, true); }
  }
  async function removeBg(c) {
    let job;
    try { job = await post('/api/removebg', { path: c.file }); } catch (e) { return toast(e.message, true); }
    const msg = h('span', { class: 'xs' }, 'Preparo…'), bar = h('div', { class: 'progress' }, h('div', { style: { width: '0%' } }));
    const bg = h('div', { class: 'modal-bg' }, h('div', { class: 'modal' }, h('h2', null, 'Rimuovo lo sfondo'), msg, bar));
    document.body.append(bg);
    const res = await pollJob(job.id, (j) => { bar.firstChild.style.width = (j.progress * 100).toFixed(0) + '%'; if (j.message) msg.textContent = j.message; });
    bg.remove();
    if (res.status !== 'done') return toast('Non sono riuscito a rimuovere lo sfondo: ' + (res.error || 'annullato'), true);
    begin(); c.file = res.result.path; c.name = (c.name || 'immagine') + ' (senza sfondo)'; addAssets([res.result]); changed();
    toast('Sfondo rimosso');
  }

  // menu a comparsa sotto un tasto
  function popMenu(anchor, items, atPoint) {
    document.querySelectorAll('.popmenu').forEach((m) => m.remove());
    const m = h('div', { class: 'popmenu', role: 'menu' }, ...items.map(([ic, label, sub, fn, color]) =>
      h('button', { class: 'pm-it' + (Array.isArray(fn) ? ' sub' : ''), role: 'menuitem', disabled: fn ? null : true, onclick: () => {
        m.remove();
        if (!fn) return;
        if (Array.isArray(fn)) popMenu({ getBoundingClientRect: () => ({ left: parseFloat(m.style.left), top: parseFloat(m.style.top), bottom: parseFloat(m.style.top), right: 0 }) }, fn, true);
        else fn();
      } },
        h('span', { class: 'pm-ic' }, icon(ic, 16, color || 'currentColor')),
        h('span', { class: 'pm-tx' }, h('b', null, label), sub ? h('span', null, sub) : null))));
    document.body.append(m);
    const r = anchor.getBoundingClientRect();
    m.style.left = Math.max(8, Math.min(window.innerWidth - m.offsetWidth - 8, r.left)) + 'px';
    if (atPoint) m.style.top = Math.max(8, Math.min(window.innerHeight - m.offsetHeight - 8, r.top)) + 'px';
    else { const top = r.top - m.offsetHeight - 6; m.style.top = (top > 8 ? top : r.bottom + 6) + 'px'; }
    const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  }

  // ---------------------------------------------------------------- aggiungere un altro video prima o dopo
  // ---------------------------------------------------------------- video nella traccia principale
  // Come in CapCut: il video entra tra due clip (mai a meta' di una), subito, e si puo' annullare.
  // Il server lo prepara soltanto (durata, audio, copia leggera se serve): il progetto lo cambia l'editor.
  let pendingIns = null;   // {at, dur, name, el} mentre il server lo prepara
  function drawPendingIns() {
    if (!pendingIns) return;
    const lane = tl.querySelector('.lane.video');
    if (!lane) return;
    // clip "in arrivo": larga al massimo quanto la parte visibile, con la barra di avanzamento
    const w = Math.max(90, Math.min((pendingIns.dur || 3) * pps, scroller.clientWidth - Math.max(0, X(pendingIns.at) - scroller.scrollLeft) - 8));
    if (!pendingIns.el) {
      pendingIns.bar = h('i', { class: 'ig-bar' });
      pendingIns.el = h('div', { class: 'insghost' }, h('div', { class: 'ig-body' }, h('div', { class: 'spinner sm' }), h('span', { class: 'ig-txt' }, 'Preparo il video…')), h('div', { class: 'ig-track' }, pendingIns.bar));
    }
    Object.assign(pendingIns.el.style, { left: X(pendingIns.at) + 'px', width: w + 'px' });
    if (pendingIns.el.parentNode !== lane) lane.append(pendingIns.el);
    lane.classList.add('pending');
  }
  async function insertVideo(path, at, known, opts = {}) {
    if (pendingIns) return toast('Un attimo: sto ancora aggiungendo l\'altro video.', true);
    video.pause();
    pendingIns = { at, dur: known && known.duration, name: known && known.name };
    drawPendingIns(); frame(true);
    let res;
    try {
      const job = await post(`/api/p/${pid}/prepinsert`, { path });
      res = await pollJob(job.id, (j) => {
        if (!pendingIns || !pendingIns.el) return;
        if (j.message) pendingIns.el.querySelector('.ig-txt').textContent = j.message + (j.progress > 0.02 ? ' · ' + Math.round(j.progress * 100) + '%' : '');
        pendingIns.bar.style.width = Math.round(Math.max(0.04, j.progress || 0) * 100) + '%';
      });
    } catch (e) { res = { status: 'error', error: e.message }; }
    if (pendingIns && pendingIns.el) { const ln = pendingIns.el.parentNode; pendingIns.el.remove(); if (ln) ln.classList.remove('pending'); }
    pendingIns = null;
    if (!alive) return;
    frame(true);
    if (res.status !== 'done') { toast('Non sono riuscito ad aggiungere il video: ' + (res.error || 'annullato'), true); return false; }
    const info = res.result;
    const rec = { id: uid('v'), at, dur: info.dur, offset: 0, file: info.file, name: info.name, w: info.w, h: info.h, hasAudio: info.hasAudio, vcodec: info.vcodec };
    if (info.preview) rec.preview = info.preview;
    if (info.image) { rec.image = true; rec.fileDur = info.fileDur; rec.src = info.src; rec.iar = info.iar; }
    // arriva da una traccia sopra: stesso pezzo e stessa durata
    if (opts.offset && !info.image) rec.offset = Math.max(0, Math.min(info.dur - 0.2, opts.offset));
    if (opts.dur) rec.dur = +Math.max(0.2, Math.min((info.image ? info.fileDur : info.dur) - rec.offset, opts.dur)).toFixed(4);   // immagine: video fermo, si allunga quanto vuoi
    clipPeaks.set(rec.file, info.peaks || []);
    await applyInsert(rec, null);
    if (!opts.quiet) toast(info.image ? 'Immagine aggiunta: tira il bordo destro per farla durare di più' : 'Video aggiunto');
    // la trascrizione del video nuovo arriva dopo, senza bloccare
    if (proj.transcript && proj.transcript.status === 'done' && ENV_WHISPER()) transcribeInsert(rec);
    return true;
  }
  const ENV_WHISPER = () => !!(ctx.env && ctx.env.whisper);
  async function transcribeInsert(rec) {
    try {
      const job = await post(`/api/p/${pid}/inserttranscript`, { path: rec.file, dur: rec.dur, offset: rec.offset || 0 });
      const res = await pollJob(job.id, () => {});
      if (!alive || res.status !== 'done') return;
      const cur = (proj.inserts || []).find((x) => x.id === rec.id);
      if (!cur) return;
      const segs = (res.result.segments || []).map((sg) => ({ ...sg, a: sg.a + cur.at, b: sg.b + cur.at, words: (sg.words || []).map((w) => ({ ...w, a: w.a + cur.at, b: w.b + cur.at })) }));
      if (!segs.length) return;
      await flush();
      proj.transcript.segments = allWords().concat(segs).sort((x, y) => x.a - y.a);
      undoStack = undoStack.filter((x) => typeof x !== 'string'); redoStack = redoStack.filter((x) => typeof x !== 'string'); updateUndo();
      changed({ transcript: true });
      if (tab === 'text') renderPanel();
    } catch (e) { /* la trascrizione e' un di piu' */ }
  }
  // come CapCut: si spostano solo le clip della traccia principale (e le parole della live, che sono il suo audio);
  // tutto quello che sta sulle altre tracce (testi, immagini, video sopra, suoni, filtri, zoom) resta dov'e'
  function shiftAfter(t0, dt) {
    const sh = (x) => (x >= t0 - 1e-6 ? +(x + dt).toFixed(4) : x);
    for (const sg of allWords()) { sg.a = sh(sg.a); sg.b = sh(sg.b); for (const w of sg.words || []) { w.a = sh(w.a); w.b = sh(w.b); } }
    for (const i of proj.inserts || []) if (i.at >= t0 - 1e-6) i.at = +(i.at + dt).toFixed(4);
    const shV = (x, strict) => ((strict ? x > t0 + 1e-6 : x >= t0 - 1e-6) ? +(x + dt).toFixed(4) : x);
    for (const v of proj.verticals || []) { v.a = shV(v.a); v.b = shV(v.b, true); if (v.ranges) v.ranges = v.ranges.map(([a, b]) => [shV(a), shV(b, true)]); }
    const segs = [];
    for (const c of proj.segs) {
      if (c.b <= t0 + 1e-6) segs.push(c);
      else if (c.a >= t0 - 1e-6) { c.a = +(c.a + dt).toFixed(4); c.b = +(c.b + dt).toFixed(4); segs.push(c); }
      else { segs.push({ ...c, b: t0 }, { ...c, id: uid('s'), a: +(t0 + dt).toFixed(4), b: +(c.b + dt).toFixed(4) }); }
    }
    proj.segs = segs;
  }
  // il contrario: toglie il tratto [t0, t0+dt] e riporta indietro quello che segue
  function shiftBack(t0, dt) {
    const t1 = t0 + dt;
    const sh = (x) => (x >= t1 - 1e-6 ? +(x - dt).toFixed(4) : Math.min(x, t0));
    if (proj.transcript) {
      proj.transcript.segments = allWords().filter((sg) => !(sg.a >= t0 - 1e-6 && sg.b <= t1 + 1e-6)).map((sg) => {
        sg.words = (sg.words || []).filter((w) => !(w.a >= t0 - 1e-6 && w.b <= t1 + 1e-6));
        sg.a = sh(sg.a); sg.b = sh(sg.b); sg.words.forEach((w) => { w.a = sh(w.a); w.b = sh(w.b); });
        return sg;
      });
    }
    for (const i of proj.inserts || []) if (i.at >= t1 - 1e-6) i.at = +(i.at - dt).toFixed(4);
    for (const v of proj.verticals || []) { v.a = sh(v.a); v.b = sh(v.b); if (v.ranges) v.ranges = v.ranges.map(([a, b]) => [sh(a), sh(b)]).filter(([a, b]) => b - a > 0.05); }
    proj.verticals && (proj.verticals = proj.verticals.filter((v) => v.b - v.a > 0.2));
    proj.segs = proj.segs.map((c) => ({ ...c, a: sh(c.a), b: sh(c.b) })).filter((c) => c.b - c.a > 0.02);
  }
  const liveDur = () => proj.liveDuration || (D - (proj.inserts || []).reduce((s, i) => s + i.dur, 0));
  // mette il video in timeline (rec.at = dove). undoEntry: se e' un "ripeti"
  // --- parte "dati": mette / toglie un video inserito (niente disegno, niente salvataggio)
  function insertCore(rec, ownSegs) {
    let at = Math.max(0, Math.min(D, rec.at));
    for (const i of proj.inserts || []) if (i.at < at && at < i.at + i.dur) at = at - i.at < i.at + i.dur - at ? i.at : i.at + i.dur;
    if (at < 0.3) at = 0; else if (at > D - 0.3) at = D;
    rec.at = +at.toFixed(4);
    proj.liveDuration = liveDur();
    shiftAfter(rec.at, rec.dur);
    proj.inserts = (proj.inserts || []).concat([rec]).sort((a, b) => a.at - b.at);
    // le clip del video (se era stato diviso, velocizzato, spento… resta com'era)
    const segs = ownSegs && ownSegs.length
      ? ownSegs.map((c) => ({ ...c, a: +(rec.at + c.a).toFixed(4), b: +(rec.at + c.b).toFixed(4), ins: rec.id }))
      : [{ id: uid('s'), a: rec.at, b: +(rec.at + rec.dur).toFixed(4), removed: false, auto: false, vol: 100, mute: false, fin: false, fout: false, ins: rec.id }];
    proj.segs.push(...segs); proj.segs.sort((a, b) => a.a - b.a);
    if (rec.words && rec.words.length) proj.transcript.segments = allWords().concat(rec.words.map((sg) => ({ ...sg, a: sg.a + rec.at, b: sg.b + rec.at, words: (sg.words || []).map((w) => ({ ...w, a: w.a + rec.at, b: w.b + rec.at })) }))).sort((x, y) => x.a - y.a);
    delete rec.words;
    D = proj.liveDuration + proj.inserts.reduce((s2, i) => s2 + i.dur, 0);
    proj.duration = D;
    return segs;
  }
  function removeCore(id) {
    const rec = (proj.inserts || []).find((x) => x.id === id);
    if (!rec) return null;
    const words = allWords().filter((sg) => sg.a >= rec.at - 1e-6 && sg.b <= rec.at + rec.dur + 1e-6);
    const own = proj.segs.filter((c) => c.ins === id).map((c) => ({ ...c, a: +(c.a - rec.at).toFixed(4), b: +(c.b - rec.at).toFixed(4) }));
    const copy = { ...rec, words: words.map((sg) => ({ ...sg, a: sg.a - rec.at, b: sg.b - rec.at, words: (sg.words || []).map((w) => ({ ...w, a: w.a - rec.at, b: w.b - rec.at })) })) };
    proj.segs = proj.segs.filter((c) => c.ins !== id);
    proj.inserts = proj.inserts.filter((x) => x.id !== id);
    shiftBack(rec.at, rec.dur);
    D = proj.liveDuration + proj.inserts.reduce((s2, i) => s2 + i.dur, 0);
    proj.duration = D;
    return { copy, own };
  }
  // l'inserimento, lo spostamento e la loro storia (Ctrl+Z / Ctrl+Y): la storia di prima non vale piu' (i tempi cambiano)
  // ---------------------------------------------------------------- calamita della traccia principale e spazi vuoti
  // Calamita accesa (come prima): le clip principali stanno attaccate. Spenta: si possono lasciare spazi vuoti (neri)
  function magnetOn() { return IS_V || proj.settings.magnet !== false; }
  const insById = (id) => (proj.inserts || []).find((x) => x.id === id);
  const isGapSeg = (c) => !!(c && c.ins && (insById(c.ins) || {}).gap);
  let gapInfo = null;
  async function getGap() { if (!gapInfo) gapInfo = await post(`/api/p/${pid}/gapfile`, {}); return gapInfo; }
  function fullSnap() {
    return JSON.stringify({ inserts: proj.inserts || [], segs: proj.segs, tracks: proj.tracks, zooms: proj.zooms, filters: proj.filters, verticals: proj.verticals || [],
      tr: proj.transcript ? proj.transcript.segments : null, duration: proj.duration, liveDuration: proj.liveDuration });
  }
  async function fullRestore(snap) {
    const s2 = JSON.parse(snap);
    Object.assign(proj, { inserts: s2.inserts, segs: s2.segs, tracks: s2.tracks, zooms: s2.zooms, filters: s2.filters, verticals: s2.verticals, duration: s2.duration, liveDuration: s2.liveDuration });
    if (s2.tr && proj.transcript) proj.transcript.segments = s2.tr;
    D = proj.duration; sel = null; multi = [];
    await afterDurationChange();
    changed({ transcript: true });
  }
  // passi "completi" (cambiano i tempi della timeline): si annullano uno alla volta
  function pushFull(snap) { undoStack = undoStack.filter((x) => typeof x === 'object' && x.kind === 'full'); undoStack.push({ kind: 'full', snap }); redoStack = []; updateUndo(); }
  const segById = (id) => proj.segs.find((x) => x.id === id);
  const gapBefore = (c) => proj.segs.find((x) => !x.gone && isGapSeg(x) && Math.abs(x.b - c.a) < 2e-3);
  const gapAfter = (c) => proj.segs.find((x) => !x.gone && isGapSeg(x) && Math.abs(x.a - c.b) < 2e-3);
  function addGapCore(g, at, dur) {
    insertCore({ id: uid('v'), at: +at.toFixed(4), dur: +dur.toFixed(4), offset: 0, file: g.file, name: 'Spazio vuoto', w: g.w, h: g.h, hasAudio: false, vcodec: 'h264', gap: true });
  }
  function shrinkGapCore(g, seg, by) {
    const rec = insById(seg.ins);
    if (!rec) return;
    const at = rec.at, len = rec.dur;
    removeCore(rec.id);
    if (len - by > 0.03) addGapCore(g, at, len - by);
  }
  // sposta una clip della traccia principale di dt secondi, lasciando (o chiudendo) spazio vuoto.
  // Da sola: le clip dopo restano ferme finche' c'e' spazio. In gruppo ("seleziona a destra"): si sposta tutto insieme.
  // ---- calamita spenta: la traccia principale diventa una semplice fila di clip (ognuna un pezzo di un file) e
  // spazi vuoti. Ogni operazione cambia la fila e la ricostruisce: niente pezzi nascosti, tempi sempre giusti.
  function mainItems() {
    return proj.segs.filter((c) => !c.gone && !(BLANK && !c.ins)).sort((x, y) => x.a - y.a).map((c) => {
      const d = mainClipData(c);
      const rec = c.ins && insById(c.ins);
      // la clip e' ancora un video inserito intero: tiene il suo id (forma d'onda e miniature gia' pronte)
      const whole = rec && Math.abs(rec.at - c.a) < 1e-3 && Math.abs(rec.at + rec.dur - c.b) < 1e-3;
      return { ...d, keepId: whole ? rec.id : null, segId: c.id };
    });
  }
  const gapItem = (g, dur) => ({ file: g.file, offset: 0, live: false, gap: true, name: 'Spazio vuoto', w: g.w, h: g.h, hasAudio: false, vcodec: 'h264', dur: +dur.toFixed(4),
    seg: { removed: false, auto: false, vol: 100, mute: false, fin: false, fout: false }, words: [] });
  function tidyItems(items, g) {
    const out = [];
    for (const it of items) {
      if (it.dur < 0.02) continue;
      const last = out[out.length - 1];
      if (it.gap && last && last.gap) { last.dur = +(last.dur + it.dur).toFixed(4); continue; }   // spazi attaccati: uno solo
      out.push(it.gap ? { ...gapItem(g, it.dur) } : it);
    }
    while (out.length && out[out.length - 1].gap) out.pop();   // spazio vuoto in fondo: non serve
    return out;
  }
  // tempo di adesso -> tempo senza i pezzi nascosti (per rimettere testi, zoom, filtri al loro posto a vista)
  function goneMapper() {
    const gr = proj.segs.filter((c) => c.gone && !(BLANK && !c.ins)).map((c) => [c.a, c.b]).sort((x, y) => x[0] - y[0]);
    if (!gr.length) return null;
    return (t) => { let d = 0; for (const [a, b] of gr) { if (t >= b) d += b - a; else if (t > a) d += t - a; } return +(t - d).toFixed(4); };
  }
  function rebuildMain(items) {
    const G = goneMapper();
    if (G) {   // la prima volta: testi, immagini, suoni, zoom, filtri e clip verticali seguono le clip a vista
      for (const tr of proj.tracks || []) if (tr.type !== 'live') (tr.clips || []).forEach((c) => { c.a = G(c.a); });
      (proj.zooms || []).forEach((z) => { z.a = G(z.a); z.b = Math.max(z.a + 0.1, G(z.b)); });
      (proj.filters || []).forEach((f) => { f.a = G(f.a); f.b = Math.max(f.a + 0.1, G(f.b)); });
      for (const v of proj.verticals || []) { v.a = G(v.a); v.b = G(v.b); if (v.ranges) v.ranges = v.ranges.map(([a, b]) => [G(a), G(b)]); }
    }
    const liveD = liveDur();
    const ins = [], segs = [], words = [];
    let at = 0;
    for (const it of items) {
      const id = it.keepId || uid('v');
      const rec = { id, at: +at.toFixed(4), dur: it.dur, offset: it.offset || 0, file: it.file, name: it.name, w: it.w, h: it.h, hasAudio: it.hasAudio, vcodec: it.vcodec };
      if (it.live) rec.live = true;
      if (it.gap) rec.gap = true;
      if (it.preview) rec.preview = it.preview;
      if (it.image) { rec.image = true; rec.fileDur = it.fileDur; rec.src = it.src; rec.iar = it.iar; }
      ins.push(rec);
      segs.push({ ...it.seg, id: it.segId || uid('s'), a: rec.at, b: +(at + it.dur).toFixed(4), ins: id, gone: false, fill: undefined });
      for (const sg of it.words || []) words.push({ ...sg, a: sg.a + at, b: sg.b + at, words: (sg.words || []).map((w2) => ({ ...w2, a: w2.a + at, b: w2.b + at })) });
      at += it.dur;
    }
    // la live (o il nero del progetto vuoto) resta in fondo, nascosta: e' solo la base da cui si leggono le clip
    const tail = { id: uid('s'), a: +at.toFixed(4), b: +(at + liveD).toFixed(4), removed: !BLANK, gone: !BLANK, auto: false, vol: 100, mute: false, fin: false, fout: false };
    proj.inserts = ins;
    proj.segs = segs.concat([tail]);
    proj.liveDuration = liveD;
    proj.duration = +(at + liveD).toFixed(4);
    D = proj.duration;
    if (proj.transcript && proj.transcript.segments) proj.transcript.segments = words.sort((x, y) => x.a - y.a);
  }
  // una clip sola: si sposta solo lei. Al suo posto resta spazio vuoto; nel punto scelto entra nello spazio vuoto
  // (se ci sta) senza muovere le altre, se no si mette al bordo della clip piu' vicina
  function freeMoveSingle(cid, dv, g, grab = 0) {
    const items = mainItems();
    const k = items.findIndex((it) => it.segId === cid);
    if (k < 0) return false;
    const c = segById(cid);
    const t = T(Math.max(0, V(c.a) + dv));   // dove la vuoi (tempo di adesso)
    const X_ = items[k];
    let acc = 0;
    const G = goneMapper(), tt = G ? G(t) : t;   // stessa scala della fila
    items[k] = gapItem(g, X_.dur);
    let list = tidyItems(items, g);
    const st2 = []; acc = 0;
    for (const it of list) { st2.push(acc); acc += it.dur; }
    const end = acc;
    if (tt >= end - 1e-3) {
      if (tt - end > 0.03) list.push(gapItem(g, tt - end));
      list.push(X_);
    } else {
      const j = st2.findIndex((s0, i) => tt >= s0 - 1e-3 && tt < s0 + list[i].dur);
      const it = list[j];
      // dove c'e' il puntatore (non l'inizio della clip): e' li' che l'utente la vuole
      const tp = Math.min(end - 1e-3, tt + Math.max(0, Math.min(X_.dur, grab)));
      const jp = st2.findIndex((s0, i) => tp >= s0 - 1e-3 && tp < s0 + list[i].dur);
      const want = it ? tt - st2[j] : 0, fitB = it ? Math.max(0, Math.min(it.dur - X_.dur, want)) : 0;
      if (it && it.gap && it.dur >= X_.dur - 1e-3 && Math.abs(fitB - want) <= Math.max(0.5, X_.dur * 0.3)) {
        // lo spazio vuoto basta: la clip ci entra (se sborda di poco, si aggancia dentro)
        const before = fitB, after = it.dur - before - X_.dur;
        list.splice(j, 1, gapItem(g, before), X_, gapItem(g, after));
      } else {
        // sopra un'altra clip: prima o dopo di lei, secondo dove sta il puntatore
        const ip = jp >= 0 ? jp : list.length - 1, pi = list[ip];
        if (pi && pi.gap && pi.dur >= X_.dur - 1e-3) {
          const before = Math.max(0, Math.min(pi.dur - X_.dur, tp - grab - st2[ip]));
          list.splice(ip, 1, gapItem(g, before), X_, gapItem(g, pi.dur - before - X_.dur));
        } else list.splice(pi && tp - st2[ip] < pi.dur / 2 ? ip : ip + 1, 0, X_);
      }
    }
    rebuildMain(tidyItems(list, g));
    return true;
  }
  // gruppo ("seleziona a destra"): si sposta tutto insieme, aggiungendo o togliendo spazio vuoto prima della prima clip
  function freeMoveGroup(cid, dt, g, groupItems) {
    const items = mainItems();
    const k = items.findIndex((it) => it.segId === cid);
    if (k < 0) return false;
    let eff = 0;
    const prev = items[k - 1];
    if (dt > 0.02) {
      if (prev && prev.gap) prev.dur = +(prev.dur + dt).toFixed(4); else items.splice(k, 0, gapItem(g, dt));
      eff = dt;
    } else if (dt < -0.02) {
      if (!prev || !prev.gap) { toast('Prima di queste clip non c\'è spazio vuoto da togliere'); return false; }
      const take = Math.min(-dt, prev.dur);
      prev.dur = +(prev.dur - take).toFixed(4);
      eff = -take;
    } else return false;
    rebuildMain(tidyItems(items, g));
    for (const it of groupItems) {
      const o = findSel(it);
      if (!o) continue;
      if (o.b !== undefined) { const len = o.b - o.a; o.a = +Math.max(0, o.a + eff).toFixed(3); o.b = +(o.a + len).toFixed(3); }
      else o.a = +Math.max(0, o.a + eff).toFixed(3);
    }
    return true;
  }
  async function freeMove(cid, dv, isGroup, groupItems, grab = 0) {
    let g;
    try { g = await getGap(); } catch (e) { toast('Non riesco a preparare lo spazio vuoto: ' + e.message, true); return; }
    const snap = fullSnap();
    const ok = isGroup ? freeMoveGroup(cid, dv, g, groupItems) : freeMoveSingle(cid, dv, g, grab);
    if (!ok) return;
    sel = null; multi = [];
    pushFull(snap);
    lightRefresh();
  }
  // dopo uno spostamento: si ridisegna la timeline e basta (le miniature restano, niente ricaricamenti)
  function lightRefresh() {
    refreshGone(); lastViewEnd = null; refit();
    composeWave();
    dirty = true; scheduleSave();
    changed({ transcript: true });
  }
  function startFreeMove(e, seg, el) {
    const x0 = e.clientX, y0 = e.clientY;
    const isGroup = multi.length > 1 && multi.some((m) => isSeg(m.type) && m.id === seg.id);
    const group = isGroup ? multi.filter((m) => ['sclip', 'zoom', 'fx'].includes(m.type)) : [];
    // cosa si muove a vista: la clip (o tutte quelle dopo, se e' un gruppo) e gli elementi del gruppo
    const moving = [];
    lanes.querySelectorAll('.blk').forEach((b) => {
      const id = b.dataset.id, ty = b.dataset.type;
      if (!id) return;
      if (isSeg(ty) && (id === seg.id || (isGroup && (segById(id) || {}).a >= seg.a - 1e-3))) moving.push(b);
      else if (group.some((m) => m.id === id && m.type === ty)) moving.push(b);
    });
    let moved = false, dx = 0, lift = null, xLane = null;
    const grab = Math.max(0, tAt(e) - seg.a);   // dove l'hai presa, dentro la clip
    el.setPointerCapture(e.pointerId);
    const mv = (ev) => {
      if (!moved && Math.abs(ev.clientX - x0) < 5 && Math.abs(ev.clientY - y0) < 5) return;
      if (!moved) lift = liftVisual(moving.filter((b) => isSeg(b.dataset.type)).map((b) => b.dataset.id));
      moved = true;
      dx = ev.clientX - x0;
      if (isGroup) {   // il gruppo va a sinistra solo se prima c'e' spazio vuoto
        const gb = gapBefore(seg);
        dx = Math.max(dx, gb ? -(gb.b - gb.a) * pps : 0);
      } else dx = Math.max(dx, -X(seg.a));
      moving.forEach((b) => { b.style.transform = `translateX(${dx}px)`; b.classList.add('lifted'); });
      if (lift) lift.move(dx, !isGroup && canLeaveMain(seg) ? ev.clientY - y0 : 0);
      xLane = !isGroup && canLeaveMain(seg) ? laneUnder(ev, 'overlay') : null;
      markLane(xLane);
    };
    const up = async (ev) => {
      el.removeEventListener('pointermove', mv);
      moving.forEach((b) => { b.style.transform = ''; b.classList.remove('lifted'); });
      if (!moved) { tapSeek(ev, Math.max(seg.a, Math.min(seg.b - 0.05, tAt(ev)))); return; }
      markLane(null);
      if (xLane) { if (lift) lift.done(); await mainToOverlay(seg, xLane, tAt(ev) - grab); return; }
      if (Math.abs(dx) >= 2) await freeMove(seg.id, dx / pps, isGroup, group, grab);
      if (lift) lift.done();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }
  async function setMainMagnet(on) {
    if (on === magnetOn()) return;
    if (on) {
      // calamita accesa: gli spazi vuoti si chiudono
      const gaps = proj.segs.filter((c) => !c.gone && isGapSeg(c));
      if (gaps.length) {
        const snap = fullSnap();
        rebuildMain(mainItems().filter((it) => !it.gap));
        pushFull(snap);
        lightRefresh();
      }
    }
    proj.settings.magnet = on;
    mainMagBtn.setAttribute('aria-pressed', String(on));
    changed();
    toast(on ? 'Calamita accesa: le clip principali restano attaccate' : 'Calamita spenta: puoi lasciare spazi vuoti tra le clip');
  }
  // seleziona tutto quello che c'e' a destra (o a sinistra) della testina: poi si sposta insieme
  function selectSide(dir) {
    const t = video.currentTime, out = [];
    const ok = (a, b) => (dir > 0 ? a >= t - 1e-3 : b <= t + 1e-3);
    for (const c of proj.segs) if (!c.gone && !(BLANK && !c.ins) && ok(c.a, c.b)) out.push({ type: 'seg', id: c.id });
    for (const tr of proj.tracks || []) if (tr.type !== 'live') for (const c of tr.clips || []) if (ok(c.a, c.a + (c.dur || 0))) out.push({ type: 'sclip', id: c.id });
    for (const z of proj.zooms || []) if (ok(z.a, z.b)) out.push({ type: 'zoom', id: z.id });
    for (const f of proj.filters || []) if (ok(f.a, f.b)) out.push({ type: 'fx', id: f.id });
    if (!out.length) { toast(dir > 0 ? 'Non c\'è niente dopo la testina' : 'Non c\'è niente prima della testina'); return; }
    multi = out.length > 1 ? out : []; sel = { ...out[dir > 0 ? 0 : out.length - 1] };
    renderTimeline(); renderPanel();
    toast(`${out.length} elementi selezionati: trascinali per spostarli insieme` + (magnetOn() && out.some((m) => m.type === 'seg') ? ' (per spostare anche le clip principali spegni la calamita)' : ''));
  }
  // progetto vuoto: un video messo nella traccia principale prende il posto del nero (dalla fine), cosi' la durata non cresce
  function consumeBlack(d) {
    const cand = proj.segs.filter((c) => !c.ins && !c.gone).sort((x, y) => y.a - x.a);
    for (const c of cand) {
      if (d <= 1e-3) break;
      const take = Math.min(d, c.b - c.a);
      if (take >= c.b - c.a - 1e-3) Object.assign(c, { gone: true, removed: true, fill: true });
      else { const nb = +(c.b - take).toFixed(4); proj.segs.push({ ...c, id: uid('s'), a: nb, b: c.b, gone: true, removed: true, fill: true }); c.b = nb; }
      d -= take;
    }
    proj.segs.sort((x, y) => x.a - y.a);
  }
  function restoreBlack(d) {
    const cand = proj.segs.filter((c) => !c.ins && c.fill).sort((x, y) => x.a - y.a);
    for (const c of cand) {
      if (d <= 1e-3) break;
      const take = Math.min(d, c.b - c.a);
      if (take >= c.b - c.a - 1e-3) { c.gone = false; c.removed = false; delete c.fill; }
      else { const na = +(c.a + take).toFixed(4); proj.segs.push({ ...c, id: uid('s'), a: c.a, b: na, gone: false, removed: false, fill: undefined }); c.a = na; }
      d -= take;
    }
    proj.segs.sort((x, y) => x.a - y.a);
  }
  async function applyInsert(rec, again, ownSegs) {
    const segs = insertCore(rec, ownSegs);
    undoStack = [{ kind: 'insert', id: rec.id }]; if (!again) redoStack = [];
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id }; tab = 'video';
    changed({ transcript: true });
    seek(rec.at + 0.05);
  }
  async function removeInsert(id) {
    const r = removeCore(id);
    if (!r) return null;
    sel = null;
    await afterDurationChange();
    changed({ transcript: true });
    seek(Math.max(0, r.copy.at - 0.05));
    return { ...r.copy, own: r.own };
  }
  // sposta un video inserito in un altro punto della traccia principale (target = tempo prima dello spostamento)
  async function moveInsert(id, target, fromHistory) {
    const rec = (proj.inserts || []).find((x) => x.id === id);
    if (!rec) return false;
    if (target >= rec.at - 1e-3 && target <= rec.at + rec.dur + 1e-3) return false;   // stesso posto
    const from = rec.at;
    const r = removeCore(id);
    const at = target > from ? target - r.copy.dur : target;
    const segs = insertCore({ ...r.copy, at }, r.own);
    if (!fromHistory) { undoStack = [{ kind: 'move', id, back: from }]; redoStack = []; }
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id };
    changed({ transcript: true });
    seek(segs[0].a + 0.05);
    return true;
  }
  async function afterDurationChange() {
    refreshGone(); lastViewEnd = null; refit();
    composeWave();
    dirty = true; await flush();   // il server deve sapere dei file nuovi prima che l'anteprima li chieda
    drawThumbs();   // le miniature sono legate ai file, non alla posizione: si riusano quelle che ci sono
  }
  // forma d'onda della timeline: la live a pezzi + quella dei video inseriti
  function composeWave() {
    if (!waveLive) return;
    const ps = waveLive.perSec || 5, lp = waveLive.peaks || [];
    const list = (proj.inserts || []).slice().sort((a, b) => a.at - b.at);
    if (!list.length) { wave = waveLive; drawWave(); return; }
    const out = [];
    let T0 = 0, L = 0;
    const put = (src, a0, n) => { for (let k = 0; k < n; k++) out.push(src[a0 + k] || 0); };
    for (const i of list) {
      if (i.at > T0 + 1e-6) { const n = Math.round((i.at - T0) * ps); put(lp, Math.round(L * ps), n); L += i.at - T0; T0 = i.at; }
      if (i.live) { put(lp, Math.round((i.offset || 0) * ps), Math.round(i.dur * ps)); T0 += i.dur; continue; }
      if (i.gap) { put([], 0, Math.round(i.dur * ps)); T0 += i.dur; continue; }
      const cp = clipPeaks.get(i.file);   // per file: le clip spostate o divise usano la stessa forma d'onda
      if (!cp && i.image) clipPeaks.set(i.file, []);   // foto: niente audio da leggere
      else if (!cp) { clipPeaks.set(i.file, []); get(`/api/p/${pid}/clipwave?path=${encodeURIComponent(i.file)}`).then((w) => { clipPeaks.set(i.file, w.peaks || []); composeWave(); }).catch(() => {}); }
      put(cp || [], Math.round((i.offset || 0) * ps), Math.round(i.dur * ps));
      T0 += i.dur;
    }
    put(lp, Math.round(L * ps), Math.round((liveDur() - L) * ps) + 1);
    wave = { perSec: ps, peaks: out };
    drawWave();
  }

  // ---------------------------------------------------------------- finestra di esportazione
  const EXPORT_DEFAULT = { dir: '', format: 'mp4', codec: 'h264', bitrate: 'rec', fps: 'source', audio: true, abr: 192 };
  const BPP = { low: 0.05, rec: 0.1, high: 0.18 };   // uguale a engine/render.py
  function fmtSize(b) { return b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB'; }
  function fmtLong(t) { t = Math.round(t); const hh = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60; return (hh ? hh + 'h ' : '') + (hh || m ? m + 'm ' : '') + s + 's'; }
  async function openExport() {
    if (outDuration() < 1) return toast(BLANK ? 'Il progetto è vuoto: trascina un video nella timeline o aggiungi un testo.' : 'Hai tagliato tutto il video.', true);
    video.pause();
    const S = proj.settings;
    const E = { ...EXPORT_DEFAULT, ...(S.export || {}) };
    let quality = S.quality, name = proj.name;
    const srcFps = proj.fps || 30;
    const resOpts = [2160, 1440, 1080, 720, 480].filter((x) => x <= H + 8).map((x) => [x + 'p', x === 2160 ? '4K' : x + 'p']);
    if (!resOpts.some(([v]) => v === quality)) quality = resOpts[0][0];
    const fpsOpts = [['source', `Originale (${Math.round(srcFps)} fps)`], ...[60, 50, 30, 25, 24].filter((f) => f < srcFps - 0.5).map((f) => [String(f), f + ' fps'])];
    const sel_ = (opts, cur, onCh) => {
      const s2 = h('select', { class: 'input xsel' }, ...opts.map(([v, l]) => h('option', { value: v, selected: String(v) === String(cur) ? true : null }, l)));
      s2.addEventListener('change', () => { onCh(s2.value); update(); });
      return s2;
    };
    const row = (label, ctl, tip) => h('div', { class: 'xrow', 'data-tip': tip || null }, h('span', { class: 'xl' }, label), ctl);
    // anteprima: il fotogramma che stai guardando
    const cover = VERT ? h('canvas', { class: 'xcover vert', width: '360', height: '640' }) : h('canvas', { class: 'xcover', width: '640', height: String(Math.round(640 * H / W)) });
    try {
      const g = cover.getContext('2d');
      if (VERT) {
        // come sara' il video verticale in questo punto
        const { regs, el, sx, sy } = vRegsAt(video.currentTime);
        for (const rg of regs) {
          const [dx, dy, dw, dh] = rg.d, [x, y, w, hh] = rg.s;
          g.filter = rg.blur ? 'blur(10px) brightness(0.93)' : 'none';
          g.drawImage(el, x * sx, y * sy, w * sx, hh * sy, dx * 360, dy * 640, dw * 360, dh * 640);
        }
      } else g.drawImage(video.el, 0, 0, cover.width, cover.height);
    } catch (e) { /* */ }
    const nameInp = h('input', { class: 'input', value: name, maxlength: '120', 'aria-label': 'Nome' });
    nameInp.addEventListener('input', () => { name = nameInp.value; update(); });
    const dirLbl = h('span', { class: 'xpath' });
    const dirBtn = ibtn('folder', 'Scegli la cartella', async () => {
      try {
        const r = await post('/api/pick', { kind: 'folder' });
        if (r.fallback) { const v = prompt('Cartella dove salvare il video:', E.dir || env.exportsDir || ''); if (v) E.dir = v.trim().replace(/^"|"$/g, ''); }
        else if (r.path) E.dir = r.path;
        update();
      } catch (e) { toast(e.message, true); }
    }, { size: 16 });
    // cosa esportare: il video orizzontale e/o le sue clip verticali
    const VL = IS_V ? [] : proj.verticals;
    const want = { vod: true, verticals: [] };
    if (S.exportWant && VL.length) { want.vod = S.exportWant.vod !== false; want.verticals = (S.exportWant.verticals || []).filter((id) => VL.some((v) => v.id === id)); }
    const whatBox = h('div', { class: 'xgroup xwhat' });
    function drawWhat() {
      const ck = (on, label, sub, fn, ic) => h('label', { class: 'xck' + (on ? ' on' : '') },
        h('input', { type: 'checkbox', checked: on ? true : null, onchange: (e) => { fn(e.target.checked); drawWhat(); update(); } }),
        h('span', { class: 'xck-ic' }, icon(ic, 14, 'currentColor', 2)), h('span', { class: 'xck-nm', 'data-notr': '' }, label), h('span', { class: 'xck-sub' }, sub));
      const all = VL.length && want.vod && want.verticals.length === VL.length;
      whatBox.replaceChildren(
        h('div', { class: 'xwhat-q' },
          h('button', { class: 'pchip' + (want.vod && !want.verticals.length ? ' on' : ''), onclick: () => { want.vod = true; want.verticals = []; drawWhat(); update(); } }, 'Solo il video'),
          h('button', { class: 'pchip' + (all ? ' on' : ''), onclick: () => { want.vod = true; want.verticals = VL.map((v) => v.id); drawWhat(); update(); } }, 'Tutto'),
          h('button', { class: 'pchip' + (!want.vod && want.verticals.length === VL.length ? ' on' : ''), onclick: () => { want.vod = false; want.verticals = VL.map((v) => v.id); drawWhat(); update(); } }, 'Solo le verticali')),
        ck(want.vod, name.trim() || proj.name, '16:9 · ' + fmtLong(outDuration()), (v) => { want.vod = v; }, 'film'),
        ...VL.map((v) => ck(want.verticals.includes(v.id), v.name, '9:16 · clip verticale', (on) => { want.verticals = on ? [...want.verticals, v.id] : want.verticals.filter((x) => x !== v.id); }, 'phone')));
    }
    const audioOpts = h('div', { class: 'xgroup' });
    const audioTgl = toggle(E.audio, (v) => { E.audio = v; audioTgl.setAttribute('aria-pressed', String(v)); update(); }, 'Audio');
    const info = h('span', { class: 'xinfo' });
    const warn = h('span', { class: 'xwarn' });
    const vgroup = h('div', { class: 'xgroup' },
      row('Risoluzione', sel_(resOpts, quality, (v) => { quality = v; })),
      row('Bitrate', sel_([['low', 'Più leggero'], ['rec', 'Consigliato'], ['high', 'Alta qualità']], E.bitrate, (v) => { E.bitrate = v; }), 'Più alto = più qualità ma file più pesante'),
      row('Codec', sel_([['h264', 'H.264 · funziona ovunque'], ['h265', 'HEVC (H.265) · file più leggero']], E.codec, (v) => { E.codec = v; })),
      row('Formato', sel_([['mp4', 'mp4'], ['mov', 'mov']], E.format, (v) => { E.format = v; })),
      row('Fotogrammi', sel_(fpsOpts, E.fps, (v) => { E.fps = v; })));
    audioOpts.append(row('Qualità audio', sel_([['128', '128 kbps'], ['192', '192 kbps'], ['320', '320 kbps']], E.abr, (v) => { E.abr = +v; })));
    function update() {
      const qh = Math.min(parseInt(quality, 10) || H, H);
      let oh = Math.floor(qh / 2) * 2, ow = Math.round(oh * W / H / 2) * 2;
      if (VERT) { ow = Math.max(2, Math.round(qh / 2) * 2); oh = Math.max(2, Math.round(ow * 16 / 9 / 2) * 2); }   // come engine/vertical.py
      const f = E.fps === 'source' ? srcFps : Math.min(srcFps, +E.fps);
      const vbr = (BPP[E.bitrate] || 0.1) * ow * oh * f * (E.codec === 'h265' ? 0.6 : 1);
      const bytes = outDuration() * (vbr + (E.audio ? E.abr * 1000 : 0)) / 8;
      info.textContent = `Durata: ${fmtLong(outDuration())}  ·  ${ow}×${oh}  ·  Dimensioni: circa ${fmtSize(bytes)}`;
      const dir = E.dir || env.exportsDir || '';
      const sep = dir.includes('\\') ? '\\' : '/';
      const nOut = (want.vod ? 1 : 0) + want.verticals.length;
      const safe = (x) => (x.trim() || 'video').replace(/[\\/:*?"<>|]+/g, '_');
      let full = dir + sep + safe(name) + '.' + E.format;
      if (VL.length) {
        if (want.vod && want.verticals.length) full = dir + sep + safe(name) + sep;
        else if (!want.vod && want.verticals.length > 1) full = dir + sep + safe(name) + ' - Clip verticali' + sep;
        else if (!want.vod && want.verticals.length === 1) full = dir + sep + safe(VL.find((v) => v.id === want.verticals[0]).name) + '.' + E.format;
        go.disabled = !nOut;
        if (nOut > 1) info.textContent = `${nOut} video` + (want.vod ? ` · orizzontale ${fmtLong(outDuration())} + ${want.verticals.length} ${want.verticals.length === 1 ? 'clip verticale' : 'clip verticali'} in "Clip verticali"` : ' verticali in una cartella');
        else if (!want.vod) info.textContent = '1 clip verticale';
      }
      dirLbl.textContent = full.length > 46 ? '…' + full.slice(-45) : full;
      dirLbl.dataset.tip = full;
      audioOpts.style.display = E.audio ? '' : 'none';
      warn.textContent = E.codec === 'h265' ? 'HEVC: su alcuni PC Windows vecchi serve un\'estensione per vederlo. YouTube lo accetta.' : '';
    }
    const bg = h('div', { class: 'modal-bg xbg' });
    const close = () => { bg.remove(); document.removeEventListener('keydown', onK, true); };
    const onK = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onK, true);
    const go = h('button', { class: 'btn primary', onclick: async () => {
      const nm = name.trim(); if (!nm) { nameInp.focus(); return; }
      go.disabled = true;
      begin(); proj.name = nm; S.quality = quality; S.export = { ...E };
      if (VL.length) S.exportWant = { vod: want.vod, verticals: want.verticals.slice() };
      dirty = true;
      await textsSaved(); await flush();
      close(); ctx.nav('export', pid, VL.length && (want.verticals.length || !want.vod) ? { vod: want.vod, verticals: want.verticals.slice() } : undefined);
    } }, 'Esporta');
    bg.append(h('div', { class: 'xmodal', role: 'dialog', 'aria-label': 'Esporta' },
      h('div', { class: 'xhead' }, h('span', null, 'Esporta'), ibtn('x', 'Chiudi', close, { size: 16 })),
      h('div', { class: 'xbody' },
        h('div', { class: 'xleft' }, cover),
        h('div', { class: 'xright' },
          row('Nome', nameInp),
          row('Esporta su', h('div', { class: 'xdir' }, dirLbl, dirBtn)),
          VL.length ? h('div', { class: 'xsec' }, h('span', null, 'Cosa esporti')) : null, VL.length ? whatBox : null,
          h('div', { class: 'xsec' }, h('span', null, 'Video')), vgroup,
          h('div', { class: 'xsec' }, h('span', null, 'Audio'), audioTgl), audioOpts,
          warn)),
      h('div', { class: 'xfoot' }, icon('film', 16), info, h('div', { class: 'grow' }), h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
    if (VL.length) drawWhat();
    update();
  }
  // scorciatoia sempre in vista: passa il progetto a un altro PC (file .vodcut)
  const shareBtn = ibtn('share', 'Passa il progetto a un altro PC (file .vodcut)', () => saveProjectFile(), { key: 'Ctrl+Maiusc+S', size: 16 });
  ctx.topRight.append(savedLabel, exportBtn);

  // divisori trascinabili: pannello a destra (larghezza) e timeline (altezza), come CapCut/Premiere
  let panelW = store.get('panelW', 350), tlH = store.get('tlH', null), leftW = store.get('leftW', 300);
  const splitV = h('div', { class: 'split-v', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': 'Ridimensiona il pannello', title: 'Trascina per ridimensionare · doppio clic per ripristinare' });
  const splitH = h('div', { class: 'split-h', role: 'separator', 'aria-orientation': 'horizontal', 'aria-label': 'Ridimensiona la timeline', title: 'Trascina per ridimensionare · doppio clic per ripristinare' });
  const splitL = h('div', { class: 'split-v', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': 'Ridimensiona il pannello a sinistra', title: 'Trascina per ridimensionare · doppio clic per ripristinare' });
  const edTop = h('div', { class: 'ed-top' }, leftPanel, splitL, viewer, splitV, panel);
  const root = h('main', { class: 'editor' }, edTop, splitH, tl);
  function applySizes() {
    panel.style.width = panelW + 'px';
    leftPanel.style.width = leftW + 'px';
    if (tlH) { tl.style.height = tlH + 'px'; tl.style.flex = '0 0 auto'; } else { tl.style.height = ''; }
    // con tante tracce la timeline non spinge via l'anteprima: resta alta al massimo cosi' e le tracce si scorrono
    tl.style.maxHeight = tlH ? 'calc(100vh - 330px)' : '44vh';
  }
  function dragSplit(el, onMove, onEnd) {
    el.addEventListener('pointerdown', (e) => {
      e.preventDefault(); el.setPointerCapture(e.pointerId); el.classList.add('on');
      const mv = (ev) => onMove(ev);
      const up = () => { el.classList.remove('on'); el.removeEventListener('pointermove', mv); onEnd(); };
      el.addEventListener('pointermove', mv);
      el.addEventListener('pointerup', up, { once: true });
    });
  }
  dragSplit(splitV, (e) => {
    const r = edTop.getBoundingClientRect();
    panelW = Math.round(Math.max(280, Math.min(Math.min(700, r.width - leftW - 380), r.right - 16 - e.clientX - 5)));
    applySizes();
  }, () => store.set('panelW', panelW));
  dragSplit(splitH, (e) => {
    const r = root.getBoundingClientRect();
    tlH = Math.round(Math.max(170, Math.min(r.height - 250, r.bottom - 12 - e.clientY - 4)));
    applySizes();
  }, () => store.set('tlH', tlH));
  splitV.addEventListener('dblclick', () => { panelW = 350; store.set('panelW', panelW); applySizes(); });
  dragSplit(splitL, (e) => {
    const r = edTop.getBoundingClientRect();
    leftW = Math.round(Math.max(230, Math.min(Math.min(560, r.width - panelW - 380), e.clientX - r.left - 8 - 4)));
    applySizes();
  }, () => store.set('leftW', leftW));
  splitL.addEventListener('dblclick', () => { leftW = 300; store.set('leftW', leftW); applySizes(); });
  splitH.addEventListener('dblclick', () => { tlH = null; store.set('tlH', null); applySizes(); });
  applySizes();
  app.append(root);

  // ---------------------------------------------------------------- timeline: disegno
  // pezzi eliminati dalla timeline: spariscono e la timeline si accorcia (V: tempo del VOD -> tempo della timeline)
  // e i pezzi accelerati/rallentati si accorciano/allungano come nel video finale
  let goneR = [], vmap = [], viewEnd = D;
  // progetto vuoto: la durata segue quello che metti. Il nero di base sta tutto in coda: se ne vede solo la parte che
  // serve a immagini/testi/suoni messi oltre l'ultima clip; il resto e' nascosto ma resta "spazio" dove appoggiare cose
  let blankVisEnd = Infinity;
  function blankFit() {
    const black = proj.segs.filter((c) => !c.ins);
    if (!black.length) return;
    const bs = Math.min(...black.map((c) => c.a));
    let need = 0;
    for (const t of proj.tracks || []) if (t.type !== 'live') for (const c of t.clips || []) need = Math.max(need, c.a + (c.dur != null ? c.dur : (c.b || c.a) - c.a));
    const ve = +Math.max(bs, Math.min(D, need)).toFixed(4);
    const vis = black.find((c) => !c.gone), hid = black.find((c) => c.gone);
    // il nero visibile e' solo sfondo: niente tolto, spostato, ingrandito o accelerato (anche se un vecchio progetto l'aveva)
    const clean = (c) => !c.removed && !c.tf && !c.speed && !(c.filters && c.filters.length) && !c.color;
    const ok = black.length <= 2 && (!vis || clean(vis)) && (ve - bs < 0.01 ? !vis : vis && Math.abs(vis.a - bs) < 1e-4 && Math.abs(vis.b - ve) < 1e-4)
      && (D - ve < 0.01 ? !hid : hid && Math.abs(hid.a - ve) < 1e-4 && Math.abs(hid.b - D) < 1e-4);
    if (!ok) {
      const tpl = { removed: false, auto: false, vol: 100, mute: false, fin: false, fout: false };
      proj.segs = proj.segs.filter((c) => c.ins);
      if (ve - bs >= 0.01) proj.segs.push({ ...tpl, id: uid('s'), a: bs, b: ve });
      if (D - ve >= 0.01) proj.segs.push({ ...tpl, id: uid('s'), a: ve, b: D, gone: true, removed: true, fill: true });
      proj.segs.sort((x, y) => x.a - y.a);
    }
    blankVisEnd = ve;
  }
  function refreshGone() {
    if (BLANK) blankFit();
    const r = proj.segs.filter((x) => x.gone && !(BLANK && x.fill)).map((x) => [x.a, x.b]).sort((a, b) => a[0] - b[0]);
    const m = [];
    for (const [a, b] of r) { if (m.length && a <= m[m.length - 1][1] + 1e-6) m[m.length - 1][1] = Math.max(m[m.length - 1][1], b); else m.push([a, b]); }
    goneR = m;
    vmap = []; let v = 0;
    for (const c of [...proj.segs].sort((x, y) => x.a - y.a)) {
      const sp = c.gone ? Infinity : (c.speed || 1);
      vmap.push({ a: c.a, b: c.b, v0: v, sp });
      if (!c.gone) v += (c.b - c.a) / sp;
    }
    viewEnd = vmap.length ? v : D;
  }
  const V = (t) => {
    if (BLANK && t > blankVisEnd) return viewEnd + (t - blankVisEnd);   // spazio libero dopo la fine
    if (!vmap.length) return t;
    if (t >= D) return viewEnd;
    let lo = 0, hi = vmap.length - 1;
    while (lo < hi) { const md = (lo + hi + 1) >> 1; if (vmap[md].a <= t) lo = md; else hi = md - 1; }
    const p = vmap[lo];
    return p.sp === Infinity ? p.v0 : p.v0 + Math.max(0, Math.min(p.b, t) - p.a) / p.sp;
  };
  const T = (v) => {
    if (BLANK && v >= viewEnd) return Math.min(D, blankVisEnd + (v - viewEnd));
    if (!vmap.length) return Math.min(D, Math.max(0, v));
    if (v <= 0) { const f = vmap.find((p) => p.sp !== Infinity); return f ? f.a : 0; }
    for (const p of vmap) {
      if (p.sp === Infinity) continue;
      if (v < p.v0 + (p.b - p.a) / p.sp) return p.a + (v - p.v0) * p.sp;
    }
    const last = [...vmap].reverse().find((p) => p.sp !== Infinity);
    return last ? Math.max(last.a, last.b - 0.04) : D;
  };
  const isGone = (a, b) => goneR.some(([ga, gb]) => a >= ga - 1e-6 && b <= gb + 1e-6);
  // quanta timeline si vede tutta insieme (progetto vuoto: quello che c'e' piu' un po' di spazio libero)
  const fitSpan = () => Math.max(1, BLANK ? Math.max(20, viewEnd * 1.25) : V(D));
  const X = (t) => V(t) * pps;
  const XW = (a, b) => X(b) - X(a);
  // se la timeline e' piu' alta del necessario, le tracce si ingrandiscono (fino a 2x)
  // altezza di ogni traccia: si cambia trascinando il bordo sotto il nome (salvata)
  let laneH = store.get('laneH', {});
  const lh = (k, key) => laneH[key || k] || LANE_H[k];
  function updateLaneScale() { return false; }
  // le tracce vuote spariscono da sole; restano visibili solo quelle appena aggiunte (finche' non ricarichi)
  const freshTracks = new Set();
  const showTrack = (t) => { if (t.clips.length) { freshTracks.delete(t.id); return true; } return freshTracks.has(t.id); };
  // tracce filtri/colori rimaste vuote: si tolgono da sole (la principale resta, solo nascosta)
  function pruneFxTracks() {
    const used = new Set(proj.filters.map((f) => f.track || 'fx'));
    used.forEach((id) => freshTracks.delete(id));
    const keep = proj.fxTracks.filter((t) => t.id === 'fx' || used.has(t.id) || freshTracks.has(t.id));
    if (keep.length !== proj.fxTracks.length) { proj.fxTracks = keep; proj.layers = normLayers(); }
  }
  function laneList() {
    pruneFxTracks();
    const L = [];
    // livelli video, dall'alto verso il basso (l'ordine decide cosa copre cosa e cosa viene zoomato)
    for (const k of proj.layers) {
      if (k === 'subs') L.push({ kind: 'subs', key: 'subs', h: lh('subs'), group: 'v', layer: k });
      else if (k === 'zoom') {
        // la prima traccia zoom decide la posizione; le altre stanno subito sotto
        proj.zoomTracks.forEach((t, i) => L.push({ kind: 'zoom', key: i ? 'zoom:' + t.id : 'zoom', h: lh('zoom', i ? 'zoom:' + t.id : 'zoom'), group: i ? 'zx' : 'v', layer: i ? null : k, ztrack: t }));
      } else if (k === 'fx' || k.startsWith('fx:')) {
        const t = proj.fxTracks.find((x) => (x.id === 'fx' ? 'fx' : 'fx:' + x.id) === k);
        // le tracce dei filtri compaiono solo quando servono (o se le hai aggiunte tu)
        if (t && (freshTracks.has(t.id) || proj.filters.some((f) => (f.track || 'fx') === t.id))) L.push({ kind: 'fx', key: k, h: lh('fx', k), group: 'v', layer: k, fxtrack: t });
      }
      else if (k === 'video') L.push({ kind: 'video', key: 'video', h: lh('video'), group: 'base' });
      else { const t = proj.tracks.find((x) => 'ov:' + x.id === k); if (t && showTrack(t)) L.push({ kind: 'overlay', key: k, h: lh('overlay', k), track: t, group: 'v', layer: k }); }
    }
    // clip verticali create da questo VOD: in cima, sopra tutto
    // (le clip verticali stanno nella tab Clip, non in una traccia)
    // audio sotto
    // l'audio della live sta dentro la clip video (come CapCut): niente traccia a parte
    soundTracks().filter(showTrack).forEach((t) => L.push({ kind: 'sound', key: 'sound:' + t.id, h: lh('sound', 'sound:' + t.id), track: t, group: 'a' }));
    return L;
  }

  function renderHeads() {
    heads.replaceChildren();
    const INFO = { zoom: ['magnify', 'Zoom', 'Zoom: ingrandisce tutto quello che sta sotto questa traccia'], video: ['film', 'Video', 'Video della live con il suo audio: i pezzi a righe vengono tolti'], fx: ['wand', 'Filtri', 'Filtri sul video: aggiungili dalla tab Video'] };
    const list = laneList();
    list.forEach((L, idx) => {
      let el;
      const movable = L.group === 'v' || L.group === 'a';
      if (INFO[L.kind]) {
        let [ic, , tip] = INFO[L.kind];
        const lt = L.ztrack || L.fxtrack;
        if (lt && lt.kind === 'adjust') { ic = 'sliders'; tip = 'Colori: luminosità, contrasto, saturazione… su tutto quello che sta sotto'; }
        const emptyFx = L.fxtrack && lt.id === 'fx' && !proj.filters.some((f) => (f.track || 'fx') === 'fx');
        const extra = lt && ((lt.id !== 'zoom' && lt.id !== 'fx') || emptyFx);
        const nm = lt ? lt.name : (proj.laneNames.video || 'Video');
        el = h('div', { class: 'head', style: { height: L.h + 'px' }, 'data-tip': tip + (movable ? ' · trascina per spostarla su o giù' : '') + ' · doppio clic sul nome per rinominare' },
          h('span', { class: 'lico' }, icon(ic, 14)),
          renameable(nm, (v) => { if (lt) lt.name = v; else proj.laneNames.video = v; }),
          L.kind === 'video' ? (() => { const t = liveTrack(); return h('button', { class: 'mb', 'aria-pressed': String(!!t.mute), 'aria-label': t.mute ? 'Riattiva l\'audio della live' : 'Muta l\'audio della live', 'data-tip': t.mute ? 'Riattiva l\'audio della live' : 'Muta l\'audio della live',
            onclick: () => { begin(); t.mute = !t.mute; changed(); } }, icon(t.mute ? 'mute' : 'speaker', 13, t.mute ? '#FF7B72' : 'currentColor', 2)); })() : null,
          extra ? h('button', { class: 'mb hdel', 'aria-label': 'Elimina la traccia', 'data-tip': 'Elimina la traccia (quello che c\'è dentro torna nella traccia principale)',
            onclick: () => removeLaneTrack(L.kind, lt.id) }, icon('x', 12, 'currentColor', 2.2)) : null);
      } else if (L.kind === 'vert') {
        el = h('div', { class: 'head', style: { height: L.h + 'px' }, 'data-tip': 'Clip verticali create da questo video: doppio clic su una per modificarla' },
          h('span', { class: 'lico' }, icon('phone', 14)), h('span', { class: 'nm static' }, 'Verticali'));
      } else if (L.kind === 'subs') {
        const on = !!proj.settings.showSubs;
        el = h('div', { class: 'head', style: { height: L.h + 'px' }, 'data-tip': 'Sottotitoli · trascina per spostarli su o giù' },
          h('button', { class: 'mb', 'aria-pressed': String(on), 'aria-label': on ? 'Nascondi i sottotitoli' : 'Mostra i sottotitoli', 'data-tip': on ? 'Nascondi i sottotitoli (anche nel video finale)' : 'Mostra i sottotitoli',
            onclick: () => toggleSubs() }, icon(on ? 'eye' : 'eyeOff', 14, on ? 'currentColor' : '#FF7B72')),
          renameable(proj.laneNames.subs || 'Testo', (v) => { proj.laneNames.subs = v; }, on ? null : 'var(--text3)'));
      } else if (L.kind === 'overlay') {
        const t = L.track;
        const isSel = sel && sel.type === 'track' && sel.id === t.id;
        el = h('div', { class: 'head', style: { height: L.h + 'px' } },
          h('button', { class: 'mb', 'aria-pressed': String(!t.hidden), 'aria-label': (t.hidden ? 'Mostra ' : 'Nascondi ') + t.name, 'data-tip': t.hidden ? 'Mostra la traccia' : 'Nascondi la traccia',
            onclick: () => { begin(); t.hidden = !t.hidden; changed(); } }, icon(t.hidden ? 'eyeOff' : 'eye', 14, t.hidden ? '#FF7B72' : 'currentColor')),
          renameable(t.name, (v) => { t.name = v; }, null, () => select({ type: 'track', id: t.id }), isSel));
      } else {
        const t = L.track;
        const isSel = sel && sel.type === 'track' && sel.id === t.id;
        el = h('div', { class: 'head', style: { height: L.h + 'px' } },
          h('button', { class: 'mb', 'aria-pressed': String(!!t.mute), 'aria-label': (t.mute ? 'Riattiva ' : 'Muta ') + t.name, 'data-tip': t.mute ? 'Riattiva la traccia' : 'Muta la traccia',
            onclick: () => { begin(); t.mute = !t.mute; changed(); } }, icon(t.mute ? 'mute' : 'speaker', 13, t.mute ? '#FF7B72' : 'currentColor', 2)),
          renameable(t.name, (v) => { t.name = v; }, null, () => select({ type: 'track', id: t.id }), isSel),
          t.vol !== 100 && !t.mute ? h('span', { class: 'v' }, t.vol + '%') : null);
      }
      if (movable) { el.classList.add('movable'); el.addEventListener('pointerdown', (ev) => startLaneMove(ev, L, idx, el)); }
      // maniglia per cambiare l'altezza di questa sola traccia
      const grip = h('div', { class: 'lresize', 'data-tip': 'Trascina per cambiare l\'altezza (con Alt: tutte uguali) · doppio clic per ripristinare' });
      grip.addEventListener('pointerdown', (ev) => {
        ev.preventDefault(); ev.stopPropagation(); grip.setPointerCapture(ev.pointerId);
        const y0 = ev.clientY, h0 = L.h, laneEl = lanes.children[idx], all = ev.altKey;
        const mv = (e2) => {
          const nh = Math.round(Math.max(LANE_MIN[L.kind], Math.min(220, h0 + e2.clientY - y0)));
          if (all || e2.altKey) {
            // Alt: tutte le tracce alla stessa altezza
            list.forEach((x, j) => { laneH[x.key] = nh; if (heads.children[j]) heads.children[j].style.height = nh + 'px'; if (lanes.children[j]) lanes.children[j].style.height = nh + 'px'; });
          } else { laneH[L.key] = nh; el.style.height = nh + 'px'; if (laneEl) laneEl.style.height = nh + 'px'; }
        };
        const up = () => { grip.removeEventListener('pointermove', mv); store.set('laneH', laneH); renderTimeline(); };
        grip.addEventListener('pointermove', mv);
        grip.addEventListener('pointerup', up, { once: true });
      });
      grip.addEventListener('dblclick', () => { delete laneH[L.key]; store.set('laneH', laneH); renderTimeline(); });
      el.append(grip);
      heads.append(el);
    });
  }

  // nome della traccia: doppio clic per rinominarla
  function renameable(text, set, color, onclick, isSel) {
    const b = h('button', { class: 'nm' + (isSel ? ' sel' : ''), style: color ? { color } : null, 'data-tip': 'Doppio clic per rinominare' }, text);
    let clickT = 0;
    b.addEventListener('click', () => { clearTimeout(clickT); if (onclick) clickT = setTimeout(onclick, 220); });
    b.addEventListener('dblclick', (e) => {
      e.stopPropagation(); clearTimeout(clickT);
      const inp = h('input', { class: 'nmedit', value: text, maxlength: '40', 'aria-label': 'Nome della traccia' });
      b.replaceWith(inp); inp.focus(); inp.select();
      let done = false;
      const fin = (ok) => {
        if (done) return; done = true;
        const v = inp.value.trim();
        if (ok && v && v !== text) { begin(); set(v); changed(); } else inp.replaceWith(b);
      };
      inp.addEventListener('keydown', (ev) => { ev.stopPropagation(); if (ev.key === 'Enter') fin(true); else if (ev.key === 'Escape') fin(false); });
      inp.addEventListener('blur', () => fin(true));
      inp.addEventListener('pointerdown', (ev) => ev.stopPropagation());
    });
    return b;
  }
  function removeLaneTrack(kind, id) {
    begin();
    if (kind === 'fx' && id === 'fx') { const t = proj.fxTracks.find((x) => x.id === 'fx'); freshTracks.delete('fx'); }
    else if (kind === 'zoom') { proj.zooms.forEach((z) => { if (z.track === id) z.track = 'zoom'; }); proj.zoomTracks = proj.zoomTracks.filter((t) => t.id !== id); }
    else { proj.filters.forEach((f) => { if (f.track === id) f.track = 'fx'; }); proj.fxTracks = proj.fxTracks.filter((t) => t.id !== id); proj.layers = normLayers(); }
    changed();
  }
  function addLaneTrack(kind) {
    if (kind === 'adjust') return addFilter('adjust', true);
    begin();
    if (kind === 'zoom') { const n = proj.zoomTracks.length + 1; proj.zoomTracks.push({ id: uid('zt'), name: 'Zoom ' + n }); }
    else if (kind === 'fx') {
      const main = proj.fxTracks.find((x) => x.id === 'fx');
      // la traccia principale dei filtri e' nascosta finche' non serve: prima si mostra quella
      if (main && !freshTracks.has('fx') && !proj.filters.some((f) => (f.track || 'fx') === 'fx')) freshTracks.add('fx');
      else { const n = proj.fxTracks.filter((t) => t.kind !== 'adjust').length + 1, id = uid('ft'); proj.fxTracks.push({ id, name: 'Filtri ' + n }); freshTracks.add(id); }
      proj.layers = normLayers();
    }
    else newTrack(kind);
    changed();
  }

  // sposta una traccia su o giu' trascinandone il nome (video con video, audio con audio)
  function startLaneMove(ev, L, idx, el) {
    if (ev.button !== 0 || ev.target.closest('button, .lresize')) return;
    const list = laneList();
    const group = list.map((x, i) => ({ x, i })).filter((o) => o.x.group === L.group);
    if (group.length < 2) return;
    ev.preventDefault();
    el.setPointerCapture(ev.pointerId);
    const y0 = ev.clientY;
    let moved = false, target = group.findIndex((o) => o.i === idx);
    const line = h('div', { class: 'lane-drop' });
    const mv = (e) => {
      if (!moved && Math.abs(e.clientY - y0) < 4) return;
      if (!moved) { moved = true; el.classList.add('moving'); tlMain.append(line); }
      // posizione di arrivo: tra quali tracce del gruppo cade il puntatore
      let k = 0;
      group.forEach((o, j) => { const r = heads.children[o.i].getBoundingClientRect(); if (e.clientY > r.top + r.height / 2) k = j + 1; });
      target = k;
      const ref = k < group.length ? heads.children[group[k].i].getBoundingClientRect() : heads.children[group[group.length - 1].i].getBoundingClientRect();
      const mr = tlMain.getBoundingClientRect();
      line.style.top = (k < group.length ? ref.top - 5 : ref.bottom + 3) - mr.top + 'px';
    };
    const up = () => {
      el.removeEventListener('pointermove', mv);
      line.remove(); el.classList.remove('moving');
      if (!moved) return;
      const from = group.findIndex((o) => o.i === idx);
      let to = target > from ? target - 1 : target;
      if (to === from) return;
      begin();
      if (L.group === 'v') {
        const keys = group.map((o) => o.x.layer);
        const [k] = keys.splice(from, 1); keys.splice(to, 0, k);
        // i livelli non mostrati (es. sottotitoli senza trascrizione) restano al loro posto
        const rest = proj.layers.filter((x) => x !== 'video' && !keys.includes(x));
        const out = keys.slice();
        rest.forEach((x) => out.splice(Math.min(out.length, proj.layers.indexOf(x)), 0, x));
        proj.layers = out.concat(['video']);
        proj.layers = normLayers();
      } else {
        const st = soundTracks();
        const [t] = st.splice(from, 1); st.splice(to, 0, t);
        proj.tracks = proj.tracks.filter((x) => x.type !== 'sound').concat(st);
      }
      changed();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }

  function tickStep() {
    const steps = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600];
    return steps.find((s) => s * pps >= 70) || 3600;
  }
  function renderRuler() {
    ruler.replaceChildren();
    const st = tickStep();
    const v0 = scroller.scrollLeft / pps - st, v1 = (scroller.scrollLeft + scroller.clientWidth) / pps + st;
    for (let t = Math.max(0, Math.floor(v0 / st) * st); t <= Math.min(V(D), v1); t += st) {
      ruler.append(h('span', { style: { left: t * pps + 3 + 'px' } }, fmt(t)), h('i', { style: { left: t * pps + 'px' } }));
    }
  }

  let waveCanvas = null, thumbsBox = null, waveH = 24, clipBox = null, waveBg = null;
  // clip presa col mouse: si stacca e si sposta tutta (miniature e onda), non solo il bordo
  let liftedIds = null;
  function liftVisual(ids) {
    const lane = clipBox && clipBox.parentNode;
    const segs = ids.map((id) => segById(id)).filter(Boolean);
    if (!lane || !segs.length) return null;
    const x0 = Math.min(...segs.map((c) => X(c.a))), x1 = Math.max(...segs.map((c) => X(c.b)));
    const inSeg = (x) => segs.some((c) => x >= X(c.a) && x < X(c.b));
    const tb = h('div', { class: 'thumbs', style: { bottom: waveH + 'px' } });
    for (const img of thumbsBox ? thumbsBox.children : []) {
      const l = parseFloat(img.style.left), w = parseFloat(img.style.width);
      if (inSeg(l + w / 2)) { const cl = img.cloneNode(); cl.style.left = (l - x0) + 'px'; tb.append(cl); }
    }
    const dpr = window.devicePixelRatio || 1, gw = Math.max(1, x1 - x0);
    const wc = document.createElement('canvas');
    wc.width = Math.round(gw * dpr); wc.height = Math.round(waveH * dpr);
    Object.assign(wc.style, { position: 'absolute', left: '0', bottom: '0', width: gw + 'px', height: waveH + 'px' });
    try { if (waveCanvas) wc.getContext('2d').drawImage(waveCanvas, (x0 - scroller.scrollLeft) * dpr, 0, gw * dpr, waveH * dpr, 0, 0, wc.width, wc.height); } catch (e) { /* */ }
    const ghost = h('div', { class: 'clipghost', style: { left: x0 + 'px', width: gw + 'px' } }, tb, wc);
    lane.append(ghost);
    liftedIds = new Set(segs.map((c) => c.id));
    updateClipMask(scroller.scrollLeft, scroller.clientWidth);
    return { el: ghost, x0, move(dx, dy = 0) { const up = Math.abs(dy) > 12; ghost.style.transform = `translate(${dx}px, ${up ? dy : 0}px)`; ghost.classList.toggle('up', up); lane.style.overflow = up ? 'visible' : ''; }, done() { lane.style.overflow = ''; ghost.remove(); liftedIds = null; updateClipMask(scroller.scrollLeft, scroller.clientWidth); } };
  }
  // maschera delle clip: solo la parte visibile della timeline (leggera anche con video lunghi)
  function updateClipMask(x0, vw) {
    if (!clipBox) return;
    const hh = clipBox.clientHeight || 80, pad = 40, l = x0 - pad, w = vw + pad * 2;
    let r = '';
    for (const c of proj.segs) {
      if (c.gone || (BLANK && !c.ins) || isGapSeg(c) || (liftedIds && liftedIds.has(c.id))) continue;   // nel nero niente miniature ne' onda; la clip presa si vede nel fantasma
      const xa = X(c.a) + 1 - l, xb = X(c.b) - 1 - l;
      if (xb < 0 || xa > w || xb - xa < 1) continue;
      r += `<rect x="${xa.toFixed(1)}" y="0" width="${(xb - xa).toFixed(1)}" height="${hh}" rx="6"/>`;
    }
    const url = `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${hh}">${r}</svg>`)}")`;
    Object.assign(clipBox.style, { maskImage: url, webkitMaskImage: url, maskSize: `${w}px ${hh}px`, webkitMaskSize: `${w}px ${hh}px`,
      maskPosition: `${l}px 0`, webkitMaskPosition: `${l}px 0`, maskRepeat: 'no-repeat', webkitMaskRepeat: 'no-repeat' });
  }
  // se la durata della timeline cambia (clip eliminate, velocita'), la vista si riadatta
  let lastViewEnd = null;
  function refit() {
    if (lastViewEnd !== null && Math.abs(viewEnd - lastViewEnd) < 1e-6) return;
    if (drag && isSeg(drag.type)) return;   // mentre trascini il bordo la scala resta ferma
    const first = lastViewEnd === null;
    lastViewEnd = viewEnd;
    fitPps = Math.max(0.005, (scroller.clientWidth - 2) / fitSpan());
    // come CapCut: la scala resta quella scelta anche se la durata cambia (spostando una clip lontano non si rimpicciolisce
    // tutto); si adatta solo all'apertura. Per rivedere tutto: zoom al minimo
    if (first) pps = fitPps;
    zoomSlider.value = String(Math.round(1000 * Math.log(pps / fitPps) / Math.log(Math.max(1.0001, 200 / fitPps))));
  }
  function renderTimeline() {
    updateLaneScale();
    arrangeLayers(); syncCc(); applySubStyle();
    refreshGone();
    refit();
    inner.style.width = Math.max(scroller.clientWidth, BLANK ? (viewEnd + Math.max(20, viewEnd * 0.3)) * pps : X(D)) + 'px';
    renderHeads();
    lanes.replaceChildren();
    // pezzi della clip verticale scelta nella tab Clip: segnati sotto il righello
    inner.querySelectorAll('.vc-mark').forEach((m) => m.remove());
    const vsel = !IS_V && sel && sel.type === 'vclip' && findSel();
    if (vsel) for (const [a, b] of vRanges(vsel)) inner.append(h('div', { class: 'vc-mark', style: { left: X(a) + 'px', width: Math.max(3, XW(a, b)) + 'px' } }));
    for (const L of laneList()) {
      const lane = h('div', { class: 'lane ' + L.kind, style: { height: L.h + 'px' }, 'data-kind': L.kind, 'data-track': L.track && L.kind !== 'live' ? L.track.id : null, 'data-layer': L.layer || null });
      lanes.append(lane);
      if (L.kind === 'vert') {
        const { rows, n } = vertRows(), rh = L.h / n;
        for (const v of proj.verticals) {
          const on = sel && sel.type === 'vclip' && sel.id === v.id;
          const b = h('div', { class: 'blk vclipb' + (on ? ' sel' : ''), style: { left: X(v.a) + 'px', width: Math.max(6, XW(v.a, v.b)) + 'px', top: (rows.get(v.id) * rh + 3) + 'px', height: (rh - 6) + 'px', bottom: 'auto' }, 'data-tip': v.name + ' · doppio clic per modificarla' },
            icon('phone', 12, 'currentColor', 2), h('span', null, v.name));
          // doppio clic: la timeline si ridisegna al primo clic, quindi lo si riconosce qui
          b.addEventListener('pointerdown', (e) => {
            e.stopPropagation(); if (e.button !== 0) return;
            const now = Date.now(), dbl = lastVDown.id === v.id && now - lastVDown.t < 450;
            lastVDown = { id: v.id, t: dbl ? 0 : now };
            if (dbl) { openVertical(v); return; }
            multi = []; select({ type: 'vclip', id: v.id });
          });
          b.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); select({ type: 'vclip', id: v.id }); popMenuAt(e.clientX, e.clientY, vclipMenu(v)); });
          lane.append(b);
        }
      } else if (L.kind === 'zoom') {
        lane.dataset.zt = L.ztrack.id;
        for (const z of proj.zooms.filter((x) => (x.track || 'zoom') === L.ztrack.id)) {
          const b = block('zoom', z.id, z.a, z.b, 'blk zoom' + (z.kind === 'custom' ? ' custom' : ''), zoomLabel(z));
          b.title = `Zoom ${fmt(z.a)} → ${fmt(z.b)}`;
          lane.append(b);
        }
      } else if (L.kind === 'fx') {
        lane.dataset.fxt = L.fxtrack.id;
        const mine = proj.filters.filter((f) => (f.track || 'fx') === L.fxtrack.id);
        if (L.fxtrack.kind === 'adjust') lane.classList.add('adj');
        if (!mine.length) {
          if (L.fxtrack.kind === 'adjust') lane.append(h('button', { class: 'lane-cta', onclick: (e) => { e.stopPropagation(); addFilter('adjust'); } }, icon('plus', 12, 'currentColor', 2.4), 'Regola i colori qui'));
          else lane.append(h('div', { class: 'lane-hint' }, L.fxtrack.id === 'fx' ? 'Aggiungi un filtro dalla tab Video' : 'Trascina qui un filtro'));
        }
        // filtri sovrapposti: uno sotto l'altro nella stessa traccia
        const rowEnd = [], rowOf = new Map();
        for (const f of mine.slice().sort((x, y) => x.a - y.a)) {
          let r = rowEnd.findIndex((e) => e <= f.a + 0.001);
          if (r < 0) { r = rowEnd.length; rowEnd.push(0); }
          rowEnd[r] = f.b; rowOf.set(f.id, r);
        }
        const nr = Math.max(1, rowEnd.length), rh = (L.h - 4) / nr;
        for (const f of mine) {
          const b = block('fx', f.id, f.a, f.b, 'blk fxb' + (f.off ? ' off' : ''), fxName(f.type) + (f.mask && f.mask.type && f.mask.type !== 'all' ? ' · maschera' : ''));
          b.title = `${fxName(f.type)} ${fmt(f.a)} → ${fmt(f.b)}`;
          if (nr > 1) Object.assign(b.style, { top: 2 + rowOf.get(f.id) * rh + 'px', height: rh - 1 + 'px', bottom: 'auto', fontSize: rh < 16 ? '9px' : '' });
          lane.append(b);
        }
      } else if (L.kind === 'video') {
        // clip video con il suo audio: miniature sopra, forma d'onda sotto
        waveH = Math.max(14, Math.round(L.h * 0.3));
        thumbsBox = h('div', { class: 'thumbs', style: { bottom: waveH + 'px' } });
        waveCanvas = h('canvas', { class: 'wave', style: { top: 'auto', bottom: '0' } });
        waveBg = h('div', { class: 'wavebg', style: { height: waveH + 'px' } });
        // miniature e audio sono ritagliati clip per clip (angoli arrotondati, 2 px di stacco tra una clip e l'altra)
        clipBox = h('div', { class: 'vclips' }, thumbsBox, waveBg, waveCanvas);
        lane.append(clipBox);
        const lt = liveTrack();
        if (BLANK && !proj.segs.some((c) => c.ins && !c.gone)) lane.append(h('div', { class: 'lane-hint main-empty' }, icon('addVideo', 13, 'currentColor', 2), 'Trascina qui i tuoi video: si mettono uno dopo l\'altro'));
        for (const c of proj.segs) {
          if (BLANK && !c.ins) {   // il nero di base: spazio libero, non una clip
            if (!c.gone) lane.append(h('div', { class: 'blk seg blankfill', style: { left: X(c.a) + 1 + 'px', width: Math.max(2, XW(c.a, c.b) - 2) + 'px' } }));
            continue;
          }
          if (isGapSeg(c)) {   // spazio vuoto (nero) lasciato a calamita spenta
            const b = block('seg', c.id, c.a, c.b, 'blk seg gapfill', '');
            b.style.left = X(c.a) + 1 + 'px'; b.style.width = Math.max(2, XW(c.a, c.b) - 2) + 'px';
            lane.append(b);
            continue;
          }
          const tags = [];
          if (c.speed && c.speed !== 1) tags.push((c.speed + '×').replace('.', ','));
          if (!c.removed && (c.mute || lt.mute)) tags.push('muto');
          else if (!c.removed && c.vol !== 100) tags.push(c.vol + '%');
          const b = block('seg', c.id, c.a, c.b, 'blk seg' + (c.removed ? ' removed' : '') + (c.mute || lt.mute ? ' muted' : ''), XW(c.a, c.b) > 34 ? tags.join(' · ') : '');
          b.style.left = X(c.a) + 1 + 'px'; b.style.width = Math.max(2, XW(c.a, c.b) - 2) + 'px';
          if (tags.length) b.classList.add('spd');
          if (sel && sel.type === 'aseg' && sel.id === c.id) b.classList.add('sel');
          lane.append(b);
        }
        drawWave();
        for (const [a, b2, si, wi] of wordCuts()) {
          const b = h('div', { class: 'blk tcut', style: { left: X(a) + 'px', width: Math.max(3, XW(a, b2)) + 'px' }, title: 'Tolto dal testo' });
          b.addEventListener('pointerdown', (e) => { e.stopPropagation(); setTab('text'); seek(a); setTimeout(() => scrollToWord(si, wi), 50); });
          lane.append(b);
        }
        drawThumbs();
      } else if (L.kind === 'subs') {
        if (!allWords().length) { lane.append(subsStatus('lane')); continue; }
        if (!proj.settings.showSubs) { lane.classList.add('off'); lane.append(h('div', { class: 'lane-hint' }, 'Sottotitoli nascosti')); continue; }
        // frasi vicine che a questo zoom non ci stanno: un'unica barra (niente blocchetti uno sopra l'altro)
        const vis = subChunks().filter((ch) => !isGone(ch.a, ch.b));
        const runs = [];
        for (const ch of vis) {
          const l = X(ch.a), r = X(ch.b);
          const last = runs[runs.length - 1];
          if (last && l - last.r < 3 && (r - l < 16 || last.r - last.l0 < 16 || last.items.length > 1 && last.tight)) { last.items.push(ch); last.r = Math.max(last.r, r); last.tight = true; }
          else runs.push({ l0: l, r, items: [ch], tight: false });
        }
        for (let k = 0; k < runs.length; k++) {
          const run = runs[k], next = runs[k + 1];
          const right = Math.min(run.r, next ? next.l0 - 2 : Infinity);
          const width = Math.max(3, right - run.l0);
          if (run.items.length === 1) {
            // ogni frase si seleziona come le altre clip (anche col rettangolo o Ctrl+clic)
            const ch = run.items[0], id = subKey(ch);
            const isS = (sel && sel.type === 'sub' && sel.id === id) || multi.some((m) => m.type === 'sub' && m.id === id);
            const b = h('div', { class: 'blk subblk' + (isS ? ' sel' : '') + (ch.hidden ? ' hid' : ''), style: { left: run.l0 + 'px', width: width + 'px' },
              'data-tip': ch.text + ' · doppio clic per correggere', 'data-type': 'sub', 'data-id': id, 'data-notr': '1' },
              width > 26 ? h('span', { style: { pointerEvents: 'none', overflow: 'hidden', textOverflow: 'ellipsis' } }, ch.text) : null);
            b.addEventListener('pointerdown', (ev) => startDrag(ev, 'sub', id, b));
            b.addEventListener('dblclick', () => fixSub(ch));
            lane.append(b);
            continue;
          }
          // tante frasi fitte: si clicca quella sotto il mouse (ingrandisci la timeline per vederle una per una)
          const ids = run.items.map(subKey);
          const isSel = (id) => (sel && sel.type === 'sub' && sel.id === id) || multi.some((m) => m.type === 'sub' && m.id === id);
          const allHid = run.items.every((ch) => ch.hidden);
          const b = h('div', { class: 'blk subblk subrun' + (allHid ? ' hid' : ''), style: { left: run.l0 + 'px', width: width + 'px' },
            'data-tip': run.items.length + ' frasi · ingrandisci la timeline per vederle una per una', 'data-type': 'sub', 'data-id': ids[0] });
          // dentro la barra: una tacca per ogni frase, e solo quella selezionata evidenziata (non tutto il gruppo)
          run.items.forEach((ch, k) => {
            const l = X(ch.a) - run.l0, w = Math.max(3, Math.min(width - l, XW(ch.a, ch.b)));
            if (isSel(subKey(ch))) b.append(h('i', { class: 'subsel', style: { left: l + 'px', width: w + 'px' } }));
            else if (k) b.append(h('i', { class: 'subtick', style: { left: l + 'px' } }));
          });
          const pick = (ev) => { const t = tAt(ev); return run.items.find((ch) => t >= ch.a && t < ch.b) || run.items.reduce((m, ch) => (Math.abs(ch.a - t) < Math.abs(m.a - t) ? ch : m)); };
          b.addEventListener('pointerdown', (ev) => { const ch = pick(ev); b.dataset.id = subKey(ch); startDrag(ev, 'sub', subKey(ch), b); });
          b.addEventListener('dblclick', (ev) => fixSub(pick(ev)));
          lane.append(b);
        }
      } else if (L.kind === 'live') {
        waveCanvas = h('canvas', { class: 'wave', height: String(L.h) });
        lane.append(waveCanvas);
        for (const c of proj.segs) {
          const b = block('aseg', c.id, c.a, c.b, 'blk aseg' + (c.mute || L.track.mute ? ' muted' : '') + (c.removed ? ' removed' : ''), (XW(c.a, c.b) > 60 && !c.removed ? (c.mute ? 'muto' : (c.vol !== 100 ? c.vol + '%' : '')) : ''));
          lane.append(b);
        }
        drawWave();
      } else {
        const t = L.track;
        if (!t.clips.length) lane.append(h('div', { class: 'lane-hint' }, L.kind === 'overlay' ? 'Trascina qui un video o un\'immagine dai Media' : 'Trascina qui un suono dai Media'));
        for (const c of t.clips) {
          const img = c.kind === 'image', vclip = c.kind === 'video';
          const b = block('sclip', c.id, c.a, c.a + c.dur, 'blk sclip' + (img || vclip ? ' oclip' : '') + (c.mute || t.mute ? ' muted' : ''), c.name + (c.mute ? ' · muto' : ''));
          b.style.background = t.color || '#2DD4BF';
          if (c.isText) b.prepend(h('span', { class: 'tglyph' }, 'T'));
          else if (img && XW(c.a, c.a + c.dur) > 30) b.prepend(h('img', { class: 'othumb', src: mediaUrl(c.file), alt: '', draggable: 'false' }));
          else if (vclip && XW(c.a, c.a + c.dur) > 30) b.prepend(h('img', { class: 'othumb', src: mthumbUrl(c.file, (c.offset || 0) + Math.min(1, c.dur / 2)), alt: '', draggable: 'false' }));
          if (t.mute || t.hidden) b.style.opacity = '0.4';
          if (img && c.anim) {
            if (c.anim.in) b.append(h('i', { class: 'anr in', style: { width: XW(c.a, c.a + Math.min(c.anim.inDur || 0.5, c.dur)) + 'px' } }));
            if (c.anim.out) b.append(h('i', { class: 'anr out', style: { width: XW(c.a + c.dur - Math.min(c.anim.outDur || 0.5, c.dur), c.a + c.dur) + 'px' } }));
            if (c.anim.loop || c.anim.motion) b.append(h('i', { class: 'anr loop' }));
          }
          if (img) for (const k of c.kf || []) {
            const d = h('i', { class: 'kfd', style: { left: XW(c.a, c.a + k.t) + 'px' }, 'data-tip': 'Keyframe · ' + fmt(c.a + k.t, 1) });
            d.addEventListener('pointerdown', (ev) => { ev.stopPropagation(); if (!(sel && sel.id === c.id)) select({ type: 'sclip', id: c.id }); seek(c.a + k.t + 0.001); renderPanel(); });
            b.append(d);
          }
          b.title = `${c.name} · ${fmt(c.a)} → ${fmt(c.a + c.dur)}`;
          lane.append(b);
        }
      }
    }
    renderRuler();
    updatePlayhead(video.currentTime);
    drawPendingIns();
  }

  // sottotitoli come appaiono nel video: frasi brevi, senza parole tolte
  let subCache = null;
  const subKey = (ch) => ch.a.toFixed(3);
  // correggi il testo di una frase: apre la trascrizione sulla parola giusta
  function fixSub(ch) {
    trMode = 'fix'; openSec.set('t.tr', true); sel = null; multi = []; tab = 'text'; renderTimeline(); renderPanel();
    setTimeout(() => { scrollToWord(ch.si, ch.wi); const el = wordEls[ch.si] && wordEls[ch.si][ch.wi]; if (el) editWord(el); }, 80);
  }
  function subChunks() {
    const maxC = proj.subStyle.maxChars || 38;
    if (subCache && subCache.ver === ver && subCache.maxC === maxC && subCache.n === allWords().length) return subCache.list;
    const rem = removed(), out = [];
    let ri = 0;
    allWords().forEach((s, si) => {
      let cur = null;
      s.words.forEach((w, wi) => {
        const mid = (w.a + w.b) / 2;
        while (ri < rem.length && rem[ri][1] < mid) ri++;
        if (w.del || (ri < rem.length && rem[ri][0] <= mid)) return;
        const hid = !!w.nosub;
        if (cur && ((cur.text + ' ' + w.w).length > maxC || w.a - cur.b > 0.7 || w.b - cur.a > 3.5 || cur.hidden !== hid)) { out.push(cur); cur = null; }
        if (!cur) cur = { a: w.a, b: w.b, text: w.w, si, wi, words: [w], hidden: hid };
        else { cur.b = w.b; cur.text += ' ' + w.w; cur.words.push(w); }
      });
      if (cur) out.push(cur);
    });
    // come nel video esportato: almeno 0,6 s, niente sovrapposizioni
    out.forEach((c) => { c.b = Math.max(c.b, c.a + 0.6); });
    for (let i = 0; i < out.length - 1; i++) if (out[i].b > out[i + 1].a) out[i].b = out[i + 1].a;
    subCache = { ver, maxC, n: allWords().length, list: out };
    return out;
  }
  function zoomLabel(z) {
    if (VERT) { const wpx = XW(z.a, z.b); return wpx > 44 ? (z.kind === 'custom' ? 'Inquadratura' : 'Webcam') : ''; }   // in verticale: a tutto schermo
    const lv = (z.kind === 'custom' && z.rect ? W / customRect(W, H, z.rect)[2] : (z.level || 2.8)).toFixed(1).replace('.', ',') + '×';
    const wpx = XW(z.a, z.b);
    return wpx > 70 ? (z.kind === 'custom' ? 'custom ' : 'zoom ') + lv : (wpx > 42 ? lv : '');
  }
  function block(type, id, a, b, cls, label) {
    const isSel = (sel && sel.type === type && sel.id === id) || multi.some((m) => m.type === type && m.id === id);
    const el = h('div', { class: cls + (isSel ? ' sel' : ''), style: { left: X(a) + 'px', width: Math.max(4, XW(a, b)) + 'px', display: isGone(a, b) ? 'none' : '' }, 'data-type': type, 'data-id': id },
      label ? h('span', { style: { pointerEvents: 'none', overflow: 'hidden', textOverflow: 'ellipsis' } }, label) : null);
    el.append(h('div', { class: 'hdl l', 'data-edge': 'l' }), h('div', { class: 'hdl r', 'data-edge': 'r' }));
    el.addEventListener('pointerdown', (e) => startDrag(e, type, id, el));
    return el;
  }

  // miniature: si riusano quelle gia' caricate (niente sfarfallio e niente lavoro inutile mentre scorre)
  const insSig = () => (proj.inserts || []).map((x) => x.id + '@' + Math.round(x.at * 10)).join(',').replace(/[^\w@,]/g, '') || '0';
  function drawThumbs() {
    if (!thumbsBox) return;
    if (!strip) { thumbsBox.replaceChildren(); return; }  // le miniature arrivano dopo il video
    const tw = Math.round(lh('video') * 16 / 9);
    const x0 = Math.max(0, scroller.scrollLeft - tw), x1 = scroller.scrollLeft + scroller.clientWidth + tw;
    const total = Math.ceil(X(D) / tw);
    const liveIv = strip.liveIv || strip.interval || 1;
    const old = new Map();
    for (const img of thumbsBox.children) old.set(img.dataset.k, img);
    const keep = new Set();
    for (let i = Math.floor(x0 / tw); i < Math.min(total, Math.ceil(x1 / tw)); i++) {
      const t = Math.min(D - 0.05, T((i + 0.5) * tw / pps));
      const c = proj.segs.find((x) => t >= x.a && t < x.b);
      if (!c || isGapSeg(c)) continue;
      // la miniatura e' di un punto di un file (la live o un video), calcolato dalle clip (non dal lettore, che dopo
      // uno spostamento si aggiorna un attimo dopo): spostando le clip resta la stessa e non sparisce mai
      const rec = c.ins ? insById(c.ins) : null;
      if (c.ins && (!rec || rec.gap)) continue;
      const onLive = !rec || !!rec.live;
      if (!rec && BLANK) continue;   // il nero di base
      const st = rec ? (rec.offset || 0) + (t - rec.at) : liveOffAt(t);
      const q = onLive ? Math.round(st / liveIv) * liveIv : Math.floor(st);
      const src = onLive ? 'src=live' : 'src=f&path=' + encodeURIComponent(rec.file);
      const key = i + ':' + tw + ':' + (onLive ? 'L' : rec.file) + ':' + q.toFixed(2);
      keep.add(key);
      if (!old.has(key)) thumbsBox.append(h('img', { src: `/api/p/${pid}/stile?token=${TOKEN}&${src}&st=${q.toFixed(2)}`, alt: '', decoding: 'async', 'data-k': key, style: { left: i * tw + 'px', width: tw + 'px' } }));
    }
    for (const [key, img] of old) if (!keep.has(key)) img.remove();
  }

  function drawWave() {
    if (!waveCanvas) return;
    const vw = scroller.clientWidth, x0 = scroller.scrollLeft;
    const dpr = window.devicePixelRatio || 1;
    const hgt = waveH;
    waveCanvas.width = Math.floor(vw * dpr); waveCanvas.height = Math.floor(hgt * dpr);
    waveCanvas.style.width = vw + 'px'; waveCanvas.style.height = hgt + 'px'; waveCanvas.style.left = x0 + 'px';
    const g = waveCanvas.getContext('2d');
    g.scale(dpr, dpr);
    updateClipMask(x0, vw);
    if (waveBg) { waveBg.style.left = x0 + 'px'; waveBg.style.width = vw + 'px'; }
    const peaks = wave.peaks || [], ps = wave.perSec || 5;
    if (!peaks.length) return;
    const lt = liveTrack();
    // forma d'onda simmetrica, centrata: piu' leggibile e pulita
    const mid = hgt / 2, maxH = hgt - 6;
    for (let x = 0; x < vw; x += 3) {
      const ta = T((x0 + x) / pps), tb = T((x0 + x + 3) / pps);
      let m = 0;
      for (let i = Math.floor(ta * ps); i <= Math.min(peaks.length - 1, Math.floor(tb * ps)); i++) m = Math.max(m, peaks[i] || 0);
      const c = proj.segs.find((cl) => ta >= cl.a && ta < cl.b);
      const off = lt.mute || (c && (c.mute || c.removed));
      const v = off ? 1 : (lt.vol / 100) * ((c ? c.vol : 100) / 100);
      const bh = Math.max(1, Math.min(maxH, m * maxH * Math.min(1.6, v)));
      g.fillStyle = off ? 'rgba(160,160,170,.35)' : 'rgba(95,138,240,.95)';
      g.fillRect(x, mid - bh / 2, 2, bh);
    }
  }

  function updatePlayhead(t) {
    playhead.style.left = X(t) + 'px';
  }

  // ---------------------------------------------------------------- timeline: interazioni
  function findSel(s = sel) {
    if (!s) return null;
    if (s.type === 'zoom') return proj.zooms.find((z) => z.id === s.id);
    if (s.type === 'seg' || s.type === 'aseg') return proj.segs.find((c) => c.id === s.id);
    if (s.type === 'subs') return proj.subStyle;
    if (s.type === 'sub') { const c = subChunks().find((x) => subKey(x) === s.id); if (c) c.id = s.id; return c || null; }
    if (s.type === 'fx') return proj.filters.find((f) => f.id === s.id);
    if (s.type === 'sclip') { for (const t of clipTracks()) { const c = t.clips.find((c) => c.id === s.id); if (c) return c; } return null; }
    if (s.type === 'track') return proj.tracks.find((t) => t.id === s.id);
    if (s.type === 'vclip') return (proj.verticals || []).find((v) => v.id === s.id);
    return null;
  }
  const isSeg = (t) => t === 'seg' || t === 'aseg';
  let multi = [];   // selezione multipla [{type,id}]
  let lastTextSel = null;
  // quale tab mostra l'elemento selezionato
  function tabFor(s) {
    if (s.type === 'aseg') return 'audio';
    if (s.type === 'sclip') { const c = findSel(s); if (c && c.isText) { if (lastTextSel !== s.id) { imgSub = 'text'; lastTextSel = s.id; } return 'text'; } return c && (c.kind === 'image' || c.kind === 'video') ? 'video' : 'audio'; }
    if (s.type === 'subs' || s.type === 'sub') return 'text';
    if (s.type === 'vclip') return 'clips';
    if (s.type === 'track') { const t = findSel(s); return t && t.type === 'overlay' ? 'video' : 'audio'; }
    return 'video';
  }
  function trackOfClip(id) { return proj.tracks.find((t) => t.clips.some((c) => c.id === id)); }
  function select(s, noTab) {
    if (!s || !sel || s.id !== sel.id) framing = false;
    if (!s) multi = [];
    sel = s;
    if (s && !noTab) tab = tabFor(s);
    renderTimeline(); renderPanel();
  }

  let drag = null;
  function startDrag(e, type, id, el) {
    e.stopPropagation();
    if (e.button !== 0) return;
    // Ctrl/Maiusc + clic: aggiunge o toglie dalla selezione multipla
    if (e.ctrlKey || e.metaKey || e.shiftKey) {
      if (!multi.length && sel && sel.type !== 'track' && sel.type !== 'subs') multi = [{ ...sel }];
      const i = multi.findIndex((m) => m.type === type && m.id === id);
      if (i >= 0) multi.splice(i, 1); else multi.push({ type, id });
      sel = multi.length === 1 ? { ...multi[0] } : (multi.length ? { ...multi[multi.length - 1] } : null);
      if (multi.length <= 1) multi = [];
      renderTimeline(); renderPanel();
      return;
    }
    if (!multi.some((m) => m.type === type && m.id === id)) multi = [];
    const item = findSel({ type, id });
    if (!item) return;
    const edge = e.target.dataset.edge || 'move';
    if (!(sel && sel.type === type && sel.id === id)) { framing = false; sel = { type, id }; tab = tabFor(sel); renderPanel(); lanes.querySelectorAll('.blk.sel').forEach((b) => b.classList.remove('sel')); el.classList.add('sel'); }
    if (type === 'sub') { startMarquee(e, { item, type, t: item.a + 0.01 }); return; }
    // calamita spenta: una clip principale si trascina liberamente (lascia o chiude spazio vuoto)
    if (!magnetOn() && edge === 'move' && !(BLANK && isSeg(type) && !item.ins)) {
      if (isSeg(type) && !item.removed) { startFreeMove(e, item, el); return; }
      // gruppo con clip principali preso da un altro elemento: si muove tutto dalla prima clip principale
      const anchor = multi.length > 1 && multi.filter((m) => isSeg(m.type)).map((m) => findSel(m)).filter(Boolean).sort((x, y) => x.a - y.a)[0];
      if (anchor && multi.some((m) => m.type === type && m.id === id)) { startFreeMove(e, anchor, el); return; }
    }
    if (isSeg(type) && edge === 'move' && item.ins && (proj.inserts || []).some((x) => x.id === item.ins)) { startInsMove(e, item, el); return; }
    // una clip della live: si prende e si sposta in un altro punto della traccia principale (come in CapCut)
    if (type === 'seg' && edge === 'move' && !item.ins && !item.removed && !BLANK && !multi.length) { startLiveMove(e, item, el); return; }
    if (isSeg(type) && edge === 'move') {
      // trascinando su un pezzo parte il rettangolo di selezione; un clic semplice lo seleziona e sposta la testina
      startMarquee(e, { item, type, t: Math.max(item.a, Math.min(item.b - 0.1, tAt(e))) });
      return;
    }
    if (isSeg(type) && edge === 'r' && item.ins && startImageStretch(e, item, el)) return;
    if (type === 'sclip' && edge === 'move' && !(multi.length > 1)) { startClipFloat(e, item, el); return; }
    drag = { type, id, edge, x0: e.clientX, y0: e.clientY, orig: JSON.parse(JSON.stringify(item)), moved: false, el, clickT: tAt(e), lane0: el.parentNode, lane: el.parentNode };
    if (isSeg(type)) {
      // bordo di un pezzo: si lavora su una copia dei pezzi iniziali, la timeline si ridisegna mentre trascini
      drag.segs0 = JSON.parse(JSON.stringify(proj.segs));
      window.addEventListener('pointermove', onDragMove);
      window.addEventListener('pointerup', onDragEnd, { once: true });
      return;
    }
    // selezione multipla: si spostano insieme (zoom, filtri, immagini, testi, suoni)
    if (edge === 'move' && multi.length > 1) {
      drag.group = multi.filter((m) => !(m.type === type && m.id === id) && ['zoom', 'fx', 'sclip'].includes(m.type))
        .map((m) => ({ it: findSel(m), m })).filter((g) => g.it).map((g) => ({ ...g, orig: { a: g.it.a, b: g.it.b } }));
    }
    el.setPointerCapture(e.pointerId);
    el.addEventListener('pointermove', onDragMove);
    el.addEventListener('pointerup', onDragEnd, { once: true });
  }
  function onDragMove(e) {
    if (!drag) return;
    const dt = (e.clientX - drag.x0) / pps;
    // spostamento in tempo del VOD che segue il puntatore sulla timeline (salta le clip eliminate, tiene conto della velocita')
    const sh = (t) => T(V(t) + dt);
    if (drag.group && drag.group.length && (drag.moved || Math.abs(e.clientX - drag.x0) >= 3)) {
      let d = sh(drag.orig.a) - drag.orig.a;
      const all = [{ o: drag.orig }, ...drag.group.map((g) => ({ o: g.orig, it: g.it }))];
      for (const { o } of all) { const len = (o.b !== undefined ? o.b : o.a + (o.dur || 0)) - o.a; d = Math.max(d, -o.a); d = Math.min(d, D - o.a - len); }
      for (const g of drag.group) {
        const len = g.orig.b !== undefined ? g.orig.b - g.orig.a : 0;
        g.it.a = g.orig.a + d; if (g.orig.b !== undefined) g.it.b = g.it.a + len;
        lanes.querySelectorAll(`[data-id="${g.m.id}"]`).forEach((el) => { el.style.left = X(g.it.a) + 'px'; });
      }
      drag.gd = d;
    }
    if (!drag.moved && Math.abs(e.clientX - drag.x0) < 3 && Math.abs(e.clientY - drag.y0) < 6) return;
    // spostamento su un'altra traccia dello stesso tipo (immagini/testi, suoni, zoom, filtri)
    if (drag.edge === 'move' && ['sclip', 'zoom', 'fx'].includes(drag.type)) {
      drag.el.style.pointerEvents = 'none';
      const under = document.elementFromPoint(e.clientX, e.clientY);
      const ln = under && under.closest && under.closest('.lane');
      const k0 = drag.lane0.dataset.kind;
      // foto o video sopra -> traccia principale
      drag.toMain = drag.type === 'sclip' && ['image', 'video'].includes(drag.orig.kind) && ln && ln.dataset.kind === 'video' ? ln : null;
      markLane(drag.toMain);
      if (ln && ln !== drag.lane && ln.dataset.kind === k0 && (ln.dataset.track || ln.dataset.zt || ln.dataset.fxt)) {
        if (!drag.moved) { begin(); drag.moved = true; }
        ln.append(drag.el); drag.lane = ln;
        drag.el.style.top = ''; drag.el.style.height = ''; drag.el.style.bottom = '';
      }
    }
    if (!drag.moved) { begin(); drag.moved = true; }
    const it = findSel({ type: drag.type, id: drag.id });
    const o = drag.orig;
    if (isSeg(drag.type)) {
      rippleEdge(dt * (o.speed || 1));
      const cur = proj.segs.find((x) => x.id === drag.id);
      if (!drag.raf) drag.raf = requestAnimationFrame(() => { if (drag) drag.raf = 0; renderTimeline(); });
      if (cur) seekQuiet(drag.edge === 'l' ? cur.a + 0.01 : cur.b - 0.05);
      return;
    }
    // magnete sui blocchi: aggancia l'inizio o la fine a bordi vicini e alla testina
    const sn = (t) => snapFind(t, drag.id, true);
    const snapMove = (a, len) => { const [sa, da] = sn(a), [sb, db] = sn(a + len); if (da <= db && da < SNAP_PX) { showSnap(sa); return sa; } if (db < SNAP_PX) { showSnap(sb); return sb - len; } showSnap(null); return a; };
    const snapEdge = (t) => { const [st, d] = sn(t); showSnap(d < SNAP_PX ? st : null); return d < SNAP_PX ? st : t; };
    if (drag.type === 'sclip' && o.kind === 'image') {
      // immagine: nessun limite di durata
      if (drag.edge === 'move') it.a = Math.max(0, Math.min(D - 0.1, snapMove(sh(o.a), o.dur)));
      else if (drag.edge === 'l') { const d = Math.max(-o.a, Math.min(o.dur - 0.2, snapEdge(sh(o.a)) - o.a)); it.a = o.a + d; it.dur = o.dur - d; if (o.kf) it.kf = o.kf.map((k) => ({ ...k, t: +(k.t - d).toFixed(3) })); }
      else it.dur = Math.max(0.2, Math.min(D - o.a, snapEdge(sh(o.a + o.dur)) - o.a));
      drag.el.style.left = X(it.a) + 'px'; drag.el.style.width = Math.max(4, XW(it.a, it.a + it.dur)) + 'px';
      seekQuiet(drag.edge === 'r' ? it.a + it.dur - 0.05 : it.a);
    } else if (drag.type === 'sclip') {
      const fileDur = o.fileDur || (o.offset + o.dur);
      if (drag.edge === 'move') it.a = Math.max(0, Math.min(D - 0.1, snapMove(sh(o.a), o.dur)));
      else if (drag.edge === 'l') { const d = Math.max(-o.offset, Math.min(o.dur - 0.2, snapEdge(sh(o.a)) - o.a)); it.a = o.a + d; it.offset = o.offset + d; it.dur = o.dur - d; }
      else it.dur = Math.max(0.2, Math.min(fileDur - o.offset, snapEdge(sh(o.a + o.dur)) - o.a));
      drag.el.style.left = X(it.a) + 'px'; drag.el.style.width = Math.max(4, XW(it.a, it.a + it.dur)) + 'px';
    } else {
      const minLen = drag.type === 'zoom' ? 0.8 : 0.3;
      if (drag.edge === 'move') { const len = o.b - o.a; it.a = Math.max(0, Math.min(D - len, snapMove(sh(o.a), len))); it.b = it.a + len; }
      else if (drag.edge === 'l') it.a = Math.max(0, Math.min(o.b - minLen, snapEdge(sh(o.a))));
      else it.b = Math.min(D, Math.max(o.a + minLen, snapEdge(sh(o.b))));
      drag.el.style.left = X(it.a) + 'px'; drag.el.style.width = Math.max(4, XW(it.a, it.b)) + 'px';
      seekQuiet(drag.edge === 'r' ? it.b - 0.05 : it.a);
    }
  }
  // bordo di un pezzo, come CapCut: tirandolo dentro la parte tagliata sparisce dalla timeline,
  // tirandolo fuori torna la parte che avevi tagliato (o eliminato)
  function rippleEdge(dS) {
    const segs = JSON.parse(JSON.stringify(drag.segs0));
    const i = segs.findIndex((x) => x.id === drag.id);
    if (i < 0) return;
    const it = segs[i], MIN = 0.1;
    const goneSeg = (a, b) => ({ ...it, id: uid('s'), a, b, removed: true, gone: true, auto: false, speed: undefined, fin: false, fout: false, adj: undefined, fx: undefined });
    if (drag.edge === 'r') {
      const nb = segs[i + 1], b0 = it.b;
      let x = b0 + dS;
      if (x < b0) {
        x = Math.max(it.a + MIN, x);
        if (nb && nb.gone) nb.a = x; else segs.splice(i + 1, 0, goneSeg(x, b0));
        it.b = x;
      } else if (nb && nb.gone) { x = Math.min(x, nb.b); it.b = x; nb.a = x; if (nb.b - nb.a < 0.02) { it.b = nb.b; segs.splice(i + 1, 1); } }
      else if (nb) { x = Math.min(x, nb.b - MIN); it.b = x; nb.a = x; }
    } else {
      const nb = segs[i - 1], a0 = it.a;
      let x = a0 + dS;
      if (x > a0) {
        x = Math.min(it.b - MIN, x);
        if (nb && nb.gone) nb.b = x; else segs.splice(i, 0, goneSeg(a0, x));
        it.a = x;
      } else if (nb && nb.gone) { x = Math.max(x, nb.a); it.a = x; nb.b = x; if (nb.b - nb.a < 0.02) { it.a = nb.a; segs.splice(i - 1, 1); } }
      else if (nb) { x = Math.max(x, nb.a + MIN); it.a = x; nb.b = x; }
    }
    proj.segs = segs;
  }
  // Q / W: taglia la parte prima / dopo la testina dell'elemento selezionato (o della clip video sotto la testina)
  function trimAt(side) {
    const t = video.currentTime, left = side === 'left';
    const within = (a, b) => t > a + 0.05 && t < b - 0.05;
    let list = (multi.length > 1 ? multi : sel ? [sel] : []).map((m) => ({ m, o: findSel(m) })).filter((x) => x.o && x.m.type !== 'track' && x.m.type !== 'subs' && x.m.type !== 'sub');
    const hadSel = list.length > 0;
    list = list.filter(({ m, o }) => (m.type === 'sclip' ? within(o.a, o.a + o.dur) : within(o.a, o.b)));
    if (hadSel && !list.length) return toast('Porta la testina dentro l\'elemento selezionato.', true);
    if (!list.length) {
      const c = proj.segs.find((x) => !x.gone && !(BLANK && !x.ins) && within(x.a, x.b));
      if (c) list = [{ m: { type: 'seg', id: c.id }, o: c }];
    }
    if (!list.length) return toast('Metti la testina dentro l\'elemento da tagliare.', true);
    begin();
    for (const { m, o } of list) {
      if (isSeg(m.type)) {
        // il pezzo tagliato sparisce dalla timeline (come CapCut); si recupera tirando il bordo
        const i = proj.segs.indexOf(o);
        const g = { ...o, id: uid('s'), removed: true, gone: true, auto: false, speed: undefined, adj: undefined, fx: undefined };
        if (left) { g.a = o.a; g.b = t; o.a = t; proj.segs.splice(i, 0, g); } else { g.a = t; g.b = o.b; o.b = t; proj.segs.splice(i + 1, 0, g); }
      } else if (m.type === 'sclip') {
        if (left) { const d = t - o.a; o.a = +t.toFixed(3); o.dur = +(o.dur - d).toFixed(3); if (o.kind !== 'image') o.offset = (o.offset || 0) + d; else if (o.kf) o.kf = o.kf.map((k) => ({ ...k, t: +(k.t - d).toFixed(3) })).filter((k) => k.t >= 0); }
        else o.dur = +(t - o.a).toFixed(3);
      } else if (left) o.a = +t.toFixed(2);
      else o.b = +t.toFixed(2);
    }
    tidySegs();
    changed();
  }
  function tidySegs() {
    proj.segs.forEach((c) => { c.a = +c.a.toFixed(2); c.b = +c.b.toFixed(2); });
    proj.segs = proj.segs.filter((c) => c.b - c.a >= 0.02);
    for (let k = 1; k < proj.segs.length; k++) proj.segs[k].a = proj.segs[k - 1].b;
    if (proj.segs.length) { proj.segs[0].a = 0; proj.segs[proj.segs.length - 1].b = D; }
    // due pezzi eliminati uno accanto all'altro diventano uno solo
    for (let k = proj.segs.length - 1; k > 0; k--) { const p = proj.segs[k - 1], c = proj.segs[k]; if (p.gone && c.gone) { p.b = c.b; proj.segs.splice(k, 1); } }
  }
  // immagine nella traccia principale: tirando il bordo destro dura di piu' (o di meno); le clip dopo scorrono
  function startImageStretch(e, seg, el) {
    const rec = insById(seg.ins);
    if (!rec || !rec.image) return false;
    const own = proj.segs.filter((c) => c.ins === rec.id);
    const last = own.filter((c) => !c.gone).sort((x, y) => y.b - x.b)[0];
    if (!last || last.id !== seg.id || own.some((c) => c.gone && c.a >= seg.b - 1e-3)) return false;   // c'e' una parte nascosta: la ritira il bordo normale
    e.preventDefault();
    const x0 = e.clientX, sp = seg.speed || 1, max = (rec.fileDur || rec.dur) - (rec.offset || 0);
    const w0 = el.offsetWidth, len0 = rec.dur;
    let len = len0;
    const mv = (ev) => {
      len = Math.max(0.2, Math.min(max, len0 + ((ev.clientX - x0) / pps) * sp));
      len = Math.max(len0 - (seg.b - seg.a) + 0.2, len);
      el.style.width = Math.max(4, w0 + ((len - len0) / sp) * pps) + 'px';
      seekQuiet(rec.at + len - 0.05);
    };
    const up = async () => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up);
      len = +len.toFixed(2);
      if (Math.abs(len - len0) < 0.02) { renderTimeline(); return; }
      const snap = fullSnap();
      const r = removeCore(rec.id);
      if (!r) return;
      const segs = r.own.map((c) => (c.id === seg.id ? { ...c, b: +(c.b + (len - len0)).toFixed(4) } : c));
      insertCore({ ...r.copy, dur: len, words: r.copy.words }, segs);
      pushFull(snap);
      await afterDurationChange();
      sel = { type: 'seg', id: seg.id };
      changed({ transcript: true });
    };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
    return true;
  }
  // ---- trascinare una clip delle tracce (foto, video, testi, suoni) come in CapCut: la clip vera segue il mouse,
  // si appoggia sulla traccia sotto il puntatore; se li' si sovrappone a un'altra (o la lasci tra due tracce)
  // nasce da sola una traccia nuova subito sopra. Foto e video si possono lasciare anche nella traccia principale.
  function startClipFloat(e, c, el) {
    const tr0 = trackOfClip(c.id);
    if (!tr0) return;
    const kind = tr0.type === 'sound' ? 'sound' : 'overlay';
    const x0 = e.clientX, y0 = e.clientY, r0 = el.getBoundingClientRect();
    const gx = e.clientX - r0.left, gy = e.clientY - r0.top;
    const grabT = Math.max(0, tAt(e) - c.a);
    const orig = { a: c.a };
    let moved = false, fl = null, line = null, tgt = null;
    el.setPointerCapture(e.pointerId);
    const laneAtY = (y) => [...lanes.querySelectorAll('.lane[data-kind]')].find((ln) => { const r = ln.getBoundingClientRect(); return y >= r.top && y < r.bottom; });
    const clearLine = () => { if (line) line.style.display = 'none'; };
    const showLine = (ln, where) => {
      if (!line) { line = h('div', { class: 'newtrack-line' }, h('span', null, 'Nuova traccia')); tl.append(line); }
      const r = ln.getBoundingClientRect(), tr = tl.getBoundingClientRect();
      Object.assign(line.style, { display: '', top: (where === 'above' ? r.top - 4 : r.bottom + 1) - tr.top + 'px', left: r.left - tr.left + 'px', width: r.width + 'px' });
    };
    const overlaps = (track, a, dur) => track.clips.some((o) => o !== c && o.a < a + dur - 1e-3 && o.a + o.dur > a + 1e-3);
    const mv = (ev) => {
      if (!moved && Math.abs(ev.clientX - x0) < 4 && Math.abs(ev.clientY - y0) < 4) return;
      if (!moved) {
        moved = true; begin();
        fl = el.cloneNode(true); fl.classList.add('floatclip'); fl.classList.remove('sel');
        Object.assign(fl.style, { position: 'fixed', left: r0.left + 'px', top: r0.top + 'px', width: r0.width + 'px', height: r0.height + 'px', bottom: 'auto', margin: '0' });
        document.body.append(fl);
        el.classList.add('floatsrc');
      }
      // dove andrebbe (tempo, agganciato ai bordi vicini e alla testina)
      let a = Math.max(0, tAt(ev) - grabT);
      const [sa, da] = snapFind(a, c.id, true), [sb, db] = snapFind(a + c.dur, c.id, true);
      if (da <= db && da < SNAP_PX) { a = sa; showSnap(sa); } else if (db < SNAP_PX) { a = Math.max(0, sb - c.dur); showSnap(sb); } else showSnap(null);
      a = +Math.min(D - 0.1, a).toFixed(2);
      const ln = laneAtY(ev.clientY);
      const innerL = inner.getBoundingClientRect().left;
      let fx = ev.clientX - gx, fy = ev.clientY - gy, snapped = false;
      tgt = null; clearLine(); markLane(null);
      if (ln && ln.dataset.kind === kind && ln.dataset.track) {
        const track = proj.tracks.find((x) => x.id === ln.dataset.track);
        const r = ln.getBoundingClientRect();
        const edgeZone = Math.min(9, r.height * 0.22);
        if (kind === 'overlay' && ev.clientY < r.top + edgeZone) { tgt = { newAbove: ln, a }; showLine(ln, 'above'); }
        else if (track && overlaps(track, a, c.dur)) { tgt = { newAbove: ln, a }; if (kind === 'overlay') showLine(ln, 'above'); else tgt = { newSound: true, a }; }
        else { tgt = { track, a }; fx = innerL + X(a); fy = r.top + (r.height - r0.height) / 2; snapped = true; }
      } else if (ln && ln.dataset.kind === 'video' && kind === 'overlay' && ['image', 'video'].includes(c.kind)) {
        tgt = { main: true }; markLane(ln);
      } else if (ln && kind === 'overlay') {
        // sopra testi/zoom o tra le tracce: una traccia nuova in quel punto
        tgt = { newAbove: ln, a }; showLine(ln, 'above');
      } else if (!ln && kind === 'overlay') {
        const first = lanes.querySelector('.lane[data-kind]');
        if (first && ev.clientY < first.getBoundingClientRect().top) { tgt = { newAbove: first, a }; showLine(first, 'above'); }
      }
      fl.classList.toggle('snapped', snapped);
      fl.style.left = fx + 'px'; fl.style.top = fy + 'px';
      const sr = scroller.getBoundingClientRect();   // vicino ai bordi la timeline scorre
      if (ev.clientX > sr.right - 30) scroller.scrollLeft += 12; else if (ev.clientX < sr.left + 30) scroller.scrollLeft -= 12;
    };
    const up = async (ev) => {
      el.removeEventListener('pointermove', mv);
      showSnap(null); clearLine(); markLane(null);
      if (line) line.remove();
      if (!moved) { renderTimeline(); renderPanel(); tapSeek(ev, Math.max(c.a, Math.min(c.a + c.dur - 0.02, tAt(ev)))); return; }
      if (fl) fl.remove();
      el.classList.remove('floatsrc');
      if (!tgt) { renderTimeline(); return; }   // lasciata fuori: resta dov'era
      if (tgt.main) { c.a = orig.a; await overlayToMain(c, tAt(ev) - grabT); return; }
      const from = trackOfClip(c.id);
      let to = tgt.track;
      if (tgt.newAbove || tgt.newSound) {
        to = newTrack(kind);
        if (kind === 'overlay' && tgt.newAbove) {
          // la traccia nuova va subito sopra quella indicata
          const key = 'ov:' + to.id, below = tgt.newAbove.dataset.layer || (tgt.newAbove.dataset.kind === 'video' ? 'video' : null);
          const rest = proj.layers.filter((k) => k !== key);
          const i = below ? rest.indexOf(below) : -1;
          if (i >= 0) { rest.splice(i, 0, key); proj.layers = rest; proj.layers = normLayers(); }
        }
      }
      c.a = tgt.a;
      if (from && to && from !== to) { from.clips = from.clips.filter((x) => x !== c); to.clips.push(c); }
      if (to) to.clips.sort((x, y) => x.a - y.a);
      sel = { type: 'sclip', id: c.id };
      changed();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }
  async function onDragEnd(e) {
    if (!drag) return;
    if (isSeg(drag.type)) {
      window.removeEventListener('pointermove', onDragMove);
      if (drag.raf) cancelAnimationFrame(drag.raf);
      const moved = drag.moved;
      drag = null;
      if (moved) { tidySegs(); changed(); } else { renderTimeline(); renderPanel(); }
      return;
    }
    drag.el.removeEventListener('pointermove', onDragMove);
    showSnap(null);
    const moved = drag.moved;
    const it = findSel({ type: drag.type, id: drag.id });
    const clickT = drag.clickT;
    drag.el.style.pointerEvents = '';
    const lane = drag.lane, lane0 = drag.lane0, toMain = drag.toMain, orig = drag.orig;
    drag = null;
    markLane(null);
    if (moved && toMain && it) { it.a = orig.a; if (orig.dur !== undefined) it.dur = orig.dur; await overlayToMain(it, tAt(e)); return; }
    if (moved && it && lane && lane !== lane0) {
      if (lane.dataset.zt) it.track = lane.dataset.zt;
      else if (lane.dataset.fxt) it.track = lane.dataset.fxt;
      else if (lane.dataset.track) {
        const from = trackOfClip(it.id), to = proj.tracks.find((t) => t.id === lane.dataset.track);
        if (from && to && from !== to) { from.clips = from.clips.filter((c) => c !== it); to.clips.push(it); to.clips.sort((x, y) => x.a - y.a); }
      }
    }
    if (moved) {
      if (it && it.a !== undefined && it.b !== undefined) { it.a = +it.a.toFixed(2); it.b = +it.b.toFixed(2); }
      if (sel && isSeg(sel.type)) { const i = proj.segs.indexOf(it); if (proj.segs[i - 1]) proj.segs[i - 1].b = it.a; if (proj.segs[i + 1]) proj.segs[i + 1].a = it.b; }
      if (it && it.dur !== undefined) { it.a = +it.a.toFixed(2); it.dur = +it.dur.toFixed(2); }
      if (sel && sel.type === 'zoom') proj.zooms.sort((a, b) => a.a - b.a);
      changed();
    } else {
      renderTimeline(); renderPanel();
      // clic su un blocco: solo selezione; doppio clic: la testina va li'
      if (it) {
        const a0 = it.a, b0 = it.dur !== undefined ? it.a + it.dur : it.b;
        tapSeek(e, Math.max(a0, Math.min(b0 - 0.02, clickT)));
      }
    }
  }

  // la testina si sposta solo col doppio clic (il righello invece la trascina sempre)
  let lastTap = null;
  function tapSeek(e, t) {
    const now = performance.now(), x = e ? e.clientX : 0, y = e ? e.clientY : 0;
    if (lastTap && now - lastTap.t < 380 && Math.hypot(x - lastTap.x, y - lastTap.y) < 8) { lastTap = null; seek(t); return true; }
    lastTap = { t: now, x, y }; return false;
  }
  // clic sul righello o sullo sfondo: sposta la testina
  function tAt(e) { return Math.max(0, Math.min(D, T((e.clientX - inner.getBoundingClientRect().left) / pps))); }
  let scrub = false;
  // magnete: la testina e i blocchi si agganciano ai bordi vicini (clip, zoom, filtri, immagini, suoni)
  let snapOn = store.get('snap', true);
  const SNAP_PX = 10;
  const snapLine = h('div', { class: 'snapline', style: { display: 'none' } });
  inner.append(snapLine);
  function snapTargets(exceptId) {
    const r = [0, D];
    for (const c of proj.segs) if (!c.gone) r.push(c.a, c.b);
    for (const z of proj.zooms) if (z.id !== exceptId) r.push(z.a, z.b);
    for (const f of proj.filters) if (f.id !== exceptId) r.push(f.a, f.b);
    for (const tr of clipTracks()) for (const c of tr.clips) if (c.id !== exceptId) r.push(c.a, c.a + c.dur);
    if (proj.settings.showSubs) for (const ch of subChunks()) if (!ch.hidden) r.push(ch.a, ch.b);
    return r;
  }
  function showSnap(t) { if (t == null) snapLine.style.display = 'none'; else Object.assign(snapLine.style, { display: '', left: X(t) + 'px' }); }
  // ritorna [tempo agganciato, distanza in px] (se non c'e' niente vicino: tempo invariato)
  function snapFind(t, exceptId, withPlayhead) {
    if (!snapOn) return [t, Infinity];
    const xt = X(t);
    let best = t, bd = SNAP_PX;
    for (const s2 of snapTargets(exceptId)) { const d = Math.abs(X(s2) - xt); if (d < bd) { bd = d; best = s2; } }
    if (withPlayhead) { const pt = video.currentTime, d = Math.abs(X(pt) - xt); if (d < bd) { bd = d; best = pt; } }
    return [best, bd];
  }
  function snapT(t, exceptId, withPlayhead) { const [b, d] = snapFind(t, exceptId, withPlayhead); showSnap(d < SNAP_PX ? b : null); return b; }
  // clic sul righello: sposta la testina. Trascinando sulle tracce: rettangolo di selezione (come in Windows)
  let marq = null;
  inner.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || e.target.closest('.blk, button, .lane-cta')) return;
    inner.setPointerCapture(e.pointerId);
    if (e.target.closest('.ruler') || e.target === playhead) {
      scrub = true;
      if (sel && sel.type !== 'track') { sel = null; multi = []; renderTimeline(); renderPanel(); }
      seek(snapT(tAt(e))); return;
    }
    startMarquee(e);
  });
  function startMarquee(e, segClick) {
    inner.setPointerCapture(e.pointerId);
    const r = inner.getBoundingClientRect();
    marq = { x0: e.clientX - r.left, y0: e.clientY - r.top, t: tAt(e), el: null, add: e.ctrlKey || e.shiftKey || e.metaKey, base: multi.slice(), segClick };
  }
  inner.addEventListener('pointermove', (e) => {
    if (scrub) { seekQuiet(snapT(tAt(e))); return; }
    if (!marq) return;
    const r = inner.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    if (!marq.el && Math.hypot(x - marq.x0, y - marq.y0) < 5) return;
    if (!marq.el) { marq.el = h('div', { class: 'marquee' }); inner.append(marq.el); }
    const L = Math.min(x, marq.x0), Tt = Math.min(y, marq.y0), Wd = Math.abs(x - marq.x0), Hd = Math.abs(y - marq.y0);
    Object.assign(marq.el.style, { left: L + 'px', top: Tt + 'px', width: Wd + 'px', height: Hd + 'px' });
    const box = { l: r.left + L, t: r.top + Tt, r: r.left + L + Wd, b: r.top + Tt + Hd };
    const hit = [];
    lanes.querySelectorAll('.blk[data-type][data-id]').forEach((b) => {
      if (b.style.display === 'none') return;
      const q = b.getBoundingClientRect();
      const on = q.right > box.l && q.left < box.r && q.bottom > box.t && q.top < box.b;
      b.classList.toggle('sel', on || marq.base.some((m) => m.id === b.dataset.id));
      if (on) hit.push({ type: b.dataset.type, id: b.dataset.id });
    });
    marq.hit = hit;
  });
  inner.addEventListener('pointerup', (ev) => {
    scrub = false; showSnap(null);
    if (!marq) return;
    const m = marq; marq = null;
    if (!m.el && m.segClick) {
      // clic su un pezzo: selezionato; doppio clic: la testina va dove hai cliccato
      const c = m.segClick.item;
      multi = []; framing = false; sel = { type: m.segClick.type, id: c.id };
      tab = tabFor(sel); renderTimeline(); renderPanel(); tapSeek(ev, snapT(m.segClick.t)); showSnap(null); return;
    }
    if (!m.el) { multi = []; if (sel && sel.type !== 'track') sel = null; renderTimeline(); renderPanel(); tapSeek(ev, snapT(m.t)); showSnap(null); return; }
    m.el.remove();
    const seen = new Set(), all = [];
    for (const x of [...(m.add ? m.base : []), ...(m.hit || [])]) { const k = x.type + x.id; if (!seen.has(k)) { seen.add(k); all.push(x); } }
    multi = all.length > 1 ? all : [];
    sel = all.length ? { ...all[all.length - 1] } : null;
    if (sel) tab = tabFor(sel);
    renderTimeline(); renderPanel();
  });
  // tasto destro: menu dell'app (niente menu del browser)
  lanes.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const b = e.target.closest('.blk[data-type][data-id]');
    if (!b) return;
    const it = { type: b.dataset.type, id: b.dataset.id };
    if (!multi.some((m) => m.type === it.type && m.id === it.id) && !(sel && sel.type === it.type && sel.id === it.id)) { multi = []; sel = it; tab = tabFor(it); renderTimeline(); renderPanel(); }
    popMenuAt(e.clientX, e.clientY, blockMenu(it, e));
  });

  // zoom della timeline
  function setPps(v, anchorT) {
    const oldX = anchorT != null ? X(anchorT) - scroller.scrollLeft : 0;
    pps = Math.max(fitPps, Math.min(200, v));
    zoomSlider.value = String(Math.round(1000 * Math.log(pps / fitPps) / Math.log(Math.max(1.0001, 200 / fitPps))));
    renderTimeline();
    if (anchorT != null) scroller.scrollLeft = X(anchorT) - oldX;
    drawWave(); drawThumbs(); renderRuler();
  }
  zoomSlider.addEventListener('input', () => {
    const k = +zoomSlider.value / 1000;
    setPps(fitPps * Math.pow(200 / fitPps, k), video.currentTime);
  });
  scroller.addEventListener('wheel', (e) => {
    if (e.ctrlKey || e.metaKey) { e.preventDefault(); setPps(pps * (e.deltaY < 0 ? 1.25 : 0.8), tAt(e)); }
    else if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      // tante tracce (non ci stanno tutte): la rotella le scorre su e giu' (Maiusc + rotella: avanti e indietro nel tempo)
      const tm = tlMain, canV = tm.scrollHeight > tm.clientHeight + 2;
      if (canV && !e.shiftKey) {
        e.preventDefault(); tm.scrollTop += e.deltaY; return;
      }
      e.preventDefault(); scroller.scrollLeft += e.deltaY;
    }
  }, { passive: false });
  let scrollRaf = 0;
  scroller.addEventListener('scroll', () => {
    cancelAnimationFrame(scrollRaf);
    scrollRaf = requestAnimationFrame(() => { drawWave(); drawThumbs(); renderRuler(); });
  });

  // trascina sulla timeline: dai Media o direttamente dal PC
  let dropLane = null, dragAsset = null;
  const EMPTY_IMG = new Image(); EMPTY_IMG.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  const insMark = h('div', { class: 'insmark', style: { display: 'none' } });
  const clearDrop = () => { if (dropLane) dropLane.classList.remove('dropping'); dropLane = null; insMark.style.display = 'none'; if (typeof dropGhost !== 'undefined') dropGhost.style.display = 'none'; if (typeof dragCard !== 'undefined') dragCard.style.display = 'none'; if (typeof dropLabel !== 'undefined') dropLabel.style.display = 'none'; };
  // la traccia sotto il mouse (anche se sopra c'e' altro: testina, miniature, bordi)
  function laneAt(e) {
    for (const ln of tl.querySelectorAll('.lane[data-kind]')) {
      const r = ln.getBoundingClientRect();
      if (e.clientY >= r.top && e.clientY < r.bottom) return ln;
    }
    return null;
  }
  const dropGhost = h('div', { class: 'dropghost', style: { display: 'none' } }, h('b'), h('span'));
  const dragCard = h('div', { class: 'dragcard', style: { display: 'none' } });
  const dropLabel = h('div', { class: 'droplabel', style: { display: 'none' } });
  // se il blocco e' stretto il nome va accanto, non schiacciato dentro
  function placeDropLabel(lane, x, text, show) {
    if (!show) { dropLabel.style.display = 'none'; return; }
    if (dropLabel.parentNode !== lane) lane.append(dropLabel);
    dropLabel.textContent = text;
    Object.assign(dropLabel.style, { display: '', left: x + 6 + 'px' });
  }
  document.body.append(dragCard);
  const assetLen = (a, t) => (a.kind === 'image' ? Math.min(5, Math.max(0.3, D - t)) : Math.max(0.2, a.duration || 3));
  tl.addEventListener('dragover', (e) => {
    e.preventDefault();
    const ln = laneAt(e);
    let ok = ln && (ln.dataset.kind === 'video' || ln.dataset.track) ? ln : null;
    // un'immagine o un suono non va nella traccia principale; un video si', e anche sopra
    if (ok && dragAsset) {
      const k = dragAsset.kind, lk = ok.dataset.kind;
      if ((lk === 'video' && k !== 'video') || (lk === 'overlay' && k === 'audio') || (lk === 'sound' && k !== 'audio')) ok = null;
    }
    if (ok !== dropLane) { if (dropLane) dropLane.classList.remove('dropping'); dropLane = ok; if (ok) ok.classList.add('dropping'); }
    if (!dragAsset) { insMark.style.display = 'none'; return; }
    dragCard.style.display = ok ? 'none' : '';
    if (!ok) { dropGhost.style.display = 'none'; insMark.style.display = 'none'; dropLabel.style.display = 'none'; return; }
    const main = ok.dataset.kind === 'video';
    const t = main ? mainDropT(tAt(e)) : tAt(e);
    const len = assetLen(dragAsset, t);
    if (dropGhost.parentNode !== ok) ok.append(dropGhost);
    dropGhost.className = 'dropghost ' + (main ? 'main' : dragAsset.kind);
    dropGhost.firstChild.textContent = dragAsset.name.replace(/\.[^.]+$/, '');
    dropGhost.lastChild.textContent = main ? 'Entra qui · ' + fmt(len) : fmt(len);
    const gw = Math.max(12, len * pps);
    Object.assign(dropGhost.style, { display: '', left: X(t) + 'px', width: gw + 'px' });
    placeDropLabel(ok, X(t) + gw, dropGhost.firstChild.textContent + ' · ' + dropGhost.lastChild.textContent, gw < 90);
    dropGhost.classList.toggle('narrow', gw < 90);
    if (main) { if (insMark.parentNode !== ok) ok.append(insMark); insMark.style.left = X(t) - 1 + 'px'; insMark.style.display = ''; }
    else insMark.style.display = 'none';
  });
  // la schedina che segue il mouse finche' non sei sopra una traccia
  document.addEventListener('dragover', (e) => {
    if (!dragAsset) return;
    Object.assign(dragCard.style, { left: e.clientX + 12 + 'px', top: e.clientY + 12 + 'px' });
    if (!tl.contains(e.target)) { dragCard.style.display = ''; dropGhost.style.display = 'none'; dropLabel.style.display = 'none'; insMark.style.display = 'none'; if (dropLane) { dropLane.classList.remove('dropping'); dropLane = null; } }
  });
  tl.addEventListener('dragleave', (e) => { if (!tl.contains(e.relatedTarget)) clearDrop(); });
  tl.addEventListener('drop', async (e) => {
    e.preventDefault();
    const laneEl = laneAt(e);
    clearDrop(); dragAsset = null;
    const t = laneEl ? tAt(e) : video.currentTime;
    const main = !!(laneEl && laneEl.dataset.kind === 'video');
    const track = main ? 'main' : laneEl && laneEl.dataset.track ? proj.tracks.find((x) => x.id === laneEl.dataset.track) : null;
    const aid = e.dataTransfer.getData('application/x-vodcut-asset');
    const onMain = (a) => main && (a.kind === 'video' || a.kind === 'image');
    if (aid) { const a = proj.assets.find((x) => x.id === aid); if (a) placeAsset(a, onMain(a) ? mainDropT(t) : t, track); return; }
    const got = await uploadFiles([...e.dataTransfer.files]);
    got.forEach((a, i) => placeAsset(a, onMain(a) ? mainDropT(t) : t, i === 0 ? track : null));
  });

  // ---------------------------------------------------------------- media (immagini e suoni del progetto)
  function addAssets(list) {
    const out = [];
    for (const f of list) {
      let a = proj.assets.find((x) => x.path === f.path);
      if (!a) { a = { id: uid('m'), ...f }; proj.assets.push(a); }
      out.push(a);
    }
    if (out.length) { dirty = true; flush().then(() => { if (alive && ltab === 'media') renderPanel(); }); }
    return out;
  }
  let importing = 0;
  async function uploadFiles(files) {
    const ok = files.filter((f) => IMG_RE.test(f.name) || AUD_RE.test(f.name) || VID_RE.test(f.name));
    if (files.length && !ok.length) { toast('Trascina video (mp4, mov…), immagini (png, jpg…) o suoni (mp3, wav…)', true); return []; }
    const got = [];
    importing += ok.length; if (ltab === 'media') renderPanel();
    for (const f of ok) {
      try {
        const r = await fetch('/api/upload?kind=asset&token=' + TOKEN + '&name=' + encodeURIComponent(f.name), { method: 'PUT', body: f });
        const j = await r.json();
        if (!r.ok) { toast(j.error || 'Import non riuscito', true); continue; }
        got.push(j);
      } catch (err) { toast('Import non riuscito: ' + err.message, true); }
      importing--; if (ltab === 'media' && alive) renderPanel();
    }
    importing = 0;
    return addAssets(got);
  }
  async function importMedia() {
    try {
      const r = await post('/api/pick', { kind: 'media' });
      if (r.fallback) {
        const inp = h('input', { class: 'input', placeholder: 'C:\\...\\immagine.png', style: { width: '100%' } });
        const ok = await new Promise((res) => {
          const bg = h('div', { class: 'modal-bg' });
          const done = (v) => { bg.remove(); res(v); };
          bg.append(h('div', { class: 'modal' }, h('h2', null, 'Percorso del file'), h('p', null, 'Incolla il percorso completo dell\'immagine o del suono, oppure trascinalo qui.'), inp,
            h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: () => done(false) }, 'Annulla'), h('button', { class: 'btn primary', onclick: () => done(true) }, 'Aggiungi'))));
          document.body.append(bg); inp.focus();
          inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') done(true); });
        });
        if (!ok || !inp.value.trim()) return [];
        return addAssets([await post('/api/probe-media', { path: inp.value.trim() })]);
      }
      if (r.skipped && r.skipped.length) toast('Formato non supportato: ' + r.skipped.join(', '), true);
      return addAssets(r.files || []);
    } catch (e) { toast(e.message, true); return []; }
  }
  function newTrack(kind) {
    if (kind === 'overlay') {
      const n = ovTracks().length;
      const t = { id: uid('t'), type: 'overlay', name: 'Video ' + (n + 1), hidden: false, color: OV_COLORS[n % OV_COLORS.length], clips: [] };
      proj.tracks.push(t); proj.layers = normLayers(); freshTracks.add(t.id);
      return t;
    }
    const n = soundTracks().length;
    const t = { id: uid('t'), name: 'Audio ' + (n + 1), type: 'sound', vol: 100, mute: false, color: SOUND_COLORS[n % SOUND_COLORS.length], clips: [] };
    proj.tracks.push(t); freshTracks.add(t.id);
    return t;
  }
  // mette un elemento dei Media sulla timeline (sulla traccia giusta, o su una nuova)
  // sulla traccia principale un video entra tra due clip: si aggancia al bordo piu' vicino
  // trascinare un video inserito sulla traccia principale: lo si porta prima o dopo le altre clip
  // ---- spostare foto e video tra la traccia principale e le tracce sopra (e viceversa), trascinandoli
  function laneUnder(ev, kind) {
    const u = document.elementsFromPoint(ev.clientX, ev.clientY).find((x) => x.classList && x.classList.contains('lane'));
    return u && u.dataset.kind === kind ? u : null;
  }
  function markLane(ln) { lanes.querySelectorAll('.lane.xdrop').forEach((x) => { if (x !== ln) x.classList.remove('xdrop'); }); if (ln) ln.classList.add('xdrop'); }
  const canLeaveMain = (seg) => { const rec = seg && seg.ins && insById(seg.ins); return !!(rec && !rec.gap && !rec.live); };
  async function mainToOverlay(seg, laneEl, t) {
    const rec = insById(seg.ins);
    if (!rec || rec.gap || rec.live) return false;
    const snap = fullSnap();
    const d = mainClipData(seg), sp = seg.speed || 1, len = +(d.dur / sp).toFixed(3);
    const b = segBox(seg);   // stesso posto e stessa grandezza che aveva nel quadro
    const at = +Math.max(0, t).toFixed(2);
    let c;
    if (rec.image) {
      c = { id: uid('c'), kind: 'image', file: rec.src || rec.file, name: (rec.name || 'Immagine').replace(/\.[^.]+$/, ''), a: at, dur: len,
        pos: { x: +b[0].toFixed(4), y: +b[1].toFixed(4), w: +b[2].toFixed(4) }, ar: +(1 / (rec.iar || 1)).toFixed(5), opacity: 100 };
    } else {
      const ar = d.w && d.h ? d.h / d.w : 1 / CA();
      c = { id: uid('c'), kind: 'video', file: d.file, name: (d.name || 'Clip').replace(/\.[^.]+$/, ''), a: at, dur: len, offset: d.offset,
        fileDur: d.offset + d.dur + 1, pos: { x: +b[0].toFixed(4), y: +b[1].toFixed(4), w: +b[2].toFixed(4) }, ar, opacity: 100,
        vol: seg.vol ?? 100, mute: !!seg.mute, hasAudio: !!d.hasAudio };
      if (d.preview) c.preview = d.preview;
    }
    let tr = laneEl && laneEl.dataset.track ? proj.tracks.find((x) => x.id === laneEl.dataset.track) : null;
    const free = (x) => !x.clips.some((o) => o.a < c.a + c.dur - 1e-3 && o.a + o.dur > c.a + 1e-3);
    if (!tr || tr.type !== 'overlay' || !free(tr)) tr = proj.tracks.find((x) => x.type === 'overlay' && free(x)) || newTrack('overlay');
    tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
    seg.removed = true; seg.gone = true;   // tolta dalla traccia principale (come "Elimina dalla timeline")
    undoStack = []; pushFull(snap);
    await afterDurationChange();
    sel = { type: 'sclip', id: c.id }; multi = []; tab = 'video';
    changed({ transcript: true });
    toast(rec.image ? 'Foto spostata su una traccia sopra' : 'Video spostato su una traccia sopra');
    return true;
  }
  async function overlayToMain(c, t) {
    const snap = fullSnap();
    const tr = trackOfClip(c.id);
    if (tr) tr.clips = tr.clips.filter((x) => x !== c);
    renderTimeline();
    const ok = await insertVideo(c.file, mainDropT(t), { name: c.name, duration: c.dur }, { dur: c.dur, offset: c.kind === 'video' ? c.offset || 0 : 0, quiet: true });
    if (!ok) { if (tr) { tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a); } changed(); return; }
    undoStack = []; pushFull(snap);
    toast(c.kind === 'image' ? 'Foto spostata nella traccia principale' : 'Video spostato nella traccia principale');
  }
  function startInsMove(e, seg, el) {
    const rec = proj.inserts.find((x) => x.id === seg.ins);
    const own = proj.segs.filter((c) => c.ins === rec.id && !c.gone);
    if (own.length > 1) {   // video diviso: si sposta solo il pezzo preso, non tutto il video
      startMainMove(e, seg, el, { own: [seg], name: (rec.name || 'Video').replace(/\.[^.]+$/, ''), dur: (seg.b - seg.a) / (seg.speed || 1), skip: null,
        drop: (target) => moveInsPiece(seg, target) });
      return;
    }
    startMainMove(e, seg, el, { own, name: (rec.name || 'Video').replace(/\.[^.]+$/, ''), dur: rec.dur, skip: rec.id,
      drop: (target) => moveInsert(rec.id, target) });
  }
  function startLiveMove(e, seg, el) {
    startMainMove(e, seg, el, { own: [seg], name: 'Clip', dur: (seg.b - seg.a) / (seg.speed || 1), skip: null, live: true,
      drop: (target) => moveLiveSeg(seg, target) });
  }
  // trascinamento di una clip della traccia principale: fantasma che segue il mouse, riga dove entra
  function startMainMove(e, seg, el, o) {
    const lane = el.parentNode, x0 = e.clientX, y0 = e.clientY;
    const own = o.own;
    const a0 = Math.min(...own.map((c) => c.a)), b0 = Math.max(...own.map((c) => c.b));
    const innerL = () => inner.getBoundingClientRect().left;
    const grab = e.clientX - innerL() - X(a0), w = Math.max(24, X(b0) - X(a0));
    let moved = false, target = null, ghost = null, xLane = null;
    el.setPointerCapture(e.pointerId);
    const mv = (ev) => {
      if (!moved && Math.abs(ev.clientX - x0) < 5 && Math.abs(ev.clientY - y0) < 5) return;
      if (!moved) {
        moved = true;
        ghost = liftVisual(own.map((c) => c.id));
        lane.querySelectorAll('.blk.seg').forEach((b) => { if (own.some((c) => c.id === b.dataset.id)) b.classList.add('lifted'); });
      }
      const gl = Math.max(0, ev.clientX - innerL() - grab);
      if (ghost) ghost.move(gl - ghost.x0, !o.live && canLeaveMain(seg) ? ev.clientY - y0 : 0);
      xLane = !o.live && canLeaveMain(seg) ? laneUnder(ev, 'overlay') : null;
      markLane(xLane);
      if (xLane) { insMark.style.display = 'none'; dropLabel.style.display = 'none'; return; }
      placeDropLabel(lane, gl + w, o.name + ' · ' + fmt(o.dur), w < 90);
      target = mainDropT(tAt(ev), o.skip);
      const same = target >= a0 - 1e-3 && target <= b0 + 1e-3;
      if (insMark.parentNode !== lane) lane.append(insMark);
      insMark.style.left = X(target) - 1 + 'px'; insMark.style.display = same ? 'none' : '';
      const r = scroller.getBoundingClientRect();   // vicino ai bordi la timeline scorre
      if (ev.clientX > r.right - 30) scroller.scrollLeft += 12; else if (ev.clientX < r.left + 30) scroller.scrollLeft -= 12;
    };
    const up = async (ev) => {
      el.removeEventListener('pointermove', mv);
      insMark.style.display = 'none'; dropLabel.style.display = 'none';
      lane.querySelectorAll('.blk.lifted').forEach((b) => b.classList.remove('lifted'));
      if (!moved) { tapSeek(ev, Math.max(seg.a, Math.min(seg.b - 0.05, tAt(ev)))); return; }
      markLane(null);
      if (xLane) { if (ghost) ghost.done(); await mainToOverlay(seg, xLane, tAt(ev) - grab / pps); return; }
      if (target !== null && !(target >= a0 - 1e-3 && target <= b0 + 1e-3)) await o.drop(target);
      if (ghost) ghost.done();
    };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up, { once: true });
  }
  // istante della live che si vede al tempo t della timeline (fuori dai video inseriti)
  function liveOffAt(t) {
    let L = t;
    for (const i of proj.inserts || []) if (i.at + i.dur <= t + 1e-6) L -= i.dur;
    return Math.max(0, L);
  }
  // sposta una clip della live: al suo posto resta un buco chiuso (la clip sparisce da li') e la stessa parte della
  // live entra nel punto scelto come clip a se', che si puo' spostare ancora, dividere, eliminare
  async function moveLiveSeg(c, target) {
    const orig = { id: c.id, gone: !!c.gone, removed: !!c.removed };
    const dur = +(c.b - c.a).toFixed(4);
    const rel = (x) => +(x - c.a).toFixed(4);
    const words = allWords().filter((sg) => sg.a >= c.a - 1e-6 && sg.b <= c.b + 1e-6)
      .map((sg) => ({ ...sg, a: rel(sg.a), b: rel(sg.b), words: (sg.words || []).map((w2) => ({ ...w2, a: rel(w2.a), b: rel(w2.b) })) }));
    const rec = { id: uid('v'), at: target, dur, offset: +liveOffAt(c.a).toFixed(4), file: proj.source, live: true, name: 'Clip della live',
      w: W, h: H, hasAudio: proj.hasAudio !== false, words };
    const own = [{ ...c, id: uid('s'), a: 0, b: dur, removed: false, gone: false, auto: false }];
    c.gone = true; c.removed = true;
    // il punto scelto e' nel tempo di prima: se e' dopo la clip, non cambia (la clip resta sulla timeline, nascosta)
    const segs = insertCore(rec, own);
    undoStack = [{ kind: 'liveMove', id: rec.id, seg: orig }]; redoStack = [];
    updateUndo();
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id }; tab = 'video';
    changed({ transcript: true });
    seek(rec.at + 0.05);
  }
  // un pezzo di un video inserito (diviso) spostato da solo: diventa una clip a se' nel punto scelto
  async function moveInsPiece(c, target) {
    const src = insById(c.ins);
    if (!src) return;
    const snap = fullSnap();
    const dur = +(c.b - c.a).toFixed(4);
    const rel = (x) => +(x - c.a).toFixed(4);
    const words = allWords().filter((sg) => sg.a >= c.a - 1e-6 && sg.b <= c.b + 1e-6)
      .map((sg) => ({ ...sg, a: rel(sg.a), b: rel(sg.b), words: (sg.words || []).map((w2) => ({ ...w2, a: rel(w2.a), b: rel(w2.b) })) }));
    const { id: _i, at: _a, dur: _d, offset: _o, words: _w, ...base } = src;
    const rec = { ...base, id: uid('v'), at: target, dur, offset: +((src.offset || 0) + (c.a - src.at)).toFixed(4), words };
    const own = [{ ...c, id: uid('s'), a: 0, b: dur, removed: false, gone: false, auto: false, ins: undefined }];
    c.gone = true; c.removed = true;
    const segs = insertCore(rec, own);
    undoStack = []; pushFull(snap);
    await afterDurationChange();
    sel = { type: 'seg', id: segs[0].id }; tab = 'video';
    changed({ transcript: true });
    seek(rec.at + 0.05);
  }
  function mainDropT(t, skipIns) {
    if (BLANK) {
      // come in CapCut: le clip si mettono una dopo l'altra, dall'inizio (niente buchi nella traccia principale)
      const cl = proj.segs.filter((c) => c.ins && !c.gone && c.ins !== skipIns);
      if (!cl.length) { const m0 = proj.segs.filter((c) => !c.gone).reduce((m, c) => Math.min(m, c.a), Infinity); return Number.isFinite(m0) ? m0 : 0; }
      const end = Math.max(...cl.map((c) => c.b));
      if (t >= end) return end;
      let best = 0, bd = Infinity;
      for (const x of cl) for (const e2 of [x.a, x.b]) { const d2 = Math.abs(e2 - t); if (d2 < bd) { bd = d2; best = e2; } }
      return best;
    }
    const segs = proj.segs.filter((c) => !c.gone && (!skipIns || c.ins !== skipIns));
    const c = segs.find((x) => t >= x.a && t < x.b);
    if (c) return t - c.a < c.b - t ? c.a : c.b;
    let best = t, bd = Infinity;
    for (const x of segs) for (const e of [x.a, x.b]) { const d = Math.abs(e - t); if (d < bd) { bd = d; best = e; } }
    return best;
  }
  function placeAsset(a, at, track) {
    if ((a.kind === 'video' || a.kind === 'image') && track === 'main') return insertVideo(a.path, at, a);
    if (track === 'main') track = null;
    const kind = a.kind === 'image' || a.kind === 'video' ? 'overlay' : 'sound';
    if (track && track.type !== kind) track = null;
    begin();
    const fresh = !track;
    if (!track) track = newTrack(kind);
    const t = Math.max(0, Math.min(D - 0.3, at));
    const name = a.name.replace(/\.[^.]+$/, '');
    let c;
    if (a.kind === 'video') {
      // video in sovrimpressione: all'inizio grande quanto lo schermo (senza deformarlo)
      const ar = a.w && a.h ? a.h / a.w : 9 / 16;
      const w = Math.min(1, (1 / CA()) / ar), hf = w * CA() * ar;
      c = { id: uid('c'), kind: 'video', file: a.path, name, a: +t.toFixed(2), dur: +Math.max(0.2, Math.min(a.duration, D - t)).toFixed(2), offset: 0, fileDur: a.duration,
        pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, ar, opacity: 100, vol: 100, mute: false, hasAudio: !!a.hasAudio };
    } else if (a.kind === 'image') {
      const ar = a.w && a.h ? a.h / a.w : 9 / 16;
      const w = Math.min(0.35, 0.6 * (1 / CA()) / ar), hf = w * CA() * ar;
      c = { id: uid('c'), kind: 'image', file: a.path, name, a: +t.toFixed(2), dur: +Math.max(0.3, Math.min(5, D - t)).toFixed(2),
        pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, ar, opacity: 100 };
    } else {
      const long = a.duration > 20;
      if (fresh && long) { track.name = tx('Musica'); track.vol = 25; }
      c = { id: uid('s'), file: a.path, name, a: +t.toFixed(2), dur: +Math.max(0.2, Math.min(a.duration, D - t)).toFixed(2), offset: 0, fileDur: a.duration,
        vol: 100, mute: false, fin: false, fout: long, duck: long };
    }
    track.clips.push(c); track.clips.sort((x, y) => x.a - y.a);
    sel = { type: 'sclip', id: c.id };
    changed();
    if (a.kind === 'image' || a.kind === 'video') { tab = 'video'; seekQuiet(c.a + 0.05); renderPanel(); }
  }

  // ---------------------------------------------------------------- azioni
  // traccia dove aggiungere: quella dell'elemento selezionato, se no la principale
  function curZoomTrack() { const z = sel && sel.type === 'zoom' ? findSel() : null; return (z && z.track) || 'zoom'; }
  function curFxTrack() { const f = sel && sel.type === 'fx' ? findSel() : null; return (f && f.track) || 'fx'; }
  function addZoom() {
    if (!cam) return toast('Per gli zoom serve la webcam: impostala in Proprietà → Progetto.', true);
    const t = video.currentTime;
    let a = t, b = Math.min(D, t + 4);
    const zt = curZoomTrack();
    for (const z of proj.zooms.filter((x) => x.track === zt)) { if (z.a <= a && a < z.b) return select({ type: 'zoom', id: z.id }); if (z.a > a && z.a < b) b = z.a; }
    if (b - a < 0.8) return toast('Qui non c\'è spazio per un altro zoom.', true);
    begin();
    const z = { id: uid('z'), track: zt, a: +a.toFixed(2), b: +b.toFixed(2), on: true, level: 2.8, in: 'snap', out: 'cut' };
    proj.zooms.push(z); proj.zooms.sort((x, y) => x.a - y.a);
    sel = { type: 'zoom', id: z.id }; tab = 'video';
    changed();
  }
  function addCustomZoom() {
    const t = video.currentTime;
    let a = t, b = Math.min(D, t + 4);
    const zt = curZoomTrack();
    for (const z of proj.zooms.filter((x) => x.track === zt)) { if (z.a <= a && a < z.b) return select({ type: 'zoom', id: z.id }); if (z.a > a && z.a < b) b = z.a; }
    if (b - a < 0.8) return toast('Qui non c\'è spazio per un altro zoom.', true);
    begin();
    const w = W / 2;
    const z = { id: uid('z'), track: zt, kind: 'custom', a: +a.toFixed(2), b: +b.toFixed(2), on: true, rect: [Math.round((W - w) / 2), Math.round((H - w * H / W) / 2), Math.round(w)], in: 'snap', out: 'cut' };
    proj.zooms.push(z); proj.zooms.sort((x, y) => x.a - y.a);
    sel = { type: 'zoom', id: z.id }; tab = 'video'; framing = true;
    changed();
    seekQuiet(z.a + 0.6);
    toast('Sposta e ridimensiona il riquadro sull\'anteprima per scegliere cosa inquadrare.');
  }
  function splitSeg() {
    const t = video.currentTime;
    const c = proj.segs.find((x) => t > x.a + 0.1 && t < x.b - 0.1);
    if (!c) return toast('Sposta la testina un po\' più dentro il pezzo.', true);
    begin();
    const n = { ...c, id: uid('s'), a: +t.toFixed(2), auto: false, adj: c.adj ? { ...c.adj } : undefined, fx: c.fx ? { ...c.fx } : undefined };
    c.b = +t.toFixed(2);
    proj.segs.splice(proj.segs.indexOf(c) + 1, 0, n);
    sel = { type: tab === 'audio' ? 'aseg' : 'seg', id: n.id }; if (tab !== 'audio') tab = 'video';
    changed();
  }
  function mergeSeg(it, dir) {
    const i = proj.segs.indexOf(it), o = proj.segs[i + dir];
    if (!o) return;
    begin();
    if (dir < 0) { o.b = it.b; } else { o.a = it.a; }
    o.auto = false;
    proj.segs.splice(i, 1);
    sel = { type: sel.type, id: o.id };
    changed();
  }
  function deleteSel() {
    if (multi.length > 1) return deleteMany(multi, false);
    if (!sel) return;
    const it = findSel();
    if (!it) return;
    begin();
    if (sel.type === 'zoom') proj.zooms = proj.zooms.filter((z) => z.id !== sel.id);
    else if (isSeg(sel.type)) it.removed = !it.removed;
    else if (sel.type === 'fx') proj.filters = proj.filters.filter((f) => f.id !== sel.id);
    else if (sel.type === 'sclip') { const tr = trackOfClip(sel.id); tr.clips = tr.clips.filter((c) => c.id !== sel.id); }
    else if (sel.type === 'track' && it.type !== 'live') { proj.tracks = proj.tracks.filter((t) => t.id !== sel.id); proj.layers = normLayers(); }
    else { undoStack.pop(); return; }
    if (!isSeg(sel.type)) sel = null;
    changed();
  }

  // ---------------------------------------------------------------- pannello
  function setTab(t) { tab = t; renderPanel(); }
  // due pannelli come CapCut: a sinistra Progetto / Media / Clip, a destra Video / Audio / Testo
  const RIGHT_TABS = ['video', 'audio', 'text'];
  function renderPanel() {
    if (LEFT_TABS.includes(tab)) { if (ltab !== tab) { ltab = tab; store.set('ltab', ltab); } tab = renderPanel.lastRight || 'video'; }
    else if (!RIGHT_TABS.includes(tab)) tab = 'video';
    if (tab === 'clips') tab = 'video';
    renderPanel.lastRight = tab;
    panelTabs.className = '';
    panelTabs.replaceChildren(seg(['Video', 'Audio', 'Testo'], RIGHT_TABS.indexOf(tab), (i) => setTab(RIGHT_TABS[i]), 'tabs3'));
    panelBody.replaceChildren();
    liveCtls = [];
    curBody = panelBody;
    if (multi.length > 1) renderMulti();
    else if (tab === 'text') renderTextTab();
    else if (tab === 'audio') renderAudioTab();
    else renderVideoTab();
    renderLeft();
  }
  function renderLeft() {
    const keep = lBody.scrollTop, same = renderLeft.last === ltab;
    const labels = { story: 'Storia', project: 'Progetto', media: 'Media', clips: 'Clip' };
    lTabs.replaceChildren(seg(LEFT_TABS.map((k) => labels[k]), LEFT_TABS.indexOf(ltab), (i) => { ltab = LEFT_TABS[i]; store.set('ltab', ltab); renderLeft(); }, 'tabs3'));
    const liveR = liveCtls;
    lBody.replaceChildren();
    curBody = lBody; liveCtls = [];
    try {
      if (ltab === 'media') renderMedia();
      else if (ltab === 'clips') renderClipsTab();
      else if (ltab === 'story') renderStoryTab();
      else renderProject();
    } finally { liveCtls = liveR.concat(liveCtls); curBody = panelBody; }
    renderLeft.last = ltab;
    if (same) lBody.scrollTop = keep;
  }

  // --- media
  // zona di import: si clicca per scegliere i file o ci si trascinano sopra
  function dropZone(compact) {
    const busy = importing > 0;
    const z = h('button', { class: 'mzone' + (compact ? ' compact' : '') + (busy ? ' busy' : ''), 'aria-label': 'Importa video, immagini e suoni',
      'data-tip': compact ? 'Importa video, immagini e suoni (o trascinali qui)' : null, onclick: () => { if (!importing) importMedia(); } },
      h('span', { class: 'mz-ico' }, busy ? h('div', { class: 'spinner' }) : icon(compact ? 'plus' : 'upload', compact ? 20 : 24, 'currentColor', 1.8)),
      compact ? null : h('strong', null, busy ? 'Importo…' : 'Video, immagini e suoni'),
      compact ? null : h('span', { class: 'xs' }, busy ? 'Un attimo' : 'Clicca o trascina qui i file'));
    return z;
  }
  function renderMedia() {
    const list = proj.assets;
    const wrap = h('div', { class: 'media' + (list.length ? '' : ' empty') });
    if (!list.length) { wrap.append(dropZone(false)); curBody.append(wrap, h('div', { class: 'mdrop-veil' }, icon('upload', 22), 'Rilascia per importare')); return; }
    const grid = h('div', { class: 'media-grid' }, dropZone(true));
    for (const a of list) {
      const isImg = a.kind === 'image', isVid = a.kind === 'video';
      const tip = isVid ? ' · trascina sulla traccia Video per metterlo nel video, sopra per sovrapporlo' : ' · trascina sulla timeline';
      const tile = h('div', { class: 'asset', draggable: 'true', 'data-tip': a.name + (isImg ? '' : ' · ' + fmt(a.duration || 0)) + tip },
        h('div', { class: 'asset-pic' + (isImg || isVid ? '' : ' snd') },
          isImg ? h('img', { src: mediaUrl(a.path), alt: '', draggable: 'false' })
            : isVid ? [h('img', { src: mthumbUrl(a.path, Math.min(1, (a.duration || 2) / 2)), alt: '', draggable: 'false' }), h('span', { class: 'asset-dur' }, fmt(a.duration || 0))]
              : icon('music', 22, '#2DD4BF')),
        h('div', { class: 'asset-nm' }, a.name.replace(/\.[^.]+$/, '')),
        h('div', { class: 'asset-acts' },
          ibtn('plus', 'Aggiungi alla timeline qui', () => placeAsset(a, video.currentTime, null), { size: 14 }),
          ibtn('x', 'Togli dai Media', () => { proj.assets = proj.assets.filter((x) => x.id !== a.id); dirty = true; scheduleSave(); renderPanel(); }, { size: 14 })));
      tile.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('application/x-vodcut-asset', a.id); e.dataTransfer.effectAllowed = 'copy'; tile.classList.add('dragging'); dragAsset = a;
        e.dataTransfer.setDragImage(EMPTY_IMG, 0, 0);
        const pic = tile.querySelector('.asset-pic img');
        dragCard.replaceChildren(pic ? h('img', { src: pic.src, alt: '' }) : icon('music', 16, '#2DD4BF'), h('span', null, a.name.replace(/\.[^.]+$/, '')));
        Object.assign(dragCard.style, { display: '', left: e.clientX + 12 + 'px', top: e.clientY + 12 + 'px' });
      });
      tile.addEventListener('dragend', () => { tile.classList.remove('dragging'); dragAsset = null; clearDrop(); });
      tile.addEventListener('dblclick', () => placeAsset(a, video.currentTime, null));
      grid.append(tile);
    }
    wrap.append(grid);
    curBody.append(wrap, h('div', { class: 'mdrop-veil' }, icon('upload', 22), 'Rilascia per importare'));
  }
  // file trascinati dal PC sul pannello Media: evidenziazione morbida, senza sfarfallii
  let dragDepth = 0;
  const isFileDrag = (e) => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  leftPanel.addEventListener('dragenter', (e) => { if (ltab !== 'media' || !isFileDrag(e)) return; e.preventDefault(); dragDepth++; leftPanel.classList.add('mdrag'); });
  leftPanel.addEventListener('dragover', (e) => { if (ltab !== 'media' || !isFileDrag(e)) return; e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
  leftPanel.addEventListener('dragleave', (e) => { if (ltab !== 'media' || !isFileDrag(e)) return; dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) leftPanel.classList.remove('mdrag'); });
  leftPanel.addEventListener('drop', async (e) => {
    if (ltab !== 'media' || !isFileDrag(e)) return;
    e.preventDefault(); dragDepth = 0; leftPanel.classList.remove('mdrag');
    await uploadFiles([...e.dataTransfer.files]);
  });
  window.addEventListener('dragend', () => { dragDepth = 0; leftPanel.classList.remove('mdrag'); });
  window.addEventListener('drop', () => { dragDepth = 0; leftPanel.classList.remove('mdrag'); });

  // --- controlli
  const cH = (label) => h('div', { class: 'ctl-h' }, label);
  function cSlider(label, value, min, max, step, fmtV, onInput) {
    const val = h('span', { class: 'val' }, fmtV(value));
    const id = uid('r');
    const r = h('input', { id, type: 'range', min, max, step, value });
    let started = false;
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } onInput(+r.value); val.textContent = fmtV(+r.value); dirty = true; scheduleSave(); renderTimeline(); });
    r.addEventListener('change', () => { started = false; renderHeads(); });
    return h('div', { class: 'ctl' }, h('div', { class: 'top' }, h('label', { for: id }, label), val), r);
  }
  function cToggle(label, on, onChange, hint, disabled) {
    const t = toggle(on, (v) => { begin(); onChange(v); changed(); }, label);
    if (disabled) t.disabled = true;
    return h('div', { class: 'tgl' + (disabled ? ' disabled' : ''), 'data-tip': hint || null }, h('div', { class: 'tx' }, label), t);
  }
  function cSeg(label, labels, cur, onPick) {
    return h('div', { class: 'ctl' }, label ? h('div', { class: 'lbl' }, label) : null, seg(labels, cur, (i) => { begin(); onPick(i); changed(); }));
  }
  // piu' elementi selezionati: cosa sono e cosa puoi farci tutti insieme
  function renderMulti() {
    const items = multi.map((m) => ({ m, o: findSel(m) })).filter((x) => x.o);
    const NAMES = { sub: ['frase', 'frasi'], seg: ['pezzo', 'pezzi'], aseg: ['pezzo audio', 'pezzi audio'], zoom: ['zoom', 'zoom'], fx: ['filtro', 'filtri'], sclip: ['elemento', 'elementi'] };
    const cnt = {};
    items.forEach((x) => { cnt[x.m.type] = (cnt[x.m.type] || 0) + 1; });
    const sub = Object.entries(cnt).map(([k, v]) => v + ' ' + (NAMES[k] || [k, k])[v > 1 ? 1 : 0]).join(' · ');
    B.append(head(items.length + ' elementi selezionati', sub, '#2F8BFF', true));
    const list = h('div', { class: 'mlist' });
    for (const [ic, label, note, fn, color] of blockMenu(multi[0])) {
      if (Array.isArray(fn)) {
        list.append(h('div', { class: 'mrow' }, h('span', { class: 'pm-ic' }, icon(ic, 15)), h('span', { class: 'ml' }, label),
          h('div', { class: 'mchips' }, ...fn.map(([, l, , f]) => h('button', { class: 'pchip', onclick: f }, l)))));
      } else {
        list.append(h('button', { class: 'mrow btnrow', onclick: fn }, h('span', { class: 'pm-ic' }, icon(ic, 15, color || 'currentColor')),
          h('span', { class: 'ml' }, label, note ? h('small', null, note) : null)));
      }
    }
    B.append(list);
  }
  function head(title, sub, color, back, actions) {
    return h('div', { class: 'insp-head' },
      back ? ibtn('left', 'Indietro', () => select(null, true), { size: 15 }) : null,
      color ? h('div', { class: 'dot', style: { background: color } }) : null,
      h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px', minWidth: '0', flexGrow: '1' } }, h('div', { class: 't' }, title), sub ? h('div', { class: 'xs' }, sub) : null),
      actions || null);
  }
  // riga audio compatta: [muto] ——volume—— 100%
  function cAudio(it, muteTip) {
    const val = h('span', { class: 'val' }, it.vol + '%');
    const r = h('input', { type: 'range', min: 0, max: 200, step: 5, value: it.vol, 'aria-label': 'Volume', disabled: it.mute ? true : null });
    let started = false;
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } it.vol = +r.value; val.textContent = it.vol + '%'; dirty = true; scheduleSave(); renderTimeline(); });
    r.addEventListener('change', () => { started = false; });
    const mb = ibtn(it.mute ? 'mute' : 'speaker', it.mute ? 'Riattiva l\'audio' : muteTip, () => { begin(); it.mute = !it.mute; changed(); }, { color: it.mute ? '#FF7B72' : 'currentColor', size: 16 });
    return h('div', { class: 'arow' }, mb, r, val);
  }
  // dissolvenze come due icone
  function cFades(it) {
    return h('div', { class: 'tgl' }, h('div', { class: 'tx' }, 'Dissolvenze'),
      h('div', { class: 'row', style: { gap: '2px' } },
        ibtn('fadeIn', 'Dissolvenza audio in entrata', () => { begin(); it.fin = !it.fin; changed(); }, { pressed: !!it.fin, size: 15 }),
        ibtn('fadeOut', 'Dissolvenza audio in uscita', () => { begin(); it.fout = !it.fout; changed(); }, { pressed: !!it.fout, size: 15 })));
  }
  const pct = (v) => v + '%';

  // controlli che seguono la testina (valori animati dai keyframe)
  let liveCtls = [];
  const B = { append: (...a) => curBody.append(...a.filter((x) => x != null && x !== false)) };
  const emptyTab = (ic, title, text) => h('div', { class: 'tab-empty' }, h('span', { class: 'te-ico' }, icon(ic, 20)), h('strong', null, title), h('span', null, text));
  // sezione a scomparsa (chiusa all'inizio, si apre col clic), come CapCut. Lo stato resta ricordato
  const openSec = new Map();   // tutto chiuso all'apertura; durante la sessione resta come lo lasci
  function fold(key, title, body, opt = {}) {
    let isOpen = openSec.has(key) ? openSec.get(key) : !!opt.open;
    openSec.set(key, isOpen);   // da qui in poi si apre/chiude solo quando lo decidi tu
    const inner = h('div', { class: 'fold-in' });
    let built = false;
    const build = () => { if (built) return; built = true; const b = typeof body === 'function' ? body() : body; (Array.isArray(b) ? b : [b]).filter(Boolean).forEach((x) => inner.append(x)); };
    if (isOpen) build();
    const btn = h('button', { class: 'fold-t', 'aria-expanded': String(isOpen) }, icon('chev', 11, 'currentColor', 2.4), h('span', null, title),
      opt.tip ? h('i', { class: 'fold-tip', 'data-tip': opt.tip }, icon('info', 12, 'currentColor', 2)) : null,
      opt.note ? h('span', { class: 'fold-note' }, opt.note) : null);
    const wrap = h('div', { class: 'fold' + (isOpen ? ' open' : '') }, h('div', { class: 'fold-h' }, btn, opt.right || null), h('div', { class: 'fold-b' }, inner));
    btn.addEventListener('click', () => {
      isOpen = !isOpen; if (isOpen) build();
      wrap.classList.toggle('open', isOpen); btn.setAttribute('aria-expanded', String(isOpen));
      openSec.set(key, isOpen);
    });
    return wrap;
  }
  const glRow = (label, value, onclick, tip) => h('button', { class: 'gl-row', onclick, 'data-tip': tip || null },
    h('span', { class: 'gl-l' }, label), value != null ? h('span', { class: 'gl-v' }, value) : null, icon('chev', 12, 'currentColor', 2.2));

  // ---------- tab Video
  function renderVideoTab() {
    const it = findSel();
    const vsel = sel && it && (sel.type === 'zoom' || sel.type === 'fx' || isSeg(sel.type) || (sel.type === 'sclip' && (it.kind === 'image' || it.kind === 'video')) || (sel.type === 'track' && it.type === 'overlay'));
    if (!vsel) {
      const rows = [];
      rows.push(glRow('Sottotitoli', proj.settings.showSubs ? 'Visibili' : 'Nascosti', () => select({ type: 'subs', id: 'subs' }), 'Stile dei sottotitoli'));
      ovTracks().forEach((t) => rows.push(glRow(t.name, t.clips.length + (t.clips.length === 1 ? ' immagine' : ' immagini'), () => select({ type: 'track', id: t.id }))));
      // filtri e colori: due sezioni separate, chiuse finche' non le apri
      const adjs = proj.filters.filter((f) => f.type === 'adjust'), nfx = proj.filters.length - adjs.length;
      B.append(
        fold('v.filters', 'Filtri', () => fxTiles((id) => addFilter(id)), { note: nfx ? String(nfx) : null, tip: 'Clic su un filtro per aggiungerlo dalla testina' }),
        fold('v.color', 'Regola colori', () => [
          h('button', { class: 'btn sm primary', style: { margin: '4px 0 10px' }, onclick: () => addFilter('adjust') }, icon('plus', 13, '#fff', 2.4), 'Aggiungi regolazione colori'),
          adjs.length ? h('div', { class: 'gl' }, ...adjs.map((f) => glRow('Regola colori', `${fmt(f.a)} → ${fmt(f.b)}`, () => { select({ type: 'fx', id: f.id }); seek(f.a + 0.05); }))) : null],
        { note: adjs.length ? String(adjs.length) : null, tip: 'Luminosità, contrasto, saturazione… su un tratto del video, dalla testina. Per una sola clip, selezionala.' }),
        rows.length ? fold('v.layers', 'Livelli', h('div', { class: 'gl' }, ...rows)) : null);
      return;
    }
    if (sel.type === 'fx') return renderFxProps(it);
    if (sel.type === 'subs') { tab = 'text'; return renderPanel(); }
    if (sel.type === 'zoom' && VERT) {
      const custom = it.kind === 'custom';
      B.append(head(custom ? 'Zoom personalizzato' : 'Zoom sulla webcam', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, custom ? '#8B93FF' : '#22C3EE', true, ibtn('trash', 'Elimina questo zoom', deleteSel, { size: 15 })),
        vFrameFold(it), zoomTime(it), zoomCurve(it));
    } else if (sel.type === 'zoom' && it.kind === 'custom') {
      const lvl = W / customRect(W, H, it.rect)[2];
      B.append(head('Zoom personalizzato', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, '#8B93FF', true, ibtn('trash', 'Elimina questo zoom', deleteSel, { size: 15 })),
        fold('z.frame', 'Inquadratura', [
          h('button', { class: 'btn sm' + (framing ? '' : ' primary'), onclick: () => { framing = !framing; if (framing) seekQuiet(Math.min(it.b - 0.1, it.a + 0.6)); renderPanel(); frame(true); } },
            icon('frame', 14), framing ? 'Chiudi inquadratura' : 'Scegli cosa inquadrare'),
          h('div', { class: 'pgroup' }, numRow('Ingrandimento', () => +(W / customRect(W, H, it.rect)[2]).toFixed(1), (v) => {
            const [x, y, w, hh] = customRect(W, H, it.rect), cx = x + w / 2, cy = y + hh / 2, nw = W / v;
            it.rect = customRect(W, H, [cx - nw / 2, cy - nw * H / W / 2, nw]).slice(0, 3).map(Math.round);
          }, 1.1, 4, 0.1, '×', 2))], { note: lvl.toFixed(1).replace('.', ',') + '×' }),
        zoomTime(it), zoomCurve(it));
    } else if (sel.type === 'zoom') {
      B.append(head('Zoom sulla webcam', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, '#22C3EE', true, ibtn('trash', 'Elimina questo zoom', deleteSel, { size: 15 })),
        fold('z.level', 'Zoom', h('div', { class: 'pgroup' }, numRow('Ingrandimento', () => it.level || 2.8, (v) => { it.level = Math.round(v * 10) / 10; }, 1.1, 4, 0.1, '×', 2.8)),
          { note: (it.level || 2.8).toFixed(1).replace('.', ',') + '×' }),
        zoomTime(it), zoomCurve(it));
    } else if (isSeg(sel.type)) {
      const i = proj.segs.indexOf(it);
      const acts = h('div', { class: 'row', style: { gap: '0' } },
        i > 0 ? ibtn('mergeL', 'Unisci al pezzo a sinistra', () => mergeSeg(it, -1), { size: 15 }) : null,
        i < proj.segs.length - 1 ? ibtn('mergeR', 'Unisci al pezzo a destra', () => mergeSeg(it, 1), { size: 15 }) : null);
      B.append(head('Clip video', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${((it.b - it.a) / (it.speed || 1)).toFixed(1).replace('.', ',')} s`, it.removed ? '#7F899C' : '#3B82F6', true, acts),
        cToggle('Nel video finale', !it.removed, (v) => { it.removed = !v; }, it.removed && it.auto ? 'Pausa tagliata in automatico: qui non parlavi' : 'Spegni per togliere questo pezzo dal video'));
      if (!it.removed) {
        const sp = it.speed || 1, adjOn = it.adj && ADJ_KEYS.some(([k]) => it.adj[k]);
        const setSpeed = (v) => { it.speed = Math.abs(v - 1) < 1e-6 ? undefined : +v.toFixed(2); };
        if (VERT) B.append(clipLayoutFold(it));
        else B.append(clipTfFold(it));
        B.append(
          fold('c.speed', 'Velocità', [
            h('div', { class: 'mchips', style: { paddingLeft: 0, marginBottom: '8px' } }, ...[0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4].map((v) =>
              h('button', { class: 'pchip' + (Math.abs(sp - v) < 1e-6 ? ' on' : ''), onclick: () => { begin(); setSpeed(v); changed(); applySpeed(); } }, (v + '×').replace('.', ',')))),
            h('div', { class: 'pgroup' }, numRow('Velocità', () => it.speed || 1, (v) => { setSpeed(v); applySpeed(); }, 0.25, 4, 0.05, '×', 1))],
          { note: sp === 1 ? 'Normale' : (sp + '×').replace('.', ',') }),
          fold('c.fx', 'Filtri', () => [
            it.fx ? h('div', { class: 'pgroup', style: { marginBottom: '8px' } }, numRow('Intensità', () => it.fx.k ?? 100, (v) => { it.fx.k = Math.round(v); }, 0, 100, 1, '%', FX_DEFAULT_K[it.fx.type] || 100)) : null,
            it.fx ? h('button', { class: 'btn sm', style: { marginBottom: '12px' }, onclick: () => { begin(); it.fx = undefined; changed(); } }, 'Togli il filtro') : null,
            fxTiles((id) => { begin(); it.fx = { type: id, k: (it.fx && it.fx.type === id ? it.fx.k : FX_DEFAULT_K[id]) || 100 }; changed(); }, it.fx ? it.fx.type : null)],
          { note: it.fx ? fxName(it.fx.type) : null }),
          fold('c.color', 'Regola colori', () => {
            it.adj = it.adj || {};
            return [h('div', { class: 'pgroup' }, ...ADJ_KEYS.map(([k, label]) => numRow(label, () => it.adj[k] || 0, (v) => { it.adj[k] = Math.round(v); }, -100, 100, 1, '', 0))),
              h('div', { class: 'row', style: { justifyContent: 'space-between', marginTop: '10px' } },
                h('span'),
                h('button', { class: 'btn sm', disabled: adjOn ? null : true, onclick: () => { begin(); it.adj = {}; changed(); } }, 'Azzera'))];
          }, { note: adjOn ? 'Modificato' : null }),
          h('div', { class: 'clipacts' },
            h('button', { class: 'btn sm', 'data-tip': 'Taglia la clip nel punto della testina', onclick: () => splitSeg() }, icon('scissors', 13), 'Dividi'),
            h('button', { class: 'btn sm', 'data-tip': 'Toglie la clip e avvicina quelle dopo', onclick: () => deleteMany([{ type: sel.type, id: it.id }], true) }, icon('trash', 13), 'Elimina')));
      }
    } else if (sel.type === 'sclip') {
      if (it.kind === 'video') renderOvVideoProps(it); else renderImageProps(it);
    } else if (sel.type === 'track') {
      const name = h('input', { class: 'input', value: it.name, 'aria-label': 'Nome traccia', style: { height: '32px' } });
      name.addEventListener('change', () => { begin(); it.name = name.value.trim() || it.name; changed(); });
      const n = it.clips.length;
      B.append(head('Traccia · ' + it.name, n + (n === 1 ? ' immagine' : ' immagini'), it.color, true, ibtn('trash', 'Elimina la traccia', async () => { if (await confirmBox('Eliminare la traccia?', 'Spariscono tutte le immagini di questa traccia.', 'Elimina', true)) deleteSel(); }, { size: 15 })),
        cToggle('Visibile nel video', !it.hidden, (v) => { it.hidden = !v; }),
        renameFold(it));
    }
  }

  // ---------- immagini: proprieta', 3D e keyframe
  const KF_EPS = 0.04;
  const clipT = (c) => Math.max(0, Math.min(c.dur, video.currentTime - c.a));
  const kfAt = (c, tr) => (c.kf || []).find((k) => Math.abs(k.t - tr) < KF_EPS);
  // cambia una proprieta': senza keyframe vale per tutta la clip, con i keyframe crea/aggiorna quello alla testina
  function setProps(c, patch) {
    if (!c.kf || !c.kf.length) {
      const p = { ...(c.pos || { x: 0.35, y: 0.35, w: 0.3 }) };
      for (const [k, v] of Object.entries(patch)) {
        if (k === 'x' || k === 'y' || k === 'w') p[k] = +(+v).toFixed(4);
        else if (k === 'op') c.opacity = v; else c[k] = +(+v).toFixed(3);
      }
      c.pos = p;
      return;
    }
    const tr = +clipT(c).toFixed(3);
    let k = kfAt(c, tr);
    if (!k) { k = { t: tr, ease: 'smooth', ...imgStateAt(c, tr) }; c.kf.push(k); c.kf.sort((a, b) => a.t - b.t); }
    for (const [kk, v] of Object.entries(patch)) k[kk] = +(+v).toFixed(4);
  }
  function toggleKf(c) {
    begin();
    const tr = +clipT(c).toFixed(3);
    const k = kfAt(c, tr);
    if (k) {
      c.kf = c.kf.filter((x) => x !== k);
      if (!c.kf.length) { const s0 = imgStateAt({ ...c, kf: [k] }, 0); c.kf = []; setProps(c, s0); }
    } else {
      c.kf = c.kf || [];
      if (!c.kf.length && tr > KF_EPS) c.kf.push({ t: 0, ease: 'smooth', ...imgStateAt(c, 0) });
      c.kf.push({ t: tr, ease: 'smooth', ...imgStateAt(c, tr) });
      c.kf.sort((a, b) => a.t - b.t);
    }
    changed();
  }
  function jumpKf(c, dir) {
    const tr = clipT(c);
    const ts = (c.kf || []).map((k) => k.t).sort((a, b) => a - b);
    const t = dir > 0 ? ts.find((x) => x > tr + KF_EPS) : ts.reverse().find((x) => x < tr - KF_EPS);
    if (t !== undefined) { seek(c.a + t + 0.001); renderPanel(); }
  }
  // riga proprieta': nome · barra · valore scrivibile (segue la testina se ci sono keyframe)
  function kRow(c, label, key, min, max, step, unit, toV = (x) => x, fromV = (x) => x, reset = 0) {
    const get = () => fromV(imgStateAt(c, clipT(c))[key]);
    const dec = step < 1 ? 1 : 0;
    const show = (v) => (+v).toFixed(dec).replace('.', ',');
    const r = h('input', { type: 'range', min, max, step, value: get(), 'aria-label': label });
    const num = h('input', { class: 'num', value: show(get()), 'aria-label': label + ' (scrivi un valore)', inputmode: 'decimal' });
    let started = false;
    const apply = (v, commit) => {
      setProps(c, { [key]: toV(v) }); dirty = true; scheduleSave(); placeOverlays(video.currentTime);
      if (commit) { renderTimeline(); renderPanel(); }
    };
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } apply(+r.value); num.value = show(r.value); });
    r.addEventListener('change', () => { started = false; renderTimeline(); renderPanel(); });
    r.addEventListener('dblclick', () => { begin(); apply(reset, true); });
    const commitNum = () => {
      const v = parseFloat(String(num.value).replace(',', '.').replace(/[^0-9.+-]/g, ''));
      if (!isFinite(v)) { num.value = show(get()); return; }
      begin(); apply(v, true);
    };
    num.addEventListener('change', commitNum);
    num.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { num.blur(); return; }
      if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        e.preventDefault();
        const k = (e.key === 'ArrowUp' ? 1 : -1) * (e.shiftKey ? 10 : 1) * step;
        const v = +(get() + k).toFixed(3); num.value = show(v); begin(); apply(v, false); r.value = v;
      }
    });
    num.addEventListener('focus', () => num.select());
    liveCtls.push(() => { const v = get(); if (document.activeElement !== r) r.value = v; if (document.activeElement !== num) num.value = show(v); });
    return h('div', { class: 'prow' }, h('span', { class: 'pl', 'data-tip': 'Doppio clic sulla barra per azzerare' }, label), r, h('label', { class: 'pv' }, num, unit ? h('span', null, unit) : null));
  }
  let imgSub = 'base';
  // video in sovrimpressione: posizione, dimensione, trasparenza e audio (niente 3D/keyframe)
  function renderOvVideoProps(it) {
    const tr = trackOfClip(it.id);
    const ar = it.ar || 9 / 16;
    B.append(head(it.name.length > 26 ? it.name.slice(0, 24) + '…' : it.name, `${tr.name} · ${fmt(it.a, 1)} → ${fmt(it.a + it.dur, 1)}`, tr.color, true, ibtn('trash', 'Elimina questo video', deleteSel, { size: 15 })));
    const place = (w, x, y) => { begin(); it.pos = { x: +x.toFixed(4), y: +y.toFixed(4), w: +w.toFixed(4) }; changed(); placeOverlays(video.currentTime); renderPanel(); };
    const fit = () => { const w = Math.min(1, (1 / CA()) / ar); place(w, (1 - w) / 2, (1 - w * CA() * ar) / 2); };
    const fill = () => { const w = Math.max(1, (1 / CA()) / ar); place(w, (1 - w) / 2, (1 - w * CA() * ar) / 2); };
    const pip = () => { const w = 0.3, hf = w * CA() * ar; place(w, 1 - w - 0.03, 1 - hf - 0.04); };
    const p = it.pos || { x: 0, y: 0, w: 1 };
    B.append(
      fold('ov.pos', 'Posizione e dimensione', [
        h('div', { class: 'mchips' },
          h('button', { class: 'pchip', onclick: fit }, 'Adatta allo schermo'),
          h('button', { class: 'pchip', onclick: fill }, 'Riempi lo schermo'),
          h('button', { class: 'pchip', onclick: pip }, 'Riquadro in basso')),
        h('div', { class: 'pgroup' },
          numRow('Dimensione', () => Math.round((it.pos || p).w * 100), (v) => { const q = it.pos || p, nw = v / 100, cx = q.x + q.w / 2, cy = q.y + q.w * CA() * ar / 2; it.pos = { w: +nw.toFixed(4), x: +(cx - nw / 2).toFixed(4), y: +(cy - nw * CA() * ar / 2).toFixed(4) }; placeOverlays(video.currentTime); }, 5, 300, 1, '%', 100),
          numRow('Opacità', () => it.opacity ?? 100, (v) => { it.opacity = Math.round(v); placeOverlays(video.currentTime); }, 0, 100, 1, '%', 100))],
      { note: Math.round(p.w * 100) + '%' }),
      fold('ov.audio', 'Audio', it.hasAudio ? [cAudio(it, 'Muta l\'audio di questo video'), cFades(it)] : h('div', { class: 'kfhint' }, 'Questo video non ha audio'),
        { note: !it.hasAudio ? 'Nessuno' : it.mute ? 'Muto' : (it.vol ?? 100) + '%' }));
  }
  function renderImageProps(it) {
    const tr = trackOfClip(it.id);
    const ar = it.ar || 9 / 16;
    const subs = it.isText ? ['text', 'base', 'anim'] : ['base', 'anim'];
    if (!subs.includes(imgSub)) imgSub = subs[0];
    const isBadge = !!(it.isText && it.text && it.text.badge);
    B.append(head(it.name.length > 26 ? it.name.slice(0, 24) + '…' : it.name, `${tr.name} · ${fmt(it.a, 1)} → ${fmt(it.a + it.dur, 1)}`, tr.color, true, ibtn('trash', isBadge ? 'Elimina questo badge' : it.isText ? 'Elimina questo testo' : 'Elimina questa immagine', deleteSel, { size: 15 })),
      seg(it.isText ? [isBadge ? 'Badge' : 'Testo', 'Base', 'Animazione'] : ['Base', 'Animazione'], subs.indexOf(imgSub), (i) => { imgSub = subs[i]; renderPanel(); }, 'subtabs'));
    if (imgSub === 'anim') return renderImageAnim(it);
    if (imgSub === 'text') return (isBadge ? badgeBody(it) : textStyleBody(it)).forEach((x) => x && panelBody.append(x));

    // keyframe: striscia con la durata della clip, rombi e testina
    const onKf = kfAt(it, clipT(it));
    const strip = h('div', { class: 'kfs-track', 'data-tip': 'Clic per spostarti nella clip' });
    for (const k of it.kf || []) {
      const d = h('i', { class: 'kfs-d' + (Math.abs(k.t - clipT(it)) < KF_EPS ? ' on' : ''), style: { left: (k.t / it.dur * 100) + '%' } });
      d.addEventListener('pointerdown', (e) => { e.stopPropagation(); seek(it.a + k.t + 0.001); renderPanel(); });
      strip.append(d);
    }
    const ph = h('i', { class: 'kfs-ph' });
    strip.append(ph);
    strip.addEventListener('pointerdown', (e) => { const r = strip.getBoundingClientRect(); seek(it.a + Math.max(0, Math.min(it.dur - 0.01, (e.clientX - r.left) / r.width * it.dur))); renderPanel(); });
    liveCtls.push(() => { ph.style.left = (clipT(it) / it.dur * 100) + '%'; });
    liveCtls.push(() => { if (!!kfAt(it, clipT(it)) !== !!onKf && !document.activeElement?.matches?.('input')) renderPanel(); });
    const kfBtn = h('button', { class: 'kfbtn' + (onKf ? ' on' : ''), 'data-tip': onKf ? 'Togli questo keyframe' : 'Aggiungi un keyframe qui', 'aria-label': 'Keyframe', onclick: () => toggleKf(it) }, icon('diamond', 13, 'currentColor', 2));
    B.append(h('div', { class: 'kfbox' },
      h('div', { class: 'kfrow' },
        ibtn('left', 'Keyframe precedente', () => jumpKf(it, -1), { size: 13 }), kfBtn, ibtn('chev', 'Keyframe successivo', () => jumpKf(it, 1), { size: 13 }),
        strip),
      onKf && (it.kf || []).length > 1 ? h('div', { class: 'kfease' }, h('span', null, 'Verso il prossimo'),
        seg(['Lineare', 'Morbido'], onKf.ease === 'linear' ? 0 : 1, (i) => { begin(); onKf.ease = i ? 'smooth' : 'linear'; changed(); }, 'mini')) : null,
      null));
    const sizeTo = (v) => {
      const s0 = imgStateAt(it, clipT(it)), nw = v / 100, hf0 = s0.w * CA() * ar, hf1 = nw * CA() * ar;
      setProps(it, { x: s0.x + (s0.w - nw) / 2, y: s0.y + (hf0 - hf1) / 2 });
      return nw;
    };
    B.append(
      fold('img.tr', 'Trasformazione',
        h('div', { class: 'pgroup' },
          kRow(it, 'Posizione X', 'x', -50, 150, 0.5, '%', (v) => v / 100, (x) => x * 100, 35),
          kRow(it, 'Posizione Y', 'y', -50, 150, 0.5, '%', (v) => v / 100, (x) => x * 100, 35),
          kRow(it, 'Dimensione', 'w', 5, 150, 1, '%', sizeTo, (x) => x * 100, 30),
          kRow(it, 'Rotazione', 'rot', -180, 180, 1, '°'),
          kRow(it, 'Opacità', 'op', 0, 100, 1, '%', undefined, undefined, 100)), { open: true }),
      fold('img.3d', '3D',
        h('div', { class: 'pgroup' },
          kRow(it, 'Orizzontale', 'ry', -75, 75, 1, '°'),
          kRow(it, 'Verticale', 'rx', -75, 75, 1, '°'),
          kRow(it, 'Profondità', 'z', -100, 60, 1, '', (v) => v / 100, (x) => x * 100)),
        { right: ibtn('restore', 'Togli l\'effetto 3D', () => { begin(); setProps(it, { rx: 0, ry: 0, z: 0 }); changed(); }, { size: 14 }) }),
      fold('img.al', 'Allinea',
        h('div', { class: 'aligngrid' },
          ...[[0, 0, 'In alto a sinistra'], [0.5, 0, 'In alto al centro'], [1, 0, 'In alto a destra'],
            [0, 0.5, 'A sinistra'], [0.5, 0.5, 'Al centro'], [1, 0.5, 'A destra'],
            [0, 1, 'In basso a sinistra'], [0.5, 1, 'In basso al centro'], [1, 1, 'In basso a destra']].map(([fx, fy, tip]) =>
            h('button', { class: 'alignbtn', 'data-tip': tip, 'aria-label': tip, onclick: () => {
              begin();
              const s0 = imgStateAt(it, clipT(it)), hf = s0.w * CA() * ar, m = 0.03;
              const x = fx === 0.5 ? (1 - s0.w) / 2 : (fx ? 1 - s0.w - m : m), y = fy === 0.5 ? (1 - hf) / 2 : (fy ? 1 - hf - m * CA() : m * CA());
              setProps(it, { x, y });
              changed(); seekQuiet(Math.max(it.a, Math.min(it.a + it.dur - 0.05, video.currentTime)));
            } }, h('i', { style: { left: (4 + fx * 12) + 'px', top: (4 + fy * 8) + 'px' } }))))));
  }

  // ---------- immagini: animazioni pronte, con anteprima animata al passaggio del mouse
  function renderImageAnim(it) {
    const an = it.anim || {};
    const kinds = [['motion', 'Movimento'], ['in', 'Entrata'], ['out', 'Uscita'], ['loop', 'Continua']];
    const nameOf = (k, t) => (ANIMS[k].find(([id]) => id === t) || [0, ''])[1];
    for (const [kind, label] of kinds) B.append(fold('an.' + kind, label, () => animBody(it, kind), { open: kind === 'motion' ? !!an.motion || !!(proj.story) : kind === 'in' && !an.in && !an.out && !an.loop && !an.motion, note: an[kind] ? nameOf(kind, an[kind]) : null }));
    B.append(h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, onclick: () => { seek(it.a); if (video.paused) togglePlay(); } }, icon('play', 11, 'currentColor'), 'Guarda'));
  }
  function animBody(it, animSub) {
    const out = [];
    const cur = (it.anim || {})[animSub] || null;
    const setAnim = (patch) => { begin(); it.anim = { ...(it.anim || {}), ...patch }; if (!it.anim.in && !it.anim.out && !it.anim.loop && !it.anim.motion) delete it.anim; changed(); };
    const tiles = [['', 'Nessuna'], ...ANIMS[animSub]].map(([type, label]) => {
      const box = h('i', { class: 'demo-box' });
      const tile = h('button', { class: 'atile' + ((cur || '') === type ? ' on' : ''), 'aria-label': label, onclick: () => {
        const patch = { [animSub]: type || null };
        if (type && animSub === 'in' && !it.anim?.inDur) patch.inDur = 0.5;
        if (type && animSub === 'out' && !it.anim?.outDur) patch.outDur = 0.5;
        setAnim(patch);
      } }, h('span', { class: 'demo' }, box), h('span', { class: 'al' }, label));
      let raf = 0, t0 = 0;
      const demo = { id: 'demo', dur: 1.6, ar: 0.62, pos: { x: 0.3, y: 0.19, w: 0.4 }, anim: {} };
      const paint = (tr) => {
        const s0 = imgFinal(demo, tr, 16 / 10);
        Object.assign(box.style, { left: s0.x * 100 + '%', top: s0.y * 100 + '%', width: s0.w * 100 + '%', opacity: String(Math.max(0, Math.min(1, s0.op / 100))), transform: imgCss(s0, 64) });
      };
      if (type) {
        demo.anim = { [animSub]: type, inDur: 0.6, outDur: 0.6 };
        if (animSub === 'out') demo.dur = 0.6;
        if (animSub === 'loop') demo.dur = 1000;
        if (animSub === 'motion') demo.dur = 2.4;
        const loopT = () => {
          const el = (performance.now() - t0) / 1000;
          const tr = animSub === 'motion' ? el % 2.4 : animSub === 'in' ? Math.min(el % 1.4, 0.6) + (el % 1.4 > 0.6 ? 0.01 : 0) : animSub === 'out' ? Math.min(0.6, el % 1.3) : el;
          paint(Math.min(demo.dur, tr)); raf = requestAnimationFrame(loopT);
        };
        tile.addEventListener('mouseenter', () => { t0 = performance.now(); cancelAnimationFrame(raf); loopT(); });
        tile.addEventListener('mouseleave', () => { cancelAnimationFrame(raf); paint(animSub === 'out' ? 0 : animSub === 'loop' ? 0 : demo.dur); });
      }
      paint(animSub === 'out' || animSub === 'loop' ? 0 : demo.dur);
      if (!type) box.classList.add('none');
      return tile;
    });
    out.push(h('div', { class: 'atiles' }, ...tiles));
    if (cur && animSub !== 'loop') {
      const key = animSub === 'in' ? 'inDur' : 'outDur';
      out.push(h('div', { class: 'pgroup' }, numRow('Durata', () => it.anim[key] || 0.5, (v) => { it.anim[key] = Math.round(v * 10) / 10; }, 0.2, Math.max(0.3, Math.min(3, it.dur)), 0.1, 's', 0.5)));
    }
    return out;
  }

  // ---------- tab Testo: testi, sottotitoli, trascrizione
  function renderTextTab() {
    const it = findSel();
    if (sel && sel.type === 'sclip' && it && it.isText) return renderImageProps(it);
    if (sel && sel.type === 'sub' && it) {
      B.append(head('Frase dei sottotitoli', `${fmt(it.a, 1)} → ${fmt(it.b, 1)}` + (it.hidden ? ' · nascosta' : ''), '#8EB4FF', true),
        h('div', { class: 'subq' + (it.hidden ? ' hid' : '') }, it.text),
        h('div', { class: 'row', style: { gap: '6px', margin: '10px 0 14px' } },
          h('button', { class: 'btn sm', onclick: () => fixSub(it) }, icon('type', 13), 'Correggi il testo'),
          h('button', { class: 'btn sm', onclick: () => { setNoSub(it.a, it.b, !it.hidden); sel = null; renderPanel(); } }, icon(it.hidden ? 'eye' : 'eyeOff', 13), it.hidden ? 'Mostra' : 'Nascondi')));
    }
    const texts = [];
    ovTracks().forEach((t) => t.clips.forEach((c) => { if (c.isText) texts.push(c); }));
    texts.sort((a, b) => a.a - b.a);
    const on = !!proj.settings.showSubs;
    const trDone = proj.transcript && proj.transcript.status === 'done';
    B.append(
      fold('t.texts', 'Testi', [
        h('button', { class: 'btn sm primary addtext', onclick: () => addText() }, icon('plus', 13, '#fff', 2.4), 'Aggiungi testo'),
        texts.length ? h('div', { class: 'gl' }, ...texts.map((c) => glRow(c.name || 'Testo', fmt(c.a), () => { select({ type: 'sclip', id: c.id }); seek(c.a + 0.05); }))) : null],
      { open: true, note: texts.length ? String(texts.length) : null }),
      fold('t.badges', 'Badge social', () => [
        h('div', { class: 'bdg-add' }, ...PLATFORMS.map(([id, name]) => h('button', { class: 'bdg-p' + (id === 'custom' ? ' own' : ''), onclick: () => addBadge(id),
          'data-tip': id === 'custom' ? 'Un badge con il tuo logo: scegli l\'immagine dal PC' : null }, platIcon(id), h('span', null, name))))],
      { note: (() => { const n = texts.filter((c) => c.text && c.text.badge).length; return n ? String(n) : null; })(), tip: 'Una targhetta col tuo nome sulla piattaforma: la metti dove vuoi e la personalizzi' }),
      fold('t.subs', 'Sottotitoli', () => (allWords().length ? subStyleBody() : subsStatus('panel')), {
        open: !allWords().length,
        note: !allWords().length ? (trStatus() === 'running' ? 'In preparazione' : 'Da creare') : on ? null : 'Nascosti',
        right: allWords().length ? ibtn(on ? 'eye' : 'eyeOff', on ? 'Nascondi i sottotitoli (anche nel video finale)' : 'Mostra i sottotitoli', () => toggleSubs(), { size: 15, color: on ? 'currentColor' : '#FF7B72' }) : null }),
      fold('t.tr', 'Trascrizione', () => { const box = h('div', { class: 'trbox' }); renderTranscript(box); return box; }, { open: !trDone }));
  }
  function addText() {
    begin();
    const t = Math.max(0, Math.min(D - 0.5, video.currentTime)), dur = Math.min(4, D - t);
    let tr = ovTracks().find((x) => !x.clips.some((c) => c.a < t + dur && c.a + c.dur > t));
    if (!tr) tr = newTrack('overlay');
    const c = { id: uid('c'), kind: 'image', isText: true, text: { ...TEXT_DEFAULT, content: tx(TEXT_DEFAULT.content) }, name: tx('Testo'), file: '', a: +t.toFixed(2), dur: +dur.toFixed(2), opacity: 100 };
    const cv = drawText(c.text, H);
    c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
    c.pos = { w: +c.natW.toFixed(5), x: +((1 - c.natW) / 2).toFixed(5), y: +((1 - c.natW * CA() * c.ar) / 2).toFixed(5) };
    tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
    refreshText(c);
    sel = { type: 'sclip', id: c.id }; tab = 'text'; imgSub = 'text';
    changed();
    seekQuiet(c.a + 0.05);
    setTimeout(() => { const ta = panelBody.querySelector('textarea.tcontent'); if (ta) { ta.focus(); ta.select(); } }, 60);
  }
  // badge social: nome e logo di ogni piattaforma restano ricordati per i prossimi progetti
  let badgeMem = null;
  async function loadBadgeMem() {
    if (badgeMem) return badgeMem;
    try { badgeMem = (await get('/api/env')).badges || {}; } catch (e) { badgeMem = {}; }
    return badgeMem;
  }
  loadBadgeMem();
  function rememberBadge(b) {
    if (!badgeMem) return;
    badgeMem[b.platform] = { handle: b.handle || '', logo: b.logo || '' };
    post('/api/settings', { badges: badgeMem }).catch(() => {});
  }
  const platIcon = (id) => (id === 'custom' ? h('i', { class: 'bdg-plus' }, icon('plus', 14, 'currentColor', 2.2))
    : h('img', { src: logoUrl(id, 'free'), alt: '', class: id === 'kick' ? 'wide' : null }));
  async function pickImagePath() {
    try {
      const r = await post('/api/pick', { kind: 'relink-image' });
      let path = r.path;
      if (r.fallback) path = prompt('Percorso completo dell\'immagine:', '') || '';
      return path || '';
    } catch (e) { toast('Non riesco ad aprire l\'immagine'); return ''; }
  }
  function addBadge(pid) {
    begin();
    const t = Math.max(0, Math.min(D - 0.5, video.currentTime)), dur = Math.min(5, D - t);
    let tr = ovTracks().find((x) => !x.clips.some((c) => c.a < t + dur && c.a + c.dur > t));
    if (!tr) tr = newTrack('overlay');
    const mem = (badgeMem || {})[pid] || {};
    const badge = { ...BADGE_DEFAULT, platform: pid, label: tx(badgeLabel(pid)), handle: mem.handle || 'iltuonome', logo: mem.logo || '' };
    const c = { id: uid('c'), kind: 'image', isText: true, text: { ...TEXT_DEFAULT, size: VERT ? 0.04 : 0.05, shadow: true, badge }, name: '', file: '', a: +t.toFixed(2), dur: +dur.toFixed(2), opacity: 100,
      anim: VERT ? { in: 'pop', inDur: 0.5, out: 'fade', outDur: 0.4 } : { in: 'slideL', inDur: 0.6, out: 'slideL', outDur: 0.5 } };
    const cv = drawText(c.text, H, logoFor(c));
    c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
    const hh = c.natW * CA() * c.ar;
    c.pos = VERT ? { w: +c.natW.toFixed(5), x: +((1 - c.natW) / 2).toFixed(5), y: +(0.6 - hh / 2).toFixed(5) }
      : { w: +c.natW.toFixed(5), x: 0.035, y: +(0.93 - hh).toFixed(5) };
    tr.clips.push(c); tr.clips.sort((x, y) => x.a - y.a);
    refreshText(c);
    sel = { type: 'sclip', id: c.id }; tab = 'text'; imgSub = 'text';
    changed();
    seekQuiet(c.a + 0.8);
    // badge personalizzato: si sceglie subito il logo
    if (pid === 'custom' && !badge.logo) pickImagePath().then((path) => { if (!path) return; begin(); c.text.badge.logo = path; rememberBadge(c.text.badge); refreshText(c); changed(); });
  }
  function badgeBody(c) {
    const t = c.text, b = t.badge = { ...BADGE_DEFAULT, ...(t.badge || {}) };
    const p = platformOf(b.platform);
    const redraw = () => { refreshText(c); placeOverlays(video.currentTime); };
    const setB = (patch, remember) => { begin(); Object.assign(b, patch); refreshText(c); if (remember) rememberBadge(b); changed(); };
    const setT = (patch) => { begin(); Object.assign(t, patch); refreshText(c); changed(); };
    const field = (label, key, ph, remember) => {
      const inp = h('input', { class: 'input', value: b[key] || '', placeholder: ph, 'aria-label': label, spellcheck: 'false', style: { height: '32px' } });
      let typing = false, tmr = 0;
      inp.addEventListener('input', () => { if (!typing) { begin(); typing = true; } b[key] = inp.value; clearTimeout(tmr); tmr = setTimeout(() => { redraw(); dirty = true; scheduleSave(); }, 80); });
      inp.addEventListener('blur', () => { if (typing) { typing = false; redraw(); if (remember) rememberBadge(b); changed(); } });
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') inp.blur(); });
      return h('div', { class: 'ctl' }, h('label', { class: 'lbl' }, label), inp);
    };
    // piattaforma: cambiandola cambia anche la scritta sopra (se era quella proposta) e il nome ricordato
    const plats = h('div', { class: 'bdg-add small' }, ...PLATFORMS.map(([id, name]) => h('button', { class: 'bdg-p' + (id === b.platform ? ' on' : ''), onclick: () => {
      if (id === b.platform) return;
      const mem = (badgeMem || {})[id] || {};
      const patch = { platform: id, accent: '' };
      if (!b.label || b.label === tx(badgeLabel(b.platform))) patch.label = tx(badgeLabel(id));
      patch.logo = mem.logo || '';
      if (mem.handle) patch.handle = mem.handle;
      setB(patch);
    } }, platIcon(id), h('span', null, name))));
    // stili: anteprima vera del badge in ogni riquadro
    const styles = h('div', { class: 'bdg-styles' }, ...BADGE_STYLES.map(([id, name]) => {
      const cv = drawBadge({ ...t, size: 0.05, badge: { ...b, style: id } }, 400, logoFor(c));
      cv.className = 'bdg-cv';
      return h('button', { class: 'bdg-st' + (b.style === id ? ' on' : ''), 'data-tip': name, 'aria-label': name, onclick: () => setB({ style: id }) }, h('span', { class: 'bdg-stage' }, cv), h('span', { class: 'al' }, name));
    }));
    const pickLogo = async () => { const path = await pickImagePath(); if (path) setB({ logo: path }, true); };
    const own = b.platform === 'custom';
    const logoName = b.logo ? b.logo.split(/[\\/]/).pop() : '';
    for (const k of ['bd.text', 'bd.style']) if (!openSec.has(k)) openSec.set(k, true);
    if (b.platform === 'custom' && !b.logo) openSec.set('bd.logo', true);   // la prima volta: nome e stile gia' aperti
    return [
      fold('bd.plat', 'Piattaforma', plats, { open: true, note: p[1] }),
      fold('bd.text', 'Scritte', [field('Nome', 'handle', 'iltuonome', true), field('Scritta sopra', 'label', 'Niente (solo il nome)'),
        ], { open: true, note: b.handle }),
      fold('bd.style', 'Stile', styles, { open: true, note: (BADGE_STYLES.find(([id]) => id === b.style) || BADGE_STYLES[0])[1] }),
      fold('bd.color', 'Colore', [sRow('Colore', swatches(b.accent || p[2], (col) => setB({ accent: col }))),
        b.accent ? h('button', { class: 'btn sm ghost', style: { marginTop: '6px' }, onclick: () => setB({ accent: '' }) }, 'Colore di ' + p[1]) : null],
      { note: b.accent ? 'Personalizzato' : p[1] }),
      fold('bd.logo', 'Logo', [
        h('div', { class: 'row', style: { gap: '6px', flexWrap: 'wrap' } },
          h('button', { class: 'btn sm' + (own && !b.logo ? ' primary' : ''), onclick: pickLogo }, icon('upload', 13), b.logo ? 'Cambia immagine' : own ? 'Scegli il tuo logo' : 'Usa un\'immagine tua'),
          b.logo ? h('button', { class: 'btn sm ghost', onclick: () => setB({ logo: '' }, true) }, own ? 'Togli il logo' : 'Logo di ' + p[1]) : null),
        b.logo ? h('div', { class: 'kfhint', 'data-notr': '' }, logoName) : null,
        ],
      { note: b.logo ? 'Immagine tua' : own ? 'Da scegliere' : p[1] }),
      fold('bd.font', 'Carattere', [
        h('div', { class: 'row', style: { gap: '6px' } },
          fontPicker(t.font, (v) => setT({ font: v })),
          h('button', { class: 'tbtn', 'aria-pressed': String(!!t.bold), 'data-tip': 'Grassetto', onclick: () => setT({ bold: !t.bold }) }, h('b', null, 'B')),
          h('button', { class: 'tbtn', 'aria-pressed': String(!!t.upper), 'data-tip': 'Nome tutto maiuscolo', onclick: () => setT({ upper: !t.upper }) }, 'AA')),
        h('div', { class: 'pgroup' }, numRow('Dimensione', () => Math.round(t.size * 1080), (v) => { t.size = v / 1080; refreshText(c); }, 12, 200, 1, 'px', 54))],
      { note: t.font }),
      h('div', { class: 'fold-h solo' }, h('span', { class: 'fold-t static' }, h('span', null, 'Ombra')), toggle(!!t.shadow, (v) => setT({ shadow: v }), 'Ombra')),
    ];
  }
  function textStyleBody(c) {
    const t = c.text = { ...TEXT_DEFAULT, ...(c.text || {}) };
    const setT = (patch) => { begin(); Object.assign(t, patch); refreshText(c); changed(); };
    // contenuto: si aggiorna mentre scrivi
    const ta = h('textarea', { class: 'input tcontent', rows: '3', 'aria-label': 'Testo', spellcheck: 'false' });
    ta.value = t.content;
    let typing = false, tmr = 0;
    ta.addEventListener('input', () => {
      if (!typing) { begin(); typing = true; }
      t.content = ta.value;
      clearTimeout(tmr); tmr = setTimeout(() => { refreshText(c); dirty = true; scheduleSave(); }, 90);
    });
    ta.addEventListener('blur', () => { if (typing) { typing = false; refreshText(c); changed({ keepPanel: true }); } });
    const presets = h('div', { class: 'sub-presets' }, ...TEXT_PRESETS.map(([name, p]) => {
      const ps = { ...t, ...p };
      const sample = h('span', { class: 'pv' }, 'Aa');
      Object.assign(sample.style, {
        fontFamily: `"${ps.font}", Arial, sans-serif`, fontWeight: ps.bold ? '700' : '400', fontStyle: ps.italic ? 'italic' : 'normal', color: ps.color,
        textTransform: ps.upper ? 'uppercase' : 'none', textShadow: textShadowFor({ ...ps, strokeW: ps.strokeW || 0.08 }, 16),
        background: ps.box ? hexA(ps.boxColor, (ps.boxOp ?? 80) / 100) : 'transparent', padding: ps.box ? '1px 7px' : '0', borderRadius: ps.box ? '6px' : '0', fontSize: '18px',
      });
      const same = Object.entries(p).every(([k, v]) => t[k] === v);
      return h('button', { class: 'sp' + (same ? ' on' : ''), 'data-tip': name, 'aria-label': name, onclick: () => setT({ ...p }) }, sample);
    }));
    const font = fontPicker(t.font, (v) => setT({ font: v }));
    const tb = (label, key, tip, style) => h('button', { class: 'tbtn', 'aria-pressed': String(!!t[key]), 'data-tip': tip, onclick: () => setT({ [key]: !t[key] }) }, style ? h(style, null, label) : label);
    const aligns = ['left', 'center', 'right'];
    return [
      ta,
      fold('tx.style', 'Stili pronti', presets, { open: true }),
      fold('tx.font', 'Carattere', [
        h('div', { class: 'row', style: { gap: '6px' } }, font, tb('B', 'bold', 'Grassetto', 'b'), tb('I', 'italic', 'Corsivo', 'i'), tb('AA', 'upper', 'Tutto maiuscolo')),
        h('div', { class: 'pgroup' }, numRow('Dimensione', () => Math.round(t.size * 1080), (v) => { t.size = v / 1080; refreshText(c); }, 12, 300, 1, 'px', 86)),
        seg(['Sinistra', 'Centro', 'Destra'], Math.max(0, aligns.indexOf(t.align)), (i) => setT({ align: aligns[i] }), 'mini wide'),
        sRow('Colore', swatches(t.color, (col) => setT({ color: col })))], { open: true, note: t.font }),
      fold('tx.stroke', 'Contorno', [
        sRow('Colore', swatches(t.strokeColor, (col) => setT({ strokeColor: col }))),
        h('div', { class: 'pgroup' }, numRow('Spessore', () => Math.round(t.strokeW * 100), (v) => { t.strokeW = v / 100; refreshText(c); }, 1, 30, 1, '%', 8))],
      { right: toggle(!!t.stroke, (v) => setT({ stroke: v }), 'Contorno') }),
      fold('tx.box', 'Sfondo', [
        sRow('Colore', swatches(t.boxColor, (col) => setT({ boxColor: col }))),
        h('div', { class: 'pgroup' },
          numRow('Opacità', () => t.boxOp ?? 80, (v) => { t.boxOp = Math.round(v); refreshText(c); }, 5, 100, 1, '%', 80),
          numRow('Angoli', () => Math.round((t.boxR ?? 0.25) * 100), (v) => { t.boxR = v / 100; refreshText(c); }, 0, 100, 1, '%', 25))],
      { right: toggle(!!t.box, (v) => setT({ box: v }), 'Sfondo') }),
      h('div', { class: 'fold-h solo' }, h('span', { class: 'fold-t static' }, h('span', null, 'Ombra')), toggle(!!t.shadow, (v) => setT({ shadow: v }), 'Ombra')),
    ];
  }

  // ---------- sottotitoli: stile
  const SUB_PRESETS = [
    ['Classico', { font: 'Arial', bold: true, upper: false, color: '#FFFFFF', stroke: false, box: true, boxColor: '#000000', boxOp: 70, shadow: false, effect: 'none' }],
    ['Contorno', { font: 'Arial', bold: true, upper: false, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: false, effect: 'none' }],
    ['Giallo', { font: 'Arial', bold: true, upper: false, color: '#FFD60A', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: true, effect: 'none' }],
    ['Karaoke', { font: 'Arial', bold: true, upper: true, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.12, box: false, shadow: false, effect: 'highlight', hiColor: '#3DDC84' }],
    ['Pop', { font: 'Impact', bold: false, upper: true, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: true, effect: 'pop' }],
    ['Minimal', { font: 'Segoe UI', bold: true, upper: false, color: '#FFFFFF', stroke: false, box: false, shadow: true, effect: 'none' }],
  ];
  const FONTS = ['Arial', 'Impact', 'Segoe UI', 'Verdana', 'Trebuchet MS', 'Tahoma', 'Georgia', 'Comic Sans MS'];
  const SWATCHES = ['#FFFFFF', '#FFD60A', '#3DDC84', '#4FC3F7', '#FF5A5F', '#FF7AD9', '#000000'];
  function subSet(patch, rerender = true) { begin(); Object.assign(proj.subStyle, patch); applySubStyle(); if (rerender) changed(); else { ver++; dirty = true; scheduleSave(); } }
  function sSlider(label, key, min, max, step, fmtV) {
    const st = proj.subStyle;
    const val = h('span', { class: 'val' }, fmtV(st[key]));
    const r = h('input', { type: 'range', min, max, step, value: st[key], 'aria-label': label });
    let started = false;
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } st[key] = +r.value; val.textContent = fmtV(+r.value); applySubStyle(); ver++; dirty = true; scheduleSave(); });
    r.addEventListener('change', () => { started = false; renderTimeline(); });
    return h('div', { class: 'ctl' }, h('div', { class: 'top' }, h('label', null, label), val), r);
  }
  function swatches(cur, onPick) {
    const custom = h('input', { type: 'color', value: cur, 'aria-label': 'Altro colore' });
    custom.addEventListener('change', () => onPick(custom.value.toUpperCase()));
    const known = SWATCHES.includes((cur || '').toUpperCase());
    return h('div', { class: 'swatches' },
      ...SWATCHES.map((c) => h('button', { class: 'sw' + (c === (cur || '').toUpperCase() ? ' on' : ''), style: { background: c }, 'aria-label': c, onclick: () => onPick(c) })),
      h('label', { class: 'sw custom' + (known ? '' : ' on'), style: known ? {} : { background: cur }, 'data-tip': 'Altro colore' }, known ? icon('plus', 12, 'currentColor', 2.4) : null, custom));
  }
  function sRow(label, control) { return h('div', { class: 'srow' }, h('span', null, label), control); }
  function subStyleBody() {
    const st = proj.subStyle;
    // stili pronti
    const presets = h('div', { class: 'sub-presets' }, ...SUB_PRESETS.map(([name, p]) => {
      const ps = { ...st, ...p };
      const sample = h('span', { class: 'pv' + (p.effect === 'pop' ? ' big' : '') }, ...(p.effect === 'highlight' ? [h('b', { style: { color: p.hiColor } }, 'Aa'), ' bb'] : ['Aa bb']));
      Object.assign(sample.style, {
        fontFamily: `"${ps.font}", Arial, sans-serif`, fontWeight: ps.bold ? '700' : '400', color: ps.color, textTransform: ps.upper ? 'uppercase' : 'none',
        textShadow: textShadowFor(ps, 16),
        background: ps.box ? hexA(ps.boxColor, ps.boxOp / 100) : 'transparent', padding: ps.box ? '1px 5px' : '0',
      });
      const same = Object.entries(p).every(([k, v]) => st[k] === v);
      return h('button', { class: 'sp' + (same ? ' on' : ''), 'data-tip': name, 'aria-label': name, onclick: () => subSet({ ...p }) }, sample);
    }));
    const font = fontPicker(st.font, (v) => subSet({ font: v }));
    const eff = { none: 'Nessuno', highlight: 'Parola', pop: 'Pop' };
    return [fold('s.style', 'Stili pronti', presets, { open: true }),
      fold('s.text', 'Carattere', [
        h('div', { class: 'row', style: { gap: '6px' } }, font,
          h('button', { class: 'tbtn', 'aria-pressed': String(!!st.bold), 'data-tip': 'Grassetto', onclick: () => subSet({ bold: !st.bold }) }, h('b', null, 'B')),
          h('button', { class: 'tbtn', 'aria-pressed': String(!!st.upper), 'data-tip': 'Tutto maiuscolo', onclick: () => subSet({ upper: !st.upper }) }, 'AA')),
        sSlider('Dimensione', 'size', 0.03, 0.12, 0.001, (v) => Math.round(v * 1080) + ' px'),
        sRow('Colore', swatches(st.color, (c) => subSet({ color: c })))], { note: st.font }),
      fold('s.stroke', 'Contorno', [
        sRow('Colore', swatches(st.strokeColor, (c) => subSet({ strokeColor: c }))),
        sSlider('Spessore', 'strokeW', 0.02, 0.25, 0.005, (v) => Math.round(v * 100) + '%')], { right: toggle(!!st.stroke, (v) => subSet({ stroke: v }), 'Contorno') }),
      fold('s.box', 'Sfondo', [
        sRow('Colore', swatches(st.boxColor, (c) => subSet({ boxColor: c }))),
        sSlider('Opacità', 'boxOp', 10, 100, 5, (v) => Math.round(v) + '%')], { right: toggle(!!st.box, (v) => subSet({ box: v }), 'Sfondo') }),
      h('div', { class: 'fold-h solo' }, h('span', { class: 'fold-t static' }, h('span', null, 'Ombra')), toggle(!!st.shadow, (v) => subSet({ shadow: v }), 'Ombra')),
      fold('s.fx', 'Effetto', [
        seg(['Nessuno', 'Parola', 'Pop'], st.effect === 'highlight' ? 1 : st.effect === 'pop' ? 2 : 0, (i) => subSet({ effect: ['none', 'highlight', 'pop'][i] })),
        st.effect === 'highlight' ? sRow('Parola detta', swatches(st.hiColor, (c) => subSet({ hiColor: c }))) : null], { note: eff[st.effect] || 'Nessuno' }),
      fold('s.pos', 'Posizione', [
        seg(['Alto', 'Centro', 'Basso'], st.y < 0.4 ? 0 : st.y < 0.75 ? 1 : 2, (i) => subSet({ y: [0.2, 0.62, 0.92][i] })),
        sSlider('Altezza', 'y', 0.12, 0.99, 0.005, (v) => Math.round((1 - v) * 100) + '%')]),
      fold('s.words', 'Parole per riga', seg(['Poche', 'Medie', 'Tante'], st.maxChars <= 20 ? 0 : st.maxChars <= 30 ? 1 : 2, (i) => subSet({ maxChars: [18, 28, 38][i] })),
        { note: st.maxChars <= 20 ? 'Poche' : st.maxChars <= 30 ? 'Medie' : 'Tante' })];
  }

  // ---------- filtri
  const FX_DEFAULT_K = { blur: 50, pixel: 45, glow: 60, vignette: 70, grain: 55, glitch: 55, vhs: 80 };
  function numRow(label, get, set, min, max, step, unit, reset) {
    const dec = step < 1 ? 1 : 0, show = (v) => (+v).toFixed(dec).replace('.', ',');
    const r = h('input', { type: 'range', min, max, step, value: get(), 'aria-label': label });
    const num = h('input', { class: 'num', value: show(get()), 'aria-label': label + ' (scrivi un valore)', inputmode: 'decimal' });
    let started = false;
    const apply = (v, commit) => { set(Math.max(min, Math.min(max, v))); fxDirty = true; dirty = true; scheduleSave(); if (commit) changed(); };
    r.addEventListener('input', () => { if (!started) { begin(); started = true; } apply(+r.value); num.value = show(r.value); });
    r.addEventListener('change', () => { started = false; renderTimeline(); });
    if (reset !== undefined) r.addEventListener('dblclick', () => { begin(); apply(reset, true); });
    num.addEventListener('change', () => { const v = parseFloat(String(num.value).replace(',', '.')); if (!isFinite(v)) { num.value = show(get()); return; } begin(); apply(v, true); });
    num.addEventListener('keydown', (e) => { if (e.key === 'Enter') num.blur(); });
    num.addEventListener('focus', () => num.select());
    return h('div', { class: 'prow' }, h('span', { class: 'pl', title: label }, label), r, h('label', { class: 'pv' }, num, unit ? h('span', null, unit) : null));
  }
  // riquadri dei filtri con l'anteprima sul fotogramma attuale
  function fxTiles(onPick, cur, noAdj) {
    const group = (kind, title) => h('div', { class: 'fxgroup' }, h('div', { class: 'fxg-t' }, title),
      h('div', { class: 'fxtiles' }, ...FX_LIST.filter((f) => f.kind === kind).map((f) => {
        const cv = h('canvas', { width: '112', height: String(Math.round(112 * H / W)) });
        const tile = h('button', { class: 'fxtile' + (cur === f.id ? ' on' : ''), 'aria-label': f.name, onclick: () => onPick(f.id) }, cv, h('span', null, f.name));
        requestAnimationFrame(() => { loadLooks().then(() => { try { fxr.thumb(video.el || video, f.id, cv); } catch (e) { /* */ } }); });
        return tile;
      })));
    return h('div', { class: 'fxpick' }, group('look', 'Look'), group('fx', 'Effetti'));
  }
  function adjustTrack(fresh) {
    let t = !fresh && proj.fxTracks.find((x) => x.kind === 'adjust');
    if (!t) {
      const n = proj.fxTracks.filter((x) => x.kind === 'adjust').length;
      t = { id: uid('ft'), name: n ? 'Colori ' + (n + 1) : 'Colori', kind: 'adjust' };
      proj.fxTracks.push(t); proj.layers = normLayers();
    }
    return t.id;
  }
  function addFilter(type, freshTrack) {
    begin();
    const t = Math.min(D - 0.5, video.currentTime);
    let track = curFxTrack();
    const tk = (proj.fxTracks.find((x) => x.id === track) || {}).kind;
    if (type === 'adjust' && (freshTrack || tk !== 'adjust')) track = adjustTrack(freshTrack);
    else if (type !== 'adjust' && tk === 'adjust') track = 'fx';
    const f = { id: uid('f'), track, type, a: +t.toFixed(2), b: +Math.min(D, t + 10).toFixed(2), k: FX_DEFAULT_K[type] || 100,
      mask: { type: 'all', x: 0.3, y: 0.3, w: 0.4, h: 0.4, feather: 0.15, invert: false, strokes: [] } };
    proj.filters.push(f);
    sel = { type: 'fx', id: f.id }; tab = 'video'; fxSub = 'filter';
    changed();
  }
  function renderFxProps(f) {
    const inside = video.currentTime >= f.a && video.currentTime < f.b;
    B.append(head(fxName(f.type), `${fmt(f.a, 1)} → ${fmt(f.b, 1)} · ${(f.b - f.a).toFixed(1).replace('.', ',')} s`, '#38BDF8', true,
      h('div', { class: 'row', style: { gap: '0' } },
        ibtn(f.off ? 'eyeOff' : 'eye', f.off ? 'Riattiva il filtro' : 'Spegni il filtro (resta sulla timeline)', () => { begin(); f.off = !f.off; changed(); }, { size: 15, color: f.off ? '#FF7B72' : 'currentColor' }),
        ibtn('trash', 'Elimina il filtro', deleteSel, { size: 15 }))),
      seg(['Filtro', 'Maschera'], fxSub === 'mask' ? 1 : 0, (i) => { fxSub = i ? 'mask' : 'filter'; if (i && !inside) seekQuiet(f.a + 0.05); renderPanel(); }, 'subtabs'));
    if (fxSub !== 'mask' && f.type === 'adjust') {
      f.adj = f.adj || {};
      const any = ADJ_KEYS.some(([k]) => f.adj[k]);
      B.append(fold('fx.adj', 'Colori', [h('div', { class: 'pgroup' }, ...ADJ_KEYS.map(([k, label]) => numRow(label, () => f.adj[k] || 0, (v) => { f.adj[k] = Math.round(v); }, -100, 100, 1, '', 0))),
        h('div', { class: 'row', style: { justifyContent: 'space-between', marginTop: '8px' } },
          h('span'),
          h('button', { class: 'btn sm', disabled: any ? null : true, onclick: () => { begin(); f.adj = {}; changed(); } }, 'Azzera tutto'))], { open: true, note: any ? 'Modificato' : null }));
      return;
    }
    if (fxSub !== 'mask') {
      B.append(fold('fx.k', 'Regolazioni', h('div', { class: 'pgroup' }, numRow('Intensità', () => f.k ?? 100, (v) => { f.k = Math.round(v); }, 0, 100, 1, '%', FX_DEFAULT_K[f.type] || 100)), { open: true }),
        fold('fx.pick', 'Cambia filtro', () => fxTiles((id) => { begin(); f.type = id; changed(); }, f.type), { note: fxName(f.type) }));
      return;
    }
    const m = f.mask = f.mask || { type: 'all' };
    const types = ['all', 'rect', 'ellipse', 'brush'];
    B.append(seg(['Tutto', 'Rettangolo', 'Ellisse', 'Pennello'], Math.max(0, types.indexOf(m.type || 'all')), (i) => {
      begin(); m.type = types[i];
      if (m.type !== 'all' && m.w === undefined) Object.assign(m, { x: 0.3, y: 0.3, w: 0.4, h: 0.4, feather: 0.15 });
      m.strokes = m.strokes || [];
      if (!inside) seekQuiet(f.a + 0.05);
      changed();
    }, 'mini wide'));
    if (m.type === 'all' || !m.type) { B.append(h('div', { class: 'kfhint' }, 'Il filtro vale su tutto il video. Scegli una forma o il pennello per applicarlo solo a una parte.')); return; }
    if (m.type === 'brush') {
      B.append(fold('m.brush', 'Pennello', [h('div', { class: 'row', style: { gap: '6px' } },
        seg(['Pennello', 'Gomma'], brushMode === 'erase' ? 1 : 0, (i) => { brushMode = i ? 'erase' : 'paint'; renderPanel(); }, 'mini'),
        h('div', { class: 'grow' }),
        h('button', { class: 'btn sm', disabled: (m.strokes || []).length ? null : true, onclick: () => { begin(); m.strokes = []; changed(); } }, 'Cancella tutto')),
      h('div', { class: 'pgroup' }, numRow('Dimensione', () => Math.round(brushR * 1000) / 10, (v) => { brushR = v / 100; }, 0.5, 20, 0.5, '%'))], { open: true, note: brushMode === 'erase' ? 'Gomma' : null }));
    }
    B.append(fold('m.edge', 'Bordi', [h('div', { class: 'pgroup' }, numRow('Sfumatura', () => Math.round((m.feather ?? 0.15) * 100), (v) => { m.feather = v / 100; }, 0, 100, 1, '%', 15)),
      cToggle('Inverti', !!m.invert, (v) => { m.invert = v; }, 'Applica il filtro fuori dalla forma invece che dentro')], { note: m.invert ? 'Invertita' : null }),
      h('div', { class: 'kfhint' }, !inside ? 'Porta la testina dentro il filtro per vedere la maschera.' :
        m.type === 'brush' ? 'Dipingi sull\'anteprima dove vuoi il filtro. In rosso la zona coperta.' : 'Sposta e ridimensiona la forma nell\'anteprima. In rosso la zona coperta.'));
  }

  // verticale: dove finisce lo zoom (un riquadro 9:16 sulla live), per ogni zoom
  function vFrameFold(it) {
    const own = !!it.vrect;
    const toggleFraming = () => { framing = !framing; if (framing) seekQuiet(Math.min(it.b - 0.1, it.a + 0.6)); renderPanel(); frame(true); };
    const size = () => { const r = vBoxOf(it); return r ? Math.round(r[3] / H * 100) : 100; };
    return fold('z.vframe', 'Inquadratura', [
      h('div', { class: 'kfhint', style: { margin: '0 0 10px' } }, own ? 'Scelta a mano per questo zoom.' : 'Automatica: ' + (it.kind === 'custom' ? 'il centro della zona scelta.' : 'la webcam al centro.')),
      h('div', { class: 'row', style: { gap: '6px', flexWrap: 'wrap' } },
        h('button', { class: 'btn sm' + (framing ? '' : ' primary'), onclick: toggleFraming }, icon('frame', 14), framing ? 'Fatto' : 'Sposta l\'inquadratura'),
        own ? h('button', { class: 'btn sm ghost', onclick: () => { begin(); delete it.vrect; changed(); frame(true); } }, 'Automatica') : null),
      h('div', { class: 'pgroup', style: { marginTop: '10px' } }, numRow('Dimensione', size, (v) => {
        const r = vBoxOf(it); if (!r) return;
        const a = zA(it), nh = H * v / 100, nw = nh * a, cx = r[0] + r[2] / 2, cy = r[1] + r[3] / 2;
        it.vrect = vertRect(W, H, [cx - nw / 2, cy - nh / 2, nw], a).slice(0, 3).map(Math.round); frame(true);
      }, 15, 100, 1, '%')),
      framing ? h('div', { class: 'kfhint' }, 'Trascina il riquadro sull\'anteprima: è quello che si vede alla fine dello zoom.') : null],
    { note: own ? 'A mano' : 'Automatica' });
  }
  // durata dello zoom (e da quando parte), scritta a mano o con la barra
  function zoomTime(it) {
    const len = it.b - it.a;
    return fold('z.time', 'Durata', h('div', { class: 'pgroup' },
      numRow('Durata', () => +(it.b - it.a).toFixed(1), (v) => { it.b = +Math.min(D, it.a + v).toFixed(2); }, 0.8, Math.max(1, Math.min(60, D - it.a)), 0.1, 's', 4),
      numRow('Inizio', () => +it.a.toFixed(1), (v) => { const l = it.b - it.a; it.a = +Math.max(0, Math.min(D - l, v)).toFixed(2); it.b = +(it.a + l).toFixed(2); }, 0, Math.max(0, D - len), 0.1, 's')),
    { note: len.toFixed(1).replace('.', ',') + ' s' });
  }
  // effetti dello zoom: riquadri con l'anteprima animata (passa sopra col mouse), come le animazioni delle immagini
  // in verticale gli effetti sono a parte (la webcam che si allarga a tutto schermo), di base non a scatto
  const zKey = (kind) => (VERT ? (kind === 'in' ? 'vin' : 'vout') : kind);
  const zCur = (it, kind) => it[zKey(kind)] || (VERT ? 'fast' : (kind === 'in' ? 'snap' : 'cut'));
  // curva dell'effetto (quanto e' ingrandito nel tempo): cosi' ogni riquadro si riconosce anche da fermo
  const SVGNS = 'http://www.w3.org/2000/svg';
  const svgEl = (tag, attrs) => { const e = document.createElementNS(SVGNS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
  function zoomFxTiles(it, kind) {
    const list = kind === 'in' ? ZOOM_IN_FX : ZOOM_OUT_FX, cur = zCur(it, kind);
    const LOOP = 2.6, CW_ = 64, CH_ = 38;
    return h('div', { class: 'atiles' + (VERT ? ' v' : '') }, ...list.map(([type, label]) => {
      const fake = kind === 'in' ? { a: 0, b: 2.0, in: type, out: 'cut' } : { a: 0, b: 1.8, in: 'snap', out: type };
      // p nel tempo del giro (el da 0 a LOOP)
      const pAt = (el) => (kind === 'in' ? (el < 0.3 ? 0 : zoomProgress(el - 0.3, fake)) : (el + 0.3 < fake.b ? zoomProgress(el + 0.3, fake) : 0));
      const X = (el) => 3 + (el / LOOP) * (CW_ - 6), Y = (p) => CH_ - 5 - Math.max(-0.05, Math.min(1.25, p)) * (CH_ - 14);
      let d = '';
      for (let i = 0; i <= 90; i++) { const el = (i / 90) * LOOP; d += (i ? 'L' : 'M') + X(el).toFixed(1) + ' ' + Y(pAt(el)).toFixed(1); }
      const svg = svgEl('svg', { class: 'zf-curve', viewBox: `0 0 ${CW_} ${CH_}`, width: CW_, height: CH_ });
      svg.append(svgEl('line', { x1: 3, x2: CW_ - 3, y1: Y(0), y2: Y(0), class: 'zc-base' }), svgEl('line', { x1: 3, x2: CW_ - 3, y1: Y(1), y2: Y(1), class: 'zc-top' }),
        svgEl('path', { d, class: 'zc-line' }));
      const dot = svgEl('circle', { r: 2.6, class: 'zc-dot', cx: X(0), cy: Y(pAt(0)) });
      svg.append(dot);
      const cam0 = h('b', { class: 'zf-cam' });
      const scene = VERT ? h('i', { class: 'zf-vscene' }, h('b', { class: 'zf-vgame' }), cam0) : h('i', { class: 'zf-scene' }, cam0);
      const tile = h('button', { class: 'atile' + (cur === type ? ' on' : ''), 'aria-label': label, onclick: () => { begin(); it[zKey(kind)] = type; changed(); } },
        h('span', { class: 'demo zf' + (VERT ? ' v' : '') }, scene, svg), h('span', { class: 'al' }, label));
      const Z = 2.4;
      const paint = (p) => {
        if (VERT) { const q = Math.max(0, p); cam0.style.height = (40 + 60 * Math.min(1.08, q)).toFixed(1) + '%'; return; }
        scene.style.transform = `scale(${Math.pow(Z, p).toFixed(4)})`;
      };
      let raf = 0, t0 = 0;
      const loopT = () => {
        const el = ((performance.now() - t0) / 1000) % LOOP, p = pAt(el);
        paint(p); dot.setAttribute('cx', X(el).toFixed(1)); dot.setAttribute('cy', Y(p).toFixed(1));
        raf = requestAnimationFrame(loopT);
      };
      const rest = () => { const el = kind === 'in' ? LOOP * 0.75 : 0; paint(VERT ? 0 : pAt(el)); dot.setAttribute('cx', X(el).toFixed(1)); dot.setAttribute('cy', Y(pAt(el)).toFixed(1)); };
      tile.addEventListener('mouseenter', () => { t0 = performance.now(); cancelAnimationFrame(raf); tile.classList.add('play'); loopT(); });
      tile.addEventListener('mouseleave', () => { cancelAnimationFrame(raf); tile.classList.remove('play'); rest(); });
      rest();
      return tile;
    }));
  }
  function zoomCurve(it) {
    const nm = (list, v) => (list.find(([id]) => id === v) || list[0])[1];
    const zt = it.track || 'zoom', same = proj.zooms.filter((z) => (z.track || 'zoom') === zt && z !== it);
    return fold('z.curve', 'Effetto', [
      h('div', { class: 'zf-lbl' }, 'Entrata'), zoomFxTiles(it, 'in'),
      h('div', { class: 'zf-lbl' }, 'Uscita'), zoomFxTiles(it, 'out'),
      same.length ? h('button', { class: 'btn sm', style: { marginTop: '12px' }, onclick: () => {
        begin(); same.forEach((z) => { z[zKey('in')] = zCur(it, 'in'); z[zKey('out')] = zCur(it, 'out'); }); changed();
        toast(`Effetto applicato a ${same.length + 1} zoom della traccia`);
      } }, icon('duplicate', 13), `Applica a tutti gli zoom della traccia (${same.length + 1})`) : null,
      ],
    { note: nm(ZOOM_IN_FX, zCur(it, 'in')) + ' · ' + nm(ZOOM_OUT_FX, zCur(it, 'out')) });
  }
  const renameFold = (it) => {
    const name = h('input', { class: 'input', value: it.name, 'aria-label': 'Nome traccia', style: { height: '32px' } });
    name.addEventListener('change', () => { begin(); it.name = name.value.trim() || it.name; changed(); });
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') name.blur(); });
    return fold('t.name', 'Nome', name, { note: it.name });
  };
  const fadeNote = (it) => (it.fin && it.fout ? 'Entrata e uscita' : it.fin ? 'Entrata' : it.fout ? 'Uscita' : 'Nessuna');

  // ---------- tab Audio
  function renderAudioTab() {
    const it = findSel();
    const asel = sel && it && (isSeg(sel.type) || (sel.type === 'sclip' && it.kind !== 'image') || (sel.type === 'track' && it.type !== 'overlay'));
    if (!asel) return renderMixer();
    if (isSeg(sel.type)) {
      B.append(head('Audio del pezzo', `${fmt(it.a, 1)} → ${fmt(it.b, 1)} · ${(it.b - it.a).toFixed(1).replace('.', ',')} s`, '#3B82F6', true));
      if (it.removed) { B.append(emptyTab('scissors', 'Pezzo tolto', 'Questo pezzo non è nel video finale, quindi neanche il suo audio')); return; }
      B.append(fold('a.vol', 'Volume', cAudio(it, 'Silenzia l\'audio di questo pezzo (il video resta)'), { open: true, note: it.mute ? 'Muto' : it.vol + '%' }),
        fold('a.fade', 'Dissolvenze', cFades(it), { note: fadeNote(it) }));
    } else if (sel.type === 'sclip') {
      const tr = trackOfClip(it.id);
      B.append(head(it.name, `${tr.name} · ${fmt(it.a, 1)} → ${fmt(it.a + it.dur, 1)}`, tr.color, true, ibtn('trash', 'Elimina questo suono', deleteSel, { size: 15 })),
        fold('a.vol', 'Volume', [cAudio(it, 'Muta questo suono'),
          cToggle('Si abbassa quando parli', !!it.duck, (v) => { it.duck = v; }, 'Utile per la musica di sottofondo')], { open: true, note: it.mute ? 'Muto' : it.vol + '%' }),
        fold('a.fade', 'Dissolvenze', cFades(it), { note: fadeNote(it) }));
    } else {
      const isLive = it.type === 'live';
      const np = isLive ? proj.segs.length : it.clips.length;
      B.append(head('Traccia · ' + it.name, np + (np === 1 ? ' parte' : ' parti'), isLive ? '#3B82F6' : it.color, true,
        isLive ? null : ibtn('trash', 'Elimina la traccia', async () => { if (await confirmBox('Eliminare la traccia?', 'Spariscono tutti i suoni di questa traccia.', 'Elimina', true)) deleteSel(); }, { size: 15 })),
        fold('a.vol', 'Volume', cAudio(it, 'Muta tutta la traccia'), { open: true, note: it.mute ? 'Muto' : it.vol + '%' }));
      if (!isLive) B.append(renameFold(it));
    }
  }
  // tutte le tracce audio in un colpo d'occhio
  function renderMixer() {
    const tracks = [liveTrack(), ...soundTracks()];
    const rows = tracks.map((t) => {
      const val = h('span', { class: 'val' }, t.vol + '%');
      const r = h('input', { type: 'range', min: 0, max: 200, step: 5, value: t.vol, 'aria-label': 'Volume ' + t.name, disabled: t.mute ? true : null });
      let started = false;
      r.addEventListener('input', () => { if (!started) { begin(); started = true; } t.vol = +r.value; val.textContent = t.vol + '%'; dirty = true; scheduleSave(); renderTimeline(); });
      r.addEventListener('change', () => { started = false; });
      return h('div', { class: 'mx-row' },
        h('div', { class: 'mx-top' },
          h('span', { class: 'dot', style: { background: t.type === 'live' ? '#3B82F6' : t.color } }),
          h('button', { class: 'mx-nm', 'data-tip': 'Opzioni della traccia', onclick: () => select({ type: 'track', id: t.id }) }, t.name),
          ibtn(t.mute ? 'mute' : 'speaker', t.mute ? 'Riattiva la traccia' : 'Muta la traccia', () => { begin(); t.mute = !t.mute; changed(); }, { color: t.mute ? '#FF7B72' : 'currentColor', size: 15 })),
        h('div', { class: 'mx-bot' }, r, val));
    });
    const hasSounds = soundTracks().some((t) => t.clips.length);
    B.append(fold('mx.tracks', 'Tracce audio', h('div', { class: 'gl mx' }, ...rows), { open: true, note: String(tracks.length) }),
      hasSounds ? fold('mx.duck', 'Musica', cToggle('Abbassa la musica quando parli', proj.settings.duck, (v) => { proj.settings.duck = v; }, 'Vale per i suoni con "Si abbassa quando parli"'),
        { note: proj.settings.duck ? 'Si abbassa' : null }) : null);
  }

  // nome del video: e' anche il nome del file esportato
  function nameField() {
    const inp = h('input', { class: 'input', value: proj.name, 'aria-label': 'Nome del video', maxlength: '120', style: { height: '32px', width: '100%' } });
    inp.addEventListener('change', () => { const v = inp.value.trim(); if (!v) { inp.value = proj.name; return; } begin(); proj.name = v; changed({ keepPanel: true }); document.title = v + ' · VODcut'; const cc = document.querySelector('.crumb-cur span[data-notr]'); if (cc) cc.textContent = v; });
    inp.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') inp.blur(); });
    return h('div', { class: 'ctl', 'data-tip': 'Il video esportato avrà questo nome' }, h('label', { class: 'lbl' }, 'Nome del video'), inp);
  }
  let acPlay = null;
  // salta al prossimo zoom / taglio dopo la testina (poi ricomincia dall'inizio)
  function jumpNext(kind) {
    const items = kind === 'zoom' ? proj.zooms.map((z) => z.a) : proj.segs.filter((c) => c.removed).map((c) => c.a);
    if (!items.length) return;
    items.sort((x, y) => x - y);
    const t = video.currentTime;
    const n = items.find((x) => x > t + 0.3);
    seek((n === undefined ? items[0] : n) + (kind === 'zoom' ? 0.6 : 0));
  }
  // formato del video finale: orizzontale o verticale (con cosa si vede nel verticale)
  const SUB_V = { size: 0.034, y: 0.74, maxChars: 22 }, SUB_H = { size: 0.055, y: 0.92, maxChars: 38 };
  function setFormat(v) {
    if (v === VERT) return;
    begin();
    const oldK = VERT ? 'subStyle_9x16' : 'subStyle_16x9', newK = v ? 'subStyle_9x16' : 'subStyle_16x9';
    const st = proj.subStyle;
    proj[oldK] = { size: st.size, y: st.y, maxChars: st.maxChars };
    proj.subStyle = { ...st, ...(proj[newK] || (v ? SUB_V : SUB_H)) };
    proj.format = v ? '9:16' : '16:9';
    VERT = v; lastSV = null;
    arrangeLayers(); applyViewMode(); subCur = null; applySubStyle();
    changed(); frame(true);
  }
  const LAYOUTS = [
    ['split', 'Diviso', 'Webcam e gioco: la webcam sopra, il gioco sotto'],
    ['fit', 'Intero', 'Tutto il video al centro, sopra lo stesso video sfocato'],
    ['game', 'Gioco', 'Solo il gioco, a tutto schermo'],
    ['cam', 'Webcam', 'Solo la webcam, a tutto schermo'],
    ['free', 'Libero', 'Tutto il video e la webcam da spostare e ingrandire come vuoi (trascinali nell\'anteprima)']];
  // impaginazione verticale di una clip: si cambia solo lei, finche' non la usi per tutte
  function layoutTiles(cur, onPick) {
    return h('div', { class: 'vlay' }, ...LAYOUTS.map(([k, name, tip]) => {
      const off = (k === 'split' || k === 'cam') && !cam;
      return h('button', { class: 'vlay-t' + (cur === k ? ' on' : ''), disabled: off ? true : null, 'data-tip': off ? 'Serve la webcam: impostala in Progetto, in Modifiche automatiche' : tip,
        onclick: () => onPick(k) }, h('i', { class: 'vlay-pic ' + k }, h('b'), h('b'), h('u')), h('span', null, name));
    }));
  }
  // orizzontale: la clip spostata e ingrandita a mano (si fa anche trascinandola nell'anteprima)
  function clipTfFold(c) {
    const tf = tfOf(c), on = !!c.tf;
    const upd = (patch) => { const t2 = { ...tfOf(c), ...patch }; c.tf = t2; if (Math.abs(t2.s - 1) < 1e-3 && Math.abs(t2.x) < 1e-3 && Math.abs(t2.y) < 1e-3) delete c.tf; tfKey = ''; frame(true); };
    return fold('c.tf', 'Posizione e zoom', [
      h('div', { class: 'pgroup' },
        numRow('Zoom', () => Math.round(tfOf(c).s * 100), (v) => upd({ s: v / 100 }), 5, 3000, 1, '%', 100),
        numRow('Orizzontale', () => Math.round(tfOf(c).x * 100), (v) => upd({ x: v / 100 }), -1000, 1000, 1, '%', 0),
        numRow('Verticale', () => Math.round(tfOf(c).y * 100), (v) => upd({ y: v / 100 }), -1000, 1000, 1, '%', 0)),
      on ? h('button', { class: 'btn sm ghost', style: { marginTop: '8px' }, onclick: () => { begin(); delete c.tf; tfKey = ''; changed(); frame(true); } }, 'Rimetti come prima') : null],
    { note: on ? Math.round(tf.s * 100) + '%' : null, tip: 'Trascina il video nell\'anteprima per spostarlo, gli angoli (o la rotellina) per ingrandirlo' });
  }
  function clipLayoutFold(c) {
    const vs = segVert(0, c), own = !!c.vlay;
    const base = { layout: vs.layout, camH: vs.camH, gameX: vs.gameX, pad: vs.pad };
    const setC = (patch) => { begin(); c.vlay = { ...base, ...(c.vlay || {}), ...patch }; changed(); frame(true); };
    const rows = [];
    if (vs.layout === 'split') rows.push(numRow('Altezza webcam', () => Math.round(vs.camH * 100), (v) => { c.vlay = { layout: vs.layout, camH: v / 100, gameX: vs.gameX, ...(c.vlay || {}), camH: v / 100 }; frame(true); }, 20, 70, 1, '%', 40));
    if (vs.layout === 'split' || vs.layout === 'game') rows.push(numRow('Posizione gioco', () => Math.round(vs.gameX * 100), (v) => { c.vlay = { layout: vs.layout, camH: vs.camH, gameX: v / 100, ...(c.vlay || {}), gameX: v / 100 }; frame(true); }, 0, 100, 1, '%', 50));
    const others = proj.segs.filter((x) => x !== c && !x.gone).length;
    const allSame = () => {
      begin();
      proj.vert = { layout: vs.layout, camH: vs.camH, gameX: vs.gameX, pad: vs.pad, ...(vs.boxes ? { boxes: vs.boxes } : {}) };
      proj.segs.forEach((x) => { delete x.vlay; });
      changed(); frame(true);
      toast('Tutte le clip ora sono così');
    };
    const name = (LAYOUTS.find(([k]) => k === vs.layout) || LAYOUTS[0])[1];
    const hasCam = (vs.layout === 'split' || vs.layout === 'cam' || vs.layout === 'free') && cam;
    const setPad = (v) => { c.vlay = { ...base, ...(c.vlay || {}), pad: v }; frame(true); };
    const frag = document.createDocumentFragment();
    // 1) come e' impaginata la clip
    frag.append(fold('c.vlay', 'Impaginazione', [
      layoutTiles(vs.layout, (k) => setC({ layout: k })),
      rows.length ? h('div', { class: 'pgroup' }, ...rows) : null,
      (others || own) ? h('div', { class: 'fold-acts' },
        h('span', { class: 'fa-l' }, own ? 'Solo questa clip' : 'Uguale alle altre clip'),
        own ? h('button', { class: 'btn sm ghost', onclick: () => { begin(); delete c.vlay; changed(); frame(true); } }, 'Come le altre') : null,
        others ? h('button', { class: 'btn sm', onclick: allSame, 'data-tip': 'Tutte le clip prendono questa impaginazione' }, icon('duplicate', 13), 'Usa per tutte') : null) : null],
    { open: true, note: name }));
    // 2) ritocchi: barre nere, viso, pezzi spostati a mano
    frag.append(fold('c.vopt', 'Ritocchi', [
      h('div', { class: 'pgroup' },
        cToggle('Barre nere sopra e sotto', vs.pad > 0, (v) => setPad(v ? 0.1 : 0), 'Webcam e gioco verso il centro: l\'interfaccia di TikTok e Reels non li copre'),
        vs.pad > 0 ? numRow('Spessore barre', () => Math.round(vs.pad * 100), (v) => setPad(v / 100), 3, 20, 1, '%', 10) : null),
      hasCam ? h('div', { class: 'pgroup' }, faceRow()) : null,
      vs.boxes ? h('div', { class: 'fold-acts' }, h('span', { class: 'fa-l' }, 'Pezzi spostati a mano'),
        h('button', { class: 'btn sm ghost', onclick: () => { begin(); c.vlay = { ...(c.vlay || {}) }; delete c.vlay.boxes; changed(); frame(true); } }, icon('restore', 13), 'Rimetti a posto')) : null],
    { open: true, note: [vs.pad > 0 ? 'Barre' : null, hasCam && proj.faceOn ? 'Viso' : null].filter(Boolean).join(' · ') || null,
      tip: 'Webcam e gioco si trascinano e si ingrandiscono anche direttamente nell\'anteprima' }));
    return frag;
  }
  function fmtLabel() {
    const r = W / H, near = (x) => Math.abs(r - x) < 0.02;
    return near(16 / 9) ? 'Orizzontale 16:9' : near(9 / 16) ? 'Verticale 9:16' : near(1) ? 'Quadrato 1:1' : near(4 / 5) ? 'Verticale 4:5' : W + '×' + H;
  }
  // ---------------------------------------------------------------- storia con immagini
  const STORY_COLORS = ['#FFFFFF', '#FFD166', '#8FD3FF', '#FFA8B8', '#B9F5A2'];
  function wrapLine(t, n) {
    const out = []; let cur = '';
    for (const w of String(t).split(/\s+/)) { if (cur && (cur + ' ' + w).length > n) { out.push(cur); cur = w; } else cur = cur ? cur + ' ' + w : w; }
    if (cur) out.push(cur);
    return out.join('\n');
  }
  function storyColor(sp) {
    const st = proj.story; st.colors = st.colors || {};
    if (!st.colors[sp]) st.colors[sp] = STORY_COLORS[Object.keys(st.colors).length % STORY_COLORS.length];
    return st.colors[sp];
  }
  function storyText(l) {
    return { ...TEXT_DEFAULT, content: wrapLine(l.text, W < H ? 20 : 34), size: W < H ? 0.04 : 0.055, font: 'Arial', bold: true,
      color: storyColor(l.speaker || ''), stroke: true, strokeColor: '#000000', strokeW: 0.1, shadow: true, box: false };
  }
  // la prima volta: immagini e testi sulla timeline, uno per battuta
  function buildStory() {
    const st = proj.story;
    if (!st || !st.pending) return;
    const imgT = newTrack('overlay'); imgT.name = 'Immagini';
    const txtT = st.captions === 'word' ? null : newTrack('overlay'); if (txtT) txtT.name = 'Testi';
    st.lines.forEach((l, i) => {
      const dur = +Math.max(0.3, l.b - l.a).toFixed(2);
      if (l.file) {
        const ar = l.ar || 16 / 9, w = Math.max(1, 1 / (CA() * ar)), hf = w * CA() * ar;
        const c = { id: uid('c'), kind: 'image', file: l.file, name: 'IMG ' + (i + 1), a: l.a, dur, ar, opacity: 100,
          pos: { x: +((1 - w) / 2).toFixed(4), y: +((1 - hf) / 2).toFixed(4), w: +w.toFixed(4) }, anim: { motion: l.motion || 'zoomIn' } };
        imgT.clips.push(c); l.imgId = c.id;
      }
      if (l.text && st.captions !== 'word') {
        const c = { id: uid('c'), kind: 'image', isText: true, text: storyText(l), name: '', file: '', a: l.a, dur, opacity: 100, anim: { in: 'pop', inDur: 0.25 } };
        const cv = drawText(c.text, H);
        c.natW = cv.width / CW(); c.ar = cv.height / cv.width;
        const w = Math.min(c.natW, 0.9);
        c.pos = { w: +w.toFixed(5), x: +((1 - w) / 2).toFixed(5), y: +(0.72 - w * CA() * c.ar / 2).toFixed(5) };
        txtT.clips.push(c); l.txtId = c.id;
        refreshText(c);
      }
    });
    if (st.captions === 'word') {
      // didascalie parola per parola: i sottotitoli con le parole dello script, ai tempi della voce
      proj.transcript = { status: 'done', language: 'it', segments: st.lines.filter((l) => (l.words || []).length).map((l) => ({
        a: l.words[0][1], b: l.words[l.words.length - 1][2], words: l.words.map(([w, a, b]) => ({ w, a, b, del: false })) })) };
      proj.subStyle = { ...(proj.subStyle || {}), font: 'Arial', bold: true, upper: false, color: '#FFFFFF', stroke: true, strokeColor: '#000000', strokeW: 0.12,
        box: false, shadow: true, effect: 'pop', size: W < H ? 0.065 : 0.08, y: 0.72, maxChars: 1 };
      proj.settings.showSubs = true;
      proj.layers = ['subs', ...normLayers().filter((x) => x !== 'subs')];   // le parole sopra le immagini
      ver++;
    }
    st.pending = false;
    ltab = 'story';
    dirty = true; scheduleSave(); renderTimeline(); renderPanel(); frame(true);
  }
  const storyClip = (id) => { for (const t of ovTracks()) { const c = t.clips.find((x) => x.id === id); if (c) return c; } return null; };
  // tab Storia: una riga per battuta, movimento dell'immagine con un clic
  function renderStoryTab() {
    const st = proj.story;
    const t = video.currentTime;
    const list = h('div', { class: 'st-list' });
    st.lines.forEach((l, i) => {
      const ic = storyClip(l.imgId), tc = storyClip(l.txtId);
      const a = ic ? ic.a : tc ? tc.a : l.a, dur = ic ? ic.dur : tc ? tc.dur : l.b - l.a;
      const mot = ic && ic.anim && ic.anim.motion;
      const motName = (MOTIONS.find(([k]) => k === mot) || [0, 'Fermo'])[1];
      const on = t >= a && t < a + dur;
      const row = h('div', { class: 'st-row' + (on ? ' on' : ''), onclick: () => { if (ic) select({ type: 'sclip', id: ic.id }); seek(a + 0.02); } },
        h('span', { class: 'st-n' }, String(i + 1)),
        ic ? h('img', { class: 'st-img', src: mediaUrl(ic.file), alt: '', loading: 'lazy' }) : h('span', { class: 'st-img none' }, icon('upload', 16)),
        h('div', { class: 'st-tx' }, l.speaker ? h('b', { style: { color: storyColor(l.speaker) } }, l.speaker) : null, h('span', null, tc ? String(tc.text.content).replace(/\n/g, ' ') : l.text)),
        ic ? h('button', { class: 'st-mot', 'data-tip': 'Clic: cambia movimento', onclick: (e) => {
          e.stopPropagation(); begin();
          const ids = ['', ...MOTIONS.map(([k]) => k)], nx = ids[(ids.indexOf(mot || '') + 1) % ids.length];
          ic.anim = { ...(ic.anim || {}), motion: nx || undefined }; if (!nx) delete ic.anim.motion;
          if (!Object.keys(ic.anim).some((k) => ic.anim[k])) delete ic.anim;
          changed(); frame(true);
        } }, icon('sparkle', 11), motName) : null);
      list.append(row);
    });
    B.append(h('div', { class: 'vc-top' }, h('div', { class: 'vc-top-t' }, h('b', null, 'Battute'), h('span', null, String(st.lines.length))),
      h('button', { class: 'btn sm', 'data-tip': 'Movimenti diversi a ogni immagine', onclick: () => {
        begin(); let k = 0;
        st.lines.forEach((l) => { const ic = storyClip(l.imgId); if (ic) { ic.anim = { ...(ic.anim || {}), motion: MOTIONS[[0, 2, 1, 4, 3, 5][k % 6]][0] }; k++; } });
        changed(); frame(true);
      } }, icon('sparkle', 13), 'Mescola')), list);
  }
  // "Segui il viso": vale per tutta la clip verticale
  function faceRow() {
    const on = !!proj.faceOn;
    const wrap = h('div', { class: 'face-row' },
      cToggle('Segui il viso', on, (v) => {
        proj.faceOn = v; frame(true);
        if (v && !faceData) startFace();
        setTimeout(renderPanel, 0);
      }, 'Se ti sposti nella webcam, il ritaglio del verticale ti segue (senza mai uscire dal riquadro della webcam)'));
    if (on && faceJob) {
      const bar = h('div', { class: 'progress', style: { marginTop: '8px' } }, h('div')), st = h('div', { class: 'kfhint', style: { margin: '6px 0 0' } });
      const upd = () => { const p = Math.round(faceProg * 100); bar.firstChild.style.width = p + '%'; st.textContent = 'Cerco il viso nella webcam… ' + p + '%'; };
      upd(); wrap.append(bar, st);
      const tm = setInterval(() => { if (!faceJob || !st.isConnected) { clearInterval(tm); return; } upd(); }, 400);
    } else if (on && !faceData && faceErr) wrap.append(h('div', { class: 'kfhint warn', style: { margin: '6px 0 0' } }, faceErr),
      h('button', { class: 'btn sm', style: { marginTop: '6px' }, onclick: () => { startFace(); renderPanel(); } }, icon('restore', 13), 'Riprova'));
    else if (on && !faceData) wrap.append(h('button', { class: 'btn sm', style: { marginTop: '6px' }, onclick: () => { startFace(); renderPanel(); } }, icon('sparkle', 13), 'Analizza il viso'));
    return wrap;
  }
  function formatFold() {
    // il formato si sceglie quando nasce il progetto e poi resta quello
    const body = [h('div', { class: 'fmt-ro' }, h('span', { class: 'fmt-ic' + (VERT ? ' v' : '') }), h('div', null, h('b', null, VERT ? 'Verticale 9:16' : 'Orizzontale 16:9'), h('small', null, 'Il formato resta quello con cui hai iniziato il progetto.')))];
    return fold('p.format', 'Formato', body, { note: VERT ? '9:16' : '16:9' });
  }
  function renderProject() {
    const S = proj.settings;
    const set = (k) => (v) => { S[k] = v; };
    const nz = proj.zooms.length, nc = proj.segs.filter((c) => c.removed).length;
    const hasSounds = soundTracks().some((t) => t.clips.length);
    // tre qualita' a partire da quella del VOD, mai sopra
    const steps = [2160, 1440, 1080, 720, 480, 360, 240];
    const top = steps.find((s) => s <= Math.min(W, H) + 8) || Math.min(W, H);
    const qOpts = steps.filter((s) => s <= top).slice(0, 3).map((s) => ({ value: s + 'p', label: s === 2160 ? '4K' : s + 'p' }));
    const PQ = [['auto', 'Auto'], ['orig', 'Originale'], ['720', '720p'], ['480', '480p']];
    if (!qOpts.some((q) => q.value === S.quality)) S.quality = qOpts[0].value;
    const outD = outDuration(), gone = D - outD;
    const fmtGone = (x) => x < 60 ? Math.round(x) + ' s' : fmt(x);
    // mappa di tutto il VOD: pezzi tenuti, pezzi tolti, zoom (clic = vai li')
    acPlay = h('i', { class: 'ac-play' });
    const map = h('div', { class: 'ac-map', 'data-tip': 'Tutto il video: gli spazi sono le parti tolte, in giallo gli zoom · clic per andarci' },
      ...removed().map(([ra, rb]) => h('span', { class: 'rm', style: { left: ra / D * 100 + '%', width: Math.max(0.3, (Math.min(D, rb) - ra) / D * 100) + '%' } })),
      ...proj.zooms.map((z) => h('span', { class: 'zm', style: { left: z.a / D * 100 + '%', width: Math.max(0.4, (z.b - z.a) / D * 100) + '%', background: z.kind === 'custom' ? '#8B93FF' : '' } })),
      acPlay);
    map.addEventListener('pointerdown', (e) => { const r = map.getBoundingClientRect(); seek((e.clientX - r.left) / r.width * D); });
    const row = (label, n, tip, kind) => h('button', { class: 'gl-row', 'data-tip': n ? tip : null, disabled: n ? null : true, onclick: () => jumpNext(kind) },
      h('span', { class: 'gl-l' }, label), h('span', { class: 'gl-v' }, String(n)), icon('chev', 12, 'currentColor', 2.2));
    [
      head('Progetto', VERT ? 'Verticale 9:16' : fmtLabel()),
      nameField(),
      !IS_VOD ? null : fold('p.auto', 'Modifiche automatiche', h('div', { class: 'gl' },
          h('div', { class: 'gl-hero' },
            h('div', { class: 'gl-dur' },
              h('span', { class: 'gl-big' }, fmt(outD)),
              h('span', { class: 'gl-of' }, 'di ' + fmt(D)),
              gone > 0.5 ? h('span', { class: 'gl-gone' }, '−' + fmtGone(gone)) : null),
            map),
          row('Zoom', nz, 'Vai al prossimo zoom', 'zoom'),
          row('Tagli', nc, 'Vai al prossimo taglio', 'cut')), { open: true, right: h('div', { class: 'row', style: { gap: '0' } },
          ibtn('webcam', cam ? 'Cambia il riquadro della webcam' : 'Imposta la webcam', async () => { video.pause(); await flush(); ctx.nav('webcam', pid); }, { size: 14 }),
          ibtn('restore', 'Rifai zoom e tagli con un altro stile', async () => {
            if (await confirmBox('Rifare l\'analisi?', 'Zoom e tagli automatici vengono ricalcolati con lo stile che scegli. Le tue modifiche a zoom e tagli automatici si perdono.', 'Scegli stile')) {
              video.pause(); await flush(); ctx.nav('style', pid);
            }
          }, { size: 14 })) }),
      fold('p.q', 'Qualità dell\'anteprima', [cSeg(null, PQ.map((x) => x[1]), Math.max(0, PQ.findIndex((x) => x[0] === (S.previewQ || 'auto'))), (i) => { S.previewQ = PQ[i][0]; setTimeout(applyQuality, 0); }),
        ],
        { note: (PQ.find((x) => x[0] === (S.previewQ || 'auto')) || PQ[0])[1], tip: 'Solo per lavorare più fluido: il video finale resta alla qualità scelta in Esporta' }),
      IS_V ? null : fold('p.share', 'Passa ad un altro PC', [
        h('button', { class: 'btn sm', onclick: () => saveProjectFile() }, icon('download', 13), 'Salva come file .vodcut')], { tip: 'Un file .vodcut con tagli, zoom, testi ed effetti. Il video va copiato a parte sull\'altro PC.' }),
    ].filter(Boolean).forEach((x) => curBody.append(x));
  }
  // progetto in un file .vodcut, da aprire su un altro PC
  async function saveProjectFile() {
    if (IS_V) return toast('Per passare il progetto a un altro PC, torna al video orizzontale');
    try { await flush(); } catch (e) { /* */ } ctx.saveProject(pid, proj.name);
  }


  // --- testo
  let trJob = null, trPoll = null;
  let wordEls = [];      // [si][wi] -> span
  let segEls = [];
  function renderTranscript(target = panelBody) {
    const B = { append: (...a) => target.append(...a.filter((x) => x != null && x !== false)) };
    const tr = proj.transcript || { status: 'none' };
    wordEls = []; segEls = [];
    if (tr.status === 'running') {
      const bar = h('div', { class: 'progress' }, h('div', { style: { width: '0%' } }));
      const msg = h('p', null, 'Sto trascrivendo il video…');
      B.append(h('div', { class: 'empty' }, h('div', { class: 'row' }, h('div', { class: 'spinner' }), h('strong', null, 'Trascrizione in corso')), msg, bar,
        h('p', { class: 'xs' }, 'Intanto puoi lavorare su zoom e tagli. La prima volta scarica il modello (circa 1 GB).')));
      watchTranscript(bar, msg);
      return;
    }
    if (tr.status !== 'done') {
      const can = env.whisper;
      B.append(h('div', { class: 'empty' },
        h('strong', null, 'Taglia il video cancellando il testo'),
        h('p', null, 'Trascriviamo tutto quello che dici. Poi togli una parola o una frase e sparisce anche dal video. I sottotitoli restano spenti: li accendi quando vuoi.'),
        tr.status === 'error' ? h('p', { style: { color: 'var(--danger)' } }, 'L\'ultima trascrizione non è riuscita: ' + (tr.error || '')) : null,
        can ? h('button', { class: 'btn sm primary', style: { alignSelf: 'flex-start' }, onclick: () => startTranscribe(false) }, 'Trascrivi il video')
          : h('p', { class: 'xs' }, 'La trascrizione non è installata su questo PC: esegui di nuovo INSTALLA.bat e riapri VODcut.')));
      return;
    }
    const segs = allWords();
    if (!segs.length) { B.append(h('div', { class: 'empty' }, h('p', null, 'Nella trascrizione non ci sono parole.'))); return; }
    B.append(h('div', { class: 'xs', style: { lineHeight: '1.45' } }, 'Clic su una parola per andarci. Tieni premuto (o tasto destro) per tagliarla, metterci il bip o correggerla. Trascina per scegliere più parole.'));
    const box = h('div', { class: 'transcript mode-cut' });
    const autoCuts = proj.segs.filter((c) => c.auto).slice().sort((a, b) => a.a - b.a);
    let ci = 0;
    segs.forEach((s, si) => {
      while (ci < autoCuts.length && autoCuts[ci].a < s.a) { box.append(pauseChip(autoCuts[ci])); ci++; }
      const ws = h('div', { class: 'ws' });
      const row = [];
      s.words.forEach((w, wi) => {
        const sp = h('span', { class: 'w' + (w.del ? ' del' : '') + (w.cens ? ' cens' : '') + (w.ed ? ' ed' : ''), 'data-si': si, 'data-wi': wi }, w.w);
        row.push(sp); ws.append(sp, ' ');
      });
      wordEls.push(row);
      const segEl = h('div', { class: 'tseg' }, h('button', { class: 'ts', onclick: () => seek(s.a) }, fmt(s.a)), ws);
      segEls.push(segEl);
      box.append(segEl);
    });
    while (ci < autoCuts.length) { box.append(pauseChip(autoCuts[ci])); ci++; }
    // clic: la testina va sulla parola. Tieni premuto / tasto destro: cosa fare con la parola.
    // Trascina: selezioni piu' parole e poi scegli cosa farci.
    const wAt = (sp) => allWords()[+sp.dataset.si].words[+sp.dataset.wi];
    const spans = () => [...box.querySelectorAll('.w')];
    let press = null;
    const clearSel = () => box.querySelectorAll('.w.rsel').forEach((x) => x.classList.remove('rsel'));
    const rangeOf = (a, b) => { const all = spans(), i = all.indexOf(a), j = all.indexOf(b); return all.slice(Math.min(i, j), Math.max(i, j) + 1); };
    function wordMenu(list, x, y) {
      const ws = list.map(wAt), one = ws.length === 1;
      const allDel = ws.every((w) => w.del), allCens = ws.every((w) => w.cens), allHid = ws.every((w) => w.nosub);
      const setAll = (k, v) => { begin(); ws.forEach((w) => { w[k] = v || undefined; }); ver++; clearSel(); changed({ keepPanel: false }); };
      const n = one ? '' : ` (${ws.length} parole)`;
      popMenuAt(x, y, [
        ['play', 'Riproduci da qui', null, () => { clearSel(); seek(ws[0].a); video.play().catch(() => {}); }],
        [allDel ? 'restore' : 'scissors', (allDel ? 'Rimetti nel video' : 'Taglia dal video') + n, allDel ? null : 'Sparisce anche dall\'audio e dal video', () => setAll('del', !allDel)],
        ['beep', (allCens ? 'Togli il bip' : 'Metti il bip') + n, allCens ? null : 'Nei sottotitoli diventa c****', () => setAll('cens', !allCens)],
        [allHid ? 'eye' : 'eyeOff', (allHid ? 'Mostra nei sottotitoli' : 'Nascondi nei sottotitoli') + n, 'L\'audio resta', () => setAll('nosub', !allHid)],
        ...(one ? [['type', 'Correggi il testo', null, () => { clearSel(); seekQuiet(ws[0].a + 0.01); editWord(list[0]); }]] : []),
      ]);
    }
    box.addEventListener('pointerdown', (e) => {
      const sp = e.target.closest('.w'); if (!sp || sp.querySelector('input') || e.button !== 0) return;
      e.preventDefault();
      clearSel();
      press = { sp, last: sp, x: e.clientX, y: e.clientY, range: false, menu: false };
      press.timer = setTimeout(() => { if (press && !press.range) { press.menu = true; sp.classList.add('rsel'); wordMenu([sp], press.x, press.y); } }, 450);
      box.setPointerCapture(e.pointerId);
    });
    box.addEventListener('pointermove', (e) => {
      if (!press || press.menu) return;
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const sp = el && el.closest && el.closest('.w');
      if (!sp || sp === press.last) return;
      press.last = sp; press.range = true; clearTimeout(press.timer);
      clearSel(); rangeOf(press.sp, sp).forEach((x) => x.classList.add('rsel'));
    });
    box.addEventListener('pointerup', (e) => {
      if (!press) return;
      const p0 = press; press = null; clearTimeout(p0.timer);
      if (p0.menu) return;
      if (p0.range) { wordMenu(rangeOf(p0.sp, p0.last), e.clientX, e.clientY); return; }
      // clic semplice: esattamente all'inizio della parola
      const w = wAt(p0.sp);
      seek(w.a);
    });
    box.addEventListener('contextmenu', (e) => {
      const sp = e.target.closest('.w'); if (!sp) return;
      e.preventDefault();
      const cur = [...box.querySelectorAll('.w.rsel')];
      if (cur.includes(sp)) wordMenu(cur, e.clientX, e.clientY);
      else { clearSel(); sp.classList.add('rsel'); wordMenu([sp], e.clientX, e.clientY); }
    });
    B.append(box);
  }
  // correggere una parola sbagliata della trascrizione (cambia anche nei sottotitoli)
  let trMode = 'cut';
  function editWord(sp) {
    const w = allWords()[+sp.dataset.si].words[+sp.dataset.wi];
    const inp = h('input', { class: 'wedit', value: w.w, spellcheck: 'false', 'aria-label': 'Correggi la parola' });
    inp.style.width = Math.max(3, w.w.length + 1) + 'ch';
    sp.replaceChildren(inp); inp.focus(); inp.select();
    let done = false;
    const finish = (save, next) => {
      if (done) return; done = true;
      const v = inp.value.replace(/\s+/g, ' ').trim();
      if (save && v && v !== w.w) { begin(); if (w.orig === undefined) w.orig = w.w; w.w = v; w.ed = true; sp.classList.add('ed'); ver++; dirty = true; scheduleSave(); renderTimeline(); }
      sp.replaceChildren(w.w);
      if (next) {
        const all = [...panelBody.querySelectorAll('.transcript .w')];
        const n = all[all.indexOf(sp) + (next > 0 ? 1 : -1)];
        if (n) { const nw = allWords()[+n.dataset.si].words[+n.dataset.wi]; seekQuiet(nw.a + 0.01); editWord(n); }
      }
    };
    inp.addEventListener('input', () => { inp.style.width = Math.max(3, inp.value.length + 1) + 'ch'; });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
      else if (e.key === 'Tab') { e.preventDefault(); finish(true, e.shiftKey ? -1 : 1); }
    });
    inp.addEventListener('blur', () => finish(true));
  }
  function pauseChip(c) {
    const on = !!c.removed;
    return h('button', { class: 'pausechip' + (on ? ' cut' : ''), 'aria-pressed': String(on), 'data-tip': on ? 'Clic per rimettere questa pausa' : 'Clic per tagliarla di nuovo',
      onclick: () => { begin(); c.removed = !on; changed({ keepPanel: false }); } }, `··· pausa ${(c.b - c.a).toFixed(1).replace('.', ',')} s` + (on ? ' (tagliata)' : ''));
  }
  function renderTranscriptFlags() {
    if (tab !== 'text') return;
    allWords().forEach((s, si) => s.words.forEach((w, wi) => { const el = wordEls[si] && wordEls[si][wi]; if (el) { el.classList.toggle('del', !!w.del); el.classList.toggle('cens', !!w.cens); } }));
  }
  function scrollToWord(si, wi) {
    const el = wordEls[si] && wordEls[si][wi];
    if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  // stato dei sottotitoli quando non ci sono ancora: in preparazione (con %) o da creare
  let trProg = { p: 0, msg: '' };
  const trStatus = () => (proj.transcript && proj.transcript.status) || 'none';
  function subsStatus(where) {
    const st = trStatus();
    if (st === 'running') {
      const pct = Math.round(trProg.p * 100);
      if (where === 'lane') return h('div', { class: 'lane-hint subs-prog' }, h('div', { class: 'spinner' }), h('span', { class: 'trp-txt' }, (proj.settings.showSubs ? 'Creo i sottotitoli' : 'Trascrizione') + (pct ? ' · ' + pct + '%' : '…')));
      // la trascrizione e' una sola: l'avanzamento si vede in Trascrizione, qui basta una riga
      return h('div', { class: 'substat' }, h('div', { class: 'row', style: { gap: '8px' } }, h('div', { class: 'spinner' }),
        h('span', { class: 'xs trp-txt' }, (proj.settings.showSubs ? 'Pronti quando finisce la trascrizione' : 'Trascrizione in corso: poi puoi accendere i sottotitoli') + (pct ? ' · ' + pct + '%' : ''))));
    }
    if (!env.whisper) {
      const msg = 'Per i sottotitoli serve la trascrizione: esegui di nuovo INSTALLA.bat e riapri VODcut.';
      return where === 'lane' ? h('div', { class: 'lane-hint' }, 'Sottotitoli non disponibili') : h('div', { class: 'substat' }, h('span', { class: 'xs' }, msg));
    }
    const err = st === 'error' ? 'L\'ultima volta non è riuscita' + (proj.transcript.error ? ': ' + proj.transcript.error : '') + '. ' : '';
    if (where === 'lane') {
      const b = h('button', { class: 'lane-cta', onclick: (e) => { e.stopPropagation(); startTranscribe(true); } }, icon('plus', 12, 'currentColor', 2.4), err ? 'Riprova a creare i sottotitoli' : 'Crea i sottotitoli');
      b.addEventListener('pointerdown', (e) => e.stopPropagation());
      return b;
    }
    return h('div', { class: 'substat' }, h('span', { class: 'xs' }, err + 'Trascriviamo quello che dici e lo trasformiamo in sottotitoli, che poi puoi personalizzare.'),
      h('button', { class: 'btn sm primary', style: { alignSelf: 'flex-start' }, onclick: () => startTranscribe(true) }, icon('cc', 14, '#fff'), 'Crea i sottotitoli'));
  }
  function paintTrProgress() {
    const pct = Math.round(trProg.p * 100);
    document.querySelectorAll('.trp-bar').forEach((b) => { b.style.width = pct + '%'; });
    document.querySelectorAll('.lane.subs .trp-txt').forEach((t) => { t.textContent = (proj.settings.showSubs ? 'Creo i sottotitoli' : 'Trascrizione') + (pct ? ' · ' + pct + '%' : '…'); });
    document.querySelectorAll('.substat .trp-txt').forEach((t) => { t.textContent = (proj.settings.showSubs ? 'Pronti quando finisce la trascrizione' : 'Trascrizione in corso: poi puoi accendere i sottotitoli') + (pct ? ' · ' + pct + '%' : ''); });
  }
  // sottotitoli di un pezzo solo (tasto destro su una clip): si trascrive quel pezzo e basta
  let subRangeJob = null;
  async function regenSubs(segs) {
    const rs = segs.map((x) => [x.a, x.b]).sort((p, q) => p[0] - q[0]);
    const merged = [];
    for (const [a, b] of rs) { const l = merged[merged.length - 1]; if (l && a <= l[1] + 0.05) l[1] = Math.max(l[1], b); else merged.push([a, b]); }
    const pill = h('div', { class: 'jobpill' }, h('div', { class: 'spinner' }), h('span', null, 'Creo i sottotitoli di questa clip…'));
    document.body.append(pill);
    subRangeJob = true;
    let words = 0, fail = '';
    try {
      await flush();
      for (const [a, b] of merged) {
        const job = await post(`/api/p/${pid}/transcriberange`, { a, b });
        const res = await pollJob(job.id, (j) => { pill.lastChild.textContent = 'Creo i sottotitoli di questa clip' + (j.progress > 0.01 ? ' · ' + Math.round(j.progress * 100) + '%' : '…'); });
        if (res.status !== 'done') { fail = res.error || 'annullata'; break; }
        words += (res.result && res.result.words) || 0;
      }
    } catch (e) { fail = e.message; }
    subRangeJob = null; pill.remove();
    if (!alive) return;
    const p2 = await get('/api/p/' + pid);
    if (p2.transcript && p2.transcript.status === 'done') proj.transcript = p2.transcript;
    if (!proj.settings.showSubs && !fail && words) { proj.settings.showSubs = true; dirty = true; scheduleSave(); }
    ver++; renderPanel(); renderTimeline(); frame(true);
    if (fail) toast('Sottotitoli non riusciti: ' + fail, true);
    else toast(words ? 'Sottotitoli pronti per questa clip' : 'Nessuna parola trovata in questa clip');
  }
  // subs: accende anche i sottotitoli (se no si trascrive soltanto, per tagliare dal testo)
  async function startTranscribe(subs) {
    try {
      if (subs !== undefined) { proj.settings.showSubs = !!subs; dirty = true; scheduleSave(); }
      trJob = await post(`/api/p/${pid}/transcribe`);
      proj.transcript = { status: 'running', segments: [] };
      trProg = { p: 0, msg: '' };
      renderPanel(); renderTimeline();
      watchTranscript();
    } catch (e) { toast(e.message, true); }
  }
  async function watchTranscript(bar, msg) {
    if (trPoll) return;
    if (!trJob) { const jobs = await get('/api/jobs'); trJob = jobs.find((j) => j.pid === pid && j.kind === 'transcribe'); }
    if (!trJob) {
      // job non piu' in corso: ricarica lo stato dal server
      const p2 = await get('/api/p/' + pid);
      proj.transcript = p2.transcript.status === 'running' ? { status: 'error', error: 'interrotta', segments: [] } : p2.transcript;
      renderPanel(); return;
    }
    trPoll = true;
    const res = await pollJob(trJob.id, (j) => {
      if (!alive) return;
      trProg = { p: j.progress || 0, msg: j.message || '' }; paintTrProgress();
      const b = panelBody.querySelector('.progress > div'); if (b) b.style.width = (j.progress * 100).toFixed(1) + '%';
      const m = panelBody.querySelector('.empty p'); if (m && j.message) m.textContent = j.message + (j.progress > 0.01 ? ' · ' + Math.round(j.progress * 100) + '%' : '');
    });
    trPoll = null; trJob = null;
    if (!alive) return;
    const p2 = await get('/api/p/' + pid);
    proj.transcript = res.status === 'done' ? p2.transcript : { status: 'error', error: res.error || 'annullata', segments: [] };
    if (res.status === 'done') toast((proj.settings.showSubs ? 'Sottotitoli pronti: ' : 'Trascrizione pronta: ') + allWords().length + ' frasi.');
    else if (res.status === 'error') toast('Trascrizione non riuscita: ' + (res.error || ''), true);
    ver++; renderPanel(); renderTimeline();
  }

  // ---------------------------------------------------------------- riproduzione
  const sounds = new Map(); // clipId -> Audio
  function soundEl(c) {
    let a = sounds.get(c.id);
    if (!a || a.dataset.file !== c.file) { a = new Audio(mediaUrl(c.file)); a.preload = 'auto'; a.dataset.file = c.file; sounds.set(c.id, a); }
    return a;
  }
  function togglePlay() {
    if (!videoReady) return;
    if (video.paused) video.play().catch((e) => { if (e.name !== 'AbortError') toast('Non riesco a riprodurre: ' + e.message, true); });
    else video.pause();
  }
  video.addEventListener('canplay', onReady);
  // diagnostica caricamento video (finisce in vodcut.log)
  const tLoad = performance.now();
  const clog = (m) => post('/api/clientlog', { msg: m + ' dopo ' + Math.round(performance.now() - tLoad) + ' ms' }).catch(() => {});
  ['loadstart', 'loadedmetadata', 'loadeddata', 'canplay', 'stalled', 'waiting', 'suspend'].forEach((ev) => video.addEventListener(ev, () => clog('video ' + ev + ' readyState=' + video.readyState), { once: ev !== 'stalled' && ev !== 'waiting' }));
  video.addEventListener('error', () => clog('video ERRORE ' + (video.error && (video.error.code + ' ' + video.error.message))));
  video.addEventListener('loadeddata', onReady);
  setTimeout(() => { if (!videoReady && video.readyState >= 2) onReady(); if (!strip) loadStrip(); }, 4000);
  video.addEventListener('play', () => { playBtn.replaceChildren(icon('pause', 15, '#0B0E13')); playBtn.setAttribute('aria-label', 'Pausa'); });
  video.addEventListener('pause', () => { playBtn.replaceChildren(icon('play', 15, '#0B0E13')); playBtn.setAttribute('aria-label', 'Riproduci'); sounds.forEach((a) => a.pause()); ovImgs.forEach((el) => { if (el.tagName === 'VIDEO') el.pause(); }); });
  video.addEventListener('error', () => {
    // il browser non legge questo video: passa da solo alla copia compatibile (nessun messaggio d'errore)
    if (curSrc === 'orig' && !compat) { compat = true; curSrc = ''; loadingTxt.textContent = 'Preparo l\'anteprima…'; applyQuality(); return; }
    if (compat && curSrc) toast('Non riesco a mostrare l\'anteprima di questo video, ma l\'esportazione funziona lo stesso.', true);
  });
  // mai fermarsi dentro una parte eliminata dalla timeline: si va al primo fotogramma dopo (o all'ultimo prima, se e' la fine)
  function visT(t) {
    t = Math.max(0, Math.min(D - 0.05, t));
    for (const [a, b] of goneR) if (t >= a && t < b) return b < D - 0.05 ? b : Math.max(0, a - 0.04);
    return t;
  }
  // ultimo istante che resta davvero nel video (le parti tolte alla fine non contano)
  function lastKept() {
    let end = D;
    for (const [a, b] of [...remCache].sort((x, y) => y[0] - x[0])) if (b >= end - 0.05 && a < end) end = a;
    return Math.max(0.05, end);
  }
  function seek(t) { video.currentTime = visT(t); frame(true); ensureVisible(video.currentTime); }
  function seekQuiet(t) { video.currentTime = visT(t); }
  function ensureVisible(t) {
    const x = X(t), l = scroller.scrollLeft, w = scroller.clientWidth;
    if (x < l + 20 || x > l + w - 20) scroller.scrollLeft = x - w * 0.3;
  }

  let lastSeg = -1, lastWord = null, raf = 0, lastRem = null, remCache = [], outTot = 0;
  function frame(force) {
    video.tick();
    const t = video.currentTime;
    if (force || !lastRem || Date.now() - lastRem > 400) { remCache = removed(); lastRem = Date.now(); outTot = outDuration(); }
    // salta le parti tagliate mentre riproduce
    if (!video.paused) {
      for (const [a, b] of remCache) if (t >= a && t < b - 0.03) {
        // se la parte tolta arriva fino alla fine, il video finisce qui: resta l'ultimo fotogramma vero
        if (b >= D - 0.06) { video.pause(); video.currentTime = Math.max(0, lastKept() - 0.04); frame(true); return; }
        video.currentTime = b; return;
      }
    }
    let inCut = remCache.some(([a, b]) => t >= a && t < b);
    if (BLANK) {   // progetto vuoto: il nero non e' "tagliato", e' solo che li' non c'e' ancora niente
      const ce = contentEnd();
      const msg = pendingIns ? 'Preparo il video…' : ce < 0.05 ? 'Trascina un video nella timeline o aggiungi un testo per iniziare' : (t >= ce - 0.02 ? 'Fine del video' : 'Questa parte verrà tagliata');
      if (veil.textContent !== msg) veil.textContent = msg;
      if (ce < 0.05 || t >= ce - 0.02) inCut = true;
    }
    veil.style.display = inCut && video.paused ? 'flex' : 'none';
    // zoom
    let p = 0, zz = null;
    for (const z of proj.zooms) { if (!cam && z.kind !== 'custom') continue; const v = zoomProgress(t, z); if (v > p) { p = v; zz = z; } }
    const sw = screen.clientWidth;
    const fz = framing && sel && sel.type === 'zoom' ? findSel() : null;
    const fr = fz ? (VERT ? vBoxOf(fz) : fz.kind === 'custom' && fz.rect ? customRect(W, H, fz.rect) : null) : null;
    if (fr) {
      // modalita' inquadratura: video intero + riquadro da spostare (in verticale alto 9:16)
      const [fx, fy, fw, fh] = fr, k = sw / W;
      Object.assign(frameBox.style, { display: 'block', left: fx * k + 'px', top: fy * k + 'px', width: fw * k + 'px', height: fh * k + 'px' });
      frameBox.classList.toggle('v', VERT); frameBox.classList.toggle('narrow', VERT || fw * k < 96);
      frameDoneBar.style.display = VERT ? '' : 'none';
      zg.style.transform = ''; badgeMain.textContent = VERT ? 'Inquadratura verticale' : 'Scegli cosa inquadrare';
    } else if (frameBox.style.display !== 'none') { frameBox.style.display = 'none'; frameDoneBar.style.display = 'none'; }
    if (fr) { /* gia' gestito */ } else if (p > 0.001) {
      const [rx, ry, rw] = rectAt(p, W, H, zoomTarget(zz, W, H, cam));
      const s = W / rw, k = sw / W;
      zg.style.transform = `translate(${-rx * k * s}px, ${-ry * k * s}px) scale(${s})`;
      zoomNow = { s, tx: -rx * k * s, ty: -ry * k * s * (1) };
      badgeMain.textContent = 'Zoom attivo';
    } else { zg.style.transform = ''; zoomNow = null; badgeMain.textContent = inCut ? 'Taglio' : 'Originale'; }
    if (fr) zoomNow = null;
    // verticale: niente ingrandimento della live, la si disegna a pezzi sullo schermo verticale
    applyViewMode();
    if (VERT && !sourceView()) {
      zg.style.transform = '';
      const inZ = proj.zooms.some((z) => z.on !== false && t >= z.a && t < z.b && (cam || z.kind === 'custom'));
      badgeMain.textContent = inZ ? 'Webcam' : inCut ? 'Taglio' : 'Verticale';
      drawVertical(t);
    }
    applyTf(t); updateTfUI(t); drawGuides();
    // filtri attivi (a video fermo si ridisegnano solo se cambia qualcosa)
    updateFxLayer(t);
    updateMaskUI();
    placeOverlays(t);
    applySpeed();
    // audio live
    const lt = liveTrack();
    const c = proj.segs.find((x) => t >= x.a && t < x.b) || proj.segs[proj.segs.length - 1];
    let v = lt.mute || c.mute ? 0 : (lt.vol / 100) * (c.vol / 100);
    if (c.fin) v *= Math.min(1, (t - c.a) / 0.5);
    if (c.fout) v *= Math.min(1, (c.b - t) / 0.5);
    // parole censurate: niente voce, bip al suo posto
    const bleep = !video.paused && censAt(t);
    if (bleep) v = 0;
    beep(bleep);
    video.volume = Math.max(0, Math.min(1, v)); video.muted = v === 0;
    badgeMute.style.display = v === 0 && !inCut ? '' : 'none';
    // suoni importati
    for (const tr of soundTracks()) {
      for (const sc of tr.clips) {
        const on = !video.paused && !tr.mute && !sc.mute && t >= sc.a && t < sc.a + sc.dur;
        const a = on || sounds.has(sc.id) ? soundEl(sc) : null;
        if (!a) continue;
        if (on) {
          const target = sc.offset + (t - sc.a);
          a.volume = Math.max(0, Math.min(1, (tr.vol / 100) * (sc.vol / 100)));
          if (a.paused) { a.currentTime = target; a.play().catch(() => {}); } else if (Math.abs(a.currentTime - target) > 0.3) a.currentTime = target;
        } else if (!a.paused) a.pause();
      }
    }
    // sottotitoli + testo attivo
    const segs = allWords();
    let si = -1;
    if (segs.length) {
      let lo = 0, hi = segs.length - 1;
      while (lo <= hi) { const m = (lo + hi) >> 1; if (segs[m].a <= t) { si = m; lo = m + 1; } else hi = m - 1; }
      if (si >= 0 && t > segs[si].b + 0.6) si = -1;
    }
    showSub(t, inCut);
    if (tab === 'text' && si !== lastSeg) {
      if (segEls[lastSeg]) segEls[lastSeg].classList.remove('active');
      if (segEls[si]) { segEls[si].classList.add('active'); if (!video.paused) segEls[si].scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
      lastSeg = si;
    }
    if (tab === 'text' && si >= 0 && wordEls[si]) {
      const wi = segs[si].words.findIndex((w) => t >= w.a && t < w.b);
      const el = wi >= 0 ? wordEls[si][wi] : null;
      if (el !== lastWord) { if (lastWord) lastWord.classList.remove('cur'); if (el) el.classList.add('cur'); lastWord = el; }
    }
    // tempo come nel video finale: le parti tolte (anche a righe) non contano, la velocita' si'
    timeLbl.textContent = fmt(outAt(t), true) + ' / ' + fmt(outTot);
    updateFsBar(t);
    if (acPlay && acPlay.isConnected) acPlay.style.left = t / D * 100 + '%';
    if (liveCtls.length && !ovDrag) liveCtls.forEach((f) => f());
    updatePlayhead(t);
    if (!video.paused && !scrub && !drag) {
      const x = X(t), l = scroller.scrollLeft, w = scroller.clientWidth;
      if (x > l + w - 40) scroller.scrollLeft = x - 60;
    }
  }
  let censCache = null;
  function censAt(t) {
    if (!censCache || censCache.ver !== ver || censCache.n !== allWords().length) {
      const r = [];
      allWords().forEach((s) => s.words.forEach((w) => { if (w.cens && !w.del) r.push([w.a - 0.03, w.b + 0.03]); }));
      censCache = { ver, n: allWords().length, r };
    }
    return censCache.r.some(([a, b]) => t >= a && t < b);
  }
  let actx = null, bgain = null;
  function beep(on) {
    if (!on && !bgain) return;
    try {
      if (!actx) {
        actx = new AudioContext(); const o = actx.createOscillator(); bgain = actx.createGain();
        o.frequency.value = 1000; bgain.gain.value = 0; o.connect(bgain).connect(actx.destination); o.start();
      }
      bgain.gain.setTargetAtTime(on ? 0.18 : 0, actx.currentTime, 0.005);
    } catch (e) { /* audio non disponibile */ }
  }
  function loop() { if (!alive) return; frame(); raf = requestAnimationFrame(loop); }

  // ---------------------------------------------------------------- tastiera
  function onKey(e) {
    if (document.querySelector('.modal-bg')) return;
    const tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' && e.target.type !== 'range' || tag === 'textarea') return;
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
    if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); redo(); return; }
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && k === 's') { e.preventDefault(); saveProjectFile(); return; }
    if ((e.ctrlKey || e.metaKey) && k === 's') { e.preventDefault(); flush(); return; }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === 'c') { if (copySel()) e.preventDefault(); return; }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && k === 'v') { if (pasteClip()) e.preventDefault(); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    // spazio = play/pausa sempre, anche se prima hai cliccato un pulsante (non deve "ripremerlo")
    if (k === ' ') { e.preventDefault(); if (tag === 'button') e.target.blur(); if (!e.repeat) togglePlay(); }
    else if (k === 'delete' || k === 'backspace') { e.preventDefault(); deleteSel(); }
    else if (k === 'z') addZoom();
    else if (k === 'c') addCustomZoom();
    else if (e.key === '>' || (e.shiftKey && e.key === '.')) { e.preventDefault(); stepRate(1); }
    else if (e.key === '<' || (e.shiftKey && e.key === ',')) { e.preventDefault(); stepRate(-1); }
    else if (k === 'q') { e.preventDefault(); trimAt('left'); }
    else if (k === 'w') { e.preventDefault(); trimAt('right'); }
    else if (k === 'n') magnetBtn.click();
    else if (k === 't') addText();
    else if (k === 'v' && !IS_V) vertFromSelection();
    else if (k === 'f') toggleFull();
    else if (k === 's' || k === 'x') splitSeg();
    else if (k === 'arrowleft') { e.preventDefault(); seek(video.currentTime - (e.shiftKey ? 5 : 1)); }
    else if (k === 'arrowright') { e.preventDefault(); seek(video.currentTime + (e.shiftKey ? 5 : 1)); }
    else if (k === 'escape') select(null, true);
  }
  document.addEventListener('keydown', onKey);
  const onKeyUp = (e) => { if (e.key === ' ' && (e.target.tagName || '').toLowerCase() === 'button') e.preventDefault(); };
  document.addEventListener('keyup', onKeyUp, true);
  window.addEventListener('beforeunload', flush);

  // ---------------------------------------------------------------- avvio
  const ro = new ResizeObserver(() => {
    layoutScreen();
    const oldFit = fitPps;
    fitPps = Math.max(0.005, (scroller.clientWidth - 2) / fitSpan());
    if (pps === oldFit || pps < fitPps) pps = fitPps;
    renderTimeline();
  });
  ro.observe(root); ro.observe(screenWrap); ro.observe(tl);
  refreshGone();
  fitPps = Math.max(0.005, (scroller.clientWidth - 2) / fitSpan()); pps = fitPps;
  layoutScreen();
  renderTimeline(); renderPanel(); updateUndo();
  // font usati nel progetto (sottotitoli e testi): si caricano subito, cosi' l'anteprima e' giusta
  loadFontList().then(() => {
    const used = new Set([(proj.subStyle || {}).font]);
    for (const tr of proj.tracks || []) for (const c of tr.clips || []) if (c.text && c.text.font) used.add(c.text.font);
    used.forEach((f) => { if (f) ensureFont(f).then(() => { if (alive) frame(true); }); });
  });
  let seek0 = null;
  try { seek0 = sessionStorage.getItem('vodcut.seek.' + pid); sessionStorage.removeItem('vodcut.seek.' + pid); } catch (e) { /* */ }
  if (VERT && cam) loadFace().then(() => { if (proj.faceOn && !faceJob) startFace(); });
  if (proj.story && proj.story.pending) setTimeout(buildStory, 0);
  video.addEventListener('loadedmetadata', () => { seek(seek0 !== null ? +seek0 + 0.05 : IS_V && proj.range ? proj.range[0] + 0.05 : proj.zooms.length ? Math.max(0, proj.zooms[0].a + 0.8) : 0); }, { once: true });
  if (proj.repairNote) {
    // progetto della versione vecchia (video unito alla live): tornato alla live originale
    delete proj.repairNote; dirty = true; scheduleSave();
    setTimeout(() => toast('Abbiamo sistemato questo progetto: il video che avevi aggiunto è stato tolto. Rimettilo trascinandolo dai Media sulla traccia Video.'), 800);
  }
  applyQuality();
  loop();
  dirty = true; scheduleSave();  // salva subito le impostazioni aggiornate
  if (proj.transcript && proj.transcript.status === 'running') watchTranscript();
  else get('/api/jobs').then((jobs) => {
    const j = jobs.find((x) => x.pid === pid && x.kind === 'transcribe');
    if (j && alive && !allWords().length) { trJob = j; proj.transcript = { status: 'running', segments: [] }; renderTimeline(); renderPanel(); watchTranscript(); }
  }).catch(() => {});

  return async () => {
    alive = false;
    dragCard.remove();
    cancelAnimationFrame(raf);
    ro.disconnect();
    document.removeEventListener('keydown', onKey);
    document.removeEventListener('keyup', onKeyUp, true);
    document.removeEventListener('fullscreenchange', onFs);
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    window.removeEventListener('beforeunload', flush);
    video.pause(); sounds.forEach((a) => a.pause());
    if (actx) actx.close().catch(() => {});
    video.removeAttribute('src'); video.load();
    await flush();
  };
}
