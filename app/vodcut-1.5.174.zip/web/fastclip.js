// NoonFrame - Clip veloci: dal link (o dal file) alle clip verticali in un passaggio, come sul sito.
// Niente webcam da sistemare, niente montaggio del video lungo: si scarica, si analizza e l'AI trova le clip.
// Il video lungo resta comunque tra i progetti (per chi vuole rifinirlo).
import { get, post, put, h, icon, toast, pollJob, droppedPath, BIG_DROP, fixLink, isLocalPath, localPath } from './lib.js';

const FORMATS = [
  ['auto', 'Automatico', 'L\'AI capisce se c\'è una webcam sopra il gioco o se sono persone che parlano'],
  ['podcast', 'Persone a tutto schermo', 'Podcast, interviste, vlog: l\'inquadratura segue chi parla'],
  ['gaming', 'Webcam sopra, gioco sotto', 'Live di gaming con il riquadro della webcam'],
  ['fit', 'Video intero', 'Tutto il video, con lo sfondo sfocato sopra e sotto'],
];
const LANGS = [['', 'Lingua automatica'], ['it', 'Italiano'], ['en', 'Inglese'], ['es', 'Spagnolo'], ['fr', 'Francese'], ['de', 'Tedesco'], ['pt', 'Portoghese']];
const LINK_RX = /(youtube\.com|youtu\.be|twitch\.tv|kick\.com)\//i;
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* */ } },
};

// riga "Clip veloci" della home: si incolla il link e si parte
export function fastStrip(nav) {
  const inp = h('input', { class: 'input fc-in', type: 'text', placeholder: 'Incolla il link: YouTube, twitch.tv/videos/…, kick.com/…', 'aria-label': 'Link del video o della live' });
  const go = () => {
    const raw = inp.value.trim();
    if (!raw) { inp.focus(); return; }
    if (isLocalPath(raw)) { nav('fastclip', null, { path: localPath(raw) }); return; }   // percorso di un video del computer
    const v = fixLink(raw);     // "www.youtube.com\watch?v=…", https mancante, testo intorno…
    if (!LINK_RX.test(v)) { toast('Usa il link di un video di YouTube o di una live di Twitch o Kick, oppure scegli un file'); inp.focus(); return; }
    nav('fastclip', null, { url: v });
  };
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
  return h('section', { class: 'fc-strip', 'aria-label': 'Clip veloci' },
    h('div', { class: 'fc-intro' },
      h('span', { class: 'fc-badge' }, icon('sparkle', 16, '#fff', 2.2)),
      h('div', null, h('h2', null, 'Clip veloci'), h('p', null, 'Dal link alle clip verticali pronte, senza passare dal montaggio della live.'))),
    h('div', { class: 'fc-go' }, inp,
      h('button', { class: 'btn primary', onclick: go }, 'Crea le clip'),
      h('button', { class: 'btn ghost', onclick: () => nav('fastclip') }, icon('upload', 14), 'Da un file')));
}

export async function screenFast(ctx, extra) {
  const { app, nav, setTitle, topbar, setCleanup } = ctx;
  setTitle('Clip veloci');
  let alive = true, running = false, pid = null, curJob = null;
  setCleanup(() => { alive = false; });
  let fmtSel = store.get('nf.fc.fmt') || 'auto';
  if (!FORMATS.some((f) => f[0] === fmtSel)) fmtSel = 'auto';

  const link = h('input', { class: 'input fc-in', type: 'text', value: (extra && extra.url) || '', placeholder: 'Incolla il link: YouTube, twitch.tv/videos/…, kick.com/…', 'aria-label': 'Link del video o della live' });
  let file = (extra && extra.path) || null;
  const fileTag = h('span', { class: 'fc-file' });
  const showFile = () => { fileTag.replaceChildren(...(file ? [icon('film', 14), h('span', null, file.split(/[\\/]/).pop()), h('button', { class: 'linkish', onclick: () => { file = null; showFile(); } }, 'Togli')] : [])); fileTag.style.display = file ? '' : 'none'; };
  const pickBtn = h('button', { class: 'btn', onclick: async () => {
    try {
      const r = await post('/api/pick', { kind: 'video' });
      const p = r.fallback ? (prompt('Percorso completo del video:', '') || '') : r.path;
      if (p) { file = p; link.value = ''; showFile(); }
    } catch (e) { toast(e.message, true); }
  } }, icon('folder', 14), 'Scegli un file');
  const zone = h('div', { class: 'fc-zone' }, h('div', { class: 'fc-row' }, link, pickBtn), fileTag);
  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('over'));
  zone.addEventListener('drop', async (e) => {
    e.preventDefault(); zone.classList.remove('over');
    const f = e.dataTransfer.files[0];
    if (!f) return;
    const real = await droppedPath(f);
    if (real) { file = real; link.value = ''; showFile(); return; }
    toast(f.size > BIG_DROP ? 'File molto grande: sceglilo con "Scegli un file", così NoonFrame lo apre senza copiarlo' : 'Scegli il video con "Scegli un file"', true);
  });

  const fmtBtns = FORMATS.map(([k, name, tip]) => h('button', { class: 'fc-fmt' + (k === fmtSel ? ' on' : ''), type: 'button', 'aria-pressed': k === fmtSel ? 'true' : 'false', 'data-tip': tip,
    onclick: () => { fmtSel = k; store.set('nf.fc.fmt', k); fmtBtns.forEach((b, i) => { const on = FORMATS[i][0] === k; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); }); } },
    h('i', { class: 'fc-ico ' + k }, h('b'), h('u')), h('span', null, name)));
  const lang = h('select', { class: 'input fc-lang', 'aria-label': 'Lingua del video' }, ...LANGS.map(([k, n]) => h('option', { value: k, selected: k === (store.get('nf.fc.lang') || '') ? true : null }, n)));
  lang.addEventListener('change', () => store.set('nf.fc.lang', lang.value));
  const q = h('input', { class: 'input fc-q', type: 'text', maxlength: '300', placeholder: 'Cosa cercare? Es. momenti divertenti, consigli pratici (facoltativo)', 'aria-label': 'Cosa cercare nel video' });
  const startBtn = h('button', { class: 'btn primary fc-start', onclick: () => start() }, icon('sparkle', 15, '#fff', 2.2), 'Crea le clip');

  const steps = [['get', 'Prendo il video'], ['prep', 'Analizzo video e audio'], ['ai', 'L\'AI trova i momenti migliori']];
  const stepEls = steps.map(([k, label]) => h('li', { class: 'fc-step', 'data-k': k }, h('span', { class: 'fc-dot' }), h('div', null, h('b', null, label), h('small', null, ''))));
  const bar = h('div', { class: 'fc-bar' }, h('i'));
  const cancelBtn = h('button', { class: 'btn ghost sm', onclick: () => cancel() }, 'Annulla');
  const prog = h('div', { class: 'fc-prog', style: { display: 'none' }, role: 'status', 'aria-live': 'polite' }, h('ol', { class: 'fc-steps' }, ...stepEls), bar, h('div', { class: 'fc-pfoot' }, h('span', { class: 'xs muted' }, 'Puoi usare il resto dell\'app intanto: le clip le trovi tra i progetti.'), cancelBtn));
  const form = h('div', { class: 'fc-form' },
    zone,
    h('div', { class: 'fc-opts' },
      h('div', { class: 'fc-lbl' }, 'Formato delle clip'), h('div', { class: 'fc-fmts', role: 'group', 'aria-label': 'Formato delle clip' }, ...fmtBtns),
      h('div', { class: 'fc-two' }, lang, q)),
    startBtn);

  app.innerHTML = '';
  app.append(topbar(-1, h('div'), false, { name: 'Clip veloci', icon: 'sparkle' }),
    h('main', { class: 'fc' },
      h('div', { class: 'fc-head' }, h('h1', null, 'Clip veloci'), h('p', { class: 'lead' }, 'Incolla il link o scegli il video: l\'AI trova i momenti migliori e ti dà le clip verticali pronte da pubblicare. Il video lungo resta tra i tuoi progetti, se vuoi rifinirlo.')),
      form, prog));
  showFile();

  function setStep(k, msg, pct) {
    const idx = steps.findIndex((s) => s[0] === k);
    stepEls.forEach((el, i) => { el.classList.toggle('done', i < idx); el.classList.toggle('now', i === idx); if (i === idx) el.querySelector('small').textContent = msg || ''; else if (i < idx) el.querySelector('small').textContent = 'Fatto'; });
    bar.firstChild.style.width = Math.round(((idx + Math.max(0, Math.min(1, pct || 0))) / steps.length) * 100) + '%';
  }
  async function follow(job, k, label) {
    curJob = job;
    const r = await pollJob(job.id, (j) => { if (alive) setStep(k, (j.message || label) + (j.progress ? ' · ' + Math.round(j.progress * 100) + '%' : ''), j.progress); });
    curJob = null;
    if (r.status !== 'done') throw new Error(r.status === 'cancelled' ? 'annullato' : (r.error || 'Qualcosa non ha funzionato'));
    return r.result || {};
  }
  function cancel() { if (curJob) post(`/api/jobs/${curJob.id}/cancel`).catch(() => {}); }

  async function start() {
    if (running) return;
    let raw = link.value.trim();
    // percorso di un video del computer incollato nel campo del link: si usa come file
    if (raw && isLocalPath(raw)) { file = localPath(raw); link.value = ''; raw = ''; showFile(); }
    const url = raw ? fixLink(raw) : '';     // "www.youtube.com\watch?v=…", https mancante, testo intorno…
    if (url && url !== raw) link.value = url;
    if (raw && !url) { link.focus(); return toast('Usa il link di un video di YouTube o di una live di Twitch o Kick'); }
    if (!url && !file) { link.focus(); return toast('Incolla un link o scegli un file'); }
    if (url && !LINK_RX.test(url)) { link.focus(); return toast('Usa il link di un video di YouTube o di una live di Twitch o Kick'); }
    running = true;
    form.style.display = 'none'; prog.style.display = '';
    try {
      // 1) il video: scaricato dal link o aperto dal computer
      setStep('get', url ? 'Scarico il video' : 'Apro il file', 0);
      if (url) pid = (await follow(await post('/api/import-url', { url }), 'get', 'Scarico il video')).project;
      else pid = (await post('/api/projects', { source: file })).id;
      if (!alive) return;
      // 2) analisi: anteprima leggera, webcam, volume
      setStep('prep', 'Analizzo il video', 0);
      await follow(await post(`/api/p/${pid}/prepare`), 'prep', 'Analizzo il video');
      if (!alive) return;
      await applyFormat(pid, fmtSel);
      // 3) la ricerca delle clip: la galleria la segue e mostra le clip appena sono pronte
      setStep('ai', 'Trascrivo e cerco i momenti migliori', 0);
      const body = { prompt: q.value.trim() };
      if (lang.value) body.lang = lang.value;
      await post(`/api/p/${pid}/clips`, body);
      nav('clips', pid);
    } catch (e) {
      running = false;
      if (!alive) return;
      prog.style.display = 'none'; form.style.display = '';
      if (e.message !== 'annullato') toast(e.message, true);
      if (pid) toast('Il video è tra i tuoi progetti: puoi riprovare da lì');
    }
  }
  if (extra && (extra.url || extra.path)) start();
}

// formato scelto: come nel sito. Senza una webcam vera (o con persone che parlano) le clip sono a tutto schermo
async function applyFormat(pid, mode) {
  const proj = await get('/api/p/' + pid);
  const cam = proj.webcam || {};
  let conf = cam.box ? Number(cam.confidence || 0) : 0;
  const W = Number(proj.width || 1920), H = Number(proj.height || 1080);
  if (cam.box && (cam.box[2] > 0.42 * W || cam.box[3] > 0.6 * H)) conf = 0;   // "webcam" grande come mezza inquadratura: e' la persona ripresa
  const m = mode === 'auto' ? (conf >= 0.45 ? 'gaming' : 'podcast') : mode;
  if ((m === 'podcast' || m === 'fit') && proj.webcam) { proj.webcam = null; await put('/api/p/' + pid, proj); }
  await post(`/api/p/${pid}/cliplayout`, { layout: m === 'fit' ? 'fit' : 'auto', apply: false });
}
