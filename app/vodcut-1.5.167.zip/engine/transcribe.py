"""Trascrizione in locale con faster-whisper (gratis, niente cloud).

GPU NVIDIA se disponibile, altrimenti CPU. Il modello viene scaricato la prima volta
(circa 0,5-1,5 GB) e poi resta sul PC.
"""


def available():
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def _add_cuda_dlls():
    """Su Windows le DLL CUDA installate con pip (nvidia-cublas/cudnn) non sono nel PATH."""
    import os
    import sys
    if sys.platform != "win32":
        return
    import site
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        base = os.path.join(sp, "nvidia")
        if not os.path.isdir(base):
            continue
        for sub in os.listdir(base):
            b = os.path.join(base, sub, "bin")
            if os.path.isdir(b):
                try:
                    os.add_dll_directory(b)
                except Exception:
                    pass
                os.environ["PATH"] = b + os.pathsep + os.environ.get("PATH", "")


def has_cuda():
    """C'e' davvero una GPU NVIDIA utilizzabile? (su Mac e sui PC senza NVIDIA: no)"""
    import sys
    if sys.platform == "darwin":
        return False
    try:
        import ctranslate2
        return ctranslate2.get_cuda_device_count() > 0
    except Exception:
        return False


# grandezza indicativa dei modelli (per mostrare l'avanzamento del primo download)
_SIZES_MB = {"small": 484, "large-v3-turbo": 1620}


def _ensure_downloaded(name, log):
    """Il modello si scarica una volta sola: intanto si mostra quanto manca (prima sembrava bloccato)."""
    import os
    import threading
    try:
        from faster_whisper.utils import download_model
    except Exception:
        return
    try:
        download_model(name, local_files_only=True)
        return   # gia' sul PC
    except Exception:
        pass
    tot = _SIZES_MB.get(name, 500)
    hub = os.environ.get("HF_HUB_CACHE") or os.path.join(os.environ.get("HF_HOME") or os.path.join(os.path.expanduser("~"), ".cache", "huggingface"), "hub")
    done = {"v": False}

    def size_mb():
        n = 0
        for root, _, files in os.walk(hub):
            if "faster-whisper-" + name.split("/")[-1] not in root:
                continue
            for f in files:
                try:
                    n += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return n / 1e6

    def watch():
        import time
        while not done["v"]:
            mb = size_mb()
            log(f"Scarico il modello per la trascrizione (una volta sola): {min(99, int(mb / tot * 100))}% · {int(mb)} di ~{tot} MB")
            time.sleep(1)

    log(f"Scarico il modello per la trascrizione (una volta sola, circa {tot} MB)…")
    th = threading.Thread(target=watch, daemon=True)
    th.start()
    try:
        download_model(name)
    except Exception as e:
        raise RuntimeError("Non riesco a scaricare il modello per la trascrizione: controlla la connessione a internet e riprova "
                           f"({str(e)[:80]})") from e
    finally:
        done["v"] = True
    log("Modello scaricato")


def cpu_plan():
    """Quanti pezzi trascrivere insieme sul processore e con quanti core ciascuno.
    Un solo pezzo alla volta usa pochi core: con 2 in parallelo un Mac/PC da 8 core va quasi il doppio piu' veloce."""
    import os
    n = os.cpu_count() or 4
    workers = 1 if n < 6 else 2 if n < 12 else 3
    return workers, max(2, n // workers)


def _load_model(log):
    _add_cuda_dlls()
    from faster_whisper import WhisperModel
    # senza GPU NVIDIA si va dritti sul modello leggero per CPU: niente download inutili da 1,6 GB
    tries = [("large-v3-turbo", "cuda", "float16"), ("small", "cuda", "float16"), ("small", "cpu", "int8")] if has_cuda() else [("small", "cpu", "int8")]
    last = None
    workers, threads = cpu_plan()
    for name, device, ctype in tries:
        try:
            _ensure_downloaded(name, log)
            if device == "cpu":
                m = WhisperModel(name, device=device, compute_type=ctype, cpu_threads=threads, num_workers=workers)
            else:
                m = WhisperModel(name, device=device, compute_type=ctype)
            log(f"Modello {name} su {'GPU' if device == 'cuda' else 'CPU'}")
            return m, device
        except Exception as e:  # driver/cuDNN mancanti -> prova il successivo
            last = e
    if last and "Non riesco a scaricare" in str(last):
        raise last
    raise RuntimeError(f"Impossibile caricare il modello di trascrizione: {last}")


def _collect(model, path, duration, language, beam, progress, cancel, prompt=None):
    # prompt: il testo che ci si aspetta (lo script di una storia) -> il modello sbaglia molto meno le parole
    segments, info = model.transcribe(path, language=language, word_timestamps=True, vad_filter=True, beam_size=beam,
                                      initial_prompt=prompt or None)
    out = []
    for seg in segments:  # la trascrizione vera avviene qui (generatore)
        if cancel and cancel():
            raise RuntimeError("annullato")
        words = []
        for w in (seg.words or []):
            txt = w.word.strip()
            if txt:
                words.append({"w": txt, "a": round(float(w.start), 2), "b": round(float(w.end), 2), "del": False})
        if words:
            out.append({"a": words[0]["a"], "b": words[-1]["b"], "words": words})
        if progress and duration:
            progress(min(0.99, float(seg.end) / duration))
    return out, getattr(info, "language", None)


CHUNK = 300.0      # pezzi da 5 minuti: si trascrivono in parallelo e ognuno si salva appena pronto
OVERLAP = 3.0      # ogni pezzo sborda un po' nel successivo, cosi' le parole a cavallo non si perdono


def _chunk_dir(path, duration, language=None):
    import hashlib
    import os
    from .util import APP_DIR
    try:
        st = os.stat(path)
        key = f"{os.path.abspath(path)}|{st.st_size}|{int(st.st_mtime)}|{round(float(duration), 1)}|{CHUNK}|small1|{language or 'auto'}"
    except OSError:
        key = f"{path}|{duration}"
    d = os.path.join(APP_DIR, "cache", "trascrizioni", hashlib.sha1(key.encode()).hexdigest()[:16])
    os.makedirs(d, exist_ok=True)
    return d


def _extract(path, a, dur, out):
    import subprocess
    from .util import ffmpeg_bin
    subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{a:.3f}", "-i", path, "-t", f"{dur:.3f}", "-vn", "-ac", "1", "-ar", "16000",
                    "-c:a", "pcm_s16le", out], check=True, capture_output=True, creationflags=0x08000000 if __import__("os").name == "nt" else 0)


def detect_language(model, path, duration, log=print):
    """La lingua della live, ascoltata in piu' punti (non solo all'inizio, dove spesso c'e' musica o la sigla):
    se all'inizio c'era una canzone in inglese, prima tutta la live veniva scritta in inglese."""
    import os
    import tempfile
    try:
        from faster_whisper.audio import decode_audio
    except Exception:
        return None
    votes = {}
    d = tempfile.mkdtemp()
    try:
        for f in (0.15, 0.35, 0.55, 0.75, 0.9):
            a = max(0.0, duration * f - 15)
            wav = os.path.join(d, f"l{int(f * 100)}.wav")
            try:
                _extract(path, a, 30.0, wav)
                audio = decode_audio(wav)
                try:
                    lang, prob, _ = model.detect_language(audio, vad_filter=True)
                except TypeError:
                    lang, prob, _ = model.detect_language(audio)
            except Exception as e:
                print("[trascrizione] lingua non letta in un punto:", str(e)[:120], flush=True)
                continue
            votes[lang] = votes.get(lang, 0.0) + float(prob or 0)
    finally:
        import shutil
        shutil.rmtree(d, ignore_errors=True)
    if not votes:
        return None
    best = max(votes, key=votes.get)
    print(f"[trascrizione] lingua: {best} ({', '.join(f'{k} {v:.2f}' for k, v in sorted(votes.items(), key=lambda x: -x[1])[:4])})", flush=True)
    return best


def transcribe_long(model, path, duration, progress=None, cancel=None, language=None, log=print):
    """Live lunga sul processore: a pezzi da 5 minuti, piu' pezzi insieme, e ogni pezzo finito resta salvato.
    Se l'app si chiude (o si aggiorna) a meta', si riparte dai pezzi che mancano invece che da zero."""
    import json
    import os
    import threading
    workers, _ = cpu_plan()
    d = _chunk_dir(path, duration, language)   # pezzi di una trascrizione in un'altra lingua non si riusano
    n = max(1, int((duration + CHUNK - 1) // CHUNK))
    spans = [(k * CHUNK, min(duration, (k + 1) * CHUNK)) for k in range(n)]
    res = {}
    for k in range(n):
        try:
            with open(os.path.join(d, f"p{k:04d}.json"), encoding="utf-8") as f:
                res[k] = json.load(f)
        except Exception:
            pass
    if res:
        log(f"Riprendo la trascrizione da dove era arrivata ({len(res)} di {n} pezzi gia' pronti)")
    part = {}
    lock = threading.Lock()
    err = []

    def report():
        if not progress:
            return
        done = sum(spans[k][1] - spans[k][0] for k in res) + sum(part.values())
        progress(min(0.99, done / max(1.0, duration)))

    def run_one(k, lang):
        a, b = spans[k]
        os.makedirs(d, exist_ok=True)   # la cartella dei pezzi deve esserci anche se qualcosa l'ha tolta nel frattempo
        wav = os.path.join(d, f"p{k:04d}.wav")
        _extract(path, a, (b - a) + (OVERLAP if k < n - 1 else 0.0), wav)

        def prog(x):
            with lock:
                part[k] = x * (b - a)
            report()
        segs, got = _collect(model, wav, (b - a) + OVERLAP, lang, 1, prog, lambda: bool(err) or (cancel and cancel()))
        try:
            os.remove(wav)
        except OSError:
            pass
        out = []
        for sg in segs:   # tempi della live; le parole oltre la fine del pezzo le tiene il pezzo dopo
            ws = [{**w, "a": round(w["a"] + a, 2), "b": round(w["b"] + a, 2)} for w in sg["words"] if k == n - 1 or w["a"] < (b - a)]
            if ws:
                out.append({"a": ws[0]["a"], "b": ws[-1]["b"], "words": ws})
        r = {"segments": out, "language": got}
        tmp = os.path.join(d, f"p{k:04d}.json.part")
        os.makedirs(d, exist_ok=True)
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(r, f)
        os.replace(tmp, os.path.join(d, f"p{k:04d}.json"))
        with lock:
            res[k] = r
            part.pop(k, None)
        report()
        return got

    todo = [k for k in range(n) if k not in res]
    lang = language or next((r.get("language") for r in res.values() if r.get("language")), None)
    if todo and not lang:
        lang = detect_language(model, path, duration, log)
    if todo and not lang:   # la lingua si decide sul primo pezzo, poi vale per tutti (niente pezzi in un'altra lingua)
        lang = run_one(todo.pop(0), None) or None
    queue = list(todo)

    def worker():
        while True:
            with lock:
                if not queue or err:
                    return
                k = queue.pop(0)
            try:
                run_one(k, lang)
            except Exception as e:
                with lock:
                    err.append(e)
                return
    ths = [threading.Thread(target=worker, daemon=True) for _ in range(min(workers, len(queue)))]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    if err:
        raise err[0]
    if cancel and cancel():
        raise RuntimeError("annullato")
    segs = sorted((sg for k in range(n) for sg in res[k]["segments"]), key=lambda x: x["a"])
    # al confine tra due pezzi la stessa parola puo' uscire due volte: si tiene la prima
    last_b, clean = -1.0, []
    for sg in segs:
        ws = [w for w in sg["words"] if w["a"] >= last_b - 0.05]
        if ws:
            last_b = max(last_b, ws[-1]["b"])
            clean.append({"a": ws[0]["a"], "b": ws[-1]["b"], "words": ws})
    segs = clean
    try:   # tutto pronto: i pezzi non servono piu'
        import shutil
        shutil.rmtree(d, ignore_errors=True)
    except Exception:
        pass
    return {"status": "done", "language": lang, "segments": segs}


def transcribe(path, duration, progress=None, cancel=None, language=None, log=print, prompt=None):
    model, device = _load_model(log)
    if device == "cpu" and not prompt and duration and duration > CHUNK * 1.5:
        return transcribe_long(model, path, float(duration), progress, cancel, language, log)
    # voci brevi (storie): ricerca piu' accurata anche su CPU, costa pochi secondi
    beam = 5 if device == "cuda" or (duration and duration < 240) else 1
    if prompt:
        prompt = " ".join(prompt.split()[:120])
    try:
        out, lang = _collect(model, path, duration, language, beam, progress, cancel, prompt)
    except Exception as e:
        if device != "cuda" or "annullato" in str(e):
            raise
        # errore CUDA durante la trascrizione (memoria, DLL): riprova su CPU
        log("GPU non disponibile per la trascrizione, uso la CPU")
        del model
        from faster_whisper import WhisperModel
        model = WhisperModel("small", device="cpu", compute_type="int8")
        out, lang = _collect(model, path, duration, language, 1, progress, cancel, prompt)
    return {"status": "done", "language": lang, "segments": out}


# ---------------------------------------------------------------- lo script incollato corregge le parole
def _nw(w):
    import re
    import unicodedata
    w = unicodedata.normalize("NFKD", str(w).lower())
    return re.sub(r"[^\w]", "", "".join(c for c in w if not unicodedata.combining(c)))


def fix_with_script(tr, script):
    """Le parole sentite scritte come nello script (nomi, marchi, termini: "Claude" e non "Cloud"),
    ai tempi della voce. Solo dove la voce dice (piu' o meno) lo script: quello che hai detto in piu' o in meno resta.
    -> quante parole sono cambiate"""
    import difflib
    sw = [w for w in str(script or "").split() if _nw(w)]
    if not sw:
        return 0
    flat = [w for sg in tr.get("segments") or [] for w in sg.get("words") or [] if not w.get("gap")]
    if not flat:
        return 0
    a = [_nw(x) for x in sw]
    b = [_nw(w["w"]) for w in flat]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    n = 0

    def put(w, txt):
        nonlocal n
        # la punteggiatura della voce resta se lo script non ne ha (i sottotitoli la usano per andare a capo)
        tail = "" if txt[-1:] in ".,!?;:…" else "".join(ch for ch in str(w["w"])[-1:] if ch in ".,!?;:…")
        new = txt + tail
        if new != w["w"]:
            w["w"] = new
            n += 1
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            for k in range(i2 - i1):   # stessa parola: si prende la grafia dello script (maiuscole, accenti)
                put(flat[j1 + k], sw[i1 + k])
        elif op == "replace":
            sa, sb = " ".join(a[i1:i2]), " ".join(b[j1:j2])
            if difflib.SequenceMatcher(None, sa, sb).ratio() < 0.55 or i2 - i1 > 6 or j2 - j1 > 6:
                continue   # qui la voce dice davvero un'altra cosa
            if i2 - i1 == j2 - j1:
                for k in range(i2 - i1):
                    put(flat[j1 + k], sw[i1 + k])
            else:
                # parole unite o divise ("Claude Code" sentito "Cloudcode"): stesso tratto di tempo, parole dello script
                ws = flat[j1:j2]
                m = i2 - i1
                if m < len(ws):
                    # quante parole sentite formano davvero quelle dello script (le altre restano come sono)
                    tgt = "".join(a[i1:i2])
                    best, bk = -1.0, m
                    for kk in range(m, len(ws) + 1):
                        r = difflib.SequenceMatcher(None, tgt, "".join(b[j1:j1 + kk])).ratio()
                        if r > best + 1e-9:
                            best, bk = r, kk
                    if best < 0.75:
                        continue
                    ws = ws[:bk]
                t1 = float(ws[-1]["b"])
                if m < len(ws):
                    for k in range(m):
                        put(ws[k], sw[i1 + k])
                    ws[m - 1]["b"] = round(t1, 3)
                    for w in ws[m:]:
                        w["del"] = True
                        w["gone"] = True
                else:
                    # meno parole sentite: la prima prende il testo in piu'
                    for k, w in enumerate(ws):
                        txt = sw[i1 + k] if k < len(ws) - 1 else " ".join(sw[i1 + k:i2])
                        put(w, txt)
    # parole assorbite da quelle dello script: tolte dai sottotitoli
    for sg in tr.get("segments") or []:
        sg["words"] = [w for w in sg.get("words") or [] if not w.get("gone")]
    return n
