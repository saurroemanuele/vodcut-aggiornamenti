// NoonFrame - scegli un pezzo della live (inizio e fine): per le clip a mano e per allungare o accorciare una clip.
// Sopra tutta la live (con le clip che ci sono gia'), sotto 6 minuti di dettaglio con le maniglie di inizio e fine.
import { get, h, icon, toast, mediaUrl, thumbUrl } from './lib.js';

const mmss = (t) => { t = Math.max(0, Math.round(t || 0)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); };
const hms = (t) => { t = Math.max(0, Math.round(t || 0)); const hh = Math.floor(t / 3600); return (hh ? hh + ':' : '') + String(Math.floor(t / 60) % 60).padStart(hh ? 2 : 1, '0') + ':' + String(t % 60).padStart(2, '0'); };

// o: { pid (progetto da cui prendere video e anteprime), duration, source, vcodec, a, b, marks: [[a, b]], from: [a, b] (pezzo di adesso),
//      title, intro, okLabel, withName, maxDur, run: async ({a, b, name}, setBusy) => {...} (fa il lavoro; se lancia un errore la finestra resta aperta) }
export function pickRange(o) {
  const D = +o.duration || 0;
  if (!D) { toast('Video della live non pronto', true); return; }
  const MAXD = o.maxDur || 180, MIND = 3, WIN = 360, pid = o.pid;
  let a = Math.max(0, +o.a || 0), b = Math.min(D, o.b != null ? +o.b : a + 30);
  let playing = false, dragging = null, creating = false, hasVideo = false, stillT = a;
  const bg = h('div', { class: 'modal-bg cg-modal-bg' });
  const vid = h('video', { class: 'cg-mvid', playsinline: true, preload: 'auto' });
  const still = h('img', { class: 'cg-mstill', alt: '' });
  const stage = h('div', { class: 'cg-mstage cg-mmstage' }, vid, still);
  const okCodec = !o.vcodec || ['h264', 'vp8', 'vp9'].includes(o.vcodec);
  const showStill = (t) => { if (!hasVideo) still.src = thumbUrl(pid, Math.min(D - 0.5, Math.max(0, t)), 480); };
  const useVideo = (src) => { vid.src = src; hasVideo = true; still.style.display = 'none'; vid.currentTime = a; };
  if (okCodec && o.source) useVideo(mediaUrl(o.source));
  else {
    showStill(a);
    const tryProxy = async () => {
      if (!bg.isConnected) return;
      try { const r = await get(`/api/p/${pid}/proxy?h=480`); if (r.ready) return useVideo(mediaUrl(r.path)); if (r.error) return; } catch (e) { return; }
      setTimeout(tryProxy, 2000);
    };
    setTimeout(tryProxy, 0);
  }
  const cur = () => (hasVideo ? vid.currentTime : stillT);
  vid.addEventListener('error', () => { if (hasVideo) { hasVideo = false; still.style.display = ''; showStill(stillT); } });
  const seek = (t) => { t = Math.max(0, Math.min(D, t)); stillT = t; if (hasVideo) vid.currentTime = t; else showStill(t); paint(); };

  // panoramica di tutta la live
  const ov = h('div', { class: 'cg-ov', 'aria-label': 'Tutta la live' });
  const ovSel = h('div', { class: 'cg-ov-sel' }), ovHead = h('div', { class: 'cg-ov-head' });
  ov.append(...(o.marks || []).map(([x, y]) => h('div', { class: 'cg-ov-clip', style: { left: (x / D * 100) + '%', width: Math.max(0.3, (y - x) / D * 100) + '%' } })),
    ...(o.from ? [h('div', { class: 'cg-ov-was', style: { left: (o.from[0] / D * 100) + '%', width: Math.max(0.3, (o.from[1] - o.from[0]) / D * 100) + '%' } })] : []), ovSel, ovHead);
  ov.addEventListener('pointerdown', (e) => {
    const r = ov.getBoundingClientRect(); const t = (e.clientX - r.left) / r.width * D;
    const len = b - a; a = Math.max(0, Math.min(D - len, t - len / 2)); b = a + len; seek(a);
  });
  // dettaglio: 6 minuti intorno alla parte scelta, con le maniglie
  const det = h('div', { class: 'cg-det' });
  const strip = h('div', { class: 'cg-strip' });
  const was = o.from ? h('div', { class: 'cg-dwas' }) : null;
  const sel = h('div', { class: 'cg-dsel' }, h('div', { class: 'cg-dh l', 'aria-label': 'Inizio' }), h('div', { class: 'cg-dh r', 'aria-label': 'Fine' }));
  const head = h('div', { class: 'cg-dhead' });
  const ticks = h('div', { class: 'cg-ticks' });
  det.append(...[strip, ticks, was, sel, head].filter(Boolean));
  let w0 = 0, stripKey = '';
  const span = () => Math.min(WIN, D);
  const winOf = () => { const mid = (a + b) / 2; return Math.max(0, Math.min(Math.max(0, D - WIN), mid - WIN / 2)); };
  const X = (t) => ((t - w0) / span() * 100) + '%';
  const info = h('span', { class: 'cg-mminfo' });
  const tooLong = h('span', { class: 'cg-mmwarn' }, 'Massimo ' + Math.round(MAXD / 60) + ' minuti per clip');
  const diff = h('span', { class: 'cg-mmdiff' });
  const name = o.withName ? h('input', { class: 'cg-q', placeholder: 'Nome della clip (facoltativo)', maxlength: '70', 'aria-label': 'Nome della clip' }) : null;
  const go = h('button', { class: 'btn primary', type: 'button', onclick: () => create() }, icon('scissors', 14, '#fff', 2), o.okLabel || 'Crea la clip');
  function paint() {
    w0 = winOf();
    const sp = span();
    const key = String(Math.round(w0));
    if (key !== stripKey) {
      stripKey = key;
      strip.replaceChildren(...Array.from({ length: 8 }, (_, i) => h('img', { src: thumbUrl(pid, Math.min(D - 0.5, w0 + (i + 0.5) * sp / 8), 72), alt: '', draggable: 'false' })));
      const step = sp > 240 ? 60 : 30;
      const t0 = Math.ceil(w0 / step) * step;
      ticks.replaceChildren(...Array.from({ length: Math.max(0, Math.floor((w0 + sp - t0) / step) + 1) }, (_, i) => t0 + i * step).map((t) => h('span', { style: { left: X(t) } }, hms(t))));
    }
    sel.style.left = X(a); sel.style.width = ((b - a) / sp * 100) + '%';
    if (was) { was.style.left = X(o.from[0]); was.style.width = ((o.from[1] - o.from[0]) / sp * 100) + '%'; }
    const t = cur();
    head.style.left = X(Math.max(w0, Math.min(w0 + sp, t))); head.style.display = t >= w0 && t <= w0 + sp ? '' : 'none';
    ovSel.style.left = (a / D * 100) + '%'; ovSel.style.width = Math.max(0.4, (b - a) / D * 100) + '%';
    ovHead.style.left = (t / D * 100) + '%';
    info.textContent = hms(a) + ' – ' + hms(b) + ' · ' + mmss(b - a);
    if (o.from) {
      const da = o.from[0] - a, db = b - o.from[1];
      const part = (v, l1, l2) => (Math.abs(v) < 0.5 ? null : (v > 0 ? '+' : '−') + Math.round(Math.abs(v)) + ' s ' + (v > 0 ? l1 : l2));
      diff.textContent = [part(da, 'prima', 'tolti all\'inizio'), part(db, 'dopo', 'tolti alla fine')].filter(Boolean).join(' · ');
    }
    tooLong.style.display = b - a > MAXD - 0.5 ? '' : 'none';
    go.disabled = creating || b - a < MIND || (o.from && Math.abs(a - o.from[0]) < 0.2 && Math.abs(b - o.from[1]) < 0.2);
  }
  const tAt = (x, w) => { const r = det.getBoundingClientRect(); return w + Math.max(0, Math.min(1, (x - r.left) / r.width)) * span(); };
  det.addEventListener('pointerdown', (e) => {
    const t = tAt(e.clientX, w0);
    const px = det.getBoundingClientRect().width / span();
    const near = (v) => Math.abs(t - v) * px < 12;
    const kind = e.target.closest('.cg-dh.l') || near(a) ? 'a' : e.target.closest('.cg-dh.r') || near(b) ? 'b' : (t > a && t < b) ? 'move' : 'seek';
    if (kind === 'seek') { seek(t); return; }
    dragging = { kind, t0: t, a0: a, b0: b, w: w0 };
    det.setPointerCapture(e.pointerId);
  });
  det.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const t = tAt(e.clientX, dragging.w);
    if (dragging.kind === 'a') { a = Math.max(0, Math.min(b - MIND, Math.max(b - MAXD, t))); seek(a); }
    else if (dragging.kind === 'b') { b = Math.min(D, Math.max(a + MIND, Math.min(a + MAXD, t))); seek(Math.max(a, b - 2)); }
    else { const len = dragging.b0 - dragging.a0; a = Math.max(0, Math.min(D - len, dragging.a0 + t - dragging.t0)); b = a + len; paint(); }
  });
  det.addEventListener('pointerup', () => { if (dragging && dragging.kind === 'move') seek(a); dragging = null; });
  const setA = () => { const t = cur(); a = Math.max(0, Math.min(t, D - MIND)); if (b - a > MAXD) b = a + MAXD; if (b < a + MIND) b = Math.min(D, a + 30); paint(); };
  const setB = () => { const t = cur(); b = Math.min(D, Math.max(t, MIND)); if (b - a > MAXD) a = b - MAXD; if (a > b - MIND) a = Math.max(0, b - 30); paint(); };
  const playBtn = h('button', { class: 'btn', type: 'button', onclick: () => togglePlay() }, icon('play', 13, 'currentColor'), 'Guarda la parte scelta');
  function togglePlay() {
    if (!hasVideo) return toast('Preparo il video, un attimo', true);
    if (playing) { vid.pause(); return; }
    if (vid.currentTime < a || vid.currentTime >= b - 0.2) vid.currentTime = a;
    vid.play().catch(() => {});
  }
  vid.addEventListener('play', () => { playing = true; playBtn.replaceChildren(icon('pause', 13, 'currentColor'), 'Pausa'); });
  vid.addEventListener('pause', () => { playing = false; playBtn.replaceChildren(icon('play', 13, 'currentColor'), 'Guarda la parte scelta'); });
  vid.addEventListener('timeupdate', () => { stillT = vid.currentTime; if (playing && vid.currentTime >= b) { vid.pause(); vid.currentTime = b; } if (!dragging) paint(); });
  vid.addEventListener('seeked', () => paint());
  const idle = () => go.replaceChildren(icon('scissors', 14, '#fff', 2), o.okLabel || 'Crea la clip');
  async function create() {
    if (creating || go.disabled) return;
    creating = true; go.disabled = true; go.replaceChildren(h('span', { class: 'spinner sm' }), 'Un attimo…');
    try {
      await o.run({ a: +a.toFixed(2), b: +b.toFixed(2), name: name ? name.value.trim() : '' }, (msg) => go.replaceChildren(h('span', { class: 'spinner sm' }), msg || 'Un attimo…'));
      close();
    } catch (e) {
      creating = false; idle(); paint();
      toast(e.message || String(e), true);
    }
  }
  const close = () => { vid.pause(); vid.removeAttribute('src'); vid.load(); bg.remove(); removeEventListener('keydown', key, true); };
  const key = (e) => {
    if (name && e.target === name) { if (e.key === 'Enter') create(); if (e.key === 'Escape') close(); return; }
    if (e.key === 'Escape') close();
    else if (e.key === ' ') { e.preventDefault(); togglePlay(); }
    else if (e.key === 'i' || e.key === 'I') setA();
    else if (e.key === 'o' || e.key === 'O') setB();
    else if (e.key === 'ArrowLeft') seek(cur() - (e.shiftKey ? 10 : 1));
    else if (e.key === 'ArrowRight') seek(cur() + (e.shiftKey ? 10 : 1));
    else return;
    e.stopPropagation();
  };
  const box = h('div', { class: 'cg-modal cg-mm', role: 'dialog', 'aria-modal': 'true', 'aria-label': o.title },
    h('button', { class: 'iconbtn cg-mx', 'aria-label': 'Chiudi', onclick: close }, icon('x', 18, 'currentColor', 2)),
    stage,
    h('div', { class: 'cg-mmside' },
      h('h2', null, o.title),
      o.intro ? h('p', { class: 'muted' }, o.intro) : null,
      h('div', { class: 'cg-mmlbl' }, 'Tutta la live', h('small', null, o.from ? 'la parte tratteggiata è la clip di adesso' : 'le strisce chiare sono le clip che hai già')), ov,
      h('div', { class: 'cg-mmlbl' }, 'Inizio e fine', h('small', null, 'trascina i bordi o sposta la parte scelta')), det,
      h('div', { class: 'cg-mmrow' }, info, o.from ? diff : null, tooLong),
      h('div', { class: 'cg-mmrow' },
        h('button', { class: 'btn sm', type: 'button', 'data-tip': 'Tasto I', onclick: setA }, 'Inizio qui'),
        h('button', { class: 'btn sm', type: 'button', 'data-tip': 'Tasto O', onclick: setB }, 'Fine qui'),
        playBtn),
      name,
      h('div', { class: 'cg-mmrow end' }, h('button', { class: 'btn ghost', type: 'button', onclick: close }, 'Annulla'), go)));
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
  bg.append(box); document.body.append(bg); addEventListener('keydown', key, true);
  paint();
}
