// NoonFrame - grafiche animate (motion graphics): numeri che contano, grafici che crescono, liste, confronti, passi.
// Disegnate su una tela a ogni fotogramma, come i testi animati (kinetic.js): in anteprima dal vivo, per l'esportazione
// l'app prepara i fotogrammi PNG. Stile moderno: schede scure in vetro, un colore d'accento, Inter.

// [id, nome, descrizione, esempio]
export const MOTION_TPLS = [
  ['numero', 'Numero', 'Una cifra che conta fino al valore', { title: 'Fatturato in un anno', value: '+240%' }],
  ['barre', 'Barre', 'Grafico a barre che cresce', { title: 'Clienti al mese', items: [{ label: 'Gen', value: '12' }, { label: 'Mar', value: '28' }, { label: 'Mag', value: '47' }, { label: 'Lug', value: '90' }] }],
  ['linea', 'Crescita', 'Linea che sale con il valore finale', { title: 'Iscritti', items: [{ value: '2' }, { value: '3' }, { value: '2.6' }, { value: '5' }, { value: '7' }, { value: '11' }], value: '11K' }],
  ['lista', 'Checklist', 'Punti che si spuntano uno alla volta', { title: 'Cosa serve', items: [{ label: 'Un\'offerta chiara' }, { label: 'Un canale di vendita' }, { label: 'Processi scritti' }] }],
  ['confronto', 'Confronto', 'Prima e dopo, o questo contro quello', { items: [{ label: 'Lavoro', value: 'Tempo = soldi' }, { label: 'Azienda', value: 'Sistemi = soldi' }] }],
  ['passi', 'Passi', 'Passaggi collegati da una linea', { title: 'Il metodo', items: [{ label: 'Offerta' }, { label: 'Traffico' }, { label: 'Vendita' }] }],
  ['progresso', 'Percentuale', 'Anello che si riempie', { title: 'Tasso di conversione', value: '68%' }],
];
export const motionName = (id) => (MOTION_TPLS.find((m) => m[0] === id) || [0, 'Grafica'])[1];
export const MOTION_ACCENTS = ['#4F8CFF', '#8B7CFF', '#22C58B', '#FFB020', '#FF5C7A', '#FFFFFF'];

const cl = (x) => Math.max(0, Math.min(1, x));
const eOut = (p) => 1 - Math.pow(1 - cl(p), 3);
const eInOut = (p) => { p = cl(p); return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; };
const eBack = (p) => { p = cl(p); const c1 = 1.4, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
const FONT = 'Inter, "Plus Jakarta Sans", system-ui, sans-serif';

function hexA(hex, a) {
  let x = String(hex || '#4F8CFF').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
}
function mix(hex, k) {   // schiarisce verso il bianco
  let x = String(hex || '#4F8CFF').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  const f = (i) => Math.round(parseInt(x.slice(i, i + 2), 16) * (1 - k) + 255 * k);
  return `rgb(${f(0)},${f(2)},${f(4)})`;
}
// "12", "1.200", "+40%", "10K€" -> {pre, num, dec, post}
export function parseNum(s) {
  const m = String(s ?? '').match(/^(\D*?)(-?\d[\d.,]*)(.*)$/);
  if (!m) return null;
  let raw = m[2], dec = 0;
  if (/,\d{1,2}$/.test(raw)) { dec = raw.split(',')[1].length; raw = raw.replace(/\./g, '').replace(',', '.'); }
  else if (/\.\d{1,2}$/.test(raw) && !/\.\d{3}/.test(raw)) { dec = raw.split('.')[1].length; }
  else raw = raw.replace(/[.,]/g, '');
  const num = parseFloat(raw);
  return Number.isFinite(num) ? { pre: m[1], num, dec, post: m[3], sep: /\d\.\d{3}/.test(m[2]) } : null;
}
function fmtNum(p, v) {
  let s = v.toFixed(p.dec);
  if (p.sep) s = s.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  if (p.dec && /,/.test(String(p.num))) s = s.replace('.', ',');
  return p.pre + s + p.post;
}
function counting(val, k) {
  const p = parseNum(val);
  if (!p) return String(val ?? '');
  return fmtNum(p, p.num * eOut(k));
}
function rr(g, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function fitText(g, txt, maxW, size, weight) {
  let s = size;
  g.font = `${weight} ${s}px ${FONT}`;
  while (s > 6 && g.measureText(txt).width > maxW) { s *= 0.92; g.font = `${weight} ${s}px ${FONT}`; }
  return s;
}
// scheda in vetro scuro con bordo sottile e luce in alto
function card(g, x, y, w, h, u, acc, k) {
  g.save();
  g.globalAlpha = cl(k * 1.4);
  g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 6 * u; g.shadowOffsetY = 2 * u;
  rr(g, x, y, w, h, 3.2 * u);
  const bg = g.createLinearGradient(0, y, 0, y + h);
  bg.addColorStop(0, 'rgba(24,30,46,.92)'); bg.addColorStop(1, 'rgba(10,13,22,.92)');
  g.fillStyle = bg; g.fill();
  g.shadowColor = 'transparent';
  // bagliore del colore d'accento in un angolo
  const gl = g.createRadialGradient(x + w * 0.85, y, 0, x + w * 0.85, y, w * 0.7);
  gl.addColorStop(0, hexA(acc, 0.28)); gl.addColorStop(1, hexA(acc, 0));
  g.save(); rr(g, x, y, w, h, 3.2 * u); g.clip(); g.fillStyle = gl; g.fillRect(x, y, w, h); g.restore();
  rr(g, x + 0.5, y + 0.5, w - 1, h - 1, 3.2 * u);
  const bd = g.createLinearGradient(0, y, 0, y + h);
  bd.addColorStop(0, 'rgba(255,255,255,.22)'); bd.addColorStop(1, 'rgba(255,255,255,.06)');
  g.strokeStyle = bd; g.lineWidth = Math.max(1, 0.18 * u); g.stroke();
  g.restore();
}
function title(g, txt, x, y, maxW, u, k) {
  if (!txt) return;
  g.save();
  g.globalAlpha = cl(k * 2);
  const s = fitText(g, String(txt).toUpperCase(), maxW, 2.3 * u, 700);
  g.fillStyle = 'rgba(255,255,255,.62)';
  g.textBaseline = 'top';
  g.fillText(String(txt).toUpperCase(), x + (1 - eOut(k)) * 2 * u, y);
  g.restore();
  return s;
}

// dimensioni della tela per ogni modello (in unita' = 1% dell'altezza del video)
const SIZE = { numero: [44, 26], barre: [56, 38], linea: [56, 34], lista: [52, 0], confronto: [64, 26], passi: [70, 26], progresso: [40, 30] };

export function motionSize(spec, H) {
  const u = H / 100;
  const [w, h0] = SIZE[spec.tpl] || SIZE.numero;
  const n = Math.max(1, Math.min(5, (spec.items || []).length || 3));
  const h = spec.tpl === 'lista' ? 11 + n * 7.2 : h0;
  const pad = 4;   // spazio per l'ombra
  return [Math.round((w + pad * 2) * u), Math.round((h + pad * 2) * u), u, pad * u];
}

// disegna la grafica al tempo t (secondi dall'inizio della clip) sulla tela cv
export function drawMotion(spec, H, t, dur, cv) {
  cv = cv || document.createElement('canvas');
  const [W0, H0, u, P] = motionSize(spec, H);
  if (cv.width !== W0) cv.width = W0;
  if (cv.height !== H0) cv.height = H0;
  const g = cv.getContext('2d');
  g.clearRect(0, 0, W0, H0);
  const acc = spec.accent || '#4F8CFF';
  const w = W0 - 2 * P, h = H0 - 2 * P, x = P, y = P;
  // entrata della scheda (0,5 s); l'uscita la fa la clip (dissolvenza), cosi' dopo 2 s il fotogramma e' fermo
  const kin = eOut(t / 0.5);
  const k = kin;
  if (k <= 0) return cv;
  g.save();
  const sc = 0.92 + 0.08 * eBack(t / 0.55);
  g.globalAlpha = k;
  g.translate(W0 / 2, H0 / 2 + (1 - kin) * 3 * u); g.scale(sc, sc); g.translate(-W0 / 2, -H0 / 2);
  card(g, x, y, w, h, u, acc, kin);
  const T = Math.max(0, t - 0.2);   // il contenuto parte dopo la scheda
  const it = (spec.items || []).slice(0, 5);
  g.textBaseline = 'alphabetic';
  const tp = spec.tpl;
  if (tp === 'numero') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    const v = counting(spec.value, T / 1.1);
    const s = fitText(g, String(spec.value || ''), w - 6.4 * u, 11 * u, 800);
    g.font = `800 ${s}px ${FONT}`;
    const gr = g.createLinearGradient(0, y + 8 * u, 0, y + 20 * u);
    gr.addColorStop(0, '#FFFFFF'); gr.addColorStop(1, mix(acc, 0.35));
    g.fillStyle = gr;
    g.fillText(v, x + 3.2 * u, y + 19 * u);
    const bw = (w - 6.4 * u) * eInOut((T - 0.3) / 0.9);
    rr(g, x + 3.2 * u, y + h - 4 * u, w - 6.4 * u, 0.8 * u, 0.4 * u); g.fillStyle = 'rgba(255,255,255,.08)'; g.fill();
    if (bw > 0) { const bg = g.createLinearGradient(x, 0, x + w, 0); bg.addColorStop(0, acc); bg.addColorStop(1, mix(acc, 0.45)); rr(g, x + 3.2 * u, y + h - 4 * u, bw, 0.8 * u, 0.4 * u); g.fillStyle = bg; g.fill(); }
  } else if (tp === 'barre') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    const vals = it.map((i) => (parseNum(i.value) || { num: 0 }).num);
    const mx = Math.max(1e-6, ...vals.map(Math.abs));
    const n = Math.max(1, it.length), gx = x + 3.2 * u, gw = w - 6.4 * u, base = y + h - 6 * u, top = y + 11 * u;
    const bw = Math.min(8 * u, gw / n * 0.56), step = gw / n;
    g.strokeStyle = 'rgba(255,255,255,.07)'; g.lineWidth = Math.max(1, 0.12 * u);
    for (let l = 0; l < 3; l++) { const ly = top + (base - top) * l / 3; g.beginPath(); g.moveTo(gx, ly); g.lineTo(gx + gw, ly); g.stroke(); }
    it.forEach((i, j) => {
      const kk = eOut((T - 0.15 - j * 0.12) / 0.8);
      const bh = (base - top) * (vals[j] / mx) * kk;
      const bx = gx + step * j + (step - bw) / 2;
      const last = j === n - 1;
      const gr = g.createLinearGradient(0, base - bh, 0, base);
      if (last) { gr.addColorStop(0, mix(acc, 0.35)); gr.addColorStop(1, acc); } else { gr.addColorStop(0, 'rgba(255,255,255,.34)'); gr.addColorStop(1, 'rgba(255,255,255,.12)'); }
      if (bh > 0.5) { rr(g, bx, base - bh, bw, bh, 1.1 * u); g.fillStyle = gr; g.fill(); }
      if (last && bh > 0.5) { g.save(); g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 4 * u; rr(g, bx, base - bh, bw, bh, 1.1 * u); g.fillStyle = hexA(acc, 0.25); g.fill(); g.restore(); }
      g.globalAlpha = k * cl(kk * 1.5);
      g.font = `700 ${2.4 * u}px ${FONT}`; g.textAlign = 'center';
      g.fillStyle = last ? '#fff' : 'rgba(255,255,255,.8)';
      g.fillText(counting(i.value, kk), bx + bw / 2, base - bh - 1.2 * u);
      g.font = `600 ${2 * u}px ${FONT}`; g.fillStyle = 'rgba(255,255,255,.55)';
      g.fillText(String(i.label || '').slice(0, 12), bx + bw / 2, base + 3 * u);
      g.globalAlpha = k; g.textAlign = 'left';
    });
  } else if (tp === 'linea') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 20 * u, u, T / 0.4);
    const vals = it.map((i) => (parseNum(i.value) || { num: 0 }).num);
    if (vals.length < 2) vals.unshift(0);
    const mn = Math.min(...vals), mx = Math.max(...vals), rg = Math.max(1e-6, mx - mn);
    const gx = x + 3.2 * u, gw = w - 6.4 * u, top = y + 11 * u, base = y + h - 4 * u;
    const pts = vals.map((v, j) => [gx + gw * j / (vals.length - 1), base - (base - top) * (v - mn) / rg]);
    const pr = eInOut((T - 0.1) / 1.2);
    const upto = pr * (pts.length - 1), ni = Math.floor(upto), fr = upto - ni;
    const path = pts.slice(0, ni + 1);
    if (ni < pts.length - 1) path.push([pts[ni][0] + (pts[ni + 1][0] - pts[ni][0]) * fr, pts[ni][1] + (pts[ni + 1][1] - pts[ni][1]) * fr]);
    if (path.length > 1) {
      const ar = g.createLinearGradient(0, top, 0, base); ar.addColorStop(0, hexA(acc, 0.35)); ar.addColorStop(1, hexA(acc, 0));
      g.beginPath(); g.moveTo(path[0][0], base); path.forEach(([px, py]) => g.lineTo(px, py)); g.lineTo(path[path.length - 1][0], base); g.closePath(); g.fillStyle = ar; g.fill();
      g.beginPath(); path.forEach(([px, py], j) => (j ? g.lineTo(px, py) : g.moveTo(px, py)));
      g.strokeStyle = mix(acc, 0.2); g.lineWidth = 0.7 * u; g.lineJoin = 'round'; g.lineCap = 'round';
      g.save(); g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 3 * u; g.stroke(); g.restore();
      const [ex, ey] = path[path.length - 1];
      const pulse = 1;
      g.beginPath(); g.arc(ex, ey, 1.2 * u * pulse, 0, Math.PI * 2); g.fillStyle = '#fff'; g.fill();
      g.beginPath(); g.arc(ex, ey, 2.4 * u * pulse, 0, Math.PI * 2); g.fillStyle = hexA(acc, 0.3); g.fill();
    }
    if (spec.value) {
      g.globalAlpha = k * cl((T - 0.9) / 0.4);
      const s = fitText(g, String(spec.value), 16 * u, 5 * u, 800);
      g.font = `800 ${s}px ${FONT}`; g.textAlign = 'right'; g.fillStyle = '#fff';
      g.fillText(counting(spec.value, (T - 0.2) / 1.1), x + w - 3.2 * u, y + 7.6 * u);
      g.textAlign = 'left'; g.globalAlpha = k;
    }
  } else if (tp === 'lista') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    it.forEach((i, j) => {
      const kk = eOut((T - 0.2 - j * 0.28) / 0.45);
      const ry = y + 9.5 * u + j * 7.2 * u;
      g.globalAlpha = k * kk;
      const ox = (1 - kk) * 4 * u;
      rr(g, x + 2.4 * u + ox, ry, w - 4.8 * u, 5.8 * u, 1.6 * u); g.fillStyle = 'rgba(255,255,255,.05)'; g.fill();
      const cx = x + 5.6 * u + ox, cy = ry + 2.9 * u, ck = eOut((T - 0.35 - j * 0.28) / 0.35);
      g.beginPath(); g.arc(cx, cy, 1.7 * u, 0, Math.PI * 2); g.fillStyle = ck > 0 ? acc : 'rgba(255,255,255,.15)'; g.fill();
      if (ck > 0) {
        g.beginPath(); g.moveTo(cx - 0.8 * u, cy); const p1 = [cx - 0.2 * u, cy + 0.7 * u], p2 = [cx + 0.9 * u, cy - 0.7 * u];
        g.lineTo(cx - 0.8 * u + (p1[0] - cx + 0.8 * u) * cl(ck * 2), cy + (p1[1] - cy) * cl(ck * 2));
        if (ck > 0.5) g.lineTo(p1[0] + (p2[0] - p1[0]) * cl(ck * 2 - 1), p1[1] + (p2[1] - p1[1]) * cl(ck * 2 - 1));
        g.strokeStyle = '#fff'; g.lineWidth = 0.45 * u; g.lineCap = 'round'; g.lineJoin = 'round'; g.stroke();
      }
      const s = fitText(g, String(i.label || ''), w - 13 * u, 2.3 * u, 650);
      g.font = `650 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textBaseline = 'middle';
      g.fillText(String(i.label || ''), x + 8.8 * u + ox, cy + 0.1 * u); g.textBaseline = 'alphabetic';
    });
    g.globalAlpha = k;
  } else if (tp === 'confronto') {
    const a = it[0] || {}, b = it[1] || {};
    const cw = (w - 9 * u) / 2;
    [[a, x + 2.4 * u, false, -1], [b, x + 6.6 * u + cw, true, 1]].forEach(([o, cx, good, dir], j) => {
      const kk = eOut((T - 0.1 - j * 0.25) / 0.55);
      g.globalAlpha = k * kk;
      const ox = (1 - kk) * 5 * u * dir;
      rr(g, cx + ox, y + 2.4 * u, cw, h - 4.8 * u, 2.2 * u);
      g.fillStyle = good ? hexA(acc, 0.16) : 'rgba(255,255,255,.04)'; g.fill();
      if (good) { g.strokeStyle = hexA(acc, 0.55); g.lineWidth = Math.max(1, 0.18 * u); g.stroke(); }
      const ic = [cx + ox + 3.6 * u, y + 7 * u];
      g.beginPath(); g.arc(ic[0], ic[1], 1.8 * u, 0, Math.PI * 2); g.fillStyle = good ? acc : 'rgba(255,90,110,.85)'; g.fill();
      g.strokeStyle = '#fff'; g.lineWidth = 0.45 * u; g.lineCap = 'round'; g.beginPath();
      if (good) { g.moveTo(ic[0] - 0.8 * u, ic[1]); g.lineTo(ic[0] - 0.15 * u, ic[1] + 0.7 * u); g.lineTo(ic[0] + 0.9 * u, ic[1] - 0.7 * u); }
      else { g.moveTo(ic[0] - 0.7 * u, ic[1] - 0.7 * u); g.lineTo(ic[0] + 0.7 * u, ic[1] + 0.7 * u); g.moveTo(ic[0] + 0.7 * u, ic[1] - 0.7 * u); g.lineTo(ic[0] - 0.7 * u, ic[1] + 0.7 * u); }
      g.stroke();
      let s = fitText(g, String(o.label || ''), cw - 9 * u, 3 * u, 800);
      g.font = `800 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textBaseline = 'middle';
      g.fillText(String(o.label || ''), cx + ox + 6.6 * u, ic[1] + 0.1 * u);
      s = fitText(g, String(o.value || ''), cw - 5 * u, 2.2 * u, 550);
      g.font = `550 ${s}px ${FONT}`; g.fillStyle = good ? 'rgba(255,255,255,.9)' : 'rgba(255,255,255,.55)';
      g.fillText(String(o.value || ''), cx + ox + 2.4 * u, y + 14.5 * u); g.textBaseline = 'alphabetic';
    });
    // VS al centro
    const kv = eBack((T - 0.45) / 0.4);
    if (kv > 0) {
      g.globalAlpha = k;
      const vx = x + w / 2, vy = y + h / 2;
      g.save(); g.translate(vx, vy); g.scale(kv, kv);
      g.beginPath(); g.arc(0, 0, 2.8 * u, 0, Math.PI * 2); g.fillStyle = '#0B0F18'; g.fill(); g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = Math.max(1, 0.18 * u); g.stroke();
      g.font = `800 ${2 * u}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff'; g.fillText('VS', 0, 0.1 * u);
      g.restore(); g.textAlign = 'left'; g.textBaseline = 'alphabetic';
    }
  } else if (tp === 'passi') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    const n = Math.max(1, it.length), gx = x + 7 * u, gw = w - 14 * u, cy = y + 13 * u;
    const lp = eInOut((T - 0.2) / (0.28 * n + 0.2));
    g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(gx, cy); g.lineTo(gx + gw, cy); g.stroke();
    const lg = g.createLinearGradient(gx, 0, gx + gw, 0); lg.addColorStop(0, acc); lg.addColorStop(1, mix(acc, 0.4));
    g.strokeStyle = lg; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(gx, cy); g.lineTo(gx + gw * (n > 1 ? lp : 1), cy); g.stroke();
    it.forEach((i, j) => {
      const px = n > 1 ? gx + gw * j / (n - 1) : gx + gw / 2;
      const kk = eBack((T - 0.2 - j * 0.28) / 0.4);
      if (kk <= 0) return;
      g.save(); g.translate(px, cy); g.scale(kk, kk);
      g.beginPath(); g.arc(0, 0, 2.6 * u, 0, Math.PI * 2);
      const cg = g.createLinearGradient(0, -2.6 * u, 0, 2.6 * u); cg.addColorStop(0, mix(acc, 0.3)); cg.addColorStop(1, acc);
      g.fillStyle = cg; g.shadowColor = hexA(acc, 0.7); g.shadowBlur = 3 * u; g.fill(); g.shadowBlur = 0;
      g.font = `800 ${2.2 * u}px ${FONT}`; g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(j + 1), 0, 0.15 * u);
      g.restore();
      g.globalAlpha = k * cl(kk);
      const s = fitText(g, String(i.label || ''), gw / n + 4 * u, 2.1 * u, 650);
      g.font = `650 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textAlign = 'center'; g.fillText(String(i.label || ''), px, cy + 6.4 * u);
      g.textAlign = 'left'; g.globalAlpha = k;
    });
  } else if (tp === 'progresso') {
    const p = parseNum(spec.value) || { num: 0 };
    const pct = Math.max(0, Math.min(100, p.num)) / 100;
    const cx = x + w / 2, cy = y + h / 2 - 1.5 * u, r = Math.min(w, h) * 0.3;
    const pr = eInOut((T - 0.1) / 1.2);
    g.lineCap = 'round';
    g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.strokeStyle = 'rgba(255,255,255,.08)'; g.lineWidth = 1.4 * u; g.stroke();
    if (pr > 0) {
      const ag = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r); ag.addColorStop(0, mix(acc, 0.4)); ag.addColorStop(1, acc);
      g.save(); g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 3 * u;
      g.beginPath(); g.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * pct * pr); g.strokeStyle = ag; g.lineWidth = 1.4 * u; g.stroke(); g.restore();
    }
    const s = fitText(g, String(spec.value || ''), r * 1.5, r * 0.62, 800);
    g.font = `800 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(counting(spec.value, (T - 0.1) / 1.2), cx, cy + 0.2 * u);
    if (spec.title) { const s2 = fitText(g, String(spec.title), w - 6 * u, 1.9 * u, 650); g.font = `650 ${s2}px ${FONT}`; g.fillStyle = 'rgba(255,255,255,.62)'; g.fillText(String(spec.title), cx, y + h - 3 * u); }
    g.textAlign = 'left'; g.textBaseline = 'alphabetic';
  }
  g.restore();
  return cv;
}

// dati puliti (dall'AI o dal pannello): testi corti, al massimo 5 elementi
export function cleanMotion(m) {
  const tpl = MOTION_TPLS.some((x) => x[0] === (m && m.tpl)) ? m.tpl : 'numero';
  const items = Array.isArray(m && m.items) ? m.items.slice(0, 5).map((i) => ({ label: String((i && i.label) || '').slice(0, 40), value: String((i && i.value) ?? '').slice(0, 20) })) : [];
  return { tpl, title: String((m && m.title) || '').slice(0, 48), value: String((m && m.value) ?? '').slice(0, 16), items, accent: (m && m.accent) || '#4F8CFF' };
}
