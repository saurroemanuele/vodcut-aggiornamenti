// Crediti NoonFrame: carta crediti (menu della foto profilo), store dei piani e delle ricariche, offerte lampo.
// Il listino arriva sempre dal server (lo decide il pannello admin): qui niente prezzi scritti a mano.
import { get, post, h, icon, toast } from './lib.js';
import { LANG } from './i18n.js';

// 1.000 / 12.500 sempre col punto (in italiano Intl non separa i numeri di 4 cifre)
const nf = (n) => String(Math.round(+n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, LANG === 'en' ? ',' : '.');
const eur = (n) => { const v = (+n || 0).toFixed(2); return (LANG === 'en' ? '€' + v : v.replace('.', ',') + ' €'); };
const day = (iso) => { try { return new Date(iso).toLocaleDateString(LANG === 'en' ? 'en-GB' : 'it-IT', { day: 'numeric', month: 'long' }); } catch (e) { return ''; } };

// la moneta dei crediti: un piccolo sole (NoonFrame = mezzogiorno)
const SUN = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="5.2" fill="currentColor"/><g stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/></g></svg>';
export const coin = (size = 14) => { const s = h('span', { class: 'cr-coin', style: { width: size + 'px', height: size + 'px' } }); s.innerHTML = SUN; return s; };

function worth(credits, perUsd) {
  const p = perUsd || 280;
  return { video: Math.floor(credits / Math.ceil(0.42 * p)), img: Math.floor(credits / Math.ceil(0.08 * p)) };
}

function countdown(iso) {
  const el = h('span', { class: 'cr-cd', 'data-notr': '' });
  const end = new Date(iso).getTime();
  const tick = () => {
    if (el._started && !el.isConnected) { clearInterval(el._iv); return; }
    el._started = true;
    let s = Math.max(0, Math.floor((end - Date.now()) / 1000));
    if (s > 3 * 86400) {
      el.textContent = (LANG === 'en' ? 'until ' : 'fino al ') + new Date(end).toLocaleDateString(LANG === 'en' ? 'en-GB' : 'it-IT', { day: 'numeric', month: 'short' });
      return;
    }
    const d = Math.floor(s / 86400); s -= d * 86400;
    const hh = Math.floor(s / 3600); s -= hh * 3600;
    const mm = Math.floor(s / 60); s -= mm * 60;
    const p2 = (x) => String(x).padStart(2, '0');
    el.textContent = d > 0 ? `${d}${LANG === 'en' ? 'd' : 'g'} ${hh}h ${p2(mm)}m` : `${p2(hh)}:${p2(mm)}:${p2(s)}`;
  };
  tick(); el._iv = setInterval(tick, 1000);
  return el;
}

let CAT = null, CAT_AT = 0;
export async function loadCatalog(force) {
  if (!force && CAT && Date.now() - CAT_AT < 3 * 60 * 1000) return CAT;
  CAT = await get('/api/ai/catalog'); CAT_AT = Date.now();
  return CAT;
}

async function buy(kind, id, btn) {
  const was = btn.textContent;
  btn.disabled = true;
  try { await post('/api/ai/buy', { item: { kind, id } }); toast('Fatto'); }
  catch (e) { if (/pagamenti arrivano|payments are coming/i.test(e.message)) toast(e.message); else toast(e.message, true); }
  finally { btn.disabled = false; btn.textContent = was; }
}

// ------------------------------------------------------------------ carta crediti (menu della foto profilo)
const kids = (...a) => a.flat().filter((x) => x != null && x !== false && x !== '');   // replaceChildren scrive "null"

export function walletCard(onOpen) {
  const card = h('div', { class: 'cw' }, h('div', { class: 'cw-skel' }));
  const go = (tab) => { onOpen && onOpen(); creditsDialog(tab); };
  loadCatalog(true).then((c) => {
    if (!c || !c.signedIn) { card.remove(); return; }
    const plans = (c.catalog || {}).plans || [];
    const pl = plans.find((p) => p.id === c.plan);
    const paid = !!(c.plan && c.plan !== 'free');
    const offer = ((c.catalog || {}).offers || [])[0];
    const pop = plans.length >= 3 ? plans[Math.floor(plans.length / 2)] : plans[0];
    // crediti del mese: barra sottile (solo con un piano)
    const used = paid && pl && pl.monthly ? Math.max(0, Math.min(1, (c.monthly || 0) / pl.monthly)) : 0;
    card.replaceChildren(...kids(
      h('div', { class: 'cw-top' },
        h('div', { class: 'cw-num' }, coin(20), h('b', { 'data-notr': '' }, nf(c.balance))),
        h('span', { class: 'cw-plan' + (paid ? ' paid' : '') }, paid ? h('span', { 'data-notr': '' }, c.planName || (plans.find((p) => p.id === c.plan) || {}).name || (c.plan[0].toUpperCase() + c.plan.slice(1))) : 'Gratis')),
      h('div', { class: 'cw-lbl' }, 'crediti disponibili'),
      paid && pl ? h('div', { class: 'cw-meter' },
        h('div', { class: 'cw-bar' }, h('i', { style: { width: (used * 100).toFixed(1) + '%' } })),
        h('div', { class: 'cw-meta' }, h('span', null, h('span', { 'data-notr': '' }, nf(c.monthly) + ' / ' + nf(pl.monthly)), ' ', h('span', null, 'del mese')),
          c.nextGrant ? h('span', null, h('span', null, 'rinnovo'), ' ', h('span', { 'data-notr': '' }, day(c.nextGrant))) : null)) : null,
      paid && c.extra ? h('div', { class: 'cw-extra' }, h('span', { 'data-notr': '' }, '+' + nf(c.extra)), ' ', h('span', null, 'crediti extra che non scadono')) : null,
      offer ? h('button', { class: 'cw-offer', onclick: () => go() },
        h('span', { class: 'cw-o-ic' }, icon('bolt', 11, 'currentColor', 2.6)), h('span', { class: 'cw-o-t', 'data-notr': '' }, offer.title), countdown(offer.endsAt)) : null,
      c.on === false ? h('div', { class: 'cw-keys' }, h('span', null, 'L\'AI ora usa le tue chiavi'),
        h('button', { class: 'linkish', onclick: async (e) => { e.stopPropagation(); try { await post('/api/ai/credits', { on: true }); toast('Crediti attivi'); onOpen && onOpen(); } catch (er) { toast(er.message, true); } } }, 'Usa i crediti')) : null,
      paid
        ? h('div', { class: 'cw-act' }, h('button', { class: 'cw-btn main', onclick: () => go('packs') }, 'Ricarica'), h('button', { class: 'cw-btn', onclick: () => go('plans') }, 'Cambia piano'))
        : h('div', { class: 'cw-act one' },
          h('button', { class: 'cw-btn main', onclick: () => go('plans') }, pop ? 'Passa a ' + pop.name + ' · ' + eur(pop.price) + (LANG === 'en' ? '/mo' : '/mese') : 'Scegli un piano'),
          h('button', { class: 'cw-link', onclick: () => go('packs') }, 'oppure ricarica i crediti'))));
  }).catch(() => card.remove());
  return card;
}

// ------------------------------------------------------------------ store: piani e ricariche
export async function creditsDialog(tab) {
  const bg = h('div', { class: 'modal-bg cs-bg' });
  const sheet = h('div', { class: 'cs', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Crediti NoonFrame' }, h('div', { class: 'cs-load' }, h('div', { class: 'spinner' })));
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.append(sheet);
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  let c;
  try { c = await loadCatalog(true); } catch (e) { sheet.replaceChildren(h('p', { class: 'cs-err' }, e.message)); return; }
  const x = h('button', { class: 'cs-x', 'aria-label': 'Chiudi', onclick: close }, icon('x', 15, 'currentColor', 2.2));
  if (!c.signedIn) {
    sheet.replaceChildren(x, h('div', { class: 'cs-empty' }, coin(34), h('h2', null, 'Accedi per usare i crediti'), h('p', null, 'I crediti sono legati al tuo account: accedi dalla foto profilo in alto a destra.')));
    return;
  }
  const cat = c.catalog || {}, per = c.creditsPerUsd || 280, cur = c.plan || 'free';
  const plans = cat.plans || [], packs = cat.packs || [], offers = cat.offers || [];
  let mode = tab === 'packs' && packs.length ? 'packs' : 'plans';
  const popular = plans.length >= 3 ? plans[Math.floor(plans.length / 2)].id : (plans[0] || {}).id;
  let selPlan = (plans.find((p) => cur === 'free' && p.id === popular) || plans.find((p) => p.id !== cur) || plans[0] || {}).id;
  let selPack = (packs[Math.min(1, packs.length - 1)] || {}).id;

  const list = h('div', { class: 'cs-list', role: 'radiogroup' });
  const cta = h('button', { class: 'cs-cta' });
  const fine = h('p', { class: 'cs-fine' });
  const tabs = h('div', { class: 'cs-tabs', role: 'tablist' });

  function paint() {
    tabs.replaceChildren(...[['plans', 'Abbonamenti'], ['packs', 'Ricariche']].filter(([k]) => (k === 'plans' ? plans : packs).length).map(([k, l]) =>
      h('button', { role: 'tab', 'aria-selected': String(mode === k), class: mode === k ? 'on' : '', onclick: () => { mode = k; paint(); } }, l)));
    if (mode === 'plans') {
      list.replaceChildren(...plans.map((p) => {
        const on = p.id === selPlan, mine = p.id === cur, w = worth(p.monthly, per);
        return h('button', { class: 'cs-row' + (on ? ' on' : '') + (mine ? ' mine' : ''), role: 'radio', 'aria-checked': String(on), onclick: () => { selPlan = p.id; paint(); } },
          h('span', { class: 'cs-radio' }),
          h('span', { class: 'cs-main' },
            h('span', { class: 'cs-name' }, h('b', { 'data-notr': '' }, p.name),
              mine ? h('em', { class: 'tag mine' }, 'Il tuo piano') : p.id === popular && cur === 'free' ? h('em', { class: 'tag' }, 'Il più scelto') : null),
            h('span', { class: 'cs-amt' }, coin(12), h('span', { 'data-notr': '' }, nf(p.monthly)), ' ', h('span', null, 'crediti al mese')),
            on ? h('span', { class: 'cs-more' },
              h('span', null, '≈ ', h('span', { 'data-notr': '' }, String(w.video)), ' ', h('span', null, 'video AI da 5 secondi'), ' · ', h('span', { 'data-notr': '' }, String(w.img)), ' ', h('span', null, 'immagini')),
              ...(p.perks || []).map((k) => h('span', { 'data-notr': '' }, k))) : null),
          h('span', { class: 'cs-price' }, h('b', { 'data-notr': '' }, eur(p.price)), h('small', null, 'al mese')));
      }));
      const p = plans.find((q) => q.id === selPlan) || {};
      const mine = p.id === cur;
      cta.disabled = mine;
      cta.textContent = mine ? 'È già il tuo piano' : 'Continua con ' + (p.name || '') + ' · ' + eur(p.price) + (LANG === 'en' ? '/mo' : '/mese');
      cta.onclick = () => buy('plan', p.id, cta);
      fine.textContent = 'Si rinnova ogni mese, disdici quando vuoi. I crediti del mese si azzerano al rinnovo. Prezzi IVA inclusa.';
    } else {
      list.replaceChildren(...packs.map((k) => {
        const on = k.id === selPack, w = worth(k.credits, per);
        return h('button', { class: 'cs-row' + (on ? ' on' : ''), role: 'radio', 'aria-checked': String(on), onclick: () => { selPack = k.id; paint(); } },
          h('span', { class: 'cs-radio' }),
          h('span', { class: 'cs-main' },
            h('span', { class: 'cs-name' }, coin(14), h('b', { 'data-notr': '' }, nf(k.credits)), h('span', { class: 'cs-unit' }, 'crediti')),
            h('span', { class: 'cs-amt dim' }, '≈ ', h('span', { 'data-notr': '' }, String(w.video)), ' ', h('span', null, 'video AI'), ' · ', h('span', { 'data-notr': '' }, String(w.img)), ' ', h('span', null, 'immagini'))),
          h('span', { class: 'cs-price' }, h('b', { 'data-notr': '' }, eur(k.price)), h('small', null, 'una volta')));
      }));
      const k = packs.find((q) => q.id === selPack) || {};
      cta.disabled = false;
      cta.textContent = 'Ricarica ' + nf(k.credits) + ' crediti · ' + eur(k.price);
      cta.onclick = () => buy('pack', k.id, cta);
      fine.textContent = 'I crediti delle ricariche non scadono mai. Prezzi IVA inclusa.';
    }
  }

  const o = offers[0];
  const offerBar = o ? h('div', { class: 'cs-offer' },
    h('span', { class: 'cs-o-ic' }, icon('bolt', 15, 'currentColor', 2.4)),
    h('span', { class: 'cs-o-txt' }, h('b', { 'data-notr': '' }, o.title),
      o.kind === 'plan'
        ? h('span', { 'data-notr': '' }, eur(o.price) + (LANG === 'en' ? '/mo ' : '/mese '), o.fullPrice ? h('s', null, eur(o.fullPrice)) : null)
        : h('span', null, h('span', { 'data-notr': '' }, nf(o.credits)), ' ', h('span', null, 'crediti che non scadono a'), ' ', h('span', { 'data-notr': '' }, eur(o.price)))),
    h('span', { class: 'cs-o-end' }, h('small', null, 'Offerta a tempo'), countdown(o.endsAt)),
    h('button', { class: 'cs-o-btn', onclick: (e) => buy('offer', o.id, e.currentTarget) }, 'Prendi l\'offerta')) : null;

  const paid = cur !== 'free';
  const head = h('div', { class: 'cs-head' },
    h('div', { class: 'cs-glow' }),
    h('div', { class: 'cs-mark' }, coin(26)),
    h('h2', null, 'Più AI, ogni mese'),
    h('p', null, 'Video, immagini e voci generate dentro NoonFrame, senza chiavi da collegare.'),
    h('div', { class: 'cs-bal' }, h('span', null, 'Hai'), coin(12), h('b', { 'data-notr': '' }, nf(c.balance)), h('span', null, 'crediti'),
      paid ? h('span', { class: 'cs-bal-pl' }, h('span', null, 'piano'), ' ', h('span', { 'data-notr': '' }, c.planName || cur)) : null));
  sheet.replaceChildren(...kids(x, head, offerBar, tabs, list, cta, fine));
  paint();
}

// ------------------------------------------------------------------ home: offerta lampo (sottile, si chiude)
export function offerBanner() {
  const box = h('div', { class: 'cr-banner', style: { display: 'none' } });
  loadCatalog().then((c) => {
    const o = ((c.catalog || {}).offers || [])[0];
    if (!o) return;
    try { if (sessionStorage.getItem('nf.offer.hide') === String(o.id)) return; } catch (e) { /* */ }
    box.replaceChildren(...kids(h('span', { class: 'cr-bn-ic' }, icon('bolt', 13, 'currentColor', 2.4)),
      h('b', { 'data-notr': '' }, o.title), o.subtitle ? h('span', { class: 'cr-bn-sub', 'data-notr': '' }, o.subtitle) : null,
      h('span', { class: 'cr-bn-cd' }, countdown(o.endsAt)),
      h('button', { class: 'cr-bn-go', onclick: () => creditsDialog() }, 'Vedi'),
      h('button', { class: 'cr-bn-x', 'aria-label': 'Nascondi', onclick: () => { box.remove(); try { sessionStorage.setItem('nf.offer.hide', String(o.id)); } catch (e) { /* */ } } }, icon('x', 12, 'currentColor', 2.2))));
    box.style.display = '';
  }).catch(() => {});
  return box;
}

// pallino sulla foto profilo quando c'e' un'offerta lampo
export function markOffer(el) {
  loadCatalog().then((c) => { if (((c.catalog || {}).offers || []).length) el.classList.add('has-offer'); }).catch(() => {});
}
