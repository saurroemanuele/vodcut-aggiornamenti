// Utility condivise: API, DOM, icone, formati.
export const TOKEN = window.VODCUT.token;

export async function api(method, path, body) {
  const opt = { method, headers: { 'X-Token': TOKEN } };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  let j = null;
  try { j = await r.json(); } catch (e) { /* vuoto */ }
  if (!r.ok) throw new Error((j && j.error) || ('Errore ' + r.status));
  return j;
}
export const get = (p) => api('GET', p);
export const post = (p, b) => api('POST', p, b || {});
export const put = (p, b) => api('PUT', p, b);

export function mediaUrl(path) { return '/media?token=' + TOKEN + '&path=' + encodeURIComponent(path); }
export function thumbUrl(pid, t, h) { return `/api/p/${pid}/thumb?token=${TOKEN}&t=${(Math.round(t * 10) / 10).toFixed(1)}&h=${h || 90}`; }

// h('div', {class:'x', onclick: fn}, child, 'testo')
// Mac: le scorciatoie si scrivono con i simboli di macOS (Cmd al posto di Ctrl)
export const IS_MAC = /Mac/i.test(navigator.platform || '') || /Macintosh/.test(navigator.userAgent || '');
export function macKeys(v) {
  if (!IS_MAC || typeof v !== 'string' || !/Ctrl|Shift|Maiusc|^Del$|^Canc$/.test(v)) return v;
  return v.replace(/Win\+Shift\+S/g, '⌘⇧4').replace(/Ctrl( ?\+ ?)(?=[a-z]{2})/g, 'Cmd$1').replace(/Ctrl ?\+ ?/g, '⌘').replace(/\bCtrl\b/g, 'Cmd')
    .replace(/(?:Maiusc|Shift) ?\+? ?/g, '⇧').replace(/^(?:Del|Canc)$/, '⌫');
}
export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'html') el.innerHTML = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, IS_MAC ? macKeys(v) : v);
    }
  }
  for (const c of kids.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(IS_MAC ? macKeys(String(c)) : String(c)));
  }
  return el;
}

const ICONS = {
  upload: '<path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  play: '<path d="M7 4.5v15l13-7.5z" fill="currentColor" stroke="none"/>',
  pause: '<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor" stroke="none"/>',
  back5: '<path d="M11 7L6 12l5 5"/><path d="M18 7l-5 5 5 5"/>',
  fwd5: '<path d="M13 7l5 5-5 5"/><path d="M6 7l5 5-5 5"/>',
  undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
  redo: '<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
  plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
  scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.1 15.9"/><path d="M14.5 14.5L20 20"/><path d="M8.1 8.1L12 12"/>',
  split: '<path d="M12 3v18"/><path d="M8 7l-4 5 4 5"/><path d="M16 7l4 5-4 5"/>',
  music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  speaker: '<path d="M11 5L6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/>',
  mute: '<path d="M11 5L6 9H3v6h3l5 4z"/><path d="M22 9l-6 6"/><path d="M16 9l6 6"/>',
  left: '<path d="M15 6l-6 6 6 6"/>',
  x: '<path d="M6 6l12 12"/><path d="M18 6L6 18"/>',
  download: '<path d="M12 4v11"/><path d="M7 10l5 5 5-5"/><path d="M5 20h14"/>',
  sparkle: '<path d="M12 3l1.8 4.6L18 9.4l-4.2 1.8L12 16l-1.8-4.8L6 9.4l4.2-1.8z"/><path d="M19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5"/><path d="M12 16h.01"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  zoomin: '<circle cx="11" cy="11" r="7"/><path d="M11 8v6M8 11h6"/><path d="M20 20l-4-4"/>',
  zoomout: '<circle cx="11" cy="11" r="7"/><path d="M8 11h6"/><path d="M20 20l-4-4"/>',
  text: '<path d="M4 6h16M4 12h10M4 18h14"/>',
  sliders: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  film: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 5v14M17 5v14M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  magnify: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/><path d="M8.5 11h5M11 8.5v5"/>',
  cc: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10.5 10.2a2.2 2.2 0 1 0 0 3.6M16.5 10.2a2.2 2.2 0 1 0 0 3.6"/>',
  wave: '<path d="M3 12h2M7 8v8M11 5v14M15 9v6M19 11v2"/>',
  cloudok: '<path d="M7 18a4.5 4.5 0 0 1-.5-9A6 6 0 0 1 18 9.5a4 4 0 0 1-1 8.5z"/><path d="M9.5 13.5l2 2 3.5-3.5"/>',
  dots: '<circle cx="6" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="18" cy="12" r="1.3"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
  restore: '<path d="M4 12a8 8 0 1 0 2.3-5.6"/><path d="M4 4v4h4"/>',
  guides: '<path d="M3 8h18M3 16h18M8 3v18M16 3v18" stroke-dasharray="2.5 2"/>',
  phone: '<rect x="7" y="2.5" width="10" height="19" rx="2.2"/><path d="M11 18.5h2"/>',
  webcam: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/>',
  mergeL: '<path d="M4 5v14"/><path d="M20 12H9"/><path d="M13 8l-4 4 4 4"/>',
  mergeR: '<path d="M20 5v14"/><path d="M4 12h11"/><path d="M11 8l4 4-4 4"/>',
  fadeIn: '<path d="M3 19L21 6v13z"/>',
  fadeOut: '<path d="M3 6l18 13H3z"/>',
  diamond: '<path d="M12 3.5l8.5 8.5-8.5 8.5L3.5 12z"/>',
  speed: '<path d="M4.5 17a8 8 0 1 1 15 0"/><path d="M12 13l4-4"/><circle cx="12" cy="13" r="1.2" fill="currentColor" stroke="none"/>',
  duplicate: '<rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  swap: '<path d="M4 8h13"/><path d="M14 4l4 4-4 4"/><path d="M20 16H7"/><path d="M10 12l-4 4 4 4"/>',
  cutout: '<path d="M12 3a4 4 0 0 1 4 4 4 4 0 0 1-8 0 4 4 0 0 1 4-4z"/><path d="M4.5 21a7.5 7.5 0 0 1 15 0"/><path d="M3 3h3M18 3h3M3 3v3M21 3v3" opacity=".6"/>',
  magnet: '<path d="M6 3v8a6 6 0 0 0 12 0V3"/><path d="M6 7h4M14 7h4"/><path d="M10 3v8a2 2 0 0 0 4 0V3"/>',
  beep: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 8l4 8M21 8l-4 8"/>',
  trimL: '<path d="M13 3v18"/><rect x="16" y="7" width="5" height="10" rx="1.5"/><path d="M4 8l5 8M9 8l-5 8"/>',
  trimR: '<path d="M11 3v18"/><rect x="3" y="7" width="5" height="10" rx="1.5"/><path d="M15 8l5 8M20 8l-5 8"/>',
  share: '<path d="M12 15V3"/><path d="M8 7l4-4 4 4"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
  wand: '<path d="M4 20L15 9"/><path d="M14 4l.8 2.2L17 7l-2.2.8L14 10l-.8-2.2L11 7l2.2-.8z"/><path d="M19 12l.5 1.5L21 14l-1.5.5L19 16l-.5-1.5L17 14l1.5-.5z"/>',
  type: '<path d="M5 7V5h14v2"/><path d="M12 5v14"/><path d="M9 19h6"/>',
  expand: '<path d="M4 9V4h5"/><path d="M20 9V4h-5"/><path d="M4 15v5h5"/><path d="M20 15v5h-5"/>',
  shrink: '<path d="M9 4v5H4"/><path d="M15 4v5h5"/><path d="M9 20v-5H4"/><path d="M15 20v-5h5"/>',
  addTrack: '<rect x="3" y="5" width="12" height="4" rx="1.2"/><rect x="3" y="12" width="12" height="4" rx="1.2"/><path d="M19.5 10v7"/><path d="M16 13.5h7"/>',
  clipAdd: '<rect x="2" y="6" width="9" height="12" rx="1.5"/><rect x="13" y="6" width="9" height="12" rx="1.5" stroke-dasharray="2 2"/><path d="M17.5 10v4M15.5 12h4"/>',
  toStart: '<path d="M4 5v14"/><rect x="8" y="7" width="12" height="10" rx="1.5"/>',
  toEnd: '<path d="M20 5v14"/><rect x="4" y="7" width="12" height="10" rx="1.5"/>',
  chev: '<path d="M9 6l6 6-6 6"/>',
  eyeOff: '<path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.2M6.6 6.6C3.7 8.4 2 12 2 12s3.5 7 10 7a9.6 9.6 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  addVideo: '<rect x="2" y="6" width="12" height="12" rx="2"/><path d="M19 9v6"/><path d="M16 12h6"/>',
  addAudio: '<path d="M7 17V6l7-2v9"/><circle cx="4.5" cy="17" r="2.5"/><path d="M19 14v7"/><path d="M15.5 17.5h7"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  duck: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><path d="M14 20l3-3 3 3"/>',
  crop: '<path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/>',
  frame: '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/><path d="M8.5 11h.01M12 11h.01M15.5 11h.01"/>',
  alert: '<path d="M10.3 3.9L2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  bulb: '<path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2V17h6v-.3c0-.8.4-1.5 1-2A7 7 0 0 0 12 2z"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
  send: '<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
  star: '<path d="M12 3.2l2.7 5.5 6 .9-4.35 4.25 1.03 6-5.38-2.83-5.38 2.83 1.03-6L3.3 9.6l6-.9z"/>',
  library: '<path d="M4 4v16M8 4v16"/><path d="M12.5 4.6l3.9-1 4 15.5-3.9 1z"/>',
  layoutV: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M14 4v16M3 12h11"/>',
  layoutH: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 13h18M15 4v9"/>',
  timeline: '<path d="M3 7h10M3 12h18M3 17h7"/><rect x="14" y="4.5" width="7" height="5" rx="1"/>',
};
export function icon(name, size = 18, color = 'currentColor', sw = 1.9) {
  const span = document.createElement('span');
  span.style.display = 'inline-flex';
  span.setAttribute('aria-hidden', 'true');
  span.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ''}</svg>`;
  return span;
}

export function fmt(t, withTenths) {
  t = Math.max(0, t || 0);
  const hh = Math.floor(t / 3600), mm = Math.floor((t % 3600) / 60), ss = Math.floor(t % 60);
  let s = hh ? `${hh}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}` : `${mm}:${String(ss).padStart(2, '0')}`;
  if (withTenths) s += ',' + Math.floor((t % 1) * 10);
  return s;
}
export function fmtDur(t) {
  if (t < 60) return Math.round(t) + ' s';
  if (t < 3600) return Math.round(t / 60) + ' min';
  const hh = Math.floor(t / 3600), mm = Math.round((t % 3600) / 60);
  return hh + ' h' + (mm ? ' ' + mm + ' min' : '');
}

// gancio per gli errori: feedback.js li mostra come finestre che restano (con "Segnala il problema")
export const hooks = { error: null };
export function toast(msg, err) {
  if (err && hooks.error) { try { hooks.error(String(msg || 'Errore')); return; } catch (e) { /* sotto: il vecchio avviso */ } }
  const el = h('div', { class: 'toast' + (err ? ' err' : '') }, msg);
  document.getElementById('toasts').append(el);
  setTimeout(() => el.remove(), err ? 6000 : 3000);
}

export function confirmBox(title, text, okLabel, danger) {
  return new Promise((res) => {
    const bg = h('div', { class: 'modal-bg' });
    const close = (v) => { bg.remove(); document.removeEventListener('keydown', onKey, true); res(v); };
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(false); } };
    document.addEventListener('keydown', onKey, true);
    const ok = h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: () => close(true) }, okLabel || 'Ok');
    bg.append(h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
      h('h2', null, title), h('p', null, text),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
        h('button', { class: 'btn ghost', onclick: () => close(false) }, 'Annulla'), ok)));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(false); });
    document.body.append(bg);
    ok.focus();
  });
}

// finestra con un campo di testo (es. il nome di qualcosa). Ritorna il testo, o null se annulli
export function promptBox(title, text, value, okLabel) {
  return new Promise((res) => {
    const bg = h('div', { class: 'modal-bg' });
    const inp = h('input', { class: 'input', value: value || '', maxlength: '120', 'aria-label': title, style: { height: '38px', width: '100%' } });
    const close = (v) => { bg.remove(); document.removeEventListener('keydown', onKey, true); res(v); };
    const okF = () => { const v = inp.value.trim(); if (!v) { inp.focus(); return; } close(v); };
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(null); } else if (e.key === 'Enter') { e.stopPropagation(); e.preventDefault(); okF(); } };
    document.addEventListener('keydown', onKey, true);
    bg.append(h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
      h('h2', null, title), text ? h('p', null, text) : null, inp,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '14px' } },
        h('button', { class: 'btn ghost', onclick: () => close(null) }, 'Annulla'), h('button', { class: 'btn primary', onclick: okF }, okLabel || 'Ok'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(null); });
    document.body.append(bg);
    inp.focus(); inp.select();
  });
}

export function seg(labels, cur, onPick, cls) {
  return h('div', { class: 'seg ' + (cls || ''), role: 'group' },
    labels.map((l, i) => h('button', { 'aria-pressed': i === cur ? 'true' : 'false', onclick: () => onPick(i) }, l)));
}

export function toggle(on, onChange, label) {
  const b = h('button', { class: 'toggle', 'aria-pressed': on ? 'true' : 'false', 'aria-label': label });
  b.addEventListener('click', () => onChange(b.getAttribute('aria-pressed') !== 'true'));
  return b;
}

export async function pollJob(id, onUpdate) {
  for (;;) {
    const j = await get('/api/jobs/' + id);
    onUpdate && onUpdate(j);
    if (j.status !== 'running') return j;
    await new Promise((r) => setTimeout(r, 400));
  }
}

// --- curva di zoom (identica a engine/render.py)
const DRIFT = 0.10, SNAP_T = 0.35, SMOOTH_IN = 0.6, SMOOTH_OUT = 0.45;
const eio = (t) => { t = Math.max(0, Math.min(1, t)); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
// effetti di entrata/uscita dello zoom (stessi calcoli di engine/render.py)
export const ZOOM_IN_FX = [['snap', 'Scatto'], ['fast', 'Veloce'], ['smooth', 'Morbida'], ['slow', 'Lenta'], ['punch', 'Colpo']];
export const ZOOM_OUT_FX = [['cut', 'Taglio netto'], ['fast', 'Veloce'], ['smooth', 'Morbida'], ['slow', 'Lenta']];
const IN_DUR = { fast: 0.25, smooth: SMOOTH_IN, slow: 1.2, punch: 0.45 };
const OUT_DUR = { fast: 0.25, smooth: SMOOTH_OUT, slow: 1.0 };
const outBack = (t) => { t = Math.max(0, Math.min(1, t)); const c = 1.2, c3 = c + 1; return 1 + c3 * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };
export function zoomProgress(t, z) {
  if (!(t >= z.a && t < z.b)) return 0;
  const dt = t - z.a, D = Math.max(0.01, z.b - z.a), u = dt / D;
  const ki = z.in || 'snap';
  let base, drift = DRIFT;
  if (ki === 'snap') { base = 1; drift = 0; }   // scatto: subito ingrandito, nessuna animazione
  else if (ki === 'punch') base = outBack(dt / IN_DUR.punch);
  else if (IN_DUR[ki]) base = eio(dt / IN_DUR[ki]);
  else { base = 1; drift = 0; }
  let p = base + drift * (1 - (1 - u) * (1 - u));
  const od = OUT_DUR[z.out];
  if (od && z.b - t < od) p *= eio((z.b - t) / od);
  return p;
}
export function targetRect(W, H, cam, level) {
  const [cx, cy, cw, ch] = cam;
  const Z = Math.max(1.05, level), w = W / Z, hh = H / Z, mx = 0.02 * w, my = 0.03 * hh;
  let x = cx + cw / 2 > W * 0.55 ? cx + cw + mx - w : (cx + cw / 2 < W * 0.45 ? cx - mx : cx + cw / 2 - w / 2);
  let y = cy + ch / 2 < H * 0.5 ? cy - my : cy + ch + my - hh;
  x = Math.min(Math.max(0, x), W - w); y = Math.min(Math.max(0, y), H - hh);
  return [x, y, w, hh];
}
export function rectAt(p, W, H, R) {
  const [x, y, w] = R, Z = W / w, k = 1 - 1 / Z, px = x / k, py = y / k;
  const s = Math.exp(p * Math.log(Z)), rw = W / s, rh = H / s;
  let rx = px - px / s, ry = py - py / s;
  rx = Math.min(Math.max(0, rx), W - rw); ry = Math.min(Math.max(0, ry), H - rh);
  return [rx, ry, rw, rh];
}

// --- bottone icona con suggerimento al passaggio del mouse
export function ibtn(name, tip, onclick, opt = {}) {
  const b = h('button', { class: 'iconbtn' + (opt.cls ? ' ' + opt.cls : ''), 'aria-label': tip, 'data-tip': tip, 'data-key': opt.key || null, onclick },
    icon(name, opt.size || 17, opt.color || 'currentColor', opt.sw || 1.8));
  if (opt.pressed !== undefined) b.setAttribute('aria-pressed', String(!!opt.pressed));
  return b;
}

// --- suggerimenti: qualsiasi elemento con data-tip (e data-key per la scorciatoia)
(function installTips() {
  let tipEl = null, timer = 0, cur = null, shownAt = 0;
  const hide = (why) => {
    clearTimeout(timer);
    if (tipEl && tipEl.classList.contains('show') && Date.now() - shownAt < 1200 && !window.__tipHideLogged) {
      window.__tipHideLogged = true;
      post('/api/clientlog', { msg: 'suggerimento nascosto subito da: ' + why }).catch(() => {});
    }
    cur = null;
    if (tipEl) tipEl.classList.remove('show');
  };
  document.addEventListener('mouseover', (e) => {
    const el = e.target.closest && e.target.closest('[data-tip]');
    if (el === cur) return;
    if (tipEl && tipEl.classList.contains('show')) hide('mouse su altro elemento');
    clearTimeout(timer); cur = null;
    if (!el) return;
    cur = el;
    timer = setTimeout(() => {
      if (cur !== el || !document.body.contains(el)) return;
      if (!tipEl) { tipEl = document.createElement('div'); tipEl.className = 'tip'; document.body.append(tipEl); }
      tipEl.textContent = el.dataset.tip;
      if (el.dataset.key) { const k = document.createElement('kbd'); k.textContent = el.dataset.key; tipEl.append(k); }
      const r = el.getBoundingClientRect();
      tipEl.style.left = '0px'; tipEl.style.top = '0px';
      const tw = tipEl.offsetWidth, th = tipEl.offsetHeight;
      let x = r.left + r.width / 2 - tw / 2, y = r.bottom + 6;
      if (y + th > window.innerHeight - 4) y = r.top - th - 6;
      x = Math.max(6, Math.min(window.innerWidth - tw - 6, x));
      tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
      tipEl.classList.add('show'); shownAt = Date.now();
      if (!window.__tipLogged) { window.__tipLogged = true; post('/api/clientlog', { msg: 'suggerimento mostrato: ' + el.dataset.tip + ' pos ' + Math.round(x) + ',' + Math.round(y) + ' dim ' + tw + 'x' + th + ' finestra ' + window.innerWidth + 'x' + window.innerHeight }).catch(() => {}); }
    }, 400);
  });
  document.addEventListener('mouseout', (e) => { if (!e.relatedTarget) hide('mouse fuori dalla finestra'); });
  document.addEventListener('pointerdown', () => hide('clic'), true);
  document.addEventListener('keydown', () => hide('tasto'), true);
  window.addEventListener('blur', () => hide('finestra non attiva'));
})();

// inquadratura finale di uno zoom: webcam (automatica) o personalizzata (scelta a mano)
export function customRect(W, H, rect) {
  let [x, y, w] = rect;
  w = Math.max(W / 8, Math.min(W / 1.05, w));
  const hh = w * H / W;
  return [Math.min(Math.max(0, x), W - w), Math.min(Math.max(0, y), H - hh), w, hh];
}
export function zoomTarget(z, W, H, cam) {
  if (z.kind === 'custom' && z.rect) return customRect(W, H, z.rect);
  if (!cam) return null;
  return targetRect(W, H, cam, z.level || 2.8);
}

// --- immagini: stato nel tempo (keyframe) e trasformazione 3D. Stessa matematica di engine/overlay.py
export const IMG_KEYS = ['x', 'y', 'w', 'rot', 'rx', 'ry', 'z', 'op'];
export const PERSP = 1.2;
const easeIO = (u) => { u = Math.max(0, Math.min(1, u)); return u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2; };
export function imgBase(c) {
  const p = c.pos || {};
  return { x: p.x ?? 0.35, y: p.y ?? 0.35, w: p.w ?? 0.3, rot: c.rot || 0, rx: c.rx || 0, ry: c.ry || 0, z: c.z || 0, op: c.opacity ?? 100 };
}
export function imgStateAt(c, tr) {
  const kf = (c.kf || []).slice().sort((a, b) => a.t - b.t);
  const b = imgBase(c);
  if (!kf.length) return b;
  const full = kf.map((f) => { const o = { t: f.t, ease: f.ease || 'smooth' }; IMG_KEYS.forEach((k) => { o[k] = f[k] ?? b[k]; }); return o; });
  const pick = (f) => { const o = {}; IMG_KEYS.forEach((k) => { o[k] = f[k]; }); return o; };
  if (tr <= full[0].t) return pick(full[0]);
  if (tr >= full[full.length - 1].t) return pick(full[full.length - 1]);
  for (let i = 0; i < full.length - 1; i++) {
    const a = full[i], n = full[i + 1];
    if (a.t <= tr && tr < n.t) {
      let u = (tr - a.t) / Math.max(1e-6, n.t - a.t);
      u = a.ease === 'linear' ? u : easeIO(u);
      const o = {}; IMG_KEYS.forEach((k) => { o[k] = a[k] + (n[k] - a[k]) * u; }); return o;
    }
  }
  return pick(full[full.length - 1]);
}
// trasformazione CSS equivalente (sw = larghezza dell'anteprima in pixel)
export function imgCss(s, sw) {
  return `perspective(${(PERSP * sw).toFixed(1)}px) translateZ(${(s.z * sw).toFixed(2)}px) rotateX(${s.rx.toFixed(2)}deg) rotateY(${s.ry.toFixed(2)}deg) rotate(${s.rot.toFixed(2)}deg)`;
}

// --- sottotitoli: stile predefinito e font
export const SUB_DEFAULT = {
  font: 'Arial', size: 0.055, y: 0.92, color: '#FFFFFF', bold: true, upper: false,
  stroke: false, strokeColor: '#000000', strokeW: 0.08,
  box: true, boxColor: '#000000', boxOp: 70,
  shadow: false, effect: 'none', hiColor: '#FFD60A', maxChars: 38,
};
// altezza (salita + discesa) / em: la dimensione dei sottotitoli .ass e' riferita a questa
export const FONT_RATIO = { 'Arial': 1.117, 'Verdana': 1.215, 'Georgia': 1.136, 'Trebuchet MS': 1.16, 'Impact': 1.22, 'Segoe UI': 1.33, 'Comic Sans MS': 1.39, 'Tahoma': 1.207 };

// --- animazioni pronte (entrata / uscita / continua). Stessa matematica di engine/overlay.py
const eOutCubic = (p) => 1 - Math.pow(1 - p, 3);
const eOutBack = (p) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
const eOutBounce = (p) => {
  const n1 = 7.5625, d1 = 2.75;
  if (p < 1 / d1) return n1 * p * p;
  if (p < 2 / d1) { p -= 1.5 / d1; return n1 * p * p + 0.75; }
  if (p < 2.5 / d1) { p -= 2.25 / d1; return n1 * p * p + 0.9375; }
  p -= 2.625 / d1; return n1 * p * p + 0.984375;
};
export const ANIMS = {
  in: [['fade', 'Dissolvenza'], ['pop', 'Pop'], ['zoom', 'Zoom'], ['slideL', 'Da sinistra'], ['slideR', 'Da destra'], ['slideU', 'Dal basso'], ['drop', 'Caduta'], ['spin', 'Giro'], ['flip', 'Ribalta 3D'], ['swing', 'Cerniera 3D']],
  out: [['fade', 'Dissolvenza'], ['pop', 'Pop'], ['zoom', 'Zoom'], ['slideL', 'A sinistra'], ['slideR', 'A destra'], ['slideU', 'In basso'], ['drop', 'Su'], ['spin', 'Giro'], ['flip', 'Ribalta 3D'], ['swing', 'Cerniera 3D']],
  loop: [['float', 'Fluttua'], ['pulse', 'Respira'], ['card', 'Carta 3D'], ['wiggle', 'Oscilla'], ['sway', 'Ondeggia 3D'], ['shake', 'Trema'], ['spinc', 'Gira']],
};
// p: 0 = fuori, 1 = al suo posto
function animEdge(s, type, p, aspect, ar) {
  p = Math.max(0, Math.min(1, p));
  const hf = s.w * aspect * ar;
  const scale = (k) => { const nw = s.w * k; s.x += (s.w - nw) / 2; s.y += (hf - nw * aspect * ar) / 2; s.w = nw; };
  const e = eOutCubic(p);
  if (type === 'fade') s.op *= p;
  else if (type === 'pop') { scale(Math.max(0.01, 0.3 + 0.7 * eOutBack(p))); s.op *= Math.min(1, p * 3); }
  else if (type === 'zoom') { scale(1.5 - 0.5 * e); s.op *= e; }
  else if (type === 'slideL') s.x -= (s.x + s.w + 0.02) * (1 - e);
  else if (type === 'slideR') s.x += (1 - s.x + 0.02) * (1 - e);
  else if (type === 'slideU') s.y += (1 - s.y + 0.02) * (1 - e);
  else if (type === 'drop') s.y -= (s.y + hf + 0.02) * (1 - eOutBounce(p));
  else if (type === 'spin') { s.rot -= 180 * (1 - e); scale(Math.max(0.01, e)); }
  else if (type === 'flip') { s.ry += 90 * (1 - e); s.op *= Math.min(1, p * 2); }
  else if (type === 'swing') { s.rx -= 90 * (1 - e); s.op *= Math.min(1, p * 2); }
  return s;
}
function animLoop(s, type, tr, aspect, ar) {
  const hf = s.w * aspect * ar, TAU = Math.PI * 2;
  // partenza morbida: il movimento cresce nel primo 0,8 s
  const u = Math.min(1, tr / 0.8), r = u * u * (3 - 2 * u);
  if (type === 'float') { s.y += 0.011 * Math.sin(TAU * tr / 3.4) * r; s.x += 0.004 * Math.sin(TAU * tr / 5.1 + 1.3) * r; s.rot += 1.4 * Math.sin(TAU * tr / 4.3 + 0.7) * r; }
  else if (type === 'pulse') { const k = 1 + 0.035 * (0.5 - 0.5 * Math.cos(TAU * tr / 2.6)), nw = s.w * k; s.x += (s.w - nw) / 2; s.y += (hf - nw * aspect * ar) / 2; s.w = nw; }
  else if (type === 'card') { s.rx += 7 * Math.sin(TAU * tr / 4.1) * r; s.ry += 9 * Math.sin(TAU * tr / 5.3 + 0.9) * r; s.z += 0.02 * Math.sin(TAU * tr / 3.7) * r; }
  else if (type === 'wiggle') s.rot += 5 * Math.sin(TAU * tr / 0.9);
  else if (type === 'sway') s.ry += 14 * Math.sin(TAU * tr / 3);
  else if (type === 'shake') { s.x += 0.004 * Math.sin(TAU * tr * 9.1); s.y += 0.004 * Math.sin(TAU * tr * 7.3); }
  else if (type === 'spinc') s.rot += 40 * (tr - (1 - Math.exp(-1.5 * tr)) / 1.5);
  return s;
}
// movimento lento per tutta la durata (stile documentario / storie): zoom e panoramiche
export const MOTIONS = [['zoomIn', 'Zoom avanti'], ['zoomOut', 'Zoom indietro'], ['panL', 'Verso sinistra'], ['panR', 'Verso destra'], ['panU', 'Verso l\'alto'], ['panD', 'Verso il basso']];
function animMotion(s, type, q, aspect, ar) {
  q = Math.max(0, Math.min(1, q));
  const e = 0.6 * q + 0.4 * q * q * (3 - 2 * q);
  const K = 1.14;
  let k = K, dx = 0, dy = 0;
  if (type === 'zoomIn') k = 1 + (K - 1) * e;
  else if (type === 'zoomOut') k = K - (K - 1) * e;
  const hf = s.w * aspect * ar, mx = (K - 1) / 2 * s.w * 0.9, my = (K - 1) / 2 * hf * 0.9;
  if (type === 'panL') dx = mx * (1 - 2 * e);
  else if (type === 'panR') dx = -mx * (1 - 2 * e);
  else if (type === 'panU') dy = my * (1 - 2 * e);
  else if (type === 'panD') dy = -my * (1 - 2 * e);
  const nw = s.w * k; s.x += (s.w - nw) / 2 + dx; s.y += (hf - nw * aspect * ar) / 2 + dy; s.w = nw;
  return s;
}
ANIMS.motion = MOTIONS;
// stato finale di un'immagine: keyframe + animazioni. aspect = larghezza/altezza del video
export function imgFinal(c, tr, aspect) {
  const s = { ...imgStateAt(c, tr) };
  const an = c.anim || {}, ar = c.ar || 9 / 16, dur = c.dur;
  if (an.motion) animMotion(s, an.motion, dur ? tr / dur : 0, aspect, ar);
  if (an.loop) animLoop(s, an.loop, tr, aspect, ar);
  if (an.in) { const d = Math.min(an.inDur || 0.5, dur); if (tr < d) animEdge(s, an.in, tr / d, aspect, ar); }
  if (an.out) { const d = Math.min(an.outDur || 0.5, dur); if (tr > dur - d) animEdge(s, an.out, (dur - tr) / d, aspect, ar); }
  return s;
}

// --- formato verticale (9:16): cosa si vede e dove. Stessa matematica di engine/vertical.py
// d = dove va sullo schermo (0..1), s = che parte della live (pixel), blur = sfondo sfocato
export const V_ASPECT = 9 / 16;
export function coverRect(r, a) {
  let [x, y, w, h] = r;
  if (w / h > a) { const nw = h * a; x += (w - nw) / 2; w = nw; } else { const nh = w / a; y += (h - nh) / 2; h = nh; }
  return [x, y, w, h];
}
function gameRect(W, H, a, gx) {
  const w = Math.min(W, H * a), hh = w / a;
  return [Math.min(Math.max(0, gx * W - w / 2), W - w), (H - hh) / 2, w, hh];
}
// o.pad: barre nere sopra e sotto (parte dello schermo, 0..0.2 ciascuna): il contenuto sta nella fascia in mezzo
export const vertPad = (o) => Math.max(0, Math.min(0.2, +((o && o.pad) || 0)));
export function vertRegions(kind, W, H, o = {}) {
  const pad = vertPad(o);
  let regs = vertRegions0(kind, W, H, o, V_ASPECT / (1 - 2 * pad));
  if (pad) regs = regs.map((r) => ({ ...r, d: [r.d[0], pad + r.d[1] * (1 - 2 * pad), r.d[2], r.d[3] * (1 - 2 * pad)] }));
  return vertBoxes(regs, o.boxes);
}
// pezzi spostati o ingranditi a mano (o.boxes[role] = [x, y, w]: stessa forma, altra posizione e grandezza)
export function vertBoxes(regs, boxes) {
  if (!boxes) return regs;
  return regs.map((r) => {
    const b = r.role && boxes[r.role];
    if (!b || r.blur) return r;
    return { ...r, d0: r.d, d: [b[0], b[1], b[2], b[2] * r.d[3] / r.d[2]] };
  }).sort((x, y) => (x.role === 'cam' ? 1 : 0) - (y.role === 'cam' ? 1 : 0));   // la webcam sta sopra il gioco
}
function vertRegions0(kind, W, H, o, a) {
  const camH = o.camH ?? 0.4;
  if (kind === 'split' && o.cam) return [{ d: [0, 0, 1, camH], s: coverRect(o.cam, a / camH), role: 'cam' }, { d: [0, camH, 1, 1 - camH], s: gameRect(W, H, a / (1 - camH), o.gameX ?? 0.5), role: 'game' }];
  if (kind === 'cam' && o.cam) return [{ d: [0, 0, 1, 1], s: coverRect(o.cam, a), role: 'cam' }];
  if (kind === 'rect' && o.rect) return [{ d: [0, 0, 1, 1], s: coverRect(o.rect, a), role: 'main' }];
  if (kind === 'game') return [{ d: [0, 0, 1, 1], s: gameRect(W, H, a, o.gameX ?? 0.5), role: 'game' }];
  if (kind === 'free') {
    // libero: tutto il video (alto come lo schermo) e la webcam intera sopra; si spostano e ingrandiscono a mano
    const gw = (W / H) / a, gx = Math.min(0, Math.max(1 - gw, 0.5 - gw * (o.gameX ?? 0.5)));
    const out = [{ d: [gx, 0, gw, 1], s: [0, 0, W, H], role: 'game' }];   // dietro: nero
    if (o.cam) { const cw = 0.9, chh = cw * a * o.cam[3] / o.cam[2]; out.push({ d: [(1 - cw) / 2, 0.04, cw, chh], s: [...o.cam], role: 'cam' }); }
    return out;
  }
  const fh = a * H / W;
  return [{ d: [0, 0, 1, 1], s: coverRect([0, 0, W, H], a), blur: true }, { d: [0, (1 - fh) / 2, 1, fh], s: [0, 0, W, H], role: 'main' }];
}
export function vertSettings(proj) {
  const v = { layout: 'split', camH: 0.4, gameX: 0.5, ...(proj.vert || {}) };
  const cam = proj.webcam && proj.webcam.box;
  if ((v.layout === 'split' || v.layout === 'cam') && !cam) v.layout = 'fit';
  v.camH = Math.max(0.2, Math.min(0.7, +v.camH || 0.4)); v.gameX = Math.max(0, Math.min(1, v.gameX ?? 0.5)); v.pad = vertPad(v);
  return v;
}
// dove si vede un pezzo della live (box, pixel) nell'impaginazione verticale regs (0..1 dello schermo)
export function vertOnScreen(regs, box) {
  const [bx, by, bw, bh] = box, cx = bx + bw / 2, cy = by + bh / 2;
  const cand = regs.filter((r) => !r.blur);
  const r = cand.find((q) => cx >= q.s[0] && cx <= q.s[0] + q.s[2] && cy >= q.s[1] && cy <= q.s[1] + q.s[3])
    || cand.reduce((m, q) => (q.d[2] * q.d[3] > m.d[2] * m.d[3] ? q : m), cand[0]);
  const kx = r.d[2] / r.s[2], ky = r.d[3] / r.s[3];
  return [r.d[0] + (bx - r.s[0]) * kx, r.d[1] + (by - r.s[1]) * ky, bw * kx, bh * ky];
}
// animazione verso "a tutto schermo" (webcam o inquadratura): il riquadro parte da dove si vede (from) e si allarga
// fino a mostrare box (l'inquadratura finale, di solito 9:16)
export function vertAnimRegs(base, box, p, from, pad = 0) {
  if (p <= 0.0005) return base;
  const f = from || box;
  const d0 = vertOnScreen(base, f), d1 = [0, pad, 1, 1 - 2 * pad];
  const d = d0.map((v, i) => v + (d1[i] - v) * p);
  const mid = f.map((v, i) => v + (box[i] - v) * p);
  const s = coverRect(mid, (d[2] / d[3]) * V_ASPECT);
  const top = { d, s };
  return p >= 0.999 && Math.abs(p - 1) < 1e-3 ? [top] : [...base, top];
}
// inquadratura verticale scelta a mano per uno zoom: [x, y, w] (alta w*16/9), sempre dentro il video
export function vertRect(W, H, r, a = V_ASPECT) {
  let [x, y, w] = r;
  w = Math.max(W / 16, Math.min(H * a, w));
  const hh = w / a;
  return [Math.min(Math.max(0, x), W - w), Math.min(Math.max(0, y), H - hh), w, hh];
}
// da dove parte lo zoom verticale (la webcam o l'inquadratura) e cosa mostra alla fine
export function vertZoomBoxes(z, W, H, cam, a = V_ASPECT) {
  const from = z.kind === 'custom' && z.rect ? customRect(W, H, z.rect) : cam;
  if (!from) return null;
  return { from, box: z.vrect ? vertRect(W, H, z.vrect, a) : from };
}
export const vertZoom = (z) => ({ ...z, in: z.vin || 'fast', out: z.vout || 'fast' });
