// Scorciatoie da tastiera dell'editor: quelle di base e quelle cambiate dall'utente (salvate nelle impostazioni).
import { h, icon, post, toast, IS_MAC } from './lib.js';

// [azione, nome, tasto di base, altri tasti di base]
export const ACTIONS = [
  ['play', 'Riproduci / pausa', ' '],
  ['shuttleBack', 'Riproduci all\'indietro (premi più volte: 2×, 4×)', 'j'],
  ['shuttleStop', 'Pausa', 'k'],
  ['shuttleFwd', 'Riproduci in avanti (premi più volte: 2×, 4×)', 'l'],
  ['back', 'Indietro di 1 secondo (con Maiusc: 5 s)', 'arrowleft'],
  ['fwd', 'Avanti di 1 secondo (con Maiusc: 5 s)', 'arrowright'],
  ['prevEdit', 'Al taglio o alla clip precedente', 'arrowup'],
  ['nextEdit', 'Al taglio o alla clip successiva', 'arrowdown'],
  ['split', 'Dividi nel punto della testina', 's', ['x']],
  ['trimL', 'Taglia prima della testina', 'q'],
  ['trimR', 'Taglia dopo la testina', 'w'],
  ['delete', 'Elimina il selezionato', 'delete', ['backspace']],
  ['marker', 'Aggiungi / togli un marcatore', 'm'],
  ['zoom', 'Aggiungi uno zoom', 'z'],
  ['customZoom', 'Zoom personalizzato', 'c'],
  ['text', 'Aggiungi un testo', 't'],
  ['vertical', 'Clip verticale dalla selezione', 'v'],
  ['snap', 'Aggancio ai bordi (acceso / spento)', 'n'],
  ['full', 'Anteprima a schermo intero', 'f'],
  ['deselect', 'Deseleziona', 'escape'],
];

let custom = {};   // azione -> tasto scelto dall'utente
let loaded = null;
export function loadKeys() {
  if (!loaded) loaded = post('/api/settings', {}).then((s) => { custom = (s && s.shortcuts) || {}; }).catch(() => {});
  return loaded;
}
const baseKeys = (a) => [a[2], ...(a[3] || [])];
export function keysOf(action) {
  const a = ACTIONS.find((x) => x[0] === action);
  if (!a) return [];
  return custom[action] ? [custom[action]] : baseKeys(a);
}
// azione per il tasto premuto (null se nessuna)
export function actionFor(key) {
  const k = key.toLowerCase();
  for (const a of ACTIONS) if (keysOf(a[0]).includes(k)) return a[0];
  return null;
}
const NAMES = { ' ': 'Spazio', arrowleft: '←', arrowright: '→', arrowup: '↑', arrowdown: '↓', delete: 'Canc', backspace: IS_MAC ? '⌫' : 'Backspace', escape: 'Esc', enter: 'Invio', tab: 'Tab' };
export const keyName = (k) => NAMES[k] || (k.length === 1 ? k.toUpperCase() : k.charAt(0).toUpperCase() + k.slice(1));
export const keyLabel = (action) => keysOf(action).map(keyName).join(' / ');

async function save() {
  try { await post('/api/settings', { shortcuts: custom }); } catch (e) { toast(e.message, true); }
}

// finestra per cambiare le scorciatoie
export function keysDialog() {
  const bg = h('div', { class: 'modal-bg' });
  let listening = null;
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); };
  const list = h('div', { class: 'keys-list' });
  const draw = () => {
    list.replaceChildren(...ACTIONS.map((a) => {
      const own = !!custom[a[0]];
      const kb = h('button', { class: 'keycap' + (listening === a[0] ? ' listen' : '') + (own ? ' own' : ''), type: 'button', 'data-notr': '',
        onclick: () => { listening = listening === a[0] ? null : a[0]; draw(); } }, listening === a[0] ? 'Premi un tasto…' : keyLabel(a[0]));
      return h('div', { class: 'keys-row' }, h('span', { class: 'keys-name' }, a[1]), kb,
        own ? h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Rimetti il tasto di base', 'data-tip': 'Rimetti ' + baseKeys(a).map(keyName).join(' / '),
          onclick: async () => { delete custom[a[0]]; await save(); draw(); } }, icon('restore', 14)) : h('span', { class: 'keys-sp' }));
    }));
  };
  const onKey = async (e) => {
    if (e.key === 'Escape' && !listening) { e.preventDefault(); e.stopPropagation(); close(); return; }
    if (!listening) return;
    e.preventDefault(); e.stopPropagation();
    if (['shift', 'control', 'alt', 'meta'].includes(e.key.toLowerCase())) return;
    const k = e.key.toLowerCase();
    const other = ACTIONS.find((a) => a[0] !== listening && keysOf(a[0]).includes(k));
    if (other) {
      // il tasto era di un'altra azione: si scambiano (niente doppioni)
      const mine = keysOf(listening)[0];
      custom[other[0]] = mine;
      toast(`${keyName(k)} era di "${other[1]}": ora quella usa ${keyName(mine)}`);
    }
    const act = ACTIONS.find((a) => a[0] === listening);
    if (k === act[2] && !other) delete custom[listening]; else custom[listening] = k;
    listening = null;
    await save(); draw();
  };
  document.addEventListener('keydown', onKey, true);
  const reset = h('button', { class: 'btn ghost sm', type: 'button', onclick: async () => { custom = {}; await save(); draw(); toast('Scorciatoie rimesse come all\'inizio'); } }, 'Rimetti tutte come all\'inizio');
  bg.append(h('div', { class: 'modal keys-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Scorciatoie da tastiera' },
    h('div', { class: 'keys-head' }, h('h3', null, 'Scorciatoie da tastiera'), h('span', { class: 'muted xs' }, 'Clicca un tasto e premi quello che vuoi usare. Ctrl/Cmd + Z, C, V e S restano sempre uguali.')),
    list,
    h('div', { class: 'keys-foot' }, reset, h('div', { class: 'grow' }), h('button', { class: 'btn primary', type: 'button', onclick: close }, 'Fatto'))));
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  loadKeys().then(draw);
}
