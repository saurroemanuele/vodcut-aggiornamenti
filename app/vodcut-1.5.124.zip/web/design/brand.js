// Grafica: brand kit (per i creator e per le agenzie con piu' clienti): colori, font e loghi sempre a portata di mano.
import { h, icon, toast, get, TOKEN, promptBox, confirmBox, post } from '../lib.js';
import { fontPicker, ensureFont } from '../fonts.js';
import { setBrandColors } from './color.js';

let data = null;
export async function loadBrands() {
  if (data) return data;
  try { data = await get('/api/brands'); } catch (e) { data = { kits: [] }; }
  if (!data.kits) data.kits = [];
  setBrandColors((curKit() || {}).colors || []);
  return data;
}
export const curKit = () => (data && (data.kits.find((k) => k.id === data.current) || data.kits[0])) || null;
async function save() {
  const r = await fetch(`/api/brands?token=${TOKEN}`, { method: 'PUT', body: JSON.stringify(data) });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || 'Non salvato');
  data = j; setBrandColors((curKit() || {}).colors || []);
}
export const logoUrl = (n) => `/api/brands/logo/${n}?token=${TOKEN}`;

// pannello che si apre dalla barra degli strumenti
export async function brandPanel(anchor, { getColor, onColor, onFont, onLogo }) {
  document.querySelectorAll('.dz-brand').forEach((x) => x.remove());
  await loadBrands();
  const el = h('div', { class: 'dz-brand', role: 'dialog', 'aria-label': 'Brand kit' });
  const close = () => { el.remove(); document.removeEventListener('pointerdown', off, true); };
  const off = (e) => { if (!el.contains(e.target) && !anchor.contains(e.target) && !e.target.closest('.dz-cpop,.fmenu,.modal-bg')) close(); };
  const paint = () => {
    const k = curKit();
    const head = h('div', { class: 'dz-bhead' }, h('span', { class: 'dz-aiic' }, icon('palette', 14, '#fff', 2)),
      h('div', null, h('b', null, 'Brand kit'), h('small', null, 'Colori, font e loghi dei tuoi brand o dei tuoi clienti')),
      h('button', { class: 'dz-ib', 'aria-label': 'Chiudi', onclick: close }, icon('x', 14)));
    if (!k) {
      el.replaceChildren(head, h('div', { class: 'dz-bempty' }, h('p', null, 'Salva qui i colori, i font e i loghi che usi sempre: li ritrovi in ogni grafica.'),
        h('button', { class: 'btn primary sm', onclick: async () => { const nm = await promptBox('Nuovo brand', 'Il nome del brand o del cliente', 'Il mio brand', 'Crea'); if (!nm) return; data.kits.push({ id: Math.random().toString(16).slice(2, 10), name: nm, colors: [], fonts: [], logos: [] }); data.current = data.kits[data.kits.length - 1].id; await save().catch((e) => toast(e.message, true)); paint(); } }, icon('plus', 13, '#fff', 2), 'Crea il brand kit')));
      return;
    }
    const kitSel = h('select', { class: 'dz-select' }, ...data.kits.map((x) => h('option', { value: x.id, selected: x.id === k.id ? true : null }, x.name)), h('option', { value: '__new' }, '+ Nuovo brand…'));
    kitSel.addEventListener('change', async () => {
      if (kitSel.value === '__new') { const nm = await promptBox('Nuovo brand', 'Il nome del brand o del cliente', '', 'Crea'); if (nm) { data.kits.push({ id: Math.random().toString(16).slice(2, 10), name: nm, colors: [], fonts: [], logos: [] }); data.current = data.kits[data.kits.length - 1].id; } }
      else data.current = kitSel.value;
      await save().catch((e) => toast(e.message, true)); paint();
    });
    const colors = h('div', { class: 'dz-bcolors' }, ...k.colors.map((c, i) => {
      const b = h('button', { class: 'dz-bsw', style: { background: c }, 'data-tip': c + ' · clic: usa · tasto destro: togli', 'data-notr': '', onclick: () => onColor(c) });
      b.addEventListener('contextmenu', async (e) => { e.preventDefault(); k.colors.splice(i, 1); await save(); paint(); });
      return b;
    }), h('button', { class: 'dz-bsw add', 'data-tip': 'Aggiungi il colore attuale', 'aria-label': 'Aggiungi colore', onclick: async () => { const c = String(getColor() || '').toUpperCase(); if (!/^#[0-9A-F]{6}$/.test(c)) { toast('Scegli prima un colore', true); return; } if (!k.colors.includes(c)) k.colors.push(c); await save().catch((e) => toast(e.message, true)); paint(); } }, icon('plus', 13, 'currentColor', 2)));
    const fonts = h('div', { class: 'dz-bfonts' }, ...k.fonts.map((f, i) => {
      ensureFont(f);
      const b = h('button', { class: 'dz-bfont', style: { fontFamily: `"${f}", Arial` }, 'data-notr': '', onclick: () => onFont(f) }, f,
        h('span', { class: 'dz-bx', 'aria-label': 'Togli', onclick: async (e) => { e.stopPropagation(); k.fonts.splice(i, 1); await save(); paint(); } }, icon('x', 11)));
      return b;
    }), fontPicker('Aggiungi un font…', async (f) => { if (!k.fonts.includes(f)) k.fonts.push(f); await save().catch((e) => toast(e.message, true)); paint(); }));
    const logos = h('div', { class: 'dz-blogos' }, ...k.logos.map((n, i) => {
      const b = h('button', { class: 'dz-blogo', 'data-tip': 'Clic: aggiungi alla grafica · tasto destro: togli', onclick: () => onLogo(n) }, h('img', { src: logoUrl(n), alt: '' }));
      b.addEventListener('contextmenu', async (e) => { e.preventDefault(); if (await confirmBox('Togliere il logo?', 'Le grafiche che lo usano già non cambiano.', 'Togli', true)) { k.logos.splice(i, 1); await save(); paint(); } });
      return b;
    }), h('button', { class: 'dz-blogo add', 'data-tip': 'Aggiungi un logo (PNG con trasparenza)', onclick: () => pickLogo(k) }, icon('plus', 16, 'currentColor', 2)));
    el.replaceChildren(head,
      h('div', { class: 'dz-brow' }, kitSel, h('button', { class: 'dz-ib', 'data-tip': 'Rinomina', 'aria-label': 'Rinomina', onclick: async () => { const nm = await promptBox('Rinomina il brand', null, k.name, 'Rinomina'); if (nm) { k.name = nm; await save(); paint(); } } }, icon('type', 14)),
        h('button', { class: 'dz-ib', 'data-tip': 'Elimina questo brand kit', 'aria-label': 'Elimina', onclick: async () => { if (await confirmBox('Eliminare il brand kit?', `"${k.name}" sparisce da qui. Le grafiche già fatte non cambiano.`, 'Elimina', true)) { data.kits = data.kits.filter((x) => x !== k); data.current = ''; await save(); paint(); } } }, icon('trash', 14))),
      h('div', { class: 'dz-blab' }, 'Colori'), colors,
      h('div', { class: 'dz-blab' }, 'Font'), fonts,
      h('div', { class: 'dz-blab' }, 'Loghi'), logos);
  };
  function pickLogo(k) {
    const inp = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', style: { display: 'none' } });
    inp.addEventListener('change', async () => {
      const f = inp.files[0]; if (!f) return;
      try {
        const r = await fetch(`/api/brands/logo?token=${TOKEN}`, { method: 'PUT', body: f });
        const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Logo non valido');
        k.logos.push(j.logo); await save(); paint();
      } catch (e) { toast(e.message, true); }
      inp.remove();
    });
    document.body.append(inp); inp.click();
  }
  paint();
  document.body.append(el);
  const r = anchor.getBoundingClientRect();
  el.style.left = r.right + 10 + 'px';
  el.style.top = '96px';
  setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  void post;
}
