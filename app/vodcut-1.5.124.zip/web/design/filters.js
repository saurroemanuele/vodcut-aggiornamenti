// Grafica: filtri sui pixel (come il menu Filtro di Photoshop). Ogni filtro: tela -> tela nuova della stessa misura.
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, w); c.height = Math.max(1, h); return c; };
const data = (c) => c.getContext('2d').getImageData(0, 0, c.width, c.height);
const copyOf = (c) => { const o = mk(c.width, c.height); o.getContext('2d').drawImage(c, 0, 0); return o; };

// sfocatura gaussiana (il bordo trasparente non "entra" dentro l'immagine)
export function gaussian(c, r) {
  if (r <= 0) return copyOf(c);
  const o = mk(c.width, c.height), g = o.getContext('2d');
  g.filter = `blur(${r}px)`; g.drawImage(c, 0, 0); g.filter = 'none';
  return o;
}
// maschera di contrasto: nitidezza "vera"
export function unsharp(c, amount = 1, radius = 2, threshold = 0) {
  const b = data(gaussian(c, radius)).data, im = data(c), d = im.data, k = amount;
  for (let i = 0; i < d.length; i += 4) {
    for (let j = 0; j < 3; j++) { const diff = d[i + j] - b[i + j]; if (Math.abs(diff) >= threshold) d[i + j] = d[i + j] + diff * k; }
  }
  const o = mk(c.width, c.height); o.getContext('2d').putImageData(im, 0, 0); return o;
}
export function addNoise(c, amount = 20, mono = true) {
  const im = data(c), d = im.data, a = amount * 2.55;
  for (let i = 0; i < d.length; i += 4) {
    if (!d[i + 3]) continue;
    if (mono) { const n = (Math.random() + Math.random() + Math.random() - 1.5) * a * 0.8; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
    else { d[i] += (Math.random() - 0.5) * a; d[i + 1] += (Math.random() - 0.5) * a; d[i + 2] += (Math.random() - 0.5) * a; }
  }
  const o = mk(c.width, c.height); o.getContext('2d').putImageData(im, 0, 0); return o;
}
// mosso: tante copie spostate lungo una direzione
export function motionBlur(c, angle = 0, dist = 20) {
  const o = mk(c.width, c.height), g = o.getContext('2d');
  const n = Math.max(2, Math.min(64, Math.round(dist / 1.5))), a = angle * Math.PI / 180;
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1) - 0.5;
    g.globalAlpha = 1 / (i + 1);   // media che si accumula (ogni copia pesa uguale)
    g.drawImage(c, Math.cos(a) * dist * t, -Math.sin(a) * dist * t);
  }
  return o;
}
// radiale: zoom (verso il centro) o rotazione
export function radialBlur(c, amount = 20, mode = 'zoom', cx = 0.5, cy = 0.5) {
  const o = mk(c.width, c.height), g = o.getContext('2d'), n = 32, X = c.width * cx, Y = c.height * cy;
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1) - 0.5;
    g.save(); g.globalAlpha = 1 / (i + 1); g.translate(X, Y);
    if (mode === 'spin') g.rotate(t * amount * Math.PI / 180);
    else { const s = 1 + t * amount / 100; g.scale(s, s); }
    g.drawImage(c, -X, -Y); g.restore();
  }
  return o;
}
export function pixelate(c, size = 12) {
  const s = Math.max(1, Math.round(size)), w = Math.max(1, Math.ceil(c.width / s)), h = Math.max(1, Math.ceil(c.height / s));
  const small = mk(w, h), sg = small.getContext('2d'); sg.imageSmoothingQuality = 'high'; sg.drawImage(c, 0, 0, w, h);
  const o = mk(c.width, c.height), g = o.getContext('2d'); g.imageSmoothingEnabled = false; g.drawImage(small, 0, 0, w * s, h * s);
  return o;
}
// spostamento dei pixel con una funzione (onda, vortice)
function remap(c, fn) {
  const W = c.width, H = c.height, src = data(c).data, o = mk(W, H), og = o.getContext('2d'), out = og.createImageData(W, H), d = out.data;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const [sx, sy] = fn(x + 0.5, y + 0.5);
    const fx = sx - 0.5, fy = sy - 0.5, x0 = Math.floor(fx), y0 = Math.floor(fy), ax = fx - x0, ay = fy - y0, o4 = (y * W + x) * 4;
    let r = 0, g = 0, b = 0, a = 0;
    for (let k = 0; k < 4; k++) {
      const xx = x0 + (k & 1), yy = y0 + (k >> 1);
      if (xx < 0 || yy < 0 || xx >= W || yy >= H) continue;
      const w = ((k & 1) ? ax : 1 - ax) * ((k >> 1) ? ay : 1 - ay), i = (yy * W + xx) * 4, al = src[i + 3] * w;
      r += src[i] * al; g += src[i + 1] * al; b += src[i + 2] * al; a += al;
    }
    if (a > 0) { d[o4] = r / a; d[o4 + 1] = g / a; d[o4 + 2] = b / a; d[o4 + 3] = a; }
  }
  og.putImageData(out, 0, 0); return o;
}
export function wave(c, amp = 10, length = 80, dir = 'h') {
  const k = 2 * Math.PI / Math.max(2, length);
  return remap(c, (x, y) => (dir === 'h' ? [x, y + Math.sin(x * k) * amp] : dir === 'v' ? [x + Math.sin(y * k) * amp, y] : [x + Math.sin(y * k) * amp, y + Math.sin(x * k) * amp]));
}
export function twirl(c, angle = 90) {
  const cx = c.width / 2, cy = c.height / 2, R = Math.min(cx, cy), A = angle * Math.PI / 180;
  return remap(c, (x, y) => {
    const dx = x - cx, dy = y - cy, r = Math.hypot(dx, dy);
    if (r >= R) return [x, y];
    const t = (1 - r / R), a = A * t * t, cs = Math.cos(a), sn = Math.sin(a);
    return [cx + dx * cs - dy * sn, cy + dx * sn + dy * cs];
  });
}
export function emboss(c, strength = 1) {
  const W = c.width, H = c.height, im = data(c), s = im.data, o = mk(W, H), og = o.getContext('2d'), out = og.createImageData(W, H), d = out.data;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4, j = (Math.max(0, y - 1) * W + Math.max(0, x - 1)) * 4, k = (Math.min(H - 1, y + 1) * W + Math.min(W - 1, x + 1)) * 4;
    const L = (q) => 0.299 * s[q] + 0.587 * s[q + 1] + 0.114 * s[q + 2];
    const v = 128 + (L(k) - L(j)) * 2 * strength;
    d[i] = v; d[i + 1] = v; d[i + 2] = v; d[i + 3] = s[i + 3];
  }
  og.putImageData(out, 0, 0); return o;
}

// effetti dei pennelli (scherma, brucia, spugna, sfoca, nitidezza): l'immagine "tutta cambiata", che il pennello rivela
export function brushEffect(c, kind, amt = 0.5) {
  if (kind === 'blur') return gaussian(c, 2 + amt * 10);
  if (kind === 'sharpen') return unsharp(c, 0.6 + amt * 1.8, 1.5, 0);
  const im = data(c), d = im.data;
  const lut = new Uint8ClampedArray(256);
  if (kind === 'dodge' || kind === 'burn') {
    const gma = kind === 'dodge' ? 1 / (1 + amt * 1.2) : 1 + amt * 1.4;
    for (let i = 0; i < 256; i++) lut[i] = 255 * Math.pow(i / 255, gma);
    for (let i = 0; i < d.length; i += 4) { d[i] = lut[d[i]]; d[i + 1] = lut[d[i + 1]]; d[i + 2] = lut[d[i + 2]]; }
  } else if (kind === 'sat' || kind === 'desat') {
    const k = kind === 'sat' ? 1 + amt * 1.5 : 1 - Math.min(1, amt * 1.4);
    for (let i = 0; i < d.length; i += 4) { const l = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; d[i] = l + (d[i] - l) * k; d[i + 1] = l + (d[i + 1] - l) * k; d[i + 2] = l + (d[i + 2] - l) * k; }
  }
  const o = mk(c.width, c.height); o.getContext('2d').putImageData(im, 0, 0); return o;
}

// elenco per il menu Filtri: parametri per il pannello
export const FILTERS = [
  { id: 'gauss', name: 'Sfocatura gaussiana', params: [['r', 'Raggio', 0, 80, 0.5, 6, ' px']], run: (c, p, k) => gaussian(c, p.r * k) },
  { id: 'motion', name: 'Sfocatura di movimento', params: [['a', 'Angolo', -180, 180, 1, 0, '°'], ['d', 'Distanza', 1, 300, 1, 30, ' px']], run: (c, p, k) => motionBlur(c, p.a, p.d * k) },
  { id: 'radial', name: 'Sfocatura radiale', params: [['amt', 'Intensità', 1, 100, 1, 25, ''], ['mode', 'Tipo', [['zoom', 'Zoom'], ['spin', 'Rotazione']], 'zoom']], run: (c, p) => radialBlur(c, p.amt, p.mode) },
  { id: 'unsharp', name: 'Maschera di contrasto', params: [['amt', 'Quantità', 0, 300, 1, 80, '%'], ['r', 'Raggio', 0.5, 20, 0.5, 2, ' px'], ['t', 'Soglia', 0, 50, 1, 2, '']], run: (c, p, k) => unsharp(c, p.amt / 100, p.r * k, p.t) },
  { id: 'noise', name: 'Aggiungi disturbo (grana)', params: [['amt', 'Quantità', 1, 60, 1, 12, '%'], ['mono', 'Monocromatico', 'bool', true]], run: (c, p) => addNoise(c, p.amt, p.mono) },
  { id: 'denoise', name: 'Riduci disturbo', params: [['s', 'Intensità', 1, 30, 1, 8, '']], server: true },
  { id: 'pixel', name: 'Pixel (mosaico)', params: [['s', 'Dimensione', 2, 100, 1, 14, ' px']], run: (c, p, k) => pixelate(c, p.s * k) },
  { id: 'wave', name: 'Onda', params: [['amp', 'Ampiezza', 0, 100, 1, 12, ' px'], ['len', 'Lunghezza', 10, 600, 1, 120, ' px'], ['dir', 'Direzione', [['h', 'Orizzontale'], ['v', 'Verticale'], ['b', 'Entrambe']], 'h']], run: (c, p, k) => wave(c, p.amp * k, p.len * k, p.dir) },
  { id: 'twirl', name: 'Vortice', params: [['a', 'Angolo', -720, 720, 1, 180, '°']], run: (c, p) => twirl(c, p.a) },
  { id: 'emboss', name: 'Rilievo', params: [['s', 'Intensità', 0.2, 4, 0.1, 1, '']], run: (c, p) => emboss(c, p.s) },
];
