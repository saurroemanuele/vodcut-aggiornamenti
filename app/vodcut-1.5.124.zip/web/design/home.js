// Home, sezione Grafica: nuovi formati in un clic, apri un'immagine, togli lo sfondo, le tue grafiche.
import { h, icon, toast, get, post, api, TOKEN, confirmBox, promptBox, mediaUrl } from '../lib.js';
import { readPsd } from './psd.js';
import { PRESETS } from './doc.js';

const HERO = ['ig-post', 'ig-45', 'story', 'yt-thumb', 'carousel'];
const presetOf = (id) => PRESETS.find((p) => p[0] === id);

function shapeIcon(w, hh, max = 30) {
  const k = max / Math.max(w, hh);
  return h('i', { class: 'gh-ratio', style: { width: Math.max(8, w * k) + 'px', height: Math.max(8, hh * k) + 'px' } });
}

export function designHome(nav) {
  let creating = false;
  async function create(p, extra = {}) {
    if (creating) return null;
    creating = true;
    try {
      const d = await post('/api/designs', { name: p ? p[1] : 'Grafica', w: p ? p[3] : 1080, h: p ? p[4] : 1080, preset: p ? p[0] : 'custom',
        bg: p && p[0] === 'logo' ? null : '#FFFFFF', pages: p && p[0] === 'carousel' ? 3 : 1, ...extra });
      return d;
    } catch (e) { toast(e.message, true); return null; } finally { creating = false; }
  }
  const open = async (p) => { const d = await create(p); if (d) nav('design', d.id); };
  // un'immagine dal computer: la grafica prende le sue misure
  async function fromImage(cut) {
    try {
      const r = await post('/api/pick', { kind: 'images' });
      if (r.fallback) { toast('Selettore non disponibile', true); return; }
      const paths = Array.isArray(r) ? r : r.path ? (Array.isArray(r.path) ? r.path : [r.path]) : r.paths || [];
      if (!paths.length) return;
      busy(true);
      if (/\.psd$/i.test(paths[0])) { await fromPsd(paths[0]); busy(false); return; }
      const d = await create(null, { name: 'Immagine', bg: cut ? null : '#FFFFFF' });
      if (!d) { busy(false); return; }
      const im = await post(`/api/d/${d.id}/import`, { paths: paths.slice(0, 1) });
      const f = im.files[0];
      if (!f) { busy(false); toast('Immagine non leggibile', true); return; }
      const k = Math.min(1, 6000 / Math.max(f.w, f.h));
      d.w = Math.round(f.w * k); d.h = Math.round(f.h * k); d.name = f.name || 'Immagine';
      d.pages[0].layers = [{ id: 'l' + Math.random().toString(36).slice(2, 10), type: 'image', name: f.name || 'Immagine', visible: true, locked: false, opacity: 1, blend: 'normal',
        x: 0, y: 0, w: d.w, h: d.h, rot: 0, flipX: false, flipY: false, src: f.file, iw: f.w, ih: f.h }];
      const rr = await fetch(`/api/d/${d.id}?token=${TOKEN}`, { method: 'PUT', body: JSON.stringify(d) });
      if (!rr.ok) throw new Error('Non riesco a creare la grafica');
      nav('design', d.id, cut ? { autoCut: true } : null);
    } catch (e) { toast(e.message, true); }
    busy(false);
  }
  // file di Photoshop: livelli, nomi, opacita' e fusione restano
  async function fromPsd(path) {
    const r = await fetch(mediaUrl(path));
    if (!r.ok) throw new Error('Non riesco ad aprire il PSD');
    const buf = await r.arrayBuffer();
    const name = path.split(/[\\/]/).pop().replace(/\.psd$/i, '');
    const d = await create(null, { name, bg: null });
    if (!d) return;
    const up = async (cv) => {
      const b = await new Promise((res) => cv.toBlob(res, 'image/png'));
      const rr = await fetch(`/api/d/${d.id}/file?kind=psd&token=${TOKEN}`, { method: 'PUT', body: b });
      const j = await rr.json(); if (!rr.ok) throw new Error(j.error || 'Livello non valido'); return j.file;
    };
    const res = await readPsd(buf, up, (p) => { busyMsg.textContent = 'Apro il PSD… ' + Math.round(p * 100) + '%'; });
    d.w = res.w; d.h = res.h; d.name = name; d.pages[0].layers = res.layers;
    const rr = await fetch(`/api/d/${d.id}?token=${TOKEN}`, { method: 'PUT', body: JSON.stringify(d) });
    if (!rr.ok) throw new Error('Non riesco a creare la grafica');
    nav('design', d.id);
  }
  const busyMsg = h('span', null, 'Preparo la grafica…');
  const busyEl = h('div', { class: 'gh-busy', style: { display: 'none' } }, h('div', { class: 'spinner' }), busyMsg);
  const busy = (v) => { busyEl.style.display = v ? '' : 'none'; if (v) busyMsg.textContent = 'Preparo la grafica…'; };

  function allFormats() {
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const wI = h('input', { class: 'input', value: '1080', inputmode: 'numeric', 'aria-label': 'Larghezza' }), hI = h('input', { class: 'input', value: '1080', inputmode: 'numeric', 'aria-label': 'Altezza' });
    const CAT = [['social', 'Social'], ['video', 'Video e streaming'], ['print', 'Stampa e altro']];
    bg.append(h('div', { class: 'modal gh-fmodal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Nuova grafica' },
      h('h2', null, 'Nuova grafica'),
      ...CAT.map(([c, n]) => h('div', { class: 'gh-fcat' }, h('div', { class: 'gh-fcl' }, n),
        h('div', { class: 'gh-fgrid' }, ...PRESETS.filter((p) => p[5] === c).map((p) => h('button', { class: 'gh-ft', onclick: () => { close(); open(p); } },
          h('span', { class: 'gh-fr' }, shapeIcon(p[3], p[4], 34)), h('b', null, p[1]), h('small', null, p[2])))))),
      h('div', { class: 'gh-fcat' }, h('div', { class: 'gh-fcl' }, 'Misura personalizzata'),
        h('div', { class: 'row gh-custom' }, wI, h('span', null, '×'), hI, h('span', { class: 'muted' }, 'px'), h('div', { class: 'grow' }),
          h('button', { class: 'btn primary', onclick: () => {
            const w = Math.round(+wI.value), hh = Math.round(+hI.value);
            if (!(w >= 1 && hh >= 1 && w <= 16000 && hh <= 16000)) { toast('Misure da 1 a 16000 px', true); return; }
            close(); open([null, 'Grafica', '', w, hh]);
          } }, 'Crea'))),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Chiudi'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  const hero = h('div', { class: 'gh-top' },
    h('div', { class: 'gh-new' },
      h('div', { class: 'hn-head' },
        h('span', { class: 'hn-plus gh' }, icon('plus', 22, '#fff', 2.4)),
        h('div', null, h('h1', null, 'Nuova grafica'), h('p', null, 'Post, storie, miniature, caroselli: livelli, testi ed effetti come in Photoshop'))),
      h('div', { class: 'gh-chips' }, ...HERO.map((id) => { const p = presetOf(id); return h('button', { class: 'gh-chip', onclick: () => open(p) }, h('span', { class: 'gh-cr' }, shapeIcon(p[3], p[4], 26)), h('b', null, p[1]), h('small', null, p[2].split(' · ')[0])); }),
        h('button', { class: 'gh-chip more', onclick: allFormats }, h('span', { class: 'gh-cr' }, icon('grid', 20, 'currentColor', 1.7)), h('b', null, 'Tutti i formati'), h('small', null, 'o misura libera')))),
    h('button', { class: 'hcard', onclick: () => fromImage(false) },
      h('div', { class: 'hc-art art-img' }, h('span', { class: 'ai-photo' }), h('span', { class: 'ai-layer a' }), h('span', { class: 'ai-layer b' })),
      h('div', { class: 'hc-txt' }, h('b', null, 'Modifica un\'immagine'), h('span', null, 'Apri una foto o un PSD e lavorali a livelli'))),
    h('button', { class: 'hcard', onclick: () => fromImage(true) },
      h('div', { class: 'hc-art art-nobg' }, h('span', { class: 'cut-bg' }), h('span', { class: 'cut-fg' }), h('span', { class: 'art-pill ai' }, icon('sparkle', 11, '#fff', 2.2), 'AI')),
      h('div', { class: 'hc-txt' }, h('b', null, 'Rimuovi lo sfondo'), h('span', null, 'Persona o prodotto scontornati in un clic, gratis'))));

  // le tue grafiche
  const grid = h('div', { class: 'pgrid' });
  const search = h('input', { class: 'psearch', type: 'search', placeholder: 'Cerca una grafica' });
  const count = h('span', { class: 'pcount' });
  const trashN = h('span', { class: 'trash-n' });
  const sec = h('section', { class: 'projects' },
    h('div', { class: 'phead' }, h('h2', null, 'Le tue grafiche'), count, h('div', { class: 'grow' }),
      h('label', { class: 'psearch-w' }, icon('magnify', 14), search),
      h('button', { class: 'btn ghost sm', 'data-tip': 'Le grafiche eliminate restano qui per 30 giorni', onclick: trashDialog }, icon('trash', 14), 'Cestino', trashN)),
    grid);
  const ago = (ts) => {
    const d = Date.now() / 1000 - ts;
    if (d < 90) return 'adesso'; if (d < 3600) return Math.round(d / 60) + ' min fa';
    if (d < 86400) return Math.round(d / 3600) + (Math.round(d / 3600) === 1 ? ' ora fa' : ' ore fa');
    if (d < 172800) return 'ieri'; if (d < 7 * 86400) return Math.round(d / 86400) + ' giorni fa';
    return new Date(ts * 1000).toLocaleDateString([], { day: 'numeric', month: 'short' });
  };
  function card(d) {
    const frame = h('div', { class: 'pc-frame gh-frame', style: { aspectRatio: d.w + ' / ' + d.h } });
    if (d.cover) {
      const im = h('img', { src: `/api/d/${d.id}/file/cover.png?token=${TOKEN}&v=${Math.round(d.updated)}`, alt: '', loading: 'lazy', decoding: 'async' });
      im.addEventListener('error', () => { im.remove(); frame.classList.add('empty'); frame.append(icon('image', 22, 'currentColor', 1.6)); });
      frame.append(im);
    } else { frame.classList.add('empty'); frame.append(icon('image', 22, 'currentColor', 1.6)); }
    const shot = h('div', { class: 'pc-shot gh-shot' + (d.w < d.h ? ' v' : '') }, frame);
    const titleEl = h('div', { class: 't', 'data-notr': '' }, d.name);
    const ren = h('button', { class: 'pc-act', 'aria-label': 'Rinomina', 'data-tip': 'Rinomina', onclick: async (e) => {
      e.stopPropagation(); const nm = await promptBox('Rinomina la grafica', null, d.name, 'Rinomina'); if (!nm || nm === d.name) return;
      try { const r = await post(`/api/d/${d.id}/meta`, { name: nm }); d.name = r.name; titleEl.textContent = r.name; c.dataset.name = r.name.toLowerCase(); } catch (er) { toast(er.message, true); }
    } }, icon('type', 14));
    const dup = h('button', { class: 'pc-act', 'aria-label': 'Duplica', 'data-tip': 'Duplica', onclick: async (e) => { e.stopPropagation(); try { await post(`/api/d/${d.id}/duplicate`, {}); load(); toast('Grafica duplicata'); } catch (er) { toast(er.message, true); } } }, icon('duplicate', 14));
    const del = h('button', { class: 'pc-act', 'aria-label': 'Elimina', 'data-tip': 'Elimina', onclick: async (e) => {
      e.stopPropagation();
      if (!(await confirmBox('Spostare nel cestino?', `"${d.name}" va nel cestino: per 30 giorni la recuperi quando vuoi.`, 'Sposta nel cestino', true))) return;
      await api('DELETE', '/api/d/' + d.id); c.remove(); count.textContent = String(grid.children.length); refreshTrash(); toast('Grafica nel cestino');
    } }, icon('trash', 14));
    shot.append(h('span', { class: 'pc-fmt' }, h('i', { style: { aspectRatio: d.w + ' / ' + d.h } }), d.w + '×' + d.h), d.pages > 1 ? h('span', { class: 'pc-dur' }, d.pages + ' pagine') : '', h('div', { class: 'pc-acts' }, ren, dup, del));
    const useTpl = async () => { try { const n = await post(`/api/d/${d.id}/duplicate`, { name: d.name }); nav('design', n.id); } catch (er) { toast(er.message, true); } };
    if (d.template) shot.append(h('span', { class: 'gh-tpl' }, icon('star', 11, '#fff', 2.2), 'Modello'),
      h('button', { class: 'pc-act gh-tedit', 'data-tip': 'Modifica il modello', 'aria-label': 'Modifica il modello', onclick: (e) => { e.stopPropagation(); nav('design', d.id); } }, icon('pen', 14)));
    const c = h('div', { class: 'rcard pcard', role: 'button', tabindex: '0', 'data-name': (d.name || '').toLowerCase(), 'data-tip': d.template ? 'Clic: nuova grafica da questo modello' : null, onclick: () => (d.template ? useTpl() : nav('design', d.id)) },
      shot, h('div', { class: 'pc-info' }, titleEl, h('div', { class: 'pc-meta' }, h('span', { class: 'pc-kind' }, icon('image', 11, 'currentColor', 2), 'Grafica'), h('span', null, '·'), h('span', null, ago(d.updated)))));
    c.addEventListener('keydown', (e) => { if (e.key === 'Enter') c.click(); });
    return c;
  }
  function filter() {
    const q = search.value.trim().toLowerCase(); let n = 0;
    for (const c of grid.children) { const ok = !q || (c.dataset.name || '').includes(q); c.style.display = ok ? '' : 'none'; if (ok) n++; }
    count.textContent = String(n);
  }
  search.addEventListener('input', filter);
  async function load() {
    let list = [];
    try { list = await get('/api/designs'); } catch (e) { /* */ }
    if (!list.length) {
      grid.replaceChildren(h('div', { class: 'pempty' }, icon('image', 26, 'currentColor', 1.5), h('b', null, 'Ancora nessuna grafica'), h('span', null, 'Scegli un formato qui sopra: in un attimo sei nell\'editor.')));
      count.textContent = '0';
    } else { grid.replaceChildren(...list.filter((d) => !d.template).map(card)); filter(); }
    const tpls = list.filter((d) => d.template);
    tplSec.style.display = tpls.length ? '' : 'none';
    tplGrid.replaceChildren(...tpls.map(card));
    refreshTrash();
  }
  const refreshTrash = () => get('/api/designs/trash').then((l) => { trashN.textContent = l.length ? String(l.length) : ''; }).catch(() => {});
  async function trashDialog() {
    const list = await get('/api/designs/trash').catch(() => []);
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    bg.append(h('div', { class: 'modal', style: { width: 'min(520px, 94vw)' } }, h('h2', null, 'Cestino delle grafiche'),
      list.length ? h('div', { class: 'gh-trash' }, ...list.map((d) => h('div', { class: 'gh-trow' }, h('span', { 'data-notr': '' }, d.name), h('small', { class: 'muted' }, d.w + '×' + d.h), h('div', { class: 'grow' }),
        h('button', { class: 'btn sm', onclick: async () => { await post(`/api/d/${d.id}/restore`, {}); close(); load(); toast('Grafica recuperata'); } }, icon('restore', 13), 'Recupera'))))
        : h('p', null, 'Il cestino è vuoto.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Chiudi'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }
  load();
  const tplGrid = h('div', { class: 'pgrid' });
  const tplSec = h('section', { class: 'projects', style: { display: 'none' } }, h('div', { class: 'phead' }, h('h2', null, 'I tuoi modelli'), h('span', { class: 'muted small' }, 'Un clic crea una grafica nuova uguale: il modello resta com\'è')), tplGrid);
  return h('div', { class: 'ghome' }, hero, busyEl, tplSec, sec);
}
