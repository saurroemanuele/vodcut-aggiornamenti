// Grafica: esportazione in SVG. Forme, tracciati e testi restano vettoriali (si modificano in Illustrator, Figma,
// Inkscape...). Quello che l'SVG non sa fare (effetti, filtri, maschere, deformazioni) diventa un'immagine al suo posto.
import { layerBitmap, layoutText, layoutVertical, textRuns, SHAPE_LIB, svgCmds, renderLayers, pathPad, fillColor } from './render.js';

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const n = (v) => (Math.round(v * 100) / 100).toString();
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; };

export function buildSvg(doc, page, assets, { scale = 2 } = {}) {
  const defs = [], body = [], fonts = new Set();
  let uid = 0;
  const id = (p) => p + (++uid);
  // colore o sfumatura (come fillStyle in render.js, in coordinate del livello 0..w, 0..h)
  const paint = (fill, w, h) => {
    if (!fill) return 'none';
    if (typeof fill === 'string') return esc(fill);
    const gid = id('g'), stops = (fill.stops || []).map(([o, c]) => `<stop offset="${n(Math.max(0, Math.min(1, o)))}" stop-color="${esc(c)}"/>`).join('');
    if (fill.type === 'radial') defs.push(`<radialGradient id="${gid}" gradientUnits="userSpaceOnUse" cx="${n(w / 2)}" cy="${n(h / 2)}" r="${n(Math.max(w, h) / 2)}">${stops}</radialGradient>`);
    else {
      const a = ((fill.angle || 0) - 90) * Math.PI / 180, r = (Math.abs(w * Math.cos(a)) + Math.abs(h * Math.sin(a))) / 2;
      defs.push(`<linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="${n(w / 2 - Math.cos(a) * r)}" y1="${n(h / 2 - Math.sin(a) * r)}" x2="${n(w / 2 + Math.cos(a) * r)}" y2="${n(h / 2 + Math.sin(a) * r)}">${stops}</linearGradient>`);
    }
    return `url(#${gid})`;
  };
  const tf = (l) => `translate(${n(l.x + l.w / 2)} ${n(l.y + l.h / 2)})${l.rot ? ` rotate(${n(l.rot)})` : ''}${l.flipX || l.flipY ? ` scale(${l.flipX ? -1 : 1} ${l.flipY ? -1 : 1})` : ''} translate(${n(-l.w / 2)} ${n(-l.h / 2)})`;
  const op = (l) => (l.opacity != null && l.opacity < 1 ? ` opacity="${n(l.opacity)}"` : '') + (l.blend && l.blend !== 'normal' ? ` style="mix-blend-mode:${l.blend}"` : '');
  const anyFx = (l) => l.fx && Object.values(l.fx).some((x) => x && x.on);
  const anyFilter = (l) => l.filters && Object.values(l.filters).some((v) => v);
  const vectorOk = (l) => (l.type === 'shape' || l.type === 'path' || (l.type === 'text' && !l.curve && !l.onPath)) && !anyFx(l) && !anyFilter(l) && !l.mask && !l.warp;
  const png = (c) => c.toDataURL('image/png');
  // un livello come immagine (con effetti, maschera, filtri, deformazione)
  const raster = (l) => {
    const bm = layerBitmap(l, scale, assets, new Map());
    const rs = bm.rs, pad = bm.pad / rs, cw = bm.cv.width / rs, ch = bm.cv.height / rs;
    return `<g transform="${tf(l)}"${op(l)}><image x="${n(-pad)}" y="${n(-pad)}" width="${n(cw)}" height="${n(ch)}" preserveAspectRatio="none" href="${png(bm.cv)}"/></g>`;
  };
  const shapeEl = (l, extra) => {
    const w = l.w, h = l.h;
    if (l.kind === 'ellipse') return `<ellipse cx="${n(w / 2)}" cy="${n(h / 2)}" rx="${n(w / 2)}" ry="${n(h / 2)}"${extra}/>`;
    if (l.kind === 'triangle') return `<polygon points="${n(w / 2)},0 ${n(w)},${n(h)} 0,${n(h)}"${extra}/>`;
    if (l.kind === 'star' || l.kind === 'poly') {
      const k = l.kind === 'star' ? Math.max(3, l.sides || 5) : Math.max(3, l.sides || 6), cnt = l.kind === 'star' ? k * 2 : k, pts = [];
      for (let i = 0; i < cnt; i++) { const a = -Math.PI / 2 + i * Math.PI * 2 / cnt, r = l.kind === 'star' && i % 2 ? (l.inner || 0.45) : 1; pts.push(n(w / 2 + Math.cos(a) * w / 2 * r) + ',' + n(h / 2 + Math.sin(a) * h / 2 * r)); }
      return `<polygon points="${pts.join(' ')}"${extra}/>`;
    }
    if (l.kind === 'lib') {
      const d = svgCmds((SHAPE_LIB[l.lib] || SHAPE_LIB.arrow)[1]).map((c) => (c[0] === 'Z' ? 'Z' : c[0] + c.slice(1).map((v, i) => n(v * (i % 2 ? h : w) / 100)).join(' '))).join(' ');
      return `<path d="${d}" fill-rule="evenodd"${extra}/>`;
    }
    const r = Math.max(0, Math.min(l.radius || 0, w / 2, h / 2));
    return `<rect width="${n(w)}" height="${n(h)}"${r ? ` rx="${n(r)}"` : ''}${extra}/>`;
  };
  const pathD = (l) => {
    const m = pathPad(l), iw = l.w - 2 * m, ih = l.h - 2 * m, X = (v) => n(m + v * iw), Y = (v) => n(m + v * ih);
    const one = (P, closed) => {
      if (!P || P.length < 2) return '';
      let d = `M${X(P[0].x)} ${Y(P[0].y)}`;
      const seg = (a, b) => (!a.ox && !a.oy && !b.ix && !b.iy ? ` L${X(b.x)} ${Y(b.y)}` : ` C${X(a.x + (a.ox || 0))} ${Y(a.y + (a.oy || 0))} ${X(b.x + (b.ix || 0))} ${Y(b.y + (b.iy || 0))} ${X(b.x)} ${Y(b.y)}`);
      for (let i = 1; i < P.length; i++) d += seg(P[i - 1], P[i]);
      if (closed && P.length > 2) d += seg(P[P.length - 1], P[0]) + ' Z';
      return d;
    };
    return [one(l.pts, l.closed), ...(l.extra || []).map((c) => one(c.pts, c.closed !== false))].join(' ');
  };
  const fontAttr = (L) => { fonts.add(L.font || 'Inter'); return ` font-family="${esc(L.font || 'Inter')}, Arial, sans-serif" font-size="${n(L.size)}" font-weight="${L.weight || 400}"${L.italic ? ' font-style="italic"' : ''}`; };
  const deco = (st, l) => { const u = st.under != null ? st.under : l.under, s = st.strike != null ? st.strike : l.strike; return u || s ? ` text-decoration="${[u ? 'underline' : '', s ? 'line-through' : ''].filter(Boolean).join(' ')}"` : ''; };
  const textEl = (l) => {
    const base = paint(l.fill || l.color, l.w, l.h), out = [];
    const ls = l.letter ? ` letter-spacing="${n(l.letter)}"` : '';
    if (l.vertical) {
      const V = layoutVertical(l), off = l.align === 'left' ? 0 : l.align === 'right' ? 1 : 0.5;
      for (const c of V.cols) {
        const y0 = (V.h - c.h) * off;
        for (const it of c.items) {
          const L = { ...l, ...it.st };
          out.push(`<text x="${n(c.x + c.w / 2)}" y="${n(y0 + it.y + it.size * 0.5)}" text-anchor="middle" dominant-baseline="middle"${fontAttr(L)} fill="${it.st.color ? esc(it.st.color) : base}"${deco(it.st, l)}>${esc(it.t)}</text>`);
        }
      }
      return out.join('');
    }
    const T = layoutText(l);
    for (const ln of T.lines) {
      if (!ln.items.length) continue;
      const x = l.align === 'left' ? 0 : l.align === 'right' ? l.w - ln.w : (l.w - ln.w) / 2, cy = ln.top + ln.h / 2;
      const spans = ln.items.map((it) => {
        const L = { ...l, ...it.st };
        return `<tspan y="${n(cy + (ln.size - it.size) * 0.35)}"${fontAttr(L)} fill="${it.st.color ? esc(it.st.color) : base}"${deco(it.st, l)}>${esc(it.t)}</tspan>`;
      }).join('');
      out.push(`<text x="${n(x)}" dominant-baseline="middle" xml:space="preserve"${ls}>${spans}</text>`);
    }
    return out.join('');
  };
  const vector = (l) => {
    let inner = '';
    if (l.type === 'shape' && l.kind === 'line') {
      const c = esc(fillColor(l.fill || l.stroke || '#000')), arrows = l.arrowStart || l.arrowEnd, lw = arrows ? l.h / 3.5 * 0.9 : l.h * 0.9, hl = Math.min(l.w * 0.45, l.h * 1.1);
      inner = `<line x1="${n(l.arrowStart ? hl * 0.6 : 0)}" y1="${n(l.h / 2)}" x2="${n(l.w - (l.arrowEnd ? hl * 0.6 : 0))}" y2="${n(l.h / 2)}" stroke="${c}" stroke-width="${n(lw)}" stroke-linecap="${arrows ? 'butt' : 'round'}"/>`;
      if (l.arrowEnd) inner += `<polygon points="${n(l.w)},${n(l.h / 2)} ${n(l.w - hl)},0 ${n(l.w - hl)},${n(l.h)}" fill="${c}"/>`;
      if (l.arrowStart) inner += `<polygon points="0,${n(l.h / 2)} ${n(hl)},0 ${n(hl)},${n(l.h)}" fill="${c}"/>`;
    } else if (l.type === 'shape') {
      inner = shapeEl(l, ` fill="${paint(l.fill, l.w, l.h)}"`);
      if (l.stroke && l.strokeW > 0) {
        // il bordo delle forme sta dentro (come nell'editor)
        const cid = id('c');
        defs.push(`<clipPath id="${cid}">${shapeEl(l, '')}</clipPath>`);
        inner += shapeEl(l, ` fill="none" stroke="${paint(l.stroke, l.w, l.h)}" stroke-width="${n(l.strokeW * 2)}" clip-path="url(#${cid})"`);
      }
    } else if (l.type === 'path') {
      inner = `<path d="${pathD(l)}" fill="${l.fill && l.closed ? paint(l.fill, l.w, l.h) : 'none'}"${l.extra ? ' fill-rule="evenodd"' : ''}${l.stroke && l.strokeW > 0 ? ` stroke="${paint(l.stroke, l.w, l.h)}" stroke-width="${n(l.strokeW)}" stroke-linecap="round" stroke-linejoin="round"` : ''}/>`;
    } else if (l.type === 'text') inner = textEl(l);
    return `<g transform="${tf(l)}"${op(l)}>${inner}</g>`;
  };
  // livelli con maschera di ritaglio sopra, o gruppi con fusione: una sola immagine (si vede uguale)
  const rasterList = (list) => {
    const c = mk(doc.w * scale, doc.h * scale);
    renderLayers(c.getContext('2d'), list, { k: scale, ox: 0, oy: 0 }, assets, { store: new Map(), clip: [0, 0, c.width, c.height] });
    return `<image x="0" y="0" width="${doc.w}" height="${doc.h}" preserveAspectRatio="none" href="${png(c)}"/>`;
  };
  let flattened = false;
  const emit = (list) => {
    const out = [];
    for (let i = 0; i < list.length; i++) {
      const l = list[i];
      if (!l.visible) { while (list[i + 1] && list[i + 1].clip) i++; continue; }
      if (list[i + 1] && list[i + 1].clip) { let j = i + 1; while (list[j] && list[j].clip) j++; out.push(rasterList(list.slice(i, j).map((x, q) => (q ? x : { ...x, clip: false })))); i = j - 1; continue; }
      if (l.type === 'group') {
        if ((!l.blend || l.blend === 'normal')) out.push(`<g${op(l)}>${emit(l.children || [])}</g>`);
        else out.push(`<g style="mix-blend-mode:${l.blend}"${l.opacity < 1 ? ` opacity="${n(l.opacity)}"` : ''}>${rasterList(l.children || [])}</g>`);
        continue;
      }
      if (l.type === 'adjust') { flattened = true; continue; }
      out.push(vectorOk(l) ? vector(l) : raster(l));
    }
    return out.join('');
  };
  const hasAdjust = (list) => list.some((l) => l.visible && (l.type === 'adjust' || (l.type === 'group' && hasAdjust(l.children || []))));
  if (page.bg) body.push(`<rect width="${doc.w}" height="${doc.h}" fill="${paint(page.bg, doc.w, doc.h)}"/>`);
  if (hasAdjust(page.layers || [])) {
    // le regolazioni cambiano i colori di quello che c'e' sotto: si esporta l'immagine finale
    flattened = true;
    body.push(rasterList(page.layers || []));
  } else body.push(emit(page.layers || []));
  const fam = [...fonts].filter((f) => !/^(Arial|Helvetica|Georgia|Times New Roman|Courier New|Verdana)$/i.test(f));
  const style = fam.length ? `<style>@import url('https://fonts.googleapis.com/css2?${fam.map((f) => 'family=' + encodeURIComponent(f).replace(/%20/g, '+')).join('&amp;')}&amp;display=swap');</style>` : '';
  const svg = `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="${doc.w}" height="${doc.h}" viewBox="0 0 ${doc.w} ${doc.h}">${style}<defs>${defs.join('')}</defs>${body.join('')}</svg>`;
  void textRuns;
  return { svg, flattened };
}
