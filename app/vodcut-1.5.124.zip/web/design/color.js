// Grafica: scelta del colore (tinta unita o sfumatura), con quadrato HSV, esadecimale, contagocce e colori recenti.
import { h, icon } from '../lib.js';

// replaceChildren senza i null (altrimenti diventano il testo "null")
const rc = (el, ...kids) => el.replaceChildren(...kids.flat().filter((x) => x != null && x !== false));

const PALETTE = ['#FFFFFF', '#000000', '#111827', '#6B7280', '#E5E7EB', '#EF4444', '#F97316', '#FACC15', '#22C55E', '#14B8A6',
  '#2F8BFF', '#6366F1', '#A855F7', '#EC4899', '#F5E6D3', '#8B5E3C'];
const GRADS = [['#FF5F6D', '#FFC371'], ['#2F8BFF', '#A855F7'], ['#00C6FF', '#0072FF'], ['#F857A6', '#FF5858'], ['#11998E', '#38EF7D'], ['#FDC830', '#F37335'], ['#141E30', '#243B55'], ['#000000', '#434343']];
let brand = [];
export function setBrandColors(list) { brand = (list || []).slice(0, 16); }
let recent = (() => { try { return JSON.parse(localStorage.getItem('nf.dz.recent') || '[]'); } catch (e) { return []; } })();
function remember(c) {
  if (typeof c !== 'string') return;
  recent = [c.toUpperCase(), ...recent.filter((x) => x !== c.toUpperCase())].slice(0, 10);
  try { localStorage.setItem('nf.dz.recent', JSON.stringify(recent)); } catch (e) { /* */ }
}

export function cssOf(v) {
  if (!v) return 'transparent';
  if (typeof v === 'string') return v;
  const st = (v.stops || []).map(([o, c]) => `${c} ${Math.round(o * 100)}%`).join(', ');
  return v.type === 'radial' ? `radial-gradient(circle, ${st})` : `linear-gradient(${v.angle || 0}deg, ${st})`;
}
const hex = (c) => '#' + c.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('').toUpperCase();
function toRgb(s) {
  let x = String(s || '#000').replace('#', '');
  if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  const n = parseInt(x.slice(0, 6), 16);
  return isFinite(n) ? [(n >> 16) & 255, (n >> 8) & 255, n & 255] : [0, 0, 0];
}
function rgb2hsv([r, g, b]) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let hh = 0;
  if (d) hh = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [(hh * 60 + 360) % 360, mx ? d / mx : 0, mx];
}
function hsv2rgb(hh, s, v) {
  const f = (n) => { const k = (n + hh / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
  return [f(5) * 255, f(3) * 255, f(1) * 255];
}

// pulsante con l'anteprima del colore; al clic si apre la finestrella
export function colorButton(value, onChange, opt = {}) {
  let cur = value;
  const sw = h('span', { class: 'dz-swatch' + (cur ? '' : ' none') });
  const lab = opt.label ? h('span', { class: 'dz-cblab' }, opt.label) : null;
  const paint = () => { sw.style.background = cur ? cssOf(cur) : ''; sw.classList.toggle('none', !cur); };
  paint();
  const b = h('button', { class: 'dz-cbtn' + (opt.cls ? ' ' + opt.cls : ''), type: 'button', 'aria-label': opt.tip || 'Colore', 'data-tip': opt.tip || null }, sw, lab);
  b.addEventListener('click', (e) => { e.stopPropagation(); openPicker(b, cur, (v) => { cur = v; paint(); if (lab) lab.remove(); onChange(v); }, opt); });
  return b;
}

export function openPicker(anchor, value, onChange, opt = {}) {
  document.querySelectorAll('.dz-cpop').forEach((x) => x.remove());
  let mode = value && typeof value === 'object' ? 'grad' : 'solid';
  let grad = value && typeof value === 'object' ? JSON.parse(JSON.stringify(value)) : { type: 'linear', angle: 135, stops: [[0, typeof value === 'string' ? value : '#2F8BFF'], [1, '#A855F7']] };
  let stopI = 0;
  let solid = typeof value === 'string' && value ? value : '#2F8BFF';
  let hsv = rgb2hsv(toRgb(mode === 'grad' ? grad.stops[0][1] : solid));
  const pop = h('div', { class: 'dz-cpop', role: 'dialog', 'aria-label': 'Colore' });
  const sv = h('canvas', { class: 'dz-sv', width: 232, height: 150 });
  const hue = h('input', { type: 'range', class: 'dz-hue', min: 0, max: 360, step: 1 });
  const hx = h('input', { class: 'dz-hex', maxlength: 7, spellcheck: 'false', 'aria-label': 'Esadecimale' });
  const prev = h('span', { class: 'dz-cprev' });
  const curHex = () => hex(hsv2rgb(...hsv));
  function emit() {
    const c = curHex();
    if (mode === 'solid') { solid = c; onChange(c); } else { grad.stops[stopI][1] = c; onChange(JSON.parse(JSON.stringify(grad))); }
  }
  function drawSV() {
    const g = sv.getContext('2d'), w = sv.width, hh = sv.height;
    g.fillStyle = hex(hsv2rgb(hsv[0], 1, 1)); g.fillRect(0, 0, w, hh);
    const wg = g.createLinearGradient(0, 0, w, 0); wg.addColorStop(0, '#fff'); wg.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = wg; g.fillRect(0, 0, w, hh);
    const bg = g.createLinearGradient(0, 0, 0, hh); bg.addColorStop(0, 'rgba(0,0,0,0)'); bg.addColorStop(1, '#000'); g.fillStyle = bg; g.fillRect(0, 0, w, hh);
    const x = hsv[1] * w, y = (1 - hsv[2]) * hh;
    g.beginPath(); g.arc(x, y, 7, 0, Math.PI * 2); g.strokeStyle = '#fff'; g.lineWidth = 2.5; g.stroke();
    g.beginPath(); g.arc(x, y, 8.5, 0, Math.PI * 2); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 1; g.stroke();
    hue.value = hsv[0]; hx.value = curHex(); prev.style.background = curHex();
  }
  const pickSV = (e) => {
    const r = sv.getBoundingClientRect();
    hsv[1] = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); hsv[2] = Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height));
    drawSV(); emit(); paintGrad();
  };
  sv.addEventListener('pointerdown', (e) => { sv.setPointerCapture(e.pointerId); pickSV(e); const mv = (ev) => pickSV(ev); const up = () => { sv.removeEventListener('pointermove', mv); sv.removeEventListener('pointerup', up); remember(curHex()); }; sv.addEventListener('pointermove', mv); sv.addEventListener('pointerup', up); });
  hue.addEventListener('input', () => { hsv[0] = +hue.value; drawSV(); emit(); paintGrad(); });
  hx.addEventListener('keydown', (e) => e.stopPropagation());
  hx.addEventListener('change', () => { const v = hx.value.trim(); if (/^#?[0-9a-f]{3}([0-9a-f]{3})?$/i.test(v)) { hsv = rgb2hsv(toRgb(v)); drawSV(); emit(); remember(curHex()); paintGrad(); } else hx.value = curHex(); });
  const setHex = (c) => { hsv = rgb2hsv(toRgb(c)); drawSV(); emit(); remember(c); paintGrad(); };
  const dropper = 'EyeDropper' in window ? h('button', { class: 'dz-ib', 'aria-label': 'Contagocce', 'data-tip': 'Prendi un colore dallo schermo', onclick: async () => { try { const r = await new window.EyeDropper().open(); setHex(r.sRGBHex); } catch (e) { /* annullato */ } } }, icon('pipette', 15)) : null;
  const sws = (list) => h('div', { class: 'dz-sws' }, ...list.map((c) => h('button', { class: 'dz-sw', style: { background: c }, 'aria-label': c, 'data-notr': '', onclick: () => setHex(c) })));
  // sfumatura
  const gradBox = h('div', { class: 'dz-grad' });
  function paintGrad() {
    if (mode !== 'grad') { rc(gradBox); return; }
    const bar = h('div', { class: 'dz-gbar', style: { background: `linear-gradient(90deg, ${grad.stops.map(([o, c]) => `${c} ${o * 100}%`).join(',')})` } },
      ...grad.stops.map(([o, c], i) => h('button', { class: 'dz-gstop' + (i === stopI ? ' on' : ''), style: { left: o * 100 + '%', background: c }, 'aria-label': 'Colore ' + (i + 1), onclick: () => { stopI = i; hsv = rgb2hsv(toRgb(c)); drawSV(); paintGrad(); } })));
    const ang = h('input', { type: 'range', min: 0, max: 360, step: 1, value: grad.angle || 0 });
    ang.addEventListener('input', () => { grad.angle = +ang.value; angV.textContent = grad.angle + '°'; onChange(JSON.parse(JSON.stringify(grad))); paintGrad2(); });
    const angV = h('b', null, (grad.angle || 0) + '°');
    rc(gradBox, bar,
      h('div', { class: 'dz-grow' }, h('button', { class: 'dz-ochip txt' + (grad.type !== 'radial' ? ' on' : ''), onclick: () => { grad.type = 'linear'; onChange(JSON.parse(JSON.stringify(grad))); paintGrad(); } }, 'Lineare'),
        h('button', { class: 'dz-ochip txt' + (grad.type === 'radial' ? ' on' : ''), onclick: () => { grad.type = 'radial'; onChange(JSON.parse(JSON.stringify(grad))); paintGrad(); } }, 'Radiale'),
        h('button', { class: 'dz-ib', 'aria-label': 'Inverti', 'data-tip': 'Inverti i colori', onclick: () => { grad.stops = grad.stops.map(([o, c]) => [1 - o, c]).reverse(); stopI = grad.stops.length - 1 - stopI; onChange(JSON.parse(JSON.stringify(grad))); paintGrad(); } }, icon('swap', 14))),
      grad.type !== 'radial' ? h('div', { class: 'dz-slider' }, h('span', null, 'Angolo'), ang, angV) : null,
      h('div', { class: 'dz-sws' }, ...GRADS.map(([a, b]) => h('button', { class: 'dz-sw', style: { background: `linear-gradient(135deg, ${a}, ${b})` }, onclick: () => { grad.stops = [[0, a], [1, b]]; stopI = 0; hsv = rgb2hsv(toRgb(a)); drawSV(); onChange(JSON.parse(JSON.stringify(grad))); paintGrad(); } }))));
  }
  const paintGrad2 = () => { const bar = gradBox.querySelector('.dz-gbar'); if (bar) bar.style.background = `linear-gradient(90deg, ${grad.stops.map(([o, c]) => `${c} ${o * 100}%`).join(',')})`; };
  const tabs = opt.gradient || opt.none ? h('div', { class: 'dz-ctabs' },
    h('button', { class: mode === 'solid' ? 'on' : '', onclick: () => { mode = 'solid'; hsv = rgb2hsv(toRgb(solid)); onChange(solid); repaint(); } }, 'Tinta unita'),
    opt.gradient ? h('button', { class: mode === 'grad' ? 'on' : '', onclick: () => { mode = 'grad'; stopI = 0; hsv = rgb2hsv(toRgb(grad.stops[0][1])); onChange(JSON.parse(JSON.stringify(grad))); repaint(); } }, 'Sfumatura') : null,
    opt.none ? h('button', { onclick: () => { onChange(''); close(); } }, 'Nessuno') : null) : null;
  function repaint() {
    if (tabs) [...tabs.children].forEach((b, i) => b.classList.toggle('on', (i === 0 && mode === 'solid') || (i === 1 && mode === 'grad' && opt.gradient)));
    drawSV(); paintGrad();
  }
  pop.append(tabs || '', sv, h('div', { class: 'dz-crow' }, prev, hue, dropper || ''), h('div', { class: 'dz-crow' }, h('span', { class: 'dz-hlab' }, 'HEX'), hx), gradBox,
    brand.length ? h('div', { class: 'dz-clab' }, 'Brand') : '', brand.length ? sws(brand) : '',
    h('div', { class: 'dz-clab' }, 'Colori'), sws(PALETTE), recent.length ? h('div', { class: 'dz-clab' }, 'Recenti') : '', recent.length ? sws(recent) : '');
  document.body.append(pop);
  const r = anchor.getBoundingClientRect();
  const pr = pop.getBoundingClientRect();
  pop.style.left = Math.max(8, Math.min(window.innerWidth - pr.width - 8, r.right - pr.width)) + 'px';
  pop.style.top = (r.bottom + pr.height + 8 > window.innerHeight ? Math.max(8, r.top - pr.height - 8) : r.bottom + 8) + 'px';
  repaint();
  const close = () => { pop.remove(); document.removeEventListener('pointerdown', off, true); document.removeEventListener('keydown', esc, true); if (mode === 'solid') remember(solid); };
  const off = (e) => { if (!pop.contains(e.target) && e.target !== anchor && !anchor.contains(e.target)) close(); };
  const esc = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  setTimeout(() => { document.addEventListener('pointerdown', off, true); document.addEventListener('keydown', esc, true); }, 0);
}
