"""Aggiornamenti automatici (come CapCut): l'app controlla da sola se c'e' una versione nuova, la scarica in
background, controlla che sia integra e firmata da VODcut, e la usa al prossimo avvio (o subito con "Riavvia").

Come e' fatto:
- L'installer mette Python, librerie, ffmpeg e una copia del codice (la "base") nella cartella del programma.
- Gli aggiornamenti contengono solo il codice dell'app (pochi MB, uguale per Windows e Mac) e finiscono in una
  cartella dell'utente (sempre scrivibile, anche sul Mac dove l'app e' firmata e non si tocca).
- All'avvio la base guarda se c'e' un aggiornamento pronto piu' nuovo e, se si', avvia quello (boot()).
  Se la versione nuova si chiude con un errore appena partita, si torna da soli alla versione di prima e quella
  nuova viene scartata (niente app che non si apre piu').
- Se un aggiornamento ha bisogno di un Python/librerie/ffmpeg piu' nuovi (RUNTIME piu' alto), non si applica da
  solo: l'app mostra "Scarica la nuova versione" con il link all'installer completo.

Questo file deve restare leggero (niente numpy/cv2): lo usa anche il lanciatore prima di caricare il resto.
"""
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile

from . import ed25519
from .version import RUNTIME, VERSION

# chiave pubblica: solo chi ha la chiave privata (Emanuele) puo' pubblicare aggiornamenti che l'app accetta
PUBLIC_KEY = base64.b64decode("hFEFBzeZbnxZxK+0wyiZnjmQl+AEqbXIobvA7baCa9s=")
DEFAULT_URL = "https://raw.githubusercontent.com/saurroemanuele/vodcut-aggiornamenti/main/{channel}/latest.json"
CHECK_EVERY = 30 * 60   # ogni mezz'ora (il file e' piccolo): gli aggiornamenti arrivano quasi subito
PLATFORM = "win" if sys.platform == "win32" else "mac" if sys.platform == "darwin" else "linux"


# ------------------------------------------------------------------ cartelle e stato
def data_dir():
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    elif sys.platform == "darwin":
        base = os.path.join(os.path.expanduser("~"), "Library", "Application Support")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "VODcut", "aggiornamenti")


def versions_dir():
    return os.path.join(data_dir(), "versioni")


def _state_path():
    return os.path.join(data_dir(), "stato.json")


def load_state():
    try:
        with open(_state_path(), encoding="utf-8") as f:
            s = json.load(f)
            return s if isinstance(s, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(s):
    try:
        os.makedirs(data_dir(), exist_ok=True)
        tmp = _state_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(s, f, indent=1)
        os.replace(tmp, _state_path())
    except OSError:
        pass


def vtuple(v):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4])
    except ValueError:
        return (0,)


def read_version(root):
    """(VERSION, RUNTIME) del codice in root, senza importarlo."""
    try:
        with open(os.path.join(root, "engine", "version.py"), encoding="utf-8") as f:
            t = f.read()
        v = re.search(r'VERSION\s*=\s*"([^"]+)"', t).group(1)
        r = int(re.search(r"RUNTIME\s*=\s*(\d+)", t).group(1))
        return v, r
    except (OSError, AttributeError, ValueError):
        return "0", 0


def base_root():
    """La cartella del codice messo dall'installer."""
    return os.environ.get("VODCUT_BASE") or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def base_runtime():
    try:
        return int(os.environ.get("VODCUT_RUNTIME") or 0) or read_version(base_root())[1] or RUNTIME
    except ValueError:
        return RUNTIME


def installed():
    """Aggiornamenti scaricati e completi: [(versione, cartella, info)]."""
    out = []
    vd = versions_dir()
    if not os.path.isdir(vd):
        return out
    for name in os.listdir(vd):
        root = os.path.join(vd, name)
        info_p = os.path.join(root, "vodcut-versione.json")
        if not os.path.isfile(info_p) or not os.path.isfile(os.path.join(root, "server.py")):
            continue
        try:
            with open(info_p, encoding="utf-8") as f:
                info = json.load(f)
        except (OSError, ValueError):
            continue
        out.append((info.get("version", "0"), root, info))
    out.sort(key=lambda x: vtuple(x[0]), reverse=True)
    return out


def pick(base):
    """La cartella da avviare: l'aggiornamento piu' nuovo che va bene, o None (si usa la base)."""
    bver, brt = read_version(base)
    st = load_state()
    bad = set(st.get("bad") or [])
    boot = st.get("boot") or {}
    for ver, root, info in installed():
        if vtuple(ver) <= vtuple(bver):
            break
        if ver in bad or int(info.get("runtime", 1)) > brt:
            continue
        # partita due volte senza mai arrivare a mostrare l'app: la scartiamo. Ma se su questo PC si e' gia' aperta
        # almeno una volta non si torna indietro (chiudere l'app mentre si apre, o aprirla due volte, non e' un guasto)
        good = set(st.get("good") or [])
        if boot.get("ver") == ver and not boot.get("ok") and boot.get("tries", 0) >= 2 and ver not in good:
            st.setdefault("bad", []).append(ver)
            save_state(st)
            print(f"[agg] la versione {ver} non si apre: torno alla {bver}", flush=True)
            continue
        return ver, root
    return None


def _restart_mark():
    return os.path.join(data_dir(), "riavvio.txt")


def _wait_old_server():
    """Dopo "Riavvia": aspetta che la vecchia finestra/server si sia chiusa (cosi' la porta e' libera)."""
    port = os.environ.pop("VODCUT_RESTART_PORT", None)
    if not port:    # Mac: il riavvio passa da "open", che non porta le variabili: la porta sta in un file
        try:
            mk = _restart_mark()
            if time.time() - os.path.getmtime(mk) < 30:
                port = open(mk, encoding="utf-8").read().strip()
            os.remove(mk)
        except (OSError, ValueError):
            pass
    if not port:
        return
    import urllib.request
    end = time.time() + 10
    while time.time() < end:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=0.5).read()
        except Exception:
            return
        time.sleep(0.25)


def boot(base):
    """Chiamata all'avvio dalla base. Se c'e' un aggiornamento pronto lo avvia e termina questo processo.
    Se l'aggiornamento cade subito, lo scarta e prova quello prima (alla fine la base: si continua qui)."""
    _wait_old_server()
    for _ in range(5):
        got = pick(base)
        if not got:
            return
        _run(base, *got)


def _run(base, ver, root):
    st = load_state()
    b = st.get("boot") or {}
    tries = (b.get("tries", 0) + 1) if (b.get("ver") == ver and not b.get("ok")) else 1
    st["boot"] = {"ver": ver, "ok": False, "tries": tries, "t": time.time()}
    save_state(st)
    env = dict(os.environ, VODCUT_BOOTED="1", VODCUT_BASE=base, VODCUT_RUNTIME=str(read_version(base)[1]))
    print(f"[agg] avvio la versione {ver}", flush=True)
    if sys.platform == "darwin":
        # Mac: stesso processo (cosi' resta l'app VODcut nel Dock). Se la versione nuova non arriva mai ad aprirsi,
        # dopo due tentativi pick() la scarta e si riparte dalla precedente.
        try:
            os.chdir(root)
            os.execve(sys.executable, [sys.executable, os.path.join(root, "server.py"), *sys.argv[1:]], env)
        except OSError as e:
            print(f"[agg] non parte ({e})", flush=True)
            _mark_bad(ver)
            return
    try:
        p = subprocess.Popen([sys.executable, os.path.join(root, "server.py"), *sys.argv[1:]], env=env, cwd=root)
    except OSError as e:
        print(f"[agg] non parte ({e})", flush=True)
        _mark_bad(ver)
        return
    end = time.time() + 40
    while time.time() < end:
        rc = p.poll()
        if rc is not None:
            if rc == 0 or (load_state().get("boot") or {}).get("ok"):
                sys.exit(rc)     # es. l'app era gia' aperta: ha solo aperto un'altra finestra
            _mark_bad(ver)
            print(f"[agg] la versione {ver} si e' chiusa con errore {rc}: la scarto", flush=True)
            return
        if (load_state().get("boot") or {}).get("ok"):
            sys.exit(0)          # la versione nuova gira: il lanciatore ha finito
        time.sleep(0.3)
    sys.exit(0)


def _mark_bad(ver):
    st = load_state()
    if ver in (st.get("good") or []):
        print(f"[agg] la versione {ver} si e' chiusa, ma qui ha gia' funzionato: la tengo", flush=True)
        return
    if ver not in (st.get("bad") or []):
        st.setdefault("bad", []).append(ver)
    st["boot"] = {"ver": ver, "ok": False, "tries": 99}
    save_state(st)


# ------------------------------------------------------------------ l'app in esecuzione
_OK_DONE = [False]
STATUS = {"state": "idle", "current": VERSION}
_LOCK = threading.Lock()
_SETTINGS = {"get": lambda: {}}


def _changelog_path():
    return os.path.join(data_dir(), "novita.json")


def _save_changelog(hist):
    """Tiene sul PC l'elenco delle novita' di tutte le versioni (serve al riepilogo dopo l'aggiornamento)."""
    if not isinstance(hist, list) or not hist:
        return
    try:
        os.makedirs(data_dir(), exist_ok=True)
        with open(_changelog_path(), "w", encoding="utf-8") as f:
            json.dump(hist[:60], f, ensure_ascii=False)
    except OSError:
        pass


def changes_between(old, new, hist=None):
    """Le novita' delle versioni dopo `old` fino a `new` compresa, dalla piu' nuova: [{version, date, items}]."""
    if hist is None:
        try:
            with open(_changelog_path(), encoding="utf-8") as f:
                hist = json.load(f)
        except (OSError, ValueError):
            hist = []
    out = []
    for e in hist or []:
        v = str(e.get("version") or "")
        if vtuple(old) < vtuple(v) <= vtuple(new):
            items = [{"type": str(i.get("type") or "impr"), "text": str(i.get("text") or "")[:300]}
                     for i in (e.get("items") or []) if isinstance(i, dict) and i.get("text")]
            out.append({"version": v, "date": str(e.get("date") or ""), "items": items[:40]})
    out.sort(key=lambda e: vtuple(e["version"]), reverse=True)
    return out[:30]


def mark_ok():
    """La finestra ha caricato l'app: questa versione funziona."""
    if _OK_DONE[0]:
        return
    _OK_DONE[0] = True
    st = load_state()
    if os.environ.get("VODCUT_BOOTED"):
        b = st.get("boot") or {}
        if b.get("ver") == VERSION:
            b.update(ok=True, tries=0)
            st["boot"] = b
    good = [v for v in (st.get("good") or []) if v != VERSION] + [VERSION]
    st["good"] = good[-10:]
    seen = st.get("seen")
    if seen and vtuple(seen) < vtuple(VERSION):
        notes = ""
        for ver, _root, info in installed():
            if ver == VERSION:
                notes = info.get("notes", "")
        STATUS["justUpdated"] = {"version": VERSION, "notes": notes, "from": seen, "history": changes_between(seen, VERSION)}
    st["seen"] = VERSION
    save_state(st)


def _ssl_ctx():
    import ssl
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _open(url, timeout=20):
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": f"NoonFrame/{VERSION} ({PLATFORM})", "Cache-Control": "no-cache"})
    if url.startswith("file:"):
        return urllib.request.urlopen(req, timeout=timeout)
    return urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx())


def manifest_url(settings):
    url = os.environ.get("VODCUT_UPDATE_URL") or DEFAULT_URL
    ch = settings.get("updateChannel") if settings.get("updateChannel") in ("stable", "beta") else "stable"
    return url.replace("{channel}", re.sub(r"[^a-z0-9-]", "", ch) or "stable")


def signed_message(version, runtime, sha):
    return f"vodcut\n{version}\n{int(runtime)}\n{sha}".encode()


def _set(**kw):
    with _LOCK:
        STATUS.update(kw)


def status():
    with _LOCK:
        return dict(STATUS)


def _download(url, dest, size, sha_expected):
    h = hashlib.sha256()
    got = 0
    with _open(url, timeout=60) as r, open(dest, "wb") as f:
        while True:
            buf = r.read(1 << 16)
            if not buf:
                break
            f.write(buf)
            h.update(buf)
            got += len(buf)
            if size:
                _set(progress=min(0.99, got / size))
    if h.hexdigest() != sha_expected:
        raise ValueError("il file scaricato e' rovinato (controllo non superato)")


def _extract(zpath, dest):
    with zipfile.ZipFile(zpath) as z:
        for n in z.namelist():
            if n.startswith(("/", "\\")) or ".." in n.replace("\\", "/").split("/") or ":" in n:
                raise ValueError("pacchetto non valido")
        z.extractall(dest)


def check(force=False):
    """Controlla e, se c'e', scarica e prepara l'aggiornamento. Ritorna lo stato."""
    settings = _SETTINGS["get"]() or {}
    if not force and settings.get("autoUpdate") is False:
        return status()
    if STATUS.get("state") in ("checking", "downloading"):
        return status()
    _set(state="checking", error=None)
    try:
        with _open(manifest_url(settings)) as r:
            m = json.loads(r.read().decode("utf-8"))
        ver = str(m["version"])
        rt = int(m.get("runtime", 1))
        if isinstance(m.get("runtimes"), dict):
            rt = int(m["runtimes"].get(PLATFORM, rt))
        _set(checked=time.time())
        _save_changelog(m.get("history"))
        if vtuple(ver) <= vtuple(VERSION) or ver in (load_state().get("bad") or []):
            _set(state="uptodate", version=VERSION)
            return status()
        notes = m.get("notes", "")
        _set(history=changes_between(VERSION, ver, m.get("history")))
        if rt > base_runtime():
            inst = (m.get("installer") or {}).get(PLATFORM) or m.get("page") or ""
            # il link "Scarica" non e' firmato: si accetta solo verso i download ufficiali di NoonFrame
            if not re.match(r"^https://(github\.com/saurroemanuele/vodcut-aggiornamenti/releases/|(www\.)?noonframe\.com/)", str(inst)):
                inst = ""
            _set(state="installer", version=ver, notes=notes, installer=inst)
            return status()
        # gia' scaricato?
        for iv, _root, _info in installed():
            if iv == ver:
                _set(state="ready", version=ver, notes=notes)
                return status()
        sha = str(m["sha256"]).lower()
        if not ed25519.verify(PUBLIC_KEY, signed_message(ver, rt, sha), base64.b64decode(m["sig"])):
            raise ValueError("firma dell'aggiornamento non valida: ignorato")
        _set(state="downloading", version=ver, notes=notes, progress=0.0)
        tmpd = os.path.join(data_dir(), "tmp")
        shutil.rmtree(tmpd, ignore_errors=True)
        os.makedirs(tmpd, exist_ok=True)
        zpath = os.path.join(tmpd, "pacchetto.zip")
        url = m["url"]
        if not re.match(r"^(https|file):", url):
            url = manifest_url(settings).rsplit("/", 1)[0] + "/" + url.lstrip("/")
        _download(url, zpath, int(m.get("size") or 0), sha)
        work = os.path.join(tmpd, "codice")
        _extract(zpath, work)
        if read_version(work)[0] != ver or not os.path.isfile(os.path.join(work, "server.py")):
            raise ValueError("il pacchetto non contiene la versione annunciata")
        with open(os.path.join(work, "vodcut-versione.json"), "w", encoding="utf-8") as f:
            json.dump({"version": ver, "runtime": rt, "notes": notes, "sha256": sha, "t": time.time()}, f)
        os.makedirs(versions_dir(), exist_ok=True)
        final = os.path.join(versions_dir(), ver)
        shutil.rmtree(final, ignore_errors=True)
        os.replace(work, final)
        shutil.rmtree(tmpd, ignore_errors=True)
        print(f"[agg] versione {ver} scaricata e pronta", flush=True)
        _set(state="ready", version=ver, notes=notes, progress=1.0)
    except Exception as e:
        print(f"[agg] controllo aggiornamenti: {e}", flush=True)
        _set(state="error", error=str(e)[:200])
    cleanup()
    return status()


def cleanup():
    """Toglie le versioni che non servono piu': tiene quella in uso e la piu' nuova pronta."""
    try:
        floor = max(vtuple(VERSION), vtuple(read_version(base_root())[0]))
        bad = set(load_state().get("bad") or [])
        inst = [x for x in installed() if x[0] not in bad]
        newest = inst[0][0] if inst and vtuple(inst[0][0]) > floor else None
        vd = versions_dir()
        for name in os.listdir(vd) if os.path.isdir(vd) else []:
            if name in (VERSION, newest):
                continue
            shutil.rmtree(os.path.join(vd, name), ignore_errors=True)
    except OSError:
        pass


def start_background(get_settings, delay=8):
    _SETTINGS["get"] = get_settings

    def loop():
        time.sleep(delay)
        while True:
            try:
                check()
            except Exception as e:  # mai far cadere l'app per un controllo
                print(f"[agg] {e}", flush=True)
            time.sleep(CHECK_EVERY)
    threading.Thread(target=loop, daemon=True, name="aggiornamenti").start()


def restart(port):
    """Riapre l'app (con la versione nuova) e chiude questa."""
    base = base_root()
    env = {k: v for k, v in os.environ.items() if k not in ("VODCUT_BOOTED",)}
    env["VODCUT_RESTART_PORT"] = str(port)
    kw = {"cwd": base, "env": env, "close_fds": True}
    if sys.platform == "win32":
        kw["creationflags"] = 0x00000008 | 0x00000200   # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    else:
        kw["start_new_session"] = True
    args = [a for a in sys.argv[1:] if not a.lower().endswith(".vodcut")]
    bundle = os.environ.get("VODCUT_BUNDLE")
    if sys.platform == "darwin" and bundle and os.path.isdir(bundle):
        # Mac: si riapre l'app vera (icona e menu di VODcut), non un Python qualsiasi
        os.makedirs(data_dir(), exist_ok=True)
        with open(_restart_mark(), "w", encoding="utf-8") as f:
            f.write(str(port))
        subprocess.Popen(["open", "-n", bundle] + (["--args", *args] if args else []), **kw)
    else:
        subprocess.Popen([sys.executable, os.path.join(base, "server.py"), *args], **kw)
    threading.Thread(target=lambda: (time.sleep(0.4), os._exit(0)), daemon=True).start()
