"""Curve dei keyframe (come CapCut): da un keyframe al prossimo il valore si muove con questa curva.
Stessa matematica di web/lib.js kfEase."""
import math

KINDS = ("linear", "in", "out", "smooth", "back", "bounce", "hold")


def _bounce_out(u):
    n, d = 7.5625, 2.75
    if u < 1 / d:
        return n * u * u
    if u < 2 / d:
        u -= 1.5 / d
        return n * u * u + 0.75
    if u < 2.5 / d:
        u -= 2.25 / d
        return n * u * u + 0.9375
    u -= 2.625 / d
    return n * u * u + 0.984375


def ease(u, kind):
    u = max(0.0, min(1.0, float(u)))
    if kind == "linear":
        return u
    if kind == "in":        # parte piano e accelera
        return u * u * u
    if kind == "out":       # parte veloce e rallenta
        return 1 - (1 - u) ** 3
    if kind == "back":      # supera un po' l'arrivo e torna indietro
        c1 = 1.70158
        return 1 + (c1 + 1) * (u - 1) ** 3 + c1 * (u - 1) ** 2
    if kind == "bounce":    # rimbalza sull'arrivo
        return _bounce_out(u)
    if kind == "hold":      # resta fermo e salta al prossimo keyframe
        return 0.0 if u < 1 else 1.0
    return 4 * u ** 3 if u < 0.5 else 1 - (-2 * u + 2) ** 3 / 2   # "smooth": morbido in entrata e in uscita


# ------------------------------------------------------------------ keyframe di una proprieta' qualsiasi
# obj["pk"][prop] = [{"t": secondi dall'inizio dell'elemento, "v": valore, "ease": curva}]
def pk_list(obj, prop):
    ks = ((obj or {}).get("pk") or {}).get(prop) or []
    return sorted((k for k in ks if isinstance(k, dict) and k.get("v") is not None), key=lambda k: float(k.get("t", 0)))


def pk_at(obj, prop, tr, base):
    ks = pk_list(obj, prop)
    if not ks:
        return base
    if tr <= ks[0]["t"]:
        return float(ks[0]["v"])
    if tr >= ks[-1]["t"]:
        return float(ks[-1]["v"])
    for a, b in zip(ks, ks[1:]):
        if a["t"] <= tr < b["t"]:
            u = ease((tr - a["t"]) / max(1e-6, b["t"] - a["t"]), a.get("ease", "smooth"))
            return float(a["v"]) + (float(b["v"]) - float(a["v"])) * u
    return float(ks[-1]["v"])


def pk_samples(obj, prop, length, base, step=0.04):
    """Punti (t, valore) per seguire la curva con tratti dritti: fitti tra il primo e l'ultimo keyframe."""
    ks = pk_list(obj, prop)
    if not ks:
        return None
    t0, t1 = max(0.0, ks[0]["t"]), min(length, ks[-1]["t"])
    pts = [(0.0, pk_at(obj, prop, 0.0, base))]
    x = t0
    while x < t1:
        pts.append((x, pk_at(obj, prop, x, base)))
        x += step
    pts.append((t1, pk_at(obj, prop, t1, base)))
    if length > t1:
        pts.append((length, pk_at(obj, prop, length, base)))
    out = []
    for p in pts:
        if not out or p[0] > out[-1][0] + 1e-6:
            out.append(p)
    return out


def ramp_cmds(points, scale=1.0, shift=0.0):
    """Comandi per il filtro volume (asendcmd): tra due punti un tratto dritto in t."""
    cmds = []
    for (x0, v0), (x1, v1) in zip(points, points[1:]):
        a, b = v0 * scale, v1 * scale
        if abs(b - a) < 1e-6:
            cmds.append((x0 + shift, f"{a:.4f}"))
        else:
            cmds.append((x0 + shift, f"{a:.4f}+({(b - a) / max(1e-6, x1 - x0):.6f})*(t-{x0 + shift:.4f})"))
    if points:
        cmds.append((points[-1][0] + shift, f"{points[-1][1] * scale:.4f}"))
    return cmds


def step_cmds(obj, prop, length, base, scale=1.0, step=0.02):
    """Come ramp_cmds ma a gradini fitti di valore fisso (niente "t" nell'espressione: nelle catene delle clip il
    tempo del filtro non parte da zero e le rampe in t sbagliavano)."""
    ks = pk_list(obj, prop)
    if not ks:
        return None
    t0, t1 = max(0.0, ks[0]["t"]), min(length, ks[-1]["t"])
    cmds = [(0.0, f"{pk_at(obj, prop, 0.0, base) * scale:.4f}")]
    x = t0
    while x < t1:
        cmds.append((x, f"{pk_at(obj, prop, x + step / 2, base) * scale:.4f}"))
        x += step
    cmds.append((t1, f"{pk_at(obj, prop, t1, base) * scale:.4f}"))
    out = []
    for c in cmds:
        if out and c[1] == out[-1][1]:
            continue
        out.append(c)
    return out
