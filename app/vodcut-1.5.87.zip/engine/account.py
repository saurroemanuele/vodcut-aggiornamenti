"""Account NoonFrame (Supabase): accesso con Google o con un codice via email, dispositivi, blocco, uso delle funzioni.

Sicurezza:
- la chiave nel codice e' quella "pubblicabile" di Supabase: da sola non legge niente, le tabelle sono protette da RLS
  e l'app scrive solo tramite funzioni controllate (app_heartbeat, app_track, app_report);
- il token di accesso si rinnova da solo; quello di rinnovo e' salvato cifrato con l'account di Windows (DPAPI),
  su Mac in un file leggibile solo dall'utente;
- l'accesso con Google usa PKCE e un codice "state" monouso: nessun sito puo' completare un login al posto tuo;
- degli usi si registrano solo nomi di azioni e numeri (mai testi, nomi di file o contenuti dei video).
"""
import base64
import hashlib
import json
import os
import secrets
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .util import APP_DIR
from .version import VERSION

SUPABASE_URL = os.environ.get("NUVORA_SUPABASE_URL") or "https://jhoidpugjjvvkjccyrxg.supabase.co"
SUPABASE_KEY = "sb_publishable_vam6nGEE5qCrRCXknhoWqQ_GvrpnvzR"
# accesso obbligatorio per usare l'app (si spegne solo per le prove: NUVORA_ACCOUNT_REQUIRED=0)
REQUIRED = os.environ.get("NUVORA_ACCOUNT_REQUIRED", "1") != "0"
ENABLED = True
# metodi di accesso attivi (Apple quando ci sara' l'account sviluppatore)
PROVIDERS = ["google"]

PATH = os.path.join(APP_DIR, "account.json")
PLATFORM = "windows" if sys.platform == "win32" else "mac" if sys.platform == "darwin" else "linux"
_LOCK = threading.RLock()
_PENDING = {}          # state -> {verifier, until}
_EVENTS = []           # eventi in coda, mandati a pacchetti
_STATE = {"online": None, "error": ""}


# ------------------------------------------------------------------ salvataggio (token di rinnovo protetto)
def _dpapi(data, protect):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    buf = ctypes.create_string_buffer(data, len(data))
    inp = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
    out = BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(inp), None, None, None, None, 0x1, ctypes.byref(out)):   # 0x1 = nessuna finestra
        raise OSError("DPAPI non disponibile")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def _seal(s):
    if not s:
        return ""
    if PLATFORM == "windows":
        try:
            return "dpapi:" + base64.b64encode(_dpapi(s.encode(), True)).decode()
        except Exception:
            pass
    return "plain:" + s


def _unseal(s):
    if not s:
        return ""
    kind, _, v = s.partition(":")
    if kind == "dpapi":
        try:
            return _dpapi(base64.b64decode(v), False).decode()
        except Exception:
            return ""
    return v if kind == "plain" else ""


def _load():
    try:
        with open(PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save(d):
    os.makedirs(APP_DIR, exist_ok=True)
    tmp = PATH + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, PATH)
    try:
        os.chmod(PATH, 0o600)
    except OSError:
        pass


def _device_key():
    d = _load()
    if not d.get("device_key"):
        d["device_key"] = secrets.token_hex(16)
        _save(d)
    return d["device_key"]


# ------------------------------------------------------------------ chiamate a Supabase
class AuthError(Exception):
    pass


def _ssl():
    try:
        from .updater import _ssl_ctx
        return _ssl_ctx()
    except Exception:
        return None


def _call(method, path, body=None, token=None, timeout=20):
    headers = {"apikey": SUPABASE_KEY, "Content-Type": "application/json", "User-Agent": f"NoonFrame/{VERSION} ({PLATFORM})"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(SUPABASE_URL + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
            raw = r.read()
            _STATE["online"] = True
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        _STATE["online"] = True
        try:
            j = json.loads(e.read() or b"{}")
        except Exception:
            j = {}
        msg = j.get("msg") or j.get("message") or j.get("error_description") or j.get("error") or f"errore {e.code}"
        raise AuthError(_friendly(str(msg), e.code))
    except (urllib.error.URLError, OSError, TimeoutError):
        _STATE["online"] = False
        raise AuthError("Nessuna connessione a internet")


def _friendly(msg, code):
    m = msg.lower()
    if "token has expired" in m or "otp" in m and ("invalid" in m or "expired" in m):
        return "Codice sbagliato o scaduto: controlla l'email o chiedine uno nuovo"
    if "rate limit" in m or code == 429:
        return "Troppi tentativi: aspetta un minuto e riprova"
    if "email" in m and "invalid" in m:
        return "Indirizzo email non valido"
    if "signups not allowed" in m:
        return "Le iscrizioni sono chiuse in questo momento"
    return msg


def _store_session(s, login=True):
    """Salva la sessione ricevuta da Supabase (access, refresh, utente)."""
    u = s.get("user") or {}
    meta = u.get("user_metadata") or {}
    with _LOCK:
        d = _load()
        if (d.get("user") or {}).get("id") != u.get("id"):
            d.pop("profile", None)      # un altro account: il profilo salvato non e' suo
        d.update({
            "access_token": _seal(s["access_token"]), "refresh": _seal(s["refresh_token"]),
            "expires_at": time.time() + int(s.get("expires_in") or 3600) - 60,
            "user": {"id": u.get("id"), "email": u.get("email"), "name": meta.get("full_name") or meta.get("name") or "",
                     "avatar": meta.get("avatar_url") or "", "provider": (u.get("app_metadata") or {}).get("provider") or ""},
        })
        d.pop("blocked", None)
        _save(d)
    if login:
        track("account.login", {"provider": d["user"]["provider"]})
        threading.Thread(target=lambda: (heartbeat(), profile()), daemon=True).start()


def _token():
    """Il token di accesso valido (rinnovato se serve). None se non si e' dentro o non si riesce."""
    with _LOCK:
        d = _load()
        if not d.get("refresh"):
            return None
        if d.get("access_token") and d.get("expires_at", 0) > time.time():
            at = _unseal(d["access_token"]) if ":" in d["access_token"][:7] else ""
            if at:
                return at
        rt = _unseal(d.get("refresh"))
    if not rt:
        return None
    try:
        s = _call("POST", "/auth/v1/token?grant_type=refresh_token", {"refresh_token": rt})
    except AuthError as e:
        if _STATE["online"]:    # rifiutato dal server (sessione revocata o account cancellato): si esce
            _STATE["error"] = str(e)
            logout(local_only=True)
        return None
    _store_session(s, login=False)
    return s["access_token"]


# ------------------------------------------------------------------ accesso
def start_email(email):
    email = (email or "").strip().lower()
    if "@" not in email or len(email) > 200:
        raise AuthError("Indirizzo email non valido")
    _call("POST", "/auth/v1/otp", {"email": email, "create_user": True})
    return True


def verify_email(email, code):
    code = "".join(ch for ch in str(code or "") if ch.isdigit())
    if len(code) < 6:
        raise AuthError("Il codice ha 6 cifre")
    s = _call("POST", "/auth/v1/verify", {"type": "email", "email": (email or "").strip().lower(), "token": code})
    _store_session(s)
    return status()


def oauth_start(port, provider="google"):
    """Indirizzo da aprire nel browser per entrare con Google o Apple (PKCE + state monouso)."""
    if provider not in PROVIDERS:
        raise AuthError("Metodo di accesso non disponibile")
    verifier = secrets.token_urlsafe(64)[:96]
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
    state = secrets.token_urlsafe(24)
    with _LOCK:
        for k in [k for k, v in _PENDING.items() if v["until"] < time.time()]:
            _PENDING.pop(k, None)
        _PENDING[state] = {"verifier": verifier, "until": time.time() + 600}
    redirect = f"http://127.0.0.1:{port}/auth/callback?s={state}"
    q = urllib.parse.urlencode({"provider": provider, "redirect_to": redirect, "code_challenge": challenge,
                                "code_challenge_method": "s256"})
    return f"{SUPABASE_URL}/auth/v1/authorize?{q}"


def oauth_finish(state, code):
    with _LOCK:
        p = _PENDING.pop(state or "", None)
    if not p or p["until"] < time.time():
        raise AuthError("Accesso scaduto: riprova dall'app")
    if not code:
        raise AuthError("Accesso annullato")
    s = _call("POST", "/auth/v1/token?grant_type=pkce", {"auth_code": code, "code_verifier": p["verifier"]})
    _store_session(s)
    return True


def logout(local_only=False):
    with _LOCK:
        d = _load()
        tok = _unseal(d.get("access_token") or "") if ":" in (d.get("access_token") or "")[:7] else ""
        for k in ("access_token", "refresh", "expires_at", "user", "device_id", "blocked", "blocked_reason", "profile"):
            d.pop(k, None)
        _save(d)
    if tok and not local_only:
        try:
            _call("POST", "/auth/v1/logout", {}, token=tok, timeout=8)
        except AuthError:
            pass


def delete_account():
    tok = _token()
    if not tok:
        raise AuthError("Per cancellare l'account serve essere connessi a internet")
    _call("POST", "/rest/v1/rpc/app_delete_account", {}, token=tok)
    logout(local_only=True)
    return True


# ------------------------------------------------------------------ stato, dispositivo, blocco
def status():
    d = _load()
    u = d.get("user")
    pr = d.get("profile") or {}
    return {"enabled": ENABLED, "providers": PROVIDERS, "required": REQUIRED, "signedIn": bool(u and d.get("refresh")), "user": u,
            "blocked": bool(d.get("blocked")), "reason": d.get("blocked_reason") or "", "online": _STATE["online"],
            "error": _STATE["error"], "device_id": d.get("device_id"),
            # profilo (senza la foto, che si chiede a parte): None finche' non e' mai stato letto dal server
            "profile": {"loaded": bool(pr), "username": pr.get("username"), "name": pr.get("name"), "nuvora_id": pr.get("nuvora_id"),
                        "photo": pr.get("photo_ver") or ""} if pr else None}


def can_use():
    """True se si puo' usare l'app: accesso fatto (anche senza internet, dopo la prima volta) e account non bloccato."""
    if not REQUIRED:
        return True
    d = _load()
    return bool(d.get("user") and d.get("refresh")) and not d.get("blocked")


# ------------------------------------------------------------------ profilo (ID NoonFrame, nome utente, foto)
_PHOTO_MIME = {"image/jpeg": b"\xff\xd8\xff", "image/png": b"\x89PNG", "image/webp": b"RIFF"}
USERNAME_RE = r"^[a-z0-9](?:[a-z0-9._]{1,18})[a-z0-9]$"


def _rpc(name, body, timeout=20):
    tok = _token()
    if not tok:
        raise AuthError("Accedi di nuovo per continuare" if _STATE["online"] is not False else "Nessuna connessione a internet")
    return _call("POST", "/rest/v1/rpc/" + name, body, token=tok, timeout=timeout)


def _keep_profile(p):
    """Salva il profilo sul computer (serve anche senza internet)."""
    if not isinstance(p, dict):
        return None
    av = p.get("avatar") or {}
    keep = {k: p.get(k) for k in ("nuvora_id", "username", "name", "google_name", "email", "provider", "created_at",
                                  "google_avatar", "username_next_change", "stats", "devices")}
    keep["photo"] = {"mime": av.get("mime"), "data": av.get("data")} if av.get("data") else None
    keep["photo_ver"] = str(av.get("updated_at") or "") if av.get("data") else ""
    keep["fetched"] = time.time()
    with _LOCK:
        d = _load()
        if not d.get("user"):
            return None
        d["profile"] = keep
        _save(d)
    return keep


def _profile_out(pr):
    if not pr:
        return None
    out = {k: v for k, v in pr.items() if k not in ("photo", "fetched")}
    ph = pr.get("photo")
    out["photo"] = f"data:{ph['mime']};base64,{ph['data']}" if ph and ph.get("mime") in _PHOTO_MIME else ""
    return out


def profile(refresh=True):
    """Il proprio profilo; se non c'e' internet, quello salvato."""
    if refresh:
        try:
            _keep_profile(_rpc("app_profile", {}))
        except AuthError:
            pass
    return _profile_out(_load().get("profile"))


def _profile_error(e):
    m = str(e)
    for key, txt in (("username:taken", "Questo nome utente è già preso"), ("username:reserved", "Questo nome utente non si può usare"),
                     ("username:format", "Da 3 a 20 caratteri: lettere minuscole, numeri, punto e trattino basso"),
                     ("username:wait", "Puoi cambiare il nome utente una volta ogni 7 giorni"),
                     ("name:length", "Il nome va da 1 a 40 caratteri"), ("account bloccato", "Account sospeso")):
        if key in m:
            return AuthError(txt)
    return e


def username_free(u):
    u = str(u or "").strip().lower()
    import re
    if not re.match(USERNAME_RE, u) or ".." in u or "__" in u or "._" in u or "_." in u:
        return {"ok": False, "why": "format"}
    return _rpc("app_username_free", {"p_username": u})


def set_profile(data):
    body = {}
    if "username" in data:
        body["username"] = str(data.get("username") or "").strip().lower()[:20]
    if "name" in data:
        body["name"] = str(data.get("name") or "").strip()[:40]
    try:
        p = _rpc("app_set_profile", {"p": body})
    except AuthError as e:
        raise _profile_error(e)
    return _profile_out(_keep_profile(p))


def set_photo(data_url):
    """Foto profilo: l'app la ridimensiona (256x256); qui si controlla che sia davvero un'immagine piccola."""
    if not data_url:
        mime, b64 = "image/jpeg", ""
    else:
        import re
        m = re.match(r"^data:(image/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$", str(data_url))
        if not m:
            raise AuthError("Formato dell'immagine non valido")
        mime, b64 = m.group(1), m.group(2)
        if len(b64) > 400000:
            raise AuthError("L'immagine è troppo grande")
        raw = base64.b64decode(b64)
        if not raw.startswith(_PHOTO_MIME[mime]) or (mime == "image/webp" and raw[8:12] != b"WEBP"):
            raise AuthError("Formato dell'immagine non valido")
    try:
        p = _rpc("app_set_avatar", {"p_mime": mime, "p_data": b64}, timeout=60)
    except AuthError as e:
        raise _profile_error(e)
    return _profile_out(_keep_profile(p))


def heartbeat():
    """Registra il dispositivo e l'ultimo accesso; risponde se l'account e' bloccato (il blocco resta anche offline)."""
    tok = _token()
    if not tok:
        return status()
    import platform as pf
    osn = f"{pf.system()} {pf.release()}" if PLATFORM != "mac" else f"macOS {pf.mac_ver()[0]}"
    try:
        from .util import load_settings
        lang = load_settings().get("lang") or ""
    except Exception:
        lang = ""
    gpu = None
    try:
        import shutil
        gpu = bool(shutil.which("nvidia-smi"))
    except Exception:
        pass
    try:
        r = _call("POST", "/rest/v1/rpc/app_heartbeat", {"p_device_key": _device_key(), "p_platform": PLATFORM, "p_os": osn,
                  "p_machine": pf.machine(), "p_app_version": VERSION, "p_gpu": gpu, "p_lang": lang}, token=tok)
    except AuthError:
        return status()
    with _LOCK:
        d = _load()
        d["device_id"] = r.get("device_id")
        d["blocked"] = bool(r.get("blocked"))
        d["blocked_reason"] = r.get("reason") or ""
        d["last_ok"] = time.time()
        _save(d)
    return status()


# ------------------------------------------------------------------ uso delle funzioni
def track(name, props=None):
    """Registra un'azione (es. "export.done"). Solo numeri e parole brevi nelle proprieta'."""
    if not ENABLED:
        return
    clean = {}
    for k, v in (props or {}).items():
        if isinstance(v, bool) or isinstance(v, (int, float)):
            clean[str(k)[:30]] = v
        elif isinstance(v, str) and len(v) <= 40:
            clean[str(k)[:30]] = v
    with _LOCK:
        _EVENTS.append({"name": name[:40], "props": clean, "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
        del _EVENTS[:-2000]


def flush():
    with _LOCK:
        batch = _EVENTS[:200]
    if not batch:
        return 0
    tok = _token()
    if not tok:
        return 0
    try:
        _call("POST", "/rest/v1/rpc/app_track", {"p_device_id": _load().get("device_id"), "p_events": batch}, token=tok)
    except AuthError:
        return 0
    with _LOCK:
        del _EVENTS[:len(batch)]
    return len(batch)


# ------------------------------------------------------------------ segnalazioni
def send_report(rep):
    """Manda una segnalazione (dict di feedback.build) collegata all'account. True se arrivata."""
    tok = _token()
    if not tok:
        return False
    imgs = [{"mime": "image/png" if i.get("type") == "png" else "image/jpeg", "data": i.get("b64", "")} for i in (rep.get("images") or [])]
    p = {k: rep.get(k) for k in ("id", "kind", "text", "contact", "screen", "system", "errors", "log", "project")}
    p["device_id"] = _load().get("device_id")
    try:
        _call("POST", "/rest/v1/rpc/app_report", {"p": p, "p_images": imgs}, token=tok, timeout=120)
        return True
    except AuthError as e:
        print(f"[account] segnalazione non inviata: {e}", flush=True)
        return False


def start_background():
    if not ENABLED:
        return

    def loop():
        time.sleep(3)
        n = 0
        while True:
            try:
                if n % 6 == 0:          # ogni 30 minuti
                    heartbeat()
                    if n == 0 and _load().get("user"):
                        profile()
                flush()
            except Exception as e:
                print(f"[account] {e}", flush=True)
            n += 1
            time.sleep(300)
    track("app.start", {"platform": PLATFORM, "version": VERSION})
    threading.Thread(target=loop, daemon=True, name="account").start()


# ------------------------------------------------------------------ stili condivisi con la community (li approva l'admin)
_SHARED = {"at": 0, "list": []}


def share_style(name, niche, kind, style):
    r = _rpc("app_share_style", {"p_name": name, "p_niche": niche or "", "p_kind": kind, "p_style": style})
    _SHARED["at"] = 0
    return r


def shared_styles(max_age=120):
    """Gli stili approvati per tutti (+ i propri, anche in attesa). Dalla cache se recenti; senza rete: lista vuota."""
    import time as _t
    if _t.time() - _SHARED["at"] < max_age:
        return _SHARED["list"]
    try:
        r = _rpc("app_shared_styles", {}, timeout=8)
        _SHARED.update(at=_t.time(), list=r if isinstance(r, list) else [])
    except Exception:
        _SHARED["at"] = _t.time() - max_age + 20   # riprova tra poco
    return _SHARED["list"]
