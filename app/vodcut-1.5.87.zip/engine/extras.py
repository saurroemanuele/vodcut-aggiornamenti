"""Librerie extra scaricate solo quando servono (con impronta SHA-256 fissa, quindi non manomettibili).

curl_cffi: serve a yt-dlp per scaricare da TikTok (il sito risponde solo a un browser "vero").
Si installa in ~/VODcut/librerie/ al primo link TikTok, poi resta li'.
"""
import hashlib
import importlib
import os
import platform
import shutil
import sys
import tempfile
import threading
import urllib.request
import zipfile

APP_DIR = os.path.join(os.path.expanduser("~"), "VODcut")
LIB_DIR = os.path.join(APP_DIR, "librerie")
_LOCK = threading.Lock()

_PY = "https://files.pythonhosted.org/packages/"
# (pacchetto, piattaforma) -> (url, sha256). Versioni scelte tra quelle supportate dallo yt-dlp incluso.
WHEELS = {
    ("curl_cffi", "win-amd64"): (_PY + "ad/03/b9df2973f1119f9d11d8fb3bf2682e5ffe5c52ef3ab89f720473c60fe97e/curl_cffi-0.16.0-cp310-abi3-win_amd64.whl",
                                 "e22a8212d830108e977ff394237f637238e265f5f65037d6c1ee71ea8cc03bcb"),
    ("curl_cffi", "mac-arm64"): (_PY + "2e/49/3b502d0d09e427b1bdec4f7339bb115c971c9b3fdaf355d02ca06e97ad61/curl_cffi-0.16.0-cp310-abi3-macosx_11_0_arm64.whl",
                                 "edd5f6e8f122157f4d2351b0b5e48e6a1c0677a2064da71451bb30ef57af19ba"),
    ("curl_cffi", "mac-x86_64"): (_PY + "fd/fe/0c330de78421af13e6384ab948e3adbcd4c638b06b53b7fff108bf1db121/curl_cffi-0.16.0-cp310-abi3-macosx_10_9_x86_64.whl",
                                  "6128021320f74999ec1216c1817b2c3adcb0f334d204add1ccf18e248bf7efcb"),
    ("curl_cffi", "linux-x86_64"): (_PY + "e4/45/9208864ec429558efac168088e50f8a91b947f742ee128cff55b88c7b635/curl_cffi-0.16.0-cp310-abi3-manylinux2014_x86_64.manylinux_2_17_x86_64.whl",
                                    "182416f07d71a342240554fa62c22e591999b78c225b21d3fe27d9f807420dd6"),
    # cffi: gia' incluso su Windows; serve solo se manca (Python 3.12)
    ("cffi", "win-amd64"): (_PY + "d9/79/615cc094e2fb508cade7de88d3b4f6c4ec2bab695c97bce9153dc65aadf5/cffi-2.1.1-cp312-cp312-win_amd64.whl",
                            "f53e442b08449d42821fa4a4fba000095af9f62742a500f978a9f557ec44339a"),
    ("cffi", "mac-arm64"): (_PY + "54/7d/16e5a096677b5e313ca80cd5e5170efa3ea44624a82bb111925522da64b1/cffi-2.1.1-cp312-cp312-macosx_11_0_arm64.whl",
                            "f81b3b8f3d4e343550fa4baa0e479bba9f2d29ce9c2e9b51d1ce1718d7442fcf"),
    ("cffi", "mac-x86_64"): (_PY + "10/69/43965eccfdead3b9220015fd1320e117be8c6ed01a62ffab76eeb752f5d5/cffi-2.1.1-cp312-cp312-macosx_10_15_x86_64.whl",
                             "c8c69575568085ba0b1b10c0249d779a214aea6f6522e949a0fc9fb0fcb449d0"),
}


def _plat():
    m = platform.machine().lower()
    if sys.platform == "win32":
        return "win-amd64" if m in ("amd64", "x86_64") else ""
    if sys.platform == "darwin":
        return "mac-arm64" if m in ("arm64", "aarch64") else "mac-x86_64"
    if sys.platform.startswith("linux") and m in ("x86_64", "amd64"):
        return "linux-x86_64"
    return ""


def _target(pkg):
    return os.path.join(LIB_DIR, pkg)


def _add_path(pkg):
    d = _target(pkg)
    if os.path.isdir(d) and d not in sys.path:
        sys.path.insert(0, d)


def _importable(mod):
    try:
        importlib.import_module(mod)
        return True
    except Exception:
        return False


def _install(pkg):
    url, sha = WHEELS.get((pkg, _plat()), (None, None))
    if not url:
        return False
    os.makedirs(LIB_DIR, exist_ok=True)
    fd, tmp = tempfile.mkstemp(suffix=".whl", dir=LIB_DIR)
    os.close(fd)
    try:
        h = hashlib.sha256()
        req = urllib.request.Request(url, headers={"User-Agent": "NoonFrame"})
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
            while True:
                b = r.read(1 << 16)
                if not b:
                    break
                h.update(b)
                f.write(b)
        if h.hexdigest() != sha:
            return False
        dest = _target(pkg)
        part = dest + ".nuovo"
        shutil.rmtree(part, ignore_errors=True)
        with zipfile.ZipFile(tmp) as z:
            for n in z.namelist():
                p = os.path.normpath(os.path.join(part, n))
                if not p.startswith(os.path.normpath(part) + os.sep):
                    return False
            z.extractall(part)
        shutil.rmtree(dest, ignore_errors=True)
        os.replace(part, dest)
        _add_path(pkg)
        return True
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def ensure_impersonation():
    """True se yt-dlp puo' fingersi un browser (serve per TikTok). Scarica curl_cffi la prima volta."""
    with _LOCK:
        _add_path("cffi")
        _add_path("curl_cffi")
        if _importable("curl_cffi"):
            return True
        try:
            if not _importable("cffi") and not (_install("cffi") and _importable("cffi")):
                return False
            if not _install("curl_cffi"):
                return False
            importlib.invalidate_caches()
            return _importable("curl_cffi")
        except Exception:
            return False


def load():
    """All'avvio: rende importabili le librerie gia' scaricate."""
    for p in ("cffi", "curl_cffi"):
        _add_path(p)
