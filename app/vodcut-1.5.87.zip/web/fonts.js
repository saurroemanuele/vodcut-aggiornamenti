// Font: quelli del sistema, quelli inclusi in NoonFrame (web/fonts) e quelli aggiunti dall'utente.
// Selettore con ricerca e categorie, anteprima di ogni font scritto nel suo stile.
import { h, icon, toast, get, post, TOKEN } from './lib.js';

export const SYSTEM_FONTS = ['Arial', 'Impact', 'Segoe UI', 'Verdana', 'Trebuchet MS', 'Tahoma', 'Georgia', 'Comic Sans MS'];
export const FONT_CATS = [['all', 'Tutti'], ['pop', 'Virali'], ['mod', 'Moderni'], ['tit', 'Titoli'], ['ele', 'Eleganti'],
  ['man', 'A mano'], ['tec', 'Tech'], ['sys', 'Sistema'], ['mine', 'I miei']];

let catalog = null, userFonts = [], loading = null;
const loaded = new Map();   // nome -> promessa
const done = new Set();     // font gia' caricati davvero (si possono misurare e disegnare)

export function loadFontList(force) {
  if (loading && !force) return loading;
  loading = Promise.all([
    catalog ? Promise.resolve(catalog) : fetch('/web/fonts/catalog.json').then((r) => r.json()).catch(() => []),
    get('/api/fonts').then((j) => j.user || []).catch(() => []),
  ]).then(([c, u]) => { catalog = c; userFonts = u; return allFonts(); });
  return loading;
}

export function allFonts() {
  const out = [];
  for (const x of catalog || []) out.push({ name: x.name, cat: x.cat });
  for (const n of SYSTEM_FONTS) out.push({ name: n, cat: 'sys' });
  for (const u of userFonts) out.push({ name: u.name, cat: 'mine', file: u.file });
  return out;
}

// carica il font (se non e' del sistema) prima di disegnare un testo con quel nome
export function ensureFont(name) {
  if (!name || SYSTEM_FONTS.includes(name)) return Promise.resolve(true);
  if (loaded.has(name)) return loaded.get(name);
  const p = loadFontList().then(async () => {
    const faces = [];
    const c = (catalog || []).find((x) => x.name === name);
    if (c) {
      const f = c.files || {};
      if (c.var) faces.push(new FontFace(name, `url(/web/fonts/${f.r})`, { weight: '100 900' }));
      else {
        faces.push(new FontFace(name, `url(/web/fonts/${f.r})`, { weight: '400' }));
        if (f.b) faces.push(new FontFace(name, `url(/web/fonts/${f.b})`, { weight: '700' }));
      }
    } else {
      for (const u of userFonts.filter((x) => x.name === name)) faces.push(new FontFace(name, `url(/api/userfont?file=${encodeURIComponent(u.file)}&token=${TOKEN})`));
    }
    if (!faces.length) return false;
    await Promise.all(faces.map((fc) => fc.load().then(() => document.fonts.add(fc)).catch(() => null)));
    done.add(name);
    return true;
  });
  loaded.set(name, p);
  return p;
}
export const fontReady = (name) => !name || SYSTEM_FONTS.includes(name) || done.has(name);

// aggiunge un font dell'utente (.ttf / .otf)
export function uploadFont() {
  return new Promise((res) => {
    const inp = h('input', { type: 'file', accept: '.ttf,.otf,font/ttf,font/otf', multiple: true, style: { display: 'none' } });
    inp.addEventListener('change', async () => {
      const added = [];
      for (const f of inp.files) {
        try {
          const r = await fetch(`/api/fonts?name=${encodeURIComponent(f.name)}&token=${TOKEN}`, { method: 'PUT', headers: { 'X-Token': TOKEN }, body: f });
          const j = await r.json();
          if (!r.ok) throw new Error(j.error || 'Errore');
          added.push(j.name);
        } catch (e) { toast(f.name + ': ' + e.message, true); }
      }
      inp.remove();
      if (added.length) { await loadFontList(true); toast(added.length > 1 ? `Aggiunti ${added.length} font` : `Font aggiunto: ${added[0]}`); }
      res(added);
    });
    document.body.append(inp); inp.click();
  });
}

// pulsante che mostra il font scelto (scritto in quel font); al clic si apre il selettore con la ricerca
export function fontPicker(cur, onPick) {
  const lab = h('span', { class: 'fp-name', 'data-notr': '' }, cur || 'Arial');
  const btn = h('button', { class: 'input fpick', type: 'button', 'aria-label': 'Font' }, lab, icon('chev', 12, 'currentColor', 2));
  const show = (n) => { lab.textContent = n; lab.style.fontFamily = `"${n}", Arial, sans-serif`; ensureFont(n); };
  show(cur || 'Arial');
  btn.addEventListener('click', () => openFontMenu(btn, lab.textContent, (n) => { show(n); onPick(n); }));
  btn.setValue = show;
  return btn;
}

let menuCat = 'all';
export async function openFontMenu(anchor, cur, onPick) {
  document.querySelectorAll('.fmenu').forEach((x) => x.remove());
  const search = h('input', { class: 'fm-search', type: 'search', placeholder: 'Cerca un font', 'aria-label': 'Cerca un font' });
  const cats = h('div', { class: 'fm-cats' });
  const list = h('div', { class: 'fm-list', role: 'listbox' });
  const addBtn = h('button', { class: 'fm-add', type: 'button' }, icon('plus', 13, 'currentColor', 2.2), 'Aggiungi i tuoi font (.ttf, .otf)');
  const m = h('div', { class: 'fmenu', role: 'dialog', 'aria-label': 'Scegli il font' },
    h('div', { class: 'fm-top' }, icon('magnify', 14), search), cats, list, addBtn);
  document.body.append(m);
  const r = anchor.getBoundingClientRect();
  const W = 320, H = Math.min(460, window.innerHeight - 24);
  m.style.width = W + 'px'; m.style.maxHeight = H + 'px';
  m.style.left = Math.max(8, Math.min(window.innerWidth - W - 8, r.left)) + 'px';
  const below = window.innerHeight - r.bottom - 10;
  m.style.top = (below >= Math.min(H, 360) ? r.bottom + 6 : Math.max(8, r.top - Math.min(H, m.offsetHeight) - 6)) + 'px';
  const close = () => { m.remove(); document.removeEventListener('pointerdown', off, true); document.removeEventListener('keydown', onKey, true); };
  const off = (e) => { if (!m.contains(e.target) && e.target !== anchor && !anchor.contains(e.target)) close(); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  setTimeout(() => { document.addEventListener('pointerdown', off, true); document.addEventListener('keydown', onKey, true); }, 0);
  // anteprime: ogni font si carica quando la sua riga si vede
  const io = new IntersectionObserver((ents) => ents.forEach((en) => { if (en.isIntersecting) { ensureFont(en.target.dataset.font); io.unobserve(en.target); } }), { root: list });
  await loadFontList();
  const draw = () => {
    const q = search.value.trim().toLowerCase();
    const fonts = allFonts();
    cats.replaceChildren(...FONT_CATS.filter(([k]) => k !== 'mine' || fonts.some((f) => f.cat === 'mine')).map(([k, n]) =>
      h('button', { class: 'fm-cat' + (menuCat === k && !q ? ' on' : ''), type: 'button', onclick: () => { menuCat = k; search.value = ''; draw(); } }, n)));
    const shown = fonts.filter((f) => (q ? f.name.toLowerCase().includes(q) : menuCat === 'all' || f.cat === menuCat));
    list.replaceChildren(...shown.map((f) => {
      const row = h('button', { class: 'fm-row' + (f.name === cur ? ' on' : ''), type: 'button', role: 'option', 'data-font': f.name, 'data-notr': '',
        onclick: async () => { await ensureFont(f.name); onPick(f.name); close(); } },
        h('span', { class: 'fm-aa', style: { fontFamily: `"${f.name}", Arial, sans-serif` } }, 'Aa'),
        h('span', { class: 'fm-n', style: { fontFamily: `"${f.name}", Arial, sans-serif` } }, f.name),
        f.cat === 'mine' ? h('span', { class: 'fm-del', role: 'button', title: 'Rimuovi questo font', onclick: async (e) => {
          e.stopPropagation();
          try { await post('/api/fonts/delete', { file: f.file }); await loadFontList(true); draw(); } catch (er) { toast(er.message, true); }
        } }, icon('x', 11, 'currentColor', 2.4)) : null);
      io.observe(row);
      return row;
    }));
    if (!shown.length) list.append(h('div', { class: 'fm-empty' }, q ? `Nessun font con "${search.value.trim()}"` : 'Nessun font qui', q ? h('small', null, 'Puoi aggiungere i tuoi font qui sotto') : null));
  };
  search.addEventListener('input', draw);
  addBtn.addEventListener('click', async () => { const got = await uploadFont(); if (got.length) { menuCat = 'mine'; search.value = ''; draw(); } });
  draw();
  search.focus();
  const on = list.querySelector('.fm-row.on'); if (on) on.scrollIntoView({ block: 'center' });
}
