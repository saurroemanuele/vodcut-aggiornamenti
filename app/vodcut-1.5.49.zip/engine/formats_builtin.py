"""Formati pronti di Noonframe: disponibili per tutti, solo da leggere (si duplicano per modificarli)."""
import json

BUILTIN = json.loads(r'''{
 "fm00000000a1": {
  "id": "fm00000000a1",
  "name": "App / prodotti digitali",
  "kind": "vendita",
  "goal": "Vendere un prodotto digitale (guida, libro, app) con video animati a personaggio fisso",
  "created": 1790600000.0,
  "updated": 1790600000.0,
  "videos": [],
  "analysis": {
   "summary": "Video animati da 75-95 secondi con un personaggio-mascotte (un animale in giacca e cravatta) che smonta una convinzione comune o svela un trucco che 'loro' (aziende, industria, comune, compagnie) sperano tu non conosca. Funzionano perché partono da una situazione che tutti vivono, mettono numeri e date concrete, fanno sentire chi guarda 'più furbo della massa' e chiudono vendendo il prodotto digitale (libro, guida, note private) come la fonte di altri segreti. Tre varianti che funzionano: il mito smontato con una storia vera, il trucco pratico con la regola esatta e i soldi risparmiati, la lezione lenta e solenne con il confronto prima/dopo.",
   "hooks": [
    "Scena di vita in seconda persona con perdita di soldi immediata: 'Ti arriva una multa… / Entri in ZTL per sbaglio… / Ti arriva l'SMS: la tariffa aumenta' (frase unica, entro 3 secondi)",
    "Mini-dialogo tra due personaggi in cui uno ripete una frase che 'sanno tutti' e l'altro chiede 'Chi te l'ha detto?' → 'Guarda qui' (entro 10 secondi si passa alla storia)",
    "Frase famosa o proverbio detto con convinzione, che verrà smontato ('Una mela al giorno toglie il medico di torno')",
    "Domanda sul prezzo di un oggetto del desiderio: 'Perché questa borsa costa 2.000 euro?'",
    "Promessa tradita, detta con calma: 'Ti avevano promesso il futuro. Guarda cosa abbiamo costruito davvero'",
    "Finta televendita ironica rivolta al potente: 'Avete appena conquistato un impero e…?'",
    "Cold open in mezzo a una scena già strana ('Mi sento uno schifo.' 'E continui a berla?') che crea curiosità prima di spiegare"
   ],
   "structure": [
    {
     "beat": "Hook",
     "share": 0.06,
     "what": "Situazione comune o frase che tutti credono vera. Il personaggio 'normale' sbaglia; la mascotte è lì a guardare."
    },
    {
     "beat": "Errore della massa",
     "share": 0.1,
     "what": "Descrivi cosa fa 'la persona normale' in frasi cortissime e un po' ironiche (paga subito, apre la busta, ringrazia pure il postino). Poi un 'Aspetta.' secco che gira il video."
    },
    {
     "beat": "La rivelazione",
     "share": 0.3,
     "what": "Il meccanismo nascosto: una data, un luogo, un articolo, un numero preciso. Nei miti: storia vera con anno e paese e chi ci guadagnava. Nei trucchi: la regola esatta, le scadenze, cosa costa (spesso 'gratis')."
    },
    {
     "beat": "Il conto",
     "share": 0.1,
     "what": "Numeri che si capiscono al volo: quanto ti chiedevano, quanto devi davvero, quanto risparmi / quanto è costato alla gente."
    },
    {
     "beat": "Ponte al prodotto",
     "share": 0.1,
     "what": "'Questo è solo il primo…' → il prodotto in bio (guida, libro, note private) presentato come l'elenco completo dei segreti. La gente ne conosce uno, la mascotte li conosce tutti."
    },
    {
     "beat": "Dettaglio extra dopo la CTA",
     "share": 0.14,
     "what": "Un'ultima attenzione concreta ('Attenzione a un dettaglio… se paghi anche un euro hai accettato') per tenere chi è arrivato fin qui e far salvare il video."
    },
    {
     "beat": "Morale a specchio + firma",
     "share": 0.2,
     "what": "Contrasto in due frasi ('Chi vince? Chi legge la data. Chi perde? Chi legge l'importo.' / 'E la rivolta? Un'altra volta.'), poi la frase firma del canale e l'invito: 'Leggi questo libro…' / 'Iscriviti per altri trucchi come questo'."
    }
   ],
   "pacing": {
    "length_sec": 80,
    "scene_sec": 1.8,
    "words_per_sec": 3.2,
    "notes": "In italiano ritmo alto: una visual nuova ogni 1,5-2 secondi, quasi una per frase, con la parola chiave della frase scritta grande sullo schermo. Frasi da 3-10 parole, molte da 1-3 ('Aspetta.' 'Nullo.' 'Gratis.'). La variante 'lenta e solenne' funziona con una visual ogni 3-6 secondi e 2,6-3 parole al secondo, ma solo con tono grave e pause."
   },
   "visuals": [
    "Sempre lo stesso personaggio-mascotte (animale antropomorfo in giacca e cravatta) come narratore: dà riconoscibilità alla serie",
    "Uno sfondo fisso e riconoscibile per il canale (verde scuro, aula, palco con proiettore) e stile disegnato coerente (cartone vintage, bianco e nero con un colore di accento)",
    "Un oggetto concreto per ogni frase: busta, calendario con il numero di giorni cerchiato, verbale con timbro 'NULLO', articolo di legge, soldi, borsa",
    "Parola chiave della frase in grande (giallo/bianco con bordo) al centro, cambia con ogni visual",
    "Prima/dopo affiancati per i confronti (telefono 1886 vs oggi, aula 1886 vs oggi)",
    "Nei miti: comparse d'epoca e ambientazioni storiche; in chiusura si torna ai personaggi dell'inizio (effetto cerchio)",
    "Persone 'normali' disegnate grigie e senza volto: sono la massa, la mascotte è l'unico colorato"
   ],
   "cta": [
    "Prodotto nominato a metà-fine come fonte di altri segreti: 'la guida di [mascotte], in bio, ne elenca decine'",
    "Invito diretto e personale in chiusura: 'Leggi questo libro e fallo leggere anche a tua nonna' (richiamo all'hook)",
    "Scarsità e appartenenza: 'Solo i primi 20.000. Link in bio. Leggi in silenzio. [Frase firma del canale].'",
    "Serie: 'Iscriviti per scoprire altri trucchi come questo' / numero della puntata nel titolo ('Trucco 36')"
   ],
   "rules": [
    "Parla in seconda persona ('ti arriva', 'paghi') per la situazione, e in terza per 'la persona normale' che sbaglia",
    "Metti sempre un numero concreto entro i primi 15 secondi (euro, giorni, anno, percentuale)",
    "Un'idea per frase, e frasi che si possono illustrare con un'immagine sola",
    "Usa un 'Aspetta.' o 'Guarda qui.' come cerniera tra l'errore e la rivelazione",
    "C'è sempre un 'loro' che ci guadagna (industria, comune, compagnia, marchio): la rivelazione è chi e come",
    "Il prodotto non si spiega mai: si presenta come la lista completa dei segreti di cui il video è un assaggio",
    "Chiudi con una frase-firma sempre uguale del canale e una morale a specchio in due frasi",
    "Tono: sicuro, un po' sornione, mai urlato; ironia sulla massa, complicità con chi guarda"
   ],
   "avoid": [
    "Temi di nicchia o legati a una situazione vecchia che pochi vivono oggi: il trucco deve toccare qualcosa che succede a tutti adesso",
    "Troppi passaggi burocratici in fila (raccomandata, 30 giorni, reclamo, 90 giorni): il guadagno deve arrivare subito",
    "Aprire con il contesto invece che con la situazione o la frase famosa",
    "Intro lente con saluti o presentazioni",
    "Citare leggi, studi o cifre non verificati: la credibilità è tutto il formato",
    "Cambiare personaggio o stile grafico tra un video e l'altro"
   ],
   "examples": [
    "Ti arriva la bolletta della luce con un conguaglio da 380 euro. La persona normale sospira. Paga. Chiede pure la rateizzazione. Aspetta. Il conguaglio deve riferirsi a consumi di un periodo preciso, e oltre quel periodo non te lo possono chiedere. [regola e scadenza verificate]. Basta un reclamo scritto. Gratis. Conguaglio preteso: 380 euro. Dovuto davvero: una parte, o niente. Questo è solo il primo trucco. Nella guida di [mascotte], in bio, ce ne sono decine come questo. Attenzione a un dettaglio: se paghi prima di reclamare, accetti. Chi vince? Chi legge le date. Chi perde? Chi legge il totale. Iscriviti per altri trucchi come questo.",
    "'Il caffè a stomaco vuoto fa male.' 'Chi te l'ha detto?' 'Lo sanno tutti.' 'E sai perché lo sanno tutti? Guarda qui.' [Anno e paese veri], un'azienda ha un problema: vende troppo poco di [prodotto]. Così inventa una regola che suona come un consiglio della nonna. La stampa sui giornali, la ripete per anni, finché la gente non la ripete da sola. Nessuno ricorda più da dove arrivi. Nel [anno] [fonte verificata] controlla i dati. Il risultato? [esito reale]. Quante frasi 'che sanno tutti' sono nate per venderti qualcosa? Leggi questo libro, e smettila di ripetere quello che ti hanno messo in bocca."
   ]
  },
  "builtin": true,
  "basedOn": "10 video TikTok di successo (circa 7 milioni di views in totale), analizzati da Noonframe",
  "prompt": "FORMATO \"App / prodotti digitali\" — Vendita di un'app o prodotto digitale\nVideo animati da 75-95 secondi con un personaggio-mascotte (un animale in giacca e cravatta) che smonta una convinzione comune o svela un trucco che 'loro' (aziende, industria, comune, compagnie) sperano tu non conosca. Funzionano perché partono da una situazione che tutti vivono, mettono numeri e date concrete, fanno sentire chi guarda 'più furbo della massa' e chiudono vendendo il prodotto digitale (libro, guida, note private) come la fonte di altri segreti. Tre varianti che funzionano: il mito smontato con una storia vera, il trucco pratico con la regola esatta e i soldi risparmiati, la lezione lenta e solenne con il confronto prima/dopo.\n\nAPERTURA (scegline una, varia sempre):\n- Scena di vita in seconda persona con perdita di soldi immediata: 'Ti arriva una multa… / Entri in ZTL per sbaglio… / Ti arriva l'SMS: la tariffa aumenta' (frase unica, entro 3 secondi)\n- Mini-dialogo tra due personaggi in cui uno ripete una frase che 'sanno tutti' e l'altro chiede 'Chi te l'ha detto?' → 'Guarda qui' (entro 10 secondi si passa alla storia)\n- Frase famosa o proverbio detto con convinzione, che verrà smontato ('Una mela al giorno toglie il medico di torno')\n- Domanda sul prezzo di un oggetto del desiderio: 'Perché questa borsa costa 2.000 euro?'\n- Promessa tradita, detta con calma: 'Ti avevano promesso il futuro. Guarda cosa abbiamo costruito davvero'\n- Finta televendita ironica rivolta al potente: 'Avete appena conquistato un impero e…?'\n- Cold open in mezzo a una scena già strana ('Mi sento uno schifo.' 'E continui a berla?') che crea curiosità prima di spiegare\n\nSTRUTTURA:\n- Hook (~6%): Situazione comune o frase che tutti credono vera. Il personaggio 'normale' sbaglia; la mascotte è lì a guardare.\n- Errore della massa (~10%): Descrivi cosa fa 'la persona normale' in frasi cortissime e un po' ironiche (paga subito, apre la busta, ringrazia pure il postino). Poi un 'Aspetta.' secco che gira il video.\n- La rivelazione (~30%): Il meccanismo nascosto: una data, un luogo, un articolo, un numero preciso. Nei miti: storia vera con anno e paese e chi ci guadagnava. Nei trucchi: la regola esatta, le scadenze, cosa costa (spesso 'gratis').\n- Il conto (~10%): Numeri che si capiscono al volo: quanto ti chiedevano, quanto devi davvero, quanto risparmi / quanto è costato alla gente.\n- Ponte al prodotto (~10%): 'Questo è solo il primo…' → il prodotto in bio (guida, libro, note private) presentato come l'elenco completo dei segreti. La gente ne conosce uno, la mascotte li conosce tutti.\n- Dettaglio extra dopo la CTA (~14%): Un'ultima attenzione concreta ('Attenzione a un dettaglio… se paghi anche un euro hai accettato') per tenere chi è arrivato fin qui e far salvare il video.\n- Morale a specchio + firma (~20%): Contrasto in due frasi ('Chi vince? Chi legge la data. Chi perde? Chi legge l'importo.' / 'E la rivolta? Un'altra volta.'), poi la frase firma del canale e l'invito: 'Leggi questo libro…' / 'Iscriviti per altri trucchi come questo'.\n\nRITMO: circa 80 secondi, una scena/visual ogni 1.8 secondi, 3.2 parole al secondo. In italiano ritmo alto: una visual nuova ogni 1,5-2 secondi, quasi una per frase, con la parola chiave della frase scritta grande sullo schermo. Frasi da 3-10 parole, molte da 1-3 ('Aspetta.' 'Nullo.' 'Gratis.'). La variante 'lenta e solenne' funziona con una visual ogni 3-6 secondi e 2,6-3 parole al secondo, ma solo con tono grave e pause.\n\nIMMAGINI:\n- Sempre lo stesso personaggio-mascotte (animale antropomorfo in giacca e cravatta) come narratore: dà riconoscibilità alla serie\n- Uno sfondo fisso e riconoscibile per il canale (verde scuro, aula, palco con proiettore) e stile disegnato coerente (cartone vintage, bianco e nero con un colore di accento)\n- Un oggetto concreto per ogni frase: busta, calendario con il numero di giorni cerchiato, verbale con timbro 'NULLO', articolo di legge, soldi, borsa\n- Parola chiave della frase in grande (giallo/bianco con bordo) al centro, cambia con ogni visual\n- Prima/dopo affiancati per i confronti (telefono 1886 vs oggi, aula 1886 vs oggi)\n- Nei miti: comparse d'epoca e ambientazioni storiche; in chiusura si torna ai personaggi dell'inizio (effetto cerchio)\n- Persone 'normali' disegnate grigie e senza volto: sono la massa, la mascotte è l'unico colorato\n\nCHIUSURA:\n- Prodotto nominato a metà-fine come fonte di altri segreti: 'la guida di [mascotte], in bio, ne elenca decine'\n- Invito diretto e personale in chiusura: 'Leggi questo libro e fallo leggere anche a tua nonna' (richiamo all'hook)\n- Scarsità e appartenenza: 'Solo i primi 20.000. Link in bio. Leggi in silenzio. [Frase firma del canale].'\n- Serie: 'Iscriviti per scoprire altri trucchi come questo' / numero della puntata nel titolo ('Trucco 36')\n\nREGOLE:\n- Parla in seconda persona ('ti arriva', 'paghi') per la situazione, e in terza per 'la persona normale' che sbaglia\n- Metti sempre un numero concreto entro i primi 15 secondi (euro, giorni, anno, percentuale)\n- Un'idea per frase, e frasi che si possono illustrare con un'immagine sola\n- Usa un 'Aspetta.' o 'Guarda qui.' come cerniera tra l'errore e la rivelazione\n- C'è sempre un 'loro' che ci guadagna (industria, comune, compagnia, marchio): la rivelazione è chi e come\n- Il prodotto non si spiega mai: si presenta come la lista completa dei segreti di cui il video è un assaggio\n- Chiudi con una frase-firma sempre uguale del canale e una morale a specchio in due frasi\n- Tono: sicuro, un po' sornione, mai urlato; ironia sulla massa, complicità con chi guarda\n\nDA EVITARE:\n- Temi di nicchia o legati a una situazione vecchia che pochi vivono oggi: il trucco deve toccare qualcosa che succede a tutti adesso\n- Troppi passaggi burocratici in fila (raccomandata, 30 giorni, reclamo, 90 giorni): il guadagno deve arrivare subito\n- Aprire con il contesto invece che con la situazione o la frase famosa\n- Intro lente con saluti o presentazioni\n- Citare leggi, studi o cifre non verificati: la credibilità è tutto il formato\n- Cambiare personaggio o stile grafico tra un video e l'altro\n\nESEMPI DI STRUTTURA (non copiarli, sono solo modelli):\n---\nTi arriva la bolletta della luce con un conguaglio da 380 euro. La persona normale sospira. Paga. Chiede pure la rateizzazione. Aspetta. Il conguaglio deve riferirsi a consumi di un periodo preciso, e oltre quel periodo non te lo possono chiedere. [regola e scadenza verificate]. Basta un reclamo scritto. Gratis. Conguaglio preteso: 380 euro. Dovuto davvero: una parte, o niente. Questo è solo il primo trucco. Nella guida di [mascotte], in bio, ce ne sono decine come questo. Attenzione a un dettaglio: se paghi prima di reclamare, accetti. Chi vince? Chi legge le date. Chi perde? Chi legge il totale. Iscriviti per altri trucchi come questo.\n---\n'Il caffè a stomaco vuoto fa male.' 'Chi te l'ha detto?' 'Lo sanno tutti.' 'E sai perché lo sanno tutti? Guarda qui.' [Anno e paese veri], un'azienda ha un problema: vende troppo poco di [prodotto]. Così inventa una regola che suona come un consiglio della nonna. La stampa sui giornali, la ripete per anni, finché la gente non la ripete da sola. Nessuno ricorda più da dove arrivi. Nel [anno] [fonte verificata] controlla i dati. Il risultato? [esito reale]. Quante frasi 'che sanno tutti' sono nate per venderti qualcosa? Leggi questo libro, e smettila di ripetere quello che ti hanno messo in bocca.\n\nScrivi sempre testi originali: prendi la struttura, mai le frasi. Non inventare risultati, numeri, recensioni o prezzi."
 }
}''')
