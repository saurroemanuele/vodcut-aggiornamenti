"""Formati: si impara da video che funzionano (propri o di altri) per scrivere script dello stesso tipo.

Per ogni video di riferimento l'app, sul computer: trascrive il parlato (Whisper), trova i cambi di inquadratura
(le "visual", con ffmpeg), salva un fotogramma per ogni inquadratura e calcola ritmo e numeri. Poi l'AI (con la
chiave dell'utente) legge tutto e scrive il FORMATO: come aprire, struttura, ritmo, regole, chiusure.

Si impara la struttura, non si copiano le frasi: gli script nuovi sono sempre originali.
Tutto resta in ~/VODcut/formati/<id>: formato.json, LEGGIMI.md (riassunto leggibile) e i fotogrammi.
"""
import json
import os
import re
import secrets
import shutil
import subprocess
import threading
import time

from . import ai
from .util import APP_DIR, NO_WINDOW, ffmpeg_bin, probe

FORMATS_DIR = os.path.join(APP_DIR, "formati")
_LOCKS = {}
_GLOCK = threading.Lock()
KINDS = {"vendita": "Vendita di un'app o prodotto digitale", "ugc": "UGC / recensione", "storia": "Storia / racconto",
         "educativo": "Educativo / consigli", "altro": "Altro"}


def _lock(k):
    with _GLOCK:
        return _LOCKS.setdefault(k, threading.RLock())


def _fid(x):
    x = str(x or "")
    if not re.fullmatch(r"fm[0-9a-f]{8,16}", x):
        raise ValueError("Formato non valido")
    return x


def _dir(fid):
    return os.path.join(FORMATS_DIR, _fid(fid))


def _path(fid):
    return os.path.join(_dir(fid), "formato.json")


READONLY = "Questo è un formato pronto di Noonframe: duplicalo per modificarlo"


def _builtin():
    try:
        from .formats_builtin import BUILTIN
        return BUILTIN
    except Exception:
        return {}


def get(fid):
    b = _builtin().get(str(fid or ""))
    if b:
        return json.loads(json.dumps(b))
    with open(_path(fid), encoding="utf-8") as f:
        fm = json.load(f)
    for v in fm.get("videos") or []:      # il giudizio cambia col tempo (un video nuovo cresce)
        if v.get("stats") or v.get("views"):
            rate(v)
    return fm


def save(fm):
    if fm.get("id") in _builtin():
        raise ValueError(READONLY)
    fm["updated"] = time.time()
    os.makedirs(_dir(fm["id"]), exist_ok=True)
    tmp = _path(fm["id"]) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(fm, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _path(fm["id"]))
    try:
        write_readme(fm)
    except Exception as e:
        print(f"[formati] LEGGIMI non scritto: {e}", flush=True)
    return fm


def _s(v, n):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v or ""))[:n]


def list_all():
    out = []
    try:
        names = os.listdir(FORMATS_DIR)
    except OSError:
        names = []                         # nessun formato creato su questo computer: restano quelli pronti
    for n in names:
        try:
            fm = get(n)
        except Exception:
            continue
        vids = fm.get("videos") or []
        out.append({"id": fm["id"], "name": fm.get("name"), "kind": fm.get("kind"), "videos": len(vids),
                    "ready": sum(1 for v in vids if v.get("status") == "pronto"), "hasPrompt": bool(fm.get("prompt")),
                    "thumb": next((v["thumbs"][0] for v in vids if v.get("thumbs")), None), "updated": fm.get("updated")})
    out.sort(key=lambda x: x.get("updated") or 0, reverse=True)
    for fm in _builtin().values():      # i formati pronti di Noonframe, in fondo
        out.append({"id": fm["id"], "name": fm.get("name"), "kind": fm.get("kind"), "videos": 0, "ready": 0, "hasPrompt": True,
                    "thumb": None, "updated": fm.get("updated"), "builtin": True, "basedOn": fm.get("basedOn")})
    return out


def duplicate(fid):
    """Copia modificabile di un formato (anche di uno pronto): stessa analisi e stesso testo, senza video."""
    src = get(fid)
    fm = create((src.get("name") or "Formato") + (" (mio)" if src.get("builtin") else " (copia)"), src.get("kind"))
    fm.update(goal=src.get("goal") or "", analysis=src.get("analysis"), prompt=src.get("prompt") or "")
    return save(fm)


def create(name, kind):
    fid = "fm" + secrets.token_hex(5)
    fm = {"id": fid, "name": _s(name, 80).strip() or "Nuovo formato", "kind": kind if kind in KINDS else "altro", "goal": "",
          "created": time.time(), "videos": [], "analysis": None, "prompt": ""}
    return save(fm)


def update(fid, data):
    with _lock(fid):
        fm = get(fid)
        for k, n in (("name", 80), ("goal", 1500), ("prompt", 12000)):
            if k in data:
                fm[k] = _s(data[k], n)
        if data.get("kind") in KINDS:
            fm["kind"] = data["kind"]
        for vd in data.get("videos") or []:
            v = next((x for x in fm["videos"] if x["id"] == vd.get("id")), None)
            if not v:
                continue
            if "views" in vd and not v.get("url"):      # i numeri dei link arrivano da soli; a mano solo per i file
                v["views"] = _s(vd["views"], 20)
                rate(v)
            if "note" in vd:
                v["note"] = _s(vd["note"], 500)
            if "title" in vd:
                v["title"] = _s(vd["title"], 120)
            if "recount" in vd:
                v["recount"] = bool(vd["recount"])
        return save(fm)


def delete(fid):
    if fid in _builtin():
        raise ValueError(READONLY)
    d = _dir(fid)
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    return True


def remove_video(fid, vid):
    with _lock(fid):
        fm = get(fid)
        v = next((x for x in fm["videos"] if x["id"] == vid), None)
        if v:
            fm["videos"].remove(v)
            d = os.path.join(_dir(fid), "video", vid)
            shutil.rmtree(d, ignore_errors=True)
        return save(fm)


SOURCES = {"tiktok": "TikTok", "instagram": "Instagram", "youtube": "YouTube", "file": "File dal computer", "web": "Altro sito"}


def source(v):
    """Da dove viene il video: TikTok, Instagram, YouTube, file dal computer."""
    u = (v.get("url") or "").lower()
    if not u:
        return "file"
    for k, keys in (("tiktok", ("tiktok.com",)), ("instagram", ("instagram.com",)), ("youtube", ("youtube.com", "youtu.be"))):
        if any(x in u for x in keys):
            return k
    return "web"


def _num(x):
    """'1,2M' / '316K' / '316000' -> 316000."""
    if x is None:
        return None
    if isinstance(x, (int, float)):
        return int(x)
    t = str(x).strip().lower().replace(" ", "").replace(".", "").replace(",", ".")
    m = re.match(r"^([0-9]+(?:\.[0-9]+)?)([km]?)$", t)
    if not m:
        return None
    return int(float(m.group(1)) * {"": 1, "k": 1e3, "m": 1e6}[m.group(2)])


def rate(v):
    """Top / Ok / Flop in automatico, dai numeri pubblici del video (views e interazioni)."""
    st = v.get("stats") or {}
    views = st.get("views")
    if views is None:
        views = _num(v.get("views"))
    if not views:
        v["rating"], v["ratingWhy"] = "", ""
        return v
    inter = sum(int(st.get(k) or 0) for k in ("likes", "comments", "shares", "saves"))
    eng = inter / views if inter else None
    if views >= 300_000 or (views >= 100_000 and eng is not None and eng >= 0.10):
        r = "top"
    elif views < 20_000 or (views < 50_000 and eng is not None and eng < 0.03):
        r = "flop"
    else:
        r = "ok"
    why = f"{views:,} views".replace(",", ".") + (f" · {eng * 100:.1f}% interazioni" if eng is not None else "")
    days = _age_days(st.get("date"))
    if r != "top" and days is not None and days < 3:     # troppo presto per dire che e' andato male
        r = "new"
        why += f" · pubblicato da {days} giorn{'o' if days == 1 else 'i'}: troppo presto per giudicarlo"
    v["rating"], v["ratingWhy"] = r, why
    return v


def _age_days(d):
    try:
        import datetime
        t = datetime.datetime.strptime(str(d)[:8], "%Y%m%d").date()
        return max(0, (datetime.date.today() - t).days)
    except Exception:
        return None


def stats_from_info(info):
    g = lambda k: int(info[k]) if isinstance(info.get(k), (int, float)) else None
    st = {"views": g("view_count"), "likes": g("like_count"), "comments": g("comment_count"),
          "shares": g("repost_count"), "saves": g("save_count"), "uploader": info.get("uploader") or info.get("channel") or "",
          "date": info.get("upload_date") or ""}
    return {k: v for k, v in st.items() if v not in (None, "")}


def _link_title(url):
    """https://www.tiktok.com/@nome/video/123?… -> 'TikTok · @nome'."""
    m = re.search(r"(tiktok|instagram|youtube|youtu)\.[a-z.]+/(@[\w.\-]+)?", url or "")
    if not m:
        return url
    site = {"tiktok": "TikTok", "instagram": "Instagram", "youtube": "YouTube", "youtu": "YouTube"}[m.group(1)]
    return site + (" · " + m.group(2) if m.group(2) else "")


def add_videos(fid, items):
    """items: [{path} o {url}] -> i video entrano in coda (stato 'in coda')."""
    with _lock(fid):
        fm = get(fid)
        added = []
        for it in items[:100]:
            vid = "v" + secrets.token_hex(4)
            src = str(it.get("path") or it.get("url") or "")
            if not src:
                continue
            v = {"id": vid, "title": _s(it.get("title") or (os.path.basename(src) if it.get("path") else _link_title(src)), 120),
                 "path": it.get("path") or "", "url": it.get("url") or "", "status": "in coda", "error": None,
                 "views": "", "rating": "", "note": "", "shotsManual": None, "added": time.time()}
            fm["videos"].append(v)
            added.append(vid)
        save(fm)
    return added


# ------------------------------------------------------------------ analisi di un video (sul computer)
SHOTS_ALGO = 3  # versione del conteggio visual (se cambia, i video vecchi si ricontano)
_W = 96          # larghezza dei fotogrammi usati per l'analisi (piccoli = veloce)


def _read_frames(path, dur):
    """Una sola lettura del video: tutti i fotogrammi (max 30 al secondo), piccoli e in grigio."""
    import cv2
    import numpy as np
    fps = 30 if dur <= 240 else 15
    vf = f"fps={fps},scale={_W}:-2:flags=area,format=gray"
    one = subprocess.run([ffmpeg_bin(), "-v", "error", "-i", path, "-an", "-frames:v", "1", "-vf", vf, "-f", "image2pipe", "-c:v", "png", "-"],
                         capture_output=True, creationflags=NO_WINDOW, timeout=60)
    im = cv2.imdecode(np.frombuffer(one.stdout, np.uint8), cv2.IMREAD_GRAYSCALE) if one.stdout else None
    if im is None:
        raise RuntimeError("Non riesco a leggere il video")
    h, w = im.shape
    r = subprocess.run([ffmpeg_bin(), "-v", "error", "-threads", "0", "-i", path, "-an", "-vf", vf, "-f", "rawvideo", "-"],
                       capture_output=True, creationflags=NO_WINDOW, timeout=max(300, dur * 3))
    buf = np.frombuffer(r.stdout, np.uint8)
    n = len(buf) // (w * h)
    return buf[:n * w * h].reshape(n, h, w), fps


def _box(fr):
    """Parte del fotogramma dove c'e' davvero il video. Nei TikTok spesso il video e' una fascia in mezzo,
    con bande nere e titolo fisso: se contassimo tutto, i tagli veri sembrerebbero piccoli."""
    import numpy as np
    n, h, w = fr.shape
    sd = fr[::max(1, n // 150)].astype(np.float32).std(axis=0)
    def span(prof):
        m = prof.max()
        if m < 4:
            return None
        idx = np.where(prof > 0.35 * m)[0]
        return (int(idx[0]), int(idx[-1]) + 1) if len(idx) else None
    r, c = span(sd.mean(axis=1)), span(sd.mean(axis=0))
    if r and c and 0.12 <= (r[1] - r[0]) * (c[1] - c[0]) / (h * w) <= 0.92:
        return r[0], r[1], c[0], c[1]
    return 0, h, 0, w


def _cuts(fr, fps, dur, box, floor=0.04, k=2.0, add=0.01, gap=0.4):
    """Un taglio e' un picco netto rispetto a quello che succede intorno (si adatta a ogni video).
    Poi confronta l'immagine prima e dopo: se e' la stessa scena (cambia solo il sottotitolo o
    il personaggio si muove), non e' una visual nuova."""
    import cv2
    import numpy as np
    y0, y1, x0, x1 = box
    c = fr[:, y0:y1, x0:x1].astype(np.float32)
    n = len(c)
    if n < 2:
        return [0.0]
    s = np.concatenate([[0.0], np.abs(np.diff(c, axis=0)).mean(axis=(1, 2)) / 255.0])
    win, loc = int(fps), max(3, int(fps * 0.4))

    def small(im):
        im = im[:int(im.shape[0] * 0.78)]            # senza la fascia dei sottotitoli
        return cv2.GaussianBlur(cv2.resize(im, (48, 36), interpolation=cv2.INTER_AREA), (3, 3), 0)
    cuts = [0.0]
    for i in np.where(s >= floor)[0]:
        lo, hi = max(0, i - win), min(n, i + win + 1)
        base = float(np.median(np.concatenate([s[lo:i], s[i + 1:hi]])))
        if s[i] < k * base + add or s[max(0, i - loc):min(n, i + loc + 1)].max() > s[i]:
            continue
        t = float(i) / fps
        if t - cuts[-1] < gap or t > dur - 0.2:
            continue
        a, b = small(c[max(0, i - 4)]), small(c[min(n - 1, i + 3)])
        corr = float(np.corrcoef(a.ravel(), b.ravel())[0, 1]) if a.std() > 1 and b.std() > 1 else 0.0
        if corr > 0.85 and float(np.abs(a - b).mean()) < 20:
            continue
        cuts.append(round(t, 2))
    return cuts


def keyframes(path, shots, dur, outdir, box=None, fps=30, limit=150):
    """I fotogrammi di tutte le visual con una sola lettura del video (box = parte utile, in frazioni)."""
    os.makedirs(outdir, exist_ok=True)
    idx = []
    for k, a in enumerate(shots[:limit]):
        b = shots[k + 1] if k + 1 < len(shots) else dur
        idx.append(int(round(min(a + 0.35, a + (b - a) / 2) * fps)))
    crop = ""
    if box and box != (0.0, 1.0, 0.0, 1.0):
        y0, y1, x0, x1 = box
        crop = f"crop=iw*{x1 - x0:.4f}:ih*{y1 - y0:.4f}:iw*{x0:.4f}:ih*{y0:.4f},"
    sel = "+".join(f"eq(n\\,{i})" for i in idx) or "eq(n\\,0)"
    vf = f"fps={fps},{crop}select={sel},scale=240:-2"
    subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-i", path, "-an", "-vf", vf, "-fps_mode", "vfr", "-q:v", "4",
                    os.path.join(outdir, "%03d.jpg")], capture_output=True, creationflags=NO_WINDOW, timeout=max(300, dur * 3))
    return [os.path.join(outdir, f"{k + 1:03d}.jpg") for k in range(len(idx)) if os.path.isfile(os.path.join(outdir, f"{k + 1:03d}.jpg"))]


def contact_sheet(files, shots, dst, cols=8):
    """Tutte le inquadrature in un'immagine sola, con il tempo di ognuna (comoda da leggere a colpo d'occhio)."""
    import cv2
    import numpy as np
    ims = []
    for f, t in zip(files, shots):
        im = cv2.imdecode(np.fromfile(f, dtype=np.uint8), cv2.IMREAD_COLOR)
        if im is None:
            continue
        im = cv2.resize(im, (180, int(180 * im.shape[0] / im.shape[1])))
        cv2.rectangle(im, (0, 0), (62, 20), (0, 0, 0), -1)
        cv2.putText(im, f"{t:.1f}s", (4, 15), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
        ims.append(im)
    if not ims:
        return None
    hmax = max(i.shape[0] for i in ims)
    ims = [cv2.copyMakeBorder(i, 0, hmax - i.shape[0], 0, 0, cv2.BORDER_CONSTANT, value=(20, 20, 20)) for i in ims]
    while len(ims) % cols:
        ims.append(np.full_like(ims[0], 20))
    rows = [np.hstack(ims[r * cols:(r + 1) * cols]) for r in range(len(ims) // cols)]
    ok, buf = cv2.imencode(".jpg", np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 85])
    if ok:
        buf.tofile(dst)
        return dst
    return None


def find_shots(path, dur, vd):
    fr, fps = _read_frames(path, dur)
    box = _box(fr)
    h, w = fr.shape[1:]
    shots = _cuts(fr, fps, dur, box)
    del fr
    rel = (box[0] / h, box[1] / h, box[2] / w, box[3] / w)
    fd = os.path.join(vd, "fotogrammi")
    shutil.rmtree(fd, ignore_errors=True)
    thumbs = keyframes(path, shots, dur, fd, rel, fps=fps)
    sheet = contact_sheet(thumbs, shots, os.path.join(vd, "inquadrature.jpg"))
    return shots, thumbs, sheet


def recount(fid, vid, stats=None):
    """Riconta le visual di un video gia' analizzato (non rifa' la trascrizione)."""
    v = next(x for x in get(fid)["videos"] if x["id"] == vid)
    path = v.get("path")
    if not path or not os.path.isfile(path):
        raise RuntimeError("File del video non trovato")
    dur = float(v.get("dur") or probe(path)["duration"])
    shots, thumbs, sheet = find_shots(path, dur, os.path.join(_dir(fid), "video", vid))
    with _lock(fid):
        cur = get(fid)
        x = next((y for y in cur["videos"] if y["id"] == vid), None)
        if x is not None:
            x.update(shots=shots, thumbs=thumbs, sheet=sheet, shotsAlgo=SHOTS_ALGO, shotsManual=None,
                     shotLen=round(dur / max(1, len(shots)), 2))
            if stats:
                x["stats"] = stats
                x["views"] = str(stats.get("views") or x.get("views") or "")
            elif x.get("url"):
                x.setdefault("stats", {})
            rate(x)
            save(cur)
    return len(shots)


def analyze_video(fid, vid, transcribe, download=None, progress=None, cancel=None):
    """Una sola analisi alla volta per video: trascrizione, inquadrature, fotogrammi, numeri."""
    fm = get(fid)
    v = next(x for x in fm["videos"] if x["id"] == vid)
    vd = os.path.join(_dir(fid), "video", vid)
    os.makedirs(vd, exist_ok=True)

    def st(**kw):
        with _lock(fid):
            cur = get(fid)
            x = next((y for y in cur["videos"] if y["id"] == vid), None)
            if x is not None:
                x.update(kw)
                save(cur)
    path = v.get("path")
    if not path and v.get("url"):
        st(status="scarico")
        got = download(v["url"], vd)
        path, title = got[0], got[1]
        stats = got[2] if len(got) > 2 else {}
        x = rate({"stats": stats})
        st(path=path, title=_s(title, 120) or v["title"], stats=stats, views=str(stats.get("views") or ""),
           rating=x["rating"], ratingWhy=x["ratingWhy"])
    if not path or not os.path.isfile(path):
        raise RuntimeError("File del video non trovato")
    dur = probe(path)["duration"]
    st(status="inquadrature", dur=round(dur, 2))
    if progress:
        progress(0.1, "Trovo i cambi di inquadratura")
    shots, thumbs, sheet = find_shots(path, dur, vd)
    st(status="trascrivo", shots=shots, thumbs=thumbs, sheet=sheet, shotsAlgo=SHOTS_ALGO)
    if progress:
        progress(0.35, "Trascrivo il parlato")
    segs, words = [], 0
    try:
        tr = transcribe(path, dur, lambda x: progress and progress(0.35 + 0.6 * x, "Trascrivo il parlato"), cancel)
        for sg in tr.get("segments", []):
            t = " ".join(w.get("w", "") for w in sg.get("words", [])).strip() or sg.get("text", "")
            if t:
                segs.append({"a": round(float(sg.get("a", 0)), 2), "b": round(float(sg.get("b", 0)), 2), "t": t})
                words += len(t.split())
        lang = tr.get("language")
    except Exception as e:
        if "annullato" in str(e).lower():
            raise
        st(status="errore", error="Trascrizione non riuscita: " + str(e)[:200])
        raise
    speech = sum(s["b"] - s["a"] for s in segs) or dur
    st(status="pronto", transcript=segs, lang=lang, words=words, wps=round(words / max(1.0, speech), 2),
       shotLen=round(dur / max(1, len(shots)), 2), hook=" ".join(s["t"] for s in segs if s["a"] < 3.0)[:300], error=None)
    return True


# ------------------------------------------------------------------ riassunto leggibile (anche da Claude)
def _fmt_t(t):
    return f"{int(t // 60)}:{t % 60:04.1f}"


def write_readme(fm):
    L = [f"# Formato: {fm.get('name')}", "", f"Tipo: {KINDS.get(fm.get('kind'), fm.get('kind'))}"]
    if fm.get("goal"):
        L += ["", f"Obiettivo: {fm['goal']}"]
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"]
    if vids:
        avg = lambda k: sum(float(v.get(k) or 0) for v in vids) / len(vids)
        L += ["", f"Video analizzati: {len(vids)} · durata media {avg('dur'):.1f}s · inquadratura media {avg('shotLen'):.2f}s · "
                  f"parole al secondo {avg('wps'):.2f}"]
        L += ["", "Per piattaforma:"]
        for k, name in SOURCES.items():
            g = [v for v in vids if source(v) == k]
            if g:
                a = lambda key: sum(float(v.get(key) or 0) for v in g) / len(g)
                L.append(f"- {name}: {len(g)} video · durata media {a('dur'):.1f}s · una visual ogni {a('shotLen'):.2f}s · parole/s {a('wps'):.2f}")
    for n, v in enumerate(fm.get("videos") or [], 1):
        L += ["", f"## Video {n}: {v.get('title')}", ""]
        meta = [f"stato: {v.get('status')}", f"piattaforma: {SOURCES[source(v)]}"]
        if v.get("dur"):
            nsh = len(v.get("shots") or [])
            meta += [f"durata {v['dur']}s", f"visual {nsh}" + "", f"inquadratura media {v.get('shotLen')}s",
                     f"parole/s {v.get('wps')}"]
        stt = v.get("stats") or {}
        for k, lbl in (("likes", "like"), ("comments", "commenti"), ("shares", "condivisioni"), ("saves", "salvataggi"), ("uploader", "account"), ("date", "pubblicato")):
            if stt.get(k) not in (None, ""):
                meta.append(f"{lbl}: {stt[k]}")
        for k, lbl in (("views", "views"), ("rating", "risultato"), ("url", "link"), ("note", "note")):
            if v.get(k):
                meta.append(f"{lbl}: {v[k]}")
        L.append(" · ".join(meta))
        if v.get("sheet"):
            L.append(f"Inquadrature (immagine): {os.path.relpath(v['sheet'], _dir(fm['id']))}")
        if v.get("transcript"):
            L += ["", "Trascrizione (con i cambi di inquadratura ▌):"]
            shots = v.get("shots") or []
            segs = v["transcript"]
            for i, sg in enumerate(segs):
                a = sg["a"] if i else 0.0
                b = segs[i + 1]["a"] if i + 1 < len(segs) else 1e9
                cuts = sum(1 for t in shots if a <= t < b)
                L.append(f"- [{_fmt_t(sg['a'])}] {'▌' * cuts} {sg['t']}")
    if fm.get("prompt"):
        L += ["", "## Formato generato", "", fm["prompt"]]
    with open(os.path.join(_dir(fm["id"]), "LEGGIMI.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


# ------------------------------------------------------------------ l'AI scrive il formato
def dataset_text(fm, max_chars=60000):
    parts = []
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"]
    order = {"top": 0, "ok": 1, "new": 2, "": 2, "flop": 3}
    vids.sort(key=lambda v: order.get(v.get("rating") or "", 2))
    for n, v in enumerate(vids, 1):
        nsh = len(v.get("shots") or [])
        head = (f"VIDEO {n} · {SOURCES[source(v)]} · risultato: {({'new': 'troppo nuovo per giudicarlo'}).get(v.get('rating'), v.get('rating')) or 'non indicato'} ({v.get('ratingWhy') or 'views ?'}) · durata {v.get('dur')}s · "
                f"{nsh} visual (una ogni {round(float(v.get('dur') or 0) / max(1, nsh), 2)}s) · {v.get('wps')} parole/s" +
                (f" · note: {v['note']}" if v.get("note") else ""))
        tx = "\n".join(f"[{sg['a']:.1f}s] {sg['t']}" for sg in v.get("transcript") or [])
        parts.append(head + "\n" + tx)
    txt = "\n\n".join(parts)
    return txt[:max_chars]


OUT_TOKENS = 3500   # risposta tipica: il formato in JSON con 2 esempi di script


def estimate_analysis(fm):
    """Quanto costa far analizzare i video a ogni modello, e quale conviene (solo chiavi collegate = si possono scegliere)."""
    data = dataset_text(fm)
    tin = int((len(_SYSTEM) + len(data) + 200) / 3.2)      # ~3,2 caratteri per token in italiano
    keys = ai.keys_status()
    opts = []
    for prov in ("anthropic", "openai", "gemini"):
        for m in ai.MODELS["text"][prov]:
            i = ai.TEXT_INFO.get(m)
            if not i:
                continue
            opts.append({"provider": prov, "providerName": ai.PROVIDERS[prov]["name"], "model": m, "name": i["name"], "tier": i["tier"],
                         "why": i["why"], "cost": round(ai.text_cost(m, tin, OUT_TOKENS), 4), "ready": bool(keys[prov]["set"])})
    ready = [o for o in opts if o["ready"]]
    rec = None
    if ready:
        best = max(o["tier"] for o in ready)
        good = [o for o in ready if o["tier"] >= min(4, best)]
        rec = min(good, key=lambda o: o["cost"])
        cheap = min(ready, key=lambda o: o["cost"])
        top = max(ready, key=lambda o: (o["tier"], -o["cost"]))
        for o in ready:
            o["tags"] = [t for t, x in (("rec", rec), ("cheap", cheap), ("best", top)) if x is o]
    videos = len([v for v in fm.get("videos") or [] if v.get("status") == "pronto"])
    return {"tokensIn": tin, "tokensOut": OUT_TOKENS, "videos": videos, "options": opts,
            "recommended": {"provider": rec["provider"], "model": rec["model"]} if rec else None}


_SYSTEM = ("Sei un analista di contenuti short-form (TikTok, Reels, Shorts). Ricevi trascrizioni con tempi di video di riferimento, "
           "con numero di inquadrature e risultati. Estrai la STRUTTURA che li fa funzionare, senza copiare frasi: dai più peso ai "
           "video con risultato 'top' e views alte, e segnala cosa hanno di diverso i 'flop'. Scrivi in italiano. "
           "Rispondi SOLO con JSON:\n")


def build_prompt(fm, cfg, cancel=None):
    data = dataset_text(fm)
    if not data.strip():
        raise ai.AIError("Nessun video pronto: aggiungi e analizza almeno 3 video")
    system = ("Sei un analista di contenuti short-form (TikTok, Reels, Shorts). Ricevi trascrizioni con tempi di video di riferimento, "
              "con numero di inquadrature e risultati. Estrai la STRUTTURA che li fa funzionare, senza copiare frasi: dai più peso ai "
              "video con risultato 'top' e views alte, e segnala cosa hanno di diverso i 'flop'. Scrivi in italiano. "
              "Rispondi SOLO con JSON:\n"
              '{"summary": "2-3 frasi: che tipo di video sono e perché funzionano",'
              ' "hooks": ["5-8 tipi di apertura dei primi 2 secondi, descritti come schema (es. \\"Problema diretto: ...\\")"],'
              ' "structure": [{"beat": "nome del passaggio", "share": 0.15, "what": "cosa succede e cosa si dice"}],'
              ' "pacing": {"length_sec": 30, "scene_sec": 2.0, "words_per_sec": 2.6, "notes": "ritmo, pause, cambi"},'
              ' "visuals": ["che tipo di immagini/inquadrature usano e quando cambiano"],'
              ' "cta": ["tipi di chiusura e invito all\'azione"],'
              ' "rules": ["regole di scrittura concrete: lunghezza frasi, tono, persona, parole"],'
              ' "avoid": ["cosa evitare (anche dai flop)"],'
              ' "examples": ["2 script ORIGINALI di esempio (argomento inventato), 60-120 parole, stessa struttura"]}')
    raw = ai.text(cfg, system, f"Tipo di video: {KINDS.get(fm.get('kind'))}. Obiettivo: {fm.get('goal') or '-'}\n\n{data}", max_tokens=8000, cancel=cancel)
    an = ai.parse_json(raw)
    return an, render_prompt(fm, an)


def render_prompt(fm, an):
    """Il formato in testo, pronto da mettere nelle istruzioni di chi scrive gli script (modificabile a mano)."""
    L = [f"FORMATO \"{fm.get('name')}\" — {KINDS.get(fm.get('kind'))}", an.get("summary") or ""]
    if an.get("hooks"):
        L += ["", "APERTURA (scegline una, varia sempre):"] + [f"- {x}" for x in an["hooks"]]
    if an.get("structure"):
        L += ["", "STRUTTURA:"] + [f"- {b.get('beat')} (~{round(float(b.get('share') or 0) * 100)}%): {b.get('what')}" for b in an["structure"] if isinstance(b, dict)]
    p = an.get("pacing") or {}
    if p:
        L += ["", f"RITMO: circa {p.get('length_sec')} secondi, una scena/visual ogni {p.get('scene_sec')} secondi, "
                  f"{p.get('words_per_sec')} parole al secondo. {p.get('notes') or ''}"]
    for key, lbl in (("visuals", "IMMAGINI"), ("cta", "CHIUSURA"), ("rules", "REGOLE"), ("avoid", "DA EVITARE")):
        if an.get(key):
            L += ["", lbl + ":"] + [f"- {x}" for x in an[key]]
    if an.get("examples"):
        L += ["", "ESEMPI DI STRUTTURA (non copiarli, sono solo modelli):"] + [f"---\n{x}" for x in an["examples"]]
    L += ["", "Scrivi sempre testi originali: prendi la struttura, mai le frasi. Non inventare risultati, numeri, recensioni o prezzi."]
    return "\n".join(L)


def scene_sec(fm):
    try:
        v = float(((fm.get("analysis") or {}).get("pacing") or {}).get("scene_sec") or 0)
    except (TypeError, ValueError):
        return None
    return max(1.0, min(6.0, v)) if v else None
