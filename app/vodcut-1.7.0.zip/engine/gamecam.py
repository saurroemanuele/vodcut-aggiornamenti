"""Live di gaming con una o piu' webcam: dove sono i riquadri delle webcam in una clip e quale e' quello dello streamer.

Serve per le clip verticali "webcam sopra e gioco sotto". Nelle live di gaming capita spesso che oltre alla webcam
dello streamer ci siano altre webcam dentro il gioco (la cam del pro che si guarda in una watch party, un compagno di
squadra, un ospite): non e' una chiamata, e' gaming. E il riquadro della webcam deve essere quello vero, intero, con i
suoi bordi (anche quando sta attaccato all'angolo del video), non solo la faccia.

Come si capisce, su una dozzina di fotogrammi sparsi nella clip:
- una webcam e' una faccia che resta sempre nello stesso punto, dentro un riquadro con lo sfondo fermo;
- il gioco intorno invece cambia di continuo (la telecamera del gioco si muove);
- il bordo vero del riquadro e' una linea lunga e netta in tutti i fotogrammi con dentro roba ferma e fuori roba che
  cambia (una mensola o lo spigolo di un muro dentro la webcam hanno roba ferma da tutte e due le parti).
Le funzioni lavorano su immagini gia' lette (BGR) e sulle facce gia' trovate: si provano anche senza video.
"""
import numpy as np

MAP_W = 480          # le mappe (cosa cambia, bordi fermi) si fanno a questa larghezza
EDGE_T = 15.0        # forza minima di un bordo (Sobel su grigi 0..255)
DYN_T = 22.0         # sopra: un punto che cambia tra un fotogramma e l'altro (gioco); sotto: fermo (sfondo della webcam)


def maps(frames):
    """Mappe della clip: S = quanto cambia ogni punto tra i fotogrammi (deviazione dei grigi), PGX/PGY = bordi verticali e
    orizzontali presenti in quasi tutti i fotogrammi (30 percentile). Tutto a MAP_W di larghezza."""
    import cv2
    h0, w0 = frames[0].shape[:2]
    mw, mh = MAP_W, max(2, int(round(MAP_W * h0 / w0)))
    gs = np.stack([cv2.resize(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (mw, mh), interpolation=cv2.INTER_AREA).astype(np.float32) for f in frames])
    S = gs.std(axis=0)
    gx = np.stack([np.abs(cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)) for g in gs])
    gy = np.stack([np.abs(cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)) for g in gs])
    q = 30 if len(frames) >= 6 else 0
    return {"S": S, "PGX": np.percentile(gx, q, axis=0), "PGY": np.percentile(gy, q, axis=0), "w": mw, "h": mh, "k": mw / float(w0)}


def face_clusters(faces, n_frames, W):
    """Le facce che restano nello stesso punto (le persone nelle webcam). faces: per ogni fotogramma [(x, y, w, h)] in
    pixel dell'immagine larga W. -> [{"cx", "cy", "fw", "n", "pres"}] dalla piu' presente."""
    cl = []
    for fi, fs in enumerate(faces):
        for (x, y, w, h) in fs or []:
            if w < W * 0.018:
                continue
            cx, cy = x + w / 2.0, y + h / 2.0
            best = None
            for c in cl:
                mfw = float(np.median(c["w"]))
                if abs(np.median(c["x"]) - cx) < 1.6 * max(mfw, w) and abs(np.median(c["y"]) - cy) < 1.6 * max(mfw, w) \
                        and 0.55 < w / max(1.0, mfw) < 1.8:
                    best = c
                    break
            if best is None:
                cl.append({"x": [cx], "y": [cy], "w": [w], "f": {fi}})
            elif fi not in best["f"]:
                best["x"].append(cx); best["y"].append(cy); best["w"].append(w); best["f"].add(fi)
    out = []
    for c in cl:
        n = len(c["f"])
        xs, ys = np.array(c["x"]), np.array(c["y"])
        fw = float(np.median(c["w"]))
        # una webcam: la faccia si sposta poco (lo streamer sulla sedia); i visi nel gioco vanno e vengono ovunque
        spread = float(max(np.percentile(np.abs(xs - np.median(xs)), 80), np.percentile(np.abs(ys - np.median(ys)), 80))) if n > 1 else 0.0
        out.append({"cx": float(np.median(xs)), "cy": float(np.median(ys)), "fw": fw, "n": n,
                    "pres": n / float(max(1, n_frames)), "spread": spread / max(1.0, fw)})
    return sorted(out, key=lambda c: -c["n"])


def _line_score(P, S, pos, lo, hi, vertical, inside_before, strip=(2, 6)):
    """Quanto la linea a pos (colonna se vertical, riga se no) e' il bordo di un riquadro con dentro roba ferma e fuori
    roba che cambia. lo..hi: le righe (o colonne) lungo cui misurarla. inside_before: il riquadro sta prima della linea
    (a sinistra o sopra). -> (punteggio 0..1, presenza del bordo 0..1, contrasto 0..1)"""
    n = P.shape[1] if vertical else P.shape[0]
    if hi - lo < 4 or pos < 1 or pos > n - 2:
        return 0.0, 0.0, 0.0
    a, b = strip
    if vertical:
        band = P[lo:hi, max(0, pos - 1):pos + 2].max(axis=1)
        s_before = S[lo:hi, max(0, pos - b):max(1, pos - a)]
        s_after = S[lo:hi, min(n - 1, pos + a):min(n, pos + b)]
    else:
        band = P[max(0, pos - 1):pos + 2, lo:hi].max(axis=0)
        s_before = S[max(0, pos - b):max(1, pos - a), lo:hi]
        s_after = S[min(n - 1, pos + a):min(n, pos + b), lo:hi]
    sup = float((band > EDGE_T).mean())
    if s_before.size == 0 or s_after.size == 0:
        return 0.0, sup, 0.0
    si, so = (float(s_before.mean()), float(s_after.mean())) if inside_before else (float(s_after.mean()), float(s_before.mean()))
    con = max(0.0, (so - si) / (so + si + 4.0))
    return sup * min(1.0, con * 2.2), sup, con


BORDER_SCORE = 0.22   # il bordo del video come lato del riquadro (webcam attaccata all'angolo): vale se non c'e' di meglio


def _best_line(M, cands, lo, hi, vertical, inside_before, border):
    P = M["PGX"] if vertical else M["PGY"]
    best = (BORDER_SCORE, border) if border is not None else (0.0, None)
    for p in cands:
        sc, sup, con = _line_score(P, M["S"], p, lo, hi, vertical, inside_before)
        # a parita' di punteggio il bordo piu' lontano dalla faccia (dentro la webcam ci sono altre linee, piu' deboli)
        if sc > best[0] + 0.02:
            best = (sc, p)
    return best


def find_rect(M, cx, cy, fw):
    """Il riquadro della webcam attorno alla faccia (cx, cy, larga fw), in coordinate delle mappe.
    -> ([x0, y0, x1, y1], qualita' 0..1) o (None, 0)."""
    mw, mh = M["w"], M["h"]
    fw = max(4.0, fw)
    xl = (int(max(0, cx - 10 * fw)), int(cx - 0.8 * fw))
    xr = (int(cx + 0.8 * fw), int(min(mw - 1, cx + 10 * fw)))
    yt = (int(max(0, cy - 6 * fw)), int(cy - 0.9 * fw))
    yb = (int(cy + 1.0 * fw), int(min(mh - 1, cy + 8 * fw)))
    r0, r1 = int(max(0, cy - 1.0 * fw)), int(min(mh, cy + 2.2 * fw))
    sides = {}
    for _ in range(2):
        L = _best_line(M, range(max(1, xl[0]), max(1, xl[1])), r0, r1, True, False, 0 if xl[0] <= 1 else None)
        R = _best_line(M, range(xr[0], min(mw - 1, xr[1])), r0, r1, True, True, mw if xr[1] >= mw - 2 else None)
        if L[1] is None or R[1] is None:
            return None, 0.0
        c0, c1 = int(L[1]) + 2, int(R[1]) - 2
        T = _best_line(M, range(max(1, yt[0]), max(1, yt[1])), c0, c1, False, False, 0 if yt[0] <= 1 else None)
        B = _best_line(M, range(yb[0], min(mh - 1, yb[1])), c0, c1, False, True, mh if yb[1] >= mh - 2 else None)
        if T[1] is None or B[1] is None:
            return None, 0.0
        sides = {"l": L, "r": R, "t": T, "b": B}
        r0, r1 = int(T[1]) + 2, int(B[1]) - 2
    x0, x1, y0, y1 = sides["l"][1], sides["r"][1], sides["t"][1], sides["b"][1]
    if x1 - x0 < 2.2 * fw or y1 - y0 < 2.0 * fw:
        return None, 0.0
    # qualita': quanti lati sono bordi veri (o il bordo del video) e quanto sono netti
    q = float(np.mean([min(1.0, s[0] / 0.45) for s in sides.values()]))
    return [int(x0), int(y0), int(x1), int(y1)], round(q, 3)


def analyze(frames, faces, ref_box=None, ref_size=None):
    """frames: fotogrammi BGR della clip (stessa grandezza); faces: per ogni fotogramma [(x, y, w, h)] in pixel di quei
    fotogrammi; ref_box: il riquadro webcam trovato su tutta la live ([x, y, w, h] su ref_size = (W, H)) per scegliere la
    webcam dello streamer quando ce ne sono piu' di una.
    -> {"gaming": bool, "cams": [{"box": [x, y, w, h] (0..1), "q", "pres", "face": [cx, cy, fw] (0..1)}], "main": indice o None,
        "dyn": parte del resto che cambia, "why": spiegazione breve}"""
    out = {"gaming": False, "cams": [], "main": None, "dyn": 0.0, "why": ""}
    if not frames or len(frames) < 4:
        out["why"] = "pochi fotogrammi"
        return out
    H, W = frames[0].shape[:2]
    M = maps(frames)
    k = M["k"]
    cls = face_clusters(faces, len(frames), W)
    big_out = [c for c in cls if c["pres"] >= 0.3 and c["fw"] >= 0.12 * W]
    cams = []
    for c in cls:
        if c["pres"] < 0.4 or c["spread"] > 1.2:
            continue
        r, q = find_rect(M, c["cx"] * k, c["cy"] * k, c["fw"] * k)
        if r is None or q < 0.35:
            continue
        x0, y0, x1, y1 = r
        bw, bh = (x1 - x0) / M["w"], (y1 - y0) / M["h"]
        ar = (x1 - x0) / max(1.0, y1 - y0)
        if bw * bh > 0.45 or not (0.5 < ar < 3.2):
            continue
        # la stessa webcam trovata da due facce (due persone nella stessa cam): una volta sola
        if any(abs(x0 / M["w"] - e["box"][0]) < 0.03 and abs(y0 / M["h"] - e["box"][1]) < 0.03 and abs(bw - e["box"][2]) < 0.04 for e in cams):
            continue
        cams.append({"box": [round(x0 / M["w"], 4), round(y0 / M["h"], 4), round(bw, 4), round(bh, 4)], "q": q, "pres": round(c["pres"], 3),
                     "face": [round(c["cx"] / W, 4), round(c["cy"] / H, 4), round(c["fw"] / W, 4)]})
    out["cams"] = cams
    if not cams:
        out["why"] = "nessuna webcam con i bordi"
        return out
    # il resto dell'immagine (fuori dalle webcam): gioco che cambia o scena ferma?
    mask = np.ones((M["h"], M["w"]), bool)
    for c in cams:
        x, y, w, h = c["box"]
        mask[int(y * M["h"]):int(np.ceil((y + h) * M["h"])), int(x * M["w"]):int(np.ceil((x + w) * M["w"]))] = False
    rest = M["S"][mask]
    dyn = float((rest > DYN_T).mean()) if rest.size else 0.0
    out["dyn"] = round(dyn, 3)
    area = sum(c["box"][2] * c["box"][3] for c in cams)
    inside = lambda c, f: c["box"][0] <= f["cx"] / W <= c["box"][0] + c["box"][2] and c["box"][1] <= f["cy"] / H <= c["box"][1] + c["box"][3]   # noqa: E731
    big_free = [f for f in big_out if not any(inside(c, f) for c in cams)]
    if big_free:
        out["why"] = "una persona grande fuori dalle webcam"
    elif area > 0.45 or max(c["box"][2] * c["box"][3] for c in cams) > 0.3:
        out["why"] = "riquadri grandi (chiamata o podcast)"
    elif dyn < 0.25:
        out["why"] = "fuori dalle webcam e' tutto fermo (non e' un gioco)"
    else:
        out["gaming"] = True
        out["why"] = "gioco con %d webcam" % len(cams)
    # la webcam dello streamer: quella dove sta il riquadro trovato su tutta la live; se no la piu' presente e grande
    main = None
    if ref_box and ref_size:
        rx, ry, rw, rh = [float(v) for v in ref_box]
        RW, RH = float(ref_size[0]), float(ref_size[1])
        pcx, pcy = (rx + rw / 2) / RW, (ry + rh / 2) / RH
        for i, c in enumerate(cams):
            x, y, w, h = c["box"]
            if x <= pcx <= x + w and y <= pcy <= y + h:
                main = i
                break
    if main is None:
        main = max(range(len(cams)), key=lambda i: (cams[i]["pres"] >= 0.7, cams[i]["q"] * cams[i]["pres"] * (cams[i]["box"][2] * cams[i]["box"][3]) ** 0.5))
    out["main"] = main
    return out


def cam_h_for(box, lo=0.27, hi=0.45):
    """Altezza della fascia della webcam nel verticale (0..1) per mostrarla intera: la fascia ha le proporzioni del
    riquadro (box [x, y, w, h] in pixel della live; una webcam 16:9 -> ~0.32 dello schermo, come i clipper di gaming)."""
    ar = float(box[2]) / max(1.0, float(box[3]))
    return round(max(lo, min(hi, (9.0 / 16.0) / max(0.3, ar))), 3)
