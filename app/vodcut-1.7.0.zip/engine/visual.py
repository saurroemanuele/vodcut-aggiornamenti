"""Cosa si vede in un fotogramma senza persone da seguire: una visual inserita nel video (immagine, articolo,
schermata, video verticale del telefono) appoggiata su uno sfondo, una grafica piatta o una scena vera.

Nei video lunghi montati (interviste, podcast con le "visual") le immagini spesso stanno in un riquadro al centro,
su uno sfondo scuro o di un colore solo. Nel verticale quel riquadro va mostrato lui: grande, intero o a tutto
schermo, mai ritagliato a caso come se fosse una persona (le facce dentro una foto o un articolo non parlano).
Tutto su un fotogramma BGR (numpy), qualsiasi grandezza; i risultati sono in 0..1 del fotogramma.
"""
import numpy as np

_W = 320            # le analisi si fanno su un fotogramma largo 320 px (veloce, e le visual sono grandi)


def _small(img, w=_W):
    import cv2
    H, W = img.shape[:2]
    if W <= w:
        return img
    return cv2.resize(img, (w, max(2, int(round(w * H / W)))), interpolation=cv2.INTER_AREA)


def inset_box(img):
    """La visual appoggiata su uno sfondo, se il fotogramma e' fatto cosi': (x, y, w, h) in 0..1, se no None.
    Sfondo = la cornice del fotogramma tutta dello stesso colore (anche con puntini o particelle attorno);
    visual = quello che lo sfondo racchiude: un riquadro staccato dai bordi (un'immagine, una scheda di YouTube, una
    foto scontornata con i nomi), o un rettangolo pieno che entra da un lato (un articolo che esce dal fondo)."""
    import cv2
    sm = _small(img)
    h, w = sm.shape[:2]
    if h < 40 or w < 40:
        return None
    lab = cv2.cvtColor(cv2.medianBlur(sm, 3), cv2.COLOR_BGR2LAB).astype(np.float32)
    b = max(2, int(round(0.03 * h)))
    sides = [lab[:b].reshape(-1, 3), lab[-b:].reshape(-1, 3), lab[:, :b].reshape(-1, 3), lab[:, -b:].reshape(-1, 3)]
    bg = np.median(np.concatenate(sides), axis=0)
    # almeno tre lati del fotogramma dello stesso colore (il quarto puo' essere toccato dalla visual)
    uni = sorted(float((np.abs(s - bg).max(axis=1) < 20).mean()) for s in sides)
    if uni[1] < 0.85:
        return None                         # la cornice non e' uno sfondo di un colore solo: e' una scena
    bgm = (np.abs(lab - bg).max(axis=2) <= 22).astype(np.uint8)
    # lo sfondo vero e' quello collegato ai bordi; i buchi scuri dentro la visual (chiusi dalla sua cornice) restano visual
    _, lbl = cv2.connectedComponents(bgm, connectivity=4)     # 0 = non sfondo, 1.. = pezzi di sfondo
    ring_l = np.concatenate([lbl[0], lbl[-1], lbl[:, 0], lbl[:, -1]])
    outside = np.isin(lbl, np.unique(ring_l[ring_l > 0]))
    raw = (~outside).astype(np.uint8)
    # via particelle e puntini sparsi (piccoli in tutte le direzioni); restano le zone piene e le linee lunghe (cornici)
    clean = (cv2.morphologyEx(raw, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)) |
             cv2.morphologyEx(raw, cv2.MORPH_OPEN, np.ones((1, 13), np.uint8)) |
             cv2.morphologyEx(raw, cv2.MORPH_OPEN, np.ones((13, 1), np.uint8)))
    k, cl, st, _ = cv2.connectedComponentsWithStats(clean, connectivity=8)
    if k <= 1:
        return None
    comps = sorted(((int(st[i, cv2.CC_STAT_AREA]), i) for i in range(1, k)), reverse=True)
    big = comps[0][0]
    keep = [i for a, i in comps if a >= 0.15 * big and a >= 0.01 * w * h]
    if not keep:
        return None
    x0 = min(int(st[i, 0]) for i in keep)
    y0 = min(int(st[i, 1]) for i in keep)
    x1 = max(int(st[i, 0] + st[i, 2]) for i in keep)
    y1 = max(int(st[i, 1] + st[i, 3]) for i in keep)
    bw, bh = x1 - x0, y1 - y0
    if bw < 8 or bh < 8:
        return None
    area = bw * bh / float(w * h)
    if not 0.03 <= area <= 0.88:
        return None
    # fuori dal riquadro (lasciando un margine per le particelle attorno): solo sfondo e puntini. Scritte, grafici,
    # altre immagini = la visual e' piu' grande di cosi' (es. un grafico con una foto piccola): niente riquadro
    pad_x, pad_y = int(0.06 * bw) + 2, int(0.06 * bh) + 2
    rest = raw.copy()
    rest[max(0, y0 - pad_y):y1 + pad_y, max(0, x0 - pad_x):x1 + pad_x] = 0
    nk, _, rst, _ = cv2.connectedComponentsWithStats(rest, connectivity=8)
    rest_px = sum(int(rst[i, cv2.CC_STAT_AREA]) for i in range(1, nk) if rst[i, cv2.CC_STAT_AREA] >= 12 and
                  max(rst[i, cv2.CC_STAT_WIDTH], rst[i, cv2.CC_STAT_HEIGHT]) >= 6)
    if rest_px > 0.012 * w * h:
        return None
    fill = float(clean[y0:y1, x0:x1].mean())
    mx, my = max(2, int(0.012 * w)), max(2, int(0.012 * h))
    touch = (x0 < mx) + (y0 < my) + (x1 > w - mx) + (y1 > h - my)
    if touch >= 2:
        return None                         # attaccata a due lati: e' la scena, non una visual
    if touch == 1:
        # entra da un lato: solo un rettangolo pieno (una persona davanti a un muro tocca il fondo ma non e' piena)
        if fill < 0.9:
            return None
    elif fill < 0.45:
        return None                         # sparsa: puntini, scritte qua e la'
    return (x0 / w, y0 / h, bw / w, bh / h)


def plain_border(img):
    """Quanto e' di un colore solo la cornice del fotogramma (il secondo lato meno uniforme dei quattro, 0..1):
    alto per le grafiche su uno sfondo (numeri, scritte, grafici animati), basso per le scene vere."""
    import cv2
    sm = _small(img)
    h, w = sm.shape[:2]
    lab = cv2.cvtColor(cv2.medianBlur(sm, 3), cv2.COLOR_BGR2LAB).astype(np.float32)
    b = max(2, int(round(0.03 * h)))
    sides = [lab[:b].reshape(-1, 3), lab[-b:].reshape(-1, 3), lab[:, :b].reshape(-1, 3), lab[:, -b:].reshape(-1, 3)]
    bg = np.median(np.concatenate(sides), axis=0)
    return sorted(float((np.abs(s - bg).max(axis=1) < 20).mean()) for s in sides)[1]


def is_graphic(img):
    """Fotogramma senza persone: e' una grafica (scritte, numeri, grafici su uno sfondo: si mostra intera) o una
    scena vera (una citta', un ufficio: si puo' ritagliare a tutto schermo)?"""
    return plain_border(img) >= 0.85 or flatness(img) >= 0.62


def flatness(img):
    """Quanto del fotogramma e' piatto (colore uniforme, niente dettagli): alto per grafiche, schermate e scritte,
    basso per le scene vere (persone, citta', uffici). 0..1"""
    import cv2
    g = cv2.cvtColor(_small(img), cv2.COLOR_BGR2GRAY).astype(np.float32)
    m = cv2.blur(g, (5, 5))
    sd = np.sqrt(np.maximum(0.0, cv2.blur(g * g, (5, 5)) - m * m))
    return float((sd < 3.0).mean())


def interest_x(img, a=9 / 16):
    """Dove guardare in una scena senza persone, per un ritaglio verticale alto quanto il video: il centro (0..1)
    della striscia con piu' dettagli (bordi), con una leggera preferenza per il centro dell'immagine."""
    import cv2
    sm = _small(img)
    h, w = sm.shape[:2]
    g = cv2.GaussianBlur(cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY), (3, 3), 0).astype(np.float32)
    e = np.abs(cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)) + np.abs(cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3))
    col = e.mean(axis=0)
    cw = max(2, int(round(min(w, h * a))))
    if cw >= w:
        return 0.5
    cs = np.concatenate([[0.0], np.cumsum(col)])
    win = cs[cw:] - cs[:-cw]                 # dettagli dentro il ritaglio, per ogni posizione
    xs = (np.arange(len(win)) + cw / 2) / w
    sc = win / (win.max() + 1e-6) - 0.35 * np.abs(xs - 0.5)
    return round(float(xs[int(np.argmax(sc))]), 3)
