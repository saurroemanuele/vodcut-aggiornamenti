// NoonFrame - "Il tuo abbonamento" (pagamenti 2.0): piano, rinnovo, metodo di pagamento, fatture e disdetta, dentro il
// tool. Dati e azioni arrivano dal server dei pagamenti (Stripe); per cambiare carta si apre la pagina sicura di Stripe in
// una finestra NoonFrame. Qui non passa nessun dato della carta: solo il circuito e le ultime 4 cifre.
import { post, h, icon, toast, confirmBox } from './lib.js';
import { LANG, locale, byLang } from './i18n.js';

const eur = (cents) => { const n = +cents || 0, v = (Math.abs(n) / 100).toFixed(2), m = n < 0 ? '−' : ''; return LANG === 'en' ? m + '€' + v : m + v.replace('.', ',') + ' €'; };
const day = (ms, year) => { try { return new Date(ms).toLocaleDateString(locale(), year ? { day: 'numeric', month: 'short', year: 'numeric' } : { day: 'numeric', month: 'long' }); } catch (e) { return ''; } };
const kids = (...a) => a.flat().filter((x) => x != null && x !== false && x !== '');
const PLAN = (id) => String(id || '').charAt(0).toUpperCase() + String(id || '').slice(1);
const BRAND = { visa: 'Visa', mastercard: 'Mastercard', amex: 'American Express', maestro: 'Maestro', discover: 'Discover', jcb: 'JCB', unionpay: 'UnionPay', diners: 'Diners' };

let current = null;
// portal: abbonamento vecchio che si gestisce ancora dalla pagina del pagamento (nel browser, come prima)
export function openSubscription(portal) {
  if (current) return;
  const body = h('div', { class: 'sb-body' }, h('div', { class: 'sb-load' }, h('div', { class: 'spinner' })));
  const bg = h('div', { class: 'nfs-bg' });
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.modal-bg')) { e.stopPropagation(); close(); } };
  // tornando alla finestra dopo il cambio carta (pagina di Stripe in un'altra finestra) i dati si rileggono
  const onFocus = () => { if (waitCard) { waitCard = false; load(); } };
  let waitCard = false, data = null;
  function close() { removeEventListener('keydown', onKey, true); removeEventListener('focus', onFocus); bg.remove(); current = null; }
  addEventListener('keydown', onKey, true);
  addEventListener('focus', onFocus);
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  bg.append(h('div', { class: 'nfs nuovo sb', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Il tuo abbonamento' },
    h('div', { class: 'nfs-head' }, h('span', { class: 'nfs-hic' }, icon('card', 19, 'var(--tx)', 1.6)),
      h('span', { class: 'nfs-ht' }, h('b', null, 'Il tuo abbonamento'), h('span', null, 'Piano, metodo di pagamento e fatture')),
      h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Chiudi', onclick: close }, icon('x', 13, 'currentColor', 2))),
    body));
  document.body.append(bg);
  current = { close };
  load();

  async function load() {
    try { data = await post('/api/ai/sub', {}); } catch (e) { paintErr(e.message); return; }
    paint();
  }
  function paintErr(msg) {
    body.replaceChildren(h('div', { class: 'sb-empty-box' }, icon('alert', 22, 'var(--err)', 1.8), h('b', null, 'Abbonamento non disponibile'), h('span', null, msg),
      h('button', { type: 'button', class: 'sb-btn', onclick: () => { body.replaceChildren(h('div', { class: 'sb-load' }, h('div', { class: 'spinner' }))); load(); } }, 'Riprova')));
  }
  const toPlans = () => { close(); dispatchEvent(new CustomEvent('nf-nav', { detail: ['credits', null, 'plans'] })); };

  function paint() {
    const s = data && data.sub;
    if (!s) {
      body.replaceChildren(h('div', { class: 'sb-empty-box' }, icon('card', 22, 'var(--t2)', 1.6),
        h('b', null, 'Non hai un abbonamento attivo'),
        h('span', null, data && data.portal ? 'Il tuo abbonamento si gestisce dalla pagina del pagamento.' : 'Con un piano hai i crediti ogni mese, l\'Assistente AI e le Clip veloci senza logo.'),
        data && data.portal ? h('button', { type: 'button', class: 'sb-btn', onclick: () => { close(); if (portal) portal(); } }, 'Apri la pagina del pagamento')
          : h('button', { type: 'button', class: 'nfs-go', onclick: toPlans }, 'Vedi i piani')));
      return;
    }
    const per = s.period === 'year' ? byLang({ it: '/anno', en: '/year', fr: '/an', de: '/Jahr', pt: '/ano', es: '/año' }) : byLang({ it: '/mese', en: '/month', fr: '/mois', de: '/Monat', pt: '/mês', es: '/mes' });
    const late = s.status === 'past_due';
    const pill = s.cancelAtEnd ? h('span', { class: 'sb-pill warn' }, 'Disdetto') : late ? h('span', { class: 'sb-pill bad' }, 'Pagamento in ritardo') : h('span', { class: 'sb-pill' }, 'Attivo');
    const note = s.cancelAtEnd ? 'Resta attivo fino al ' + day(s.endsAt) + ', poi torni al piano gratuito e non paghi più niente.'
      : late ? 'L\'ultimo rinnovo non è andato a buon fine: aggiorna il metodo di pagamento, Stripe riprova da solo.'
        : 'Si rinnova da solo il ' + day(s.renewsAt) + '. Disdici quando vuoi.';
    const plan = h('div', { class: 'sb-card' },
      h('div', { class: 'sb-top' }, h('span', { class: 'sb-name', 'data-notr': '' }, PLAN(s.plan)), pill, s.test ? h('span', { class: 'sb-pill test' }, 'Prova') : null,
        h('span', { class: 'sb-price tnum' }, eur(s.priceCents) + per)),
      h('span', { class: 'sb-note' }, note),
      h('div', { class: 'sb-acts' }, h('button', { type: 'button', class: 'linkish', onclick: toPlans }, 'Cambia piano')));

    const pm = data.pm;
    const pmText = !pm ? 'Nessun metodo di pagamento salvato'
      : pm.type === 'card' ? (BRAND[pm.brand] || PLAN(pm.brand) || 'Carta') + ' •••• ' + pm.last4
        : pm.type === 'paypal' ? 'PayPal' : PLAN(pm.type);
    const pmSub = pm && pm.type === 'card' && pm.exp ? 'Scade ' + pm.exp : pm && pm.type === 'paypal' ? pm.email : '';
    const cardBtn = h('button', { type: 'button', class: 'sb-btn', onclick: async () => {
      cardBtn.disabled = true;
      try {
        const r = await post('/api/ai/sub/card', {});
        waitCard = true;
        toast(r.window ? 'Cambia il metodo di pagamento nella finestra sicura di Stripe' : 'Cambia il metodo di pagamento nella pagina che si è aperta nel browser');
      } catch (e) { toast(e.message, true); }
      cardBtn.disabled = false;
    } }, 'Cambia');
    const pay = h('div', { class: 'sb-card' },
      h('div', { class: 'sb-row' }, h('span', { class: 'ic' }, icon('card', 17, 'currentColor', 1.7)),
        h('span', { class: 'tx' }, h('small', null, 'Metodo di pagamento'), h('b', { 'data-notr': '' }, pmText), pmSub ? h('small', { 'data-notr': pm.type === 'paypal' ? '' : null }, pmSub) : null),
        cardBtn),
      h('span', { class: 'sb-safe' }, icon('lock', 11, 'currentColor', 2), 'Gestito da Stripe: i dati della carta non passano da NoonFrame'));

    const STAT = { paid: ['Pagata', ''], open: ['Da pagare', 'warn'], uncollectible: ['Non pagata', 'bad'] };
    const inv = (data.invoices || []).map((x) => {
      // fattura negativa (si scende di piano): e' credito sui prossimi rinnovi, non un pagamento
      const st = x.cents < 0 ? ['Credito', ''] : STAT[x.status] || [x.status, ''];
      const dl = x.pdf ? h('button', { type: 'button', class: 'linkish', onclick: async () => {
        dl.disabled = true;
        try { await post('/api/ai/invoice', { url: x.pdf, name: x.number || new Date(x.date).toISOString().slice(0, 10) }); toast('Fattura salvata in Download'); } catch (e) { toast(e.message, true); }
        dl.disabled = false;
      } }, icon('download', 13, 'currentColor', 2), 'Scarica') : null;
      return h('div', null, h('span', { class: 'd' }, day(x.date, true)), h('span', { class: 'a tnum' }, eur(x.cents)), h('span', { class: 'sb-pill sm ' + st[1] }, st[0]), dl);
    });

    const foot = s.cancelAtEnd
      ? h('div', { class: 'sb-foot' }, h('span', { class: 'grow' }), h('button', { type: 'button', class: 'nfs-go', onclick: (e) => act(e.currentTarget, 'resume') }, 'Riattiva l\'abbonamento'))
      : h('div', { class: 'sb-foot' }, h('span', { class: 'grow' }), h('button', { type: 'button', class: 'sb-stop', onclick: (e) => act(e.currentTarget, 'cancel') }, 'Disdici l\'abbonamento'));

    body.replaceChildren(...kids(plan, pay, h('div', { class: 'sb-lab' }, 'Fatture'),
      inv.length ? h('div', { class: 'sb-inv' }, ...inv) : h('div', { class: 'sb-empty' }, 'Ancora nessuna fattura'), foot));
  }

  async function act(btn, what) {
    const s = data.sub;
    if (what === 'cancel' && !(await confirmBox('Disdire l\'abbonamento?',
      'Resta attivo fino al ' + day(s.renewsAt) + ': fino ad allora puoi usare tutto, crediti compresi. Poi torni al piano gratuito e non paghi più niente.', 'Disdici', true))) return;
    btn.disabled = true;
    try {
      const r = await post('/api/ai/sub/' + what, {});
      toast(what === 'cancel' ? 'Abbonamento disdetto: resta attivo fino al ' + day(r.endsAt || s.renewsAt) : 'Abbonamento riattivato: si rinnova da solo');
      // il piano nel resto dell'app si aggiorna quando Stripe conferma (qualche secondo)
      setTimeout(() => dispatchEvent(new CustomEvent('nf-credits-changed')), 4000);
      await load();
    } catch (e) { toast(e.message, true); btn.disabled = false; }
  }
}
