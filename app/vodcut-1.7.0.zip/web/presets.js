// Pagina Preset: uno stile per ogni pagina (titolo d'apertura, sottotitoli, badge social). Quello predefinito vale per le
// clip nuove. Piu' avanti ogni preset si collega a una pagina social (TikTok, Instagram, YouTube) per pubblicare le clip
// in automatico con il suo stile: il campo "pages" del preset e' gia' qui per quello (per ora sempre vuoto).
import { h, post, icon, toast, confirmBox, promptBox, costText } from './lib.js';
import { loadLook, setLookCache, defaultLook, hookStyle, lookThumb } from './clipstyle.js';
import { t as tx } from './i18n.js';

const MAX = 40;   // come il server (clipPresets)
const clone = (x) => JSON.parse(JSON.stringify(x));
const newId = () => 'st' + Math.random().toString(36).slice(2, 9);
const WORDS = { parola: '1 parola', due: '2 parole', tre: '3 parole', frase: 'Frase intera' };
const styleOf = (p) => { const d = defaultLook(); return { hook: { ...d.hook, ...(p.hook || {}) }, subs: { ...d.subs, ...(p.subs || {}) }, badge: { ...d.badge, ...(p.badge || {}) } }; };

// lo stile attivo diventa sempre un preset (prima era solo "Il mio stile"): cosi' si vede tra gli altri.
// -> { look, presets, pending }: pending = mai salvato (stile di base), si salva quando lo usi o lo cambi
async function ensurePresets() {
  const st = await loadLook(true);
  const look = clone(st.look), presets = clone(st.presets || []);
  let pending = false;
  if (!presets.some((p) => p.id === look.preset)) {
    const id = newId();
    presets.unshift({ id, name: tx('Il mio stile'), hook: clone(look.hook), subs: clone(look.subs), badge: clone(look.badge), pages: [], at: Date.now() });
    look.preset = id;
    if (st.saved) { await post('/api/cliplook', { look, presets }); setLookCache(look, presets); } else pending = true;
  }
  return { look, presets, pending };
}

// ctx: { edit(id): apre il preset, onSide(): ridisegna la barra laterale }
export function presetsPage(ctx) {
  const S = { look: null, presets: [], pending: false };
  const count = h('span', { class: 'pp-cnt' });
  const newBtn = h('button', { type: 'button', class: 'btn primary ps-new', onclick: () => run(create)() }, icon('plus', 14, '#fff', 2.2), 'Nuovo preset');
  const head = h('header', { class: 'pp-head' }, h('div', { class: 'pp-crumb' }, h('span', null, 'Preset'), count), h('div', { class: 'grow' }), newBtn);
  const body = h('div', { class: 'pp-body' });
  const root = h('div', { class: 'pp ps-list' }, head, body);
  const run = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

  async function save(look, presets) {
    await post('/api/cliplook', { look, presets });
    setLookCache(look, presets);
    S.look = clone(look); S.presets = clone(presets);
    if (ctx.onSide) ctx.onSide();   // nella barra a sinistra il nome del preset predefinito
  }
  async function load() {
    const st = await ensurePresets();
    S.look = st.look; S.presets = st.presets; S.pending = st.pending;
    paint();
    if (ctx.onSide) ctx.onSide();
  }
  const isDef = (p) => p.id === S.look.preset;
  const open = async (id) => { if (S.pending) { await save(S.look, S.presets); S.pending = false; } ctx.edit(id); };

  async function create() {
    if (S.presets.length >= MAX) { toast('Puoi avere al massimo ' + MAX + ' preset', true); return; }
    const nm = ((await promptBox('Nuovo preset', 'Per esempio il nome della pagina: ogni pagina può avere il suo stile.', '', 'Crea')) || '').trim();
    if (!nm) return;
    const base = S.presets.find(isDef) || {};
    const p = { id: newId(), name: nm.slice(0, 40), ...clone(styleOf(base)), pages: [], at: Date.now() };
    await save(S.look, [...S.presets, p]);
    S.pending = false;
    ctx.edit(p.id);
  }
  async function makeDefault(p) {
    await save({ ...S.look, ...clone(styleOf(p)), preset: p.id }, S.presets);
    toast('Le prossime clip escono con «' + p.name + '»');
    paint();
  }
  async function duplicate(p) {
    if (S.presets.length >= MAX) { toast('Puoi avere al massimo ' + MAX + ' preset', true); return; }
    const i = S.presets.indexOf(p);
    const cp = { ...clone(p), id: newId(), name: (p.name + ' ' + tx('(copia)')).slice(0, 40), pages: [], at: Date.now() };
    const list = [...S.presets]; list.splice(i + 1, 0, cp);
    await save(S.look, list);
    toast('Preset duplicato');
    paint();
  }
  async function rename(p) {
    const nm = ((await promptBox('Rinomina il preset', null, p.name, 'Rinomina')) || '').trim();
    if (!nm || nm === p.name) return;
    await save(S.look, S.presets.map((x) => (x.id === p.id ? { ...x, name: nm.slice(0, 40) } : x)));
    toast('Rinominato');
    paint();
  }
  // si puo' eliminare anche il predefinito: le clip nuove passano al primo preset rimasto (ne resta sempre almeno uno)
  async function remove(p) {
    const rest = S.presets.filter((x) => x.id !== p.id);
    if (!rest.length) { toast('Serve almeno un preset: creane un altro prima', true); return; }
    const next = isDef(p) ? rest[0] : null;
    const msg = next ? `«${p.name}» è il preset delle clip nuove: al suo posto userò «${next.name}». Le clip già fatte restano come sono.`
      : `«${p.name}» non sarà più tra i preset. Le clip già fatte restano come sono.`;
    if (!(await confirmBox('Eliminare il preset?', msg, 'Elimina', true))) return;
    await save(next ? { ...S.look, ...clone(styleOf(next)), preset: next.id } : S.look, rest);
    toast(next ? `Preset eliminato: ora le clip nuove usano «${next.name}»` : 'Preset eliminato');
    paint();
  }

  const qa = (ic, tip, fn, cls) => h('button', { type: 'button', class: cls || null, 'aria-label': tip, 'data-tip': tip, onclick: (e) => { e.stopPropagation(); run(fn)(); } }, icon(ic, 14, 'currentColor', 1.8));
  function card(p) {
    const st = styleOf(p), def = isDef(p);
    const cv = h('canvas', { width: '360', height: '640', class: 'ps-cv', 'aria-hidden': 'true' });
    lookThumb(st, cv).catch(() => { /* anteprima non pronta: resta lo sfondo */ });
    const only = S.presets.length < 2;
    const del = qa('trash', only ? 'Serve almeno un preset' : 'Elimina', () => remove(p), 'del');
    if (only) del.disabled = true;
    const bar = h('div', { class: 'pj-acts' }, qa('pen', 'Rinomina', () => rename(p)), qa('duplicate', 'Duplica', () => duplicate(p)), del);
    const hs = hookStyle(st.hook), b = st.badge;
    const pages = (p.pages || []).length;
    const el = h('div', { class: 'ps-card' + (def ? ' def' : ''), role: 'button', tabindex: '0', onclick: () => run(open)(p.id) },
      h('div', { class: 'ps-shot' }, cv, def ? h('span', { class: 'ps-tag' }, icon('check', 11, 'currentColor', 2.6), 'Predefinito') : null, bar),
      h('div', { class: 'ps-info' },
        h('b', { class: 'ps-nm', 'data-notr': '' }, p.name),
        h('span', { class: 'ps-sum' }, h('span', { 'data-notr': '' }, hs.font), h('span', null, '·'), h('span', null, WORDS[st.subs.words] || WORDS.tre),
          b.on ? h('span', null, '·') : null, b.on ? h('span', { 'data-notr': '' }, b.handle ? '@' + b.handle : b.platform) : null),
        // pagina social collegata (in arrivo): per ora solo il posto, senza funzioni finte
        h('span', { class: 'ps-social' + (pages ? ' on' : '') }, icon('link', 12, 'currentColor', 1.8),
          h('span', null, pages ? (pages === 1 ? '1 pagina collegata' : pages + ' pagine collegate') : 'Pagina social: in arrivo')),
        def ? h('span', { class: 'ps-def' }, 'Usato per le clip nuove')
          : h('button', { type: 'button', class: 'ps-use', onclick: (e) => { e.stopPropagation(); run(makeDefault)(p); } }, 'Usa per le clip nuove')));
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target === el) run(open)(p.id); });
    return el;
  }
  function paint() {
    count.textContent = String(S.presets.length);
    newBtn.disabled = S.presets.length >= MAX;
    body.replaceChildren(
      h('div', { class: 'ps-intro' }, icon('presets', 16, 'currentColor', 1.7),
        h('span', null, 'Uno stile per ogni pagina: titolo d\'apertura, sottotitoli e badge social. Quello predefinito vale per le clip nuove. Presto potrai collegare ogni preset a una pagina social e pubblicare le clip in automatico con il suo stile.')),
      h('div', { class: 'ps-grid' }, ...S.presets.map(card),
        h('button', { type: 'button', class: 'ps-card add', disabled: S.presets.length >= MAX ? true : null, onclick: () => run(create)() },
          h('span', { class: 'ps-add-ic' }, icon('plus', 18, 'currentColor', 2)), h('b', null, 'Nuovo preset'), h('span', null, 'Lo stile di un\'altra pagina'))));
  }
  run(load)();
  return root;
}

// ---------------------------------------------------------------- Clip veloci: con che stili escono le clip
// L'unico passaggio dopo il link: uno o piu' stili tra i tuoi preset e Auto (gli stili automatici dell'AI). Uno solo = tutte
// le clip con quello; piu' di uno = per ogni clip l'AI sceglie tra quelli e li usa tutti (cosi' li confronti).
// Ricorda l'ultima scelta ma chiede sempre. -> { ids: [...], name } o null
const PICK_KEY = 'nf.fc.styles';
// opts.cost: la risposta di /api/clipcost (una promessa): quanti crediti costano le clip, mostrato prima di partire
export async function pickPreset(opts = {}) {
  const st = await ensurePresets();
  const valid = (id) => id === 'auto' || st.presets.some((p) => p.id === id);
  let sel = [];
  try { const v = JSON.parse(localStorage.getItem(PICK_KEY) || '[]'); if (Array.isArray(v)) sel = v.filter(valid); } catch (e) { /* */ }
  if (!sel.length) sel = [st.look.preset];
  const nameOf = (id) => (id === 'auto' ? 'Auto' : (st.presets.find((x) => x.id === id) || {}).name || '');
  return new Promise((resolve) => {
    const grid = h('div', { class: 'pk-grid', role: 'group', 'aria-label': 'Stili delle clip' });
    const note = h('span', { class: 'pk-note', 'aria-live': 'polite' });
    // il costo: arriva dal server (durata del link letta senza scaricarlo); con piu' stili c'e' anche la scelta dello stile
    let cost = opts.cost ? undefined : null;
    const costEl = h('span', { class: 'pk-cost', 'aria-live': 'polite', hidden: !opts.cost });
    const paintCost = () => {
      if (cost === undefined) { costEl.replaceChildren(h('span', { class: 'spinner sm' }), h('span', null, 'Calcolo i crediti…')); return; }
      if (!cost || cost.error || !cost.credits) { costEl.hidden = true; return; }
      const n = cost.clips + (chosen().length > 1 ? cost.styles : 0);
      const low = cost.balance != null && cost.balance < n;
      costEl.hidden = false;
      costEl.classList.toggle('warn', low && !cost.perHour);
      // durata del link non letta: il costo di un'ora di video, per avere un'idea
      costEl.replaceChildren(icon('sparkle', 13, 'currentColor', 2),
        h('span', null, cost.perHour ? 'Circa ' + n + ' crediti per ogni ora di video.' : costText(n, cost.balance)),
        ...(low && !cost.perHour ? [h('button', { type: 'button', class: 'linkish', onclick: () => { done(null); dispatchEvent(new CustomEvent('nf-plans')); } }, 'Ricarica')] : []));
    };
    if (opts.cost) Promise.resolve(opts.cost).then((c) => { cost = c || null; paintCost(); }, () => { cost = null; paintCost(); });
    const go = h('button', { type: 'button', class: 'btn primary pk-go' }, icon('sparkle', 14, '#fff', 2.2), h('span', null, 'Crea le clip'));
    const bg = h('div', { class: 'modal-bg pk-bg' });
    const done = (v) => { removeEventListener('keydown', onKey, true); bg.remove(); resolve(v); };
    const onKey = (e) => {
      if (e.key === 'Escape') { e.stopPropagation(); done(null); }
      else if (e.key === 'Enter' && !(e.target && e.target.closest && e.target.closest('button'))) { e.preventDefault(); confirm(); }
    };
    // nell'ordine delle schede: Auto, poi i preset
    const chosen = () => ['auto', ...st.presets.map((x) => x.id)].filter((id) => sel.includes(id));
    async function confirm() {
      const ids = chosen();
      if (!ids.length) return;
      go.disabled = true;
      try {
        if (st.pending) { await post('/api/cliplook', { look: st.look, presets: st.presets }); setLookCache(st.look, st.presets); st.pending = false; }
      } catch (e) { toast(e.message, true); go.disabled = false; return; }
      try { localStorage.setItem(PICK_KEY, JSON.stringify(ids)); } catch (e) { /* */ }
      done({ ids, name: ids.length > 1 ? ids.length + ' stili' : nameOf(ids[0]) });
    }
    go.onclick = confirm;
    const thumb = (x, cls) => {
      const cv = h('canvas', { width: '360', height: '640', class: cls, 'aria-hidden': 'true' });
      lookThumb(styleOf(x), cv).catch(() => { /* anteprima non pronta: resta lo sfondo */ });
      return cv;
    };
    const card = (id, shot, name, sum, notr) => {
      const on = sel.includes(id);
      return h('button', {
        type: 'button', class: 'pk-card' + (on ? ' on' : '') + (id === 'auto' ? ' auto' : ''), role: 'checkbox', 'aria-checked': String(on),
        onclick: () => { sel = on ? sel.filter((x) => x !== id) : [...sel, id]; paint(); } },
      h('div', { class: 'pk-shot' }, shot, h('span', { class: 'pk-check' + (on ? ' on' : '') }, on ? icon('check', 12, '#fff', 2.8) : null)),
      h('b', { class: 'pk-nm', ...(notr ? { 'data-notr': '' } : {}) }, name), h('span', { class: 'pk-sum' }, sum));
    };
    // Auto: le anteprime dei tuoi preset a ventaglio, con la scintilla dell'AI
    const autoShot = () => h('div', { class: 'pk-auto' },
      h('div', { class: 'pk-fan n' + Math.min(3, st.presets.length) }, ...st.presets.slice(0, 3).map((x) => thumb(x, 'pk-mini'))),
      h('span', { class: 'pk-ai' }, icon('sparkle', 18, '#fff', 2)));
    const sumOf = (x) => { const s2 = styleOf(x); return h('span', null, h('span', { 'data-notr': '' }, hookStyle(s2.hook).font), ' · ', h('span', null, WORDS[s2.subs.words] || WORDS.tre)); };
    function paint() {
      grid.replaceChildren(card('auto', autoShot(), 'Auto', 'Gli stili automatici dell\'AI'),
        ...st.presets.map((x) => card(x.id, thumb(x, 'pk-cv'), x.name, sumOf(x), true)));
      const ids = chosen();
      go.disabled = !ids.length;
      note.classList.toggle('warn', !ids.length);
      note.textContent = !ids.length ? 'Scegli almeno uno stile'
        : ids.length > 1 ? ids.length + ' stili: l\'AI sceglie quello giusto per ogni clip'
          : ids[0] === 'auto' ? 'Tutte le clip con gli stili automatici' : 'Tutte le clip con «' + nameOf(ids[0]) + '»';
      paintCost();
    }
    paint();
    bg.append(h('div', { class: 'pk-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Con che stili escono le clip?' },
      h('div', { class: 'pk-head' }, h('h2', null, 'Con che stili escono le clip?'),
        h('p', null, 'Scegli uno o più stili. Con più stili l\'AI sceglie per ogni clip quello che le sta meglio e li usa tutti, così puoi confrontarli.')),
      grid,
      h('div', { class: 'pk-foot' }, h('div', { class: 'pk-left' }, costEl, note), h('button', { type: 'button', class: 'btn ghost', onclick: () => done(null) }, 'Annulla'), go)));
    bg.addEventListener('click', (e) => { if (e.target === bg) done(null); });
    addEventListener('keydown', onKey, true);
    document.body.append(bg);
    go.focus();
  });
}
