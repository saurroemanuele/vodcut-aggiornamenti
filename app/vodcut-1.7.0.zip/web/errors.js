// Rebrand 18a: ogni errore in una delle cinque forme del design, sempre con cosa fare dopo. I messaggi arrivano gia'
// scritti bene dal server (links.py, disco pieno, crediti...): qui si riconoscono per dare titolo, forma e azioni.
// Sotto il campo (link), striscia in alto (connessione), avviso in basso (un lavoro non riuscito), foglio al centro
// (serve una scelta: file sparito, disco pieno, crediti finiti). Niente codici tecnici: vanno in "Copia i dettagli".
import { h, icon, toast } from './lib.js';

const P = {
  link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1',
  warn: 'M12 3l10 18H2zM12 10v4M12 17h.01', lock: 'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3',
  wifi: 'M2 8.5a15 15 0 0 1 20 0M5.5 12a10 10 0 0 1 13 0M9 15.5a5 5 0 0 1 6 0M12 19h.01M3 3l18 18',
  file: 'M6 3h8l4 4v14H6zM14 3v4h4M9 13l6 6M15 13l-6 6', disk: 'M4 6h16v12H4zM4 14h16M8 17h.01',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4', clock: 'M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM12 7.5V12l3 2',
  credit: 'M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM12 7.5v9', subs: 'M3 6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM7 14h4M13 14h4M7 10h10',
  face: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 20a8 8 0 0 1 16 0', export: 'M12 15V4M7 9l5-5 5 5M5 20h14',
  ai: 'M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z', user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 20a8 8 0 0 1 16 0',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13', film: 'M3 6h13v12H3zM16 10l5-3v10l-5-3',
};
// [chiave, forma, icona, titolo, riconoscimento del messaggio]
const CASES = [
  ['notlink', 'inline', 'link', 'Non è un link', /non sembra un link|is not a valid url/i],
  ['channel', 'inline', 'link', 'È il link del canale', /porta al canale|canale o una playlist/i],
  ['private', 'inline', 'lock', 'Video privato', /privato o riservato/i],
  ['age', 'inline', 'lock', 'YouTube chiede l\'età', /confermare l'et/i],
  ['geo', 'inline', 'lock', 'Non disponibile nel tuo paese', /dal tuo paese/i],
  ['notstarted', 'inline', 'clock', 'La live non è ancora finita', /non (è|e') ancora iniziata/i],
  ['rate', 'inline', 'clock', 'Il sito sta rallentando', /limitando i download/i],
  ['bot', 'inline', 'shield', 'YouTube chiede una conferma', /non sei un bot/i],
  ['nolink', 'inline', 'link', 'Non trovo questo video', /Non trovo questo video|Kick non trova|non si scarica un video|video scaricabile|non ha lasciato scaricare/i],
  ['interrupted', 'toast', 'shield', 'Download interrotto', /antivirus o OneDrive/i],
  ['unreach', 'banner', 'wifi', 'Non riesco a raggiungere il sito.', /raggiungere il sito/i],
  ['offline', 'banner', 'wifi', 'La connessione si è interrotta.', /connessione si (è|e') interrotta|non risponde o la connessione/i],
  ['ssl', 'banner', 'shield', 'La connessione sicura non è riuscita.', /connessione sicura/i],
  ['disk', 'sheet', 'disk', 'Il disco è pieno', /disco( del computer)? (è|e') pieno/i],
  ['incomplete', 'sheet', 'film', 'Il video non è completo', /non (è|e') completo/i],
  ['missing', 'sheet', 'file', 'Non trovo più il video', /non si trova pi|File non trovato|Non trovo questo file|Non trovo più il video/i],
  ['locked', 'sheet', 'shield', 'Il file è bloccato', /usando il file|file (è|e') bloccato|in uso da un altro programma/i],
  ['deleted', 'sheet', 'trash', 'Questo progetto non c\'è più', /progetto non c'(e'|è) pi|Progetto non trovato/i],
  ['credits', 'sheet', 'credit', 'Crediti finiti', /Crediti NoonFrame finiti|crediti finiti|insufficient_credits/i],
  ['login', 'sheet', 'user', 'Accedi per usare l\'AI', /Accedi (al tuo account NoonFrame|a NoonFrame per usare)/i],
  ['subsfail', 'toast', 'subs', 'Sottotitoli non riusciti', /Trascrizione non riuscita|sottotitoli non (riusciti|riscritti)/i],
  ['facefail', 'toast', 'face', 'Non trovo una faccia da seguire', /nessuna faccia|non trovo (una|la) faccia|viso non trovato/i],
  ['aislow', 'toast', 'ai', 'L\'AI non risponde', /L'AI non ha risposto|AI non risponde|servizio AI/i],
  ['expfail', 'toast', 'export', 'Esportazione non riuscita', /Esportazione non riuscita|non riesco a esportare/i],
];
export function explain(msg) {
  const m = String(msg || '');
  const c = CASES.find((x) => x[4].test(m));
  return c ? { key: c[0], form: c[1], icon: c[2], title: c[3], text: m } : { key: 'generic', form: 'toast', icon: 'warn', title: 'Qualcosa non ha funzionato', text: m };
}
const svg = (k, size) => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.8');
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.innerHTML = '<path d="' + (P[k] || P.warn) + '"/>';
  return s;
};
export const errIcon = svg;

// "Copia i dettagli per il supporto": il messaggio con versione, ora e schermata (niente dati personali)
export async function copyDetails(msg, where) {
  const v = (window.VODCUT && window.VODCUT.version) || '';
  const txt = ['NoonFrame ' + v, new Date().toISOString(), where ? 'Schermata: ' + where : '', String(msg || '')].filter(Boolean).join('\n');
  try { await navigator.clipboard.writeText(txt); toast('Dettagli copiati: incollali nel messaggio al supporto'); return true; } catch (e) { return false; }
}
const go = (s, id) => window.dispatchEvent(new CustomEvent('nf-nav', { detail: [s, id] }));
// azioni di ogni caso quando non c'e' un contesto (avviso o foglio da qualunque punto dell'app)
function defaultActs(key) {
  switch (key) {
    case 'credits': return [['Ricarica o cambia piano', 'pri', () => window.dispatchEvent(new Event('nf-plans'))]];
    case 'login': return [['Accedi', 'pri', () => window.dispatchEvent(new Event('nuvora:login'))]];
    case 'deleted': return [['Apri il cestino', 'pri', () => go('projects', 'trash')], ['Torna ai progetti', '', () => go('projects')]];
    case 'missing': return [['Cerca il file', 'pri', () => window.dispatchEvent(new Event('nf-relink'))], ['Torna ai progetti', '', () => go('projects')]];
    case 'disk': return [['Ho liberato spazio', 'pri', null]];
    case 'locked': return [['Ho capito', 'pri', null]];
    case 'incomplete': return [['Ho capito', 'pri', null]];
    default: return [];
  }
}

// ---------------------------------------------------------------------------------------------- foglio al centro
let sheetKey = '';
export function showSheet(msg, opts = {}) {
  const ex = explain(msg);
  if (sheetKey === ex.key + ex.text) return;
  sheetKey = ex.key + ex.text;
  const bg = h('div', { class: 'nfs-bg er-bg' });
  const close = (acted) => { sheetKey = ''; bg.remove(); document.removeEventListener('keydown', onKey, true); if (acted !== true && opts.onDismiss) opts.onDismiss(); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  let acts = opts.acts || defaultActs(ex.key);
  if (!acts.some((a) => !a[2])) acts = acts.concat([['Chiudi', acts.length ? 'ghost' : 'pri', null]]);   // c'e' sempre un modo per chiudere
  const path = (String(msg).match(/[A-Za-z]:\\[^\n:*?"<>|]+\.\w{2,4}/) || [])[0];
  const copy = h('button', { type: 'button', class: 'er-copy', onclick: async () => { if (await copyDetails(opts.details || msg, opts.where)) copy.textContent = 'Dettagli copiati'; } }, 'Copia i dettagli per il supporto');
  bg.append(h('div', { class: 'nfs er-sheet', role: 'alertdialog', 'aria-modal': 'true', 'aria-label': ex.title },
    h('span', { class: 'er-ic' + (ex.key === 'credits' ? ' info' : '') }, svg(ex.icon, 24)),
    h('b', null, ex.title), h('p', null, ex.text),
    path ? h('code', { 'data-notr': '' }, path) : null,
    h('div', { class: 'er-acts' }, ...acts.map(([label, kind, fn]) =>
      h('button', { type: 'button', class: 'er-b ' + (kind || 'sec'), onclick: () => { close(!!fn); if (fn) fn(); } }, label))),
    copy));
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
  document.addEventListener('keydown', onKey, true);
  document.body.append(bg);
  return () => close(true);
}

// ---------------------------------------------------------------------------------------------- striscia in alto
let banner = null;
export function showBanner(title, text, retry) {
  hideBanner();
  banner = h('div', { class: 'er-banner', role: 'status' }, svg('wifi', 16),
    h('span', { class: 'tx' }, h('b', null, title), ' ', text),
    retry ? h('button', { type: 'button', onclick: retry }, 'Riprova') : null,
    h('button', { type: 'button', class: 'x', 'aria-label': 'Chiudi', onclick: hideBanner }, icon('x', 12, 'currentColor', 2.2)));
  document.body.append(banner);
}
export function hideBanner() { if (banner) { banner.remove(); banner = null; } }

// ---------------------------------------------------------------------------------------------- sotto il campo
// box: dove metterlo (sotto il campo del link); acts: [[etichetta, 'pri'|'', funzione]]
export function inlineError(box, msg, acts = []) {
  const ex = explain(msg);
  const el = h('div', { class: 'er-inline', role: 'alert' }, h('span', { class: 'ic' }, svg(ex.icon, 16)),
    h('span', { class: 'tx' }, h('b', null, ex.key === 'generic' ? 'Non riesco a usare questo link' : ex.title), h('span', null, ex.text)),
    acts.length ? h('span', { class: 'acts' }, ...acts.map(([label, kind, fn]) => h('button', { type: 'button', class: kind || '', onclick: fn }, label))) : null);
  box.replaceChildren(el);
  box.hidden = false;
  return el;
}
