// Rebrand: foglio "Scorciatoie da tastiera" (20a) e scorciatoie globali dell'app. L'elenco mostra solo i tasti che
// funzionano davvero: quelli dell'editor si leggono da keys.js (anche se l'utente li ha cambiati).
import { h, icon, IS_MAC } from './lib.js';
import { keysOf, keyName, loadKeys, keysDialog } from './keys.js';
import { t as tx } from './i18n.js';

const A = (act) => ({ act });   // tasto dell'editor, come l'ha scelto l'utente
const CATS = [
  ['play', 'Riproduzione', 'Editor', 'M8 5l11 7-11 7z', [
    ['Riproduci o metti in pausa', [A('play')]],
    ['Indietro, pausa, avanti', [A('shuttleBack'), A('shuttleStop'), A('shuttleFwd')], 'Premi più volte J o L per andare più veloce'],
    ['Un fotogramma indietro / avanti', [A('back'), A('fwd')], 'Con Maiusc: un secondo'],
    ['Al taglio o alla clip precedente', [A('prevEdit')]],
    ['Al taglio o alla clip successiva', [A('nextEdit')]],
    ['Più veloce / più lento', [['>'], ['<']]],
    ['Anteprima a schermo intero', [A('full')]],
  ]],
  ['cut', 'Tagli e modifica', 'Editor', 'M6 4a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM6 15a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM8.1 8.1L20 20M8.1 15.9L20 4', [
    ['Dividi alla testina', [A('split')]],
    ['Taglia prima della testina', [A('trimL')]],
    ['Taglia dopo la testina', [A('trimR')]],
    ['Togli la selezione', [A('delete')]],
    ['Annulla l\'ultima modifica', [['Mod', 'Z']]],
    ['Rifai', [['Mod', 'Shift', 'Z'], ['Mod', 'Y']]],
    ['Copia / Incolla', [['Mod', 'C'], ['Mod', 'V']]],
    ['Deseleziona', [A('deselect')]],
  ]],
  ['add', 'Aggiungi alla testina', 'Editor', 'M12 5v14M5 12h14', [
    ['Zoom', [A('zoom')]],
    ['Zoom personalizzato', [A('customZoom')]],
    ['Titolo', [A('text')]],
    ['Marcatore', [A('marker')]],
    ['Clip verticale dalla selezione', [A('vertical')]],
  ]],
  ['tl', 'Timeline', 'Editor', 'M3 6h18M3 12h18M3 18h18M8 4v4M14 10v4M10 16v4', [
    ['Avvicina / allontana', [['Mod', 'rotella']]],
    ['Aggancio ai bordi acceso / spento', [A('snap')]],
    ['Aggiungi o togli dalla selezione', [['Mod', 'clic'], ['Shift', 'clic']]],
  ]],
  ['save', 'Salvataggio', 'Editor', 'M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6', [
    ['Salva adesso', [['Mod', 'S']], 'NoonFrame salva comunque da solo mentre lavori'],
    ['Passa il progetto a un altro PC', [['Mod', 'Shift', 'S']]],
  ]],
  ['proj', 'Progetti', 'Pagina Progetti', 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z', [
    ['Cerca un progetto', [['Mod', 'F']]],
    ['Seleziona tutti', [['Mod', 'A']]],
    ['Selezione multipla', [['Mod', 'clic'], ['Shift', 'clic']]],
    ['Metti nel cestino', [['Canc'], ['Backspace']]],
    ['Deseleziona', [['Esc']]],
  ]],
  ['app', 'App e navigazione', 'Ovunque', 'M3 11.5L12 4l9 7.5M5 10v10h5v-6h4v6h5V10', [
    ['Nuovo progetto', [['Mod', 'N']]],
    ['Monta un video', [['Mod', 'O']]],
    ['Vai alla Home', [['Mod', '1']]],
    ['Vai a Progetti', [['Mod', '2']]],
    ['Il mio stile (Preset)', [['Mod', '3']]],
    ['Impostazioni dell\'account', [['Mod', ',']]],
    ['Cambia tema chiaro / scuro', [['Mod', 'Shift', 'T']]],
    ['Scorciatoie da tastiera', [['Mod', '/'], ['?']]],
    ['Chiudi una finestra o un menu', [['Esc']]],
  ]],
];
const SYM = {
  mac: { Mod: '⌘', Alt: '⌥', Shift: '⇧', Canc: '⌦', Backspace: '⌫', Esc: 'esc', rotella: 'rotella', clic: 'clic' },
  win: { Mod: 'Ctrl', Alt: 'Alt', Shift: 'Maiusc', Canc: 'Canc', Backspace: 'Backspace', Esc: 'Esc', rotella: 'rotella', clic: 'clic' },
};
const ls = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
// una combinazione -> i tasti da disegnare (un tasto dell'editor puo' averne piu' d'uno: S oppure X)
// i nomi dei tasti scritti in italiano si traducono qui (i tasti stanno in un elemento che il traduttore salta)
const KW = new Set(['Spazio', 'Canc', 'Invio', 'Maiusc', 'rotella', 'clic', 'Fine', 'Inizio']);
const kw = (k) => (KW.has(k) ? tx(k) : k);
function combos(c, os) {
  if (c.act) return keysOf(c.act).map((k) => [kw(keyName(k).replace('Backspace', SYM[os].Backspace).replace('Canc', SYM[os].Canc).replace('Esc', SYM[os].Esc))]);
  return [c.map((k) => kw(SYM[os][k] || k))];
}

let openNow = null;
export function shortcutsSheet() {
  if (openNow) return;
  let os = ls('nf-os', IS_MAC ? 'mac' : 'win') === 'mac' ? 'mac' : 'win';
  let cat = 'all', q = '';
  const bg = h('div', { class: 'nfs-bg' });
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); openNow = null; };
  const onKey = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); if (q) { qIn.value = ''; q = ''; paint(); } else close(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key === '/') { e.preventDefault(); e.stopPropagation(); close(); }
  };
  document.addEventListener('keydown', onKey, true);
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
  const qIn = h('input', { type: 'text', class: 'ks-qin', placeholder: 'Cerca un\'azione o un tasto', 'aria-label': 'Cerca un\'azione o un tasto' });
  const qX = h('button', { type: 'button', class: 'pp-qx', 'aria-label': 'Togli la ricerca', hidden: true, onclick: () => { qIn.value = ''; q = ''; paint(); qIn.focus(); } }, icon('x', 9, 'currentColor', 2.6));
  qIn.addEventListener('input', () => { q = qIn.value; paint(); });
  const sub = h('span');
  const osSeg = h('div', { class: 'ks-os' });
  const nav = h('nav', { class: 'ks-nav' });
  const list = h('div', { class: 'ks-list' });
  const total = h('span', { class: 'tnum' });
  const box = h('div', { class: 'nfs ks', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Scorciatoie da tastiera' },
    h('div', { class: 'ks-head' },
      h('span', { class: 'ks-hic' }, icon('keyboard', 19, 'var(--tx)', 1.6)),
      h('span', { class: 'ks-ht' }, h('b', null, 'Scorciatoie da tastiera'), sub),
      h('span', { class: 'grow' }),
      h('label', { class: 'ks-q' }, icon('search', 15, 'var(--t2)', 1.7), qIn, qX),
      osSeg,
      h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Chiudi', 'data-tip': 'Chiudi (Esc)', onclick: close }, icon('x', 13, 'currentColor', 2))),
    h('div', { class: 'ks-main' }, nav, list),
    h('div', { class: 'ks-foot' }, h('span', null, 'Le scorciatoie dell\'editor funzionano quando non stai scrivendo in un campo di testo'),
      h('span', { class: 'grow' }),
      h('button', { type: 'button', class: 'ks-change', onclick: () => { close(); keysDialog(); } }, icon('pen', 13, 'currentColor', 1.8), h('span', null, 'Cambia i tasti dell\'editor')),
      total));
  bg.append(box);
  document.body.append(bg);
  openNow = bg;

  const match = (r) => {
    const s = q.trim().toLowerCase();
    if (!s) return true;
    if ((r[0] + ' ' + (r[2] || '') + ' ' + tx(r[0]) + ' ' + tx(r[2] || '')).toLowerCase().includes(s)) return true;
    const keys = r[1].flatMap((c) => combos(c, os)).map((k) => k.join(' ').toLowerCase());
    return keys.some((k) => k.split(' ').includes(s) || (s.length > 1 && k.includes(s)));
  };
  const label = (txt) => {
    const s = q.trim().toLowerCase(), i = s ? txt.toLowerCase().indexOf(s) : -1;
    return i < 0 ? [txt] : [txt.slice(0, i), h('mark', null, txt.slice(i, i + s.length)), txt.slice(i + s.length)];
  };
  function paint() {
    qX.hidden = !q;
    sub.textContent = 'Apri questa finestra quando vuoi con ' + (os === 'mac' ? '⌘ /' : 'Ctrl + /');
    osSeg.replaceChildren(...[['win', 'Windows'], ['mac', 'macOS']].map(([k, l]) => h('button', { type: 'button', class: os === k ? 'on' : '', onclick: () => { os = k; try { localStorage.setItem('nf-os', k); } catch (e) { /* */ } paint(); } }, l)));
    const all = CATS.reduce((n, c) => n + c[4].length, 0);
    const s = q.trim();
    const use = s || cat === 'all' ? CATS : CATS.filter((c) => c[0] === cat);
    const groups = use.map(([, name, where, , rows]) => [name, where, rows.filter(match)]).filter((g) => g[2].length);
    const shown = groups.reduce((n, g) => n + g[2].length, 0);
    nav.replaceChildren(...[['all', 'Tutte', '', 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z', { length: all }], ...CATS].map(([k, name, , ic, rows]) => {
      const n = s ? (k === 'all' ? shown : CATS.find((c) => c[0] === k)[4].filter(match).length) : rows.length;
      return h('button', { type: 'button', class: (!s && cat === k ? 'on' : '') + (s && !n ? ' dim' : ''), onclick: () => { cat = k; q = ''; qIn.value = ''; paint(); } },
        svgPath(ic), h('span', { class: 'l' }, name), h('span', { class: 'n tnum' }, String(n)));
    }));
    if (!groups.length) {
      list.replaceChildren(h('div', { class: 'pp-empty' }, h('span', { class: 'pp-eic' }, icon('search', 20, 'var(--t2)', 1.7)),
        h('b', null, 'Nessuna scorciatoia per «' + s + '»'), h('span', null, 'Prova con un\'altra parola, per esempio "taglia", "zoom" o "salva"'),
        h('button', { type: 'button', class: 'pp-ebtn', onclick: () => { qIn.value = ''; q = ''; paint(); } }, 'Togli la ricerca')));
    } else {
      list.replaceChildren(...groups.map(([name, where, rows]) => h('section', { class: 'ks-g' },
        h('div', { class: 'ks-gh' }, h('b', null, name), h('span', null, where)),
        h('div', { class: 'ks-rows' }, ...rows.map((r) => h('div', { class: 'ks-r' },
          h('span', { class: 'ks-rl', 'data-notr': '' }, h('span', null, ...label(tx(r[0]))), r[2] ? h('small', null, tx(r[2])) : null),
          h('span', { class: 'ks-rk' }, ...r[1].flatMap((c) => combos(c, os)).flatMap((keys, i) => [i ? h('span', { class: 'or' }, 'oppure') : null,
            h('span', { class: 'ks-combo', 'data-notr': '' }, ...keys.map((k) => h('kbd', null, k)))]).filter(Boolean))))))));
    }
    total.textContent = s ? shown + ' di ' + all + ' scorciatoie' : all + ' scorciatoie';
  }
  loadKeys().then(paint);
  paint();
  setTimeout(() => qIn.focus(), 50);
}
function svgPath(d) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', 15); s.setAttribute('height', 15);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.7');
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.innerHTML = '<path d="' + d + '"/>';
  return s;
}

// scorciatoie di tutta l'app (fuori dai campi di testo; Ctrl+/ funziona ovunque)
// ctx: { nav, newProject, monta, toggleTheme }
export function installGlobalKeys(ctx) {
  document.addEventListener('keydown', (e) => {
    const mod = e.ctrlKey || e.metaKey;
    const tg = e.target || {};
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName || '') || tg.isContentEditable;
    if (mod && e.key === '/') { e.preventDefault(); shortcutsSheet(); return; }
    if (typing || document.querySelector('.modal-bg, .nfs-bg')) return;
    if (!mod && e.key === '?' && !e.altKey) { e.preventDefault(); shortcutsSheet(); return; }
    if (!mod || e.altKey) return;
    const k = e.key.toLowerCase();
    if (!e.shiftKey && k === 'n') { e.preventDefault(); ctx.newProject(); }
    else if (!e.shiftKey && k === 'o') { e.preventDefault(); ctx.monta(); }
    else if (!e.shiftKey && k === '1') { e.preventDefault(); ctx.nav('home'); }
    else if (!e.shiftKey && k === '2') { e.preventDefault(); ctx.nav('projects'); }
    else if (!e.shiftKey && k === '3') { e.preventDefault(); ctx.preset(); }
    else if (!e.shiftKey && k === ',') { e.preventDefault(); ctx.nav('profile'); }
    else if (e.shiftKey && k === 't') { e.preventDefault(); ctx.toggleTheme(); }
  });
}
