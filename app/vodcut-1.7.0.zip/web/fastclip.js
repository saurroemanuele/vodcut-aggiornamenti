// NoonFrame - Clip veloci: dal link (o dal file) alle clip verticali in un passaggio, come sul sito.
// Niente webcam da sistemare, niente montaggio del video lungo: si scarica, si analizza e l'AI trova le clip.
// Il video lungo resta comunque tra i progetti (per chi vuole rifinirlo).
// Rebrand 13a: la scheda di avanzamento (Scarico · Analizzo · Cerco i momenti) con il costo; il lavoro continua anche
// "in secondo piano" (la catena non dipende dalla schermata) e alla fine arriva l'avviso "N clip pronte · Apri".
import { get, post, put, h, icon, toast, pollJob, droppedPath, BIG_DROP, fixLink, isLocalPath, localPath, thumbUrl, linkProblem } from './lib.js';
import { pickPreset } from './presets.js';
import { explain, errIcon, copyDetails, inlineError } from './errors.js';

const FORMATS = [
  ['auto', 'Automatico', 'L\'AI capisce se c\'è una webcam sopra il gioco o se sono persone che parlano'],
  ['podcast', 'Persone a tutto schermo', 'Podcast, interviste, vlog: l\'inquadratura segue chi parla'],
  ['gaming', 'Webcam sopra, gioco sotto', 'Live di gaming con il riquadro della webcam'],
  ['fit', 'Video intero', 'Tutto il video, con lo sfondo sfocato sopra e sotto'],
];
const LANGS = [['', 'Lingua automatica'], ['it', 'Italiano'], ['en', 'Inglese'], ['es', 'Spagnolo'], ['fr', 'Francese'], ['de', 'Tedesco'], ['pt', 'Portoghese']];
const LINK_RX = /(youtube\.com|youtu\.be|twitch\.tv|kick\.com)\//i;
const STEPS = [['get', 3], ['prep', 3], ['ai', 4]];
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* */ } },
};
const hms = (t) => { t = Math.max(0, Math.round(t || 0)); const hh = Math.floor(t / 3600); return (hh ? hh + ':' : '') + String(Math.floor(t / 60) % 60).padStart(hh ? 2 : 1, '0') + ':' + String(t % 60).padStart(2, '0'); };
const source = (r) => (r.file ? 'File' : /twitch\.tv/i.test(r.url) ? 'Twitch' : /kick\.com/i.test(r.url) ? 'Kick' : 'YouTube');

// ---------------------------------------------------------------------------------------------- il lavoro (uno alla volta)
const RUN = { cur: null, subs: new Set(), watching: false, nav: null };
const emit = () => RUN.subs.forEach((f) => f());
export const fastBusy = () => !!(RUN.cur && RUN.cur.status === 'run');

async function runFast(o) {
  const r = RUN.cur = { ...o, phase: 'get', pct: { get: 0, prep: 0, ai: 0 }, msg: '', status: 'run', pid: null, name: '', dur: 0, credits: o.credits || null, target: 0, made: 0, job: null };
  emit();
  const follow = async (job, phase) => {
    r.job = job; emit();
    // "Annulla" premuto mentre il lavoro stava partendo: si ferma subito, prima di spendere
    if (r.status !== 'run') { post(`/api/jobs/${job.id}/cancel`).catch(() => {}); r.job = null; throw new Error('annullato'); }
    const res = await pollJob(job.id, (j) => { r.pct[phase] = Math.max(0, Math.min(1, j.progress || 0)); r.msg = j.message || ''; r.eta = j.eta; if (j.made != null) r.made = j.made; emit(); });
    r.job = null;
    if (res.status !== 'done') throw new Error(res.status === 'cancelled' ? 'annullato' : (res.error || 'Qualcosa non ha funzionato'));
    r.pct[phase] = 1;
    return res.result || {};
  };
  try {
    // 1) il video: scaricato dal link o aperto dal computer
    if (r.url) r.pid = (await follow(await post('/api/import-url', { url: r.url }), 'get')).project;
    else { r.pid = (await post('/api/projects', { source: r.file })).id; r.pct.get = 1; }
    try {
      const p = await get('/api/p/' + r.pid); r.name = p.name; r.dur = p.duration;
      // video delle Clip veloci: riaperto dai Progetti va alla galleria delle clip (anche se le clip non sono riuscite
      // o se le hai fermate proprio adesso)
      if (!p.fastClips) { p.fastClips = true; await put('/api/p/' + r.pid, p); }
    } catch (e) { /* */ }
    if (r.status !== 'run') return;
    // 2) analisi: anteprima leggera, webcam, volume
    r.phase = 'prep'; emit();
    await follow(await post(`/api/p/${r.pid}/prepare`), 'prep');
    if (r.status !== 'run') return;
    await applyFormat(r.pid, r.fmt);
    if (r.status !== 'run') return;
    // 3) l'AI cerca i momenti e monta le clip (il costo vero lo dice il server)
    r.phase = 'ai'; emit();
    try {
      const e = await post(`/api/p/${r.pid}/clipestimate`);
      if (!e.error) { r.target = e.target || 0; if (!r.credits && e.credits && e.perUsd) r.credits = Math.max(1, Math.ceil((+e.usd || 0) * e.perUsd)); }
    } catch (e) { /* */ }
    emit();
    if (r.status !== 'run') return;   // annullato mentre chiedevo il costo: le clip non partono
    const body = { prompt: r.prompt || '' };
    if (r.lang) body.lang = r.lang;
    // lo stile scelto prima: un preset per tutte le clip, o Auto (l'AI sceglie lo stile di ogni clip)
    if (r.style) body.style = { ids: r.style.ids };
    const res = await follow(await post(`/api/p/${r.pid}/clips`, body), 'ai');
    r.status = 'done'; r.made = (res.clips || []).length; emit();
    // finito: se stai guardando si apre la galleria, se no arriva l'avviso
    if (RUN.watching && RUN.nav) RUN.nav('clips', r.pid); else readyNote(r);
  } catch (e) {
    if (r.status !== 'run') return;
    r.status = e.message === 'annullato' ? 'cancelled' : 'error'; r.err = e.message; emit();
    if (!RUN.watching && r.status === 'error') toast(e.message + (r.pid ? ' · Il video è tra i tuoi progetti: puoi riprovare da lì' : ''), true);
  } finally {
    setTimeout(() => { if (RUN.cur === r && r.status !== 'run') { RUN.cur = null; emit(); } }, 400);
  }
}
function cancelRun() {
  const r = RUN.cur;
  if (!r || r.status !== 'run') return;
  if (r.job) post(`/api/jobs/${r.job.id}/cancel`).catch(() => {});
  r.status = 'cancelled'; emit();
  if (r.pid) toast('Ho fermato le clip. Il video è tra i tuoi progetti: puoi riprovare da lì');
}
// avviso in basso "N clip pronte · Apri" (13c), anche se sei in un'altra schermata
function readyNote(r) {
  document.querySelectorAll('.fx-ready').forEach((x) => x.remove());
  const el = h('div', { class: 'fx-ready', role: 'status' },
    h('span', { class: 'ic' }, icon('check', 16, 'var(--ok)', 2.2)),
    h('span', { class: 'tx' }, h('b', null, r.made === 1 ? '1 clip pronta' : r.made + ' clip pronte'), h('span', { 'data-notr': '' }, r.name || '')),
    h('button', { type: 'button', class: 'go', onclick: () => { el.remove(); if (RUN.nav) RUN.nav('clips', r.pid); } }, 'Apri'),
    h('button', { type: 'button', class: 'x', 'aria-label': 'Chiudi', onclick: () => el.remove() }, icon('x', 13, 'currentColor', 2)));
  document.body.append(el);
  setTimeout(() => el.remove(), 30000);
}

// ---------------------------------------------------------------------------------------------- la schermata
// ctx: { app, nav, setTitle, setCleanup, shell(...contenuto) }
export async function screenFast(ctx, extra) {
  const { app, nav, setTitle, setCleanup } = ctx;
  setTitle('Clip veloci');
  RUN.nav = nav; RUN.watching = true;
  const wrap = h('div', { class: 'fx-page' });
  const paint = () => { if (RUN.cur) progressCard(wrap, nav); };
  RUN.subs.add(paint);
  setCleanup(() => { RUN.watching = false; RUN.subs.delete(paint); });
  app.innerHTML = '';
  app.classList.remove('live-only');
  app.append(ctx.shell(wrap));

  const want = extra && (extra.url || extra.path);
  if (RUN.cur && RUN.cur.status === 'run') {
    if (want) toast('Sto già creando le clip di un altro video: aspetta che finisca, poi parte questo');
    progressCard(wrap, nav);
    return;
  }
  formCard(wrap, nav, extra || {});
}

function formCard(wrap, nav, extra) {
  let fmtSel = store.get('nf.fc.fmt') || 'auto';
  if (!FORMATS.some((f) => f[0] === fmtSel)) fmtSel = 'auto';
  let file = extra.path || null;
  const link = h('input', { class: 'fx-in', type: 'text', value: extra.url || '', placeholder: 'Incolla il link: YouTube, twitch.tv/videos/…, kick.com/…', 'aria-label': 'Link del video o della live' });
  const fileTag = h('span', { class: 'fx-file' });
  const showFile = () => { fileTag.replaceChildren(...(file ? [icon('film', 14), h('span', { 'data-notr': '' }, file.split(/[\\/]/).pop()), h('button', { class: 'linkish', type: 'button', onclick: () => { file = null; showFile(); } }, 'Togli')] : [])); fileTag.hidden = !file; };
  const pickBtn = h('button', { class: 'fx-pick', type: 'button', 'aria-label': 'Scegli un file', 'data-tip': 'Scegli un file dal computer', onclick: async () => {
    try {
      const r = await post('/api/pick', { kind: 'video' });
      const p = r.fallback ? (prompt('Percorso completo del video:', '') || '') : r.path;
      if (p) { file = p; link.value = ''; showFile(); }
    } catch (e) { toast(e.message, true); }
  } }, icon('upload', 17, 'currentColor', 1.6));
  const field = h('div', { class: 'fx-field' }, icon('link', 18, 'currentColor', 1.6), link, pickBtn);
  const errBox = h('div', { class: 'h8-err', hidden: true });
  link.addEventListener('input', () => { errBox.hidden = true; });
  field.addEventListener('dragover', (e) => { e.preventDefault(); field.classList.add('over'); });
  field.addEventListener('dragleave', () => field.classList.remove('over'));
  field.addEventListener('drop', async (e) => {
    e.preventDefault(); field.classList.remove('over');
    const f = e.dataTransfer.files[0];
    if (!f) return;
    const real = await droppedPath(f);
    if (real) { file = real; link.value = ''; showFile(); return; }
    toast(f.size > BIG_DROP ? 'File molto grande: sceglilo con il pulsante, così NoonFrame lo apre senza copiarlo' : 'Scegli il video con il pulsante accanto al campo', true);
  });
  link.addEventListener('keydown', (e) => { if (e.key === 'Enter') start(); });
  const fmts = h('div', { class: 'fx-fmts', role: 'radiogroup', 'aria-label': 'Formato delle clip' });
  const drawFmts = () => fmts.replaceChildren(...FORMATS.map(([k, name, tip]) => h('button', { class: 'fx-fmt' + (k === fmtSel ? ' on' : ''), type: 'button', role: 'radio', 'aria-checked': String(k === fmtSel), 'data-tip': tip,
    onclick: () => { fmtSel = k; store.set('nf.fc.fmt', k); drawFmts(); } }, h('i', { class: 'fc-ico ' + k }, h('b'), h('u')), h('span', null, name))));
  drawFmts();
  const lang = h('select', { class: 'fx-sel', 'aria-label': 'Lingua del video' }, ...LANGS.map(([k, n]) => h('option', { value: k, selected: k === (store.get('nf.fc.lang') || '') ? true : null }, n)));
  lang.addEventListener('change', () => store.set('nf.fc.lang', lang.value));
  const q = h('input', { class: 'fx-q', type: 'text', maxlength: '300', placeholder: 'Cosa cercare? Es. momenti divertenti, consigli pratici (facoltativo)', 'aria-label': 'Cosa cercare nel video' });
  const go = h('button', { class: 'fx-go', type: 'button', onclick: () => start() }, icon('sparkle', 15, '#fff', 2.2), h('span', null, 'Crea le clip'));
  wrap.replaceChildren(h('div', { class: 'fx-card form' },
    h('div', { class: 'fx-head' }, h('span', { class: 'fx-hic' }, icon('sparkle', 19, 'var(--tx)', 1.6)),
      h('span', { class: 'fx-ht' }, h('b', null, 'Clip veloci'), h('span', null, 'L\'AI trova i momenti migliori e ti dà le clip verticali pronte. Il video lungo resta tra i tuoi progetti.'))),
    field, errBox, fileTag,
    h('div', { class: 'fx-lab' }, 'Formato delle clip'), fmts,
    h('div', { class: 'fx-two' }, lang, q),
    h('div', { class: 'fx-foot' }, h('button', { class: 'fx-cancel', type: 'button', onclick: () => nav('home') }, 'Annulla'), go)));
  showFile();

  // fromHome: link incollato nella Home. Se annulli la scelta degli stili torni li', non su questa scheda
  async function start(fromHome) {
    if (fastBusy()) { toast('Sto già creando le clip di un altro video: aspetta che finisca'); return; }
    let raw = link.value.trim();
    // percorso di un video del computer incollato nel campo del link: si usa come file
    if (raw && isLocalPath(raw)) { file = localPath(raw); link.value = ''; raw = ''; showFile(); }
    const url = raw ? fixLink(raw) : '';     // "www.youtube.com\watch?v=…", https mancante, testo intorno…
    if (url && url !== raw) link.value = url;
    if (!url && !file) { link.focus(); return toast('Incolla un link o scegli un file'); }
    const bad = url ? linkProblem(url) : '';
    if (bad || (raw && !url)) { inlineError(errBox, bad || linkProblem(''), [['Scegli un file', '', () => { errBox.hidden = true; pickBtn.click(); }]]); link.focus(); return; }
    go.disabled = true;
    // l'unico passaggio dopo il link: con che stili escono le clip (i tuoi preset e/o Auto; con piu' stili l'AI li distribuisce)
    // intanto il server legge quanto dura il video (senza scaricarlo) e dice quanti crediti costano le clip
    const cost = post('/api/clipcost', url ? { url } : { path: file }).catch(() => null);
    let style = null;
    try { style = await pickPreset({ cost }); } catch (e) { toast(e.message, true); }
    go.disabled = false;
    if (!wrap.isConnected) return;
    if (!style) { if (fromHome) nav('home'); return; }
    let credits = null;
    try { const c = await Promise.race([cost, null]); if (c && c.credits && !c.perHour) credits = c.clips + (style.ids.length > 1 ? c.styles : 0); } catch (e) { /* */ }
    runFast({ url, file: url ? null : file, fmt: fmtSel, lang: lang.value, prompt: q.value.trim(), style, credits });
    progressCard(wrap, nav);
  }
  if (extra.url || extra.path) start(true);
}

function progressCard(wrap, nav) {
  const r = RUN.cur;
  if (!r) return;
  if (r.status === 'error' || r.status === 'cancelled') {
    const failed = r.status === 'error';
    const ex = explain(r.err);
    // l'azione giusta per l'errore: un file al posto del link (video privato, eta', paese, anti-bot) o riprovare
    const wantFile = ['private', 'age', 'geo', 'bot', 'nolink'].includes(ex.key);
    const again = () => { const o = { url: r.url, file: r.file, fmt: r.fmt, lang: r.lang, prompt: r.prompt, style: r.style, credits: r.credits }; RUN.cur = null; runFast(o); progressCard(wrap, nav); };
    const copy = h('button', { class: 'fx-cancel', type: 'button', onclick: async () => { if (await copyDetails(r.err, 'Clip veloci')) copy.textContent = 'Dettagli copiati'; } }, 'Copia i dettagli');
    wrap.replaceChildren(h('div', { class: 'fx-card' },
      h('div', { class: 'fx-err' }, h('span', { class: 'ic' + (failed ? ' bad' : '') }, failed ? errIcon(ex.icon, 20) : icon('x', 20, 'currentColor', 1.8)),
        h('b', null, failed ? (ex.key === 'generic' ? 'Le clip non sono riuscite' : ex.title) : 'Clip fermate'),
        h('span', null, failed ? r.err : 'Non è stato speso niente per la parte che non è partita.'),
        r.pid ? h('span', { class: 'sm' }, 'Il video è tra i tuoi progetti: puoi riprovare da lì quando vuoi.') : null),
      h('div', { class: 'fx-foot' },
        failed ? copy : null,
        r.pid ? h('button', { class: 'fx-cancel', type: 'button', onclick: () => nav('clips', r.pid) }, 'Apri il progetto') : null,
        wantFile && failed ? h('button', { class: 'fx-go', type: 'button', onclick: () => { RUN.cur = null; formCard(wrap, nav, {}); const b = wrap.querySelector('.fx-pick'); if (b) b.click(); } }, 'Scegli un file')
          : ex.key === 'notstarted' ? h('button', { class: 'fx-go', type: 'button', onclick: () => { RUN.cur = null; nav('home'); } }, 'Ho capito')
            : h('button', { class: 'fx-go', type: 'button', onclick: again }, 'Riprova'))));
    return;
  }
  let card = wrap.querySelector('.fx-card.run');
  if (!card) {
    card = h('div', { class: 'fx-card run' },
      h('div', { class: 'fx-frame' }, h('div', { class: 'fx-shade' }), h('div', { class: 'fx-scan' }), h('div', { class: 'fx-found' }),
        h('span', { class: 'fx-src' }, icon('link', 11, 'currentColor', 1.8), h('span', { class: 'l' })),
        h('div', { class: 'fx-cap' }, h('div', { class: 'tx' }, h('b', { 'data-notr': '' }), h('span', { class: 'tnum' })), h('span', { class: 'eta tnum' }))),
      h('div', { class: 'fx-segs' }, h('div', { class: 'bars' }), h('div', { class: 'labs' })),
      h('div', { class: 'fx-run-foot' }, h('span', { class: 'cost' }, icon('info', 12, 'currentColor', 1.8), h('span', { class: 'l' })),
        h('span', { class: 'acts' },
          h('button', { type: 'button', class: 'lnk', onclick: () => cancelRun() }, 'Annulla'),
          h('button', { type: 'button', class: 'lnk b', onclick: () => nav('home') }, 'In secondo piano'))));
    wrap.replaceChildren(card);
  }
  const fr = card.querySelector('.fx-frame');
  if (r.pid && !fr.querySelector('img') && r.dur) {
    const im = h('img', { src: thumbUrl(r.pid, Math.max(1, r.dur * 0.3), 360), alt: '', onerror: (e) => e.target.remove() });
    fr.prepend(im);
  }
  card.querySelector('.fx-src .l').textContent = source(r).toUpperCase();
  card.querySelector('.fx-cap b').textContent = r.name || (r.file ? r.file.split(/[\\/]/).pop() : 'Preparo il video…');
  const fm = (FORMATS.find((f) => f[0] === r.fmt) || FORMATS[0])[1], lg = (LANGS.find((l) => l[0] === r.lang) || LANGS[0])[1];
  card.querySelector('.fx-cap .tx span').textContent = [r.dur ? hms(r.dur) : '', fm, lg, r.style ? r.style.name : ''].filter(Boolean).join(' · ');
  card.querySelector('.fx-cap .eta').textContent = r.eta > 30 ? '≈ ' + Math.max(1, Math.round(r.eta / 60)) + ' min' : '';
  // le clip si accendono man mano che l'AI le monta
  const found = card.querySelector('.fx-found');
  const n = Math.min(8, r.target || (r.phase === 'ai' ? 5 : 0));
  if (found.children.length !== n) found.replaceChildren(...Array.from({ length: n }, () => h('span')));
  [...found.children].forEach((el, i) => el.classList.toggle('on', i < r.made));
  const label = { get: r.file ? 'Apro il file' : 'Scarico', prep: 'Analizzo', ai: 'Cerco i momenti' };
  const idx = STEPS.findIndex(([k]) => k === r.phase);
  const bars = card.querySelector('.fx-segs .bars'), labs = card.querySelector('.fx-segs .labs');
  bars.replaceChildren(...STEPS.map(([k, w], i) => h('div', { style: { flex: w } }, h('i', { class: i < idx ? 'done' : '', style: { width: Math.round((i < idx ? 1 : i === idx ? r.pct[k] : 0) * 100) + '%' } }))));
  labs.replaceChildren(...STEPS.map(([k, w], i) => h('div', { class: i < idx ? 'done' : i === idx ? 'now' : '', style: { flex: w } }, h('i'), h('span', null, label[k]),
    h('small', { class: 'tnum' }, i < idx ? (k === 'get' && r.dur ? hms(r.dur) : '') : i === idx && r.pct[k] > 0.01 ? Math.round(r.pct[k] * 100) + '%' : ''))));
  card.querySelector('.fx-run-foot .cost .l').textContent = (r.credits ? '≈ ' + r.credits + ' crediti · ' : '') + 'puoi continuare a usare l\'app';
}

// formato scelto: come nel sito. Senza una webcam vera (o con persone che parlano) le clip sono a tutto schermo
async function applyFormat(pid, mode) {
  const proj = await get('/api/p/' + pid);
  const cam = proj.webcam || {};
  let conf = cam.box ? Number(cam.confidence || 0) : 0;
  const W = Number(proj.width || 1920), H = Number(proj.height || 1080);
  if (cam.box && (cam.box[2] > 0.42 * W || cam.box[3] > 0.6 * H)) conf = 0;   // "webcam" grande come mezza inquadratura: e' la persona ripresa
  const m = mode === 'auto' ? (conf >= 0.45 ? 'gaming' : 'podcast') : mode;
  // scelto da te (podcast o video intero): niente webcam, nemmeno quella che le clip di gaming trovano da sole;
  // deciso in automatico: le clip guardano lo stesso se c'e' una webcam sopra un gioco (nei video montati si sposta)
  if ((m === 'podcast' || m === 'fit') && proj.webcam) { proj.webcam = mode === 'auto' ? null : { none: true }; await put('/api/p/' + pid, proj); }
  await post(`/api/p/${pid}/cliplayout`, { layout: m === 'fit' ? 'fit' : 'auto', apply: false });
}
