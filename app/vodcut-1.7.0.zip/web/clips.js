// NoonFrame - clip virali dalla live (stile Opus): l'AI trova i momenti migliori, ognuno e' gia' una clip verticale montata.
// Galleria con punteggio di viralita', titolo e motivo; anteprima al passaggio del mouse; ogni clip si apre nell'editor.
import { get, post, put, api, h, icon, toast, confirmBox, promptBox, pollJob, mediaUrl, thumbUrl, TOKEN, costRow, costConfirm, credOf } from './lib.js';
import { exportRun, exportsOf } from './exportsheet.js';
import { drawText } from './text.js';
import { pickRange } from './rangepick.js';
import { ensureFont } from './fonts.js';
import { HOOK_STYLE, AUTO_LOOKS, hookStyle, hookContent, hookTitle, hookFor, clipKind, loadLook, openStyleWizard, badgeLogosReady, setLookCache } from './clipstyle.js';

const VW = 1080, VH = 1920;

export const scoreColor = (s) => (s == null ? 'var(--text3)' : s >= 90 ? '#3DDC84' : s >= 75 ? '#A3E635' : s >= 60 ? '#FFD60A' : '#FF9F43');
const mmss = (t) => { t = Math.max(0, Math.round(t || 0)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); };
const hms = (t) => { t = Math.max(0, Math.round(t || 0)); const hh = Math.floor(t / 3600); return (hh ? hh + ':' : '') + String(Math.floor(t / 60) % 60).padStart(hh ? 2 : 1, '0') + ':' + String(t % 60).padStart(2, '0'); };

// titolo d'apertura alto hH vicino a dove sta bene (p.spot = il suo centro, p.spotB = il suo bordo in basso) ma mai
// sopra le facce (p.avoid: fasce occupate mentre c'e' il titolo, calcolate con la clip) ne' sopra le fasce in extra
// (il badge). Uguale a hook_spot in server.py
function hookSpot(p, hH, extra = []) {
  // fasce [inizio, fine] (facce) o [inizio, fine, peso] (una grafica a schermo intero: meglio non coprirla)
  const bands = [...(p.avoid || []), ...extra].map(([a, b, k = 1]) => [a - 0.012, b + 0.012, k]);
  const want = p.spotB != null ? p.spotB - hH : (p.spot ?? 0.5) - hH / 2;
  // mai sotto ~l'82% dello schermo: li' ci sono la descrizione e i pulsanti di TikTok, Reels e Shorts
  const lo = 0.06, hi = Math.max(0.06, 0.82 - hH), cl = (y) => Math.max(lo, Math.min(hi, y));
  const hits = (y) => bands.reduce((s, [a, b, k]) => s + Math.max(0, Math.min(b, y + hH) - Math.max(a, y)) * k, 0);
  const cands = [cl(want), ...bands.flatMap(([a, b]) => [cl(b), cl(a - hH)])];
  let best = null;
  for (const y of cands) { const sc = hits(y) * 25 + Math.abs(y - want); if (!best || sc < best[0] - 1e-9 || (Math.abs(sc - best[0]) < 1e-9 && y < best[1])) best = [sc, y]; }
  return +best[1].toFixed(4);
}
// badge social in automatico: tra le posizioni pronte quella che copre meno facce e sottotitoli (p.occ, la mappa fatta
// con la clip) e mai il titolo d'apertura (boxes). Uguale a badge_auto_xy in server.py
// (in alto, o a sinistra sopra la fascia in basso: in basso e a destra ci sono descrizione e pulsanti di TikTok e Reels)
const BADGE_AUTO = [[0.05, 0.05], [-0.05, 0.05], [null, 0.05], [0.05, 0.74]];
function badgeAutoXY(p, w, hh, boxes = []) {
  const occ = String(p.occ || ''), [C, R] = p.grid || [18, 32];
  let best = null;
  BADGE_AUTO.forEach(([x0, y0], i) => {
    const x = x0 === null ? (1 - w) / 2 : x0 < 0 ? 1 - w + x0 : x0;
    const y = y0 > 0.5 ? Math.max(0, y0 - hh) : y0;
    let tot = 0, n = 0, mx = 0;
    if (occ.length === C * R) {
      for (let r = Math.max(0, Math.floor(y * R)); r < Math.min(R, Math.ceil((y + hh) * R)); r++) {
        for (let c = Math.max(0, Math.floor(x * C)); c < Math.min(C, Math.ceil((x + w) * C)); c++) { const v = +occ[r * C + c] / 9; tot += v; n++; mx = Math.max(mx, v); }
      }
    }
    const hit = boxes.some((b) => x < b.x + b.w + 0.01 && b.x < x + w + 0.01 && y < b.y + b.h + 0.01 && b.y < y + hh + 0.01);
    const sc = (n ? tot / n : 0) + mx * 0.5 + (hit ? 2 : 0) + i * 0.01;
    if (!best || sc < best[0]) best = [sc, x, y];
  });
  return { x: +best[1].toFixed(4), y: +best[2].toFixed(4) };
}

// dove va la scritta d'apertura: clip con le facce lette (interviste, podcast) -> dove non copre nessuno (hookSpot);
// se no (gaming) quando si vede solo la webcam sta in alto, sopra la testa; con cam sopra e gioco sotto sulla linea tra i due
function hookY(ch, c, hH = 0.1, extra = []) {
  const p = c.pos || {};
  if (p.spot != null || p.spotB != null) return hookSpot(p, hH, extra);
  const a = c.a || 0, b = a + (c.dur || 3.2);
  // due persone una sopra l'altra (regia delle chiamate / live a confronto): il titolo sulla linea in mezzo
  const seg = (ch.segs || []).find((s) => !s.removed && s.a <= a + 0.1 && a + 0.1 < s.b);
  if (seg && seg.vlay && seg.vlay.layout === 'stack') return 'mid';
  const lay = (ch.vert && ch.vert.layout) || 'split';
  const zoomed = (ch.zooms || []).some((z) => z.on !== false && z.a < b && a < z.b);
  // gaming come i clipper: il titolo appena sotto la webcam, in cima al gioco (come _hook_y in server.py)
  if (lay === 'split' && !zoomed && ch.clip && ch.clip.gaming) return +((ch.vert.camH ?? 0.4) + 0.035).toFixed(4);
  return lay === 'split' && !zoomed ? 0.33 : 0.07;
}
// quanto resta il titolo da gaming: come i clipper, i primi secondi della clip (da 5 a 9 s di clip vera; gaming_hook_dur in server.py)
const gamingHookDur = (ch) => {
  const len = (ch.segs || []).filter((s) => !s.removed).reduce((t, s) => t + (s.b - s.a), 0) || 30;
  return +Math.max(5, Math.min(9, len * 0.2)).toFixed(2);
};
// quando sta a schermo il titolo d'apertura (tempo della live) -> [inizio, durata]: `want` secondi di clip vera da a0
// (i silenzi tolti non contano, se no sparirebbe prima di leggerlo) e mai sopra una faccia a tutto schermo: nel gaming
// da un video montato aspetta che finisca e chiude prima della prossima; se il primo tratto e' troppo corto per leggerlo
// prende quello dopo. Uguale a _hook_window in server.py
export function hookWindow(ch, a0, want, minVis = 2) {
  const segs = (ch.segs || []).filter((s) => !s.removed).sort((x, y) => x.a - y.a);
  const gaming = !!(ch.clip && ch.clip.gaming);
  const full = (s) => gaming && !!(s.vlay && s.vlay.layout) && s.vlay.layout !== 'split';
  const runs = [];
  let cur = null;
  for (const s of segs) {
    if (s.b <= a0 + 1e-6) continue;
    if (full(s)) { cur = null; continue; }
    if (!cur) { cur = []; runs.push(cur); }
    cur.push([Math.max(a0, s.a), s.b]);
  }
  if (!runs.length) return [+(+a0).toFixed(2), +(+want).toFixed(2)];
  const vis = (r) => r.reduce((t, [x, y]) => t + (y - x), 0);
  const run = runs.find((r) => vis(r) >= Math.min(want, minVis) - 1e-3) || runs.reduce((m, r) => (vis(r) > vis(m) ? r : m));
  let left = want, end = run[0][0];
  for (const [x, y] of run) {
    const take = Math.min(left, y - x);
    end = x + take; left -= take;
    if (left <= 1e-3) break;
  }
  return [+run[0][0].toFixed(2), +Math.max(0.5, end - run[0][0]).toFixed(2)];
}

// la tua immagine del badge (logo scelto nello stile delle clip): null se non c'e' o non si carica
const ownLogos = new Map();
function ownBadgeLogo(path) {
  if (!path) return Promise.resolve(null);
  if (!ownLogos.has(path)) ownLogos.set(path, new Promise((res) => {
    const im = new Image();
    im.onload = () => res(im); im.onerror = () => { ownLogos.delete(path); res(null); };
    setTimeout(() => res(im.complete && im.naturalWidth ? im : null), 6000);
    im.src = mediaUrl(path);
  }));
  return ownLogos.get(path);
}
// disegna la scritta d'apertura con lo stesso motore dei testi dell'editor e la salva nella clip
export async function bakeHooks(cid, force) {
  const ch = await get('/api/p/' + cid);
  let changed = false;
  // lo stile del titolo per questa clip: quello scelto per lei (Clip veloci: un preset, o "auto" = quello automatico del suo
  // tipo), se no quello automatico del suo tipo (gaming, intervista) o il tuo
  const look = (await loadLook()).look, kind = clipKind(ch), cst = (ch.clip || {}).style;
  const hk = cst && cst.hook ? cst.hook : cst && cst.id === 'auto' ? (AUTO_LOOKS[kind] ? AUTO_LOOKS[kind].hook : look.hook) : hookFor(look, kind);
  const st = hookStyle(hk);
  const gstyle = hk.preset === 'gaming';   // titolo da gaming: il titolo della clip con le parole chiave colorate
  await ensureFont(st.font);
  const anim = hk.anim && hk.anim !== 'none' ? { in: hk.anim, inDur: 0.35 } : null;   // come entra il titolo
  const all = (ch.tracks || []).flatMap((t) => t.clips || []);
  const boxOf = (c) => ({ x: c.pos.x, y: c.pos.y, w: c.pos.w, h: c.pos.w * (c.ar || 0.2) * VW / VH });
  const live = (x, c) => x.a < c.a + (c.dur || 3.2) && c.a < x.a + (x.dur || 0);
  for (const t of ch.tracks || []) {
    for (const c of t.clips || []) {
      // badge social dello stile delle clip: si disegna con il logo della piattaforma, dove l'hai messo
      // (in automatico il posto si sceglie dopo, quando si sa dove va il titolo)
      if (c.clipBadge && c.isText && c.text && c.text.badge) {
        if (c.file && !force) continue;
        await badgeLogosReady();
        await ensureFont(c.text.font);
        const cv = drawText(c.text, VH, await ownBadgeLogo(c.text.badge.logo));
        const natW = cv.width / VW, ar = cv.height / cv.width;
        const blob = await new Promise((res) => cv.toBlob(res, 'image/png'));
        const r = await fetch(`/api/p/${cid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: blob });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error || 'Badge non salvato');
        const p0 = c.pos || {}, hh = natW * ar * VW / VH;
        Object.assign(c, { file: j.path, natW, ar, pos: { ...p0, x: +Math.max(0, Math.min(1 - natW, p0.x ?? 0.05)).toFixed(4), y: +Math.max(0, Math.min(1 - hh, p0.y ?? 0.05)).toFixed(4), w: +natW.toFixed(4) } });
        changed = true;
        continue;
      }
      const old = c.hook && c.text && c.text.font && c.text.v !== HOOK_STYLE.v;   // scritte fatte con lo stile vecchio: si ridisegnano
      if (!c.isText || (c.file && c.text && c.text.font && !(force && c.hook) && !old)) continue;
      const tx0 = c.text || {};
      const raw = String(tx0.content || '').replace(/\*/g, '').replace(/\n/g, ' ');
      // il testo l'hai cambiato tu nell'editor (non e' piu' quello disegnato qui l'ultima volta): resta il tuo
      const edited = c.hook && tx0.gen != null && tx0.content !== tx0.gen;
      let content = String(tx0.content || '');
      if (c.hook && !edited) {
        const short = String(tx0.hook ?? '').trim() || raw;
        content = gstyle && tx0.title ? hookTitle(tx0.title, tx0.kw) : hookContent(short);
      }
      const spec = { ...st, content };
      if (c.hook) {
        for (const k of ['hook', 'title', 'kw']) if (tx0[k] !== undefined) spec[k] = tx0[k];
        spec.gen = content;
        // il titolo da gaming resta i primi secondi (come i clipper); gli altri i soliti 3,2 s (se la durata non l'hai cambiata tu).
        // Secondi di clip vera, e mai sopra una faccia a tutto schermo: parte dopo e chiude prima
        if (!edited && (c.autoDur || Math.abs((c.dur || 3.2) - 3.2) < 0.01)) {
          const want = gstyle && tx0.title ? gamingHookDur(ch) : 3.2;
          const moved = c.aAuto != null && Math.abs((c.a || 0) - c.aAuto) > 0.02;   // spostato a mano nell'editor: resta li'
          if (moved) {
            const [a1, d1] = hookWindow({ segs: ch.segs }, c.a || 0, want);
            c.dur = +Math.max(0.5, a1 + d1 - (c.a || 0)).toFixed(2);
          } else {
            const a0 = c.a0 ?? c.a ?? 0;
            const [a1, d1] = hookWindow(ch, a0, want);
            Object.assign(c, { a: a1, a0: +(+a0).toFixed(2), aAuto: a1, dur: d1 });
          }
          c.want = want; c.autoDur = true;
        }
      }
      const cv = drawText(spec, VH);
      const natW = cv.width / VW, ar = cv.height / cv.width;
      const w = Math.min(gstyle && c.hook && tx0.title ? 0.84 : 0.9, natW);   // titolo da gaming: un po' di margine ai lati, come i clipper
      const blob = await new Promise((res) => cv.toBlob(res, 'image/png'));
      const r = await fetch(`/api/p/${cid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: blob });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Scritta non salvata');
      const p0 = c.pos || {};
      const autoY = c.hook && (p0.auto || p0.y == null || !c.file || (old && Math.abs(p0.y - 0.33) < 0.005));
      const hH = w * ar * VW / VH;
      let y = autoY ? hookY(ch, c, hH) : p0.y;
      if (y === 'mid') y = +Math.max(0.05, 0.5 - hH / 2).toFixed(4);
      Object.assign(c, { file: j.path, text: spec, natW, ar, pos: { ...(c.hook ? p0 : {}), x: +((1 - w) / 2).toFixed(4), y, w: +w.toFixed(4), ...(autoY ? { auto: true } : {}) } });
      if (!autoY) delete c.pos.auto;
      if (c.hook) { if (anim) c.anim = anim; else delete c.anim; }
      changed = true;
    }
  }
  // titolo d'apertura in automatico nelle clip con le facce lette: dove non copre nessuno e mai sopra un badge messo a mano
  for (const hc of all.filter((c) => c.hook && c.file && c.pos && c.pos.auto && (c.pos.spot != null || c.pos.spotB != null))) {
    const hH = hc.pos.w * (hc.ar || 0.2) * VW / VH;
    const fixedB = all.filter((x) => x.clipBadge && x.file && x.pos && !x.pos.auto && live(x, hc)).map((x) => { const b = boxOf(x); return [b.y, b.y + b.h]; });
    const y = hookSpot(hc.pos, hH, fixedB);
    if (y !== hc.pos.y) { hc.pos = { ...hc.pos, y }; changed = true; }
  }
  // badge social in automatico: dove copre meno facce e sottotitoli, mai sopra il titolo d'apertura
  for (const bc of all.filter((c) => c.clipBadge && c.file && c.pos && c.pos.auto)) {
    const hh = bc.pos.w * (bc.ar || 0.2) * VW / VH;
    const hooks = all.filter((c) => c.hook && c.file && c.pos && live(bc, c)).map(boxOf);
    const xy = badgeAutoXY(bc.pos, bc.pos.w, hh, hooks);
    if (xy.x !== bc.pos.x || xy.y !== bc.pos.y) { bc.pos = { ...bc.pos, ...xy }; changed = true; }
  }
  // titolo d'apertura e badge social mai uno sopra l'altro: il titolo (messo in automatico) va sotto il badge, o sopra
  const badges = all.filter((c) => c.clipBadge && c.file && c.pos);
  for (const hc of all.filter((c) => c.hook && c.file && c.pos && c.pos.auto && c.pos.spot == null && c.pos.spotB == null)) {
    const hH = (hc.pos.w ?? hc.natW ?? 0.86) * (hc.ar || 0.2) * VW / VH;
    let y = hc.pos.y;
    for (const bc of badges) {
      if (!(bc.a < hc.a + (hc.dur || 3.2) && hc.a < bc.a + (bc.dur || 0))) continue;
      const by = bc.pos.y, bh = bc.pos.w * (bc.ar || 0.2) * VW / VH;
      if (y < by + bh + 0.01 && y + hH > by - 0.01) y = by + bh / 2 < 0.5 ? by + bh + 0.015 : Math.max(0.02, by - hH - 0.015);
    }
    y = +Math.max(0.02, Math.min(0.98 - hH, y)).toFixed(4);
    if (y !== hc.pos.y) { hc.pos = { ...hc.pos, y }; changed = true; }
  }
  if (changed) await put('/api/p/' + cid, ch);
}

async function findJob(pid, kind) {
  try { return (await get('/api/jobs')).find((j) => j.pid === pid && j.kind === kind) || null; } catch (e) { return null; }
}

// Rebrand 13c "Clip pronte": dentro il progetto (percorso Progetti > video), clip 9:16 ordinate per punteggio, filtri
// Tutte / Da esportare / Esportate, "Esporta tutte (N)", "Trova altre clip" con il costo; la clip si apre in un'anteprima
// con inizio e fine (±1 s), descrizione e hashtag (scritti da te o dall'AI), Esporta, Apri nell'editor, Togli.
// ctx: { app, nav, setTitle, setCleanup, shell(...contenuto), openProject(p) }
const LAY_NAME = { auto: 'Formato automatico', full: 'Tutto schermo', fit: 'Video intero' };
export async function screenClips(pid, ctx) {
  const { app, nav, setTitle, setCleanup } = ctx;
  let data = await post(`/api/p/${pid}/cliplist`);
  const parent = await get('/api/p/' + pid);
  setTitle('Clip · ' + parent.name);
  let alive = true, sort = 'score', tab = 'all', selecting = false, query = '';
  const selected = new Set();
  let job = await findJob(pid, 'clips');
  let pjob = await findJob(pid, 'clipprev');
  const working = new Set();   // clip con l'anteprima in preparazione
  const queued = new Set();   // clip che aspettano le anteprime in corso
  let est = null;   // stima della ricerca: quante clip e quanti crediti

  // ---------------------------------------------------------------- intestazione, video lungo, filtri e strumenti
  const count = h('span', { class: 'pp-cnt' });
  const findBtn = h('button', { class: 'cr-more', type: 'button', onclick: () => start() }, icon('sparkle', 14, 'currentColor', 1.8), h('span', { class: 'l' }, 'Trova altre clip'));
  const expAll = h('button', { class: 'cr-exp', type: 'button', onclick: () => { const l = todo(); exportClips((l.length ? l : data.clips).map((c) => c.id)); } }, icon('upload', 14, '#fff', 2), h('span', { class: 'l' }));
  const head = h('header', { class: 'pp-head cr-head' },
    h('div', { class: 'pp-crumb' }, h('span', { class: 'pp-root link', onclick: () => nav('projects') }, 'Progetti'), icon('right', 16, 'var(--t3)', 1.8),
      h('span', { 'data-notr': '' }, parent.name), count),
    h('div', { class: 'grow' }), findBtn, expAll);
  const srcCard = h('div', { class: 'cr-src' },
    h('span', { class: 'th' }, h('img', { src: thumbUrl(pid, Math.max(1, (data.duration || 60) * 0.3), 180), alt: '', onerror: (e) => e.target.remove() })),
    h('span', { class: 'tx' }, h('b', null, 'Dal video lungo · ' + hms(data.duration)), h('span')),
    h('button', { class: 'go', type: 'button', onclick: () => (ctx.openProject ? ctx.openProject({ id: pid }) : nav('editor', pid)) }, h('span', null, 'Apri il video lungo'), icon('right', 14, 'currentColor', 1.8)));
  const searchIn = h('input', { class: 'cr-search', placeholder: 'Cerca nei titoli', 'aria-label': 'Cerca nei titoli', oninput: () => { query = searchIn.value.trim().toLowerCase(); drawGrid(); } });
  const tabs = h('div', { class: 'pp-filters cr-tabs' });
  const tools = h('div', { class: 'cr-tools' });
  const status = h('div', { class: 'cg-status cr-status', style: { display: 'none' } });
  const grid = h('div', { class: 'cr-grid' });
  const selBar = h('div', { class: 'pp-bar cr-selbar', hidden: true });
  const body = h('div', { class: 'pp-body cr-body' }, srcCard, h('div', { class: 'cr-row' }, tabs, h('span', { class: 'grow' }), tools), status, grid);
  const page = h('div', { class: 'pp cr' }, head, body, selBar);
  app.innerHTML = '';
  app.classList.remove('live-only');
  app.append(ctx.shell(page));
  const blankish = data.kind === 'blank' || data.kind === 'story';   // progetto vuoto: niente da cercare
  if (blankish) { findBtn.hidden = true; srcCard.hidden = true; }
  const langName = (k) => { const v = (data.langs || {})[k] || ''; return v ? v.charAt(0).toUpperCase() + v.slice(1) : ''; };
  const todo = () => data.clips.filter((c) => !c.exported);
  // stima della ricerca (il costo vero lo dice il server)
  let estP = null;
  function loadEst() {
    if (blankish) return;
    estP = post(`/api/p/${pid}/clipestimate`).then((e) => { if (!alive || e.error) return est; est = { target: e.target, credits: e.credits && e.perUsd ? Math.max(1, Math.ceil((+e.usd || 0) * e.perUsd)) : null, usd: +e.usd || 0, hasTranscript: e.hasTranscript }; drawGrid(); return est; }).catch(() => est);
  }
  const estLabel = () => (!est ? '' : est.credits ? '≈ ' + est.credits + ' crediti' : est.usd ? '≈ $' + est.usd.toFixed(2) : '');

  // stile delle clip: titolo d'apertura, sottotitoli e badge social (gli stessi passaggi di prima di cercare le clip),
  // per le prossime clip e, se ce ne sono, per quelle gia' fatte
  // sfondo dell'anteprima dello stile: un momento della clip migliore messo in verticale come nella clip (o, prima
  // delle clip, un fotogramma della live con la webcam sopra il gioco); e dove vanno li' i sottotitoli in automatico
  async function lookFrame() {
    try {
      const c = data.clips[0];
      if (c) {
        const ch = await api('GET', `/api/p/${c.id}`);
        const segs = (ch.segs || []).filter((s) => !s.removed);
        const rs = ch.ranges || [[c.a, c.b]];
        const a = rs[0][0], b = rs[rs.length - 1][1];
        let t = a + Math.min(Math.max(2.5, (b - a) * 0.45), Math.max(0.5, b - a - 0.5));
        const sg = segs.find((s) => s.a <= t && t < s.b) || segs.find((s) => s.a > t) || segs[0];
        if (sg && !(sg.a <= t && t < sg.b)) t = Math.min(sg.b - 0.05, sg.a + 0.4);
        const cam = (ch.webcam || {}).box || null;
        const lay = { ...(ch.vert || {}), ...((sg && sg.vlay) || {}) };
        const split = lay.layout === 'split' && !!cam;
        const autoSub = sg && sg.vlay && sg.vlay.subY ? { y: sg.vlay.subY } : split ? { camH: lay.camH ?? 0.4 } : { y: 0.8 };
        // dove va il titolo (come nella clip): sulla linea tra i due, sotto la webcam, in basso sul petto quando una
        // persona e' a tutto schermo, subito sotto il video intero (o la visual) con lo sfondo sfocato
        const hookY = lay.layout === 'stack' ? 'mid' : split ? 0.33 : !cam && (lay.layout === 'rect' || lay.layout === 'game') ? { spot: 0.77 }
          : lay.layout === 'fit' ? { spot: 0.74 } : 0.07;
        if (ch.width && ch.height) return { frame: { src: thumbUrl(pid, t, 720), W: ch.width, H: ch.height, lay, cam }, autoSub, hookY, cam: split };
      }
    } catch (e) { /* sotto: un fotogramma della live */ }
    const t = Math.max(1, (data.duration || 60) * 0.3);
    if (data.webcamBox && data.width && data.height) {
      return { frame: { src: thumbUrl(pid, t, 720), W: data.width, H: data.height, lay: { layout: 'split', camH: 0.4, gameX: 0.5 }, cam: data.webcamBox }, autoSub: { camH: 0.4 }, hookY: 0.33, cam: true };
    }
    return { frame: thumbUrl(pid, t, 640), autoSub: { y: 0.8 }, hookY: 0.07, cam: false };
  }
  async function lookBox(opts = {}) {
    const has = data.clips.length > 0 && !opts.search;
    const fr = await lookFrame();
    return new Promise((resolve) => {
      openStyleWizard({
        title: 'Stile delle clip',
        lead: opts.search ? 'Scegli come escono le clip: titolo d\'apertura, sottotitoli e badge social. Resta salvato anche per le prossime live.'
          : 'Titolo d\'apertura, sottotitoli e badge social: vale per le prossime clip' + (has ? ' e per quelle già fatte.' : '.'),
        frame: fr.frame, cam: fr.cam, autoSub: fr.autoSub, hookY: fr.hookY,
        finalLabel: opts.search ? 'Trova le clip' : has ? 'Applica a tutte le clip' : 'Salva',
        quick: opts.search ? 'Usa lo stile salvato' : null,
        onCancel: () => resolve(false),
        onFinish: async (look, presets) => {
          const r = await post(`/api/p/${pid}/cliplook`, { look, presets, apply: has });
          setLookCache(look, presets);
          resolve(true);
          if (has && alive) {
            toast('Stile aggiornato in ' + r.clips + ' clip: rifaccio le anteprime');
            (async () => {
              for (const c of data.clips) { try { await bakeHooks(c.id, true); } catch (e) { console.warn(e); } }
              await reload();
              await previews(data.clips.map((c) => c.id));
            })();
          }
        },
      });
    });
  }

  // quanti zoom sulla webcam per clip (con lo swoosh): automatico, nessuno o un numero preciso
  function zoomBox() {
    let n = data.clipZooms ?? 'auto';
    const bg = h('div', { class: 'modal-bg' });
    const opts = [['auto', 'Auto'], [0, 'Nessuno'], [1, '1'], [2, '2'], [3, '3'], [4, '4'], [5, '5']];
    const seg = h('div', { class: 'seg cg-seg cg-zseg', role: 'group', 'aria-label': 'Zoom per clip' });
    const hint = h('p', { class: 'muted', style: { margin: '10px 0 0' } });
    const draw = () => {
      seg.replaceChildren(...opts.map(([k, l]) => h('button', { type: 'button', class: String(n) === String(k) ? 'on' : '', onclick: () => { n = k; draw(); } }, l)));
      hint.textContent = n === 'auto' ? 'Da 1 a 3 in base alla durata della clip.'
        : n === 0 ? 'Le clip escono senza zoom e senza swoosh.'
          : `Fino a ${n} zoom per clip. Lo zoom si fa solo quando parla o reagisce lo streamer: se nella clip ci sono meno momenti così, gli zoom saranno meno.`;
    };
    draw();
    const close = () => bg.remove();
    const has = data.clips.length > 0;
    const save = async () => {
      let r;
      try { r = await post(`/api/p/${pid}/clipzooms`, { n, apply: has }); } catch (e) { return toast(e.message, true); }
      data.clipZooms = n; close();
      if (has) { toast('Zoom aggiornati in ' + r.clips + ' clip: rifaccio le anteprime'); await reload(); await previews(data.clips.map((c) => c.id)); }
      else toast('Salvato: le prossime clip avranno questi zoom');
    };
    bg.append(h('div', { class: 'modal cg-zmodal', role: 'dialog', 'aria-label': 'Zoom nelle clip' },
      h('h2', null, 'Zoom nelle clip'),
      h('div', { class: 'cg-slbl' }, 'Zoom sulla webcam per ogni clip'), seg, hint,
      h('p', { class: 'muted', style: { margin: '8px 0 0' } }, has ? 'Vale per tutte le clip di questa live e per le prossime. Gli zoom che hai messo a mano restano.' : 'Lo scegli adesso e le clip escono già così.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px', marginTop: '14px' } },
        h('button', { class: 'btn ghost', type: 'button', onclick: close }, 'Annulla'),
        h('button', { class: 'btn primary', type: 'button', onclick: save }, has ? 'Salva e applica' : 'Salva'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  // formato delle clip verticali: scelto subito, prima di creare le clip, e cambiabile dopo per tutte insieme
  function layoutBox() {
    let lay = data.clipLayout || 'auto';
    const cam = !!data.webcam;
    const OPTS = [
      ['auto', 'Automatico', cam ? 'Webcam sopra e gioco sotto. Se nella scena c\'è solo la webcam, la persona a tutto schermo.'
        : 'La persona a tutto schermo quando si vede bene (podcast, intervista, camera fissa), se no il video intero.'],
      ['full', 'Tutto schermo', cam ? 'Solo il gioco, a tutto schermo.' : 'Il video riempie lo schermo verticale, centrato sulla persona che si vede di più.'],
      ['fit', 'Intero', 'Tutto il video al centro, con lo stesso video sfocato sopra e sotto.']];
    const bg = h('div', { class: 'modal-bg' });
    const tiles = h('div', { class: 'cg-lays', role: 'radiogroup', 'aria-label': 'Formato delle clip' });
    const hint = h('p', { class: 'muted', style: { margin: '12px 0 0', minHeight: '38px' } });
    const draw = () => {
      tiles.replaceChildren(...OPTS.map(([k, name]) => h('button', { type: 'button', role: 'radio', 'aria-checked': String(lay === k), class: 'cg-lay' + (lay === k ? ' on' : ''), onclick: () => { lay = k; draw(); } },
        h('i', { class: 'cg-lay-pic ' + k + (cam ? ' cam' : '') }, h('b'), h('u')), h('span', null, name))));
      hint.textContent = OPTS.find(([k]) => k === lay)[2];
    };
    draw();
    const close = () => bg.remove();
    const has = data.clips.length > 0;
    const saveBtn = h('button', { class: 'btn primary', type: 'button' }, has ? 'Salva e applica' : 'Salva');
    saveBtn.onclick = async () => {
      saveBtn.disabled = true;
      let r;
      try { r = await post(`/api/p/${pid}/cliplayout`, { layout: lay, apply: has }); } catch (e) { saveBtn.disabled = false; return toast(e.message, true); }
      data.clipLayout = lay;
      if (!r.id) { close(); drawTools(); return toast('Salvato: le prossime clip escono in questo formato'); }
      saveBtn.textContent = 'Cambio il formato…';
      const res = await pollJob(r.id, (j) => { saveBtn.textContent = j.message || 'Cambio il formato…'; });
      close();
      if (res.status !== 'done') return toast(res.error || 'Formato non cambiato', true);
      toast('Formato cambiato in ' + res.result.clips + ' clip: rifaccio le anteprime');
      await reload(); await previews(data.clips.map((c) => c.id));
    };
    bg.append(h('div', { class: 'modal cg-zmodal', role: 'dialog', 'aria-label': 'Formato delle clip' },
      h('h2', null, 'Formato delle clip'), tiles, hint,
      h('p', { class: 'muted', style: { margin: '6px 0 0' } }, has ? 'Vale per tutte le clip di questa live e per le prossime. Nell\'editor puoi sempre cambiarlo per una clip sola.' : 'Lo scegli adesso e le clip escono già così.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px', marginTop: '14px' } },
        h('button', { class: 'btn ghost', type: 'button', onclick: close }, 'Annulla'), saveBtn)));
    bg.addEventListener('click', (e) => { if (e.target === bg && !saveBtn.disabled) close(); });
    document.body.append(bg);
  }

  function drawTools() {
    const n = data.clips.length, nd = data.clips.filter((c) => c.exported).length, nf = data.clips.filter((c) => c.fav).length;
    count.textContent = n ? String(n) : '';
    const left = todo().length;
    expAll.querySelector('.l').textContent ='Esporta tutte (' + (left || n) + ')';
    expAll.hidden = !n;
    findBtn.querySelector('.l').textContent =n ? 'Trova altre clip' : 'Trova le clip';
    findBtn.classList.toggle('main', !n);   // senza clip e' l'azione della pagina (in mezzo non c'e' un altro bottone)
    findBtn.disabled = !!job;
    srcCard.querySelector('.tx span').textContent = [LAY_NAME[data.clipLayout || 'auto'], langName(data.lang)].filter(Boolean).join(' · ');
    if (tab === 'fav' && !nf) tab = 'all';
    tabs.replaceChildren(...[['all', 'Tutte', n], ['todo', 'Da esportare', n - nd], ['done', 'Esportate', nd], ...(nf ? [['fav', 'Preferite', nf]] : [])].map(([k, l, c]) =>
      h('button', { type: 'button', class: tab === k ? 'on' : '', onclick: () => { tab = k; drawTools(); drawGrid(); } }, h('span', null, l), h('span', { class: 'n' }, String(c)))));
    tabs.hidden = !n;
    const tb = (ic, tip, fn, on) => h('button', { type: 'button', class: 'cr-tb' + (on ? ' on' : ''), 'aria-label': tip, 'data-tip': tip, onclick: fn }, icon(ic, 15, 'currentColor', 1.8));
    tools.replaceChildren(...[
      n ? searchIn : null,
      n ? h('div', { class: 'pp-seg cr-sort' }, ...[['score', 'Più virali'], ['time', 'Ordine nella live']].map(([k, l]) => h('button', { type: 'button', class: sort === k ? 'on' : '', onclick: () => { sort = k; drawTools(); drawGrid(); } }, l))) : null,
      n ? langSel() : null,
      tb('text', 'Stile: titolo d\'apertura, sottotitoli e badge social', () => lookBox()),
      tb('phone', 'Formato: come si vede il video nelle clip verticali', () => layoutBox()),
      data.webcam ? tb('zoomin', 'Zoom sulla webcam in ogni clip', () => zoomBox()) : null,
      blankish ? null : tb('plus', 'Clip a mano: un momento qualsiasi della live', () => manualBox()),
      n ? tb('check', selecting ? 'Fine selezione' : 'Seleziona più clip', () => { selecting = !selecting; selected.clear(); drawTools(); drawGrid(); drawSel(); }, selecting) : null].filter(Boolean));
  }
  // lingua delle clip: sottotitoli riscritti nella lingua scelta, titoli e scritte tradotti
  function langSel() {
    const L = data.langs || { it: 'italiano', en: 'inglese' };
    const sel = h('select', { class: 'cr-lang', 'aria-label': 'Lingua delle clip', 'data-tip': 'Lingua di sottotitoli, titoli e scritte delle clip' },
      ...Object.entries(L).map(([k, v]) => h('option', { value: k, selected: k === data.lang ? true : null }, v.charAt(0).toUpperCase() + v.slice(1))));
    sel.addEventListener('change', async () => {
      const lang = sel.value;
      // la traduzione di titoli e scritte costa crediti: prima il costo
      const n = post(`/api/p/${pid}/cliplangcost`).then((e) => (e && !e.error && e.credits && e.usd ? credOf(e.usd, e.perUsd) : 0)).catch(() => 0);
      if (!await costConfirm('Clip in ' + L[lang] + '?', 'Riscrivo i sottotitoli delle clip ascoltando di nuovo l\'audio in ' + L[lang] + ' (gratis, sul tuo computer) e traduco titoli e scritte d\'apertura con l\'AI.', 'Cambia lingua', n)) { sel.value = data.lang; return; }
      let j;
      try { j = await post(`/api/p/${pid}/cliplang`, { lang }); } catch (e) { sel.value = data.lang; return toast(e.message, true); }
      showStatus(j, 'Cambio la lingua delle clip');
      let r;
      try { r = await pollJob(j.id, (x) => { if (alive) showStatus(x, 'Cambio la lingua delle clip'); }); } catch (e) { r = { status: 'error', error: e.message }; }
      if (!alive) return;
      status.style.display = 'none';
      if (r.status !== 'done') { toast(r.error || 'Lingua non cambiata', true); await reload(); return; }
      toast(r.result && r.result.translated ? 'Clip in ' + L[lang] + ': sottotitoli e titoli aggiornati' : 'Sottotitoli in ' + L[lang] + ' (titoli non tradotti: serve una chiave AI)');
      await reload();
      await previews(data.clips.map((c) => c.id));
    });
    return sel;
  }
  function visible() {
    let l = data.clips.filter((c) => (tab === 'all' || (tab === 'todo' && !c.exported) || (tab === 'done' && c.exported) || (tab === 'fav' && c.fav))
      && (!query || String(c.name || '').toLowerCase().includes(query)));
    // le preferite sempre per prime
    l = l.slice().sort((a, b) => (!!b.fav - !!a.fav) || (sort === 'time' ? a.a - b.a : (b.score ?? -1) - (a.score ?? -1) || a.a - b.a));
    return l;
  }

  // ---------------------------------------------------------------- dove funziona meglio (TikTok, Reels, Shorts)
  const PF_NAME = { tiktok: 'TikTok', reels: 'Reels', shorts: 'Shorts' };
  function bestPf(c) {
    if (!c.pf) return null;
    const e = Object.entries(c.pf).filter(([k]) => PF_NAME[k]).sort((a, b) => b[1] - a[1]);
    return e.length && e[0][1] - (e[1] ? e[1][1] : 0) >= 3 ? e[0] : null;   // quasi pari: nessuna piattaforma in evidenza
  }
  function pfBox(c) {
    if (!c.pf) return null;
    const best = bestPf(c);
    return h('div', { class: 'cg-pfbox cr-pf' },
      h('div', { class: 'cg-pfh' }, 'Dove funziona meglio'),
      ...Object.keys(PF_NAME).map((k) => h('div', { class: 'cg-pfrow' + (best && best[0] === k ? ' best' : '') },
        h('span', null, PF_NAME[k]),
        h('div', { class: 'cg-pfbar' }, h('div', { style: { width: (c.pf[k] || 0) + '%' } })),
        h('b', null, String(c.pf[k] ?? '–')))),
      c.pfWhy ? h('p', { class: 'cg-pfwhy' }, c.pfWhy) : null);
  }

  // ---------------------------------------------------------------- clip a mano e clip allungata (o accorciata) nella live
  function manualBox() {
    if (job) return toast('Aspetta che l\'AI finisca di cercare le clip', true);
    const D = +data.duration || 0;
    pickRange({ pid, duration: D, source: data.source, vcodec: data.vcodec, a: 0, b: Math.min(D, 30), marks: data.clips.map((c) => [c.a, c.b]),
      title: 'Clip a mano', okLabel: 'Crea la clip', withName: true,
      intro: 'Scegli un momento qualsiasi della live, anche uno che l\'AI non ha preso. La clip esce montata come le altre: webcam e gioco, sottotitoli e zoom.',
      run: async ({ a, b, name }, busy) => {
        const j = await post(`/api/p/${pid}/clipmanual`, { a, b, name });
        const r = await pollJob(j.id, (x) => busy(x.message));
        if (r.status !== 'done') throw new Error(r.error || 'Clip non creata');
        toast('Clip creata: la trovi nella galleria');
        await reload();
        await previews([r.result.clip.id]);
      } });
  }
  // la clip dell'AI ha tagliato l'inizio che serve a capire (o finisce troppo presto): si allunga nella live, le modifiche restano
  function extendBox(c) {
    if (job) return toast('Aspetta che l\'AI finisca di cercare le clip', true);
    const D = +data.duration || 0;
    pickRange({ pid, duration: D, source: data.source, vcodec: data.vcodec, a: c.a, b: c.b, from: [c.a, c.b],
      marks: data.clips.filter((x) => x.id !== c.id).map((x) => [x.a, x.b]), maxDur: 300,
      title: 'Allunga o accorcia la clip', okLabel: 'Salva',
      intro: 'Sposta l\'inizio prima per aggiungere il contesto che serve, o la fine dopo per arrivare al finale. Quello che hai già modificato nella clip resta.',
      run: async ({ a, b }, busy) => {
        busy('Aggiorno la clip…');
        await setRange(c, a, b, busy);
      } });
  }
  // wait=false: non aspetta la nuova anteprima (dalla scheda della clip si puo' subito cambiare ancora)
  async function setRange(c, a, b, busy, wait = true) {
    const j = await post(`/api/p/${c.id}/clipextend`, { a, b });
    const r = await pollJob(j.id, (x) => busy && busy(x.message));
    if (r.status !== 'done') throw new Error(r.error || 'Clip non aggiornata');
    toast('Clip aggiornata: ' + mmss(r.result.dur));
    await reload();
    if (wait) await previews([c.id]); else previews([c.id]).catch(() => {});
  }

  // ---------------------------------------------------------------- scheda di una clip (9:16)
  function card(c) {
    const pv = h('div', { class: 'cr-pv' });
    const posterSrc = c.poster ? mediaUrl(c.poster) + '&v=' + Math.round(c.previewAt || 0) : thumbUrl(pid, Math.min((data.duration || 1) - 0.5, c.a + 1), 480);
    pv.append(h('img', { class: 'cg-poster' + (c.poster ? '' : ' raw'), src: posterSrc, alt: '', loading: 'lazy', draggable: 'false' }));
    let vid = null;
    if (c.preview) {
      pv.addEventListener('pointerenter', () => {
        if (selecting) return;
        if (!vid) { vid = h('video', { class: 'cg-vid', src: mediaUrl(c.preview) + '&v=' + Math.round(c.previewAt || 0), muted: true, loop: true, playsinline: true, preload: 'auto' }); vid.muted = true; pv.append(vid); }
        vid.currentTime = 0; vid.play().catch(() => {});
      });
      pv.addEventListener('pointerleave', () => { if (vid) vid.pause(); });
    }
    if (working.has(c.id) || queued.has(c.id) || (!c.preview && (pjob || job))) pv.append(h('div', { class: 'cg-wait' }, h('span', { class: 'spinner sm' }), h('span', null, c.preview ? 'Aggiorno l\'anteprima' : job && !working.has(c.id) ? 'Anteprima in coda' : 'Preparo l\'anteprima')));
    else if (!c.preview) pv.append(h('div', { class: 'cg-wait soft' }, h('span', null, 'Anteprima non pronta')));
    if (c.score != null) pv.append(h('span', { class: 'cr-score', style: { color: scoreColor(c.score) }, 'data-tip': 'Punteggio: quanto la clip può funzionare da sola (0-100)' }, String(c.score)));
    if (c.manual || c.edited) pv.append(h('span', { class: 'cr-tag' + (c.score == null ? ' first' : '') }, c.manual ? 'A mano' : 'Modificata'));
    if (c.exported) pv.append(h('span', { class: 'cr-done', 'data-tip': 'Già esportata' }, icon('check', 10, '#fff', 3)));
    pv.append(h('button', { class: 'cr-fav' + (c.fav ? ' on' : ''), type: 'button', 'aria-pressed': String(!!c.fav), 'aria-label': 'Preferita', 'data-tip': c.fav ? 'Togli dalle preferite' : 'Preferita: va in cima',
      onclick: (e) => { e.stopPropagation(); toggleFav(c); } }, icon('star', 14, 'currentColor', 2)));
    pv.append(h('span', { class: 'cr-dur tnum' }, mmss(c.dur)));
    if (selecting) pv.append(h('span', { class: 'pp-chk cr-chk' + (selected.has(c.id) ? ' on' : '') }, icon('check', 11, '#fff', 3)));
    const el = h('article', { class: 'cr-card' + (selected.has(c.id) ? ' sel' : ''), tabindex: '0', 'aria-label': c.name, 'data-id': c.id },
      pv, h('b', { class: 'cr-nm', 'data-notr': '' }, c.name), h('span', { class: 'cr-rg tnum' }, hms(c.a) + ' → ' + hms(c.b)));
    el.addEventListener('click', () => { if (selecting) { selected.has(c.id) ? selected.delete(c.id) : selected.add(c.id); drawGrid(); drawSel(); } else player(c); });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') el.click(); });
    el.addEventListener('contextmenu', (e) => { e.preventDefault(); more(c, { x: e.clientX, y: e.clientY }); });
    return el;
  }

  async function toggleFav(c) {
    c.fav = !c.fav;
    drawTools(); drawGrid();
    try { await post(`/api/p/${pid}/clipfav`, { id: c.id, on: c.fav }); }
    catch (e) { c.fav = !c.fav; drawTools(); drawGrid(); toast(e.message, true); }
  }
  function drawGrid() {
    const l = visible();
    if (!data.clips.length) { grid.replaceChildren(job ? waiting() : empty()); return; }
    const moreCard = !blankish && !selecting ? h('button', { class: 'cr-card cr-add', type: 'button', disabled: job ? true : null, onclick: () => start() },
      icon('plus', 18, 'currentColor', 1.8), h('b', null, 'Trova altre clip'), estLabel() ? h('span', { class: 'tnum' }, estLabel()) : null) : null;
    if (!l.length) {
      grid.replaceChildren(h('div', { class: 'pp-empty cr-none' }, h('span', { class: 'pp-eic' }, icon(query ? 'search' : 'phone', 22, 'var(--t2)', 1.6)),
        h('b', null, query ? 'Nessuna clip con «' + searchIn.value.trim() + '»' : tab === 'done' ? 'Ancora nessuna clip esportata' : tab === 'todo' ? 'Le hai esportate tutte' : 'Nessuna clip qui'),
        h('span', null, tab === 'done' ? 'Esporta una clip: la ritrovi qui' : 'Cambia filtro per vedere le altre')));
      return;
    }
    grid.replaceChildren(...l.map(card), ...(moreCard ? [moreCard] : []));
    expBadges();
  }

  // galleria vuota (2.0): le clip "fantasma" nella stessa griglia delle clip vere, che sfumano, e sopra il messaggio.
  // L'azione e' il bottone in alto ("Trova le clip"), qui niente doppioni
  function ghostEmpty({ run, ic, title, text, chips, hint, action }) {
    const ghost = () => h('span', { class: 'cg-ghost' }, h('i', { class: 'pv' }), h('i', { class: 't1' }), h('i', { class: 't2' }));
    return h('div', { class: 'cg-void' + (run ? ' run' : ''), role: 'status' },
      h('div', { class: 'cg-ghosts', 'aria-hidden': 'true' }, ...Array.from({ length: 6 }, ghost)),
      h('div', { class: 'cg-void-msg' },
        h('span', { class: 'pp-eic' + (run ? ' run' : '') }, icon(ic, 22, run ? 'var(--ac)' : 'var(--t2)', 1.7)),
        h('b', { class: 't' }, title), h('span', { class: 'd' }, text),
        chips && chips.length ? h('div', { class: 'cg-chips' }, ...chips.map((c) => h('span', null, c))) : null,
        hint ? h('span', { class: 'cg-hint' }, icon('sparkle', 13, 'currentColor', 2), h('span', null, hint)) : null,
        action || null));
  }
  // mentre l'AI cerca e monta: le clip arrivano qui una alla volta
  function waiting() {
    return ghostEmpty({ run: true, ic: 'sparkle', title: 'Le clip arrivano qui',
      text: 'Ogni clip compare appena è montata, anche mentre l\'AI prepara le altre. Puoi intanto fare altro: la ricerca continua.' });
  }

  function empty() {
    if (blankish) {
      // progetto vuoto: niente live da leggere, si spiega come arrivarci invece di far partire una ricerca che fallisce
      return ghostEmpty({ ic: 'upload', title: 'Le clip AI partono da una live o da un video lungo',
        text: 'Questo è un progetto vuoto, quindi non c\'è niente da cui tirare fuori le clip. Importa la tua live (o un podcast, un video lungo) dalla Home come nuovo progetto.',
        action: h('button', { class: 'btn primary cg-void-go', onclick: () => nav('home') }, icon('upload', 14, '#fff', 2.2), 'Importa una live') });
    }
    const chips = est ? ['Circa ' + est.target + ' clip', estLabel(), est.hasTranscript ? '' : 'Prima la trascrivo'].filter(Boolean) : [];
    return ghostEmpty({ ic: 'phone', title: 'Ancora nessuna clip',
      text: 'L\'AI ascolta il video, trova i momenti che possono diventare virali e li monta in clip verticali, con sottotitoli, punteggio e motivo.',
      chips, hint: 'Premi «Trova le clip» in alto per iniziare' });
  }

  function drawSel() {
    if (!selecting) { selBar.hidden = true; return; }
    selBar.hidden = false;
    const n = selected.size;
    const act = (ic, label, fn, cls, off) => h('button', { type: 'button', class: 'pp-act' + (cls ? ' ' + cls : ''), disabled: off ? true : null, onclick: fn }, icon(ic, 14, 'currentColor', 1.7), h('span', null, label));
    selBar.replaceChildren(h('span', { class: 'pp-seln' }, n ? (n === 1 ? '1 selezionata' : n + ' selezionate') : 'Tocca le clip da scegliere'),
      act('check', 'Tutte', () => { visible().forEach((c) => selected.add(c.id)); drawGrid(); drawSel(); }),
      act('upload', 'Esporta', () => exportClips([...selected]), '', !n),
      act('trash', 'Togli', () => removeClips([...selected]), 'del', !n),
      h('button', { type: 'button', class: 'pp-act x', 'aria-label': 'Fine selezione', 'data-tip': 'Fine selezione', onclick: () => { selecting = false; selected.clear(); drawTools(); drawGrid(); drawSel(); } }, icon('x', 13, 'currentColor', 2)));
  }

  // ---------------------------------------------------------------- azioni
  async function openClip(c) {
    try { await bakeHooks(c.id); } catch (e) { /* la scritta la ridisegna l'editor */ }
    nav('editor', c.id);
  }
  // "Rifai questa clip" (13c): l'AI riguarda il momento e lo rifa' (inizio, fine, titolo); costa crediti, quindi prima il costo
  async function redoClip(c) {
    let est = null;
    try { est = await post(`/api/p/${c.id}/clipredocost`); } catch (e) { /* */ }
    if (est && est.error) { toast(est.error, true); return null; }
    const n = est && est.usd != null && est.credits ? credOf(est.usd, est.perUsd) : 0;
    if (!(await costConfirm('Rifare questa clip?', 'L\'AI riguarda il momento e rifà inizio, fine e titolo. La clip di adesso viene sostituita.', 'Rifai', n))) return null;
    let j;
    try { j = await post(`/api/p/${c.id}/clipredo`); } catch (e) { toast(e.message, true); return null; }
    working.add(c.id); drawGrid();
    toast('L\'AI rifà la clip: la trovi qui tra poco');
    const r = await pollJob(j.id, () => {});
    working.delete(c.id);
    if (r.status === 'cancelled') { if (r.refunded) toast(r.refunded === 1 ? 'Annullato: ti ho restituito 1 credito' : 'Annullato: ti ho restituito ' + r.refunded + ' crediti'); await reload(); return null; }
    if (r.status !== 'done') { toast(r.error || 'Clip non rifatta', true); await reload(); return null; }
    toast('Clip rifatta: anteprima in arrivo');
    await reload();
    previews([r.result.id]).catch(() => {});
    return r.result.id;
  }
  async function exportClips(ids) {
    if (!ids.length) return;
    try {
      for (const id of ids) { const c = data.clips.find((x) => x.id === id); if (c && c.needsBake) await bakeHooks(id); }
    } catch (e) { return toast(e.message, true); }
    // il foglio con l'avanzamento resta sopra le clip (si chiude e continua nella pillola dei lavori)
    // prima si sceglie come escono (nome, cartella, qualita'), poi il foglio con l'avanzamento
    const items = ids.map((id) => data.clips.find((x) => x.id === id)).filter(Boolean).map((c) => ({ id: c.id, name: c.name,
      poster: c.poster ? mediaUrl(c.poster) + '&v=' + Math.round(c.previewAt || 0) : thumbUrl(pid, Math.min((data.duration || 1) - 0.5, c.a + 1), 480),
      dur: c.dur || (c.b != null && c.a != null ? c.b - c.a : 0) }));
    exportRun(pid, { vod: false, verticals: ids }, { setup: true, items, name: ids.length === 1 ? (items[0] || {}).name : ids.length + ' clip', onDone: () => reload() });
  }
  async function rename(c) {
    const nm = await promptBox('Rinomina la clip', 'È anche il nome del file quando la esporti.', c.name, 'Rinomina');
    if (!nm || nm === c.name) return false;
    try { await post(`/api/p/${c.id}/rename`, { name: nm }); await post(`/api/p/${pid}/cliprename`, { id: c.id, name: nm }); } catch (e) { toast(e.message, true); return false; }
    c.name = nm; drawGrid();
    return true;
  }
  async function removeClips(ids) {
    const one = ids.length === 1;
    if (!await confirmBox(one ? 'Togliere la clip?' : `Togliere ${ids.length} clip?`, 'Il video lungo resta com\'è.', 'Togli', true)) return false;
    for (const id of ids) {
      try { await api('DELETE', '/api/p/' + id); } catch (e) { /* gia' tolta */ }
      try { await post(`/api/p/${pid}/clipremove`, { id }); } catch (e) { /* */ }
    }
    data.clips = data.clips.filter((c) => !ids.includes(c.id));
    selected.clear(); drawTools(); drawGrid(); drawSel();
    return true;
  }
  // menu col tasto destro su una clip
  function more(c, at) {
    document.querySelectorAll('.pp-menu').forEach((x) => x.remove());
    const m = h('div', { class: 'pp-menu', role: 'menu' });
    const close = () => { m.remove(); removeEventListener('pointerdown', out, true); removeEventListener('keydown', esc, true); menuClose = null; };
    const it = (ic, label, fn, cls) => h('button', { class: 'pp-mi' + (cls ? ' ' + cls : ''), type: 'button', role: 'menuitem', onclick: () => { close(); fn(); } }, icon(ic, 15, 'currentColor', 1.6), h('span', null, label));
    m.append(it('play', 'Guarda', () => player(c)), it('scissors', 'Apri nell\'editor', () => openClip(c)), it('expand', 'Allunga o accorcia', () => extendBox(c)),
      it('type', 'Rinomina', () => rename(c)), it('sparkle', 'Rifai questa clip', () => redoClip(c)), it('refresh', 'Aggiorna l\'anteprima', () => refresh([c.id])), it('upload', 'Esporta', () => exportClips([c.id])),
      h('div', { class: 'pp-msep' }), it('trash', 'Togli la clip', () => removeClips([c.id]), 'del'));
    m.style.left = Math.max(8, Math.min(innerWidth - 236, at.x)) + 'px';
    m.style.top = at.y + 'px';
    document.body.append(m);
    if (m.getBoundingClientRect().bottom > innerHeight - 8) m.style.top = Math.max(8, at.y - m.offsetHeight) + 'px';
    const out = (e) => { if (!m.contains(e.target)) close(); };
    const esc = (e) => { if (e.key === 'Escape') close(); };
    menuClose = close;
    setTimeout(() => { if (!m.isConnected) return; addEventListener('pointerdown', out, true); addEventListener('keydown', esc, true); }, 0);
  }

  // ---------------------------------------------------------------- anteprima della clip (13c)
  function player(c) {
    const list = visible();
    let idx = Math.max(0, list.findIndex((x) => x.id === c.id));
    const bg = h('div', { class: 'nfs-bg cr-bg' });
    const box = h('div', { class: 'nfs cr-modal', role: 'dialog', 'aria-modal': 'true' });
    let rangeT = null, pend = null, busy = false;
    const close = () => { clearTimeout(rangeT); if (pend) applyRange(); bg.remove(); removeEventListener('keydown', key, true); };
    const key = (e) => {
      const tg = (e.target.tagName || '').toLowerCase();
      if (e.key === 'Escape') { e.stopPropagation(); close(); return; }
      if (tg === 'textarea' || tg === 'input') return;
      if (e.key === 'ArrowRight') go(1); if (e.key === 'ArrowLeft') go(-1);
    };
    function go(d) { if (list.length < 2) return; if (pend) applyRange(); idx = (idx + d + list.length) % list.length; draw(); }
    // inizio e fine (±1 s): si applicano poco dopo l'ultimo clic, con la stessa funzione di "Allunga o accorcia"
    // una modifica alla volta: quella che arriva mentre l'altra si salva aspetta il suo turno (anche a scheda chiusa)
    async function applyRange() {
      const p = pend;
      if (!p) return;
      if (busy) { clearTimeout(rangeT); rangeT = setTimeout(applyRange, 600); return; }
      pend = null; busy = true;
      try { await setRange(p.c, p.a, p.b, null, false); } catch (e) { toast(e.message, true); }
      busy = false;
      // la clip aggiornata torna al suo posto nell'elenco (non in quello della clip che stai guardando adesso)
      const fresh = data.clips.find((x) => x.id === p.c.id), at = list.findIndex((x) => x.id === p.c.id);
      if (fresh && at >= 0) list[at] = fresh;
      if (bg.isConnected && fresh && at === idx && !(pend && pend.c.id === p.c.id)) draw();
    }
    function draw() {
      const x = list[idx];
      const D = +data.duration || 0;
      const media = x.preview ? h('video', { class: 'cr-mvid', src: mediaUrl(x.preview) + '&v=' + Math.round(x.previewAt || 0), poster: x.poster ? mediaUrl(x.poster) : null, controls: true, autoplay: true, playsinline: true })
        : h('div', { class: 'cg-mnone' }, h('img', { src: thumbUrl(pid, x.a + 1, 640), alt: '' }), h('span', null, 'L\'anteprima non è ancora pronta'));
      let a = x.a, b = x.b;
      const aV = h('b', { class: 'tnum' }, hms(a)), bV = h('b', { class: 'tnum' }, hms(b));
      const nudge = (which, d) => {
        if (which === 'a') a = Math.max(0, Math.min(b - 3, a + d)); else b = Math.min(D || b + d, Math.max(a + 3, b + d));
        aV.textContent = hms(a); bV.textContent = hms(b);
        pend = { c: x, a, b };
        clearTimeout(rangeT); rangeT = setTimeout(applyRange, 900);
      };
      const step = (lab, val, which) => h('div', { class: 'cr-step' }, h('span', { class: 'l' }, h('small', null, lab), val),
        h('button', { type: 'button', 'aria-label': lab + ' un secondo prima', 'data-tip': 'Un secondo prima', onclick: () => nudge(which, -1) }, '−'),
        h('button', { type: 'button', 'aria-label': lab + ' un secondo dopo', 'data-tip': 'Un secondo dopo', onclick: () => nudge(which, 1) }, '+'));
      // descrizione e hashtag: tuoi o scritti dall'AI (costa crediti: lo chiede prima)
      const desc = h('textarea', { class: 'cr-desc', rows: '3', placeholder: 'Scrivi la descrizione del post, oppure falla scrivere all\'AI', 'aria-label': 'Descrizione' });
      desc.value = x.desc || '';
      let tags = [...(x.tags || [])];
      const saveSocial = async (patch) => { try { const r = await post(`/api/p/${x.id}/clipsocial`, patch); x.desc = r.desc; x.tags = r.tags; if ('desc' in patch) x.socialAi = false; } catch (e) { toast(e.message, true); } };
      desc.addEventListener('change', () => saveSocial({ desc: desc.value }));
      const tagBox = h('div', { class: 'cr-tags' });
      const tagIn = h('input', { class: 'cr-tagin', placeholder: tags.length ? '' : 'Aggiungi un hashtag', 'aria-label': 'Aggiungi un hashtag' });
      const drawTags = () => tagBox.replaceChildren(...tags.map((t, i) => h('span', { class: 'cr-chip', 'data-notr': '' }, '#' + t,
        h('button', { type: 'button', 'aria-label': 'Togli #' + t, onclick: () => { tags.splice(i, 1); drawTags(); saveSocial({ tags }); } }, icon('x', 9, 'currentColor', 2.6)))), tagIn);
      tagIn.addEventListener('keydown', (e) => {
        if ((e.key === 'Enter' || e.key === ' ' || e.key === ',') && tagIn.value.trim()) { e.preventDefault(); tags.push(...tagIn.value.split(/[\s,]+/).map((t) => t.replace(/^#/, '').toLowerCase()).filter(Boolean)); tags = [...new Set(tags)]; tagIn.value = ''; drawTags(); saveSocial({ tags }); tagIn.focus(); }
        else if (e.key === 'Backspace' && !tagIn.value && tags.length) { tags.pop(); drawTags(); saveSocial({ tags }); }
      });
      drawTags();
      const copy = async (txt, what) => { try { await navigator.clipboard.writeText(txt); toast(what + ' copiata'); } catch (e) { toast('Non riesco a copiare: seleziona il testo e copialo a mano', true); } };
      // costo dal testo vero di questa clip (quello che l'AI leggera'), non una media
      const crOf = (e) => (e && !e.error && e.usd != null && e.credits ? Math.max(1, Math.ceil(e.usd * (e.perUsd || 320))) : null);
      const est = post(`/api/p/${x.id}/clipsocialcost`).catch(() => null);
      const aiBtn = h('button', { type: 'button', class: 'cr-mini', onclick: async () => {
        const e = await est;
        if (e && e.error) { toast(e.error, true); return; }
        const cr = crOf(e);
        const ok = await costConfirm(desc.value || tags.length ? 'Riscrivere con l\'AI?' : 'Scrivere con l\'AI?',
          'L\'AI legge quello che si dice nella clip e scrive descrizione e hashtag. Quelli di adesso vengono sostituiti.', 'Scrivi', cr || 0);
        if (!ok) return;
        aiBtn.disabled = true; aiBtn.textContent = 'Scrivo…';
        try {
          const j = await post(`/api/p/${x.id}/clipsocialai`, {});
          const r = await pollJob(j.id, () => {});
          if (r.status !== 'done') throw new Error(r.error || 'Descrizione non scritta');
          x.desc = r.result.desc; x.tags = r.result.tags; x.socialAi = true;
          if (bg.isConnected && list[idx] === x) { desc.value = x.desc; tags = [...x.tags]; drawTags(); }
          const n = r.result.charged;   // crediti scalati davvero
          if (n != null) toast(n === 1 ? 'Fatto · usato 1 credito' : 'Fatto · usati ' + n + ' crediti');
        } catch (e) { toast(e.message, true); }
        aiBtn.disabled = false; aiBtn.textContent = desc.value ? 'Riscrivi' : 'Scrivi con l\'AI';
      } }, desc.value || tags.length ? 'Riscrivi' : 'Scrivi con l\'AI');
      est.then((e) => { const cr = crOf(e); if (cr) aiBtn.dataset.tip = 'Con l\'AI · circa ' + cr + (cr === 1 ? ' credito' : ' crediti'); });
      const nameEl = h('h2', { 'data-notr': '', 'data-tip': 'Clic per rinominare', onclick: async () => { if (await rename(x)) nameEl.textContent = x.name; } }, x.name);
      box.replaceChildren(...[
        h('div', { class: 'cr-mstage' }, media),
        h('div', { class: 'cr-mside' },
          h('div', { class: 'cr-mh' }, h('div', { class: 'tt' }, nameEl, h('span', { class: 'tnum' }, hms(x.a) + ' → ' + hms(x.b) + ' · ' + mmss(x.dur))),
            list.length > 1 ? h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Clip precedente', 'data-tip': 'Clip precedente (←)', onclick: () => go(-1) }, icon('left', 14, 'currentColor', 2)) : null,
            list.length > 1 ? h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Clip successiva', 'data-tip': 'Clip successiva (→)', onclick: () => go(1) }, icon('right', 14, 'currentColor', 2)) : null,
            h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Chiudi', 'data-tip': 'Chiudi (Esc)', onclick: close }, icon('x', 13, 'currentColor', 2))),
          h('div', { class: 'cr-mbody' },
            h('div', { class: 'cr-why' }, h('b', { style: { color: scoreColor(x.score) } }, x.score != null ? String(x.score) : '–'), h('span', null, x.why || 'Clip creata da te: nessun punteggio dell\'AI.')),
            pfBox(x),
            h('div', { class: 'cr-lab' }, h('span', null, 'Inizio e fine'), h('button', { type: 'button', class: 'cr-link', onclick: () => { close(); extendBox(x); } }, 'Scegli nella live')),
            h('div', { class: 'cr-steps' }, step('Inizio', aV, 'a'), step('Fine', bV, 'b')),
            h('div', { class: 'cr-lab' }, h('span', null, 'Descrizione'), x.socialAi && x.desc ? h('span', { class: 'cr-ai', 'data-tip': 'Scritta dall\'AI' }, 'AI') : null, h('span', { class: 'grow' }), aiBtn,
              h('button', { type: 'button', class: 'cr-mini', onclick: () => copy(desc.value, 'Descrizione') }, icon('copy', 12, 'currentColor', 1.8), h('span', null, 'Copia'))),
            desc,
            h('div', { class: 'cr-lab' }, h('span', null, 'Hashtag'), h('small', null, 'a parte, se non li usi'), h('span', { class: 'grow' }),
              h('button', { type: 'button', class: 'cr-mini', onclick: () => copy(tags.map((t) => '#' + t).join(' '), 'Lista degli hashtag') }, icon('copy', 12, 'currentColor', 1.8), h('span', null, 'Copia'))),
            tagBox),
          h('div', { class: 'cr-mfoot' },
            h('button', { type: 'button', class: 'cr-mexp', onclick: () => { close(); exportClips([x.id]); } }, x.exported ? 'Esporta di nuovo' : 'Esporta la clip'),
            h('button', { type: 'button', class: 'cr-medit', onclick: () => { close(); openClip(x); } }, 'Apri nell\'editor'),
            h('div', { class: 'cr-mlinks' },
              h('button', { type: 'button', onclick: async () => { if (await redoClip(x)) close(); } }, icon('sparkle', 12, 'currentColor', 1.8), h('span', null, 'Rifai questa clip')),
              h('button', { type: 'button', onclick: () => { refresh([x.id]); toast('Rifaccio l\'anteprima'); } }, 'Aggiorna l\'anteprima'),
              h('button', { type: 'button', class: 'del', onclick: async () => { if (await removeClips([x.id])) close(); } }, 'Togli la clip'))))].filter(Boolean));
    }
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
    bg.append(box); document.body.append(bg); addEventListener('keydown', key, true); draw();
  }

  // ---------------------------------------------------------------- ricerca con l'AI e anteprime
  function showStatus(j, label) {
    status.style.display = '';
    const pct = Math.round((j.progress || 0) * 100);
    status.replaceChildren(...[h('span', { class: 'spinner sm' }),
      h('div', { class: 'cg-st-tx' }, h('b', null, label), h('span', null, j.message || '…')),
      h('div', { class: 'cg-st-bar' }, h('div', { style: { width: pct + '%' } })),
      h('span', { class: 'cg-st-pct' }, pct + '%'),
      j.kind === 'clips' ? h('button', { class: 'btn sm', onclick: () => post(`/api/jobs/${j.id}/cancel`).catch(() => {}) }, 'Annulla') : null].filter(Boolean));
  }
  // "Trova altre clip": cosa cercare, lingua (la prima volta) e il costo, poi lo stile; parte solo con la conferma
  function askSearch() {
    return new Promise((resolve) => {
      const bg = h('div', { class: 'nfs-bg' });
      const done = (v) => { bg.remove(); removeEventListener('keydown', k, true); resolve(v); };
      const k = (e) => { if (e.key === 'Escape') { e.stopPropagation(); done(null); } };
      const q = h('input', { class: 'nfs-in', type: 'text', maxlength: '300', value: (data.run && data.run.prompt) || '', placeholder: 'Es. spaventi, momenti divertenti, giocate epiche (facoltativo)', 'aria-label': 'Cosa cercare nella live' });
      const fl = h('select', { class: 'nfs-in', 'aria-label': 'Lingua della live' }, h('option', { value: '' }, 'Lingua automatica'),
        ...Object.entries(data.langs || { it: 'italiano', en: 'inglese' }).map(([kk, v]) => h('option', { value: kk, selected: kk === data.subLang ? true : null }, v.charAt(0).toUpperCase() + v.slice(1))));
      const has = data.clips.length > 0;
      const go = h('button', { class: 'nfs-go', type: 'button', onclick: () => done({ prompt: q.value.trim(), lang: has ? null : fl.value }) }, h('span', null, 'Avanti'), icon('right', 14, 'currentColor', 2.2));
      q.addEventListener('keydown', (e) => { if (e.key === 'Enter') go.click(); });
      bg.append(h('div', { class: 'nfs nuovo cr-ask', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Trova le clip' },
        h('div', { class: 'nfs-head' }, h('span', { class: 'nfs-hic' }, icon('sparkle', 19, 'var(--tx)', 1.6)),
          h('span', { class: 'nfs-ht' }, h('b', null, has ? 'Trova altre clip' : 'Trova le clip'), h('span', null, has ? 'Le clip dell\'AI che non hai modificato vengono sostituite. Quelle che hai modificato restano.' : 'L\'AI ascolta la live e monta in verticale i momenti migliori.')),
          h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Chiudi', onclick: () => done(null) }, icon('x', 13, 'currentColor', 2))),
        h('label', { class: 'nfs-field' }, h('span', null, 'Cosa cercare'), q),
        has ? null : h('label', { class: 'nfs-field' }, h('span', null, 'Lingua della live'), fl),
        costRow((estP || Promise.resolve(est)).then((e) => (e && e.credits) || 0), () => done(null)),
        h('div', { class: 'nfs-nfoot' }, h('span', { class: 'nfs-nsum tnum' }, est ? 'Circa ' + est.target + ' clip' + (est.hasTranscript ? '' : ' · prima la trascrivo (gratis)') : ''),
          h('button', { class: 'nfs-cancel', type: 'button', onclick: () => done(null) }, 'Annulla'), go)));
      addEventListener('keydown', k, true);
      document.body.append(bg);
      setTimeout(() => q.focus(), 50);
    });
  }
  async function start() {
    if (job) return;
    const ask = await askSearch();
    if (!ask || !alive) return;
    if (!await lookBox({ search: true })) return;   // i passaggi iniziali: come escono le clip
    if (job || !alive) return;
    const body = { prompt: ask.prompt };
    if (ask.lang != null) body.lang = ask.lang;   // con le clip gia' fatte la lingua si cambia dal menu della galleria
    try { job = await post(`/api/p/${pid}/clips`, body); } catch (e) { return toast(e.message, true); }
    // le anteprime in corso sono delle clip che stanno per essere sostituite: si fermano, cosi' si vede solo la ricerca
    if (pjob) post(`/api/jobs/${pjob.id}/cancel`).catch(() => {});
    queued.clear();
    await follow();
  }
  async function follow() {
    if (!job) return;
    drawTools(); drawGrid();
    showStatus(job, 'L\'AI cerca le clip');
    // le clip compaiono una alla volta, appena sono montate (le anteprime si preparano alla fine)
    let shown = '', loading = false;
    const onJob = (j) => {
      if (!alive) return;
      showStatus(j, 'L\'AI cerca le clip');
      // quando parte il montaggio (le clip vecchie da sostituire spariscono) e a ogni clip pronta
      const key = /^Monto la clip/.test(j.message || '') ? (j.made || 0) + '|' + j.message : '';
      if (key && key !== shown && !loading) {
        shown = key; loading = true;
        post(`/api/p/${pid}/cliplist`).then((d) => { if (alive && job) { data = d; drawTools(); drawGrid(); } }).catch(() => {}).finally(() => { loading = false; });
      }
    };
    let r;
    try { r = await pollJob(job.id, onJob); } catch (e) { r = { status: 'error', error: e.message }; }
    job = null;
    if (!alive) return;
    status.style.display = 'none';
    if (r.status === 'cancelled' && r.refunded) toast(r.refunded === 1 ? 'Annullato: ti ho restituito 1 credito' : 'Annullato: ti ho restituito ' + r.refunded + ' crediti');
    if (r.status !== 'done') { if (r.error && !/annullat/i.test(r.error) && r.status !== 'cancelled') toast(r.error, true); await reload(); return; }
    toast(`${(r.result.clips || []).length} clip pronte da guardare`);
    await reload();
    await previews();
  }
  async function reload() {
    try { data = await post(`/api/p/${pid}/cliplist`); } catch (e) { return; }
    if (alive) { drawTools(); drawGrid(); drawSel(); }
  }
  async function refresh(ids) {
    for (const id of ids) {
      try { await bakeHooks(id); } catch (e) { /* */ }
    }
    await previews(ids);
  }
  // anteprime: prima le scritte d'apertura (le disegna l'app), poi i video leggeri, che compaiono uno alla volta
  const tried = new Set();   // anteprime gia' provate in questa visita (se una non riesce non si riprova all'infinito)
  async function previews(only) {
    if (job) return;   // mentre l'AI cerca le clip non si preparano anteprime (le fa alla fine)
    const need = (only || data.clips.filter((c) => (!c.preview || c.stale || c.needsBake) && !tried.has(c.id + ':' + (c.updated || 0))).map((c) => c.id))
      .filter((id) => data.clips.some((c) => c.id === id));
    if (!need.length) return;
    if (pjob) { need.forEach((id) => queued.add(id)); drawGrid(); return; }   // dopo quelle in corso
    for (const id of need) {
      const c = data.clips.find((x) => x.id === id);
      if (c && c.needsBake) { try { await bakeHooks(id); } catch (e) { console.warn(e); } }
    }
    if (pjob) return;
    need.forEach((id) => { working.add(id); const c = data.clips.find((x) => x.id === id); if (c) tried.add(c.id + ':' + (c.updated || 0)); });
    drawGrid();
    try { pjob = await post(`/api/p/${pid}/clippreview`, { ids: need }); } catch (e) { working.clear(); return toast(e.message, true); }
    await followPrev();
  }
  async function followPrev() {
    if (!pjob) return;
    let lastDone = -1;
    if (!job) showStatus(pjob, 'Preparo le anteprime');
    const timer = setInterval(async () => {
      try {
        const d = await post(`/api/p/${pid}/cliplist`);
        if (!alive || job) return;
        const ready = d.clips.filter((c) => c.preview && !c.stale && working.has(c.id)).map((c) => c.id);   // un'anteprima vecchia da rifare non e' pronta
        if (ready.length !== lastDone) { lastDone = ready.length; ready.forEach((id) => working.delete(id)); data = d; drawGrid(); }
      } catch (e) { /* */ }
    }, 4000);
    try { await pollJob(pjob.id, (j) => { if (alive && !job) showStatus(j, 'Preparo le anteprime'); }); } catch (e) { /* */ }
    clearInterval(timer);
    pjob = null; working.clear();
    if (!alive || job) return;   // c'e' una ricerca in corso: lo stato lo mostra lei
    status.style.display = 'none';
    await reload();
    const next = [...queued].filter((id) => data.clips.some((c) => c.id === id && (!c.preview || c.stale || c.needsBake)));
    queued.clear();
    if (next.length) await previews(next);
  }

  let menuClose = null;
  // clip che si stanno esportando (anche con il foglio chiuso): l'etichetta sull'anteprima
  function expBadges() {
    for (const e of exportsOf(pid)) {
      for (const id of e.ids) {
        const pv = grid.querySelector('.cr-card[data-id="' + id + '"] .cr-pv');
        if (!pv) continue;
        let b = pv.querySelector('.cg-exp');
        if (e.status === 'error') { if (b) b.remove(); continue; }
        if (!b) { b = h('span', { class: 'cg-exp' }); pv.append(b); }
        const t = e.status === 'done' ? 'Esportata' : e.queued ? 'In coda' : e.p < 0.01 ? 'Preparo…' : 'Esporto ' + Math.round(e.p * 100) + '%';
        if (b.textContent !== t) b.textContent = t;
        b.classList.toggle('ok', e.status === 'done');
      }
    }
  }
  const onExport = (ev) => { if (ev.detail && ev.detail.pid === pid) expBadges(); };
  addEventListener('nf-export', onExport);
  setCleanup(() => { alive = false; removeEventListener('nf-export', onExport); if (menuClose) menuClose(); document.querySelectorAll('.pp-menu, .cr-bg').forEach((x) => x.remove()); });
  drawTools(); drawGrid(); drawSel();
  loadEst();
  if (job && pjob) { post(`/api/jobs/${pjob.id}/cancel`).catch(() => {}); pjob = null; }   // una cosa alla volta: prima la ricerca
  if (job) follow();
  else if (pjob) followPrev();
  else if (data.clips.some((c) => !c.preview || c.stale || c.needsBake)) previews();
}
