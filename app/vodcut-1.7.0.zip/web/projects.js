// Rebrand: progetti. Miniatura comune (Home "Recenti" e pagina Progetti) e pagina Progetti (16a): cartelle, ricerca,
// ordine, griglia/lista, filtri per tipo, selezione multipla (Sposta, Duplica, Nel cestino con Annulla), cestino 30 giorni.
import { h, get, post, api, icon, fmt, toast, confirmBox, promptBox, TOKEN } from './lib.js';
import { shellDirty, allFolders, newFolder, renameFolder, deleteFolder } from './shell.js';

export const ratioLabel = (w, hh) => {
  const r = w / hh;
  for (const [k, v] of [['16:9', 16 / 9], ['9:16', 9 / 16], ['1:1', 1], ['4:5', 0.8], ['4:3', 4 / 3], ['21:9', 21 / 9]]) if (Math.abs(r - v) < 0.03) return k;
  return r > 1 ? '16:9' : '9:16';
};
export const ago = (ts) => {
  const d = (Date.now() / 1000 - ts);
  if (d < 90) return 'adesso';
  if (d < 3600) return Math.round(d / 60) + ' min fa';
  if (d < 86400) return Math.round(d / 3600) + (Math.round(d / 3600) === 1 ? ' ora fa' : ' ore fa');
  if (d < 172800) return 'ieri';
  if (d < 7 * 86400) return Math.round(d / 86400) + ' giorni fa';
  if (d < 14 * 86400) return '1 settimana fa';
  if (d < 35 * 86400) return Math.round(d / (7 * 86400)) + ' settimane fa';
  return new Date(ts * 1000).toLocaleDateString([], { day: 'numeric', month: 'short' });
};
// tipo per i filtri: Live (VOD), Video (montaggio), Clip (verticali o progetti 9:16)
export const typeOf = (p) => (p.kind === 'vod' ? 'live' : (p.aw || 16) < (p.ah || 9) ? 'clip' : 'video');
const TYPE_NAME = { live: 'Live', video: 'Video', clip: 'Clip' };
const fmtIcon = (p) => h('i', { class: 'pj-fi', style: { aspectRatio: (p.aw || 16) + ' / ' + (p.ah || 9) } });

// miniatura 16:10 che contiene il formato vero del progetto
export function thumb(p, extra) {
  const frame = h('div', { class: 'pj-frame', style: { aspectRatio: (p.aw || 16) + ' / ' + (p.ah || 9) } });
  if (p.cover === false) frame.classList.add('empty');   // progetto vuoto: ancora niente da mostrare
  else if (p.exists !== false) {
    const im = h('img', { src: `/api/p/${p.id}/cover?token=${TOKEN}&v=${Math.round(p.updated || 0)}`, alt: '', loading: 'lazy', decoding: 'async', draggable: 'false' });
    im.addEventListener('error', () => { im.remove(); frame.classList.add('empty'); });
    frame.append(im);
  } else { frame.classList.add('empty', 'missing'); frame.append(h('span', { class: 'pj-miss' }, 'File non trovato')); }
  return h('div', { class: 'pj-shot' + ((p.aw || 16) < (p.ah || 9) ? ' v' : '') }, frame, ...(extra || []));
}

// Home "Recenti": miniatura, nome, formato · durata · quando. Con acts, al passaggio del mouse compaiono in alto a
// destra le azioni rapide (come nel prototipo): sposta in una cartella, rinomina, passa a un altro PC, nel cestino
export function recentCard(p, open, acts) {
  const bar = acts ? h('div', { class: 'pj-acts' },
    qa('folder', 'Sposta in una cartella', (b) => acts.move(b)), qa('pen', 'Rinomina', () => acts.rename()),
    qa('share', 'Passa a un altro PC', () => acts.share()), qa('trash', 'Nel cestino', () => acts.trash(), 'del')) : null;
  const el = h('div', { class: 'pj-rc', role: 'button', tabindex: '0', onclick: () => open(p) },
    thumb(p, bar ? [bar] : null),
    h('b', { class: 'pj-nm', 'data-notr': '' }, p.name),
    h('span', { class: 'pj-meta' }, fmtIcon(p), h('span', null, ratioLabel(p.aw || 16, p.ah || 9)), p.duration > 0.5 ? h('span', null, '·') : null,
      p.duration > 0.5 ? h('span', { class: 'tnum' }, fmt(p.duration)) : null, h('span', null, '·'), h('span', null, ago(p.updated))));
  el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target === el) open(p); });
  return el;
}
const qa = (ic, tip, fn, cls) => h('button', { type: 'button', class: cls || null, 'aria-label': tip, 'data-tip': tip, onclick: (e) => { e.stopPropagation(); fn(e.currentTarget); } },
  icon(ic, 14, 'currentColor', 1.8));

// menu che si apre da un tasto (up: sopra, per la barra in basso; at: dove si e' cliccato col tasto destro)
function popMenu(anchor, items, up, at) {
  closeMenus();
  const r = at ? { left: at.x, right: at.x + 228, top: at.y, bottom: at.y } : anchor.getBoundingClientRect();
  const m = h('div', { class: 'pp-menu', role: 'menu' }, ...items.filter(Boolean));
  m.style.left = Math.max(8, Math.min(innerWidth - 236, up || at ? r.left : r.right - 228)) + 'px';
  if (up) m.style.bottom = (innerHeight - r.top + 8) + 'px'; else m.style.top = (r.bottom + 6) + 'px';
  document.body.append(m);
  if (!up && m.getBoundingClientRect().bottom > innerHeight - 8) { m.style.top = ''; m.style.bottom = (innerHeight - r.top + 6) + 'px'; }
  const off = (e) => { if (!m.contains(e.target) && !anchor.contains(e.target)) closeMenus(); };
  m._off = () => document.removeEventListener('pointerdown', off, true);
  setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  return m;
}
const mi = (ic, label, fn, cls) => h('button', { class: 'pp-mi' + (cls ? ' ' + cls : ''), type: 'button', role: 'menuitem', onclick: (e) => { e.stopPropagation(); closeMenus(); fn(); } },
  icon(ic, 15, 'currentColor', 1.6), h('span', null, label));
// "Sposta in": le cartelle, una nuova, oppure fuori da ogni cartella
function moveItems(list, ids, onMove) {
  return [h('div', { class: 'pp-mh' }, 'Sposta in'),
    ...allFolders(list).map((f) => h('button', { class: 'pp-mi', type: 'button', role: 'menuitem', onclick: (e) => { e.stopPropagation(); closeMenus(); onMove(f); } }, icon('folder', 15, 'currentColor', 1.6), h('span', { 'data-notr': '' }, f))),
    mi('plus', 'Nuova cartella…', async () => { const nm = await newFolder(); if (nm) onMove(nm); }),
    list.some((p) => ids.includes(p.id) && p.folder) ? mi('x', 'Nessuna cartella', () => onMove('')) : null];
}
// avviso con "Annulla" (per le azioni rapide della Home)
function undoToast(msg, undo) {
  const el = h('div', { class: 'toast pj-undo' }, h('span', null, msg),
    h('button', { type: 'button', onclick: async () => { el.remove(); try { await undo(); } catch (e) { toast(e.message, true); } } }, 'Annulla'));
  document.getElementById('toasts').append(el);
  setTimeout(() => el.remove(), 6000);
}
async function askRename(p) {
  const nm = await promptBox('Rinomina il video', 'È anche il nome del file quando lo esporti.', p.name, 'Rinomina');
  if (!nm || !nm.trim() || nm.trim() === p.name) return false;
  await post(`/api/p/${p.id}/meta`, { name: nm.trim() });
  return true;
}
// azioni rapide di una miniatura della Home. list(): tutti i progetti; done(): ridisegna dopo un cambio
export function quickActs(p, { list, share, done }) {
  const run = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } shellDirty(); done(); };
  return {
    move: (btn) => popMenu(btn, moveItems(list(), [p.id], run(async (f) => {
      const was = p.folder || '';
      await post(`/api/p/${p.id}/meta`, { folder: f });
      undoToast(f ? 'Spostati in ' + f : 'Tolti dalla cartella', run(() => post(`/api/p/${p.id}/meta`, { folder: was })));
    }))),
    rename: run(async () => { if (await askRename(p)) toast('Rinominato'); }),
    share: () => share(p.id, p.name),
    trash: run(async () => {
      await api('DELETE', '/api/p/' + p.id);
      undoToast('Progetto nel cestino: lo recuperi per 30 giorni', run(() => post('/api/trash/restore', { id: p.id })));
    }),
  };
}

// ---------------------------------------------------------------------------------------------- pagina Progetti
const SORTS = [['recent', 'Recenti'], ['name', 'Nome'], ['dur', 'Durata']];
const KINDS = [['all', 'Tutti'], ['live', 'Live'], ['video', 'Video'], ['clip', 'Clip']];
const ls = (k, d) => { try { return localStorage.getItem(k) || d; } catch (e) { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* */ } };
const nOf = (n, one, many) => (n === 1 ? '1 ' + one : n + ' ' + many);
const leftLabel = (d) => (d <= 1 ? 'Si elimina domani' : 'Si elimina tra ' + d + ' giorni');
function closeMenus() { document.querySelectorAll('.pp-menu').forEach((m) => { if (m._off) m._off(); m.remove(); }); }

// ctx: { where: {folder?, trash?}, nav, open(p), share(id, name), onSide(): ridisegna la barra laterale }
export function projectsPage(ctx) {
  const trash = !!ctx.where.trash, folder = ctx.where.folder || '';
  const S = { list: [], bin: [], q: '', sort: ls('nf-proj-sort', 'recent'), view: ls('nf-proj-view', 'grid'), kind: 'all', sel: new Set(), loaded: false };
  if (!SORTS.some(([k]) => k === S.sort)) S.sort = 'recent';
  if (S.view !== 'list') S.view = 'grid';

  // ---- header fisso: breadcrumb, ricerca, ordine, vista (non si sposta quando cambia la vista)
  const count = h('span', { class: 'pp-cnt' });
  const crumb = h('div', { class: 'pp-crumb' },
    h('span', { class: 'pp-root' + (trash || folder ? ' link' : ''), onclick: () => { if (trash || folder) ctx.nav('projects'); } }, 'Progetti'),
    trash || folder ? icon('right', 16, 'var(--t3)', 1.8) : null,
    trash ? h('span', null, 'Cestino') : folder ? h('span', { 'data-notr': '' }, folder) : null,
    count);
  const qIn = h('input', { class: 'pp-qin', type: 'text', placeholder: 'Cerca un progetto', 'aria-label': 'Cerca un progetto' });
  const clearQ = () => { qIn.value = ''; S.q = ''; qX.hidden = true; paint(); };
  const qX = h('button', { class: 'pp-qx', type: 'button', 'aria-label': 'Togli la ricerca', hidden: true, onclick: () => { clearQ(); qIn.focus(); } }, icon('x', 10, 'currentColor', 2.4));
  qIn.addEventListener('input', () => { S.q = qIn.value; qX.hidden = !S.q; paint(); });
  qIn.addEventListener('keydown', (e) => { if (e.key === 'Escape' && qIn.value) { e.stopPropagation(); clearQ(); } });
  const search = h('label', { class: 'pp-q' }, icon('search', 15, 'var(--t2)', 1.7), qIn, qX);
  const seg = (items, cur, pick) => {
    const box = h('div', { class: 'pp-seg' });
    const draw = (v) => box.replaceChildren(...items.map(([k, label, ic]) => h('button', { type: 'button', class: k === v ? 'on' : '', 'aria-label': ic ? label : null, 'data-tip': ic ? label : null, onclick: () => { pick(k); draw(k); } },
      ic ? icon(ic, 14, 'currentColor', 1.7) : label)));
    draw(cur);
    return box;
  };
  const sortSeg = seg(SORTS, S.sort, (k) => { S.sort = k; lsSet('nf-proj-sort', k); paint(); });
  const viewSeg = seg([['grid', 'Griglia', 'apps'], ['list', 'Lista', 'list']], S.view, (k) => { S.view = k; lsSet('nf-proj-view', k); paint(); });
  const head = h('header', { class: 'pp-head' }, crumb, h('div', { class: 'grow' }), search, sortSeg, viewSeg);

  const body = h('div', { class: 'pp-body' });
  const bar = h('div', { class: 'pp-bar', hidden: true });
  const note = h('div', { class: 'pp-toast', hidden: true, role: 'status' });
  const root = h('div', { class: 'pp' + (trash ? ' trash' : '') }, head, body, bar, note);

  // ---- avviso in alto con "Annulla"
  let noteT = null;
  function flash(msg, undo) {
    clearTimeout(noteT);
    note.replaceChildren(...[icon('check', 14, 'var(--ok)', 2.2), h('span', null, msg),
      undo ? h('button', { type: 'button', class: 'pp-undo', onclick: async () => { note.hidden = true; try { await undo(); } catch (e) { toast(e.message, true); } await reload(); } }, 'Annulla') : null].filter(Boolean));   // senza Annulla niente "null" in fondo
    note.hidden = false;
    note.classList.remove('in'); void note.offsetWidth; note.classList.add('in');
    noteT = setTimeout(() => { note.hidden = true; }, undo ? 6000 : 3200);
  }

  async function reload() {
    try {
      const [l, t] = await Promise.all([get('/api/projects'), get('/api/trash')]);
      S.list = l; S.bin = t;
    } catch (e) { toast(e.message, true); }
    S.loaded = true;
    const ids = new Set((trash ? S.bin : S.list).map((p) => p.id));
    for (const id of [...S.sel]) if (!ids.has(id)) S.sel.delete(id);
    shellDirty();
    if (ctx.onSide) ctx.onSide();
    paint();
  }

  // ---- azioni (sempre sul server; "Annulla" rifa' il contrario)
  const many = (ids, fn) => Promise.all(ids.map(fn));
  async function moveTo(ids, f) {
    const prev = S.list.filter((p) => ids.includes(p.id)).map((p) => [p.id, p.folder || '']);
    await many(ids, (id) => post(`/api/p/${id}/meta`, { folder: f }));
    S.sel.clear(); await reload();
    flash(f ? 'Spostati in ' + f : 'Tolti dalla cartella', () => many(prev, ([id, was]) => post(`/api/p/${id}/meta`, { folder: was })));
  }
  async function duplicate(ids) {
    const made = await many(ids, (id) => post(`/api/p/${id}/duplicate`, {}));
    S.sel.clear(); await reload();
    flash(ids.length === 1 ? 'Progetto duplicato' : ids.length + ' progetti duplicati',
      () => many(made.map((r) => r.id), async (id) => { await api('DELETE', '/api/p/' + id); await post('/api/trash/purge', { id }); }));
  }
  async function toTrash(ids) {
    await many(ids, (id) => api('DELETE', '/api/p/' + id));
    S.sel.clear(); await reload();
    flash((ids.length === 1 ? 'Progetto nel cestino' : ids.length + ' progetti nel cestino') + ': lo recuperi per 30 giorni',
      () => many(ids, (id) => post('/api/trash/restore', { id })));
  }
  async function restore(ids) {
    await many(ids, (id) => post('/api/trash/restore', { id }));
    S.sel.clear(); await reload();
    flash(ids.length === 1 ? '1 progetto ripristinato' : ids.length + ' progetti ripristinati', () => many(ids, (id) => api('DELETE', '/api/p/' + id)));
  }
  async function purge(ids) {
    const ok = await confirmBox('Eliminare per sempre?', ids.length === 1 ? 'Il progetto non si potrà più recuperare. I video sul computer restano.'
      : `I ${ids.length} progetti non si potranno più recuperare. I video sul computer restano.`, 'Elimina per sempre', true);
    if (!ok) return;
    await many(ids, (id) => post('/api/trash/purge', { id }));
    S.sel.clear(); await reload();
    flash('Eliminati per sempre');
  }
  async function emptyTrash() {
    if (!S.bin.length) return;
    if (!(await confirmBox('Svuotare il cestino?', 'I progetti nel cestino spariscono per sempre. I video sul computer restano.', 'Svuota il cestino', true))) return;
    await post('/api/trash/purge', { all: true });
    S.sel.clear(); await reload();
    flash('Cestino svuotato');
  }
  async function rename(p) {
    if (!(await askRename(p))) return;
    await reload();
    flash('Rinominato');
  }
  // cartelle: rinomina ed elimina (i progetti restano, escono solo dalla cartella)
  async function renameF(f) {
    const nm = await promptBox('Rinomina la cartella', null, f, 'Rinomina');
    if (!(await renameFolder(f, nm, S.list))) return;
    await reload();
    flash('Cartella rinominata');
  }
  async function deleteF(f) {
    if (!(await deleteFolder(f, S.list))) return;
    await reload();
    flash('Cartella eliminata');
  }
  const run = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); await reload(); } };

  // ---- menu: "Sposta in" (dalla barra di selezione) e il menu "..." di un progetto
  const moveIds = (ids) => moveItems(S.list, ids, (f) => run(moveTo)(ids, f));
  function folderMenu(anchor, f, at) {
    popMenu(anchor, [mi('right', 'Apri', () => ctx.nav('projects', 'f:' + f)), mi('pen', 'Rinomina', () => run(renameF)(f)),
      h('div', { class: 'pp-msep' }), mi('trash', 'Elimina la cartella', () => run(deleteF)(f), 'del')], false, at);
  }
  function projectMenu(anchor, p, at) {
    const items = trash ? [
      mi('restore', 'Ripristina', () => run(restore)([p.id])),
      h('div', { class: 'pp-msep' }),
      mi('trash', 'Elimina per sempre', () => run(purge)([p.id]), 'del')]
      : [
        mi('right', 'Apri', () => ctx.open(p)),
        p.aiClips ? mi('sparkle', 'Apri le clip virali', () => ctx.nav('clips', p.id)) : null,
        mi('pen', 'Rinomina', () => run(rename)(p)),
        mi('duplicate', 'Duplica', () => run(duplicate)([p.id])),
        h('button', { class: 'pp-mi', type: 'button', role: 'menuitem', onclick: (e) => { e.stopPropagation(); const m = document.querySelector('.pp-menu'); if (m) m.replaceChildren(...moveIds([p.id]).filter(Boolean)); } },
          icon('move', 15, 'currentColor', 1.6), h('span', null, 'Sposta in una cartella'), icon('right', 13, 'var(--t3)', 1.8)),
        mi('share', 'Passa a un altro PC', () => ctx.share(p.id, p.name)),
        h('div', { class: 'pp-msep' }),
        mi('trash', 'Nel cestino', () => run(toTrash)([p.id]), 'del')];
    popMenu(anchor, items, false, at);
  }

  // ---- selezione multipla
  const toggle = (id) => { if (S.sel.has(id)) S.sel.delete(id); else S.sel.add(id); paint(); };
  function paintBar() {
    if (!S.sel.size) { if (!bar.hidden) { bar.hidden = true; closeMenus(); } return; }
    const ids = [...S.sel];
    const act = (ic, label, fn, cls) => h('button', { type: 'button', class: 'pp-act' + (cls ? ' ' + cls : ''), onclick: (e) => fn(e.currentTarget) }, icon(ic, 14, 'currentColor', 1.7), h('span', null, label));
    bar.replaceChildren(h('span', { class: 'pp-seln' }, S.sel.size === 1 ? '1 selezionato' : S.sel.size + ' selezionati'),
      ...(trash ? [act('restore', 'Ripristina', () => run(restore)(ids)), act('trash', 'Elimina per sempre', () => run(purge)(ids), 'del')]
        : [act('move', 'Sposta', (b) => popMenu(b, moveIds(ids), true)), act('duplicate', 'Duplica', () => run(duplicate)(ids)), act('trash', 'Nel cestino', () => run(toTrash)(ids), 'del')]),
      h('button', { type: 'button', class: 'pp-act x', 'aria-label': 'Deseleziona', 'data-tip': 'Deseleziona', onclick: () => { S.sel.clear(); paint(); } }, icon('x', 13, 'currentColor', 2)));
    if (bar.hidden) { note.hidden = true; bar.hidden = false; bar.classList.remove('in'); void bar.offsetWidth; bar.classList.add('in'); }
  }

  // ---- contenuto
  function shownList() {
    let l = trash ? S.bin : S.list.filter((p) => (folder ? p.folder === folder : true));
    const base = l;
    if (!trash && S.kind !== 'all') l = l.filter((p) => typeOf(p) === S.kind);
    const q = S.q.trim().toLowerCase();
    if (q) l = l.filter((p) => (p.name || '').toLowerCase().includes(q));
    const by = { recent: (a, b) => (trash ? b.trashedAt - a.trashedAt : b.updated - a.updated), name: (a, b) => (a.name || '').localeCompare(b.name || ''), dur: (a, b) => (b.duration || 0) - (a.duration || 0) };
    return { base, list: [...l].sort(by[S.sort]) };
  }
  const check = (p, on) => h('span', { class: 'pp-chk' + (on ? ' on' : ''), role: 'checkbox', 'aria-checked': on ? 'true' : 'false', 'aria-label': 'Seleziona', onclick: (e) => { e.stopPropagation(); toggle(p.id); } },
    icon('check', 11, '#fff', 3));
  const more = (p) => h('button', { class: 'pp-more', type: 'button', 'aria-label': 'Altre azioni', 'data-tip': 'Altre azioni', onclick: (e) => { e.stopPropagation(); projectMenu(e.currentTarget, p); } }, icon('dots', 16, 'currentColor', 1.8));
  const when = (p) => (trash ? leftLabel(p.daysLeft) : ago(p.updated));
  const clipsBadge = (p) => (!trash && (p.aiClips || p.verticals) ? h('span', { class: 'pp-clips' + (p.aiClips ? ' go' : ''), 'data-tip': p.aiClips ? 'Apri le clip virali' : null,
    onclick: p.aiClips ? (e) => { if (S.sel.size) return; e.stopPropagation(); ctx.nav('clips', p.id); } : null }, (p.aiClips || p.verticals) + ' clip') : null);
  function onCard(p, e) {
    if (S.sel.size || trash || e.ctrlKey || e.metaKey || e.shiftKey) { toggle(p.id); return; }
    ctx.open(p);
  }
  const keys = (el, p) => {
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target === el) onCard(p, e); });
    el.addEventListener('contextmenu', (e) => { e.preventDefault(); projectMenu(el, p, { x: e.clientX, y: e.clientY }); });
    return el;
  };
  function card(p) {
    const on = S.sel.has(p.id);
    const shot = thumb(p, [check(p, on), clipsBadge(p), p.duration > 0.5 ? h('span', { class: 'pp-dur tnum' }, fmt(p.duration)) : null].filter(Boolean));
    const inFolder = p.folder && !folder && !trash;
    return keys(h('div', { class: 'pp-card' + (on ? ' on' : ''), role: 'button', tabindex: '0', onclick: (e) => onCard(p, e) },
      shot,
      h('div', { class: 'pp-info' },
        h('div', { class: 'pp-nmrow' }, h('b', { class: 'pp-nm', 'data-notr': '' }, p.name), more(p)),
        h('span', { class: 'pp-meta' }, fmtIcon(p), h('span', null, TYPE_NAME[typeOf(p)]), h('span', { class: 'sep' }, '·'), h('span', null, when(p)),
          inFolder ? h('span', { class: 'sep' }, '·') : null, inFolder ? h('span', { class: 'fd', 'data-notr': '' }, p.folder) : null))), p);
  }
  function row(p) {
    const on = S.sel.has(p.id);
    return keys(h('div', { class: 'pp-row' + (on ? ' on' : ''), role: 'button', tabindex: '0', onclick: (e) => onCard(p, e) },
      check(p, on),
      h('span', { class: 'pp-rn' }, h('span', { class: 'pp-rshot' }, thumb(p)), h('b', { 'data-notr': '' }, p.name), clipsBadge(p)),
      h('span', null, TYPE_NAME[typeOf(p)]),
      h('span', { class: 'tnum' }, ratioLabel(p.aw || 16, p.ah || 9)),
      h('span', { class: 'tnum' }, p.duration > 0.5 ? fmt(p.duration) : '—'),
      p.folder ? h('span', { 'data-notr': '' }, p.folder) : h('span', null, '—'),
      h('span', null, when(p)),
      more(p)), p);
  }
  function empty(q) {
    const [ic, t, s] = q ? ['search', 'Nessun progetto con «' + S.q.trim() + '»', folder ? 'Controlla il nome o cerca in tutte le cartelle' : 'Controlla il nome e riprova']
      : trash ? ['trash', 'Il cestino è vuoto', 'I progetti che elimini restano qui per 30 giorni']
        : folder ? ['folder', 'Questa cartella è vuota', 'Seleziona dei progetti e usa "Sposta" per metterli qui']
          : S.kind !== 'all' ? ['apps', 'Nessun progetto di questo tipo', 'Scegli "Tutti" per vederli tutti']
            : ['film', 'Ancora nessun progetto', 'Torna alla Home e incolla un link: in pochi minuti hai le prime clip'];
    return h('div', { class: 'pp-empty' }, h('span', { class: 'pp-eic' }, icon(ic, 22, 'var(--t2)', 1.6)), h('b', null, t), h('span', null, s),
      q ? h('button', { type: 'button', class: 'pp-ebtn', onclick: clearQ }, 'Togli la ricerca')
        : folder && S.list.length ? h('button', { type: 'button', class: 'pp-ebtn', onclick: () => ctx.nav('projects') }, 'Tutti i progetti')
          : !trash && !folder && S.kind === 'all' ? h('button', { type: 'button', class: 'pp-ebtn', onclick: () => ctx.nav('home') }, 'Vai alla Home') : null);
  }
  function paint() {
    if (!S.loaded) return;
    const { base, list } = shownList();
    count.textContent = String(list.length);
    const parts = [];
    if (!trash) {
      parts.push(h('div', { class: 'pp-filters' }, ...KINDS.map(([k, label]) => h('button', { type: 'button', class: S.kind === k ? 'on' : '', onclick: () => { S.kind = k; paint(); } },
        h('span', null, label), h('span', { class: 'n' }, String(k === 'all' ? base.length : base.filter((p) => typeOf(p) === k).length))))));
    }
    if (!trash && !folder && !S.q.trim()) {
      parts.push(h('div', { class: 'pp-folders' }, ...allFolders(S.list).map((f) => {
        const ps = S.list.filter((p) => p.folder === f);
        const last = ps.length ? Math.max(...ps.map((p) => p.updated || 0)) : 0;
        // al passaggio del mouse: Rinomina ed Elimina (come nella barra laterale); tasto destro: lo stesso menu
        const fc = h('div', { class: 'pp-fcard', role: 'button', tabindex: '0', onclick: () => ctx.nav('projects', 'f:' + f) },
          h('span', { class: 'pp-fic' }, icon('folder', 17, 'currentColor', 1.6)),
          h('span', { class: 'pp-ftx' }, h('b', { 'data-notr': '' }, f), h('span', null, nOf(ps.length, 'progetto', 'progetti') + (last ? ' · ' + ago(last) : ''))),
          h('span', { class: 'pp-fact' }, qa('pen', 'Rinomina', () => run(renameF)(f)), qa('trash', 'Elimina la cartella', () => run(deleteF)(f), 'del')));
        fc.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target === fc) ctx.nav('projects', 'f:' + f); });
        fc.addEventListener('contextmenu', (e) => { e.preventDefault(); folderMenu(fc, f, { x: e.clientX, y: e.clientY }); });
        return fc;
      }), h('button', { type: 'button', class: 'pp-fcard add', onclick: async () => { const nm = await newFolder(); if (nm) { await reload(); flash('Cartella creata'); } } },
        icon('plus', 14, 'currentColor', 2), h('span', null, 'Nuova cartella'))));
    }
    if (trash) {
      parts.push(h('div', { class: 'pp-tinfo' }, icon('clock', 14, 'currentColor', 1.7),
        h('span', { class: 'grow' }, 'I progetti eliminati restano qui 30 giorni, poi spariscono da soli. I video sul computer restano.'),
        h('button', { type: 'button', class: 'pp-tempty', disabled: !S.bin.length, onclick: run(emptyTrash) }, 'Svuota il cestino')));
    }
    if (!list.length) parts.push(empty(!!S.q.trim()));
    else if (S.view === 'list') {
      parts.push(h('div', { class: 'pp-table' },
        h('div', { class: 'pp-th' }, h('span'), h('span', null, 'Nome'), h('span', null, 'Tipo'), h('span', null, 'Formato'), h('span', null, 'Durata'), h('span', null, 'Cartella'),
          h('span', null, trash ? 'Si elimina' : 'Modificato'), h('span')),
        ...list.map(row)));
    } else parts.push(h('div', { class: 'pp-grid' }, ...list.map(card)));
    const y = body.scrollTop;
    body.replaceChildren(...parts);
    body.scrollTop = y;
    root.classList.toggle('selecting', S.sel.size > 0);
    paintBar();
  }

  // ---- tastiera: Ctrl+F cerca, Ctrl+A seleziona tutto, Esc deseleziona, Canc nel cestino
  const onKey = (e) => {
    if (!root.isConnected) { document.removeEventListener('keydown', onKey); closeMenus(); return; }
    if (document.querySelector('.modal-bg, .nfs-bg, .nft')) return;
    const tg = e.target || {};
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName || '') || tg.isContentEditable;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); qIn.focus(); qIn.select(); return; }
    if (typing) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') { e.preventDefault(); for (const p of shownList().list) S.sel.add(p.id); paint(); return; }
    if (e.key === 'Escape' && S.sel.size) { S.sel.clear(); paint(); return; }
    if ((e.key === 'Delete' || e.key === 'Backspace') && S.sel.size) { e.preventDefault(); const ids = [...S.sel]; run(trash ? purge : toTrash)(ids); }
  };
  document.addEventListener('keydown', onKey);
  reload();
  root.reload = reload;
  return root;
}
