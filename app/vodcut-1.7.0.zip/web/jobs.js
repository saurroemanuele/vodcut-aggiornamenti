// Pillola "Lavori in corso" (rebrand, 19b): i lavori veri dell'app (download, preparazione, sottotitoli, clip,
// esportazioni, lavori AI) letti da /api/jobs. Compare solo se c'e' almeno un lavoro; finito = verde con "Apri" e
// sparisce dopo 4 secondi. Il DOM si aggiorna senza ricrearlo (niente lampeggi) e l'entrata si anima solo quando compare.
import { h, get, popOpened, onPopOpened } from './lib.js';

// tipo di lavoro -> [icona, titolo]. I lavori di servizio (anteprime, miniature, proxy) non si mostrano
const KINDS = {
  download: ['dl', 'Scarico il video'], prepare: ['ai', 'Preparo il video'],
  transcribe: ['ai', 'Sottotitoli'], trrange: ['ai', 'Sottotitoli'],
  clips: ['clip', 'Cerco le clip'], clipmanual: ['clip', 'Creo la clip'], clipextend: ['clip', 'Aggiorno la clip'],
  clipstyle: ['clip', 'Aggiorno la clip'], cliplayout: ['clip', 'Aggiorno la clip'], cliplang: ['clip', 'Traduco la clip'],
  export: ['exp', 'Esporto'],
  aiedit: ['ai', 'Montaggio AI'], aiwrite: ['ai', 'Testi AI'], aigraphics: ['ai', 'Grafiche AI'],
  fxcode: ['ai', 'Effetto su misura'], fxreview: ['ai', 'Effetto su misura'], behind: ['ai', 'Titoli dietro la persona'],
  story: ['ai', 'Storia AI'], storyvoice: ['ai', 'Voce della storia'],
  fmtvideos: ['ai', 'Video di riferimento'], fmtanalyze: ['ai', 'Video di riferimento'], denoise: ['ai', 'Riduco il rumore'],
};
const IC = {
  ai: 'M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z',
  clip: 'M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z',
  dl: 'M12 4v11M7 10l5 5 5-5M5 20h14',
  exp: 'M12 15V4M7 9l5-5 5 5M5 20h14',
  ok: 'M5 12.5l4.5 4.5L19 7.5',
  err: 'M12 8v5M12 16.5h.01M10.3 3.9L2.5 18a2 2 0 0 0 1.7 3h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
};
const DONE_SHOW = 4000, EVERY = 1500;
const S = { run: [], done: new Map(), seen: new Map(), names: {}, namesAt: 0, subs: new Set(), timer: null, onOpen: null, shown: false };

// chi apre il lavoro finito (lo decide app.js: editor, clip, cartella dell'esportazione...)
export function setJobOpener(fn) { S.onOpen = fn; }

const svg = (d, size, sw) => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('width', size); s.setAttribute('height', size); s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', sw || 1.9);
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.innerHTML = '<path d="' + d + '"/>';
  return s;
};
const notify = () => S.subs.forEach((f) => f());

async function names(jobs) {
  const miss = jobs.some((j) => j.pid && !(j.pid in S.names) && !(j.pid.split('_')[0] in S.names));
  if (!miss || Date.now() - S.namesAt < 10000) return;
  S.namesAt = Date.now();
  try { for (const p of await get('/api/projects')) S.names[p.id] = p.name; } catch (e) { /* */ }
}
const nameOf = (pid) => (pid && (S.names[pid] || S.names[pid.split('_')[0]])) || '';

async function finish(j) {
  let r = null;
  try { r = await get('/api/jobs/' + j.id); } catch (e) { /* lavoro sparito: niente riga */ }
  if (!r || r.status === 'cancelled' || r.status === 'running') return;
  S.done.set(j.id, { ...j, ...r, doneAt: Date.now() });
  notify();
  setTimeout(() => { S.done.delete(j.id); notify(); }, DONE_SHOW);
}

async function poll() {
  let run = [];
  try { run = (await get('/api/jobs')).filter((j) => KINDS[j.kind] && j.status === 'running'); } catch (e) { run = S.run; }
  const ids = new Set(run.map((j) => j.id));
  for (const [id, j] of S.seen) if (!ids.has(id)) { S.seen.delete(id); finish(j); }
  for (const j of run) S.seen.set(j.id, j);
  await names(run);
  S.run = run;
  notify();
}
function start() { if (!S.timer) { poll(); S.timer = setInterval(() => { if (!S.subs.size) { clearInterval(S.timer); S.timer = null; return; } poll(); }, EVERY); } }

function rowsOf() {
  const rows = S.run.map((j) => ({ key: j.id, j, done: false, err: false, pct: Math.round(Math.max(0, Math.min(1, j.progress || 0)) * 100) }));
  for (const [id, j] of S.done) rows.push({ key: id, j, done: j.status === 'done', err: j.status !== 'done', pct: 100 });
  return rows;
}

export function jobsPill() {
  const arc = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  const ring = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  ring.setAttribute('class', 'nfj-ring'); ring.setAttribute('viewBox', '0 0 22 22');
  ring.innerHTML = '<circle cx="11" cy="11" r="9" fill="none" stroke="var(--gline)" stroke-width="2.4"></circle>';
  for (const [k, v] of [['cx', 11], ['cy', 11], ['r', 9], ['fill', 'none'], ['stroke-width', 2.4], ['stroke-linecap', 'round'], ['stroke-dasharray', 56.5]]) arc.setAttribute(k, v);
  ring.append(arc);
  const lb = h('span', { class: 'nfj-lb' });
  const pill = h('button', { class: 'nfj-pill', type: 'button', 'aria-label': 'Lavori in corso' }, ring, lb);
  const list = h('div', { class: 'nfj-rows' });
  const pop = h('div', { class: 'nfj-pop', hidden: true }, h('div', { class: 'nfj-hd' }, 'Lavori in corso'), list);
  const wrap = h('span', { class: 'nfj', hidden: true }, pill, pop);
  let open = false, hov = null, sig = '', arcInit = false, visible = false, wasIn = false;
  const setOpen = (v) => { open = v; if (v) popOpened('jobs'); sig = ''; paint(); };
  wrap.addEventListener('pointerenter', () => { clearTimeout(hov); hov = setTimeout(() => { if (!open && visible) setOpen(true); }, 120); });
  wrap.addEventListener('pointerleave', () => { clearTimeout(hov); hov = setTimeout(() => { if (open) setOpen(false); }, 220); });
  pill.addEventListener('click', () => setOpen(!open));
  const offPop = onPopOpened('jobs', () => { if (open) setOpen(false); });
  const outside = (e) => { if (open && !wrap.contains(e.target)) setOpen(false); };
  document.addEventListener('pointerdown', outside);
  list.addEventListener('click', (e) => {
    const b = e.target.closest('.nfj-open'); if (!b) return;
    const r = S.done.get(b.dataset.key); S.done.delete(b.dataset.key); setOpen(false);
    if (r && S.onOpen) S.onOpen(r);
  });

  function paint() {
    // la pillola nasce prima di entrare nella pagina: si stacca solo quando c'era ed e' stata tolta (cambio schermata)
    if (!wrap.isConnected) { if (wasIn) cleanup(); return; }
    wasIn = true;
    const rows = rowsOf(), run = rows.filter((r) => !r.done && !r.err);
    if (!rows.length) {
      if (visible) { visible = false; wrap.hidden = true; open = false; pop.hidden = true; }
      document.documentElement.style.setProperty('--nf-jobs-w', '0px');
      return;
    }
    if (!visible) {
      visible = true; wrap.hidden = false;
      pill.classList.remove('enter'); void pill.offsetWidth; pill.classList.add('enter');   // entra solo quando compare
    }
    const avg = run.length ? run.reduce((t, r) => t + r.pct, 0) / run.length : 100;
    const allDone = !run.length, anyErr = allDone && rows.some((r) => r.err) && !rows.some((r) => r.done);
    const label = allDone ? (anyErr ? 'Non riuscito' : 'Fatto') : (run.length === 1 ? '1 lavoro · ' : run.length + ' lavori · ') + Math.round(avg) + '%';
    if (lb.textContent !== label) lb.textContent = label;
    pill.classList.toggle('done', allDone && !anyErr);
    pill.classList.toggle('err', anyErr);
    arc.setAttribute('stroke', allDone ? (anyErr ? 'var(--err)' : 'var(--ok)') : 'var(--ac)');
    const off = (56.5 * (1 - avg / 100)).toFixed(1);
    if (!arcInit) { arc.style.transition = 'none'; arc.style.strokeDashoffset = off; arc.getBoundingClientRect(); arc.style.transition = 'stroke-dashoffset .3s linear, stroke .2s'; arcInit = true; }
    else arc.style.strokeDashoffset = off;
    pop.hidden = !open;
    if (open) {
      const s2 = rows.map((r) => r.key + (r.done ? 'd' : r.err ? 'e' : '')).join(',');
      if (s2 !== sig) {
        sig = s2;
        list.replaceChildren(...rows.map((r) => {
          const [ic, title] = KINDS[r.j.kind] || ['ai', 'Lavoro'];
          const nm = nameOf(r.j.pid);
          return h('div', { class: 'nfj-row' + (r.done ? ' done' : r.err ? ' err' : ''), 'data-k': r.key },
            h('span', { class: 'nfj-ic' }, svg(IC[r.done ? 'ok' : r.err ? 'err' : ic], 14)),
            h('div', { class: 'nfj-tx' },
              h('div', { class: 'nfj-t1' }, h('b', null, h('span', null, title), nm ? h('span', { 'data-notr': '' }, ' · ' + nm) : null), h('span', { class: 'nfj-pc' })),
              h('div', { class: 'nfj-st' }),
              r.done || r.err ? null : h('div', { class: 'nfj-bar' }, h('i'))),
            r.done || r.err ? h('button', { class: 'nfj-open', type: 'button', 'data-key': r.key }, 'Apri') : null);
        }));
      }
      for (const r of rows) {
        const el = list.querySelector('[data-k="' + r.key + '"]'); if (!el) continue;
        const pc = r.done ? 'Fatto' : r.err ? 'Non riuscito' : r.pct + '%';
        const st = r.err ? (r.j.error || '') : r.done ? 'Finito' : (r.j.message || '');
        const pe = el.querySelector('.nfj-pc'), se = el.querySelector('.nfj-st'), bi = el.querySelector('.nfj-bar i');
        if (pe.textContent !== pc) pe.textContent = pc;
        if (se.textContent !== st) se.textContent = st;
        if (bi) bi.style.width = r.pct + '%';
      }
    }
    document.documentElement.style.setProperty('--nf-jobs-w', (pill.offsetWidth + 6) + 'px');
  }
  function cleanup() { S.subs.delete(paint); offPop(); document.removeEventListener('pointerdown', outside); }
  S.subs.add(paint);
  start();
  paint();
  return wrap;
}
