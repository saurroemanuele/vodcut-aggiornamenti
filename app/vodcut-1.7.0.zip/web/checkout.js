// Pagamento dentro l'app (senza aprire il browser): foglio con la pagina sicura di NoonFrame (noonframe.com/paga.html),
// dove il modulo della carta e' quello di Stripe. Stripe blocca i pagamenti veri su pagine senza https, e l'app gira su
// 127.0.0.1: per questo il modulo sta in quella pagina, mostrata qui in un riquadro. I dati della carta vanno solo a Stripe;
// i crediti li aggiunge il server quando Stripe conferma (webhook), poi qui si aggiornano da soli.
// PayPal porta su un'altra pagina: si apre in una finestra NoonFrame a parte e il foglio aspetta.
import { get, post, h, icon, toast, getTheme } from './lib.js';
import { LANG } from './i18n.js';

const catalog = () => get('/api/ai/catalog').catch(() => null);
// la pagina sempre aggiornata (la finestra dell'app tiene in memoria i file): in prova (pagina sul PC) a ogni apertura,
// se no a ogni versione dell'app
const fresh = (u) => u + '?v=' + (/^http:\/\/127\.0\.0\.1[:/]/.test(u) ? Date.now() : String((window.VODCUT || {}).version || '1').replace(/[^\w.-]/g, ''));
const hashOf = (o) => Object.entries(o).filter(([, v]) => v != null && v !== '').map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(String(v))).join('&');

// item: { kind, id, period }; info: come mostrarlo prima che risponda Stripe { kind, name, det, price, plan, email }
// risponde { fallback } se il pagamento dentro l'app non e' ancora attivo (si usa il browser come prima), { changed }
// se e' stato un cambio di piano (senza pagamento qui), { paid } quando il foglio si chiude
export async function openCheckout(item, info = {}) {
  const before = await catalog();
  let r;
  try { r = await post('/api/ai/checkout', { item }); } catch (e) { toast(e.message, true); return { error: true }; }
  if (r.fallback) return { fallback: true };
  if (r.changed) { window.dispatchEvent(new CustomEvent('nf-credits-changed')); return { changed: true, plan: r.plan }; }
  const payUrl = r.payUrl;
  let origin = '';
  try { origin = new URL(payUrl).origin; } catch (e) { toast('Pagamento non avviato: riprova', true); return { error: true }; }
  const base = { lang: LANG, theme: getTheme(), kind: info.kind || item.kind, name: info.name, det: info.det, price: info.price, period: item.period,
    plan: info.plan, email: info.email, test: r.test ? '1' : '', mock: r.mock ? '1' : '' };
  const src = fresh(payUrl) + '#' + hashOf({ ...base, cs: r.clientSecret, pk: r.pk, po: location.origin, embed: '1' });

  return new Promise((resolve) => {
    let busy = false, paid = false, closed = false, polling = false, paypalOpen = false, credited = false, paypalUsed = false;
    const frame = h('iframe', { class: 'co-frame', src, title: 'Pagamento', allow: 'payment *', referrerpolicy: 'no-referrer' });
    const wait = h('div', { class: 'co-wait' }, h('div', { class: 'spinner' }));
    const sheet = h('div', { class: 'co-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Pagamento' }, wait, frame);
    const bg = h('div', { class: 'co-bg' }, sheet);
    const send = (ev, data) => { try { frame.contentWindow.postMessage({ nf: 'pay', ev, ...(data || {}) }, origin); } catch (e) { /* */ } };
    const close = () => {
      if (closed) return;
      closed = true;
      removeEventListener('message', onMsg); removeEventListener('keydown', onKey, true);
      if (paypalOpen) post('/api/pay/window', { close: true }).catch(() => {});
      bg.classList.add('out');
      setTimeout(() => bg.remove(), 180);
      // pagato ma Stripe non ha ancora confermato: i crediti arrivano da soli tra poco (si continua a controllare)
      if (paid && !credited) toast('Pagamento ricevuto: i crediti arrivano tra qualche secondo');
      resolve({ paid });
    };
    const onKey = (e) => { if (e.key === 'Escape' && !busy) { e.stopPropagation(); close(); } };
    // dopo il pagamento: si guarda il saldo finche' il server non conferma (al massimo 5 minuti), poi lo si dice al foglio.
    // Si continua anche se il foglio e' gia' chiuso (Stripe a volte conferma qualche secondo dopo): appena arrivano i
    // crediti si aggiornano la pagina dei piani e il saldo in alto, senza cambiare pagina
    const poll = () => {
      if (polling) return;
      polling = true;
      const t0 = Date.now();
      const tick = async () => {
        if (credited) return;
        if (closed && !paid && !paypalUsed) return;   // chiuso senza pagare: niente da aspettare
        const c = await catalog();
        if (c && before && (c.balance !== before.balance || c.plan !== before.plan)) {
          const got = Math.max(0, (c.balance || 0) - (before.balance || 0));
          if (paypalOpen) { paypalOpen = false; post('/api/pay/window', { close: true }).catch(() => {}); }
          paid = true; credited = true;
          send('credited', { got, balance: c.balance || 0 });
          window.dispatchEvent(new CustomEvent('nf-credits-changed'));
          if (closed) toast(c.plan !== before.plan ? 'Piano attivo: ' + (c.planName || c.plan) : '+' + got + ' crediti');
          return;
        }
        if (Date.now() - t0 < 5 * 60 * 1000) setTimeout(tick, 2500);
      };
      setTimeout(tick, 1500);
    };
    async function openPaypal() {
      let p;
      try { p = await post('/api/ai/checkout', { item, method: 'paypal' }); } catch (e) { send('paypal_fail'); toast(e.message, true); return; }
      if (!p.clientSecret) { toast('PayPal non è disponibile: paga con la carta', true); return; }
      const url = fresh(payUrl) + '#' + hashOf({ ...base, cs: p.clientSecret, pk: p.pk, method: 'paypal' });
      try { await post('/api/pay/window', { url }); paypalOpen = true; paypalUsed = true; poll(); } catch (e) { toast(e.message, true); }
    }
    const onMsg = (e) => {
      if (e.origin !== origin || e.source !== frame.contentWindow || !e.data || e.data.nf !== 'pay') return;
      const ev = e.data.ev;
      if (ev === 'ready') wait.remove();
      else if (ev === 'busy') { busy = !!e.data.on; bg.classList.toggle('busy', busy); }
      else if (ev === 'close') close();
      else if (ev === 'done') { paid = true; poll(); }
      else if (ev === 'paypal') openPaypal();
      else if (ev === 'paypal_cancel') { if (paypalOpen) { paypalOpen = false; post('/api/pay/window', { close: true }).catch(() => {}); } }
    };
    addEventListener('message', onMsg);
    addEventListener('keydown', onKey, true);
    bg.addEventListener('click', (e) => { if (e.target === bg && !busy) close(); });
    // la pagina non risponde (niente rete o pagina non raggiungibile): lo si dice invece di restare sullo spinner
    setTimeout(() => {
      if (!wait.isConnected || closed) return;
      wait.replaceChildren(icon('info', 22, 'currentColor', 1.8), h('b', null, 'Il pagamento non si è aperto'),
        h('span', null, 'Controlla la connessione e riprova: non ti abbiamo addebitato niente.'),
        h('button', { class: 'btn ghost sm', type: 'button', onclick: close }, 'Chiudi'));
      wait.classList.add('err');
    }, 20000);
    document.body.append(bg);
  });
}
