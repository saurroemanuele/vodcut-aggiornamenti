// Rebrand: i fogli della Home. "Monta" (17a): uno o piu' video (in ordine), materiale facoltativo nei Media, formato e
// lavori automatici; "Apri l'editor" si accende appena c'e' un video. "Nuovo" (17b): formato, nome facoltativo, editor vuoto.
import { h, get, post, icon, fmt, toast, TOKEN, droppedPath, BIG_DROP } from './lib.js';

const IMG = /\.(png|jpe?g|webp|gif|bmp|svg|heic|heif|tiff?)$/i, AUD = /\.(mp3|wav|m4a|aac|ogg|flac|opus|wma)$/i, VID = /\.(mp4|mov|mkv|m4v|webm|avi|flv|ts|mts|m2ts|wmv)$/i;
const CLAPPER = 'M3 10h18v10H3zM3.5 10l1.3-4.5h15.4L18.9 10zM8 5.5L6.8 10M12 5.5L10.8 10M16 5.5L14.8 10';
const KINDS = [
  ['g', 'Grafiche e logo', 'PNG, SVG, GIF', 'M4 5h16v14H4zM4 15l4-4 4 4 3-3 5 5M15 9.5a1.5 1.5 0 1 0 0 .01', IMG],
  ['f', 'Foto', 'JPG, PNG, HEIC', 'M4 7h3l2-3h6l2 3h3v12H4zM12 10a3 3 0 1 0 0 6 3 3 0 0 0 0-6z', IMG],
  ['m', 'Musica', 'MP3, WAV, M4A', 'M9 18V6l11-2v12M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM20 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z', AUD],
  ['s', 'Effetti sonori', 'Woosh, boom, ding', 'M4 9h4l5-4v14l-5-4H4zM16.5 8.5a5 5 0 0 1 0 7', AUD]];
// i formati che l'editor sa fare con un video tuo; 1:1 e 4:5 per ora solo nei progetti nuovi
const FMTS = [['native', 'Come il video', 0, 0], ['16:9', '16:9', 20, 11], ['9:16', '9:16', 11, 20], ['1:1', '1:1', 16, 16], ['4:5', '4:5', 14, 17]];
// lavori automatici: [chiave, nome, spiegazione, costo, acceso all'inizio]
const AUTOS = [
  ['subs', 'Crea i sottotitoli', 'Dalla voce, nella lingua del video', 'Gratis', true],
  ['pauses', 'Togli le pause', 'I tagli li puoi rimettere uno per uno', 'Gratis', true],
  ['cuts', 'Taglia errori e ripetizioni', 'Frasi ricominciate e parti inutili', 'Con l\'AI', false],
  ['zooms', 'Zoom sulle frasi chiave', 'Nei momenti forti, se c\'è una persona', 'Con l\'AI', false]];

const path = (d) => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', 17); s.setAttribute('height', 17);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '1.6');
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.innerHTML = '<path d="' + d + '"/>';
  return s;
};
const size = (b) => (!b ? '' : b >= 1e9 ? (b / 1e9).toLocaleString('it-IT', { maximumFractionDigits: 1 }) + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB');
const toggle = (on, fn) => {
  const t = h('button', { type: 'button', class: 'nfs-tg' + (on ? ' on' : ''), role: 'switch', 'aria-checked': on ? 'true' : 'false', onclick: () => { const v = !t.classList.contains('on'); t.classList.toggle('on', v); t.setAttribute('aria-checked', v ? 'true' : 'false'); fn(v); } }, h('i'));
  return t;
};

// guscio comune: sfondo, foglio, intestazione con icona e X, Esc per chiudere
export function sheet(cls, ic, title, sub) {
  const bg = h('div', { class: 'nfs-bg' });
  const box = h('div', { class: 'nfs ' + cls, role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape' && !box.dataset.busy) { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg && !box.dataset.busy) close(); });
  const head = h('div', { class: 'nfs-head' }, h('span', { class: 'nfs-hic' }, ic),
    h('span', { class: 'nfs-ht' }, h('b', null, title), h('span', null, sub)),
    h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Chiudi', 'data-tip': 'Chiudi', onclick: () => { if (!box.dataset.busy) close(); } }, icon('x', 13, 'currentColor', 2)));
  box.append(head);
  bg.append(box);
  document.body.append(bg);
  return { bg, box, close };
}

// ---------------------------------------------------------------------------------------------- Monta (17a)
// ctx: { nav, first: video (o elenco di video) gia' scelti, facoltativo }
export function montaSheet(ctx) {
  const S = { vids: [], reading: [], mats: { g: [], f: [], m: [], s: [] }, fmt: 'native', auto: Object.fromEntries(AUTOS.map((a) => [a[0], a[4]])), busy: false };
  const { box, close } = sheet('monta', path(CLAPPER), 'Monta un video', 'Scegli il video: il resto puoi aggiungerlo anche dopo');
  const body = h('div', { class: 'nfs-body' });
  const sum1 = h('span', { class: 'b' }), sum2 = h('span', { class: 's' });
  const openBtn = h('button', { type: 'button', class: 'nfs-go', onclick: () => run() }, h('span', null, 'Apri l\'editor'), icon('right', 14, 'currentColor', 2.2));
  const foot = h('div', { class: 'nfs-foot' }, h('span', { class: 'nfs-sum' }, sum1, sum2),
    h('button', { type: 'button', class: 'nfs-cancel', onclick: close }, 'Annulla'), openBtn);
  box.append(body, foot);

  // ---- video: uno o piu', in ordine (si trascinano per cambiare l'ordine)
  async function addVideoPath(p) {
    if (!p) return;
    if (S.vids.some((v) => v.path === p) || S.reading.includes(p)) { toast('Questo video c\'è già'); return; }
    S.reading.push(p); paint();   // leggere un video lungo puo' richiedere qualche secondo: intanto si vede la riga
    try {
      const info = await post('/api/probe-media', { path: p });
      if (info.kind !== 'video') toast('Scegli un video: MP4, MOV, MKV…', true);
      else S.vids.push(info);
    } catch (e) { toast(e.message, true); }
    S.reading = S.reading.filter((x) => x !== p);
    paint();
  }
  async function pickVideo() {
    try {
      const r = await post('/api/pick', { kind: 'video' });
      const p = r.fallback ? (prompt('Percorso completo del video:', '') || '').trim().replace(/^"|"$/g, '') : r.path;
      if (p) await addVideoPath(p);
    } catch (e) { toast(e.message, true); }
  }
  async function pickMaterial(k, re) {
    try {
      const r = await post('/api/pick', { kind: 'media' });
      if (r.fallback) { toast('Aggiungi il materiale dai Media, nell\'editor', true); return; }
      const files = (r.files || []).filter((f) => re.test(f.path));
      const bad = (r.files || []).length - files.length + (r.skipped || []).length;
      if (bad) toast(k === 'm' || k === 's' ? 'Qui vanno i suoni: MP3, WAV, M4A' : 'Qui vanno le immagini: PNG, JPG, SVG, GIF', true);
      const have = new Set(S.mats[k].map((f) => f.path));
      S.mats[k].push(...files.filter((f) => !have.has(f.path)));
      paint();
    } catch (e) { toast(e.message, true); }
  }
  let dragFrom = -1;
  function videoRow(v, i) {
    const row = h('div', { class: 'nfs-vrow', draggable: 'true' },
      h('span', { class: 'nfs-grip', 'aria-hidden': 'true' }, icon('dots', 14, 'var(--t3)', 2)),
      h('span', { class: 'nfs-vn' }, String(i + 1)),
      h('span', { class: 'nfs-vth' }, h('img', { src: `/api/mthumb?path=${encodeURIComponent(v.path)}&t=2&token=${TOKEN}`, alt: '', draggable: 'false', onerror: (e) => e.target.remove() })),
      h('span', { class: 'nfs-vtx' }, h('b', { 'data-notr': '' }, v.name), h('span', { class: 'tnum' }, [fmt(v.duration), size(v.size)].filter(Boolean).join(' · '))),
      h('button', { type: 'button', class: 'nfs-vx', 'aria-label': 'Togli', 'data-tip': 'Togli', onclick: () => { S.vids.splice(i, 1); paint(); } }, icon('x', 13, 'currentColor', 2)));
    row.addEventListener('dragstart', (e) => { dragFrom = i; row.classList.add('drag'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'nf-video'); });
    row.addEventListener('dragend', () => { dragFrom = -1; row.classList.remove('drag'); body.querySelectorAll('.nfs-vrow.over').forEach((x) => x.classList.remove('over')); });
    row.addEventListener('dragover', (e) => { if (dragFrom < 0) return; e.preventDefault(); row.classList.add('over'); });
    row.addEventListener('dragleave', () => row.classList.remove('over'));
    row.addEventListener('drop', (e) => {
      if (dragFrom < 0) return;
      e.preventDefault(); e.stopPropagation();
      const [m] = S.vids.splice(dragFrom, 1); S.vids.splice(i, 0, m); dragFrom = -1; paint();
    });
    return row;
  }
  // file trascinati da Esplora risorse nel foglio: video in coda, immagini e suoni nel materiale
  box.addEventListener('dragover', (e) => { if (dragFrom >= 0 || !e.dataTransfer.types.includes('Files')) return; e.preventDefault(); box.classList.add('over'); });
  box.addEventListener('dragleave', (e) => { if (!box.contains(e.relatedTarget)) box.classList.remove('over'); });
  box.addEventListener('drop', async (e) => {
    if (dragFrom >= 0 || !e.dataTransfer.files.length) return;
    e.preventDefault(); box.classList.remove('over');
    for (const f of e.dataTransfer.files) {
      const real = await droppedPath(f);
      if (!real) { toast(f.size > BIG_DROP ? 'File molto grande: sceglilo con il pulsante, così NoonFrame lo apre senza copiarlo' : 'Scegli il file con il pulsante', true); continue; }
      if (VID.test(real)) await addVideoPath(real);
      else if (IMG.test(real) || AUD.test(real)) {
        try { const info = await post('/api/probe-media', { path: real }); S.mats[info.kind === 'audio' ? 'm' : 'g'].push(info); paint(); } catch (er) { toast(er.message, true); }
      }
    }
  });

  function paint() {
    if (S.busy) return;
    const vsec = h('div', { class: 'nfs-sec' },
      h('div', { class: 'nfs-lab' }, h('b', null, 'Video'), h('span', null, 'Uno o più: vengono messi uno dopo l\'altro')),
      ...S.vids.map(videoRow),
      ...S.reading.map((p) => h('div', { class: 'nfs-vrow wait' }, h('span', { class: 'spinner' }),
        h('span', { class: 'nfs-vtx' }, h('b', { 'data-notr': '' }, p.split(/[\\/]/).pop()), h('span', null, 'Leggo il video…')))),
      h('button', { type: 'button', class: 'nfs-drop' + (S.vids.length || S.reading.length ? '' : ' big'), onclick: pickVideo }, icon('upload', 18, 'currentColor', 1.6),
        h('span', null, h('b', null, S.vids.length || S.reading.length ? 'Aggiungi un altro video' : 'Scegli il video'), h('span', null, 'MP4, MOV, MKV · anche di più ore'))));
    const msec = h('div', { class: 'nfs-sec' },
      h('div', { class: 'nfs-lab' }, h('b', null, 'Materiale'), h('span', null, 'Facoltativo · finisce nei Media del progetto')),
      h('div', { class: 'nfs-mats' }, ...KINDS.map(([k, label, hint, ic, re]) => {
        const n = S.mats[k].length;
        return h('div', { class: 'nfs-mat' + (n ? ' on' : ''), role: 'button', tabindex: '0', onclick: () => pickMaterial(k, re), onkeydown: (e) => { if (e.key === 'Enter') pickMaterial(k, re); } },
          h('span', { class: 'top' }, path(ic), n ? h('button', { type: 'button', class: 'n', 'aria-label': 'Togli', 'data-tip': 'Togli', onclick: (e) => { e.stopPropagation(); S.mats[k] = []; paint(); } }, h('span', null, String(n)), icon('x', 10, 'currentColor', 2.4))
            : h('span', { class: 'plus' }, '+')),
          h('span', { class: 'tx' }, h('b', null, label), n ? h('span', { 'data-notr': '' }, S.mats[k].map((f) => f.name).join(', ')) : h('span', null, hint)));
      })));
    const fsec = h('div', { class: 'nfs-sec' }, h('div', { class: 'nfs-lab' }, h('b', null, 'Formato')),
      h('div', { class: 'nfs-seg' }, ...FMTS.map(([k, label, w, hh, off]) => h('button', { type: 'button', class: S.fmt === k ? 'on' : '', disabled: off ? true : null,
        'data-tip': off ? (k === '16:9' ? 'Con un video orizzontale è uguale a "Come il video"' : 'Per ora solo nei progetti nuovi: usa "Nuovo"') : null, onclick: () => { S.fmt = k; paint(); } },
      w ? h('i', { style: { width: w + 'px', height: hh + 'px' } }) : null, label))));
    const asec = h('div', { class: 'nfs-sec tight' }, h('div', { class: 'nfs-lab' }, h('b', null, 'Mentre si apre l\'editor')),
      ...AUTOS.map(([k, label, hint, cost]) => h('div', { class: 'nfs-auto' },
        h('span', { class: 'tx' }, h('b', null, label), h('span', null, hint)),
        h('span', { class: 'cost' + (cost === 'Gratis' ? ' free' : '') }, cost),
        toggle(S.auto[k], (v) => { S.auto[k] = v; paintSum(); }))));
    const y = body.scrollTop;
    body.replaceChildren(vsec, msec, fsec, asec);
    body.scrollTop = y;
    paintSum();
  }
  function paintSum() {
    const n = S.vids.length, tot = S.vids.reduce((t, v) => t + (v.duration || 0), 0);
    sum1.textContent = n ? (n === 1 ? '1 video' : n + ' video') + ' · ' + fmt(tot) : 'Nessun video';
    const ai = S.auto.cuts || S.auto.zooms, any = AUTOS.some(([k]) => S.auto[k]);
    sum2.textContent = !any ? 'Nessun lavoro automatico' : ai ? 'Con l\'AI: vedi il costo nell\'editor prima che parta' : 'Lavori automatici gratis, sul tuo computer';
    openBtn.disabled = !n || S.reading.length > 0;
  }

  // ---- avanzamento in 3 passi: apro i video, preparo l'anteprima, apro l'editor
  async function run() {
    if (!S.vids.length || S.busy) return;
    S.busy = true; box.dataset.busy = '1';
    const steps = [S.vids.length === 1 ? 'Apro il video' : 'Apro i ' + S.vids.length + ' video', 'Preparo l\'anteprima', 'Apro l\'editor'].map((label) => {
      const right = h('span', { class: 'r tnum' });
      const el = h('div', { class: 'nfs-step' }, h('span', { class: 'dot' }, icon('check', 11, '#fff', 3), h('i')), h('span', { class: 'l' }, label), right);
      return { el, right };
    });
    const skip = h('button', { type: 'button', class: 'nfs-skip', hidden: true }, 'Apri subito l\'editor');
    body.replaceChildren(h('div', { class: 'nfs-steps' }, ...steps.map((s) => s.el),
      h('span', { class: 'nfs-note' }, 'I lavori automatici continuano anche dentro l\'editor: li vedi comparire nella timeline'), skip));
    foot.hidden = true;
    const set = (i, st, txt) => { const s = steps[i]; s.el.classList.remove('now', 'done'); if (st) s.el.classList.add(st); s.right.textContent = txt || ''; };
    let pid = null;
    try {
      set(0, 'now');
      const [first, ...more] = S.vids;
      const assets = Object.values(S.mats).flat().map((f) => f.path);
      // 1:1, 4:5 (o 16:9 da un video verticale): un progetto nel formato scelto con i video in fila nella traccia principale
      const tall = (v) => v && v.width && v.height && v.height > v.width;
      const asBlank = S.fmt === '1:1' || S.fmt === '4:5' || (S.fmt === '16:9' && tall(first));
      const p = asBlank
        ? await post('/api/projects/blank', { format: S.fmt, name: String(first.name || '').replace(/\.[^.]+$/, ''), monta: { more: S.vids.map((v) => v.path), assets, auto: S.auto } })
        : await post('/api/projects', { source: first.path, kind: 'video', more: more.map((v) => v.path), assets, format: S.fmt, auto: S.auto });
      pid = p.id;
      set(0, 'done', 'Fatto');
      set(1, 'now');
      // la preparazione (audio e anteprima) continua anche nell'editor: qui si vede, e si puo' saltare
      let go = false;
      skip.hidden = false; skip.onclick = () => { go = true; };
      while (!go) {
        let j = null;
        try { j = (await get('/api/jobs')).find((x) => x.pid === pid && x.kind === 'prepare'); } catch (e) { /* */ }
        if (!j) break;
        steps[1].right.textContent = Math.round((j.progress || 0) * 100) + '%';
        await new Promise((r) => setTimeout(r, 400));
      }
      skip.hidden = true;
      set(1, 'done', 'Fatto');
      set(2, 'now');
      close();
      ctx.nav('editor', pid);
    } catch (e) {
      S.busy = false; delete box.dataset.busy; foot.hidden = false;
      toast(e.message, true);
      if (pid) { close(); ctx.nav('editor', pid); return; }
      paint();
    }
  }
  paint();
  (async () => { for (const p of [].concat(ctx.first || [])) await addVideoPath(p); })();
}

// ---------------------------------------------------------------------------------------------- Nuovo (17b)
const NFMTS = [['16:9', 'YouTube, Twitch', 72, 40, '1920×1080'], ['9:16', 'TikTok, Reels, Shorts', 36, 64, '1080×1920'], ['1:1', 'Post quadrati', 54, 54, '1080×1080'], ['4:5', 'Post Instagram', 48, 60, '1080×1350']];
// ctx: { nav, more: [[icona, testo, fn]] link sotto (Storie con immagini, progetto da un altro PC) }
export function nuovoSheet(ctx) {
  let fm = '16:9', busy = false;
  const { box, close } = sheet('nuovo', icon('plus', 19, 'var(--tx)', 1.7), 'Nuovo progetto', 'Scegli il formato: l\'editor si apre vuoto');
  const tiles = h('div', { class: 'nfs-nf' });
  const sumEl = h('span', { class: 'nfs-nsum tnum' });
  const draw = () => {
    tiles.replaceChildren(...NFMTS.map(([k, sub, w, hh]) => h('button', { type: 'button', class: 'nfs-nt' + (k === fm ? ' on' : ''), onclick: () => { fm = k; draw(); }, ondblclick: () => create() },
      h('span', { class: 'pic' }, h('i', { style: { width: w + 'px', height: hh + 'px' } })), h('span', { class: 'tx' }, h('b', null, k), h('span', null, sub)))));
    sumEl.textContent = fm + ' · ' + NFMTS.find((x) => x[0] === fm)[4];
  };
  const name = h('input', { class: 'nfs-in', type: 'text', placeholder: 'Senza titolo', maxlength: '120', 'aria-label': 'Nome del progetto' });
  name.addEventListener('keydown', (e) => { if (e.key === 'Enter') create(); });
  const go = h('button', { type: 'button', class: 'nfs-go', onclick: () => create() }, 'Crea');
  async function create() {
    if (busy) return;
    busy = true; go.disabled = true; box.dataset.busy = '1'; go.textContent = 'Creo…';
    try {
      const p = await post('/api/projects/blank', { format: fm, name: name.value.trim() || 'Senza titolo' });
      close();
      ctx.nav('editor', p.id);
    } catch (e) { busy = false; go.disabled = false; delete box.dataset.busy; go.textContent = 'Crea'; toast(e.message, true); }
  }
  draw();
  box.append(tiles,
    h('label', { class: 'nfs-field' }, h('span', null, 'Nome (facoltativo)'), name),
    h('div', { class: 'nfs-nfoot' }, sumEl, h('button', { type: 'button', class: 'nfs-cancel', onclick: close }, 'Annulla'), go));
  if ((ctx.more || []).length) {
    box.append(h('div', { class: 'nfs-more' }, ...ctx.more.map(([ic, label, fn]) => h('button', { type: 'button', onclick: () => { close(); fn(); } }, icon(ic, 14, 'currentColor', 1.7), h('span', null, label)))));
  }
  setTimeout(() => name.focus(), 50);
}
