// Esportazione dentro un foglio (rebrand 8, "Esporta"). Lo usano l'editor e la galleria delle clip.
// 1) solo per le clip (opts.setup): come escono. Nome del file (o della cartella e di ogni clip), dove salvarle, qualita'
// 2) avanzamento: anteprima, a che punto e', quanto manca. All'inizio "Preparo il video" con la barra in movimento (prima
//    del primo fotogramma passano alcuni secondi: non deve sembrare fermo)
// 3) "Esportato" con "Apri la cartella" e "Guarda il video"
// Chiudendo il foglio l'esportazione continua e resta in vista: un riquadro in basso a destra (con "Mostra" per riaprire il
// foglio) e, nella galleria, l'etichetta sulle clip che si stanno esportando (evento "nf-export")
import { h, icon, get, post, fmt, toast, confirmBox, pollJob } from './lib.js';
import { explain, copyDetails } from './errors.js';

const sizeTxt = (b) => (!b ? '' : b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB');
const openPath = async (path, reveal) => { const r = await post('/api/open', { path, reveal }); if (!r.ok) toast('File non trovato', true); };
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* */ } },
};
const QUAL = [['2160p', '4K'], ['1440p', '1440p'], ['1080p', '1080p · Full HD'], ['720p', '720p · più leggero']];
const safeName = (x) => (String(x || '').trim() || 'video').replace(/[\\/:*?"<>|]+/g, '_');
const etaTxt = (s) => (s > 90 ? 'Circa ' + Math.round(s / 60) + ' min' : s > 5 ? 'Meno di un minuto' : s > 0 ? 'Quasi fatto' : '');

// ---------------------------------------------------------------- le esportazioni in corso (una per lavoro)
// le seguono il foglio, il riquadro in basso e la galleria; il lavoro si legge una volta sola
const TRACK = new Map();
function track(job, meta) {
  if (TRACK.has(job.id)) return TRACK.get(job.id);
  const T = { id: job.id, ...meta, p: 0, msg: '', left: 0, status: 'running', result: null, error: '', subs: new Set(), t0: 0 };
  TRACK.set(job.id, T);
  T.emit = () => {
    T.subs.forEach((f) => f(T));
    window.dispatchEvent(new CustomEvent('nf-export', { detail: { pid: T.pid, ids: T.ids, p: T.p, status: T.status, queued: T.queued } }));
  };
  pollJob(job.id, (j) => {
    T.p = Math.max(0, Math.min(1, j.progress || 0));
    T.msg = j.message || '';
    T.queued = T.msg === 'In coda';   // aspetta che finisca l'esportazione in corso (una alla volta)
    if (T.p >= 0.01) {
      if (!T.t0) T.t0 = Date.now() - 1000;
      const el = (Date.now() - T.t0) / 1000;
      T.left = T.p > 0.04 ? el / T.p - el : 0;
    }
    T.emit();
  }).then(async (res) => {
    T.status = res.status === 'done' ? 'done' : res.status === 'cancelled' ? 'cancelled' : 'error';
    T.error = res.error || '';
    if (T.status === 'done') {
      let ex = null;
      try { ex = (await get('/api/p/' + T.pid)).lastExport; } catch (e) { /* */ }
      T.result = ex || res.result || {};
      T.p = 1;
      if (T.onDone) T.onDone();
    }
    T.emit();
    setTimeout(() => TRACK.delete(T.id), 15 * 60 * 1000);
  });
  return T;
}
// per la galleria: le clip di questo progetto che si stanno esportando (o appena esportate) -> [{ ids, p, status }]
export function exportsOf(pid) {
  return [...TRACK.values()].filter((T) => T.pid === pid && T.status !== 'cancelled').map((T) => ({ ids: T.ids, p: T.p, status: T.status, queued: T.queued }));
}

// ---------------------------------------------------------------- il foglio
let cur = null;
function sheet() {
  if (cur) cur.close();
  const bg = h('div', { class: 'nfs-bg' });
  const box = h('div', { class: 'nfs xs-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Esporta' });
  bg.append(box);
  document.body.append(bg);
  const S = { bg, box, alive: true, onClose: null };
  S.close = () => {
    if (!S.alive) return;
    S.alive = false; bg.remove(); document.removeEventListener('keydown', onKey, true);
    if (cur === S) cur = null;
    if (S.onClose) { const f = S.onClose; S.onClose = null; f(); }
  };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.modal-bg.dlg-top')) { e.stopPropagation(); S.close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg) S.close(); });
  cur = S;
  return S;
}
const head = (S, title, sub) => h('div', { class: 'nfs-head' }, h('span', { class: 'nfs-hic' }, icon('upload', 18, 'var(--tx)', 1.7)),
  h('span', { class: 'nfs-ht' }, h('b', null, 'Esporta'), h('span', { 'data-notr': '' }, sub || title || '')),
  h('button', { type: 'button', class: 'nfs-x', 'aria-label': 'Chiudi', 'data-tip': 'Chiudi', onclick: () => S.close() }, icon('x', 13, 'currentColor', 2)));
const thumbOf = (poster, many, cls) => (poster ? h('span', { class: 'xs2-th ' + (cls || '') }, h('img', { src: poster, alt: '' }))
  : h('span', { class: 'xs2-th ph ' + (cls || '') }, icon(many ? 'phone' : 'film', 20, 'var(--t2)', 1.7)));

// pid: il progetto che esporta; want: come per POST /export (vod, verticals, timelines, export, quality)
// opts: { name: per il titolo, setup: prima si sceglie come escono (clip), items: [{ id, name, poster, dur }], onDone }
export async function exportRun(pid, want, opts = {}) {
  const S = sheet();
  const items = Array.isArray(opts.items) ? opts.items : [];
  const poster = (items.find((x) => x.poster) || {}).poster || '';
  if (opts.setup) {
    const r = await setup(S, pid, want, opts, items);
    if (!r) return;   // chiuso senza esportare
    ({ want, opts } = r);
  }
  // ogni esportazione e' un lavoro suo: se ce n'e' gia' una in corso, questa aspetta "In coda" (lo decide il server)
  let job = null;
  try { job = await post(`/api/p/${pid}/export`, want || {}); } catch (e) { failed(S, { pid, want, opts }, e.message); return; }
  const T = track(job, { pid, want, opts, ids: (want && want.verticals) || [], name: opts.name || '', poster, many: items.length > 1 || (want && !want.vod) });
  if (opts.onDone && !T.onDone) T.onDone = opts.onDone;
  follow(S, T);
}

// ---- 1) come escono le clip: nome, dove, qualita'
async function setup(S, pid, want, opts, items) {
  S.box.replaceChildren(head(S, opts.name), h('div', { class: 'xs2-load' }, h('div', { class: 'spinner' })));
  let env = {}, parent = {};
  try { [env, parent] = await Promise.all([get('/api/env'), get('/api/p/' + pid)]); } catch (e) { /* valori di partenza */ }
  if (!S.alive) return null;
  const ids = (want && want.verticals) || [];
  const list = await Promise.all(ids.map(async (id) => {
    const it = items.find((x) => x.id === id);
    if (it && it.name) return { ...it };
    try { const p = await get('/api/p/' + id); return { id, name: p.name, poster: it && it.poster, dur: it && it.dur }; } catch (e) { return { id, name: '' }; }
  }));
  if (!S.alive) return null;
  const many = list.length > 1;
  const poster = (items.find((x) => x.poster) || {}).poster || '';
  let dir = store.get('nf.export.dir') || '';
  const H = parent.height || 1080;
  const qOpts = QUAL.filter(([v]) => parseInt(v, 10) <= Math.max(1080, H + 8));
  let quality = store.get('nf.export.q') || '1080p';
  if (!qOpts.some(([v]) => v === quality)) quality = '1080p';
  const nameIn = h('input', { class: 'xs2-in', maxlength: '120', spellcheck: 'false',
    value: many ? (parent.name ? parent.name + ' - Clip verticali' : 'Clip verticali') : (list[0] && list[0].name) || opts.name || '',
    'aria-label': many ? 'Nome della cartella' : 'Nome del file' });
  const rows = list.map((x) => {
    x.inp = h('input', { class: 'xs2-in sm', value: x.name || '', maxlength: '120', spellcheck: 'false', 'aria-label': 'Nome della clip' });
    return h('label', { class: 'xs2-item' }, x.poster ? h('img', { src: x.poster, alt: '' }) : h('span', { class: 'ph' }), x.inp,
      h('small', { class: 'tnum' }, x.dur ? fmt(x.dur) : ''));
  });
  const where = h('span', { class: 'xs2-path', 'data-notr': '' });
  const qSeg = h('div', { class: 'xs-q' });
  const paint = () => {
    const base = dir || env.exportsDir || '';
    const sep = base.includes('\\') ? '\\' : '/';
    const full = base + sep + safeName(nameIn.value) + (many ? sep : '.mp4');
    where.textContent = full.length > 58 ? '…' + full.slice(-57) : full;
    where.dataset.tip = full;
    qSeg.replaceChildren(...qOpts.map(([v, l]) => h('button', { type: 'button', class: quality === v ? 'on' : '', onclick: () => { quality = v; paint(); } }, l)));
  };
  nameIn.addEventListener('input', paint);
  const pick = h('button', { type: 'button', class: 'xs2-pick', onclick: async () => {
    try {
      const r = await post('/api/pick', { kind: 'folder' });
      if (r.fallback) { const v = prompt('Cartella dove salvare:', dir || env.exportsDir || ''); if (v) dir = v.trim().replace(/^"|"$/g, ''); }
      else if (r.path) dir = r.path;
      paint();
    } catch (e) { toast(e.message, true); }
  } }, icon('folder', 13, 'currentColor', 1.8), h('span', null, 'Cambia'));
  return new Promise((resolve) => {
    S.onClose = () => resolve(null);
    const go = h('button', { type: 'button', class: 'btn primary xs2-go', onclick: () => {
      const nm = nameIn.value.trim();
      if (!nm) { nameIn.focus(); return; }
      store.set('nf.export.q', quality);
      if (dir) store.set('nf.export.dir', dir);
      const w = { ...want, quality };
      if (dir) w.export = { ...(want.export || {}), dir };
      let o = opts;
      if (many) {
        w.folderName = nm;
        w.names = Object.fromEntries(list.map((x) => [x.id, (x.inp.value || '').trim()]).filter(([, v]) => v));
      } else if (list[0]) { w.names = { [list[0].id]: nm }; o = { ...opts, name: nm }; }   // il titolo con il nome scelto
      S.onClose = null;
      resolve({ want: w, opts: o });
    } }, icon('upload', 14, '#fff', 2.2), h('span', null, many ? 'Esporta ' + list.length + ' clip' : 'Esporta'));
    nameIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') go.click(); });
    S.box.replaceChildren(head(S, opts.name, many ? list.length + ' clip' : ''),
      h('div', { class: 'xs2-setup' },
        many ? null : h('div', { class: 'xs2-top' }, thumbOf(poster, true, 'big'),
          h('div', { class: 'xs2-fld' }, h('span', { class: 'xs2-lab' }, 'Nome del file'), h('div', { class: 'xs2-name' }, nameIn, h('span', { class: 'ext' }, '.mp4')))),
        many ? h('div', { class: 'xs2-fld' }, h('span', { class: 'xs2-lab' }, 'Nome della cartella'), nameIn) : null,
        many ? h('div', { class: 'xs2-fld' }, h('span', { class: 'xs2-lab' }, 'Le clip'), h('div', { class: 'xs2-list' }, ...rows)) : null,
        h('div', { class: 'xs2-fld' }, h('span', { class: 'xs2-lab' }, 'Dove'), h('div', { class: 'xs2-dir' }, icon('folder', 14, 'var(--t2)', 1.7), where, pick)),
        h('div', { class: 'xs2-fld' }, h('span', { class: 'xs2-lab' }, 'Qualità'), qSeg)),
      h('div', { class: 'xs2-foot' }, h('span', { class: 'grow' }), h('button', { type: 'button', class: 'btn ghost', onclick: () => S.close() }, 'Annulla'), go));
    paint();
    setTimeout(() => { if (S.alive) { nameIn.focus(); nameIn.select(); } }, 40);
  });
}

// ---- 2) in corso (foglio). Chiudendolo mentre esporta compare il riquadro in basso
function follow(S, T) {
  const label = h('span', { class: 'xs2-st' }, 'Preparo il video…');
  const pct = h('b', { class: 'xs2-pct tnum' });
  const bar = h('i');
  const barBox = h('div', { class: 'xs2-bar wait' }, bar);
  const eta = h('span', { class: 'xs2-eta' });
  S.box.replaceChildren(head(S, T.name),
    h('div', { class: 'xs2-run' },
      h('div', { class: 'xs2-card' }, thumbOf(T.poster, T.many),
        h('div', { class: 'xs2-mid' }, h('b', { class: 'xs2-nm', 'data-notr': '' }, T.name), label, barBox,
          h('div', { class: 'xs2-meta' }, eta, h('span', { class: 'grow' }), pct))),
      h('span', { class: 'xs2-hint' }, icon('info', 12, 'currentColor', 1.8), h('span', null, 'Puoi chiudere: continua in secondo piano'))),
    h('div', { class: 'xs2-foot' },
      h('button', { type: 'button', class: 'xs2-stop', onclick: () => stop(T, S) }, 'Annulla esportazione'),
      h('span', { class: 'grow' }),
      h('button', { type: 'button', class: 'btn primary xs2-go', onclick: () => S.close() }, 'Continua a lavorare')));
  const paint = () => {
    if (!S.alive) return;
    if (T.status === 'done') { T.subs.delete(paint); done(S, T); return; }
    if (T.status === 'error') { T.subs.delete(paint); failed(S, T, T.error); return; }
    if (T.status === 'cancelled') { T.subs.delete(paint); S.close(); return; }
    if (T.queued) {   // un'altra esportazione e' in corso: questa parte subito dopo
      barBox.classList.remove('wait'); barBox.classList.add('queue'); pct.textContent = ''; eta.textContent = '';
      label.textContent = 'In coda: parte appena finisce l\'esportazione in corso';
      return;
    }
    barBox.classList.remove('queue');
    if (T.p < 0.01) {   // prima del primo fotogramma: si prepara (encoder, sorgente), la barra si muove
      barBox.classList.add('wait'); pct.textContent = ''; eta.textContent = '';
      label.textContent = T.msg || 'Preparo il video…';
      return;
    }
    barBox.classList.remove('wait');
    bar.style.width = (T.p * 100).toFixed(1) + '%';
    pct.textContent = Math.round(T.p * 100) + '%';
    label.textContent = T.msg || 'Esporto il video';
    eta.textContent = etaTxt(T.left);
  };
  T.subs.add(paint);
  S.onClose = () => { T.subs.delete(paint); if (T.status === 'running') dock(T); };
  paint();
}
async function stop(T, S) {
  if (await confirmBox('Annullare l\'esportazione?', 'Le modifiche restano salvate, puoi esportare di nuovo quando vuoi.', 'Annulla esportazione', true)) {
    post(`/api/jobs/${T.id}/cancel`).catch(() => {});
    if (S) { S.onClose = null; S.close(); }   // annullata: niente riquadro in basso
  }
}

// ---- 3) fatto: "Esportato" con "Apri la cartella" e "Guarda il video"
function done(S, T) {
  const ex = T.result || {};
  const many = ex.files && ex.files.length > 1;
  const folder = ex.folder || ex.path;
  const sub = many ? ex.files.length + ' video nella stessa cartella'
    : [fmt(ex.duration || 0), ex.width && ex.height ? Math.min(ex.width, ex.height) + 'p' : '', sizeTxt(ex.size)].filter(Boolean).join(' · ');
  const extras = [];
  if (ex.srt) extras.push(h('button', { type: 'button', class: 'xs-x', onclick: () => openPath(ex.srt, true) }, icon('text', 13, 'currentColor', 1.8), h('span', null, 'Sottotitoli per YouTube (.srt)')));
  if (ex.chapters) extras.push(h('button', { type: 'button', class: 'xs-x', onclick: () => openPath(ex.chapters) }, icon('list', 13, 'currentColor', 1.8), h('span', null, 'Capitoli per la descrizione')));
  const path = String(folder || '');
  S.onClose = null;
  S.box.replaceChildren(...[head(S, T.name),
    h('div', { class: 'xs2-done' },
      h('div', { class: 'xs2-card' }, h('span', { class: 'xs2-okth' }, thumbOf(T.poster, T.many), h('span', { class: 'xs2-ok' }, icon('check', 14, '#fff', 3))),
        h('div', { class: 'xs2-mid' }, h('b', { class: 'xs2-big' }, many ? ex.files.length + ' video pronti' : 'Esportato'), h('span', { class: 'xs2-st' }, sub),
          path ? h('span', { class: 'xs2-path', 'data-notr': '', 'data-tip': path }, path.length > 58 ? '…' + path.slice(-57) : path) : null)),
      many ? h('div', { class: 'xs-files' }, ...ex.files.map((f) => h('button', { type: 'button', class: 'xs-f', onclick: () => openPath(f.path) },
        icon(f.vertical ? 'phone' : 'film', 14, 'currentColor', 1.8), h('span', { 'data-notr': '' }, f.name), h('small', { class: 'tnum' }, fmt(f.duration || 0))))) : null,
      extras.length ? h('div', { class: 'xs2-extra' }, ...extras) : null),
    h('div', { class: 'xs2-foot' },
      h('span', { class: 'grow' }),
      !many && ex.path ? h('button', { type: 'button', class: 'btn ghost', onclick: () => openPath(ex.path) }, icon('play', 13, 'currentColor', 1.8), h('span', null, 'Guarda il video')) : null,
      h('button', { type: 'button', class: 'btn primary xs2-go', onclick: () => openPath(folder, !ex.folder) }, icon('folder', 13, '#fff', 2), h('span', null, 'Apri la cartella')))].filter(Boolean));
}
// ---- non riuscita (18a): niente errore grezzo, Riprova e i dettagli per il supporto
function failed(S, T, err) {
  const ex = explain(err);
  const known = ['disk', 'missing', 'locked', 'deleted'].includes(ex.key);
  const msg = known ? err : 'Non riesco a esportare il video. Il progetto è salvato e non hai perso niente: riprova, oppure copia i dettagli per il supporto.';
  const copy = h('button', { type: 'button', class: 'xs2-stop', onclick: async () => { if (await copyDetails(err, 'Esportazione')) copy.textContent = 'Dettagli copiati'; } }, 'Copia i dettagli per il supporto');
  S.onClose = null;
  S.box.replaceChildren(head(S, (T.opts || {}).name || T.name), h('div', { class: 'xs-fail' }, h('b', null, known ? ex.title : 'Esportazione non riuscita'), h('p', null, msg)),
    h('div', { class: 'xs2-foot' }, copy, h('span', { class: 'grow' }),
      h('button', { type: 'button', class: 'btn ghost', onclick: () => S.close() }, 'Chiudi'),
      h('button', { type: 'button', class: 'btn primary xs2-go', onclick: () => { S.close(); exportRun(T.pid, T.want, { ...(T.opts || {}), setup: false }); } }, 'Riprova')));
}

// ---------------------------------------------------------------- il riquadro in basso a destra (foglio chiuso)
// mentre esporta: anteprima, nome, barra e percentuale, "Mostra" riapre il foglio; finito: "Esportato" con "Apri la
// cartella", resta finche' non lo chiudi. Uno per esportazione, uno sopra l'altro
let dockBox = null;
function dock(T) {
  if (!dockBox || !dockBox.isConnected) { dockBox = h('div', { class: 'xd-stack', 'aria-live': 'polite' }); document.body.append(dockBox); }
  if (dockBox.querySelector('[data-job="' + T.id + '"]')) return;
  const st = h('span', { class: 'xd-st' });
  const bar = h('i');
  const barBox = h('div', { class: 'xs2-bar sm wait' }, bar);
  const acts = h('div', { class: 'xd-acts' });
  const th = h('span', { class: 'xd-th' }, thumbOf(T.poster, T.many));
  const el = h('div', { class: 'xd', 'data-job': T.id, role: 'status' }, th,
    h('div', { class: 'xd-mid' }, h('b', { class: 'xd-nm', 'data-notr': '' }, T.name || 'Esportazione'), st, barBox), acts,
    h('button', { type: 'button', class: 'xd-x', 'aria-label': 'Chiudi', 'data-tip': T.status === 'running' ? 'Nascondi: l\'esportazione continua' : 'Chiudi', onclick: () => remove() }, icon('x', 12, 'currentColor', 2)));
  dockBox.append(el);
  const remove = () => { T.subs.delete(paint); el.remove(); };
  const show = () => { remove(); const S = sheet(); follow(S, T); };
  let last = '';
  function paint() {
    if (!el.isConnected) { T.subs.delete(paint); return; }
    if (T.status === 'cancelled') { remove(); return; }
    if (T.status === 'done' || T.status === 'error') {
      if (last === T.status) return;
      last = T.status;
      el.classList.add(T.status === 'done' ? 'ok' : 'err');
      barBox.remove();
      if (T.status === 'done') {
        const ex = T.result || {};
        const many = ex.files && ex.files.length > 1;
        th.append(h('span', { class: 'xs2-ok' }, icon('check', 12, '#fff', 3)));
        st.textContent = many ? ex.files.length + ' video pronti' : 'Esportato' + (ex.size ? ' · ' + sizeTxt(ex.size) : '');
        acts.replaceChildren(h('button', { type: 'button', class: 'xd-go', onclick: () => openPath(ex.folder || ex.path, !ex.folder) }, icon('folder', 12, '#fff', 2), h('span', null, 'Apri la cartella')));
      } else {
        st.textContent = 'Esportazione non riuscita';
        acts.replaceChildren(h('button', { type: 'button', class: 'xd-lnk', onclick: () => { remove(); const S = sheet(); failed(S, T, T.error); } }, 'Dettagli'));
      }
      return;
    }
    if (last !== 'run') { last = 'run'; acts.replaceChildren(h('button', { type: 'button', class: 'xd-lnk', onclick: show }, 'Mostra')); }
    const wait = T.p < 0.01 && !T.queued;
    barBox.classList.toggle('wait', wait);
    barBox.classList.toggle('queue', !!T.queued);
    if (!wait && !T.queued) bar.style.width = (T.p * 100).toFixed(1) + '%';
    st.textContent = T.queued ? 'In coda' : wait ? 'Preparo il video…' : Math.round(T.p * 100) + '%' + (etaTxt(T.left) ? ' · ' + etaTxt(T.left) : '');
  }
  T.subs.add(paint);
  paint();
}
