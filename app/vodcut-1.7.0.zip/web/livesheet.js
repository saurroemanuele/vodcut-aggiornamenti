// "Dalla live" senza passi (rebrand 12a-d): dal link o dal file della live un foglio sulla Home con l'avanzamento
// (scarico o apro, audio, dettagli), poi tagli e zoom calcolati sul computer con le scelte di sempre e l'editor si apre
// da solo con il suggerimento. Webcam e stile non si chiedono qui: dall'editor si correggono quando vuoi.
import { h, icon, get, post, put, fmt, pollJob, toast, TOKEN, fixLink, linkProblem, isLocalPath, localPath } from './lib.js';

const LINK_I = 'M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7';
const svg = (d, size) => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', size); s.setAttribute('height', size);
  s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor'); s.setAttribute('stroke-width', '2');
  s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
  s.innerHTML = '<path d="' + d + '"/>';
  return s;
};
const srcName = (url) => {
  const u = String(url || '').toLowerCase();
  return /twitch\.tv/.test(u) ? 'TWITCH' : /kick\.com/.test(u) ? 'KICK' : /youtu\.?be/.test(u) ? 'YOUTUBE' : 'LINK';
};
const sizeTxt = (b) => (!b ? '' : b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB');
const etaTxt = (s) => (!(s > 0) ? '' : s >= 90 ? '≈ ' + Math.round(s / 60) + ' min' : '≈ ' + Math.max(5, Math.round(s / 5) * 5) + ' s');
// dove sta la webcam, in parole ("in alto a destra")
export function camWhere(box, W, H) {
  if (!box || !W || !H) return '';
  const cx = (box[0] + box[2] / 2) / W, cy = (box[1] + box[3] / 2) / H;
  const v = cy < 0.36 ? 'in alto' : cy > 0.64 ? 'in basso' : 'in mezzo';
  const o = cx < 0.36 ? 'a sinistra' : cx > 0.64 ? 'a destra' : 'al centro';
  return v === 'in mezzo' && o === 'al centro' ? 'al centro' : v + ' ' + o;
}

let open = null;
// src: { url } oppure { file }. ctx: { nav, pickFile, whisper } (pickFile: sceglie un file dal computer, ritorna il percorso)
export function liveImport(src, ctx) {
  if (open) return;
  // src: { url } dal link, { file } dal computer, { pid } un progetto gia' importato (riaperto dai Progetti)
  const S = { src, pid: null, job: null, alive: true, phase: src.pid ? 'audio' : src.url ? 'get' : 'open', pct: { get: src.pid ? 1 : 0, audio: 0, more: 0 }, name: '', meta: '', eta: 0 };
  const bg = h('div', { class: 'nfs-bg lv-bg' });
  const box = h('div', { class: 'nfs lv', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Dalla live' });
  bg.append(box);
  document.body.append(bg);
  open = bg;
  const close = () => { S.alive = false; bg.remove(); open = null; };

  // ---- 12a/12b/12d: la card con l'anteprima e l'avanzamento
  const img = h('img', { class: 'lv-img', alt: '', draggable: 'false' });
  const cam = h('i', { class: 'lv-cam' });
  const badge = h('span', { class: 'lv-src' }, src.url ? svg(LINK_I, 11) : icon('film', 11, 'currentColor', 2), h('span', { 'data-notr': '' }, src.url ? srcName(src.url) : src.pid ? 'VIDEO' : 'FILE'));
  const title = h('b', { 'data-notr': '' });
  const meta = h('span', { class: 'lv-meta' });
  const eta = h('span', { class: 'lv-eta' });
  const segs = h('div', { class: 'lv-segs' });
  const note = h('span', { class: 'lv-note' });
  const cancel = h('button', { type: 'button', class: 'lv-x', onclick: () => stop() }, 'Annulla');
  const card = h('div', { class: 'lv-card' },
    h('div', { class: 'lv-pv' }, img, h('i', { class: 'lv-scan' }), cam, badge,
      h('div', { class: 'lv-cap' }, h('span', { class: 'lv-t' }, title, meta), eta)),
    segs, h('div', { class: 'lv-foot' }, note, cancel));
  box.replaceChildren(card);

  const STEPS = () => [[src.url ? 'Scarico' : 'Apro', 'get', src.url ? 5 : 1], ['Audio', 'audio', src.url ? 3.5 : 5], ['Dettagli', 'more', src.url ? 1.5 : 3]];
  function paint(ready) {
    const order = ['get', 'audio', 'more'];
    const cur = order.indexOf(S.phase === 'open' ? 'get' : S.phase);
    segs.replaceChildren(...STEPS().map(([label, k, w], i) => {
      const done = ready || i < cur, now = !ready && i === cur;
      const p = done ? 1 : now ? Math.max(0.03, S.pct[k] || 0) : 0;
      const val = done ? (k === 'get' && S.size ? sizeTxt(S.size) : '') : now && S.pct[k] > 0.01 ? Math.round(S.pct[k] * 100) + '%' : '';
      return h('div', { class: 'lv-seg' + (done ? ' done' : now ? ' now' : ''), style: { flex: String(w) } },
        h('i', null, h('i', { style: { width: (p * 100).toFixed(1) + '%' } })),
        h('span', null, h('i', { class: 'dot' }), h('b', null, label), val ? h('small', { class: 'tnum' }, val) : null));
    }));
    title.textContent = S.name || (src.url ? 'Scarico la live' : 'Apro la live');
    meta.textContent = S.meta;
    eta.textContent = ready ? 'Pronto' : etaTxt(S.eta);
    eta.classList.toggle('ok', !!ready);
  }
  note.textContent = src.url || src.pid ? 'Finito, si apre l\'editor da solo' : 'Il file non viene copiato: lo apriamo da dov\'è';
  paint();

  async function stop() {
    if (!S.alive) return;
    S.alive = false;
    if (S.job) post(`/api/jobs/${S.job.id}/cancel`).catch(() => {});
    close();
    if (S.pid) toast('Ho fermato l\'analisi. La live è tra i tuoi progetti: la riapri quando vuoi.');
  }
  const follow = async (job, k) => {
    S.job = job;
    const r = await pollJob(job.id, (j) => {
      if (!S.alive) return;
      S.pct[k] = Math.max(0, Math.min(1, j.progress || 0)); S.eta = j.eta || 0;
      if (k === 'get' && j.size) S.size = j.size;
      paint();
    });
    S.job = null;
    return r;
  };
  async function showProject() {
    const p = await get('/api/p/' + S.pid);
    S.name = p.name; S.W = p.width; S.H = p.height;
    S.meta = [p.duration ? fmt(p.duration) : '', sizeTxt(p.size || S.size)].filter(Boolean).join(' · ');
    img.src = `/api/p/${S.pid}/frame?token=${TOKEN}&t=${((p.duration || 10) * 0.35).toFixed(1)}`;
    img.onload = () => img.classList.add('on');
    paint();
    return p;
  }
  function showCam(p) {
    const b = p.webcam && p.webcam.box;
    if (!b || !p.width || !p.height) { cam.style.display = 'none'; return; }
    Object.assign(cam.style, { display: 'block', left: (b[0] / p.width * 100) + '%', top: (b[1] / p.height * 100) + '%', width: (b[2] / p.width * 100) + '%', height: (b[3] / p.height * 100) + '%' });
  }

  (async () => {
    try {
      // 1) scarico dal link o apro il file (il file resta dov'e')
      if (src.pid) {
        S.pid = src.pid;
      } else if (src.url) {
        const r = await follow(await post('/api/import-url', { url: src.url }), 'get');
        if (!S.alive) return;
        if (r.status !== 'done' || !r.result || !r.result.project) { if (r.status !== 'cancelled') failed(r.error || 'Download non riuscito'); return; }
        S.pid = r.result.project;
      } else {
        S.pid = (await post('/api/projects', { source: src.file })).id;
        S.pct.get = 1;
      }
      if (!S.alive) return;
      let p = await showProject();
      // 2) audio e webcam: lo stesso lavoro di prima, senza chiedere niente
      S.phase = 'audio'; paint();
      if (!(p.analysis && p.analysis.ready)) {
        const jobs = await get('/api/jobs');
        const running = jobs.find((j) => j.pid === S.pid && j.kind === 'prepare' && j.status === 'running');
        const r = await follow(running || await post(`/api/p/${S.pid}/prepare`), 'audio');
        if (!S.alive) return;
        if (r.status !== 'done') { if (r.status !== 'cancelled') failed(r.error || 'Analisi non riuscita', true); return; }
      }
      // 3) dettagli: tagli e zoom con le scelte di sempre (gratis, sul computer)
      S.phase = 'more'; S.pct.more = 0.15; paint();
      p = await get('/api/p/' + S.pid);
      showCam(p);
      const wc = p.webcam || {};
      const sure = !!(wc.box && (wc.remembered || (wc.confidence || 0) >= 0.5));
      const unsure = !!(wc.box && !sure);
      let zl = 2.8;
      try { const v = parseFloat(localStorage.getItem('vodcut.zoomLevel')); if (v >= 1.1 && v <= 4) zl = v; } catch (e) { /* */ }
      let lv = { cuts: 1, zooms: 1 };
      try { const o = JSON.parse(localStorage.getItem('nf-live-style') || 'null'); if (o && o.cuts != null) lv = o; } catch (e) { /* */ }
      if (unsure) {   // webcam incerta: niente zoom nel posto sbagliato, li aggiungi dopo averla segnata
        p.webcam = { none: true, guess: wc.box }; await put('/api/p/' + S.pid, p);
      }
      const tick = setInterval(() => { if (S.pct.more < 0.9) { S.pct.more += 0.07; paint(); } }, 400);
      try { p = await post(`/api/p/${S.pid}/propose`, { cuts: lv.cuts, zooms: unsure ? -1 : lv.zooms, zoomScale: sure ? zl : null }); } finally { clearInterval(tick); }
      if (!S.alive) return;
      const nCuts = (p.segs || []).filter((s) => s.removed && s.auto).length;
      const nZooms = (p.zooms || []).filter((z) => z.auto).length;
      const where = sure ? camWhere(wc.box, p.width, p.height) : '';
      p.liveSugg = { cuts: nCuts, zooms: nZooms, cam: sure ? 'ok' : unsure ? 'unsure' : 'none', where, seen: false };
      p.stage = 'editor';
      await put('/api/p/' + S.pid, p);
      // sottotitoli come sempre (la scelta si ricorda); dopo il salvataggio, cosi' la trascrizione non si sovrascrive
      let subs = true;
      try { const v = localStorage.getItem('vodcut.autoSubs'); if (v !== null) subs = v === '1'; } catch (e) { /* */ }
      if (subs && ctx.whisper && !(p.transcript && p.transcript.status && !['none', 'error'].includes(p.transcript.status))) post(`/api/p/${S.pid}/transcribe`).catch(() => {});
      // 12d: un secondo di "Pronto" con i numeri, poi l'editor
      S.meta = [nCuts === 1 ? '1 taglio' : nCuts + ' tagli', nZooms === 1 ? '1 zoom' : nZooms + ' zoom', where ? 'webcam ' + where : ''].filter(Boolean).join(' · ');
      note.textContent = 'Apro l\'editor…'; cancel.style.visibility = 'hidden';
      paint(true);
      await new Promise((r) => setTimeout(r, 1100));
      if (!S.alive) return;
      close();
      ctx.nav('editor', S.pid);
    } catch (e) {
      if (S.alive) failed(e.message, !!S.pid);
    }
  })();

  // ---- 12c: il link non si scarica (o l'analisi non riesce): correggi e riprova, oppure passa al file
  function failed(msg, analysis) {
    if (!S.alive) return;
    const inp = h('input', { class: 'lv-in', type: 'text', value: src.url || '', placeholder: 'twitch.tv/videos/…', 'aria-label': 'Link della live' });
    const again = () => {
      const raw = inp.value.trim();
      if (!raw) return;
      if (isLocalPath(raw)) { close(); liveImport({ file: localPath(raw) }, ctx); return; }
      const url = fixLink(raw), bad = linkProblem(url);
      if (bad) { why.textContent = bad; return; }
      close(); liveImport({ url }, ctx);
    };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') again(); });
    const why = h('p', null, msg);
    box.replaceChildren(h('div', { class: 'lv-err' },
      h('span', { class: 'lv-eic' }, svg(analysis ? 'M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z' : 'M18.8 12.3l1.7-1.7a5 5 0 0 0-7.1-7.1l-1.7 1.7M5.2 11.7l-1.7 1.7a5 5 0 0 0 7.1 7.1l1.7-1.7M8 2v3M2 8h3M16 19v3M19 16h3', 22)),
      h('b', null, analysis ? 'Non riesco ad analizzare la live' : 'Non riesco a scaricare la live'), why,
      analysis || !src.url ? null : h('div', { class: 'lv-field' }, svg(LINK_I, 14), inp, h('button', { type: 'button', class: 'lv-go', onclick: again }, 'Riprova')),
      h('div', { class: 'lv-links' },
        analysis && S.pid ? h('button', { type: 'button', class: 'linkish', onclick: () => { close(); ctx.nav('editor', S.pid); } }, 'Apri l\'editor lo stesso') : null,
        analysis && S.pid ? h('span', null, '·') : null,
        h('button', { type: 'button', class: 'linkish', onclick: async () => { const f = await ctx.pickFile(); if (f) { close(); liveImport({ file: f }, ctx); } } }, icon('upload', 12, 'currentColor', 1.8), h('span', null, 'Scegli un file')),
        h('span', null, '·'),
        h('button', { type: 'button', class: 'linkish', onclick: close }, 'Annulla'))));
    if (!analysis && src.url) setTimeout(() => inp.focus(), 50);
  }
}
