// Rebrand: tour guidato a passi (Home al primo avvio, si rivede dal menu del profilo). Evidenzia gli elementi veri della
// schermata ([data-tour="..."]); i passi senza elemento visibile si saltano. Esc chiude, frecce e Invio per muoversi.
import { h } from './lib.js';

const TOURS = {
  home: [
    ['link', 'Benvenuto in NoonFrame', 'Incolla qui il link di una live o di un video: NoonFrame trova i momenti migliori e ti prepara le clip verticali da solo.', 'below'],
    ['more', 'Altri modi per iniziare', 'Dalla live apre la registrazione di una live, Monta ti porta nell\'editor con il tuo materiale, Nuovo crea un progetto vuoto nel formato che vuoi.', 'below'],
    ['nav', 'I tuoi progetti', 'Tutto quello che crei finisce qui, diviso in cartelle. Da Progetti cerchi, ordini e sposti più progetti insieme.', 'right'],
    ['preset', 'I tuoi preset', 'Uno stile per ogni pagina: font, colori e sottotitoli. Le clip nuove escono con quello predefinito.', 'right'],
    ['me', 'Crediti e account', 'L\'anello attorno alla tua foto mostra i crediti rimasti. Da qui apri account, piani, lingua e tema.', 'auto'],
  ],
  // editor: il passo 1 e' il consenso all'Assistente AI (AI Act)
  editor: [
    ['ai', 'Stai parlando con un\'AI', 'Questo pannello è un assistente basato sull\'intelligenza artificiale, non una persona. Gli chiedi a parole cosa fare al video e lui lo fa: le risposte sono generate in automatico e possono sbagliare, controllale sempre. Prima di usare crediti ti chiede conferma.', 'right', { consent: true }],
    ['pv', 'L\'anteprima', 'Qui vedi il video come verrà esportato. Spazio per riprodurre, J, K e L per andare indietro e avanti.', 'below'],
    ['tools', 'Gli strumenti', 'Progetto, Media, Video, Audio e Testo: scegli uno strumento e il pannello accanto mostra cosa puoi fare. Clicca un elemento della timeline per le sue proprietà.', 'left'],
    ['tl', 'La timeline', 'Tagli, testi, sottotitoli e musica stanno qui. S divide nel punto della testina, Q e W tagliano prima e dopo.', 'above'],
    ['exp', 'Esporta', 'Quando hai finito crea il video finale: scegli dove salvarlo e la qualità.', 'left'],
  ],
};
const done = (name) => { try { return localStorage.getItem('nf-tour-' + name) === 'done'; } catch (e) { return true; } };
export const tourSeen = done;

let cur = null;
// quiet: si cambia schermata, il tour si chiude ma non conta come visto (riparte la prossima volta)
export function endTour(quiet) { if (cur) cur.end(quiet); }
// il tour e' aperto? (l'Assistente AI non ripete il consenso mentre lo chiede il tour); 'nf-tour-state' quando si apre o si chiude
export const tourOpen = () => !!cur;
const tourState = () => window.dispatchEvent(new CustomEvent('nf-tour-state', { detail: { open: !!cur } }));
// force: anche se l'hai gia' visto (dal menu "Rivedi il tour"); opts: { consented(), onConsent() } per il passo del consenso
export function startTour(name, force, opts = {}) {
  if (cur || document.querySelector('.auth-bg') || (!force && done(name))) return;   // mai sopra l'accesso o la licenza
  const visible = (key) => [...document.querySelectorAll('[data-tour="' + key + '"]')].find((el) => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
  const steps = (TOURS[name] || []).filter(([key]) => visible(key));
  if (!steps.length) return;
  let i = 0;
  const hole = h('div', { class: 'nft-hole' });
  const card = h('div', { class: 'nft-card', role: 'dialog', 'aria-modal': 'true' });
  const root = h('div', { class: 'nft' }, hole, card);
  const end = (quiet) => {
    if (quiet !== true) { try { localStorage.setItem('nf-tour-' + name, 'done'); } catch (e) { /* */ } }
    window.removeEventListener('keydown', onKey, true); window.removeEventListener('resize', place);
    root.classList.add('out'); setTimeout(() => root.remove(), 220);
    cur = null;
    tourState();
  };
  const go = (n) => { if (n >= steps.length) { end(); return; } if (n < 0) return; i = n; paint(); };
  const onKey = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); end(); }
    else if (e.key === 'ArrowRight' || e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); const nx = card.querySelector('.next'); if (nx && !nx.disabled) nx.click(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); e.stopPropagation(); go(i - 1); }
  };
  function place() {
    const [key, , , side] = steps[i];
    const el = visible(key);
    const W = innerWidth, H = innerHeight, P = 5, CW = 340, CH = card.offsetHeight || 210;
    let x = W / 2, y = H / 2, w = 0, hh = 0, rad = 12;
    if (el) {
      const r = el.getBoundingClientRect();
      x = r.left; y = r.top; w = r.width; hh = r.height;
      rad = Math.min(hh / 2, parseFloat(getComputedStyle(el).borderTopLeftRadius) || 10);
    }
    Object.assign(hole.style, { left: (x - P) + 'px', top: (y - P) + 'px', width: (w + P * 2) + 'px', height: (hh + P * 2) + 'px', borderRadius: (rad + P) + 'px' });
    let sd = side, cx, cy;
    if (sd === 'auto') sd = y > H / 2 ? 'right-up' : (x > W / 2 ? 'left' : 'below');
    if (sd === 'below') { cx = x + w / 2 - CW / 2; cy = y + hh + P + 16; }
    else if (sd === 'right') { cx = x + w + P + 18; cy = y - 10; }
    else if (sd === 'right-up') { cx = x + w + P + 18; cy = y + hh - CH; }
    else if (sd === 'above') { cx = x + w / 2 - CW / 2; cy = y - CH - P - 16; }
    else { cx = x - CW - P - 18; cy = y; }
    card.style.left = Math.max(16, Math.min(W - CW - 16, cx)) + 'px';
    card.style.top = Math.max(16, Math.min(H - CH - 16, cy)) + 'px';
  }
  function paint() {
    const [, title, text, , o = {}] = steps[i];
    const last = i === steps.length - 1;
    // passo del consenso: "Avanti" si accende solo con la casella spuntata
    const ask = o.consent && !(opts.consented && opts.consented());
    const chk = ask ? h('input', { type: 'checkbox' }) : null;
    const next = h('button', { type: 'button', class: 'nft-b next', disabled: ask ? true : null, onclick: () => { if (ask && opts.onConsent) opts.onConsent(); go(i + 1); } }, last ? 'Inizia' : 'Avanti');
    if (chk) chk.addEventListener('change', () => { next.disabled = !chk.checked; });
    card.replaceChildren(h('div', { class: 'nft-in' },
      h('div', { class: 'nft-top' }, ...steps.map((_, k) => h('i', { class: 'nft-dot' + (k === i ? ' now' : k < i ? ' past' : '') })), h('span', { class: 'n tnum' }, (i + 1) + ' di ' + steps.length)),
      h('h3', null, title), h('p', null, text),
      ask ? h('label', { class: 'nft-ok' }, chk, h('span', null, 'Ho capito che sto usando un\'intelligenza artificiale e che le sue risposte possono contenere errori')) : null,
      h('div', { class: 'nft-row' },
        h('button', { type: 'button', class: 'nft-skip', onclick: end }, 'Salta il tour'), h('span', { class: 'grow' }),
        i > 0 ? h('button', { type: 'button', class: 'nft-b back', onclick: () => go(i - 1) }, 'Indietro') : null, next)));
    place();
    requestAnimationFrame(place);
    const nx = card.querySelector('.next'); if (nx) nx.focus({ preventScroll: true });
  }
  window.addEventListener('keydown', onKey, true);
  window.addEventListener('resize', place);
  document.body.append(root);
  cur = { end };
  tourState();
  paint();
}
