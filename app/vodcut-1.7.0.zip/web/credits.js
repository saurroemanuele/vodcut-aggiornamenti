// Crediti NoonFrame: carta crediti (menu della foto profilo), offerte lampo; piani e ricariche stanno in plans.js.
// Il listino arriva sempre dal server (lo decide il pannello admin): qui niente prezzi scritti a mano.
import { get, post, h, icon, toast } from './lib.js';
import { LANG, locale, byLang } from './i18n.js';
import { openSubscription } from './subscription.js';

// 1.000 / 12.500 sempre col punto (in italiano Intl non separa i numeri di 4 cifre)
const nf = (n) => String(Math.round(+n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, LANG === 'en' ? ',' : '.');
const eur = (n) => { const v = (+n || 0).toFixed(2); return (LANG === 'en' ? '€' + v : v.replace('.', ',') + ' €'); };
const day = (iso) => { try { return new Date(iso).toLocaleDateString(locale(), { day: 'numeric', month: 'long' }); } catch (e) { return ''; } };
const MO = () => byLang({ it: '/mese', en: '/mo', fr: '/mois', de: '/Monat', pt: '/mês', es: '/mes' });

// la moneta dei crediti: un piccolo sole (NoonFrame = mezzogiorno)
const SUN = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="5.2" fill="currentColor"/><g stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/></g></svg>';
export const coin = (size = 14) => { const s = h('span', { class: 'cr-coin', style: { width: size + 'px', height: size + 'px' } }); s.innerHTML = SUN; return s; };

function countdown(iso) {
  const el = h('span', { class: 'cr-cd', 'data-notr': '' });
  const end = new Date(iso).getTime();
  const tick = () => {
    if (el._started && !el.isConnected) { clearInterval(el._iv); return; }
    el._started = true;
    let s = Math.max(0, Math.floor((end - Date.now()) / 1000));
    if (s > 3 * 86400) {
      el.textContent = byLang({ it: 'fino al ', en: 'until ', fr: 'jusqu\'au ', de: 'bis ', pt: 'até ', es: 'hasta el ' }) + new Date(end).toLocaleDateString(locale(), { day: 'numeric', month: 'short' });
      return;
    }
    const d = Math.floor(s / 86400); s -= d * 86400;
    const hh = Math.floor(s / 3600); s -= hh * 3600;
    const mm = Math.floor(s / 60); s -= mm * 60;
    const p2 = (x) => String(x).padStart(2, '0');
    el.textContent = d > 0 ? `${d}${byLang({ it: 'g', en: 'd', fr: 'j', de: 'T' })} ${hh}h ${p2(mm)}m` : `${p2(hh)}:${p2(mm)}:${p2(s)}`;
  };
  tick(); el._iv = setInterval(tick, 1000);
  return el;
}

let CAT = null, CAT_AT = 0;
export async function loadCatalog(force) {
  if (!force && CAT && Date.now() - CAT_AT < 3 * 60 * 1000) return CAT;
  CAT = await get('/api/ai/catalog'); CAT_AT = Date.now();
  return CAT;
}

// ------------------------------------------------------------------ carta crediti (menu della foto profilo)
const kids = (...a) => a.flat().filter((x) => x != null && x !== false && x !== '');   // replaceChildren scrive "null"

// "Gestisci abbonamento": la pagina dentro il tool (piano, carta, fatture, disdetta). La pagina del pagamento nel browser
// resta solo per gli abbonamenti vecchi che si gestiscono ancora da li' (Lemon Squeezy)
export function openPortal() { openSubscription(browserPortal); }
async function browserPortal() {
  try { await post('/api/ai/portal', {}); toast('Pagina dell\'abbonamento aperta nel browser'); } catch (e) { toast(e.message, true); }
}

// profilo: piano attuale, rinnovo o scadenza, crediti e gestione dell'abbonamento
export function planCard() {
  const card = h('section', { class: 'prof-card prof-plan' }, h('h2', null, 'Piano e pagamenti'), h('div', { class: 'cw-skel' }));
  Promise.all([loadCatalog(true), get('/api/ai/substatus').catch(() => ({}))]).then(([c, st]) => {
    if (!c || !c.signedIn) { card.remove(); return; }
    const sub = (st && st.sub) || null;
    const paid = !!(c.plan && c.plan !== 'free');
    const name = c.planName || (((c.catalog || {}).plans || []).find((p) => p.id === c.plan) || {}).name || 'Gratis';
    const when = (iso) => { try { return new Date(iso).toLocaleDateString(locale(), { day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return ''; } };
    const status = sub && sub.status === 'cancelled' && sub.endsAt
      ? h('span', { class: 'v warn' }, h('span', null, 'Disdetto: attivo fino al'), ' ', h('span', { 'data-notr': '' }, when(sub.endsAt)))
      : sub && sub.renewsAt ? h('span', { class: 'v' }, h('span', null, 'Si rinnova il'), ' ', h('span', { 'data-notr': '' }, when(sub.renewsAt)))
        : null;
    const row = (k, v) => h('div', { class: 'prof-row' }, h('span', { class: 'k' }, k), v);
    card.replaceChildren(...kids(h('h2', null, 'Piano e pagamenti'),
      row('Piano', h('span', { class: 'v', 'data-notr': '' }, paid ? name + (sub && sub.period === 'year' ? ' · ' + byLang({ it: 'annuale', en: 'yearly', fr: 'annuel', de: 'jährlich', pt: 'anual', es: 'anual' }) : '') : byLang({ it: 'Gratis', en: 'Free', fr: 'Gratuit', de: 'Kostenlos', pt: 'Grátis', es: 'Gratis' }))),
      status ? row(sub.status === 'cancelled' ? 'Stato' : 'Rinnovo', status) : null,
      row('Crediti', h('span', { class: 'v' }, coin(13), ' ', h('b', { 'data-notr': '' }, nf(c.balance)))),
      h('div', { class: 'prof-plan-acts' },
        paid ? h('button', { class: 'btn', onclick: (e) => openPortal(e.currentTarget) }, icon('card', 14), 'Gestisci abbonamento') : null,
        h('button', { class: 'btn ' + (paid ? 'ghost' : 'primary'), onclick: () => creditsDialog(paid ? 'packs' : 'plans') }, paid ? 'Ricarica crediti' : 'Scegli un piano')),
      paid ? h('p', { class: 'field-note' }, 'Da "Gestisci abbonamento" cambi carta, scarichi le fatture o disdici: il piano resta attivo fino alla fine del periodo pagato.') : null));
  }).catch(() => card.remove());
  return card;
}

export function walletCard(onOpen) {
  const card = h('div', { class: 'cw' }, h('div', { class: 'cw-skel' }));
  const go = (tab) => { onOpen && onOpen(); creditsDialog(tab); };
  loadCatalog(true).then((c) => {
    if (!c || !c.signedIn) { card.remove(); return; }
    const plans = (c.catalog || {}).plans || [];
    const pl = plans.find((p) => p.id === c.plan);
    const paid = !!(c.plan && c.plan !== 'free');
    const offer = ((c.catalog || {}).offers || [])[0];
    const pop = plans.length >= 3 ? plans[Math.floor(plans.length / 2)] : plans[0];
    // crediti del mese: barra sottile (solo con un piano)
    const used = paid && pl && pl.monthly ? Math.max(0, Math.min(1, (c.monthly || 0) / pl.monthly)) : 0;
    card.replaceChildren(...kids(
      h('div', { class: 'cw-top' },
        h('div', { class: 'cw-num' }, coin(20), h('b', { 'data-notr': '' }, nf(c.balance))),
        h('span', { class: 'cw-plan' + (paid ? ' paid' : '') }, paid ? h('span', { 'data-notr': '' }, c.planName || (plans.find((p) => p.id === c.plan) || {}).name || (c.plan[0].toUpperCase() + c.plan.slice(1))) : 'Gratis')),
      h('div', { class: 'cw-lbl' }, 'crediti disponibili'),
      paid && pl ? h('div', { class: 'cw-meter' },
        h('div', { class: 'cw-bar' }, h('i', { style: { width: (used * 100).toFixed(1) + '%' } })),
        h('div', { class: 'cw-meta' }, h('span', null, h('span', { 'data-notr': '' }, nf(c.monthly) + ' / ' + nf(pl.monthly)), ' ', h('span', null, 'del mese')),
          c.nextGrant ? h('span', null, h('span', null, 'rinnovo'), ' ', h('span', { 'data-notr': '' }, day(c.nextGrant))) : null)) : null,
      paid && c.extra ? h('div', { class: 'cw-extra' }, h('span', { 'data-notr': '' }, '+' + nf(c.extra)), ' ', h('span', null, 'crediti extra che non scadono')) : null,
      offer ? h('button', { class: 'cw-offer', onclick: () => go() },
        h('span', { class: 'cw-o-ic' }, icon('bolt', 11, 'currentColor', 2.6)), h('span', { class: 'cw-o-t', 'data-notr': '' }, offer.title), countdown(offer.endsAt)) : null,
      false ? h('div', { class: 'cw-keys' }, h('span', null, 'L\'AI ora usa le tue chiavi'),
        h('button', { class: 'linkish', onclick: async (e) => { e.stopPropagation(); try { await post('/api/ai/credits', { on: true }); toast('Crediti attivi'); onOpen && onOpen(); } catch (er) { toast(er.message, true); } } }, 'Usa i crediti')) : null,
      paid
        ? h('div', { class: 'cw-act' }, h('button', { class: 'cw-btn main', onclick: () => go('packs') }, 'Ricarica'), h('button', { class: 'cw-btn', onclick: () => go('plans') }, 'Cambia piano'))
        : null,
      paid ? h('button', { class: 'cw-link', onclick: (e) => { onOpen && onOpen(); openPortal(e.currentTarget); } }, 'Gestisci abbonamento: carta, fatture, disdetta')
        : null,
      paid ? null
        : h('div', { class: 'cw-act one' },
          h('button', { class: 'cw-btn main', onclick: () => go('plans') }, pop ? 'Passa a ' + pop.name + ' · ' + eur(pop.price) + MO() : 'Scegli un piano'),
          h('button', { class: 'cw-link', onclick: () => go('packs') }, 'oppure ricarica i crediti'))));
  }).catch(() => card.remove());
  return card;
}

// ------------------------------------------------------------------ store: piani e ricariche
// e' la pagina "Crediti e piani" (plans.js); nell'editor si apre in un foglio grande, cosi' non si lascia il montaggio
export async function creditsDialog(tab) {
  const m = await import('./plans.js');
  if (document.querySelector('.editor')) return m.plansSheet(tab);
  window.dispatchEvent(new CustomEvent('nf-nav', { detail: ['credits', tab || null] }));
}

// ------------------------------------------------------------------ home: offerta lampo (sottile, si chiude)
export function offerBanner() {
  const box = h('div', { class: 'cr-banner', style: { display: 'none' } });
  loadCatalog().then((c) => {
    const o = ((c.catalog || {}).offers || [])[0];
    if (!o) return;
    try { if (sessionStorage.getItem('nf.offer.hide') === String(o.id)) return; } catch (e) { /* */ }
    box.replaceChildren(...kids(h('span', { class: 'cr-bn-ic' }, icon('bolt', 13, 'currentColor', 2.4)),
      h('b', { 'data-notr': '' }, o.title), o.subtitle ? h('span', { class: 'cr-bn-sub', 'data-notr': '' }, o.subtitle) : null,
      h('span', { class: 'cr-bn-cd' }, countdown(o.endsAt)),
      h('button', { class: 'cr-bn-go', onclick: () => creditsDialog() }, 'Vedi'),
      h('button', { class: 'cr-bn-x', 'aria-label': 'Nascondi', onclick: () => { box.remove(); try { sessionStorage.setItem('nf.offer.hide', String(o.id)); } catch (e) { /* */ } } }, icon('x', 12, 'currentColor', 2.2))));
    box.style.display = '';
  }).catch(() => {});
  return box;
}

// pallino sulla foto profilo quando c'e' un'offerta lampo
export function markOffer(el) {
  loadCatalog().then((c) => { if (((c.catalog || {}).offers || []).length) el.classList.add('has-offer'); }).catch(() => {});
}
