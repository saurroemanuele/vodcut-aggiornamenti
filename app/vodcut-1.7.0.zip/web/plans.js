// Crediti e piani (21a): abbonamenti (mensile o annuale) e ricariche, come nel mockup dei pagamenti. Il listino arriva sempre
// dal server (lo decide il pannello admin). "Passa a…" e "Compra" aprono il foglio di pagamento dentro l'app; se non e' ancora
// attivo, il pagamento si apre nel browser come prima. Si usa come pagina (barra laterale) o, nell'editor, in un foglio grande.
import { post, h, icon, toast, confirmBox } from './lib.js';
import { LANG, locale, byLang, t as tx } from './i18n.js';
import { coin, loadCatalog, openPortal } from './credits.js';
import { openCheckout } from './checkout.js';

const nf = (n) => String(Math.round(+n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, LANG === 'en' ? ',' : '.');
const eur = (n) => { const v = (+n || 0).toFixed(2); return (LANG === 'en' ? '€' + v : v.replace('.', ',') + ' €'); };
const day = (iso) => { try { return new Date(iso).toLocaleDateString(locale(), { day: 'numeric', month: 'long' }); } catch (e) { return ''; } };
const MO = () => byLang({ it: '/mese', en: '/month', fr: '/mois', de: '/Monat', pt: '/mês', es: '/mes' });
const YR = () => byLang({ it: '/anno', en: '/year', fr: '/an', de: '/Jahr', pt: '/ano', es: '/año' });
const kids = (...a) => a.flat().filter((x) => x != null && x !== false && x !== '');
const tick = () => icon('check', 13, 'currentColor', 2.6);

// anello dei crediti (34 px, come nel mockup): pieno = crediti del mese o di benvenuto rimasti
function ring(frac) {
  const r = 14, c = 2 * Math.PI * r, f = Math.max(0, Math.min(1, frac || 0));
  const s = h('span', { class: 'pl-ring', 'aria-hidden': 'true' });
  s.innerHTML = `<svg width="34" height="34" viewBox="0 0 34 34"><circle cx="17" cy="17" r="${r}" fill="none" stroke="currentColor" stroke-opacity=".16" stroke-width="3"/>`
    + `<circle cx="17" cy="17" r="${r}" fill="none" stroke="var(--ac)" stroke-width="3" stroke-linecap="round" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${(c * (1 - f)).toFixed(1)}" transform="rotate(-90 17 17)"/></svg>`;
  return s;
}

// opts: { tab: 'plans'|'packs', onClose() se e' in un foglio }
export function plansView(opts = {}) {
  const root = h('div', { class: 'pl' });
  let mode = opts.tab === 'packs' ? 'packs' : 'plans', period = 'month';
  let c = null;
  const head = h('header', { class: 'pl-head' });
  const body = h('div', { class: 'pl-body' });
  root.append(head, body);

  async function load(force) {
    try { c = await loadCatalog(force); } catch (e) { body.replaceChildren(h('p', { class: 'pl-err' }, e.message)); return; }
    paint();
  }
  // acquisto: foglio di pagamento nell'app; se non e' attivo, la pagina di Stripe nel browser (come prima)
  async function buy(kind, id, per, info, btn) {
    btn.disabled = true;
    try {
      const item = per === 'year' ? { kind, id, period: per } : { kind, id };
      // chi ha gia' un abbonamento cambia piano su quello: Stripe addebita subito la differenza, quindi prima si dice quanto
      if (kind === 'plan' && c && c.plan && c.plan !== 'free' && !(await okChange(item, info))) { btn.disabled = false; return; }
      const r = await openCheckout(item, info);
      if (r.fallback) {
        const b = await post('/api/ai/buy', { item });
        if (b.changed) toast('Piano cambiato');
        else if (b.opened) { toast('Completa il pagamento nella pagina che si è aperta nel browser'); waitBrowser(); }
      } else if (r.changed) toast('Piano cambiato');
      await load(true);
    } catch (e) { toast(e.message, true); }
    btn.disabled = false;
  }
  // anteprima del cambio di piano (dal server, con i conti di Stripe) e conferma con l'importo di oggi
  async function okChange(item, info) {
    const pv = await post('/api/ai/planpreview', { item });
    if (!pv || !pv.change) return true;   // niente da cambiare (abbonamento nuovo): si paga nel foglio come sempre
    const due = pv.dueCents, price = eur((pv.priceCents || 0) / 100) + (pv.period === 'year' ? YR() : MO());
    const when = pv.renewsAt ? day(new Date(pv.renewsAt).toISOString()) : '';
    const name = (info && info.plan) || pv.plan;
    const sure = due != null && !!when;   // anteprima di Stripe non riuscita: la conferma senza l'importo esatto
    const text = !sure ?'Oggi paghi solo la differenza per i giorni che restano, con lo stesso metodo di pagamento dell\'abbonamento. Poi il piano costa ' + price + '.'
      : due > 0 ? 'Oggi paghi ' + eur(due / 100) + ' per i giorni che restano, con lo stesso metodo di pagamento dell\'abbonamento. Dal ' + when + ' il piano costa ' + price + '.'
        : 'Il cambio vale da subito: quello che hai già pagato del piano di adesso diventa uno sconto sui prossimi rinnovi. Dal ' + when + ' il piano costa ' + price + '.';
    return confirmBox('Passare a ' + name + '?', text, sure && due > 0 ? 'Paga ' + eur(due / 100) : 'Cambia piano');
  }
  // pagamento nel browser: il saldo si aggiorna da solo appena Stripe conferma (al massimo 15 minuti)
  function waitBrowser() {
    const b0 = c ? { balance: c.balance, plan: c.plan } : null, t0 = Date.now();
    const go = async () => {
      if (!root.isConnected) return;
      try {
        const n = await loadCatalog(true);
        if (b0 && (n.balance !== b0.balance || n.plan !== b0.plan)) { c = n; paint(); window.dispatchEvent(new CustomEvent('nf-credits-changed')); toast('Pagamento ricevuto'); return; }
      } catch (e) { /* riprova */ }
      if (Date.now() - t0 < 15 * 60 * 1000) setTimeout(go, 4000);
    };
    setTimeout(go, 3000);
  }

  function paint() {
    if (!c) return;
    if (!c.signedIn) {
      head.replaceChildren(h('div', { class: 'pl-tt' }, h('h1', null, 'Crediti e piani')), opts.onClose ? h('button', { class: 'pl-x', type: 'button', 'aria-label': 'Chiudi', onclick: opts.onClose }, icon('x', 14, 'currentColor', 2.2)) : '');
      body.replaceChildren(h('div', { class: 'pl-empty' }, coin(34), h('h2', null, 'Accedi per usare i crediti'), h('p', null, 'I crediti sono legati al tuo account: accedi dalla foto profilo in alto a destra.')));
      return;
    }
    const cat = c.catalog || {}, plans = cat.plans || [], packs = cat.packs || [], offers = cat.offers || [];
    const cur = c.plan || 'free', paid = cur !== 'free';
    const mine = plans.find((p) => p.id === cur);
    // offerta sul primo mese di un piano (personale o per tutti): la piu' conveniente
    const planOff = (pid) => (!paid ? offers.filter((o) => o.kind === 'plan' && o.plan === pid).sort((a, b) => a.price - b.price)[0] : null) || null;
    const hasYear = plans.some((p) => p.priceYear);
    if (!hasYear) period = 'month';
    const saveOf = (p) => (p.priceYear && p.price ? Math.round((1 - p.priceYear / (p.price * 12)) * 100) : 0);
    const maxSave = Math.max(0, ...plans.map(saveOf));
    const freeMonths = Math.max(0, ...plans.map((p) => (p.priceYear && p.price ? Math.round(12 - p.priceYear / p.price) : 0)));
    const popular = plans.length >= 3 ? plans[Math.floor(plans.length / 2)].id : (plans[0] || {}).id;
    const frac = paid && mine && mine.monthly ? (c.monthly || 0) / mine.monthly : (c.balance || 0) / Math.max(c.balance || 0, 120);

    head.replaceChildren(...kids(
      h('div', { class: 'pl-tt' }, h('h1', null, 'Crediti e piani'), h('p', null, 'I crediti servono per l\'AI e le Clip veloci. Montare a mano è sempre gratis.')),
      opts.onClose ? h('button', { class: 'pl-x', type: 'button', 'aria-label': 'Chiudi', onclick: opts.onClose }, icon('x', 14, 'currentColor', 2.2)) : null));
    const seg = (items, cur2, pick) => h('div', { class: 'pl-seg', role: 'tablist' }, ...items.map(([k, label, extra]) => h('button', { type: 'button', class: k === cur2 ? 'on' : '', role: 'tab', 'aria-selected': String(k === cur2), onclick: () => pick(k) }, label, extra || null)));
    const bar = h('div', { class: 'pl-bar' },
      seg([['plans', 'Abbonamenti'], ['packs', 'Ricariche']].filter(([k]) => (k === 'plans' ? plans : packs).length), mode, (k) => { mode = k; paint(); }),
      mode === 'plans' && hasYear ? seg([['month', 'Mensile'], ['year', 'Annuale', maxSave > 0 ? h('em', { class: 'pl-save' }, freeMonths >= 1 ? '−' + freeMonths + ' ' + (freeMonths === 1 ? byLang({ it: 'mese', en: 'month', fr: 'mois', de: 'Monat', pt: 'mês', es: 'mes' }) : byLang({ it: 'mesi', en: 'months', fr: 'mois', de: 'Monate', pt: 'meses', es: 'meses' })) : '−' + maxSave + '%') : null]], period, (k) => { period = k; paint(); }) : null,
      h('div', { class: 'grow' }),
      h('div', { class: 'pl-wallet' }, ring(frac), h('b', null, h('span', { 'data-notr': '' }, nf(c.balance)), ' ', h('span', null, 'crediti')),
        h('span', { class: 'pl-wsep' }),
        h('span', { class: 'pl-wplan' }, paid ? h('span', null, h('span', null, 'Piano'), ' ', h('span', { 'data-notr': '' }, c.planName || (mine || {}).name || cur), c.nextGrant ? h('span', null, ' · ', h('span', null, 'rinnovo il'), ' ', h('span', { 'data-notr': '' }, day(c.nextGrant))) : null) : 'Piano Gratis')));

    const yearly = period === 'year';
    let grid;
    if (mode === 'plans') {
      grid = h('div', { class: 'pl-grid n' + Math.min(4, plans.length) }, ...plans.map((p) => {
        const isMine = p.id === cur, pop = !paid && p.id === popular, po = !yearly ? planOff(p.id) : null, y = yearly && p.priceYear;
        const price = y ? p.priceYear / 12 : po ? po.price : p.price;
        // i numeri fuori dalla traduzione (in inglese il traduttore cambierebbe "1,200" in "1.200")
        const perks = [h('span', null, h('span', { 'data-notr': '' }, nf(p.monthly)), ' ', h('span', null, 'crediti al mese')), ...(p.perks || []).map((k) => h('span', { 'data-notr': '' }, k))].slice(0, 4);
        const det = nf(p.monthly) + ' ' + tx('crediti ogni mese');   // va alla pagina di pagamento gia' tradotto
        const btn = h('button', { type: 'button', class: 'pl-btn' + (isMine ? ' mine' : pop ? ' main' : ''), disabled: isMine ? true : null },
          isMine ? 'Il tuo piano' : h('span', null, h('span', null, 'Passa a'), ' ', h('span', { 'data-notr': '' }, p.name)));
        if (!isMine) {
          btn.onclick = () => (po
            ? buy('offer', po.id, null, { kind: 'plan', name: 'NoonFrame ' + p.name, plan: p.name, det, price: eur(po.price) }, btn)
            : buy('plan', p.id, y ? 'year' : 'month', { kind: 'plan', name: 'NoonFrame ' + p.name, plan: p.name, det, price: eur(y ? p.priceYear : p.price) }, btn));
        }
        return h('div', { class: 'pl-card' + (isMine ? ' mine' : pop ? ' pop' : '') },
          pop ? h('span', { class: 'pl-tag' }, 'Il più scelto') : null,
          h('b', { class: 'pl-name', 'data-notr': '' }, p.name),
          h('span', { class: 'pl-for', 'data-notr': '' }, p.tagline || ''),
          h('div', { class: 'pl-price' }, h('b', { class: 'tnum', 'data-notr': '' }, eur(price)), h('span', null, MO())),
          h('span', { class: 'pl-bill' }, y ? h('span', null, h('span', { 'data-notr': '' }, eur(p.priceYear)), ' ', h('span', null, 'all\'anno'))
            : po ? h('span', null, h('span', null, 'il primo mese, poi'), ' ', h('span', { 'data-notr': '' }, eur(p.price) + MO())) : 'Fatturato ogni mese'),
          h('ul', { class: 'pl-perks' }, ...perks.map((k) => h('li', null, tick(), k))),
          btn);
      }));
    } else {
      const per100 = (k) => (k.price / k.credits) * 100;
      const best = packs.reduce((b, k) => (!b || per100(k) < per100(b) ? k : b), null);
      grid = h('div', { class: 'pl-grid n' + Math.min(3, packs.length) }, ...packs.map((k, i) => {
        const tag = best && k.id === best.id ? 'Il migliore' : i === 1 && packs.length > 2 ? 'Conviene' : null;
        const btn = h('button', { type: 'button', class: 'pl-btn' + (tag ? ' main' : '') }, 'Compra');
        btn.onclick = () => buy('pack', k.id, null, { kind: 'pack', name: nf(k.credits) + ' ' + tx('crediti'), det: tx('Ricarica · non scadono'), price: eur(k.price) }, btn);
        return h('div', { class: 'pl-card pack' + (tag ? ' pop' : '') },
          tag ? h('span', { class: 'pl-tag' + (tag === 'Il migliore' ? ' ok' : '') }, tag) : null,
          h('div', { class: 'pl-cred' }, coin(18), h('b', { class: 'tnum', 'data-notr': '' }, nf(k.credits))),
          h('span', { class: 'pl-for' }, 'crediti, una volta sola · non scadono'),
          h('div', { class: 'pl-price' }, h('b', { class: 'tnum', 'data-notr': '' }, eur(k.price))),
          h('span', { class: 'pl-bill' }, h('span', { 'data-notr': '' }, eur(per100(k))), ' ', h('span', null, 'ogni 100 crediti')),
          btn);
      }));
    }
    const foot = h('div', { class: 'pl-foot' },
      h('span', null, icon('lock', 12, 'currentColor', 2), 'Pagamento sicuro con Stripe'), h('span', null, 'Prezzi IVA inclusa'),
      mode === 'plans' ? h('span', null, 'Disdici quando vuoi') : null, h('span', null, 'I crediti delle ricariche non scadono'),
      paid ? h('button', { type: 'button', class: 'linkish pl-manage', onclick: (e) => openPortal(e.currentTarget) }, 'Gestisci abbonamento') : null);
    body.replaceChildren(bar, grid, foot);
  }

  body.append(h('div', { class: 'pl-load' }, h('div', { class: 'spinner' })));
  load(true);
  const onChange = () => { if (!root.isConnected) { removeEventListener('nf-credits-changed', onChange); return; } load(true); };
  addEventListener('nf-credits-changed', onChange);
  return root;
}

// nell'editor: la stessa pagina in un foglio grande (cosi' non si lascia il montaggio)
export function plansSheet(tab) {
  const bg = h('div', { class: 'modal-bg pl-bg' });
  const close = () => { bg.remove(); removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.co-bg')) { e.stopPropagation(); close(); } };
  addEventListener('keydown', onKey, true);
  bg.append(h('div', { class: 'pl-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Crediti e piani' }, plansView({ tab, onClose: close })));
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
}
