// NoonFrame - stile delle clip: i passaggi prima di creare le clip (titolo d'apertura, sottotitoli, badge social),
// con l'anteprima verticale dal vivo e gli stili salvati con un nome (preset). Lo stesso stile poi vale per le clip
// nuove e, se lo chiedi, per quelle gia' fatte.
import { post, h, icon, toast, confirmBox, vertRegions } from './lib.js';
import { drawText, PLATFORMS, BADGE_STYLES, badgeLabel as badgeLabelIt, logoUrl, platformOf, badgeLogosReady as logosReady } from './text.js';
import { ensureFont, fontPicker, fontReady } from './fonts.js';
import { t as tx } from './i18n.js';

const badgeLabel = (pid) => tx(badgeLabelIt(pid));   // "Live su Twitch" nella lingua dell'app

// ---------------------------------------------------------------- titolo d'apertura
// grande, bianco con contorno, l'ultima parola colorata
export const HOOK_STYLE = { font: 'Montserrat', weight: 900, size: 0.056, color: '#FFFFFF', bold: true, upper: true, align: 'center', stroke: true,
  strokeColor: '#000000', strokeW: 0.1, shadow: true, crisp: true, hlColor: '#FFD60A', lineH: 1.06, v: 2 };
// stili pronti del titolo; poi lo personalizzi (font e colori del tuo brand)
export const HOOK_PRESETS = [
  ['classico', 'Classico', {}],
  ['verde', 'Verde', { hlColor: '#3DDC84' }],
  ['box', 'Riquadro', { color: '#111111', stroke: false, shadow: false, box: true, boxColor: '#FFFFFF', boxOp: 100, boxR: 0.22, hlColor: '#FF3B30' }],
  ['neon', 'Neon', { hlColor: '#FF4FD8', bloom: '#FF4FD8', bloomK: 0.4 }],
  ['pulito', 'Pulito', { font: 'Poppins', weight: 800, stroke: false, shadow: true, hlColor: '#3DDC84' }],
  ['impatto', 'Impatto', { font: 'Anton', weight: 400, upper: true, strokeW: 0.12, hlColor: '#FF5A1F' }],
  ['titolo', 'Titolo', { font: 'Bebas Neue', weight: 400, upper: true, strokeW: 0.08, hlColor: '#FFD60A', size: 0.066 }],
  ['morbido', 'Morbido', { font: 'Rubik', weight: 800, upper: false, stroke: false, box: true, boxColor: '#111114', boxOp: 86, boxR: 0.3, hlColor: '#6CB2FF', shadow: false }],
];
const HOOK_KEYS = ['font', 'color', 'hlColor', 'stroke', 'box', 'boxColor', 'size', 'strokeColor', 'strokeW', 'boxOp', 'upper', 'shadow', 'weight'];
export function hookStyle(u) {
  const pr = HOOK_PRESETS.find((x) => x[0] === (u && u.preset)) || HOOK_PRESETS[0];
  const own = {};
  for (const k of HOOK_KEYS) if (u && u[k] !== undefined && u[k] !== null && u[k] !== '') own[k] = u[k];
  return { ...HOOK_STYLE, ...pr[2], ...own };
}
export function hookContent(txt) {
  const w = String(txt || '').trim().split(/\s+/).filter(Boolean);
  if (!w.length) return '';
  const last = w.length > 1 ? w.pop() : null;
  let lines = [w.join(' ')];
  // due righe quando e' lunga (si legge meglio sul telefono)
  if ((w.join(' ') + (last ? ' ' + last : '')).length > 16 && w.length > 1) {
    const k = Math.ceil(w.length / 2);
    lines = [w.slice(0, k).join(' '), w.slice(k).join(' ')];
  }
  if (last) lines[lines.length - 1] = (lines[lines.length - 1] + ' *' + last + '*').trim();
  return lines.join('\n');
}
export const HOOK_ANIMS = [['pop', 'Pop'], ['slam', 'Slam'], ['rise', 'Dal basso'], ['zoom', 'Zoom'], ['tilt', 'Inclinato'], ['none', 'Nessuna']];

// ---------------------------------------------------------------- sottotitoli
export const SUB_PRESETS = [
  ['classico', 'Classico', { font: 'Montserrat', color: '#FFFFFF', hiColor: '#FFD60A', upper: true, stroke: true, strokeColor: '#000000', strokeW: 0.1, box: false, shadow: true, sizeV: 0.05 }],
  ['karaoke', 'Karaoke', { font: 'Poppins', color: '#FFFFFF', hiColor: '#3DDC84', upper: false, stroke: true, strokeColor: '#000000', strokeW: 0.09, box: false, shadow: true, sizeV: 0.048 }],
  ['riquadro', 'Riquadro', { font: 'Inter', color: '#FFFFFF', hiColor: '#FFD60A', upper: false, stroke: false, box: true, boxColor: '#000000', boxOp: 72, shadow: false, sizeV: 0.042 }],
  ['impatto', 'Impatto', { font: 'Anton', color: '#FFFFFF', hiColor: '#FF5A1F', upper: true, stroke: true, strokeColor: '#000000', strokeW: 0.12, box: false, shadow: true, sizeV: 0.056 }],
  ['pulito', 'Pulito', { font: 'Inter', color: '#FFFFFF', hiColor: '#6CB2FF', upper: false, stroke: false, box: false, shadow: true, sizeV: 0.044 }],
  ['titolo', 'Titolo', { font: 'Bebas Neue', color: '#FFFFFF', hiColor: '#FFD60A', upper: true, stroke: true, strokeColor: '#000000', strokeW: 0.08, box: false, shadow: true, sizeV: 0.06 }],
];
export const SUB_WORDS = [['parola', 'Una'], ['due', 'Due'], ['tre', 'Tre'], ['frase', 'Frase']];
export const SUB_FX = [['pop', 'Pop'], ['bounce', 'Rimbalzo'], ['fade', 'Dissolvenza'], ['rise', 'Dal basso'], ['slam', 'Da grande'], ['none', 'Nessuna']];
export const SUB_POS = [['auto', 'Automatica'], ['centro', 'Al centro'], ['basso', 'In basso']];

// ---------------------------------------------------------------- badge social
export const BADGE_ANIMS = [['slideL', 'Da sinistra'], ['slideR', 'Da destra'], ['pop', 'Pop'], ['drop', 'Cade'], ['zoom', 'Zoom']];
const BADGE_PLATS = PLATFORMS.filter((p) => p[0] !== 'custom');
const BADGE_SPOTS = [['tl', 'In alto a sinistra', 0.05, 0.05], ['tc', 'In alto al centro', null, 0.05], ['tr', 'In alto a destra', -0.05, 0.05],
  ['bl', 'In basso a sinistra', 0.05, 0.9], ['bc', 'In basso al centro', null, 0.9], ['br', 'In basso a destra', -0.05, 0.9]];
export function badgeSpec(b) {
  return { content: '', font: b.font || 'Inter', size: b.size || 0.032, color: '#FFFFFF', bold: true, italic: false, upper: !!b.upper, align: 'left',
    stroke: false, box: false, shadow: true, lineH: 1.15,
    badge: { platform: b.platform || 'twitch', style: b.style || 'pill', handle: b.handle || '', label: b.label ?? badgeLabel(b.platform || 'twitch'), accent: b.accent || '', logo: '' } };
}
// i loghi delle piattaforme caricati (al massimo qualche secondo: senza logo il badge si disegna lo stesso)
export function badgeLogosReady() {
  return Promise.race([logosReady(), new Promise((r) => setTimeout(r, 3000))]);
}

// ---------------------------------------------------------------- lo stile salvato
export function defaultLook() {
  return {
    preset: '',
    hook: { preset: 'classico', anim: 'pop' },
    subs: { preset: 'classico', ...SUB_PRESETS[0][2], hiOn: true, words: 'tre', effect: 'pop', pos: 'auto' },
    badge: { on: false, platform: 'twitch', handle: '', label: badgeLabel('twitch'), style: 'pill', accent: '', size: 0.032, x: 0.05, y: 0.05, anim: 'slideL', sound: true, when: 'always' },
  };
}
const clone = (x) => JSON.parse(JSON.stringify(x));
let cache = null;   // {look, presets, badges}
export async function loadLook(force) {
  if (cache && !force) return cache;
  let r = {};
  try { r = await post('/api/cliplook/get', {}); } catch (e) { r = {}; }
  const d = defaultLook();
  let look;
  if (r.look && r.look.hook) {
    look = { preset: r.look.preset || '', hook: { ...d.hook, ...r.look.hook }, subs: { ...d.subs, ...r.look.subs }, badge: { ...d.badge, ...r.look.badge } };
  } else {
    // stile scelto prima (titolo e sottotitoli separati): si parte da li'
    look = d;
    if (r.hookStyle) look.hook = { ...d.hook, ...r.hookStyle };
    const cs = r.clipSubs || {};
    for (const k of ['font', 'color', 'hiColor', 'upper', 'box', 'stroke', 'effect']) if (cs[k] !== undefined) look.subs[k] = cs[k];
    if (cs.size === 'medi') look.subs.sizeV = 0.04;
    if (cs.words === 'parola') look.subs.words = 'parola';
    else if (cs.words === 'frase') look.subs.words = 'frase';
    if (cs.pos && cs.pos !== 'cam') look.subs.pos = cs.pos;
    if ((look.subs.hiColor || '').toUpperCase() === '#3DDC84' && !cs.own) look.subs.hiColor = '#FFD60A';
  }
  // nome del canale ricordato dall'editor (badge social)
  const mem = (r.badges || {})[look.badge.platform];
  if (!look.badge.handle && mem && mem.handle) look.badge.handle = mem.handle;
  cache = { look, presets: Array.isArray(r.presets) ? r.presets : [], badges: r.badges || {}, saved: !!(r.look && r.look.hook) };
  return cache;
}
export function lookCache() { return cache; }
export function setLookCache(look, presets) {
  cache = { ...(cache || {}), look: clone(look), presets: presets ? clone(presets) : (cache ? cache.presets : []), saved: true };
}
// il titolo d'apertura con lo stile salvato (per disegnarlo nelle clip)
export async function savedHook() {
  const c = await loadLook();
  return c.look.hook;
}

// ---------------------------------------------------------------- disegno dell'anteprima
const ease = { outCubic: (p) => 1 - (1 - p) ** 3, outBack: (p) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2; } };
function outBounce(p) {
  const n1 = 7.5625, d1 = 2.75;
  if (p < 1 / d1) return n1 * p * p;
  if (p < 2 / d1) { p -= 1.5 / d1; return n1 * p * p + 0.75; }
  if (p < 2.5 / d1) { p -= 2.25 / d1; return n1 * p * p + 0.9375; }
  p -= 2.625 / d1; return n1 * p * p + 0.984375;
}
// come in engine/overlay.py (anim_edge): scala, spostamento, rotazione e trasparenza a p (0..1) dell'entrata
function edge(type, p, box) {
  p = Math.max(0, Math.min(1, p));
  const e = ease.outCubic(p), s = { k: 1, dx: 0, dy: 0, rot: 0, a: 1 };
  if (type === 'fade') s.a = p;
  else if (type === 'pop') { s.k = Math.max(0.01, 0.3 + 0.7 * ease.outBack(p)); s.a = Math.min(1, p * 3); }
  else if (type === 'zoom') { s.k = 1.5 - 0.5 * e; s.a = e; }
  else if (type === 'slideL') s.dx = -(box.x + box.w + 0.02) * (1 - e);
  else if (type === 'slideR') s.dx = (1 - box.x + 0.02) * (1 - e);
  else if (type === 'drop') s.dy = -(box.y + box.h + 0.02) * (1 - outBounce(p));
  else if (type === 'slam') { s.k = 1 + 1.4 * (1 - e); s.a = Math.min(1, p * 2.5); }
  else if (type === 'rise') { s.dy = 0.06 * (1 - e); s.a = e; }
  else if (type === 'tilt') { const b = ease.outBack(p); s.rot = -14 * (1 - b); s.k = Math.max(0.01, 0.6 + 0.4 * b); s.a = Math.min(1, p * 2.5); }
  return s;
}
// immagine (canvas) messa nel riquadro verticale: box in 0..1 del riquadro, con l'animazione d'entrata
function place(g, img, box, anim, p, W, H) {
  const s = anim && anim !== 'none' ? edge(anim, p, box) : { k: 1, dx: 0, dy: 0, rot: 0, a: 1 };
  if (s.a <= 0.001) return;
  const cx = (box.x + box.w / 2 + s.dx) * W, cy = (box.y + box.h / 2 + s.dy) * H;
  g.save();
  g.globalAlpha = s.a;
  g.translate(cx, cy);
  if (s.rot) g.rotate((s.rot * Math.PI) / 180);
  g.scale(s.k, s.k);
  g.drawImage(img, -box.w * W / 2, -box.h * H / 2, box.w * W, box.h * H);
  g.restore();
}
function hexA(hex, a) {
  let x = (hex || '#000').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
}
// i sottotitoli come nel video: font, grandezza, colori, contorno, ombra, riquadro; la parola detta colorata
function drawSubs(g, s, words, cur, W, H, yBottom, fx, p) {
  const px = Math.round((s.sizeV || 0.05) * H);
  const weight = /Anton|Bebas|Bangers|Luckiest|Lilita/.test(s.font || '') ? 400 : 800;
  g.save();
  g.font = `${weight} ${px}px "${s.font || 'Montserrat'}", Arial, sans-serif`;
  g.textBaseline = 'alphabetic'; g.lineJoin = 'round'; g.miterLimit = 2;
  const ws = words.map((w) => (s.upper ? w.toUpperCase() : w));
  const sp = g.measureText(' ').width;
  const widths = ws.map((w) => g.measureText(w).width);
  const tot = widths.reduce((a, b) => a + b, 0) + sp * (ws.length - 1);
  // entrata della frase
  let k = 1, a = 1, dy = 0;
  const q = Math.max(0, Math.min(1, p));
  if (fx === 'pop') k = 0.82 + 0.18 * Math.min(1, q / 0.85);
  else if (fx === 'bounce') k = q < 0.55 ? 0.62 + (1.12 - 0.62) * (q / 0.55) : 1.12 - 0.12 * ((q - 0.55) / 0.45);
  else if (fx === 'fade') a = q;
  else if (fx === 'rise') { dy = 0.028 * H * (1 - ease.outCubic(q)); a = Math.min(1, q * 1.4); }
  else if (fx === 'slam') { k = 1.5 - 0.5 * ease.outCubic(q); a = q; }
  const base = yBottom * H - px * 0.22 + dy;
  g.translate(W / 2, base - px * 0.35);
  g.scale(k, k);
  g.translate(-W / 2, -(base - px * 0.35));
  g.globalAlpha = a;
  if (s.box) {
    const pad = px * 0.22;
    g.fillStyle = hexA(s.boxColor || '#000000', (s.boxOp ?? 70) / 100);
    g.beginPath(); g.roundRect(W / 2 - tot / 2 - pad, base - px * 0.92 - pad * 0.4, tot + pad * 2, px * 1.18 + pad * 0.8, px * 0.12); g.fill();
  }
  let x = W / 2 - tot / 2;
  ws.forEach((w, i) => {
    if (s.shadow) { g.shadowColor = 'rgba(0,0,0,.55)'; g.shadowOffsetY = Math.max(1, px * 0.05); g.shadowBlur = px * 0.06; }
    if (s.stroke) { g.strokeStyle = s.strokeColor || '#000'; g.lineWidth = (s.strokeW ?? 0.1) * px * 2; g.strokeText(w, x, base); g.shadowColor = 'transparent'; }
    g.fillStyle = s.hiOn !== false && i === cur ? (s.hiColor || '#FFD60A') : (s.color || '#FFFFFF');
    g.fillText(w, x, base);
    g.shadowColor = 'transparent';
    x += widths[i] + sp;
  });
  g.restore();
}
const SAMPLE = ['quando', 'gli', 'ho', 'detto', 'la', 'verità', 'non', 'ci', 'poteva', 'credere'];
function chunksOf(words, mode) {
  const n = mode === 'parola' ? 1 : mode === 'due' ? 2 : mode === 'tre' ? 3 : 5;
  const out = [];
  for (let i = 0; i < words.length; i += n) out.push(words.slice(i, i + n));
  return out;
}

// ---------------------------------------------------------------- i passaggi
// opts: {title, lead, frame, cam (live di gaming con la webcam), autoSub, finalLabel,
//        onFinish(look, presets) -> promessa (salva e parte), quick (testo del pulsante per partire subito con lo stile salvato)}
// frame: url di un fotogramma (ritagliato al centro) o {src, W, H, lay, cam}: il fotogramma messo in verticale come
//        nella clip (webcam sopra e gioco sotto, due persone una sopra l'altra, una a tutto schermo...)
// autoSub: dove vanno i sottotitoli in automatico in quella clip ({y} o {camH} per quelli attaccati sotto la webcam)
// hookY: dove sta il titolo d'apertura in quella clip (0..1 dall'alto, o 'mid' sulla linea in mezzo)
export async function openStyleWizard(opts = {}) {
  const st = await loadLook();
  const look = clone(st.look);
  let presets = clone(st.presets || []);
  let step = 0;
  let alive = true;
  const STEPS = [['hook', 'Titolo'], ['subs', 'Sottotitoli'], ['badge', 'Badge social'], ['save', 'Salva']];
  const bg = h('div', { class: 'modal-bg sw-bg' });
  const box = h('div', { class: 'sw-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': opts.title || 'Stile delle clip' });
  bg.append(box);
  const close = () => { alive = false; bg.remove(); removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.fmenu')) { e.stopPropagation(); close(); if (opts.onCancel) opts.onCancel(); } };
  addEventListener('keydown', onKey, true);

  // anteprima: riquadro verticale 9:16 con lo sfondo (un fotogramma del video o due persone finte)
  const PW = 360, PH = 640;
  const cv = h('canvas', { class: 'sw-cv', width: PW, height: PH, 'aria-label': 'Anteprima della clip verticale' });
  const g = cv.getContext('2d');
  // lo sfondo (fotogramma gia' messo in verticale), fatto una volta sola
  let frame = null;
  const fr = opts.frame && typeof opts.frame === 'object' ? opts.frame : opts.frame ? { src: opts.frame } : null;
  if (fr && fr.src) {
    const im = new Image();
    im.onload = () => {
      const c = document.createElement('canvas'); c.width = PW; c.height = PH;
      const gg = c.getContext('2d');
      gg.fillStyle = '#0b0e14'; gg.fillRect(0, 0, PW, PH);
      if (fr.W && fr.H && fr.lay) {
        const lay = fr.lay;
        let kind = lay.layout || 'fit';
        if ((kind === 'split' || kind === 'cam') && !fr.cam) kind = 'fit';
        const k = im.naturalHeight / fr.H;
        const regs = vertRegions(kind, fr.W, fr.H, { cam: fr.cam, camH: lay.camH, gameX: lay.gameX, pad: lay.pad, boxes: lay.boxes, rect: lay.rect, top: lay.top, bot: lay.bot, fits: lay.fits });
        for (const r of regs) {
          const [dx, dy, dw, dh] = r.d, [sx, sy, sw, sh] = r.s;
          if (sw < 1 || sh < 1) continue;
          gg.save();
          if (r.blur) gg.filter = 'blur(9px) brightness(.9)';
          gg.drawImage(im, sx * k, sy * k, sw * k, sh * k, dx * PW, dy * PH, dw * PW, dh * PH);
          gg.restore();
        }
      } else {
        // ritagliato in verticale al centro (come una clip a tutto schermo)
        const k = Math.max(PW / im.naturalWidth, PH / im.naturalHeight);
        const w = im.naturalWidth * k, hh = im.naturalHeight * k;
        gg.drawImage(im, (PW - w) / 2, (PH - hh) / 2, w, hh);
      }
      gg.fillStyle = 'rgba(0,0,0,.12)'; gg.fillRect(0, 0, PW, PH);
      frame = c;
    };
    im.src = fr.src;
  }
  await badgeLogosReady();
  let t0 = performance.now();
  const restart = () => { t0 = performance.now(); };
  // cache delle immagini disegnate (si rifanno solo quando cambia lo stile)
  let hookImg = null, hookKey = '', badgeImg = null, badgeKey = '';
  const getHook = () => {
    const spec = { ...hookStyle(look.hook), content: hookContent('Non ci credo IMPOSSIBILE') };
    const k = JSON.stringify(spec);
    if (k !== hookKey) {
      hookKey = k;
      if (!fontReady(spec.font)) ensureFont(spec.font).then(() => { hookKey = ''; });   // font appena caricato: si ridisegna una volta
      hookImg = drawText(spec, PH);
    }
    return hookImg;
  };
  const getBadge = () => {
    const spec = badgeSpec(look.badge);
    const k = JSON.stringify(spec);
    if (k !== badgeKey) {
      badgeKey = k;
      if (!fontReady(spec.font)) ensureFont(spec.font).then(() => { badgeKey = ''; });
      badgeImg = drawText(spec, PH);
    }
    return badgeImg;
  };
  function background() {
    g.fillStyle = '#0b0e14'; g.fillRect(0, 0, PW, PH);
    if (frame) { g.drawImage(frame, 0, 0); return; }
    if (opts.cam) {
      // webcam sopra (una persona) e gioco sotto, solo forme morbide
      const ch = PH * 0.4;
      let gr = g.createLinearGradient(0, 0, 0, ch);
      gr.addColorStop(0, 'hsl(214 30% 22%)'); gr.addColorStop(1, 'hsl(214 28% 12%)');
      g.fillStyle = gr; g.fillRect(0, 0, PW, ch);
      g.fillStyle = 'hsl(214 22% 34%)';
      g.beginPath(); g.arc(PW / 2, ch * 0.42, PW * 0.12, 0, Math.PI * 2); g.fill();
      g.beginPath(); g.roundRect(PW / 2 - PW * 0.25, ch * 0.66, PW * 0.5, ch * 0.5, PW * 0.18); g.fill();
      gr = g.createLinearGradient(0, ch, PW, PH);
      gr.addColorStop(0, 'hsl(150 26% 18%)'); gr.addColorStop(0.55, 'hsl(196 30% 16%)'); gr.addColorStop(1, 'hsl(262 26% 14%)');
      g.fillStyle = gr; g.fillRect(0, ch, PW, PH - ch);
      g.fillStyle = 'rgba(255,255,255,.06)';
      for (let i = 0; i < 5; i++) { g.beginPath(); g.roundRect(PW * (0.1 + i * 0.17), PH * (0.62 + (i % 2) * 0.12), PW * 0.12, PH * 0.06, 6); g.fill(); }
      g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(0, ch - 1, PW, 2);
      return;
    }
    // due persone una sopra l'altra (come le clip con piu' persone), solo forme morbide
    for (const [y0, hue] of [[0, 214], [PH / 2, 262]]) {
      const gr = g.createLinearGradient(0, y0, 0, y0 + PH / 2);
      gr.addColorStop(0, `hsl(${hue} 30% 22%)`); gr.addColorStop(1, `hsl(${hue} 28% 12%)`);
      g.fillStyle = gr; g.fillRect(0, y0, PW, PH / 2);
      g.fillStyle = `hsl(${hue} 22% 34%)`;
      g.beginPath(); g.arc(PW / 2, y0 + PH * 0.2, PW * 0.13, 0, Math.PI * 2); g.fill();
      g.beginPath(); g.roundRect(PW / 2 - PW * 0.27, y0 + PH * 0.29, PW * 0.54, PH * 0.3, PW * 0.2); g.fill();
    }
    g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(0, PH / 2 - 1, PW, 2);
  }
  // il titolo dove sta nella clip (sulla linea tra le due persone, sotto la webcam, in alto), mai sopra il badge
  const hookBox = (img) => {
    const w = Math.min(0.9, img.width / PW), hh = w * (img.height / img.width) * PW / PH;
    const hy = opts.hookY ?? (opts.cam ? 0.33 : 'mid');
    let y = hy === 'mid' ? Math.max(0.05, 0.5 - hh / 2) : hy;
    if (look.badge.on && badgeImg) {
      const bx = badgeBox(badgeImg);
      if (y < bx.y + bx.h + 0.01 && y + hh > bx.y - 0.01) y = bx.y + bx.h / 2 < 0.5 ? bx.y + bx.h + 0.015 : Math.max(0.02, bx.y - hh - 0.015);
    }
    return { x: (1 - w) / 2, y: Math.max(0.02, Math.min(0.98 - hh, y)), w, h: hh };
  };
  const badgeBox = (img) => {
    const w = img.width / PW, hh = img.height / PH;
    const x = Math.max(0, Math.min(1 - w, look.badge.x)), y = Math.max(0, Math.min(1 - hh, look.badge.y));
    return { x, y, w, h: hh };
  };
  // dove vanno i sottotitoli (come nella clip): mai sopra il badge social
  const subY = () => {
    const s = look.subs, a = opts.autoSub || {};
    let y = s.pos === 'centro' ? 0.62 : s.pos === 'basso' ? 0.8
      : a.camH ? Math.min(0.86, a.camH + (s.sizeV || 0.05) * 1.25 + 0.012) : a.y ? a.y : opts.cam ? 0.55 : 0.534;
    if (look.badge.on && badgeImg) {
      const bx = badgeBox(badgeImg), size = s.sizeV || 0.05;
      if (y - size * 1.3 < bx.y + bx.h && y > bx.y) y = bx.y + bx.h / 2 > 0.5 ? bx.y - 0.012 : Math.min(0.92, bx.y + bx.h + 0.012 + size * 1.3);
    }
    return y;
  };
  let dragging = null;
  function paint(now) {
    if (!alive) return;
    const t = (now - t0) / 1000;
    background();
    const id = STEPS[step][0];
    // titolo: entra e resta 2,6 s, poi riparte
    if (id === 'hook' || id === 'save') {
      const cyc = id === 'hook' ? 2.8 : 6.5, tt = t % cyc;
      if (id === 'hook' || tt < 2.6) {
        const img = getHook();
        place(g, img, hookBox(img), look.hook.anim, tt / 0.35, PW, PH);
      }
    }
    // sottotitoli: frasi a ciclo con l'entrata scelta, la parola detta colorata
    if (id === 'subs' || id === 'save' || id === 'badge') {
      const all = chunksOf(SAMPLE, look.subs.words);
      const per = 0.95;
      const start = id === 'save' ? 2.6 : 0;
      const cyc = id === 'save' ? 6.5 : all.length * per + 0.6;
      const tt = (t % cyc) - start;
      if (id === 'badge') drawSubs(g, look.subs, all[0], 0, PW, PH, subY(), 'none', 1);
      else if (tt >= 0) {
        const ci = Math.min(all.length - 1, Math.floor(tt / per));
        if (tt < all.length * per) {
          const into = tt - ci * per, wcur = Math.min(all[ci].length - 1, Math.floor(into / (per / all[ci].length)));
          drawSubs(g, look.subs, all[ci], wcur, PW, PH, subY(), look.subs.effect, into / 0.17);
        }
      }
    }
    // badge: con l'entrata scelta; nel passaggio del badge si sposta e si ridimensiona qui
    if (look.badge.on) {
      const img = getBadge();
      const bx = badgeBox(img);
      // nell'ultimo passaggio come nella clip: entra subito dopo l'inizio, resta tutta la clip o 4,5 s
      const tt = id === 'save' ? t % 6.5 : t % 4.5;
      const p = dragging || (id !== 'badge' && id !== 'save') ? 1 : (tt - 0.25) / 0.55;
      if (!(id === 'save' && look.badge.when === 'start' && tt > 4.75)) place(g, img, bx, look.badge.anim, p, PW, PH);
      if (id === 'badge') {
        g.save(); g.strokeStyle = 'rgba(108,178,255,.95)'; g.lineWidth = 1.5; g.setLineDash([5, 4]);
        g.strokeRect(bx.x * PW - 4, bx.y * PH - 4, bx.w * PW + 8, bx.h * PH + 8); g.setLineDash([]);
        g.fillStyle = '#6CB2FF'; g.beginPath(); g.arc(bx.x * PW + bx.w * PW + 4, bx.y * PH + bx.h * PH + 4, 6, 0, Math.PI * 2); g.fill();
        g.restore();
      }
    }
    requestAnimationFrame(paint);
  }

  // trascina il badge nell'anteprima (e l'angolo per ingrandirlo)
  cv.addEventListener('pointerdown', (e) => {
    if (STEPS[step][0] !== 'badge' || !look.badge.on) return;
    const r = cv.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    const bx = badgeBox(getBadge());
    const corner = Math.abs(px - (bx.x + bx.w)) < 0.05 && Math.abs(py - (bx.y + bx.h)) < 0.04;
    if (!corner && !(px >= bx.x - 0.02 && px <= bx.x + bx.w + 0.02 && py >= bx.y - 0.02 && py <= bx.y + bx.h + 0.02)) return;
    e.preventDefault();
    cv.setPointerCapture(e.pointerId);
    dragging = { corner, px, py, x: bx.x, y: bx.y, size: look.badge.size, w: bx.w };
  });
  cv.addEventListener('pointermove', (e) => {
    const r = cv.getBoundingClientRect(), px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
    if (!dragging) {
      if (STEPS[step][0] === 'badge' && look.badge.on) {
        const bx = badgeBox(getBadge());
        const corner = Math.abs(px - (bx.x + bx.w)) < 0.05 && Math.abs(py - (bx.y + bx.h)) < 0.04;
        const inside = px >= bx.x && px <= bx.x + bx.w && py >= bx.y && py <= bx.y + bx.h;
        cv.style.cursor = corner ? 'nwse-resize' : inside ? 'move' : '';
      }
      return;
    }
    if (dragging.corner) {
      // l'angolo: la grandezza segue la larghezza del badge
      const nw = Math.max(0.12, Math.min(0.95, dragging.w + (px - dragging.px)));
      look.badge.size = +Math.max(0.018, Math.min(0.08, dragging.size * nw / dragging.w)).toFixed(4);
      syncBadgeSize();
    } else {
      look.badge.x = +Math.max(0, Math.min(0.98, dragging.x + px - dragging.px)).toFixed(4);
      look.badge.y = +Math.max(0, Math.min(0.97, dragging.y + py - dragging.py)).toFixed(4);
    }
  });
  const endDrag = () => { if (dragging) { dragging = null; restart(); draw(); } };
  cv.addEventListener('pointerup', endDrag);
  cv.addEventListener('pointercancel', endDrag);
  let syncBadgeSize = () => {};

  // ---- controlli
  const body = h('div', { class: 'sw-ctl' });
  const stepper = h('ol', { class: 'sw-steps' });
  const backBtn = h('button', { class: 'btn ghost', type: 'button' }, 'Indietro');
  const nextBtn = h('button', { class: 'btn primary', type: 'button' });
  const quickBtn = opts.quick && st.saved ? h('button', { class: 'btn ghost sw-quick', type: 'button' }, opts.quick) : null;
  const presetSel = h('select', { class: 'sw-psel', 'aria-label': 'Stile salvato' });
  function drawPresetSel() {
    presetSel.replaceChildren(h('option', { value: '' }, presets.length ? 'Stile attuale' : 'Nessuno stile salvato'),
      ...presets.map((p) => h('option', { value: p.id, selected: p.id === look.preset ? true : null }, p.name)));
    presetSel.disabled = !presets.length;
  }
  presetSel.addEventListener('change', () => {
    const p = presets.find((x) => x.id === presetSel.value);
    if (!p) return;
    const d = defaultLook();
    look.preset = p.id;
    look.hook = { ...d.hook, ...clone(p.hook || {}) };
    look.subs = { ...d.subs, ...clone(p.subs || {}) };
    look.badge = { ...d.badge, ...clone(p.badge || {}) };
    hookKey = badgeKey = '';
    restart(); draw();
  });

  // pezzi riusabili dei controlli
  const row = (label, ...els) => h('div', { class: 'sw-row' }, h('span', { class: 'sw-lbl' }, label), h('div', { class: 'sw-val' }, ...els));
  const segOf = (opts_, cur, onPick, label) => h('div', { class: 'seg sw-seg', role: 'group', 'aria-label': label },
    ...opts_.map(([k, l]) => h('button', { type: 'button', 'aria-pressed': String(cur === k), onclick: () => { onPick(k); restart(); draw(); } }, l)));
  const colorIn = (val, onIn, label) => {
    const c = h('input', { type: 'color', class: 'sw-col', value: val || '#FFFFFF', 'aria-label': label });
    c.addEventListener('input', () => { onIn(c.value.toUpperCase()); });
    return c;
  };
  const toggle = (on, onT, label) => {
    const b = h('button', { type: 'button', class: 'sw-tog' + (on ? ' on' : ''), role: 'switch', 'aria-checked': String(!!on), 'aria-label': label },
      h('i'));
    b.addEventListener('click', () => { const v = !b.classList.contains('on'); b.classList.toggle('on', v); b.setAttribute('aria-checked', String(v)); onT(v); draw(); });
    return b;
  };
  const slider = (val, min, max, stepv, fmt, onIn, label) => {
    const out = h('output', { class: 'sw-out' }, fmt(val));
    const r = h('input', { type: 'range', class: 'sw-rng', min, max, step: stepv, value: val, 'aria-label': label });
    r.addEventListener('input', () => { const v = parseFloat(r.value); out.textContent = fmt(v); onIn(v); });
    r.setValue = (v) => { r.value = v; out.textContent = fmt(v); };
    return h('div', { class: 'sw-sl' }, r, out);
  };
  const pxOf = (v) => Math.round(v * 1920) + ' px';
  const pct = (v) => Math.round(v) + '%';

  const colsFor = (n) => (n % 4 === 0 ? 4 : 3);
  function presetChips(list, cur, render, onPick) {
    return h('div', { class: 'sw-chips', style: '--cols:' + colsFor(list.length) }, ...list.map(([k, name, s]) => {
      const c = render(s, k);
      return h('button', { type: 'button', class: 'sw-chip' + (cur === k ? ' on' : ''), 'aria-pressed': String(cur === k), onclick: () => { onPick(k, s); hookKey = badgeKey = ''; restart(); draw(); } },
        h('span', { class: 'sw-chip-pv' }, c), h('span', { class: 'sw-chip-n' }, name));
    }));
  }

  function hookStep() {
    const u = look.hook, s = hookStyle(u);
    const own = (k, v) => { u[k] = v; hookKey = ''; };
    return [
      h('p', { class: 'sw-lead' }, 'La scritta grande dei primi secondi. Parti da uno stile e mettici font e colori del tuo brand.'),
      presetChips(HOOK_PRESETS, u.preset, (pst) => { const cvs = drawText({ ...HOOK_STYLE, ...pst, size: 0.11, content: 'Ci *credo*' }, 300); cvs.className = 'sw-chip-cv'; return cvs; },
        (k) => { look.hook = { preset: k, anim: u.anim }; }),
      row('Font', fontPicker(s.font, (v) => { own('font', v); draw(); })),
      row('Grandezza', slider(s.size, 0.04, 0.09, 0.001, pxOf, (v) => own('size', +v.toFixed(3)), 'Grandezza del titolo')),
      row('Colori', colorIn(s.color, (v) => own('color', v), 'Colore del testo'), h('small', { class: 'sw-hint' }, 'Testo'),
        colorIn(s.hlColor || '#FFD60A', (v) => own('hlColor', v), 'Colore della parola in evidenza'), h('small', { class: 'sw-hint' }, 'Parola in evidenza')),
      row('Sfondo', toggle(!!s.box, (v) => { own('box', v); if (v && !hookStyle(u).boxColor) own('boxColor', '#FFFFFF'); }, 'Sfondo dietro al titolo'),
        s.box ? colorIn(s.boxColor || '#FFFFFF', (v) => own('boxColor', v), 'Colore dello sfondo') : null,
        s.box ? slider(s.boxOp ?? 100, 20, 100, 1, pct, (v) => own('boxOp', Math.round(v)), 'Opacità dello sfondo') : null),
      row('Bordo', toggle(!!s.stroke, (v) => own('stroke', v), 'Contorno del testo'),
        s.stroke ? colorIn(s.strokeColor || '#000000', (v) => own('strokeColor', v), 'Colore del contorno') : null,
        s.stroke ? slider(s.strokeW ?? 0.1, 0.03, 0.2, 0.005, (v) => Math.round(v * 100) + '%', (v) => own('strokeW', +v.toFixed(3)), 'Spessore del contorno') : null),
      row('Testo', toggle(!!s.upper, (v) => own('upper', v), 'Tutto maiuscolo'), h('small', { class: 'sw-hint' }, 'Maiuscolo'),
        toggle(!!s.shadow, (v) => own('shadow', v), 'Ombra'), h('small', { class: 'sw-hint' }, 'Ombra')),
      row('Entrata', segOf(HOOK_ANIMS, u.anim || 'pop', (k) => { u.anim = k; }, 'Come entra il titolo')),
    ];
  }

  function subsStep() {
    const s = look.subs;
    const set = (k, v) => { s[k] = v; };
    return [
      h('p', { class: 'sw-lead' }, 'Come si leggono le parole: font, grandezza, colori, quante parole per volta e come entrano.'),
      presetChips(SUB_PRESETS, s.preset, (pst) => {
        const c = document.createElement('canvas'); c.width = 150; c.height = 64; c.className = 'sw-chip-cv';
        const gg = c.getContext('2d');
        drawSubs(gg, { ...pst, sizeV: 0.22, hiOn: true }, ['Che', 'bello'], 1, 150, 64, 0.82, 'none', 1);
        return c;
      }, (k, pst) => { Object.assign(s, clone(pst), { preset: k }); }),
      row('Font', fontPicker(s.font || 'Montserrat', (v) => { set('font', v); ensureFont(v); draw(); })),
      row('Grandezza', slider(s.sizeV || 0.05, 0.028, 0.075, 0.001, pxOf, (v) => set('sizeV', +v.toFixed(3)), 'Grandezza dei sottotitoli')),
      row('Colori', colorIn(s.color, (v) => set('color', v), 'Colore del testo'), h('small', { class: 'sw-hint' }, 'Testo'),
        colorIn(s.hiColor || '#FFD60A', (v) => set('hiColor', v), 'Colore della parola detta'),
        toggle(s.hiOn !== false, (v) => set('hiOn', v), 'Parola detta colorata'), h('small', { class: 'sw-hint' }, 'Parola detta')),
      row('Sfondo', toggle(!!s.box, (v) => set('box', v), 'Riquadro dietro ai sottotitoli'),
        s.box ? colorIn(s.boxColor || '#000000', (v) => set('boxColor', v), 'Colore del riquadro') : null,
        s.box ? slider(s.boxOp ?? 70, 20, 100, 1, pct, (v) => set('boxOp', Math.round(v)), 'Opacità del riquadro') : null),
      row('Bordo', toggle(!!s.stroke, (v) => set('stroke', v), 'Contorno'),
        s.stroke ? colorIn(s.strokeColor || '#000000', (v) => set('strokeColor', v), 'Colore del contorno') : null,
        s.stroke ? slider(s.strokeW ?? 0.1, 0.03, 0.2, 0.005, (v) => Math.round(v * 100) + '%', (v) => set('strokeW', +v.toFixed(3)), 'Spessore del contorno') : null),
      row('Testo', toggle(!!s.upper, (v) => set('upper', v), 'Tutto maiuscolo'), h('small', { class: 'sw-hint' }, 'Maiuscolo'),
        toggle(!!s.shadow, (v) => set('shadow', v), 'Ombra'), h('small', { class: 'sw-hint' }, 'Ombra')),
      row('Parole per volta', segOf(SUB_WORDS, s.words || 'tre', (k) => set('words', k), 'Parole per volta')),
      row('Entrata', segOf(SUB_FX, s.effect || 'pop', (k) => set('effect', k), 'Come entrano')),
      row('Posizione', segOf(SUB_POS, s.pos || 'auto', (k) => set('pos', k), 'Dove stanno')),
      h('p', { class: 'sw-note' }, s.pos === 'auto' ? 'Automatica: sulla linea tra le due persone, in basso quando una è a tutto schermo, sotto la webcam nelle live di gaming.' : ''),
    ];
  }

  function badgeStep() {
    const b = look.badge;
    const set = (k, v) => { b[k] = v; badgeKey = ''; };
    const nameIn = h('input', { class: 'input sw-in', value: b.handle || '', placeholder: 'nomedelcanale', maxlength: '40', spellcheck: 'false', 'aria-label': 'Nome del canale' });
    nameIn.addEventListener('input', () => { set('handle', nameIn.value.replace(/^@+/, '').trim()); restart(); });
    const labIn = h('input', { class: 'input sw-in', value: b.label ?? '', placeholder: 'Niente (solo il nome)', maxlength: '40', 'aria-label': 'Scritta sopra al nome' });
    labIn.addEventListener('input', () => { set('label', labIn.value); });
    const sz = slider(b.size || 0.032, 0.018, 0.07, 0.001, pxOf, (v) => { set('size', +v.toFixed(4)); }, 'Grandezza del badge');
    syncBadgeSize = () => { sz.firstChild.setValue(look.badge.size); badgeKey = ''; };
    const plats = h('div', { class: 'sw-plats' }, ...BADGE_PLATS.map(([id, name]) => h('button', { type: 'button', class: 'bdg-p' + (b.platform === id ? ' on' : ''), 'aria-pressed': String(b.platform === id),
      onclick: () => {
        if (b.label === badgeLabel(b.platform) || !b.label) b.label = badgeLabel(id);
        const mem = (st.badges || {})[id];
        if (mem && mem.handle && !b.handle) b.handle = mem.handle;
        b.platform = id; b.accent = ''; badgeKey = ''; restart(); draw();
      } }, h('img', { src: logoUrl(id, 'free'), alt: '', class: id === 'kick' ? 'wide' : null }), h('span', null, name))));
    const styles = h('div', { class: 'sw-chips', style: '--cols:' + colsFor(BADGE_STYLES.length) }, ...BADGE_STYLES.map(([id, name]) => {
      const c = drawText(badgeSpec({ ...b, style: id, size: 0.05, handle: b.handle || 'nomecanale' }), 360);
      c.className = 'sw-chip-cv';
      return h('button', { type: 'button', class: 'sw-chip' + (b.style === id ? ' on' : ''), 'aria-pressed': String(b.style === id), onclick: () => { set('style', id); restart(); draw(); } },
        h('span', { class: 'sw-chip-pv' }, c), h('span', { class: 'sw-chip-n' }, name));
    }));
    const curSpot = spotKey(b);
    const spots = h('div', { class: 'sw-spots', role: 'group', 'aria-label': 'Posizioni pronte' }, ...BADGE_SPOTS.map(([k, name, x, y]) => h('button', { type: 'button', class: 'sw-spot ' + k + (k === curSpot ? ' on' : ''), 'data-tip': name, 'aria-label': name, 'aria-pressed': String(k === curSpot),
      onclick: () => {
        const img = getBadge(), w = img.width / PW, hh = img.height / PH;
        b.x = +(x === null ? (1 - w) / 2 : x < 0 ? 1 - w + x : x).toFixed(4);
        b.y = +(y > 0.5 ? Math.min(0.97 - hh, y - hh) : y).toFixed(4);
        restart(); draw();
      } }, h('i'))));
    const off = !b.on;
    return [
      h('p', { class: 'sw-lead' }, 'Il nome del tuo canale con il logo della piattaforma: entra con un\'animazione e un woosh. Trascinalo nell\'anteprima per spostarlo, tira l\'angolo per ingrandirlo.'),
      row('Badge', toggle(!!b.on, (v) => { b.on = v; restart(); draw(); }, 'Metti il badge nelle clip'), h('small', { class: 'sw-hint' }, b.on ? 'Nelle clip' : 'Spento')),
      off ? null : row('Piattaforma', plats),
      off ? null : row('Nome del canale', nameIn),
      off ? null : row('Scritta sopra', labIn),
      off ? null : row('Stile', styles),
      off ? null : row('Colore', colorIn(b.accent || platformOf(b.platform)[2], (v) => set('accent', v), 'Colore del badge'),
        b.accent ? h('button', { type: 'button', class: 'btn sm ghost', onclick: () => { set('accent', ''); draw(); } }, 'Colore di ' + platformOf(b.platform)[1]) : null),
      off ? null : row('Grandezza', sz),
      off ? null : row('Posizione', spots),
      off ? null : row('Entrata', segOf(BADGE_ANIMS, b.anim || 'slideL', (k) => set('anim', k), 'Come entra il badge')),
      off ? null : row('Suono', toggle(b.sound !== false, (v) => set('sound', v), 'Woosh quando entra'), h('small', { class: 'sw-hint' }, 'Woosh')),
      off ? null : row('Quando', segOf([['always', 'Tutta la clip'], ['start', 'Solo all\'inizio']], b.when || 'always', (k) => set('when', k), 'Quanto resta')),
    ].filter(Boolean);
  }

  const nameIn = h('input', { class: 'input sw-in', maxlength: '40', placeholder: 'Es. Il mio stile', 'aria-label': 'Nome dello stile' });
  function saveStep() {
    const cur = presets.find((p) => p.id === look.preset);
    if (!nameIn.value) nameIn.value = cur ? cur.name : '';
    const list = h('div', { class: 'sw-plist' }, ...presets.map((p) => h('div', { class: 'sw-pitem' + (p.id === look.preset ? ' on' : '') },
      h('span', { 'data-notr': '' }, p.name),
      h('button', { type: 'button', class: 'iconbtn sm', 'aria-label': 'Elimina lo stile ' + p.name, onclick: async () => {
        if (!await confirmBox('Eliminare lo stile?', `«${p.name}» non sarà più tra gli stili salvati. Le clip già fatte restano come sono.`, 'Elimina', true)) return;
        presets = presets.filter((x) => x.id !== p.id);
        if (look.preset === p.id) look.preset = '';
        drawPresetSel(); draw();
      } }, icon('x', 12, 'currentColor', 2.4)))));
    return [
      h('p', { class: 'sw-lead' }, 'Così escono le clip. Dagli un nome per ritrovarlo tra gli stili salvati, anche nelle prossime live.'),
      recap(),
      row('Nome', nameIn),
      cur ? h('p', { class: 'sw-note' }, `Salvando aggiorni «${cur.name}». Cambia il nome per salvarlo come stile nuovo.`) : null,
      presets.length ? row('Stili salvati', list) : null,
    ].filter(Boolean);
  }

  // riepilogo delle scelte, con il passaggio da riaprire per cambiarle
  const nameOf = (list, k) => (list.find((x) => x[0] === k) || [])[1] || '';
  const WORDS_TXT = { parola: '1 parola per volta', due: '2 parole per volta', tre: '3 parole per volta', frase: 'Frase intera' };
  function spotKey(b) {
    const img = getBadge(), w = img.width / PW, hh = img.height / PH;
    const cx = b.x + w / 2, cy = b.y + hh / 2;
    // dal bordo a cui e' attaccato (un badge largo ha il centro quasi in mezzo anche quando sta a destra)
    const L = b.x < 0.1, R = b.x + w > 0.9;
    const col = L && !R ? 'l' : R && !L ? 'r' : L && R ? 'c' : cx < 0.38 ? 'l' : cx > 0.62 ? 'r' : 'c';
    return (cy < 0.5 ? 't' : 'b') + col;
  }
  const spotOf = (b) => nameOf(BADGE_SPOTS, spotKey(b));
  function recap() {
    const hs = hookStyle(look.hook), s = look.subs, b = look.badge;
    const dot = (c) => h('i', { class: 'sw-dot', style: 'background:' + (c || '#FFFFFF') });
    const sep = () => h('span', { 'aria-hidden': 'true' }, '·');
    const line = (i, label, ...parts) => h('div', { class: 'sw-sum-r' },
      h('span', { class: 'sw-lbl' }, label),
      h('div', { class: 'sw-sum-t' }, ...parts),
      h('button', { type: 'button', class: 'btn sm ghost', onclick: () => { step = i; restart(); draw(); } }, 'Modifica'));
    return h('div', { class: 'sw-sum' },
      line(0, 'Titolo', dot(hs.color), dot(hs.hlColor), h('b', { 'data-notr': '' }, hs.font), sep(), h('span', null, pxOf(hs.size)), sep(),
        h('span', null, 'Entrata ' + nameOf(HOOK_ANIMS, look.hook.anim || 'pop'))),
      line(1, 'Sottotitoli', dot(s.color), s.hiOn !== false ? dot(s.hiColor) : null, h('b', { 'data-notr': '' }, s.font || 'Montserrat'), sep(),
        h('span', null, pxOf(s.sizeV || 0.05)), sep(), h('span', null, WORDS_TXT[s.words] || WORDS_TXT.tre), sep(),
        h('span', null, 'Entrata ' + nameOf(SUB_FX, s.effect || 'pop'))),
      line(2, 'Badge social', ...(b.on && b.handle
        ? [h('img', { src: logoUrl(b.platform, 'free'), alt: '', style: 'height:16px;width:auto' }), h('b', { 'data-notr': '' }, b.handle), sep(), h('span', null, spotOf(b))]
        : [h('span', { class: 'sw-sum-off' }, 'Spento')])));
  }

  function draw() {
    stepper.replaceChildren(...STEPS.map(([k, name], i) => h('li', { class: 'sw-step' + (i === step ? ' cur' : i < step ? ' done' : '') },
      h('button', { type: 'button', onclick: () => { step = i; restart(); draw(); }, 'aria-current': i === step ? 'step' : null }, h('b', null, String(i + 1)), h('span', null, name)))));
    const id = STEPS[step][0];
    body.replaceChildren(...(id === 'hook' ? hookStep() : id === 'subs' ? subsStep() : id === 'badge' ? badgeStep() : saveStep()));
    backBtn.style.visibility = step ? 'visible' : 'hidden';
    nextBtn.textContent = step < STEPS.length - 1 ? 'Avanti' : (opts.finalLabel || 'Salva');
    if (step === STEPS.length - 1) nextBtn.prepend(icon('sparkle', 14, '#fff', 2.2));
  }
  async function finish() {
    if (look.badge.on && !String(look.badge.handle || '').trim()) { step = 2; draw(); toast('Scrivi il nome del canale per il badge, o spegnilo', true); return; }
    const nm = nameIn.value.trim();
    if (nm) {
      const cur = presets.find((p) => p.id === look.preset);
      const same = cur && cur.name === nm ? cur : presets.find((p) => p.name.toLowerCase() === nm.toLowerCase());
      const data = { name: nm.slice(0, 40), hook: clone(look.hook), subs: clone(look.subs), badge: clone(look.badge), at: Date.now() };
      if (same) { Object.assign(same, data); look.preset = same.id; }
      else { const id = 'st' + Math.random().toString(36).slice(2, 9); presets.unshift({ id, ...data }); look.preset = id; }
    }
    nextBtn.disabled = true;
    const old = nextBtn.textContent;
    nextBtn.textContent = 'Un attimo…';
    try {
      await (opts.onFinish ? opts.onFinish(clone(look), clone(presets)) : post('/api/cliplook', { look, presets }));
      setLookCache(look, presets);
      close();
    } catch (e) {
      nextBtn.disabled = false; nextBtn.textContent = old;
      toast(e.message, true);
    }
  }
  backBtn.addEventListener('click', () => { if (step) { step -= 1; restart(); draw(); } });
  nextBtn.addEventListener('click', () => { if (step < STEPS.length - 1) { step += 1; restart(); draw(); } else finish(); });
  if (quickBtn) quickBtn.addEventListener('click', () => { step = STEPS.length - 1; draw(); finish(); });

  drawPresetSel();
  box.append(
    h('div', { class: 'sw-head' },
      h('div', { class: 'sw-ttl' }, h('h2', null, opts.title || 'Stile delle clip'), opts.lead ? h('p', null, opts.lead) : null),
      h('label', { class: 'sw-pwrap' }, h('span', null, 'Stile salvato'), presetSel),
      h('button', { class: 'iconbtn sw-x', type: 'button', 'aria-label': 'Chiudi', onclick: () => { close(); if (opts.onCancel) opts.onCancel(); } }, icon('x', 16, 'currentColor', 2.2))),
    stepper,
    h('div', { class: 'sw-main' }, h('div', { class: 'sw-pvw' }, cv, h('small', { class: 'sw-pvn' }, 'Anteprima: la clip vera prende colori e font da qui')), body),
    h('div', { class: 'sw-foot' }, backBtn, h('div', { class: 'grow' }), quickBtn, nextBtn));
  document.body.append(bg);
  draw();
  requestAnimationFrame(paint);
  return { close };
}
