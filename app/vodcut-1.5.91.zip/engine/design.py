"""Grafica: i progetti dell'editor grafico (livelli, pagine, immagini) e le loro esportazioni.

Ogni grafica e' una cartella in VODcut/grafiche/<id>: design.json (il documento), cover.png (anteprima per la home)
e files/ (immagini importate, pittura, maschere). Tutto resta nella cartella: si sposta e si copia intera."""
import json
import os
import re
import secrets
import shutil
import struct
import time

from .util import APP_DIR

DESIGNS_DIR = os.path.join(APP_DIR, "grafiche")
TRASH_DIR = os.path.join(DESIGNS_DIR, ".cestino")
EXPORT_DIR = os.path.join(APP_DIR, "immagini")
TRASH_DAYS = 30
MAX_DOC = 40 * 1024 * 1024        # il documento (senza immagini) non puo' essere piu' grande di cosi'
MAX_FILE = 120 * 1024 * 1024      # una singola immagine
MAX_SIDE = 16000                  # lato massimo della tela in pixel
ID_RE = re.compile(r"^g[0-9a-f]{10}$")
FILE_RE = re.compile(r"^[a-z0-9_]{1,40}\.(png|jpg|webp)$")
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")


def _dir(gid):
    if not ID_RE.match(str(gid or "")):
        raise FileNotFoundError(gid)
    return os.path.join(DESIGNS_DIR, gid)


def _sniff(data):
    """Formato dai primi byte (non dal nome): solo immagini vere."""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def _now():
    return round(time.time(), 3)


def _write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


def new_id():
    return "g" + secrets.token_hex(5)


def create(name="Grafica senza titolo", w=1080, h=1080, bg="#FFFFFF", preset="", pages=1):
    w, h, pages = int(w), int(h), max(1, min(20, int(pages or 1)))
    if not (1 <= w <= MAX_SIDE and 1 <= h <= MAX_SIDE):
        raise ValueError("Misure non valide")
    gid = new_id()
    d = _dir(gid)
    os.makedirs(os.path.join(d, "files"), exist_ok=True)
    doc = {"id": gid, "v": 1, "name": (str(name or "").strip() or "Grafica senza titolo")[:120], "w": w, "h": h, "preset": str(preset or "")[:40],
           "created": _now(), "updated": _now(),
           "pages": [{"id": "p" + secrets.token_hex(4), "name": f"Pagina {i + 1}", "bg": bg if bg is None else str(bg)[:20], "layers": []} for i in range(pages)]}
    _write_json(os.path.join(d, "design.json"), doc)
    return doc


def load(gid):
    with open(os.path.join(_dir(gid), "design.json"), encoding="utf-8") as f:
        return json.load(f)


def save(gid, doc):
    """Salva il documento che manda l'editor (alcuni campi li decide solo il server)."""
    cur = load(gid)
    if not isinstance(doc, dict) or not isinstance(doc.get("pages"), list) or not doc["pages"]:
        raise ValueError("Documento non valido")
    w, h = int(doc.get("w") or cur["w"]), int(doc.get("h") or cur["h"])
    if not (1 <= w <= MAX_SIDE and 1 <= h <= MAX_SIDE):
        raise ValueError("Misure non valide")
    doc["id"], doc["created"], doc["v"] = cur["id"], cur.get("created") or _now(), 1
    doc["w"], doc["h"] = w, h
    doc["name"] = (str(doc.get("name") or "").strip() or cur.get("name") or "Grafica")[:120]
    doc["updated"] = _now()
    raw = json.dumps(doc, ensure_ascii=False, separators=(",", ":"))
    if len(raw) > MAX_DOC:
        raise ValueError("Grafica troppo grande")
    tmp = os.path.join(_dir(gid), "design.json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(raw)
    os.replace(tmp, os.path.join(_dir(gid), "design.json"))
    return {"ok": True, "updated": doc["updated"]}


def list_all():
    out = []
    if not os.path.isdir(DESIGNS_DIR):
        return out
    for gid in os.listdir(DESIGNS_DIR):
        if not ID_RE.match(gid):
            continue
        try:
            d = load(gid)
        except Exception:
            continue
        out.append({"id": gid, "name": d.get("name"), "w": d.get("w"), "h": d.get("h"), "updated": d.get("updated") or 0,
                    "pages": len(d.get("pages") or []), "preset": d.get("preset") or "", "folder": d.get("folder") or "",
                    "cover": os.path.isfile(os.path.join(_dir(gid), "cover.png"))})
    out.sort(key=lambda x: -(x["updated"] or 0))
    return out


def meta(gid, data):
    doc = load(gid)
    if "name" in data and str(data["name"]).strip():
        doc["name"] = str(data["name"]).strip()[:120]
    if "folder" in data:
        doc["folder"] = str(data.get("folder") or "")[:80]
    doc["updated"] = _now()
    _write_json(os.path.join(_dir(gid), "design.json"), doc)
    return {"id": gid, "name": doc["name"], "folder": doc.get("folder") or ""}


def duplicate(gid):
    src = _dir(gid)
    nid = new_id()
    shutil.copytree(src, _dir(nid))
    doc = load(nid)
    doc["id"], doc["name"], doc["created"], doc["updated"] = nid, (doc.get("name") or "Grafica") + " (copia)", _now(), _now()
    _write_json(os.path.join(_dir(nid), "design.json"), doc)
    return doc


def trash(gid):
    src = _dir(gid)
    if not os.path.isdir(src):
        return False
    os.makedirs(TRASH_DIR, exist_ok=True)
    dst = os.path.join(TRASH_DIR, gid)
    if os.path.exists(dst):
        shutil.rmtree(dst, ignore_errors=True)
    shutil.move(src, dst)
    try:
        with open(os.path.join(dst, "cestino.json"), "w") as f:
            json.dump({"at": time.time()}, f)
    except OSError:
        pass
    return True


def trashed():
    out = []
    if not os.path.isdir(TRASH_DIR):
        return out
    for gid in os.listdir(TRASH_DIR):
        if not ID_RE.match(gid):
            continue
        d = os.path.join(TRASH_DIR, gid)
        try:
            at = json.load(open(os.path.join(d, "cestino.json"))).get("at", 0)
        except Exception:
            at = os.path.getmtime(d)
        if time.time() - at > TRASH_DAYS * 86400:
            shutil.rmtree(d, ignore_errors=True)
            continue
        try:
            doc = json.load(open(os.path.join(d, "design.json"), encoding="utf-8"))
        except Exception:
            continue
        out.append({"id": gid, "name": doc.get("name"), "at": at, "w": doc.get("w"), "h": doc.get("h")})
    return sorted(out, key=lambda x: -x["at"])


def restore(gid):
    if not ID_RE.match(gid):
        raise FileNotFoundError(gid)
    src = os.path.join(TRASH_DIR, gid)
    if not os.path.isdir(src) or os.path.exists(_dir(gid)):
        return False
    shutil.move(src, _dir(gid))
    try:
        os.remove(os.path.join(_dir(gid), "cestino.json"))
    except OSError:
        pass
    return True


# ---------------------------------------------------------------- file della grafica (immagini, pittura, maschere)
def file_path(gid, name):
    if name == "cover.png":
        return os.path.join(_dir(gid), "cover.png")
    if not FILE_RE.match(str(name or "")):
        raise FileNotFoundError(name)
    return os.path.join(_dir(gid), "files", name)


def put_file(gid, data, kind="img"):
    """Un'immagine mandata dall'editor (pittura, maschera, immagine incollata). -> nome del file."""
    if len(data) > MAX_FILE:
        raise ValueError("Immagine troppo grande")
    ext = _sniff(data)
    if not ext:
        raise ValueError("Immagine non valida")
    kind = re.sub(r"[^a-z]", "", str(kind or "img"))[:8] or "img"
    name = f"{kind}_{secrets.token_hex(6)}.{ext}"
    d = os.path.join(_dir(gid), "files")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, name), "wb") as f:
        f.write(data)
    return name


def put_cover(gid, data):
    if _sniff(data) != "png" or len(data) > 8 * 1024 * 1024:
        raise ValueError("Anteprima non valida")
    with open(os.path.join(_dir(gid), "cover.png"), "wb") as f:
        f.write(data)
    return True


def import_path(gid, path):
    """Copia nella grafica un'immagine scelta dal computer (la grafica non dipende piu' dal file originale)."""
    if not os.path.isfile(path) or os.path.splitext(path)[1].lower() not in IMG_EXT:
        raise ValueError("Serve un'immagine (PNG, JPG, WebP, GIF, BMP)")
    if os.path.getsize(path) > MAX_FILE:
        raise ValueError("Immagine troppo grande")
    with open(path, "rb") as f:
        data = f.read()
    if not _sniff(data):
        # GIF / BMP / altri: si converte in PNG
        import cv2
        import numpy as np
        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_UNCHANGED)
        if img is None:
            raise ValueError("Immagine non leggibile")
        ok, buf = cv2.imencode(".png", img)
        if not ok:
            raise ValueError("Immagine non leggibile")
        data = buf.tobytes()
    name = put_file(gid, data, "img")
    w, h = image_size(file_path(gid, name))
    return {"file": name, "w": w, "h": h, "name": os.path.splitext(os.path.basename(path))[0][:80]}


def image_size(path):
    with open(path, "rb") as f:
        head = f.read(64 * 1024)
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return struct.unpack(">II", head[16:24])
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        c = head[12:16]
        if c == b"VP8X":
            return 1 + int.from_bytes(head[24:27], "little"), 1 + int.from_bytes(head[27:30], "little")
        if c == b"VP8L":
            b = head[21:25]
            return 1 + (((b[1] & 0x3F) << 8) | b[0]), 1 + (((b[3] & 0xF) << 10) | (b[2] << 2) | ((b[1] & 0xC0) >> 6))
        if c == b"VP8 ":
            return struct.unpack("<H", head[26:28])[0] & 0x3FFF, struct.unpack("<H", head[28:30])[0] & 0x3FFF
    import cv2
    import numpy as np
    img = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError("Immagine non leggibile")
    return img.shape[1], img.shape[0]


def gc_files(gid):
    """Toglie le immagini che il documento non usa piu' (pittura vecchia, immagini cancellate).
    Le tiene un giorno: servono ad Annulla anche dopo aver salvato."""
    d = os.path.join(_dir(gid), "files")
    if not os.path.isdir(d):
        return 0
    raw = json.dumps(load(gid))
    n = 0
    for fn in os.listdir(d):
        if FILE_RE.match(fn) and fn not in raw and time.time() - os.path.getmtime(os.path.join(d, fn)) > 86400:
            try:
                os.remove(os.path.join(d, fn))
                n += 1
            except OSError:
                pass
    return n


# ---------------------------------------------------------------- esportazione
def _safe_name(s):
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', " ", str(s or ""))
    s = re.sub(r"\.{2,}", ".", s).strip(" .")
    return (s or "Grafica")[:100]


def _unique(path):
    base, ext = os.path.splitext(path)
    i = 2
    while os.path.exists(path):
        path = f"{base} ({i}){ext}"
        i += 1
    return path


def jpeg_pdf(jpegs):
    """PDF minimo con una pagina per immagine JPEG (nessuna libreria esterna). jpegs = [(bytes, w, h)]"""
    objs = []
    kids = []
    out = [b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"]

    def add(body):
        objs.append(body)
        return len(objs) + 2   # 1 = catalogo, 2 = pagine
    for data, w, h in jpegs:
        img = add(b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length %d >>\nstream\n"
                  % (w, h, len(data)) + data + b"\nendstream")
        pw, ph = w * 72.0 / 150, h * 72.0 / 150       # 150 dpi
        cs = b"q %.2f 0 0 %.2f 0 0 cm /Im0 Do Q" % (pw, ph)
        cnt = add(b"<< /Length %d >>\nstream\n" % len(cs) + cs + b"\nendstream")
        pg = add(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Resources << /XObject << /Im0 %d 0 R >> >> /Contents %d 0 R >>" % (pw, ph, img, cnt))
        kids.append(pg)
    allobjs = [b"<< /Type /Catalog /Pages 2 0 R >>",
               b"<< /Type /Pages /Kids [" + b" ".join(b"%d 0 R" % k for k in kids) + b"] /Count %d >>" % len(kids)] + objs
    offs = []
    pos = len(out[0])
    for i, body in enumerate(allobjs):
        chunk = b"%d 0 obj\n" % (i + 1) + body + b"\nendobj\n"
        offs.append(pos)
        out.append(chunk)
        pos += len(chunk)
    xref = [b"xref\n0 %d\n0000000000 65535 f \n" % (len(allobjs) + 1)] + [b"%010d 00000 n \n" % o for o in offs]
    out += xref
    out.append(b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(allobjs) + 1, pos))
    return b"".join(out)


def export(gid, files, fmt, name, folder=None):
    """files = [bytes] (una per pagina, gia' disegnate dall'editor). -> percorsi salvati."""
    load(gid)   # la grafica esiste
    fmt = fmt if fmt in ("png", "jpg", "webp", "pdf") else "png"
    folder = folder or EXPORT_DIR
    os.makedirs(folder, exist_ok=True)
    base = _safe_name(name)
    if fmt == "pdf":
        pages = []
        for data in files:
            if _sniff(data) != "jpg":
                raise ValueError("Pagina non valida")
            w, h = _jpeg_size(data)
            pages.append((data, w, h))
        p = _unique(os.path.join(folder, base + ".pdf"))
        with open(p, "wb") as f:
            f.write(jpeg_pdf(pages))
        return [p]
    out = []
    for i, data in enumerate(files):
        if _sniff(data) != fmt:
            raise ValueError("Immagine non valida")
        p = _unique(os.path.join(folder, base + (f" - {i + 1}" if len(files) > 1 else "") + "." + fmt))
        with open(p, "wb") as f:
            f.write(data)
        out.append(p)
    return out


def _jpeg_size(data):
    i = 2
    while i < len(data) - 9:
        if data[i] != 0xFF:
            i += 1
            continue
        m = data[i + 1]
        if m in (0xC0, 0xC1, 0xC2):
            h, w = struct.unpack(">HH", data[i + 5:i + 9])
            return w, h
        ln = struct.unpack(">H", data[i + 2:i + 4])[0]
        i += 2 + ln
    raise ValueError("JPEG non valido")
