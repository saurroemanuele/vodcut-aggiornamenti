"""Trascrizione in locale con faster-whisper (gratis, niente cloud).

GPU NVIDIA se disponibile, altrimenti CPU. Il modello viene scaricato la prima volta
(circa 0,5-1,5 GB) e poi resta sul PC.
"""


def available():
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def _add_cuda_dlls():
    """Su Windows le DLL CUDA installate con pip (nvidia-cublas/cudnn) non sono nel PATH."""
    import os
    import sys
    if sys.platform != "win32":
        return
    import site
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        base = os.path.join(sp, "nvidia")
        if not os.path.isdir(base):
            continue
        for sub in os.listdir(base):
            b = os.path.join(base, sub, "bin")
            if os.path.isdir(b):
                try:
                    os.add_dll_directory(b)
                except Exception:
                    pass
                os.environ["PATH"] = b + os.pathsep + os.environ.get("PATH", "")


def has_cuda():
    """C'e' davvero una GPU NVIDIA utilizzabile? (su Mac e sui PC senza NVIDIA: no)"""
    import sys
    if sys.platform == "darwin":
        return False
    try:
        import ctranslate2
        return ctranslate2.get_cuda_device_count() > 0
    except Exception:
        return False


# grandezza indicativa dei modelli (per mostrare l'avanzamento del primo download)
_SIZES_MB = {"small": 484, "large-v3-turbo": 1620}


def _ensure_downloaded(name, log):
    """Il modello si scarica una volta sola: intanto si mostra quanto manca (prima sembrava bloccato)."""
    import os
    import threading
    try:
        from faster_whisper.utils import download_model
    except Exception:
        return
    try:
        download_model(name, local_files_only=True)
        return   # gia' sul PC
    except Exception:
        pass
    tot = _SIZES_MB.get(name, 500)
    hub = os.environ.get("HF_HUB_CACHE") or os.path.join(os.environ.get("HF_HOME") or os.path.join(os.path.expanduser("~"), ".cache", "huggingface"), "hub")
    done = {"v": False}

    def size_mb():
        n = 0
        for root, _, files in os.walk(hub):
            if "faster-whisper-" + name.split("/")[-1] not in root:
                continue
            for f in files:
                try:
                    n += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return n / 1e6

    def watch():
        import time
        while not done["v"]:
            mb = size_mb()
            log(f"Scarico il modello per la trascrizione (una volta sola): {min(99, int(mb / tot * 100))}% · {int(mb)} di ~{tot} MB")
            time.sleep(1)

    log(f"Scarico il modello per la trascrizione (una volta sola, circa {tot} MB)…")
    th = threading.Thread(target=watch, daemon=True)
    th.start()
    try:
        download_model(name)
    except Exception as e:
        raise RuntimeError("Non riesco a scaricare il modello per la trascrizione: controlla la connessione a internet e riprova "
                           f"({str(e)[:80]})") from e
    finally:
        done["v"] = True
    log("Modello scaricato")


def _load_model(log):
    _add_cuda_dlls()
    from faster_whisper import WhisperModel
    # senza GPU NVIDIA si va dritti sul modello leggero per CPU: niente download inutili da 1,6 GB
    tries = [("large-v3-turbo", "cuda", "float16"), ("small", "cuda", "float16"), ("small", "cpu", "int8")] if has_cuda() else [("small", "cpu", "int8")]
    last = None
    for name, device, ctype in tries:
        try:
            _ensure_downloaded(name, log)
            m = WhisperModel(name, device=device, compute_type=ctype)
            log(f"Modello {name} su {'GPU' if device == 'cuda' else 'CPU'}")
            return m, device
        except Exception as e:  # driver/cuDNN mancanti -> prova il successivo
            last = e
    if last and "Non riesco a scaricare" in str(last):
        raise last
    raise RuntimeError(f"Impossibile caricare il modello di trascrizione: {last}")


def _collect(model, path, duration, language, beam, progress, cancel, prompt=None):
    # prompt: il testo che ci si aspetta (lo script di una storia) -> il modello sbaglia molto meno le parole
    segments, info = model.transcribe(path, language=language, word_timestamps=True, vad_filter=True, beam_size=beam,
                                      initial_prompt=prompt or None)
    out = []
    for seg in segments:  # la trascrizione vera avviene qui (generatore)
        if cancel and cancel():
            raise RuntimeError("annullato")
        words = []
        for w in (seg.words or []):
            txt = w.word.strip()
            if txt:
                words.append({"w": txt, "a": round(float(w.start), 2), "b": round(float(w.end), 2), "del": False})
        if words:
            out.append({"a": words[0]["a"], "b": words[-1]["b"], "words": words})
        if progress and duration:
            progress(min(0.99, float(seg.end) / duration))
    return out, getattr(info, "language", None)


def transcribe(path, duration, progress=None, cancel=None, language=None, log=print, prompt=None):
    model, device = _load_model(log)
    # voci brevi (storie): ricerca piu' accurata anche su CPU, costa pochi secondi
    beam = 5 if device == "cuda" or (duration and duration < 240) else 1
    if prompt:
        prompt = " ".join(prompt.split()[:120])
    try:
        out, lang = _collect(model, path, duration, language, beam, progress, cancel, prompt)
    except Exception as e:
        if device != "cuda" or "annullato" in str(e):
            raise
        # errore CUDA durante la trascrizione (memoria, DLL): riprova su CPU
        log("GPU non disponibile per la trascrizione, uso la CPU")
        del model
        from faster_whisper import WhisperModel
        model = WhisperModel("small", device="cpu", compute_type="int8")
        out, lang = _collect(model, path, duration, language, 1, progress, cancel, prompt)
    return {"status": "done", "language": lang, "segments": out}


# ---------------------------------------------------------------- lo script incollato corregge le parole
def _nw(w):
    import re
    import unicodedata
    w = unicodedata.normalize("NFKD", str(w).lower())
    return re.sub(r"[^\w]", "", "".join(c for c in w if not unicodedata.combining(c)))


def fix_with_script(tr, script):
    """Le parole sentite scritte come nello script (nomi, marchi, termini: "Claude" e non "Cloud"),
    ai tempi della voce. Solo dove la voce dice (piu' o meno) lo script: quello che hai detto in piu' o in meno resta.
    -> quante parole sono cambiate"""
    import difflib
    sw = [w for w in str(script or "").split() if _nw(w)]
    if not sw:
        return 0
    flat = [w for sg in tr.get("segments") or [] for w in sg.get("words") or [] if not w.get("gap")]
    if not flat:
        return 0
    a = [_nw(x) for x in sw]
    b = [_nw(w["w"]) for w in flat]
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    n = 0

    def put(w, txt):
        nonlocal n
        # la punteggiatura della voce resta se lo script non ne ha (i sottotitoli la usano per andare a capo)
        tail = "" if txt[-1:] in ".,!?;:…" else "".join(ch for ch in str(w["w"])[-1:] if ch in ".,!?;:…")
        new = txt + tail
        if new != w["w"]:
            w["w"] = new
            n += 1
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            for k in range(i2 - i1):   # stessa parola: si prende la grafia dello script (maiuscole, accenti)
                put(flat[j1 + k], sw[i1 + k])
        elif op == "replace":
            sa, sb = " ".join(a[i1:i2]), " ".join(b[j1:j2])
            if difflib.SequenceMatcher(None, sa, sb).ratio() < 0.55 or i2 - i1 > 6 or j2 - j1 > 6:
                continue   # qui la voce dice davvero un'altra cosa
            if i2 - i1 == j2 - j1:
                for k in range(i2 - i1):
                    put(flat[j1 + k], sw[i1 + k])
            else:
                # parole unite o divise ("Claude Code" sentito "Cloudcode"): stesso tratto di tempo, parole dello script
                ws = flat[j1:j2]
                m = i2 - i1
                if m < len(ws):
                    # quante parole sentite formano davvero quelle dello script (le altre restano come sono)
                    tgt = "".join(a[i1:i2])
                    best, bk = -1.0, m
                    for kk in range(m, len(ws) + 1):
                        r = difflib.SequenceMatcher(None, tgt, "".join(b[j1:j1 + kk])).ratio()
                        if r > best + 1e-9:
                            best, bk = r, kk
                    if best < 0.75:
                        continue
                    ws = ws[:bk]
                t1 = float(ws[-1]["b"])
                if m < len(ws):
                    for k in range(m):
                        put(ws[k], sw[i1 + k])
                    ws[m - 1]["b"] = round(t1, 3)
                    for w in ws[m:]:
                        w["del"] = True
                        w["gone"] = True
                else:
                    # meno parole sentite: la prima prende il testo in piu'
                    for k, w in enumerate(ws):
                        txt = sw[i1 + k] if k < len(ws) - 1 else " ".join(sw[i1 + k:i2])
                        put(w, txt)
    # parole assorbite da quelle dello script: tolte dai sottotitoli
    for sg in tr.get("segments") or []:
        sg["words"] = [w for w in sg.get("words") or [] if not w.get("gone")]
    return n
