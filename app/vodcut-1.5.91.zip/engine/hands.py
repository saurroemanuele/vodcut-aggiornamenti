"""Mani: dove sono e cosa fanno (palmo aperto, pugno, indice...) fotogramma per fotogramma, tutto sul computer.

Due modelli piccoli (MediaPipe Hands convertiti in ONNX da PINTO0309, licenza Apache 2.0): uno trova il palmo,
l'altro i 21 punti della mano. Servono agli effetti su misura che seguono la mano (p.hand nell'effetto)."""
import math
import os

import numpy as np

from . import behind as BH

BASE = "https://raw.githubusercontent.com/saurroemanuele/vodcut-aggiornamenti/main/modelli/"
PINTO = "https://raw.githubusercontent.com/PINTO0309/hand-gesture-recognition-using-onnx/main/model/"
MODELS = {
    "palm": ("mano_palmo.onnx", [BASE + "mano_palmo.onnx", PINTO + "palm_detection/palm_detection_full_inf_post_192x192.onnx"], 4_500_000),
    "land": ("mano_punti.onnx", [BASE + "mano_punti.onnx", PINTO + "hand_landmark/hand_landmark_sparse_Nx3x224x224.onnx"], 10_000_000),
}
SHA = {"palm": "3530b2b4a50d80173b573cd478b13436a015d3058bcff68e74435c6414ed7de3",
       "land": "9fcea307b52350eec3366cd6ad4eb11f89cff58f2a482a60ec8704d0e012e63a"}
_S = {}
FINGERS = ((5, 6, 8), (9, 10, 12), (13, 14, 16), (17, 18, 20))   # base, nocca di mezzo, punta


def _path(name):
    from .util import APP_DIR
    return os.path.join(APP_DIR, "modelli", name)


def ensure_models(log=None, cancel=None):
    out = {}
    for k, (name, urls, min_size) in MODELS.items():
        p = _path(name)
        if not (os.path.exists(p) and os.path.getsize(p) >= min_size):
            BH._download(urls, p, round(min_size / 1e6) + 1, min_size,
                         (lambda m: log("Scarico il modello delle mani (solo la prima volta)")) if log else None, cancel)
            # file controllato: se non e' esattamente quello atteso non si usa
            import hashlib
            h = hashlib.sha256()
            with open(p, "rb") as f:
                for b in iter(lambda: f.read(1 << 20), b""):
                    h.update(b)
            if h.hexdigest() != SHA[k]:
                os.remove(p)
                raise RuntimeError("Il modello delle mani scaricato non è valido: riprova più tardi")
        out[k] = p
    return out


def _sessions():
    if "palm" not in _S:
        import onnxruntime as ort
        ps = ensure_models()
        so = ort.SessionOptions()
        so.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 4) - 1))
        for k in ("palm", "land"):
            s = ort.InferenceSession(ps[k], so, providers=["CPUExecutionProvider"])
            _S[k] = (s, s.get_inputs()[0].name)
    return _S


def _palms(img):
    """Palmi nel fotogramma BGR -> [(score, cx, cy, size, rot)] in pixel."""
    import cv2
    h, w = img.shape[:2]
    S = max(w, h)
    px, py = (S - w) // 2, (S - h) // 2
    sq = np.zeros((S, S, 3), np.uint8)
    sq[py:py + h, px:px + w] = img
    x = cv2.resize(sq, (192, 192), interpolation=cv2.INTER_AREA)[..., ::-1].astype(np.float32) / 255.0
    s, nm = _sessions()["palm"]
    boxes = s.run(None, {nm: x.transpose(2, 0, 1)[None]})[0]
    out = []
    for sc, bx, by, bs, k0x, k0y, k2x, k2y in boxes:
        if bs <= 0 or sc < 0.5:
            continue
        rot = 0.5 * math.pi - math.atan2(-(k2y - k0y), k2x - k0x)
        size = 2.9 * bs
        cx = bx + 0.5 * bs * math.sin(rot)
        cy = by - 0.5 * bs * math.cos(rot)
        out.append((float(sc), cx * S - px, cy * S - py, size * S, rot))
    return out


def _affine(cx, cy, size, rot):
    """Matrice ritaglio 224x224 -> fotogramma (la mano dritta, dita in su)."""
    k = size / 224.0
    c, s = math.cos(rot), math.sin(rot)
    # colonne: asse x del ritaglio, asse y del ritaglio, origine
    return np.array([[c * k, -s * k, cx - (c * 112 - s * 112) * k],
                     [s * k, c * k, cy - (s * 112 + c * 112) * k]], np.float32)


def _landmarks(img, roi):
    import cv2
    M = _affine(*roi)
    crop = cv2.warpAffine(img, M, (224, 224), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_CONSTANT)
    x = crop[..., ::-1].astype(np.float32) / 255.0
    s, nm = _sessions()["land"]
    xyz, score, lr = s.run(None, {nm: x.transpose(2, 0, 1)[None]})
    p = xyz[0].reshape(21, 3)[:, :2]
    pts = p @ M[:, :2].T + M[:, 2]
    return pts, float(np.ravel(score)[0]), float(np.ravel(lr)[0])


def _roi_from(pts):
    """Il riquadro della mano per il fotogramma dopo, dai punti di questo (come fa MediaPipe)."""
    w, m = pts[0], pts[9]
    rot = 0.5 * math.pi - math.atan2(-(m[1] - w[1]), m[0] - w[0])
    c, s = math.cos(rot), math.sin(rot)
    ax, ay = np.array([c, s]), np.array([-s, c])
    ctr = pts.mean(0)
    u, v = (pts - ctr) @ ax, (pts - ctr) @ ay
    size = max(u.max() - u.min(), v.max() - v.min()) * 2.0
    mid = ctr + ax * (u.max() + u.min()) / 2 + ay * (v.max() + v.min()) / 2
    mid = mid - ay * 0.1 * size            # un po' verso le dita
    return (float(mid[0]), float(mid[1]), float(size), rot)


def describe(pts, W, H):
    """Punti della mano -> palmo, apertura 0..1, punta dell'indice, grandezza e gesto."""
    d = lambda i, j: float(np.hypot(*(pts[i] - pts[j])))
    palm = d(0, 9) or 1.0
    ext, opn = [], []
    for b, m, t in FINGERS:
        r = d(0, t) / max(1e-6, d(0, b))       # dito dritto ~1,9 volte la distanza polso-base, chiuso ~1
        opn.append(min(1.0, max(0.0, (r - 1.15) / 0.65)))
        ext.append(r > 1.5 and d(0, t) > d(0, m))
    thumb = d(4, 5) > palm * 0.95            # punta del pollice lontana dalla base dell'indice
    n = sum(ext)
    if n >= 4:
        g = "aperta"
    elif thumb and not ext[0] and not ext[1]:
        g = "pollice"                          # (anulare e mignolo di lato sembrano lunghi: non contano)
    elif n == 0:
        g = "pugno"
    elif ext[0] and not ext[1]:
        g = "indice"
    elif ext[0] and ext[1] and not ext[2]:
        g = "vittoria"
    else:
        g = ""
    c = pts[[0, 5, 9, 13, 17]].mean(0)
    return {"x": c[0] / W, "y": c[1] / H, "open": sum(opn) / 4, "tx": pts[8][0] / W, "ty": pts[8][1] / H,
            "size": palm / H, "g": g}


class Tracker:
    """Una mano seguita nel tempo: cerca il palmo solo quando la perde (piu' veloce e piu' stabile)."""

    def __init__(self):
        self.roi = None
        self.last = None

    def step(self, img):
        h, w = img.shape[:2]
        cands = [self.roi] if self.roi else []
        got = None
        for roi in cands:
            pts, sc, lr = _landmarks(img, roi)
            if sc >= 0.5:
                got = (pts, sc, lr)
        if got is None:
            best = None
            for sc, cx, cy, size, rot in _palms(img):
                # la stessa mano di prima se c'era, altrimenti la piu' grande
                val = size / h - (math.hypot(cx - self.last[0], cy - self.last[1]) / h if self.last else 0)
                if best is None or val > best[0]:
                    best = (val, (cx, cy, size, rot))
            if best:
                pts, sc, lr = _landmarks(img, best[1])
                if sc >= 0.5:
                    got = (pts, sc, lr)
        if got is None:
            self.roi = None
            return None
        pts = got[0]
        self.roi = _roi_from(pts)
        out = describe(pts, w, h)
        self.last = (out["x"] * w, out["y"] * h)
        out["right"] = got[2] > 0.5
        out["pts"] = pts
        return out


def detect(img):
    """Una sola immagine: tutte le mani che trova."""
    h, w = img.shape[:2]
    res = []
    for sc, cx, cy, size, rot in _palms(img):
        pts, s2, lr = _landmarks(img, (cx, cy, size, rot))
        if s2 >= 0.5:
            o = describe(pts, w, h)
            o["pts"] = pts
            res.append(o)
    return res


def _smooth(pts, fps):
    """Riempie i buchi brevi (la mano persa per un attimo) e toglie il tremolio."""
    n = len(pts)
    vis = [p[4] for p in pts]
    gap = int(round(0.4 * fps))
    i = 0
    while i < n:
        if vis[i]:
            i += 1
            continue
        j = i
        while j < n and not vis[j]:
            j += 1
        if 0 < i and j < n and j - i <= gap:
            a, b = pts[i - 1], pts[j]
            for k in range(i, j):
                f = (k - i + 1) / (j - i + 1)
                pts[k] = [pts[k][0]] + [a[q] + (b[q] - a[q]) * f for q in (1, 2, 3)] + [1] + \
                         [a[q] + (b[q] - a[q]) * f for q in (5, 6, 7)] + [a[8]]
        i = j
    out = [list(p) for p in pts]
    for k in range(n):
        if not pts[k][4]:
            continue
        win = [pts[m] for m in range(max(0, k - 1), min(n, k + 2)) if pts[m][4]]
        for q in (1, 2, 5, 6, 7):
            out[k][q] = sum(p[q] for p in win) / len(win)
        out[k][3] = sum(p[3] for p in win) / len(win)
    # gesto: si cambia solo se dura almeno 3 campioni (niente sfarfallio)
    g = ""
    for k in range(n):
        cur = out[k][8]
        if cur != g and all(k + m < n and out[k + m][8] == cur for m in range(3)):
            g = cur
        out[k][8] = g if out[k][4] else ""
    return out


def track(source, a, b, fps=10.0, W=None, H=None, progress=None, cancel=None, t0=0.0):
    """Mano del pezzo [a, b] del video -> righe [t, x, y, open, vis, tipx, tipy, size, gesto] (t da t0, coordinate 0..1)."""
    if W is None or H is None:
        from .util import probe
        info = probe(source)
        w0, h0 = int(info.get("width") or 1280), int(info.get("height") or 720)
        k = min(1.0, 960 / max(w0, h0))
        W, H = max(64, int(w0 * k) // 2 * 2), max(64, int(h0 * k) // 2 * 2)
    _sessions()
    dur = max(0.0, b - a)
    n = max(1, int(dur * fps))
    tr = Tracker()
    pts = []
    for i, img in enumerate(BH._frames(source, a, dur, fps, W, H)):
        if cancel and cancel():
            raise RuntimeError("annullato")
        o = tr.step(img)
        t = round(t0 + i / fps, 3)
        if o:
            pts.append([t, o["x"], o["y"], o["open"], 1, o["tx"], o["ty"], o["size"], o["g"]])
        else:
            pts.append([t, 0, 0, 0, 0, 0, 0, 0, ""])
        if progress:
            progress(min(1.0, (i + 1) / n))
    pts = _smooth(pts, fps)
    return [[p[0]] + [round(float(v), 4) for v in p[1:4]] + [int(p[4])] + [round(float(v), 4) for v in p[5:8]] + [p[8]] for p in pts]
