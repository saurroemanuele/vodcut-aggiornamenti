// Effetti su misura scritti dall'AI: il codice gira nella sandbox (web/fxbox.html, niente rete, niente accesso all'app).
// Qui: la coda delle richieste, l'ultimo fotogramma di ogni effetto (per l'anteprima, che e' sincrona) e i fotogrammi
// per l'esportazione.
let frame = null, ready = null, rid = 0;
const wait = new Map();
const last = new Map();      // id effetto -> { t, bm, w, h }
const busy = new Set();      // id effetto con una richiesta in corso (anteprima)
const errors = new Map();    // id effetto -> errore
const loaded = new Set();    // chiave codice gia' compilata nella sandbox
let onFrame = null;          // chi ridisegna l'anteprima quando arriva un fotogramma

function box() {
  if (ready) return ready;
  ready = new Promise((res) => {
    frame = document.createElement('iframe');
    frame.src = '/web/fxbox.html';
    frame.setAttribute('sandbox', 'allow-scripts');
    frame.setAttribute('aria-hidden', 'true');
    frame.tabIndex = -1;
    Object.assign(frame.style, { position: 'fixed', width: '1px', height: '1px', left: '-10px', top: '-10px', opacity: '0', pointerEvents: 'none', border: '0' });
    window.addEventListener('message', (ev) => {
      if (!frame || ev.source !== frame.contentWindow) return;
      const m = ev.data || {};
      if (m.ready) { res(); return; }
      const w = wait.get(m.rid); if (!w) return;
      wait.delete(m.rid);
      if (m.ok) w.ok(m.bitmap); else w.no(new Error(m.error || 'errore'));
    });
    document.body.append(frame);
  });
  return ready;
}

const hashCode = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
export const fxKey = (spec) => spec.id + ':' + hashCode(spec.code || '');

export function fxParams(spec, t, dur, extra) {
  return { dur, k: dur ? Math.max(0, Math.min(1, t / dur)) : 0, fps: 30, accent: spec.accent || '#4F8CFF', accent2: spec.accent2 || '#A78BFA',
    text: spec.text || '', seed: spec.seed || 7, anchor: spec.anchor || { x: 0.5, y: 0.5 }, size: spec.size || 0.5,
    hand: extra && extra.hand ? extra.hand : null };
}

// un fotogramma dell'effetto -> ImageBitmap (w x h)
export async function renderFx(spec, t, dur, w, h, extra) {
  await box();
  const key = fxKey(spec);
  const first = !loaded.has(key);
  const id = ++rid;
  const p = new Promise((ok, no) => wait.set(id, { ok, no }));
  frame.contentWindow.postMessage({ type: 'render', rid: id, key, code: spec.code, w: Math.round(w), h: Math.round(h), t, p: fxParams(spec, t, dur, extra), first }, '*');
  const bm = await p;
  loaded.add(key);
  return bm;
}

export function setFxRedraw(fn) { onFrame = fn; }
export function fxError(spec) { return errors.get(fxKey(spec)) || null; }

// anteprima: disegna subito l'ultimo fotogramma pronto e chiede quello giusto (arriva al giro dopo)
export function drawCodeFx(spec, H, t, dur, canvas, extra) {
  const ar = spec.ar || 16 / 9;
  const hh = Math.max(64, Math.round(H)), ww = Math.max(64, Math.round(hh * ar));
  const c = canvas || document.createElement('canvas');
  if (c.width !== ww || c.height !== hh) { c.width = ww; c.height = hh; }
  const g = c.getContext('2d');
  const key = fxKey(spec), L = last.get(key);
  g.clearRect(0, 0, ww, hh);
  if (L && L.bm) g.drawImage(L.bm, 0, 0, ww, hh);
  const want = Math.round(t * 30) / 30;
  // con la mano: si ridisegna anche se la mano si e' spostata (clip spostata, mano appena tracciata)
  const hk = extra && extra.hand ? [extra.hand.visible ? 1 : 0, extra.hand.x, extra.hand.y, extra.hand.open].map((v) => Math.round(v * 500)).join() : '';
  if ((!L || Math.abs(L.t - want) > 1e-3 || L.w !== ww || L.hk !== hk) && !busy.has(key) && !errors.has(key)) {
    busy.add(key);
    // anteprima leggera: al massimo 720 righe
    const k = Math.min(1, 720 / hh);
    renderFx(spec, want, dur, ww * k, hh * k, extra).then((bm) => {
      const old = last.get(key); if (old && old.bm && old.bm.close) old.bm.close();
      last.set(key, { t: want, bm, w: ww, hk });
      errors.delete(key);
    }).catch((e) => { errors.set(key, e.message); }).finally(() => { busy.delete(key); if (onFrame) onFrame(); });
  }
  return c;
}

// prova il codice: qualche fotogramma, errori compresi (prima di aggiungerlo al video)
export async function testFx(spec, dur) {
  for (const t of [0.05, dur * 0.5, Math.max(0.05, dur - 0.05)]) {
    const bm = await renderFx(spec, t, dur, 320, Math.round(320 / (spec.ar || 16 / 9)));
    if (bm && bm.close) bm.close();
  }
  errors.delete(fxKey(spec));
  return true;
}
