// Grafica: apre i file di Photoshop (.psd) con i livelli (libreria ag-psd, MIT, caricata solo quando serve).
import { uid } from './doc.js';

let lib = null;
function loadLib() {
  if (lib) return lib;
  lib = new Promise((res, rej) => {
    if (window.agPsd) { res(window.agPsd); return; }
    const s = document.createElement('script');
    s.src = '/web/vendor/ag-psd.js';
    s.onload = () => (window.agPsd ? res(window.agPsd) : rej(new Error('Lettore PSD non disponibile')));
    s.onerror = () => { lib = null; rej(new Error('Lettore PSD non disponibile')); };
    document.head.append(s);
  });
  return lib;
}

const BLEND = { normal: 'normal', multiply: 'multiply', screen: 'screen', overlay: 'overlay', darken: 'darken', lighten: 'lighten',
  'color dodge': 'color-dodge', 'color burn': 'color-burn', 'hard light': 'hard-light', 'soft light': 'soft-light',
  difference: 'difference', exclusion: 'exclusion', hue: 'hue', saturation: 'saturation', color: 'color', luminosity: 'luminosity' };

// buf = ArrayBuffer del .psd; upload(canvas) -> nome del file nella grafica
export async function readPsd(buf, upload, onStep) {
  const ag = await loadLib();
  const psd = ag.readPsd(buf, { skipThumbnail: true, skipLinkedFilesData: true });
  let n = 0;
  const count = (list) => (list || []).reduce((a, l) => a + (l.children ? count(l.children) : 1), 0);
  const total = Math.max(1, count(psd.children));
  async function conv(list) {
    const out = [];
    for (const L of list || []) {
      const base = { id: uid(), name: (L.name || '').slice(0, 80), visible: !L.hidden, locked: false, opacity: L.opacity == null ? 1 : L.opacity,
        blend: BLEND[L.blendMode] || 'normal', rot: 0, flipX: false, flipY: false };
      if (L.children) {
        const kids = await conv(L.children);
        if (kids.length) out.push({ ...base, type: 'group', name: base.name || 'Gruppo', children: kids, open: false, x: 0, y: 0, w: 1, h: 1 });
        continue;
      }
      n++; onStep && onStep(n / total);
      const cv = L.canvas;
      if (!cv || !cv.width || !cv.height) continue;   // livello vuoto (o di sola regolazione)
      const file = await upload(cv);
      out.push({ ...base, type: 'image', name: base.name || 'Livello', src: file, iw: cv.width, ih: cv.height,
        x: L.left || 0, y: L.top || 0, w: cv.width, h: cv.height });
    }
    return out;
  }
  const layers = await conv(psd.children);
  // PSD senza livelli: solo l'immagine finale
  if (!layers.length && psd.canvas) {
    const file = await upload(psd.canvas);
    layers.push({ id: uid(), type: 'image', name: 'Immagine', visible: true, locked: false, opacity: 1, blend: 'normal', rot: 0, flipX: false, flipY: false,
      src: file, iw: psd.width, ih: psd.height, x: 0, y: 0, w: psd.width, h: psd.height });
  }
  return { w: psd.width, h: psd.height, layers };
}
