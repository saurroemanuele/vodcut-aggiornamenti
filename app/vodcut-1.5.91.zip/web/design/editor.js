// Grafica: l'editor (tela, strumenti, livelli, proprieta'). Il disegno e' in render.js, il documento in doc.js.
import { h, icon, toast, get, post, TOKEN, confirmBox, promptBox, pollJob, IS_MAC } from '../lib.js';
import { fontPicker, ensureFont } from '../fonts.js';
import { uid, clone, BLENDS, FX_DEFAULT, FILTER_DEFAULT, ADJUST_KINDS, textLayer, shapeLayer, imageLayer, paintLayer, adjustLayer,
  groupLayer, walk, findLayer, corners, bounds, toLocal, moveBy, scaleAround, flatVisible } from './doc.js';
import { Assets, renderPage, layerBitmap, pageCanvas, hitLayer, textHeight, textNaturalWidth, fontOf, dropCache, fillColor } from './render.js';
import { colorButton } from './color.js';
import { readPsd } from './psd.js';
import { mediaUrl } from '../lib.js';
import { LANG, t as tr } from '../i18n.js';

// replaceChildren senza i null (altrimenti diventano il testo "null")
const rc = (el, ...kids) => el.replaceChildren(...kids.flat().filter((x) => x != null && x !== false));

const MOD = IS_MAC ? '⌘' : 'Ctrl+';
const TOOLS = [
  ['move', 'cursor', 'Sposta e trasforma', 'V'], ['text', 'type', 'Testo', 'T'], ['shape', 'square', 'Forme', 'U'],
  ['brush', 'brush', 'Pennello', 'B'], ['eraser', 'eraser', 'Gomma', 'E'], ['eyedrop', 'pipette', 'Contagocce', 'I'],
  ['crop', 'crop', 'Ritaglia la tela', 'C'], ['hand', 'hand', 'Mano (sposta la vista)', 'H'],
];
const SHAPES = [['rect', 'square', 'Rettangolo'], ['ellipse', 'circle', 'Ellisse'], ['triangle', 'triangle', 'Triangolo'], ['poly', 'hexagon', 'Poligono'], ['star', 'star', 'Stella'], ['line', 'line', 'Linea']];
const HANDLE = 9;

export async function mountDesign(root, gid, { onTitle, topRight, autoCut }) {
  let doc = await get('/api/d/' + gid);
  let alive = true;
  const S = {
    page: 0, sel: [], tool: 'move', zoom: 1, panX: 0, panY: 0, hover: null,
    color: '#111111', brush: { size: 40, hard: 0.8, opacity: 1 }, shape: 'rect', maskEdit: false, snap: true,
    editing: null, crop: null, guides: [], busy: null,
  };
  const assets = new Assets((n) => `/api/d/${gid}/file/${n}?token=${TOKEN}`, () => { dropAllForSrc(); draw(); paintLayersSoon(); });
  const page = () => doc.pages[Math.min(S.page, doc.pages.length - 1)];
  const layers = () => page().layers;
  const selLayers = () => S.sel.map((id) => findLayer(layers(), id)).filter(Boolean).map((r) => r.layer);
  const one = () => (S.sel.length === 1 ? selLayers()[0] || null : null);
  function dropAllForSrc() { /* la chiave della cache contiene la versione dell'immagine: niente da fare */ }

  // ------------------------------------------------------------ cronologia (Annulla / Ripeti)
  const hist = { stack: [], idx: -1, key: '', t: 0 };
  const snap = () => JSON.stringify({ w: doc.w, h: doc.h, pages: doc.pages, page: S.page });
  function commit(key) {
    const s = snap(), now = Date.now();
    if (hist.stack[hist.idx] === s) return;
    if (key && hist.key === key && now - hist.t < 900 && hist.idx === hist.stack.length - 1 && hist.idx > 0) hist.stack[hist.idx] = s;
    else { hist.stack.splice(hist.idx + 1); hist.stack.push(s); if (hist.stack.length > 150) hist.stack.shift(); hist.idx = hist.stack.length - 1; }
    hist.key = key || ''; hist.t = now;
    scheduleSave(); draw();
    // modifiche continue (cursori, colori, testo): il pannello resta com'e', si aggiornano solo lista e pagine
    if (key && key !== 'nudge') { paintLayersSoon(); pagesSoon(); } else refresh();
  }
  function restore(i) {
    if (i < 0 || i >= hist.stack.length) return;
    hist.idx = i; hist.key = '';
    const o = JSON.parse(hist.stack[i]);
    doc.w = o.w; doc.h = o.h; doc.pages = o.pages; S.page = Math.min(o.page || 0, doc.pages.length - 1);
    S.sel = S.sel.filter((id) => findLayer(layers(), id));
    stopEdit(false);
    scheduleSave(); draw(); refresh(true);
  }
  const undo = () => restore(hist.idx - 1), redo = () => restore(hist.idx + 1);

  // ------------------------------------------------------------ salvataggio (da solo, dopo ogni modifica)
  const memMap = new Map(), pending = new Map();   // nome in memoria -> nome sul disco
  let saveT = 0, saving = null, coverT = 0;
  const saveDot = h('span', { class: 'dz-save' });
  let firstDirty = 0;
  function scheduleSave() {
    // dopo l'ultima modifica, ma mai piu' di 2 secondi dalla prima non salvata (anche se si continua a lavorare)
    const now = Date.now(); if (!firstDirty) firstDirty = now;
    clearTimeout(saveT); saveDot.className = 'dz-save on'; saveDot.dataset.tip = 'Salvataggio…';
    saveT = setTimeout(save, Math.max(0, Math.min(450, 2000 - (now - firstDirty))));
    clearTimeout(coverT); coverT = setTimeout(saveCover, 2500);
  }
  async function save() {
    if (saving) { await saving; }
    saveT = 0; firstDirty = 0;
    saving = (async () => {
      await Promise.all([...pending.values()]);
      let raw = JSON.stringify(doc);
      for (const [m, f] of memMap) raw = raw.split(m).join(f);
      const r = await fetch(`/api/d/${gid}?token=${TOKEN}`, { method: 'PUT', body: raw });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'Salvataggio non riuscito');
      saveDot.className = 'dz-save'; saveDot.dataset.tip = 'Salvato';
    })().catch((e) => { saveDot.className = 'dz-save err'; saveDot.dataset.tip = e.message; }).finally(() => { saving = null; });
    return saving;
  }
  async function saveCover() {
    try {
      const k = Math.min(1, 480 / Math.max(doc.w, doc.h));
      const c = await pageCanvas(doc, doc.pages[0], k, assets);
      const b = await new Promise((r) => c.toBlob(r, 'image/png'));
      await fetch(`/api/d/${gid}/cover?token=${TOKEN}`, { method: 'PUT', body: b });
    } catch (e) { /* anteprima: non importa */ }
  }
  // una tela (pittura, maschera) diventa un file della grafica: subito in memoria, il file arriva dopo
  function storeCanvas(cv, kind) {
    const mem = 'mem' + uid('_') + '.png';
    assets.put(mem, cv);
    const p = new Promise((res) => cv.toBlob(res, 'image/png'))
      .then((b) => fetch(`/api/d/${gid}/file?kind=${kind}&token=${TOKEN}`, { method: 'PUT', body: b }))
      .then((r) => r.json()).then((j) => { if (j.file) { memMap.set(mem, j.file); assets.alias(mem, j.file); } })
      .catch(() => toast('Non riesco a salvare la pittura', true)).finally(() => pending.delete(mem));
    pending.set(mem, p);
    return mem;
  }
  async function uploadBlob(blob, kind = 'img') {
    const r = await fetch(`/api/d/${gid}/file?kind=${kind}&token=${TOKEN}`, { method: 'PUT', body: blob });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Immagine non valida');
    return j.file;
  }

  // ------------------------------------------------------------ interfaccia
  const cv = h('canvas', { class: 'dz-cv' }), ov = h('canvas', { class: 'dz-ov' });
  const stage = h('div', { class: 'dz-stage', tabindex: '0' }, cv, ov);
  const opts = h('div', { class: 'dz-opts' });
  const toolsBar = h('div', { class: 'dz-tools' });
  const props = h('div', { class: 'dz-props' });
  const layerList = h('div', { class: 'dz-llist' });
  const pagesBar = h('div', { class: 'dz-pages' });
  const zoomLbl = h('button', { class: 'dz-zoom', 'data-tip': 'Adatta alla finestra (' + MOD + '0)', onclick: () => fit() });
  const busyEl = h('div', { class: 'dz-busy', style: { display: 'none' } });
  const side = h('aside', { class: 'dz-side' },
    h('div', { class: 'dz-ptitle' }, 'Proprietà'), props,
    h('div', { class: 'dz-lhead' }, h('span', { class: 'dz-ptitle' }, 'Livelli'), h('div', { class: 'grow' }),
      ib('plus', 'Nuovo livello di pittura', () => addLayer(paintLayer(doc))),
      ib('adjust', 'Livello di regolazione', (e) => adjustMenu(e.currentTarget)),
      ib('group', 'Raggruppa (' + MOD + 'G)', () => groupSel()),
      ib('mask', 'Maschera di livello', () => toggleMask()),
      ib('duplicate', 'Duplica (' + MOD + 'J)', () => duplicateSel()),
      ib('trash', 'Elimina (Canc)', () => deleteSel())),
    layerList);
  const root2 = h('div', { class: 'dz' },
    opts,
    h('div', { class: 'dz-main' }, toolsBar, h('div', { class: 'dz-center' }, h('div', { class: 'dz-stagewrap' }, stage, busyEl), pagesBar), side));
  root.append(root2);
  const undoB = ib('undo', 'Annulla (' + MOD + 'Z)', () => undo()), redoB = ib('redo', 'Ripeti (' + MOD + 'Shift+Z)', () => redo());
  if (topRight) topRight.append(saveDot, undoB, redoB, zoomLbl,
    h('button', { class: 'btn primary sm dz-expbtn', onclick: () => exportDialog() }, icon('download', 14, '#fff', 2), 'Esporta'));
  function ib(name, tip, fn, cls) { return h('button', { class: 'dz-ib' + (cls ? ' ' + cls : ''), 'aria-label': tip, 'data-tip': tip, onclick: fn }, icon(name, 16, 'currentColor', 1.9)); }

  // ------------------------------------------------------------ vista
  const dpr = () => window.devicePixelRatio || 1;
  const toDoc = (sx, sy) => [(sx - S.panX) / S.zoom, (sy - S.panY) / S.zoom];
  const toScr = (x, y) => [S.panX + x * S.zoom, S.panY + y * S.zoom];
  function fit() {
    const r = stage.getBoundingClientRect();
    const z = Math.min((r.width - 80) / doc.w, (r.height - 80) / doc.h);
    S.zoom = Math.max(0.02, Math.min(8, z || 1));
    S.panX = (r.width - doc.w * S.zoom) / 2; S.panY = (r.height - doc.h * S.zoom) / 2;
    draw();
  }
  function zoomAt(z, sx, sy) {
    const r = stage.getBoundingClientRect();
    if (sx == null) { sx = r.width / 2; sy = r.height / 2; }
    const [dx, dy] = toDoc(sx, sy);
    S.zoom = Math.max(0.02, Math.min(32, z));
    S.panX = sx - dx * S.zoom; S.panY = sy - dy * S.zoom;
    draw();
  }

  // ------------------------------------------------------------ disegno
  let raf = 0, checker = null;
  function draw() { if (!raf && alive) raf = requestAnimationFrame(render); }
  function render() {
    raf = 0;
    const r = stage.getBoundingClientRect(), d = dpr();
    const W = Math.max(1, Math.round(r.width * d)), H = Math.max(1, Math.round(r.height * d));
    for (const c of [cv, ov]) if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
    const g = cv.getContext('2d');
    g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H);
    const k = S.zoom * d, ox = S.panX * d, oy = S.panY * d;
    // ombra della tela e scacchiera (trasparenza)
    g.save(); g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 30 * d; g.fillStyle = '#fff'; g.fillRect(ox, oy, doc.w * k, doc.h * k); g.restore();
    if (!page().bg) {
      if (!checker) { const c = document.createElement('canvas'); c.width = c.height = 16; const cg = c.getContext('2d'); cg.fillStyle = '#fff'; cg.fillRect(0, 0, 16, 16); cg.fillStyle = '#E6E8EC'; cg.fillRect(0, 0, 8, 8); cg.fillRect(8, 8, 8, 8); checker = g.createPattern(c, 'repeat'); }
      g.fillStyle = checker; g.fillRect(ox, oy, doc.w * k, doc.h * k);
    }
    const hide = new Set(S.editing ? [S.editing.id] : []);
    const ok = renderPage(g, doc, page(), { k, ox, oy }, assets, { hide });
    if (!ok) setTimeout(draw, 120);
    zoomLbl.textContent = Math.round(S.zoom * 100) + '%';
    renderOverlay();
  }

  function selBox() {
    const ls = selLayers();
    if (!ls.length) return null;
    if (ls.length === 1 && ls[0].type !== 'group' && ls[0].type !== 'adjust') return { l: ls[0], cs: corners(ls[0]), rot: ls[0].rot || 0 };
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const l of ls) { if (l.type === 'adjust') continue; const b = bounds(l); x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y); x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h); }
    if (!isFinite(x0)) return null;
    return { l: null, cs: [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], rot: 0, box: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 } };
  }
  function handles(sb) {
    // 8 maniglie + rotazione, in coordinate dello schermo
    const s = sb.cs.map(([x, y]) => toScr(x, y));
    const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
    const out = { nw: s[0], n: mid(s[0], s[1]), ne: s[1], e: mid(s[1], s[2]), se: s[2], s: mid(s[2], s[3]), sw: s[3], w: mid(s[3], s[0]) };
    const isText = sb.l && sb.l.type === 'text';
    if (isText) { delete out.n; delete out.s; }
    const a = sb.rot * Math.PI / 180;
    out.rot = [out.n ? out.n[0] + Math.sin(a) * 26 : mid(s[0], s[1])[0] + Math.sin(a) * 26, (out.n ? out.n[1] : mid(s[0], s[1])[1]) - Math.cos(a) * 26];
    return out;
  }
  function renderOverlay() {
    const d = dpr(), g = ov.getContext('2d');
    g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, ov.width, ov.height);
    const poly = (cs, color, w = 1, dash) => { g.beginPath(); cs.forEach(([x, y], i) => { const [a, b] = toScr(x, y); if (i) g.lineTo(a, b); else g.moveTo(a, b); }); g.closePath(); g.strokeStyle = color; g.lineWidth = w; g.setLineDash(dash || []); g.stroke(); g.setLineDash([]); };
    // passaggio del mouse
    if (S.hover && !S.sel.includes(S.hover) && S.tool === 'move' && !S.drag) {
      const r = findLayer(layers(), S.hover);
      if (r) { const b = r.layer.type === 'group' ? bounds(r.layer) : null; poly(b ? [[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]] : corners(r.layer), '#4F9BFF', 1); }
    }
    // guide magnetiche
    for (const gd of S.guides) {
      g.beginPath(); g.strokeStyle = '#FF3D9A'; g.lineWidth = 1;
      if (gd.x != null) { const [x] = toScr(gd.x, 0); g.moveTo(Math.round(x) + 0.5, 0); g.lineTo(Math.round(x) + 0.5, ov.height); }
      else { const [, y] = toScr(0, gd.y); g.moveTo(0, Math.round(y) + 0.5); g.lineTo(ov.width, Math.round(y) + 0.5); }
      g.stroke();
    }
    // selezione
    const sb = S.tool === 'move' && !S.editing ? selBox() : null;
    if (sb) {
      if (!sb.l) for (const l of selLayers()) if (l.type !== 'adjust') poly(l.type === 'group' ? (() => { const b = bounds(l); return [[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]]; })() : corners(l), 'rgba(79,155,255,.55)', 1);
      poly(sb.cs, '#2F8BFF', 1.5);
      const locked = selLayers().some((l) => l.locked);
      if (!locked && !S.drag) {
        const hs = handles(sb);
        const top = hs.n || [(toScr(...sb.cs[0])[0] + toScr(...sb.cs[1])[0]) / 2, (toScr(...sb.cs[0])[1] + toScr(...sb.cs[1])[1]) / 2];
        g.beginPath(); g.moveTo(top[0], top[1]); g.lineTo(hs.rot[0], hs.rot[1]); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1; g.stroke();
        for (const [k2, [x, y]] of Object.entries(hs)) {
          g.beginPath();
          if (k2 === 'rot') g.arc(x, y, 5.5, 0, Math.PI * 2);
          else if (k2.length === 1) { g.save(); g.translate(x, y); g.rotate(sb.rot * Math.PI / 180 + (k2 === 'e' || k2 === 'w' ? Math.PI / 2 : 0)); g.roundRect(-7, -3, 14, 6, 3); g.restore(); }
          else g.roundRect(x - 5, y - 5, 10, 10, 2.5);
          g.fillStyle = '#fff'; g.fill(); g.strokeStyle = '#2F8BFF'; g.lineWidth = 1.5; g.stroke();
        }
      }
      // misure durante il trascinamento
      if (S.drag && S.drag.label) {
        const [x, y] = toScr(sb.cs[2][0], sb.cs[2][1]);
        g.font = '600 11px -apple-system, "Segoe UI", sans-serif';
        const tw = g.measureText(S.drag.label).width + 14;
        g.fillStyle = '#2F8BFF'; g.beginPath(); g.roundRect(x + 8, y + 8, tw, 20, 6); g.fill();
        g.fillStyle = '#fff'; g.fillText(S.drag.label, x + 15, y + 22);
      }
    }
    // riquadro di selezione (trascinando sul vuoto)
    if (S.marq) {
      const [a, b] = toScr(S.marq.x0, S.marq.y0), [c, e] = toScr(S.marq.x1, S.marq.y1);
      g.fillStyle = 'rgba(47,139,255,.08)'; g.fillRect(Math.min(a, c), Math.min(b, e), Math.abs(c - a), Math.abs(e - b));
      g.strokeStyle = '#2F8BFF'; g.lineWidth = 1; g.strokeRect(Math.min(a, c) + 0.5, Math.min(b, e) + 0.5, Math.abs(c - a), Math.abs(e - b));
    }
    // ritaglio
    if (S.crop) {
      const c = S.crop, [x0, y0] = toScr(c.x, c.y), [x1, y1] = toScr(c.x + c.w, c.y + c.h);
      g.fillStyle = 'rgba(8,10,14,.62)';
      g.beginPath(); g.rect(0, 0, ov.width / d, ov.height / d); g.rect(x0, y0, x1 - x0, y1 - y0); g.fill('evenodd');
      g.strokeStyle = '#fff'; g.lineWidth = 1; g.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0, y1 - y0);
      g.strokeStyle = 'rgba(255,255,255,.35)';
      for (let i = 1; i < 3; i++) { g.beginPath(); g.moveTo(x0 + (x1 - x0) * i / 3, y0); g.lineTo(x0 + (x1 - x0) * i / 3, y1); g.moveTo(x0, y0 + (y1 - y0) * i / 3); g.lineTo(x1, y0 + (y1 - y0) * i / 3); g.stroke(); }
      g.fillStyle = '#fff';
      for (const [x, y] of [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]) { g.fillRect(x - 5, y - 5, 10, 10); }
      g.font = '600 11px -apple-system, "Segoe UI", sans-serif'; const lab = Math.round(c.w) + ' × ' + Math.round(c.h);
      g.fillStyle = 'rgba(0,0,0,.6)'; g.beginPath(); g.roundRect(x0, y1 + 8, g.measureText(lab).width + 14, 20, 6); g.fill(); g.fillStyle = '#fff'; g.fillText(lab, x0 + 7, y1 + 22);
    }
    // pennello: il cerchio della punta
    if ((S.tool === 'brush' || S.tool === 'eraser') && S.mouse) {
      const r = S.brush.size / 2 * S.zoom;
      g.beginPath(); g.arc(S.mouse[0], S.mouse[1], Math.max(1, r), 0, Math.PI * 2); g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 2; g.stroke();
      g.beginPath(); g.arc(S.mouse[0], S.mouse[1], Math.max(1, r), 0, Math.PI * 2); g.strokeStyle = '#fff'; g.lineWidth = 1; g.stroke();
    }
    // forma che si sta disegnando
    if (S.drag && S.drag.kind === 'newshape') { const b = S.drag.box; poly([[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]], '#2F8BFF', 1, [4, 3]); }
  }

  // ------------------------------------------------------------ selezione dei livelli
  function select(ids, add) {
    if (add) { for (const id of ids) { const i = S.sel.indexOf(id); if (i >= 0) S.sel.splice(i, 1); else S.sel.push(id); } } else S.sel = [...ids];
    S.maskEdit = S.maskEdit && !!(one() && one().mask);
    draw(); refresh();
  }
  // livello sotto il punto (dall'alto). deep = dentro i gruppi
  function hitAt(px, py, deep) {
    const ls = layers();
    for (let i = ls.length - 1; i >= 0; i--) {
      const l = ls[i];
      if (!l.visible || l.locked || l.type === 'adjust') continue;
      if (l.type === 'group') {
        const inner = hitIn(l.children || [], px, py);
        if (inner) return deep ? inner : l;
        continue;
      }
      if (hitLayer(l, px, py, toLocal, assets)) return l;
    }
    return null;
  }
  function hitIn(list, px, py) {
    for (let i = list.length - 1; i >= 0; i--) {
      const l = list[i];
      if (!l.visible || l.locked || l.type === 'adjust') continue;
      if (l.type === 'group') { const r = hitIn(l.children || [], px, py); if (r) return r; continue; }
      if (hitLayer(l, px, py, toLocal, assets)) return l;
    }
    return null;
  }
  function handleAt(sx, sy) {
    if (S.tool !== 'move' || selLayers().some((l) => l.locked)) return null;
    const sb = selBox(); if (!sb) return null;
    const hs = handles(sb);
    for (const [k, [x, y]] of Object.entries(hs)) if (Math.hypot(sx - x, sy - y) <= HANDLE) return { k, sb };
    return null;
  }

  // ------------------------------------------------------------ trascinamenti sulla tela
  let spaceDown = false;
  stage.addEventListener('pointerdown', (e) => {
    stage.focus({ preventScroll: true });
    if (S.editing) { if (e.target === cv || e.target === ov) stopEdit(true); else return; }
    const r = stage.getBoundingClientRect(), sx = e.clientX - r.left, sy = e.clientY - r.top;
    const [px, py] = toDoc(sx, sy);
    if (e.button === 1 || spaceDown || S.tool === 'hand') return startPan(e, sx, sy);
    if (e.button !== 0) return;
    stage.setPointerCapture(e.pointerId);
    if (S.tool === 'crop') return startCrop(e, px, py, sx, sy);
    if (S.tool === 'eyedrop') return eyedrop(sx, sy);
    if ((S.tool === 'brush' || S.tool === 'eraser') && e.altKey) return eyedrop(sx, sy);
    if (S.tool === 'brush' || S.tool === 'eraser') return startPaint(e, px, py);
    if (S.tool === 'shape') { S.drag = { kind: 'newshape', x0: px, y0: py, box: { x: px, y: py, w: 0, h: 0 }, move: (x, y, ev) => shapeMove(x, y, ev) }; return; }
    if (S.tool === 'text') {
      e.preventDefault();   // il fuoco resta al testo che si apre (non alla tela)
      const hit = hitAt(px, py, true);
      if (hit && hit.type === 'text') { select([hit.id]); startEdit(hit); return; }
      const l = textLayer(doc, { text: '', color: S.color, auto: true, align: 'left' });
      l.w = 20; l.x = px; l.y = py - l.size * 0.6;
      addLayer(l, true);
      setTool('move', true);
      startEdit(l, true);
      return;
    }
    // sposta
    const hd = handleAt(sx, sy);
    if (hd) return startTransform(e, hd, px, py);
    const hit = hitAt(px, py, e.ctrlKey || e.metaKey);
    if (hit) {
      if (e.shiftKey) { select([hit.id], true); return; }
      if (!S.sel.includes(hit.id)) select([hit.id]);
      if (e.detail === 2 && hit.type === 'text') { startEdit(hit); return; }
      return startMove(e, px, py, e.altKey);
    }
    if (!e.shiftKey) select([]);
    S.marq = { x0: px, y0: py, x1: px, y1: py, add: e.shiftKey, base: [...S.sel] };
  });
  stage.addEventListener('dblclick', (e) => {
    const r = stage.getBoundingClientRect(); const [px, py] = toDoc(e.clientX - r.left, e.clientY - r.top);
    if (S.tool !== 'move') return;
    const hit = hitAt(px, py, true);
    if (hit && hit.type === 'text') { select([hit.id]); startEdit(hit); }
  });
  stage.addEventListener('pointermove', (e) => {
    const r = stage.getBoundingClientRect(), sx = e.clientX - r.left, sy = e.clientY - r.top;
    S.mouse = [sx, sy];
    const [px, py] = toDoc(sx, sy);
    if (S.pan) { S.panX = S.pan.x + (e.clientX - S.pan.cx); S.panY = S.pan.y + (e.clientY - S.pan.cy); draw(); return; }
    if (S.drag) { S.drag.move(px, py, e); draw(); return; }
    if (S.marq) {
      S.marq.x1 = px; S.marq.y1 = py;
      const x0 = Math.min(S.marq.x0, px), x1 = Math.max(S.marq.x0, px), y0 = Math.min(S.marq.y0, py), y1 = Math.max(S.marq.y0, py);
      const ids = layers().filter((l) => l.visible && !l.locked && l.type !== 'adjust').filter((l) => { const b = bounds(l); return b.x < x1 && b.x + b.w > x0 && b.y < y1 && b.y + b.h > y0; }).map((l) => l.id);
      S.sel = S.marq.add ? [...new Set([...S.marq.base, ...ids])] : ids;
      draw(); return;
    }
    if (S.cropDrag) { S.cropDrag(px, py, e); draw(); return; }
    if (S.tool === 'shape' && S.drag === undefined) { /* niente */ }
    if (S.tool === 'shape' && S.drag && S.drag.kind === 'newshape') return;
    // cursore e passaggio
    let cur = '';
    if (S.tool === 'move') {
      const hd = handleAt(sx, sy);
      if (hd) cur = hd.k === 'rot' ? 'grab' : cursorFor(hd.k, hd.sb.rot);
      const hit = hd ? null : hitAt(px, py, e.ctrlKey || e.metaKey);
      const hv = hit ? hit.id : null;
      if (hv !== S.hover) { S.hover = hv; draw(); }
      if (!cur && hit) cur = 'move';
    } else if (S.tool === 'hand' || spaceDown) cur = 'grab';
    else if (S.tool === 'text') cur = 'text';
    else if (S.tool === 'brush' || S.tool === 'eraser') { cur = 'none'; draw(); }
    else if (S.tool === 'shape' || S.tool === 'crop' || S.tool === 'eyedrop') cur = 'crosshair';
    stage.style.cursor = cur;
  });
  const endDrag = (e) => {
    if (S.pan) { S.pan = null; stage.style.cursor = spaceDown || S.tool === 'hand' ? 'grab' : ''; return; }
    if (S.drag) {
      const d = S.drag; S.drag = null; S.guides = [];
      if (d.kind === 'newshape') finishShape(d, e);
      else if (d.end) d.end(e);
      draw(); return;
    }
    if (S.marq) { S.marq = null; draw(); refresh(); return; }
    if (S.cropDrag) { S.cropDrag = null; draw(); }
  };
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);
  stage.addEventListener('pointerleave', () => { S.mouse = null; if (S.hover) { S.hover = null; } draw(); });
  stage.addEventListener('wheel', (e) => {
    e.preventDefault();
    const r = stage.getBoundingClientRect();
    if (e.ctrlKey || e.metaKey) { zoomAt(S.zoom * Math.exp(-e.deltaY * 0.0022), e.clientX - r.left, e.clientY - r.top); return; }
    S.panX -= e.shiftKey ? e.deltaY : e.deltaX; S.panY -= e.shiftKey ? 0 : e.deltaY; draw();
  }, { passive: false });

  function cursorFor(k, rot) {
    const dirs = ['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'];
    const i = (dirs.indexOf(k) + Math.round(((rot % 360) + 360) % 360 / 45)) % 8;
    return ['ns-resize', 'nesw-resize', 'ew-resize', 'nwse-resize', 'ns-resize', 'nesw-resize', 'ew-resize', 'nwse-resize'][i];
  }
  function startPan(e, sx, sy) { S.pan = { x: S.panX, y: S.panY, cx: e.clientX, cy: e.clientY }; stage.setPointerCapture(e.pointerId); stage.style.cursor = 'grabbing'; }

  // magnetismo: bordi e centri della tela e degli altri livelli
  function snapMove(box, dx, dy) {
    S.guides = [];
    if (!S.snap) return [dx, dy];
    const th = 6 / S.zoom;
    const xs = [0, doc.w / 2, doc.w], ys = [0, doc.h / 2, doc.h];
    for (const l of flatVisible(layers())) {
      if (S.sel.includes(l.id) || l.type === 'adjust') continue;
      const b = bounds(l); xs.push(b.x, b.x + b.w / 2, b.x + b.w); ys.push(b.y, b.y + b.h / 2, b.y + b.h);
    }
    const mx = [box.x + dx, box.x + dx + box.w / 2, box.x + dx + box.w], my = [box.y + dy, box.y + dy + box.h / 2, box.y + dy + box.h];
    let bx = null, by = null;
    for (const a of mx) for (const t of xs) if (Math.abs(a - t) < th && (!bx || Math.abs(a - t) < Math.abs(bx.d))) bx = { d: t - a, t };
    for (const a of my) for (const t of ys) if (Math.abs(a - t) < th && (!by || Math.abs(a - t) < Math.abs(by.d))) by = { d: t - a, t };
    if (bx) { dx += bx.d; S.guides.push({ x: bx.t }); }
    if (by) { dy += by.d; S.guides.push({ y: by.t }); }
    return [dx, dy];
  }

  function startMove(e, px, py, dup) {
    let ls = selLayers().filter((l) => !l.locked);
    if (!ls.length) return;
    if (dup) { duplicateSel(true); ls = selLayers(); }
    const orig = ls.map((l) => clone(l));
    const sb = selBox(); const box = sb.box || bounds(ls[0]);
    let moved = false;
    S.drag = {
      move(x, y, ev) {
        let dx = x - px, dy = y - py;
        if (ev.shiftKey) { if (Math.abs(dx) > Math.abs(dy)) dy = 0; else dx = 0; }
        [dx, dy] = snapMove(box, dx, dy);
        if (Math.abs(dx) + Math.abs(dy) > 0) moved = true;
        ls.forEach((l, i) => { const o = orig[i]; const cur = clone(o); moveBy(cur, dx, dy); Object.assign(l, cur.type === 'group' ? { children: cur.children } : { x: cur.x, y: cur.y }); });
        S.drag.label = 'X ' + Math.round(box.x + dx) + '  Y ' + Math.round(box.y + dy);
      },
      end() { if (moved || dup) commit(); },
    };
  }

  function startTransform(e, hd, px, py) {
    const ls = selLayers().filter((l) => !l.locked);
    const orig = ls.map((l) => clone(l));
    const sb = hd.sb, single = sb.l;
    if (hd.k === 'rot') {
      const c = single ? [single.x + single.w / 2, single.y + single.h / 2] : [sb.box.x + sb.box.w / 2, sb.box.y + sb.box.h / 2];
      const a0 = Math.atan2(py - c[1], px - c[0]);
      S.drag = {
        move(x, y, ev) {
          let da = (Math.atan2(y - c[1], x - c[0]) - a0) * 180 / Math.PI;
          ls.forEach((l, i) => {
            const o = orig[i];
            let r = ((o.rot || 0) + da);
            if (ev.shiftKey) r = Math.round(r / 15) * 15; else if (Math.abs(((r % 90) + 90) % 90) < 2.5 || Math.abs(((r % 90) + 90) % 90) > 87.5) r = Math.round(r / 90) * 90;
            const dr = r - (o.rot || 0);
            const rotOne = (t, src) => {
              if (t.type === 'group') { t.children.forEach((ch, j) => rotOne(ch, src.children[j])); return; }
              if (t.type === 'adjust') return;
              const a = dr * Math.PI / 180, cx = src.x + src.w / 2 - c[0], cy = src.y + src.h / 2 - c[1];
              const nx = c[0] + cx * Math.cos(a) - cy * Math.sin(a), ny = c[1] + cx * Math.sin(a) + cy * Math.cos(a);
              t.x = nx - t.w / 2; t.y = ny - t.h / 2; t.rot = ((((src.rot || 0) + dr) % 360) + 360) % 360; if (t.rot > 180) t.rot -= 360;
            };
            rotOne(l, o);
          });
          S.drag.label = Math.round(single ? single.rot : da) + '°';
        },
        end() { commit(); },
      };
      return;
    }
    // ridimensionamento: l'angolo opposto resta fermo
    const k = hd.k;
    const ax = k.includes('w') ? 1 : k.includes('e') ? -1 : 0, ay = k.includes('n') ? 1 : k.includes('s') ? -1 : 0;   // da dove si tira
    const R = single ? (single.rot || 0) * Math.PI / 180 : 0, cs = Math.cos(R), sn = Math.sin(R);
    const ob = single ? { x: single.x, y: single.y, w: single.w, h: single.h } : { ...sb.box };
    const ctr = [ob.x + ob.w / 2, ob.y + ob.h / 2];
    const anchorLocal = [ax * ob.w / 2, ay * ob.h / 2];
    const anchor = [ctr[0] + anchorLocal[0] * cs - anchorLocal[1] * sn, ctr[1] + anchorLocal[0] * sn + anchorLocal[1] * cs];
    const isText = single && single.type === 'text';
    const keepRatio = (ev) => (single && (single.type === 'image' || single.type === 'group' || (isText && ax && ay))) || !single ? !ev.shiftKey : ev.shiftKey;
    S.drag = {
      move(x, y, ev) {
        // punto del mouse nelle coordinate del riquadro (ruotato), rispetto all'angolo fermo
        const dx = x - anchor[0], dy = y - anchor[1];
        let lx = dx * cs + dy * sn, ly = -dx * sn + dy * cs;
        let nw = ax ? Math.abs(lx) : ob.w, nh = ay ? Math.abs(ly) : ob.h;
        if (ax && Math.sign(lx) === ax) nw = 1;
        if (ay && Math.sign(ly) === ay) nh = 1;
        if (keepRatio(ev) && ax && ay) { const kk = Math.max(nw / ob.w, nh / ob.h); nw = ob.w * kk; nh = ob.h * kk; }
        if (ev.altKey) { /* dal centro */ }
        nw = Math.max(1, nw); nh = Math.max(1, nh);
        const kx = nw / ob.w, ky = nh / ob.h;
        // nuovo centro
        const nlx = -ax * nw / 2, nly = -ay * nh / 2;
        const ncx = anchor[0] + nlx * cs - nly * sn, ncy = anchor[1] + nlx * sn + nly * cs;
        if (single) {
          const l = ls[0], o = orig[0];
          if (single.type === 'group') {
            Object.assign(l, clone(o)); scaleAround(l, ob.x + (ax === 1 ? ob.w : ax === -1 ? 0 : ob.w / 2), ob.y + (ay === 1 ? ob.h : ay === -1 ? 0 : ob.h / 2), kx, ky);
          } else if (isText) {
            if (ax && ay) { const kk = nw / ob.w; l.size = Math.max(4, o.size * kk); l.w = Math.max(10, o.w * kk); l.letter = (o.letter || 0) * kk; }
            else { l.w = Math.max(10, nw); l.auto = false; }
            l.h = textHeight(l);
            // l'angolo (o il lato) da cui non si tira resta fermo; sui lati resta fermo anche il bordo in alto
            const lx2 = -ax * l.w / 2, ly2 = ay ? -ay * l.h / 2 : (l.h - o.h) / 2;
            const c2x = anchor[0] + lx2 * cs - ly2 * sn, c2y = anchor[1] + lx2 * sn + ly2 * cs;
            l.x = c2x - l.w / 2; l.y = c2y - l.h / 2;
          } else {
            l.w = nw; l.h = nh; l.x = ncx - nw / 2; l.y = ncy - nh / 2;
            if (o.fx && o.fx.stroke) { /* il contorno resta della stessa misura */ }
          }
          S.drag.label = Math.round(l.w) + ' × ' + Math.round(isText ? l.h : l.h);
        } else {
          const ox = ax === 1 ? ob.x + ob.w : ax === -1 ? ob.x : ob.x + ob.w / 2, oy = ay === 1 ? ob.y + ob.h : ay === -1 ? ob.y : ob.y + ob.h / 2;
          ls.forEach((l, i) => { const c = clone(orig[i]); scaleAround(c, ox, oy, kx, ky); Object.assign(l, c); });
          S.drag.label = Math.round(nw) + ' × ' + Math.round(nh);
        }
      },
      end() { commit(); },
    };
  }

  function finishShape(d, e) {
    let b = d.box;
    if (b.w < 3 && b.h < 3) {   // un clic: forma di misura standard
      const s = Math.round(Math.min(doc.w, doc.h) * 0.3);
      b = { x: d.x0 - s / 2, y: d.y0 - s / 2, w: s, h: S.shape === 'line' ? Math.max(4, s / 40) : s };
    }
    const l = shapeLayer(S.shape, b.x, b.y, Math.max(1, b.w), Math.max(1, b.h), { fill: S.colorSet ? S.color : '#2F8BFF' });
    if (S.shape === 'line') { l.h = Math.max(2, Math.round(Math.min(doc.w, doc.h) / 150)); l.y = b.y + b.h / 2 - l.h / 2; l.w = Math.max(10, Math.hypot(b.w, b.h)); }
    addLayer(l);
    setTool('move');
    void e;
  }
  // forma: aggiorna il riquadro mentre si trascina
  const shapeMove = (px, py, ev) => {
    const d = S.drag; let w = px - d.x0, hh = py - d.y0;
    if (ev.shiftKey) { const m = Math.max(Math.abs(w), Math.abs(hh)); w = Math.sign(w || 1) * m; hh = Math.sign(hh || 1) * m; }
    d.box = { x: Math.min(d.x0, d.x0 + w), y: Math.min(d.y0, d.y0 + hh), w: Math.abs(w), h: Math.abs(hh) };
    if (ev.altKey) d.box = { x: d.x0 - Math.abs(w), y: d.y0 - Math.abs(hh), w: Math.abs(w) * 2, h: Math.abs(hh) * 2 };
  };

  // ------------------------------------------------------------ pennello e gomma (pittura o maschera del livello)
  function paintTarget() {
    let l = one();
    if (S.tool === 'eraser' && l && l.type !== 'paint' && l.type !== 'group' && l.type !== 'adjust') return { l, mask: true };
    if (l && S.maskEdit && l.mask) return { l, mask: true };
    if (l && l.type === 'paint') return { l, mask: false };
    if (S.tool === 'eraser') { toast('Scegli un livello da cancellare', true); return null; }
    // nuovo livello di pittura sopra quello scelto
    l = paintLayer(doc);
    addLayer(l, true);
    return { l, mask: false };
  }
  function startPaint(e, px, py) {
    const t = paintTarget(); if (!t) return;
    const l = t.l;
    if (l.locked) { toast('Il livello è bloccato', true); return; }
    let base;
    if (t.mask) {
      if (!l.mask) {
        const iw = Math.min(2048, Math.round(l.type === 'image' && l.iw ? l.iw : l.w)), ihh = Math.max(1, Math.round(iw * l.h / l.w));
        base = document.createElement('canvas'); base.width = iw; base.height = ihh;
        const g0 = base.getContext('2d'); g0.fillStyle = '#fff'; g0.fillRect(0, 0, iw, ihh);
        l.mask = { src: storeCanvas(base, 'mask'), on: true };
      } else {
        const a = assets.get(l.mask.src); if (!a) { toast('Maschera non ancora pronta', true); return; }
        base = document.createElement('canvas'); base.width = a.w; base.height = a.h; base.getContext('2d').drawImage(a.el, 0, 0);
      }
    } else {
      base = document.createElement('canvas'); base.width = Math.max(1, Math.round(l.w)); base.height = Math.max(1, Math.round(l.h));
      const a = l.src ? assets.get(l.src) : null;
      if (a) base.getContext('2d').drawImage(a.el, 0, 0, base.width, base.height);
    }
    const sx = base.width / l.w, sy = base.height / l.h;
    const stroke = document.createElement('canvas'); stroke.width = base.width; stroke.height = base.height;
    const out = document.createElement('canvas'); out.width = base.width; out.height = base.height;
    const sg = stroke.getContext('2d'), og = out.getContext('2d');
    const erase = S.tool === 'eraser';
    const color = t.mask ? '#fff' : S.color;
    const rad = Math.max(0.5, S.brush.size / 2 * sx);
    // il tratto si ridisegna intero a ogni movimento: bordi lisci, niente "perline" tra un punto e l'altro
    const pts = [];
    const hard = S.brush.hard;
    const strokePath = () => {
      sg.clearRect(0, 0, stroke.width, stroke.height);
      if (!pts.length) return;
      sg.save();
      sg.lineCap = 'round'; sg.lineJoin = 'round';
      const far = 100000, soft = hard < 0.98;
      sg.strokeStyle = color; sg.fillStyle = color;
      sg.lineWidth = soft ? 2 * rad * (0.3 + 0.7 * hard) : 2 * rad;
      if (soft) { sg.shadowColor = color; sg.shadowBlur = rad * (1 - hard) * 1.6 + 1; sg.shadowOffsetX = far; sg.translate(-far, 0); }
      sg.beginPath();
      if (pts.length === 1) { sg.arc(pts[0][0], pts[0][1], sg.lineWidth / 2, 0, Math.PI * 2); sg.fill(); }
      else {
        sg.moveTo(pts[0][0], pts[0][1]);
        for (let i = 1; i < pts.length - 1; i++) { const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2; sg.quadraticCurveTo(pts[i][0], pts[i][1], mx, my); }
        sg.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
        sg.stroke();
      }
      sg.restore();
    };
    const mem = 'live_' + l.id + '.png';
    const compose = () => {
      og.globalCompositeOperation = 'copy'; og.globalAlpha = 1; og.drawImage(base, 0, 0);
      og.globalAlpha = S.brush.opacity;
      // gomma: toglie (sulla maschera: nasconde); pennello sulla maschera: rimette
      og.globalCompositeOperation = erase ? 'destination-out' : 'source-over';
      og.drawImage(stroke, 0, 0);
      og.globalAlpha = 1; og.globalCompositeOperation = 'source-over';
      assets.put(mem, out);
    };
    const origSrc = t.mask ? l.mask.src : l.src;
    if (t.mask) l.mask.src = mem; else l.src = mem;
    const dab = (x, y, straight) => {
      const [lx, ly] = toLocal(l, x, y);
      if (straight && pts.length > 1) pts.length = 1;
      pts.push([lx * sx, ly * sy]);
      strokePath();
    };
    dab(px, py); compose(); draw();
    S.drag = {
      move(x, y, ev) { dab(x, y, ev.shiftKey); compose(); },
      end() {
        const name = storeCanvas(out, t.mask ? 'mask' : 'paint');
        if (t.mask) l.mask.src = name; else { l.src = name; l.iw = out.width; }
        void origSrc;
        commit();
      },
    };
  }

  function eyedrop(sx, sy) {
    const d = dpr();
    try {
      const px = cv.getContext('2d').getImageData(Math.round(sx * d), Math.round(sy * d), 1, 1).data;
      const hex = '#' + [px[0], px[1], px[2]].map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase();
      setColor(hex, true);
      toast('Colore preso: ' + hex);
    } catch (e) { /* */ }
  }
  function setColor(c, apply) {
    S.color = c; S.colorSet = true;
    if (apply) {
      const ls = selLayers().filter((l) => l.type === 'text' || l.type === 'shape');
      if (ls.length) { ls.forEach((l) => { if (l.type === 'text') { l.color = c; delete l.fill; } else l.fill = c; }); commit(); }
    }
    paintTools(); paintOpts();
  }

  // ------------------------------------------------------------ ritaglio della tela
  function startCropMode() { S.crop = { x: 0, y: 0, w: doc.w, h: doc.h, ratio: 0 }; draw(); paintOpts(); }
  function startCrop(e, px, py, sx, sy) {
    if (!S.crop) startCropMode();
    const c = S.crop, o = { ...c };
    const near = (x, y) => { const [a, b] = toScr(x, y); return Math.hypot(a - sx, b - sy) < 12; };
    let mode = null;
    if (near(c.x, c.y)) mode = 'nw'; else if (near(c.x + c.w, c.y)) mode = 'ne'; else if (near(c.x + c.w, c.y + c.h)) mode = 'se'; else if (near(c.x, c.y + c.h)) mode = 'sw';
    else if (px > c.x && px < c.x + c.w && py > c.y && py < c.y + c.h) mode = 'move';
    else mode = 'new';
    S.cropDrag = (x, y) => {
      const dx = x - px, dy = y - py;
      if (mode === 'move') { c.x = o.x + dx; c.y = o.y + dy; return; }
      let x0 = o.x, y0 = o.y, x1 = o.x + o.w, y1 = o.y + o.h;
      if (mode === 'new') { x0 = px; y0 = py; x1 = x; y1 = y; }
      if (mode.includes('w')) x0 = o.x + dx; if (mode.includes('e')) x1 = o.x + o.w + dx;
      if (mode.includes('n')) y0 = o.y + dy; if (mode.includes('s')) y1 = o.y + o.h + dy;
      let w = Math.max(1, Math.abs(x1 - x0)), hh = Math.max(1, Math.abs(y1 - y0));
      if (c.ratio) { hh = w / c.ratio; if (mode === 'new' || mode.includes('n')) y0 = mode === 'new' ? Math.min(y0, y1) : y1 - hh; }
      c.x = Math.min(x0, x1); c.y = Math.min(y0, mode === 'new' && c.ratio ? y0 : y1); c.w = w; c.h = hh;
      if (!c.ratio) c.y = Math.min(y0, y1);
    };
  }
  function applyCrop() {
    const c = S.crop; if (!c) return;
    const x = Math.round(c.x), y = Math.round(c.y), w = Math.max(1, Math.round(c.w)), hh = Math.max(1, Math.round(c.h));
    for (const p of doc.pages) for (const l of p.layers) moveBy(l, -x, -y);
    doc.w = w; doc.h = hh; S.crop = null;
    commit(); fit(); setTool('move');
  }
  function resizeCanvas(w, hh, scaleContent) {
    w = Math.max(1, Math.min(16000, Math.round(w))); hh = Math.max(1, Math.min(16000, Math.round(hh)));
    if (scaleContent) { const kx = w / doc.w, ky = hh / doc.h, k = Math.min(kx, ky); for (const p of doc.pages) for (const l of p.layers) { scaleAround(l, 0, 0, k, k); moveBy(l, (w - doc.w * k) / 2, (hh - doc.h * k) / 2); } }
    else { const dx = (w - doc.w) / 2, dy = (hh - doc.h) / 2; for (const p of doc.pages) for (const l of p.layers) moveBy(l, dx, dy); }
    doc.w = w; doc.h = hh; commit(); fit();
  }

  // ------------------------------------------------------------ testo: si scrive direttamente sulla tela
  function startEdit(l, fresh) {
    if (l.locked) return;
    stopEdit(false);
    ensureFont(l.font);
    const ta = h('textarea', { class: 'dz-tedit', spellcheck: 'false', 'aria-label': 'Testo' });
    ta.value = l.text || '';
    S.editing = { id: l.id, ta, fresh, before: l.text };
    const place = () => {
      const lines = Math.max(1, (ta.value.match(/\n/g) || []).length + 1);
      const z = S.zoom;
      Object.assign(ta.style, {
        left: S.panX + l.x * z + 'px', top: S.panY + l.y * z + 'px', width: Math.max(20, l.w * z + 4) + 'px', height: Math.max(l.size * l.lineH * z, l.h * z) + 'px',
        font: fontOf(l, z), lineHeight: (l.size * (l.lineH || 1.2) * z) + 'px', color: fillColor(l.fill || l.color), textAlign: l.align || 'center',
        letterSpacing: (l.letter || 0) * z + 'px', textTransform: l.upper ? 'uppercase' : 'none', transform: `rotate(${l.rot || 0}deg)`,
      });
      void lines;
    };
    ta.addEventListener('input', () => {
      l.text = ta.value;
      if (l.auto) { const cx = l.x + l.w / 2; l.w = Math.max(20, textNaturalWidth(l)); if (!S.editing.fresh) l.x = cx - l.w / 2; }
      l.h = textHeight(l); place(); draw();
    });
    ta.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Escape' || (e.key === 'Enter' && (e.ctrlKey || e.metaKey))) { e.preventDefault(); stopEdit(true); } });
    ta.addEventListener('blur', () => setTimeout(() => { if (S.editing && S.editing.ta === ta) stopEdit(true); }, 0));
    stage.append(ta); place();
    S.editing.place = place;
    ta.focus(); if (!fresh) ta.select();
    setTimeout(() => { if (document.activeElement !== ta && S.editing && S.editing.ta === ta) ta.focus(); }, 0);
    draw();
  }
  function stopEdit(save) {
    const ed = S.editing; if (!ed) return;
    S.editing = null; ed.ta.remove();
    const r = findLayer(layers(), ed.id);
    if (r) {
      const l = r.layer;
      if (!String(l.text || '').trim()) { r.arr.splice(r.i, 1); S.sel = S.sel.filter((id) => id !== l.id); }
      else if (l.text !== ed.before || ed.fresh) l.name = String(l.text).split('\n')[0].slice(0, 40);
    }
    if (save) commit(); else { draw(); refresh(); }
  }

  // ------------------------------------------------------------ operazioni sui livelli
  function container() {
    // i livelli nuovi vanno sopra quello scelto (nello stesso gruppo)
    const l = one(); if (!l) return { arr: layers(), i: layers().length };
    const r = findLayer(layers(), l.id);
    return { arr: r.arr, i: r.i + 1 };
  }
  function addLayer(l, noCommit) {
    const c = container();
    c.arr.splice(c.i, 0, l);
    S.sel = [l.id];
    if (!noCommit) commit(); else { draw(); refresh(); }
    return l;
  }
  function deleteSel() {
    if (!S.sel.length) return;
    for (const id of [...S.sel]) { const r = findLayer(layers(), id); if (r) r.arr.splice(r.i, 1); }
    S.sel = []; commit();
  }
  const reId = (l) => { l.id = uid(); if (l.children) l.children.forEach(reId); return l; };
  function duplicateSel(inPlace) {
    const ids = [];
    for (const l of selLayers()) {
      const r = findLayer(layers(), l.id);
      const c = reId(clone(l)); c.name = (l.name || '') + (inPlace ? '' : ' copia');
      if (!inPlace) moveBy(c, 20, 20);
      r.arr.splice(r.i + 1, 0, c); ids.push(c.id);
    }
    S.sel = ids; if (!inPlace) commit(); else { draw(); refresh(); }
  }
  function groupSel() {
    const ls = selLayers(); if (!ls.length) return;
    const first = findLayer(layers(), ls[0].id);
    const arr = first.arr;
    const inSame = ls.filter((l) => arr.includes(l));
    if (!inSame.length) return;
    const idx = Math.max(...inSame.map((l) => arr.indexOf(l)));
    const kids = arr.filter((l) => inSame.includes(l));
    const g = groupLayer(kids.map((l) => l));
    for (const l of kids) arr.splice(arr.indexOf(l), 1);
    arr.splice(Math.min(idx - kids.length + 1, arr.length), 0, g);
    S.sel = [g.id]; commit();
  }
  function ungroup() {
    const l = one(); if (!l || l.type !== 'group') return;
    const r = findLayer(layers(), l.id);
    r.arr.splice(r.i, 1, ...(l.children || []));
    S.sel = (l.children || []).map((c) => c.id); commit();
  }
  function arrange(dir) {
    for (const l of (dir > 0 ? [...selLayers()].reverse() : selLayers())) {
      const r = findLayer(layers(), l.id); const a = r.arr;
      a.splice(r.i, 1);
      const ni = dir === 2 ? a.length : dir === -2 ? 0 : Math.max(0, Math.min(a.length, r.i + dir));
      a.splice(ni, 0, l);
    }
    commit();
  }
  function align(how) {
    const ls = selLayers().filter((l) => l.type !== 'adjust'); if (!ls.length) return;
    const multi = ls.length > 1;
    const sb = selBox(); const B = multi ? sb.box : { x: 0, y: 0, w: doc.w, h: doc.h };
    for (const l of ls) {
      const b = bounds(l); let dx = 0, dy = 0;
      if (how === 'l') dx = B.x - b.x; if (how === 'r') dx = B.x + B.w - (b.x + b.w); if (how === 'ch') dx = B.x + B.w / 2 - (b.x + b.w / 2);
      if (how === 't') dy = B.y - b.y; if (how === 'b') dy = B.y + B.h - (b.y + b.h); if (how === 'cv') dy = B.y + B.h / 2 - (b.y + b.h / 2);
      moveBy(l, dx, dy);
    }
    commit();
  }
  function toggleMask() {
    const l = one();
    if (!l || l.type === 'group' || l.type === 'adjust') { toast('Scegli un livello per aggiungere la maschera', true); return; }
    if (l.mask) { delete l.mask; S.maskEdit = false; commit(); return; }
    const iw = Math.min(2048, Math.round(l.type === 'image' && l.iw ? l.iw : l.w)), ihh = Math.max(1, Math.round(iw * l.h / l.w));
    const c = document.createElement('canvas'); c.width = iw; c.height = ihh; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, iw, ihh);
    l.mask = { src: storeCanvas(c, 'mask'), on: true };
    S.maskEdit = true; setTool('eraser');
    toast('Maschera aggiunta: la gomma nasconde, il pennello fa riapparire');
    commit();
  }
  function adjustMenu(anchor) {
    menu(anchor, ADJUST_KINDS.map(([k, n]) => [n, () => addLayer(adjustLayer(k))]));
  }
  function menu(anchor, items) {
    document.querySelectorAll('.dz-menu').forEach((x) => x.remove());
    const r = anchor.getBoundingClientRect();
    const m = h('div', { class: 'dz-menu', style: { left: Math.min(window.innerWidth - 240, r.left) + 'px', top: r.bottom + 6 + 'px' } },
      ...items.filter(Boolean).map((it) => (it === '-' ? h('hr') : h('button', { onclick: () => { m.remove(); it[1](); }, disabled: it[2] ? true : null }, it[0]))));
    document.body.append(m);
    const rr = m.getBoundingClientRect(); if (rr.bottom > window.innerHeight - 8) m.style.top = Math.max(8, r.top - rr.height - 6) + 'px';
    const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  }

  // ------------------------------------------------------------ immagini: dal computer, trascinate, incollate
  // PSD: i livelli arrivano in un gruppo con il nome del file
  async function addPsd(buf, name) {
    setBusy('Apro il PSD…', 0);
    try {
      const res = await readPsd(buf, async (cv) => uploadBlob(await new Promise((r) => cv.toBlob(r, 'image/png')), 'psd'), (p) => setBusy('Apro il PSD…', p));
      if (!res.layers.length) { toast('Il PSD non ha livelli da importare', true); return; }
      const g = groupLayer(res.layers); g.name = (name || 'PSD').slice(0, 60); g.open = false;
      if (res.w !== doc.w || res.h !== doc.h) { const k = Math.min(doc.w / res.w, doc.h / res.h); scaleAround(g, 0, 0, k, k); moveBy(g, (doc.w - res.w * k) / 2, (doc.h - res.h * k) / 2); }
      addLayer(g);
    } catch (e) { toast(e.message, true); } finally { setBusy(null); }
  }
  async function addImagesFromPaths(paths) {
    for (const p of paths.filter((x) => /\.psd$/i.test(x))) {
      try { const r = await fetch(mediaUrl(p)); await addPsd(await r.arrayBuffer(), p.split(/[\\/]/).pop().replace(/\.psd$/i, '')); } catch (e) { toast(e.message, true); }
    }
    paths = paths.filter((x) => !/\.psd$/i.test(x));
    if (!paths.length) return;
    setBusy('Importo le immagini…');
    try {
      const r = await post(`/api/d/${gid}/import`, { paths });
      let n = 0;
      for (const f of r.files) { const l = imageLayer(f.file, f.w, f.h, doc, f.name); moveBy(l, n * 24, n * 24); addLayer(l, true); n++; }
      if (r.skipped && r.skipped.length) toast('Non importate: ' + r.skipped.join(', '), true);
      if (n) commit();
    } catch (e) { toast(e.message, true); }
    setBusy(null);
  }
  async function pickImages() {
    try {
      const r = await post('/api/pick', { kind: 'images' });
      if (r.fallback) { toast('Trascina le immagini sulla tela', true); return; }
      const paths = Array.isArray(r) ? r : r.path ? (Array.isArray(r.path) ? r.path : [r.path]) : r.paths || [];
      await addImagesFromPaths(paths);
    } catch (e) { toast(e.message, true); }
  }
  async function addImageBlob(blob, name, at) {
    let bm;
    try { bm = await createImageBitmap(blob); } catch (e) { toast('Immagine non leggibile', true); return; }
    let up = blob;
    if (!/image\/(png|jpeg|webp)/.test(blob.type)) {
      const c = document.createElement('canvas'); c.width = bm.width; c.height = bm.height; c.getContext('2d').drawImage(bm, 0, 0);
      up = await new Promise((r) => c.toBlob(r, 'image/png'));
    }
    const file = await uploadBlob(up, 'img');
    const l = imageLayer(file, bm.width, bm.height, doc, (name || 'Immagine').replace(/\.[a-z0-9]+$/i, '').slice(0, 60));
    if (at) { l.x = at[0] - l.w / 2; l.y = at[1] - l.h / 2; }
    addLayer(l);
  }
  stage.addEventListener('dragover', (e) => { e.preventDefault(); stage.classList.add('over'); });
  stage.addEventListener('dragleave', () => stage.classList.remove('over'));
  stage.addEventListener('drop', async (e) => {
    e.preventDefault(); stage.classList.remove('over');
    const r = stage.getBoundingClientRect(); const at = toDoc(e.clientX - r.left, e.clientY - r.top);
    for (const f of [...e.dataTransfer.files].filter((x) => /\.psd$/i.test(x.name))) await addPsd(await f.arrayBuffer(), f.name.replace(/\.psd$/i, ''));
    const files = [...e.dataTransfer.files].filter((f) => /^image\//.test(f.type) && !/\.psd$/i.test(f.name));
    if (!files.length) { if (![...e.dataTransfer.files].some((x) => /\.psd$/i.test(x.name))) toast('Trascina immagini (PNG, JPG, WebP, PSD…)', true); return; }
    setBusy('Importo le immagini…');
    try { for (const f of files) await addImageBlob(f, f.name, files.length === 1 ? at : null); } catch (er) { toast(er.message, true); }
    setBusy(null);
  });
  let clip = null;
  const onPaste = async (e) => {
    if (!alive || isTyping(e.target)) return;
    const it = [...(e.clipboardData ? e.clipboardData.items : [])].find((x) => /^image\//.test(x.type));
    if (it) { e.preventDefault(); setBusy('Incollo l\'immagine…'); try { await addImageBlob(it.getAsFile(), 'Immagine incollata'); } catch (er) { toast(er.message, true); } setBusy(null); return; }
    if (clip) { e.preventDefault(); pasteLayers(); }
  };
  function copyLayers() { const ls = selLayers(); if (ls.length) { clip = ls.map((l) => clone(l)); try { localStorage.setItem('nf.dzclip', JSON.stringify({ gid, layers: clip })); } catch (e) { /* */ } } }
  function pasteLayers() {
    if (!clip) return;
    const ids = [];
    for (const l of clip) { const c = reId(clone(l)); moveBy(c, 20, 20); layers().push(c); ids.push(c.id); }
    clip = clip.map((l) => { const c = clone(l); moveBy(c, 20, 20); return c; });
    S.sel = ids; commit();
  }
  document.addEventListener('paste', onPaste);
  // finestra chiusa subito dopo una modifica: l'ultimo salvataggio parte lo stesso
  const onHide = () => {
    if (!saveT || pending.size) return;
    let raw = JSON.stringify(doc);
    for (const [m, f] of memMap) raw = raw.split(m).join(f);
    try { fetch(`/api/d/${gid}?token=${TOKEN}`, { method: 'PUT', body: raw, keepalive: raw.length < 60000 }); } catch (e) { /* */ }
  };
  window.addEventListener('pagehide', onHide);
  window.addEventListener('beforeunload', onHide);

  // ------------------------------------------------------------ rimuovi sfondo (AI, sul computer)
  async function removeBg(l, mode) {
    setBusy(mode === 'persona' ? 'Ritaglio la persona…' : 'Rimuovo lo sfondo…', 0);
    try {
      const src = memMap.get(l.src) || l.src;
      if (pending.has(l.src)) await pending.get(l.src);
      const j = await post(`/api/d/${gid}/removebg`, { file: memMap.get(l.src) || src, mode });
      const r = await pollJob(j.id, (x) => setBusy(x.message || 'Rimuovo lo sfondo…', x.progress));
      if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
      l.src = r.result.file; l.name = (l.name || 'Immagine').replace(/ \(senza sfondo\)$/, '') + ' (senza sfondo)';
      commit();
      toast('Sfondo rimosso');
    } catch (e) { toast(e.message, true); }
    setBusy(null);
  }
  // ------------------------------------------------------------ immagini create dall'AI
  async function aiDialog() {
    let info = { ready: false };
    try { info = await get('/api/designs/ai-info'); } catch (e) { /* */ }
    const st = { kind: 'image', prompt: '' };
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const ta = h('textarea', { class: 'input dz-aita', rows: 4, placeholder: 'Es. "Un tramonto sul mare in stile fotografico, colori caldi"' });
    ta.addEventListener('input', () => { st.prompt = ta.value; });
    ta.addEventListener('keydown', (e) => e.stopPropagation());
    const kinds = h('div', { class: 'dz-fmts two' });
    const paintK = () => rc(kinds, ...[['image', 'Immagine', 'A tutta tela, nelle proporzioni della grafica'], ['sticker', 'Elemento', 'Oggetto o icona con lo sfondo trasparente']].map(([k, n, d]) =>
      h('button', { class: 'dz-fmt' + (st.kind === k ? ' on' : ''), onclick: () => { st.kind = k; paintK(); } }, h('b', null, n), h('small', null, d))));
    paintK();
    const r = doc.w / doc.h, ratio = r > 1.3 ? '16:9' : r < 0.77 ? '9:16' : '1:1';
    const go = h('button', { class: 'btn primary', disabled: info.ready ? null : true, onclick: async () => {
      if (!st.prompt.trim()) { ta.focus(); return; }
      close(); setBusy('L\'AI crea l\'immagine…', 0.05);
      try {
        const j = await post(`/api/d/${gid}/ai`, { prompt: st.prompt, kind: st.kind, ratio });
        const res = await pollJob(j.id, (x) => setBusy(x.message || 'L\'AI crea l\'immagine…', x.progress));
        if (res.status !== 'done') throw new Error(res.error || 'Non riuscito');
        const f = res.result;
        const l = imageLayer(f.file, f.w, f.h, doc, st.prompt.slice(0, 40));
        if (st.kind === 'image') { const k = Math.max(doc.w / f.w, doc.h / f.h); l.w = f.w * k; l.h = f.h * k; l.x = (doc.w - l.w) / 2; l.y = (doc.h - l.h) / 2; }
        if (st.kind === 'image' && !one()) { layers().unshift(l); S.sel = [l.id]; commit(); } else addLayer(l);
        toast('Immagine creata');
      } catch (er) { toast(er.message, true); }
      setBusy(null);
    } }, icon('sparkle', 14, '#fff', 2), 'Crea');
    bg.append(h('div', { class: 'modal dz-aimodal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Crea con l\'AI' },
      h('div', { class: 'dz-aih' }, h('span', { class: 'dz-aiic' }, icon('sparkle', 14, '#fff', 2)), h('div', null, h('b', null, 'Crea un\'immagine con l\'AI'), h('small', null, 'Descrivila: arriva come livello nuovo, la modifichi come le altre'))),
      ta, kinds,
      info.ready ? h('p', { class: 'dz-note' }, 'Costo circa $' + (+info.usd || 0.08).toFixed(2) + ' a immagine, con la tua chiave AI.')
        : h('p', { class: 'dz-note warn' }, info.error || 'Serve una chiave AI per le immagini: aggiungila in Storie AI → Chiavi AI.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
    setTimeout(() => ta.focus(), 30);
  }
  function setBusy(msg, p) {
    S.busy = msg;
    if (!msg) { busyEl.style.display = 'none'; return; }
    busyEl.style.display = '';
    rc(busyEl, h('div', { class: 'spinner' }), h('span', null, msg + (p ? ' · ' + Math.round(p * 100) + '%' : '')));
  }

  // ------------------------------------------------------------ strumenti
  function setTool(t, quiet) {
    if (S.editing && t !== 'move') stopEdit(true);
    if (S.crop && t !== 'crop') { S.crop = null; }
    S.tool = t;
    if (t === 'crop') startCropMode();
    stage.style.cursor = t === 'hand' ? 'grab' : '';
    paintTools(); paintOpts(); draw();
    void quiet;
  }
  function paintTools() {
    rc(toolsBar, 
      ...TOOLS.map(([id, ic, tip, key]) => h('button', { class: 'dz-tool' + (S.tool === id ? ' on' : ''), 'aria-label': tip, 'data-tip': tip + ' (' + key + ')', onclick: () => setTool(id) },
        icon(id === 'shape' ? (SHAPES.find((s) => s[0] === S.shape) || SHAPES[0])[1] : ic, 18, 'currentColor', 1.8))),
      h('div', { class: 'dz-tsep' }),
      h('button', { class: 'dz-tool', 'aria-label': 'Aggiungi immagini', 'data-tip': 'Aggiungi immagini dal computer', onclick: pickImages }, icon('image', 18, 'currentColor', 1.8)),
      h('button', { class: 'dz-tool ai', 'aria-label': 'Crea con l\'AI', 'data-tip': 'Crea un\'immagine con l\'AI', onclick: aiDialog }, icon('sparkle', 18, 'currentColor', 1.8)),
      h('div', { class: 'grow' }),
      colorButton(S.color, (c) => setColor(c, true), { cls: 'dz-tcolor', tip: 'Colore (pennello, testo e forme)' }));
  }
  function paintOpts() {
    const t = S.tool;
    const kids = [];
    const lab = (s) => h('span', { class: 'dz-olab' }, s);
    const rng = (v, min, max, step, fn, w = 110) => { const i = h('input', { type: 'range', min, max, step, value: v, style: { width: w + 'px' } }); i.addEventListener('input', () => fn(+i.value)); return i; };
    if (t === 'brush' || t === 'eraser') {
      const sv = h('b', { class: 'dz-oval' }, S.brush.size + ' px');
      kids.push(lab('Dimensione'), rng(S.brush.size, 1, 400, 1, (v) => { S.brush.size = v; sv.textContent = v + ' px'; }), sv,
        lab('Durezza'), rng(Math.round(S.brush.hard * 100), 0, 100, 1, (v) => { S.brush.hard = v / 100; }, 90),
        lab('Opacità'), rng(Math.round(S.brush.opacity * 100), 1, 100, 1, (v) => { S.brush.opacity = v / 100; }, 90));
      const l = one();
      if (l && l.mask) kids.push(h('span', { class: 'dz-osep' }), h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.maskEdit ? true : null, onchange: (e) => { S.maskEdit = e.target.checked; refresh(); } }), 'Dipingi sulla maschera'));
      kids.push(h('span', { class: 'dz-ohint' }, t === 'eraser' ? (l && l.type !== 'paint' ? 'Sui livelli non di pittura la gomma usa la maschera: niente si perde' : '') : 'Tieni premuto Alt per il contagocce · [ ] cambia la dimensione'));
    } else if (t === 'shape') {
      kids.push(...SHAPES.map(([k, ic, n]) => h('button', { class: 'dz-ochip' + (S.shape === k ? ' on' : ''), 'data-tip': n, 'aria-label': n, onclick: () => { S.shape = k; paintOpts(); paintTools(); } }, icon(ic, 15, 'currentColor', 1.9))),
        h('span', { class: 'dz-ohint' }, 'Trascina sulla tela · Shift: proporzioni fisse · Alt: dal centro'));
    } else if (t === 'text') {
      kids.push(h('span', { class: 'dz-ohint' }, 'Clic sulla tela per scrivere · doppio clic su un testo per modificarlo'));
    } else if (t === 'crop') {
      const ratios = [[0, 'Libero'], [1, '1:1'], [4 / 5, '4:5'], [9 / 16, '9:16'], [16 / 9, '16:9']];
      kids.push(...ratios.map(([r, n]) => h('button', { class: 'dz-ochip txt' + ((S.crop && S.crop.ratio) === r ? ' on' : ''), onclick: () => {
        if (!S.crop) startCropMode(); S.crop.ratio = r;
        if (r) { const c = S.crop; let w = c.w, hh = w / r; if (hh > doc.h) { hh = doc.h; w = hh * r; } c.w = w; c.h = hh; c.x = (doc.w - w) / 2; c.y = (doc.h - hh) / 2; }
        draw(); paintOpts();
      } }, n)),
      h('span', { class: 'grow' }),
      h('button', { class: 'btn sm ghost', onclick: () => setTool('move') }, 'Annulla'),
      h('button', { class: 'btn sm primary', onclick: applyCrop }, icon('check', 13, '#fff', 2.4), 'Applica'));
    } else if (t === 'eyedrop') {
      kids.push(h('span', { class: 'dz-ohint' }, 'Clic sulla tela per prendere un colore: va al testo o alla forma scelti'));
    } else if (t === 'hand') {
      kids.push(h('span', { class: 'dz-ohint' }, 'Trascina per spostare la vista · rotellina + ' + MOD.replace('+', '') + ' per lo zoom'));
    } else {
      kids.push(h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.snap ? true : null, onchange: (e) => { S.snap = e.target.checked; } }), 'Allineamento magnetico'),
        h('span', { class: 'dz-osep' }),
        ...[['alignL', 'l', 'Allinea a sinistra'], ['alignCH', 'ch', 'Centra in orizzontale'], ['alignR', 'r', 'Allinea a destra'], ['alignT', 't', 'Allinea in alto'], ['alignCV', 'cv', 'Centra in verticale'], ['alignB', 'b', 'Allinea in basso']]
          .map(([ic, k, n]) => h('button', { class: 'dz-ochip', 'data-tip': n + (S.sel.length > 1 ? '' : ' (alla tela)'), 'aria-label': n, disabled: S.sel.length ? null : true, onclick: () => align(k) }, icon(ic, 15, 'currentColor', 1.8))),
        h('span', { class: 'dz-ohint' }, S.sel.length ? 'Alt + trascina: duplica · Shift: blocca la direzione' : 'Clic su un livello per sceglierlo · ' + MOD + 'clic: dentro i gruppi'));
    }
    rc(opts, ...kids);
  }

  // ------------------------------------------------------------ pannello proprieta'
  let refreshT = 0;
  function refresh(full) { clearTimeout(refreshT); refreshT = setTimeout(() => { if (!alive) return; paintProps(); paintLayers(); paintPages(); paintOpts(); undoB.disabled = hist.idx <= 0; redoB.disabled = hist.idx >= hist.stack.length - 1; }, full ? 0 : 16); }
  const sec = (title, kids, opt = {}) => {
    const key = 'nf.dz.sec.' + title;
    let open = opt.open != null ? opt.open : (() => { try { return localStorage.getItem(key) !== '0'; } catch (e) { return true; } })();
    const body = h('div', { class: 'dz-secb' }, ...kids);
    const el = h('section', { class: 'dz-sec' + (open ? ' open' : '') },
      h('button', { class: 'dz-sech', onclick: () => { open = !open; el.classList.toggle('open', open); try { localStorage.setItem(key, open ? '1' : '0'); } catch (e) { /* */ } } },
        icon('chev', 12, 'currentColor', 2.2), h('span', null, title), opt.right || null), body);
    return el;
  };
  // campo numerico: si scrive, si usano le frecce, o si trascina l'etichetta
  function num(label, val, set, o = {}) {
    const inp = h('input', { class: 'dz-num', value: fmtN(val, o.dec), inputmode: 'decimal', 'aria-label': o.aria || label });
    const done = (v, key) => { if (!isFinite(v)) return; if (o.min != null) v = Math.max(o.min, v); if (o.max != null) v = Math.min(o.max, v); set(v); inp.value = fmtN(v, o.dec) ; commit(key); };
    inp.addEventListener('change', () => done(parseFloat(inp.value.replace(',', '.'))));
    inp.addEventListener('keydown', (e) => { if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); const v = parseFloat(inp.value.replace(',', '.')) || 0; done(v + (e.key === 'ArrowUp' ? 1 : -1) * (e.shiftKey ? 10 : o.step || 1), 'num' + label); } else if (e.key === 'Enter') inp.blur(); });
    const lab = h('label', { class: 'dz-nlab' }, label);
    lab.addEventListener('pointerdown', (e) => {
      e.preventDefault(); const x0 = e.clientX, v0 = parseFloat(inp.value.replace(',', '.')) || 0; lab.setPointerCapture(e.pointerId);
      const mv = (ev) => { const v = v0 + Math.round((ev.clientX - x0) / 2) * (o.step || 1) * (ev.shiftKey ? 10 : 1); done(v, 'drag' + label); };
      const up = () => { lab.removeEventListener('pointermove', mv); lab.removeEventListener('pointerup', up); };
      lab.addEventListener('pointermove', mv); lab.addEventListener('pointerup', up);
    });
    return h('div', { class: 'dz-field' + (o.wide ? ' wide' : '') }, lab, inp, o.unit ? h('span', { class: 'dz-unit' }, o.unit) : null);
  }
  const fmtN = (v, dec = 0) => (v == null || !isFinite(v) ? '' : String(+(+v).toFixed(dec)));
  function slider(label, val, min, max, step, set, unit = '', key) {
    const out = h('b', null, fmtN(val, step < 1 ? 2 : 0) + unit);
    const i = h('input', { type: 'range', min, max, step, value: val });
    i.addEventListener('input', () => { set(+i.value); out.textContent = fmtN(+i.value, step < 1 ? 2 : 0) + unit; draw(); commit(key || 'sl' + label); });
    i.addEventListener('dblclick', () => { const d = min < 0 ? 0 : min; i.value = d; set(d); out.textContent = fmtN(d) + unit; commit(); });
    return h('div', { class: 'dz-slider' }, h('span', null, label), i, out);
  }
  const row = (...k) => h('div', { class: 'dz-row' }, ...k);
  const chipBtn = (ic, tip, on, fn) => h('button', { class: 'dz-ochip' + (on ? ' on' : ''), 'aria-label': tip, 'data-tip': tip, onclick: fn }, typeof ic === 'string' && ic.length > 2 ? icon(ic, 15, 'currentColor', 1.9) : h('b', null, ic));
  function selectEl(items, cur, fn) {
    const s = h('select', { class: 'dz-select' }, ...items.map(([v, n]) => h('option', { value: v, selected: v === cur ? true : null }, n)));
    s.addEventListener('change', () => fn(s.value));
    return s;
  }

  function paintProps() {
    const ls = selLayers();
    const l = ls.length === 1 ? ls[0] : null;
    const kids = [];
    if (!ls.length) {
      const p = page();
      kids.push(h('div', { class: 'dz-phead' }, h('span', { class: 'dz-pic' }, icon('frame', 14, 'currentColor', 2)), h('div', null, h('b', null, 'Tela'), h('small', null, doc.w + ' × ' + doc.h + ' px'))));
      kids.push(sec('Dimensioni', [
        row(num(LANG === 'en' ? 'W' : 'L', doc.w, (v) => { resizeCanvas(v, doc.h, false); }, { min: 1, max: 16000, unit: 'px' }), num(LANG === 'en' ? 'H' : 'A', doc.h, (v) => { resizeCanvas(doc.w, v, false); }, { min: 1, max: 16000, unit: 'px' })),
        h('div', { class: 'dz-btnrow' },
          h('button', { class: 'btn sm', onclick: () => resizeDialog() }, 'Ridimensiona…'),
          h('button', { class: 'btn sm', onclick: () => setTool('crop') }, icon('crop', 13), 'Ritaglia')),
      ]));
      kids.push(sec('Sfondo della pagina', [
        row(colorButton(p.bg || '#FFFFFF', (c) => { p.bg = c; commit('bg'); }, { gradient: true, label: p.bg ? null : 'Trasparente' }),
          h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: p.bg ? null : true, onchange: (e) => { p.bg = e.target.checked ? null : '#FFFFFF'; commit(); } }), 'Trasparente')),
      ]));
      kids.push(h('div', { class: 'dz-empty' }, icon('cursor', 18, 'currentColor', 1.6), h('span', null, 'Scegli un livello sulla tela o nella lista per modificarlo')));
      rc(props, ...kids);
      return;
    }
    if (!l) {
      kids.push(h('div', { class: 'dz-phead' }, h('span', { class: 'dz-pic' }, icon('layers', 14, 'currentColor', 2)), h('div', null, h('b', null, ls.length + ' livelli'), h('small', null, 'Selezione multipla'))));
      kids.push(sec('Allinea', [h('div', { class: 'dz-btnrow' },
        ...[['alignL', 'l'], ['alignCH', 'ch'], ['alignR', 'r'], ['alignT', 't'], ['alignCV', 'cv'], ['alignB', 'b']].map(([ic, k]) => chipBtn(ic, 'Allinea', false, () => align(k))))]));
      kids.push(sec('Opacità', [slider('Opacità', Math.round(ls[0].opacity * 100), 0, 100, 1, (v) => ls.forEach((x) => { x.opacity = v / 100; }), '%')]));
      kids.push(h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: groupSel }, icon('group', 13), 'Raggruppa'), h('button', { class: 'btn sm', onclick: () => duplicateSel() }, icon('duplicate', 13), 'Duplica'), h('button', { class: 'btn sm danger', onclick: deleteSel }, icon('trash', 13), 'Elimina')));
      rc(props, ...kids);
      return;
    }
    const TYPE = { text: ['type', 'Testo'], shape: ['square', 'Forma'], image: ['image', 'Immagine'], paint: ['brush', 'Pittura'], group: ['group', 'Gruppo'], adjust: ['adjust', 'Regolazione'] }[l.type];
    const nameIn = h('input', { class: 'dz-pname', value: l.name || TYPE[1], 'aria-label': 'Nome del livello', 'data-notr': '' });
    nameIn.addEventListener('change', () => { l.name = nameIn.value.trim() || TYPE[1]; commit(); });
    nameIn.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') nameIn.blur(); });
    kids.push(h('div', { class: 'dz-phead' }, h('span', { class: 'dz-pic' }, icon(TYPE[0], 14, 'currentColor', 2)), h('div', null, nameIn, h('small', null, TYPE[1] + (l.locked ? ' · bloccato' : ''))),
      ib(l.locked ? 'lock' : 'unlock', l.locked ? 'Sblocca' : 'Blocca', () => { l.locked = !l.locked; commit(); })));
    // posizione e misure
    if (l.type !== 'adjust') {
      const tr = [];
      if (l.type === 'group') {
        const b = bounds(l);
        tr.push(row(num('X', b.x, (v) => moveBy(l, v - b.x, 0)), num('Y', b.y, (v) => moveBy(l, 0, v - b.y))));
      } else {
        let ratio = l.w / l.h;
        tr.push(row(num('X', l.x, (v) => { l.x = v; }), num('Y', l.y, (v) => { l.y = v; })),
          row(num(LANG === 'en' ? 'W' : 'L', l.w, (v) => { if (l.type === 'text') { l.w = v; l.auto = false; l.h = textHeight(l); } else { const lock = l.type === 'image'; l.w = v; if (lock) l.h = v / ratio; } }, { min: 1 }),
            l.type === 'text' ? h('div', { class: 'dz-field ro' }, h('label', { class: 'dz-nlab' }, LANG === 'en' ? 'H' : 'A'), h('span', { class: 'dz-num ro' }, fmtN(l.h))) : num(LANG === 'en' ? 'H' : 'A', l.h, (v) => { const lock = l.type === 'image'; l.h = v; if (lock) l.w = v * ratio; }, { min: 1 })),
          row(num('Rotazione', l.rot || 0, (v) => { l.rot = ((v % 360) + 540) % 360 - 180; }, { unit: '°', dec: 1, wide: true }),
            h('div', { class: 'dz-btnrow tight' }, chipBtn('flipH', 'Rifletti in orizzontale', l.flipX, () => { l.flipX = !l.flipX; commit(); }), chipBtn('flipV', 'Rifletti in verticale', l.flipY, () => { l.flipY = !l.flipY; commit(); }))));
      }
      tr.push(h('div', { class: 'dz-btnrow' }, ...[['alignL', 'l'], ['alignCH', 'ch'], ['alignR', 'r'], ['alignT', 't'], ['alignCV', 'cv'], ['alignB', 'b']].map(([ic, k]) => chipBtn(ic, 'Allinea alla tela', false, () => align(k)))));
      kids.push(sec('Posizione', tr));
    }
    kids.push(sec('Livello', [slider('Opacità', Math.round((l.opacity == null ? 1 : l.opacity) * 100), 0, 100, 1, (v) => { l.opacity = v / 100; }, '%'),
      row(h('span', { class: 'dz-flab' }, 'Fusione'), selectEl(BLENDS, l.blend || 'normal', (v) => { l.blend = v; commit(); }))]));
    // per tipo
    if (l.type === 'text') kids.push(textProps(l));
    if (l.type === 'shape') kids.push(shapeProps(l));
    if (l.type === 'image') kids.push(imageProps(l));
    if (l.type === 'adjust') kids.push(adjustProps(l));
    if (l.type === 'group') kids.push(sec('Gruppo', [h('p', { class: 'dz-note' }, (l.children || []).length + ' livelli dentro'), h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm', onclick: ungroup }, 'Separa il gruppo'))]));
    if (l.type === 'paint') kids.push(sec('Pittura', [h('p', { class: 'dz-note' }, 'Dipingi con il pennello (B), cancella con la gomma (E).')]));
    if (l.type !== 'group' && l.type !== 'adjust') { kids.push(filterProps(l)); kids.push(fxProps(l)); kids.push(maskProps(l)); }
    rc(props, ...kids);
  }

  function textProps(l) {
    const ta = h('textarea', { class: 'dz-ta', rows: 2, 'data-notr': '' }); ta.value = l.text || '';
    ta.addEventListener('input', () => { l.text = ta.value; if (l.auto) { const cx = l.x + l.w / 2; l.w = Math.max(20, textNaturalWidth(l)); l.x = cx - l.w / 2; } l.h = textHeight(l); l.name = l.text.split('\n')[0].slice(0, 40) || 'Testo'; draw(); commit('text'); });
    ta.addEventListener('keydown', (e) => e.stopPropagation());
    const refit = () => { if (l.auto) { const cx = l.x + l.w / 2; l.w = Math.max(20, textNaturalWidth(l)); l.x = cx - l.w / 2; } l.h = textHeight(l); };
    const fp = fontPicker(l.font, (f) => { l.font = f; ensureFont(f).then(() => { dropCache(l.id); refit(); commit(); }); });
    const W = [[300, 'Leggero'], [400, 'Normale'], [500, 'Medio'], [600, 'Semi'], [700, 'Grassetto'], [800, 'Extra'], [900, 'Nero']];
    return sec('Testo', [ta, fp,
      row(num('Dim.', l.size, (v) => { l.size = v; refit(); }, { min: 4, max: 2000, unit: 'px' }), selectEl(W.map(([v, n]) => [String(v), n]), String(l.weight || 400), (v) => { l.weight = +v; refit(); commit(); })),
      h('div', { class: 'dz-btnrow' },
        chipBtn('tAlignL', 'A sinistra', l.align === 'left', () => { l.align = 'left'; commit(); }),
        chipBtn('tAlignC', 'Al centro', !l.align || l.align === 'center', () => { l.align = 'center'; commit(); }),
        chipBtn('tAlignR', 'A destra', l.align === 'right', () => { l.align = 'right'; commit(); }),
        h('span', { class: 'dz-vsep' }),
        chipBtn('italic', 'Corsivo', l.italic, () => { l.italic = !l.italic; refit(); commit(); }),
        chipBtn('AA', 'Tutto maiuscolo', l.upper, () => { l.upper = !l.upper; refit(); commit(); })),
      row(num('Interl.', l.lineH || 1.2, (v) => { l.lineH = v; refit(); }, { step: 0.05, dec: 2, min: 0.5, max: 4 }), num('Spazio', l.letter || 0, (v) => { l.letter = v; refit(); }, { min: -50, max: 200, unit: 'px' })),
      row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(l.fill || l.color, (c) => { if (typeof c === 'string') { l.color = c; delete l.fill; } else l.fill = c; commit('tcolor'); }, { gradient: true })),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: l.auto ? true : null, onchange: (e) => { l.auto = e.target.checked; refit(); commit(); } }), 'Larghezza automatica'),
    ]);
  }
  function shapeProps(l) {
    return sec('Forma', [
      h('div', { class: 'dz-btnrow' }, ...SHAPES.map(([k, ic, n]) => chipBtn(ic, n, l.kind === k, () => { l.kind = k; l.name = n; commit(); }))),
      row(h('span', { class: 'dz-flab' }, l.kind === 'line' ? 'Colore' : 'Riempimento'), colorButton(l.fill || '', (c) => { l.fill = c; commit('fill'); }, { gradient: l.kind !== 'line', none: l.kind !== 'line' })),
      l.kind !== 'line' ? row(h('span', { class: 'dz-flab' }, 'Bordo'), colorButton(l.stroke || '', (c) => { l.stroke = c; if (c && !l.strokeW) l.strokeW = Math.max(2, Math.round(Math.min(l.w, l.h) / 40)); commit('stroke'); }, { none: true }), num('Spess.', l.strokeW || 0, (v) => { l.strokeW = v; }, { min: 0, max: 500, unit: 'px' })) : null,
      l.kind === 'rect' ? slider('Angoli', l.radius || 0, 0, Math.round(Math.min(l.w, l.h) / 2), 1, (v) => { l.radius = v; }, ' px') : null,
      l.kind === 'poly' || l.kind === 'star' ? slider(l.kind === 'star' ? 'Punte' : 'Lati', l.sides || (l.kind === 'star' ? 5 : 6), 3, 16, 1, (v) => { l.sides = v; }) : null,
      l.kind === 'star' ? slider('Interno', Math.round((l.inner || 0.45) * 100), 10, 95, 1, (v) => { l.inner = v / 100; }, '%') : null,
    ]);
  }
  function imageProps(l) {
    const a = assets.get(l.src);
    return sec('Immagine', [
      h('div', { class: 'dz-aibox' },
        h('div', { class: 'dz-aih' }, h('span', { class: 'dz-aiic' }, icon('cutout', 14, '#fff', 2)), h('div', null, h('b', null, 'Rimuovi sfondo'), h('small', null, 'Con l\'AI, sul tuo computer · gratis'))),
        h('div', { class: 'dz-btnrow' },
          h('button', { class: 'btn sm primary', disabled: S.busy ? true : null, onclick: () => removeBg(l, 'oggetto') }, icon('sparkle', 13, '#fff', 2), 'Oggetto o prodotto'),
          h('button', { class: 'btn sm', disabled: S.busy ? true : null, onclick: () => removeBg(l, 'persona') }, icon('user', 13), 'Persona'))),
      h('div', { class: 'dz-btnrow' },
        h('button', { class: 'btn sm', onclick: () => { if (!a) return; const cx = l.x + l.w / 2, cy = l.y + l.h / 2; l.w = a.w; l.h = a.h; l.x = cx - a.w / 2; l.y = cy - a.h / 2; commit(); } }, 'Dimensione originale'),
        h('button', { class: 'btn sm', onclick: () => { const k = Math.max(doc.w / l.w, doc.h / l.h); l.w *= k; l.h *= k; l.rot = 0; l.x = (doc.w - l.w) / 2; l.y = (doc.h - l.h) / 2; commit(); } }, 'Riempi la tela'),
        h('button', { class: 'btn sm', onclick: () => { const k = Math.min(doc.w / l.w, doc.h / l.h); l.w *= k; l.h *= k; l.rot = 0; l.x = (doc.w - l.w) / 2; l.y = (doc.h - l.h) / 2; commit(); } }, 'Adatta')),
      a ? h('p', { class: 'dz-note' }, 'Originale ' + a.w + ' × ' + a.h + ' px') : null,
    ]);
  }
  function adjustProps(l) {
    const p = l.p || (l.p = {});
    const kids = [row(h('span', { class: 'dz-flab' }, 'Tipo'), selectEl(ADJUST_KINDS, l.kind, (v) => { const n = adjustLayer(v); l.kind = v; l.p = n.p; l.name = n.name; commit(); }))];
    if (l.kind === 'bc') kids.push(slider('Luminosità', p.brightness || 0, -100, 100, 1, (v) => { p.brightness = v; }), slider('Contrasto', p.contrast || 0, -100, 100, 1, (v) => { p.contrast = v; }));
    if (l.kind === 'hsl') kids.push(slider('Tonalità', p.hue || 0, -180, 180, 1, (v) => { p.hue = v; }, '°'), slider('Saturazione', p.saturation || 0, -100, 100, 1, (v) => { p.saturation = v; }), slider('Luminosità', p.lightness || 0, -100, 100, 1, (v) => { p.lightness = v; }));
    if (l.kind === 'bw') kids.push(slider('Intensità', p.amount == null ? 100 : p.amount, 0, 100, 1, (v) => { p.amount = v; }, '%'));
    if (l.kind === 'warm') kids.push(slider('Temperatura', p.amount || 0, -100, 100, 1, (v) => { p.amount = v; }));
    if (l.kind === 'blur') kids.push(slider('Sfocatura', p.amount || 0, 0, 60, 0.5, (v) => { p.amount = v; }, ' px'));
    kids.push(h('p', { class: 'dz-note' }, 'Cambia tutti i livelli che stanno sotto. I livelli restano intatti: la togli quando vuoi.'));
    return sec('Regolazione', kids);
  }
  function filterProps(l) {
    const f = l.filters || {};
    const set = (k) => (v) => { l.filters = { ...FILTER_DEFAULT, ...(l.filters || {}), [k]: v }; };
    const any = Object.values(f).some((v) => v);
    return sec('Filtri', [
      slider('Luminosità', f.brightness || 0, -100, 100, 1, set('brightness')),
      slider('Contrasto', f.contrast || 0, -100, 100, 1, set('contrast')),
      slider('Saturazione', f.saturation || 0, -100, 100, 1, set('saturation')),
      slider('Tonalità', f.hue || 0, -180, 180, 1, set('hue'), '°'),
      slider('Sfocatura', f.blur || 0, 0, 50, 0.5, set('blur'), ' px'),
      slider('Bianco e nero', f.grayscale || 0, 0, 100, 1, set('grayscale'), '%'),
      any ? h('button', { class: 'btn sm ghost', onclick: () => { delete l.filters; commit(); } }, 'Togli i filtri') : null,
    ], { open: any ? true : undefined, right: any ? h('i', { class: 'dz-dot' }) : null });
  }
  function fxProps(l) {
    const fx = l.fx || {};
    const get2 = (k) => ({ ...FX_DEFAULT[k], ...(fx[k] || {}) });
    const setFx = (k, patch) => { l.fx = { ...(l.fx || {}), [k]: { ...get2(k), ...patch } }; };
    const block = (k, title, body) => {
      const on = !!(fx[k] && fx[k].on);
      return h('div', { class: 'dz-fx' + (on ? ' on' : '') },
        h('div', { class: 'dz-fxh' }, h('b', null, title), h('div', { class: 'grow' }),
          h('button', { class: 'toggle', 'aria-pressed': on ? 'true' : 'false', 'aria-label': title, onclick: () => { setFx(k, { on: !on }); commit(); } })),
        on ? h('div', { class: 'dz-fxb' }, ...body(get2(k))) : null);
    };
    const anyOn = ['shadow', 'stroke', 'glow'].some((k) => fx[k] && fx[k].on);
    return sec('Effetti', [
      block('shadow', 'Ombra', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { setFx('shadow', { color: c }); commit('shc'); })),
        slider('Opacità', Math.round(s.opacity * 100), 0, 100, 1, (v) => setFx('shadow', { opacity: v / 100 }), '%'),
        slider('Sfumatura', s.blur, 0, 200, 1, (v) => setFx('shadow', { blur: v }), ' px'),
        slider('Distanza X', s.x, -200, 200, 1, (v) => setFx('shadow', { x: v }), ' px'),
        slider('Distanza Y', s.y, -200, 200, 1, (v) => setFx('shadow', { y: v }), ' px')]),
      block('stroke', 'Contorno', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { setFx('stroke', { color: c }); commit('stc'); })),
        slider('Spessore', s.width, 1, 100, 1, (v) => setFx('stroke', { width: v }), ' px')]),
      block('glow', 'Bagliore', (s) => [row(h('span', { class: 'dz-flab' }, 'Colore'), colorButton(s.color, (c) => { setFx('glow', { color: c }); commit('glc'); })),
        slider('Intensità', Math.round(s.opacity * 100), 0, 100, 1, (v) => setFx('glow', { opacity: v / 100 }), '%'),
        slider('Ampiezza', s.blur, 1, 200, 1, (v) => setFx('glow', { blur: v }), ' px')]),
    ], { open: anyOn ? true : undefined, right: anyOn ? h('i', { class: 'dz-dot' }) : null });
  }
  function maskProps(l) {
    if (!l.mask) return sec('Maschera', [h('p', { class: 'dz-note' }, 'Nasconde parti del livello senza cancellarle: la gomma nasconde, il pennello fa riapparire.'),
      h('button', { class: 'btn sm', onclick: toggleMask }, icon('mask', 13), 'Aggiungi maschera')], { open: false });
    return sec('Maschera', [
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: S.maskEdit ? true : null, onchange: (e) => { S.maskEdit = e.target.checked; if (S.maskEdit && S.tool !== 'brush' && S.tool !== 'eraser') setTool('eraser'); refresh(); } }), 'Modifica la maschera con pennello e gomma'),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: l.mask.on !== false ? true : null, onchange: (e) => { l.mask.on = e.target.checked; commit(); } }), 'Maschera attiva'),
      h('div', { class: 'dz-btnrow' }, h('button', { class: 'btn sm ghost', onclick: toggleMask }, 'Togli la maschera')),
    ], { open: true, right: h('i', { class: 'dz-dot' }) });
  }

  // ------------------------------------------------------------ lista dei livelli
  let dragRow = null, layersT = 0;
  function paintLayersSoon() { clearTimeout(layersT); layersT = setTimeout(() => alive && paintLayers(), 200); }
  let pagesT = 0;
  function pagesSoon() { clearTimeout(pagesT); pagesT = setTimeout(() => alive && paintPages(), 300); }
  const thumbStore = new Map(), pageStore = new Map();
  function thumb(l) {
    const c = h('canvas', { class: 'dz-lthumb', width: 36, height: 36 });
    const g = c.getContext('2d');
    if (l.type === 'adjust') { return h('span', { class: 'dz-lthumb ic' }, icon('adjust', 15, 'currentColor', 1.8)); }
    if (l.type === 'group') { return h('span', { class: 'dz-lthumb ic' }, icon('group', 15, 'currentColor', 1.8)); }
    try {
      const bm = layerBitmap(l, Math.min(36 / Math.max(1, l.w), 36 / Math.max(1, l.h)) * 2, assets, thumbStore);
      const w = bm.cv.width - bm.pad * 2, hh = bm.cv.height - bm.pad * 2, k = Math.min(32 / w, 32 / hh);
      g.drawImage(bm.cv, bm.pad, bm.pad, w, hh, 18 - w * k / 2, 18 - hh * k / 2, w * k, hh * k);
    } catch (e) { /* */ }
    return c;
  }
  function paintLayers() {
    const rows = [];
    const rowFor = (l, depth, parent) => {
      const on = S.sel.includes(l.id);
      const eye = h('button', { class: 'dz-leye' + (l.visible ? '' : ' off'), 'aria-label': l.visible ? 'Nascondi' : 'Mostra', onclick: (e) => { e.stopPropagation(); l.visible = !l.visible; commit(); } }, icon(l.visible ? 'eye' : 'eyeOff', 14, 'currentColor', 1.9));
      const nm = h('span', { class: 'dz-lname', 'data-notr': '' }, l.name || ({ text: 'Testo', shape: 'Forma', image: 'Immagine', paint: 'Pittura', group: 'Gruppo', adjust: 'Regolazione' })[l.type]);
      nm.addEventListener('dblclick', async (e) => { e.stopPropagation(); const v = await promptBox('Rinomina il livello', null, l.name, 'Rinomina'); if (v) { l.name = v; commit(); } });
      const r = h('div', { class: 'dz-lrow' + (on ? ' on' : '') + (l.visible ? '' : ' hidden') + (parent ? ' child' : ''), draggable: 'true', style: { paddingLeft: 6 + depth * 16 + 'px' } },
        l.type === 'group' ? h('button', { class: 'dz-lfold' + (l.open !== false ? ' open' : ''), onclick: (e) => { e.stopPropagation(); l.open = l.open === false; paintLayers(); } }, icon('chev', 11, 'currentColor', 2.4)) : h('span', { class: 'dz-lfold sp' }),
        eye, thumb(l), nm,
        l.mask ? h('span', { class: 'dz-lbadge', 'data-tip': 'Maschera' }, icon('mask', 11, 'currentColor', 2)) : null,
        l.fx && Object.values(l.fx).some((x) => x && x.on) ? h('span', { class: 'dz-lbadge', 'data-tip': 'Effetti' }, 'fx') : null,
        l.blend && l.blend !== 'normal' ? h('span', { class: 'dz-lbadge', 'data-tip': 'Fusione' }, '◐') : null,
        l.locked ? h('span', { class: 'dz-lbadge' }, icon('lock', 11, 'currentColor', 2)) : null);
      r.addEventListener('click', (e) => { if (e.shiftKey || e.ctrlKey || e.metaKey) select([l.id], true); else select([l.id]); });
      r.addEventListener('contextmenu', (e) => { e.preventDefault(); if (!S.sel.includes(l.id)) select([l.id]); layerMenu(r); });
      r.addEventListener('dragstart', (e) => { dragRow = l.id; e.dataTransfer.effectAllowed = 'move'; r.classList.add('drag'); });
      r.addEventListener('dragend', () => { dragRow = null; r.classList.remove('drag'); layerList.querySelectorAll('.dz-lrow').forEach((x) => x.classList.remove('dt', 'db', 'di')); });
      r.addEventListener('dragover', (e) => {
        if (!dragRow || dragRow === l.id) return; e.preventDefault();
        const rr = r.getBoundingClientRect(), y = (e.clientY - rr.top) / rr.height;
        r.classList.toggle('dt', y < 0.33 || (l.type !== 'group' && y < 0.5)); r.classList.toggle('db', y > 0.66 || (l.type !== 'group' && y >= 0.5)); r.classList.toggle('di', l.type === 'group' && y >= 0.33 && y <= 0.66);
      });
      r.addEventListener('dragleave', () => r.classList.remove('dt', 'db', 'di'));
      r.addEventListener('drop', (e) => {
        e.preventDefault();
        const where = r.classList.contains('di') ? 'in' : r.classList.contains('dt') ? 'above' : 'below';
        r.classList.remove('dt', 'db', 'di');
        moveLayer(dragRow, l.id, where);
      });
      rows.push(r);
      if (l.type === 'group' && l.open !== false) for (let i = (l.children || []).length - 1; i >= 0; i--) rowFor(l.children[i], depth + 1, l);
    };
    const ls = layers();
    for (let i = ls.length - 1; i >= 0; i--) rowFor(ls[i], 0, null);
    const p = page();
    rows.push(h('div', { class: 'dz-lrow bgrow' + (S.sel.length ? '' : ' on'), onclick: () => select([]) },
      h('span', { class: 'dz-lfold sp' }), h('span', { class: 'dz-leye sp' }),
      h('span', { class: 'dz-lthumb sw', style: { background: p.bg ? (typeof p.bg === 'string' ? p.bg : '#888') : 'repeating-conic-gradient(#ddd 0 25%, #fff 0 50%) 0 0/10px 10px' } }),
      h('span', { class: 'dz-lname' }, 'Sfondo')));
    rc(layerList, ...rows);
  }
  function moveLayer(id, targetId, where) {
    if (id === targetId) return;
    const src = findLayer(layers(), id), tgt = findLayer(layers(), targetId);
    if (!src || !tgt) return;
    // non dentro se stesso
    let bad = false; if (src.layer.type === 'group') walk(src.layer.children || [], (c) => { if (c.id === targetId) bad = true; });
    if (bad) return;
    src.arr.splice(src.i, 1);
    const t2 = findLayer(layers(), targetId);
    if (where === 'in') { t2.layer.children = t2.layer.children || []; t2.layer.children.push(src.layer); t2.layer.open = true; }
    else t2.arr.splice(where === 'above' ? t2.i + 1 : t2.i, 0, src.layer);   // la lista e' al contrario: "sopra" = indice piu' alto
    commit();
  }
  function layerMenu(anchor) {
    const l = one();
    menu(anchor, [
      ['Duplica', () => duplicateSel()],
      ['Porta in primo piano', () => arrange(2)], ['Porta avanti', () => arrange(1)], ['Porta indietro', () => arrange(-1)], ['Porta in fondo', () => arrange(-2)],
      '-',
      ['Raggruppa', groupSel], l && l.type === 'group' ? ['Separa il gruppo', ungroup] : null,
      l && l.type !== 'group' && l.type !== 'adjust' ? [l.mask ? 'Togli la maschera' : 'Aggiungi maschera', toggleMask] : null,
      l ? [l.locked ? 'Sblocca' : 'Blocca', () => { l.locked = !l.locked; commit(); }] : null,
      l ? [l.visible ? 'Nascondi' : 'Mostra', () => { l.visible = !l.visible; commit(); }] : null,
      '-',
      ['Elimina', deleteSel],
    ]);
  }

  // ------------------------------------------------------------ pagine (caroselli, versioni)
  async function paintPages() {
    const els = doc.pages.map((p, i) => {
      const c = h('canvas', { class: 'dz-pgcv' });
      const b = h('button', { class: 'dz-pg' + (i === S.page ? ' on' : ''), 'aria-label': 'Pagina ' + (i + 1), onclick: () => { if (S.page !== i) { stopEdit(true); S.page = i; S.sel = []; draw(); refresh(); } } }, c, h('span', null, String(i + 1)));
      b.addEventListener('contextmenu', (e) => { e.preventDefault(); menu(b, [['Duplica la pagina', () => dupPage(i)], ['Sposta a sinistra', () => movePage(i, -1), i === 0], ['Sposta a destra', () => movePage(i, 1), i === doc.pages.length - 1], '-', ['Elimina la pagina', () => delPage(i), doc.pages.length < 2]]); });
      pageThumb(p, c);
      return b;
    });
    rc(pagesBar, h('span', { class: 'dz-pgl' }, icon('pages', 14, 'currentColor', 1.8), 'Pagine'), ...els,
      h('button', { class: 'dz-pg add', 'data-tip': 'Nuova pagina', 'aria-label': 'Nuova pagina', onclick: () => { doc.pages.splice(S.page + 1, 0, { id: uid('p'), name: tr('Pagina'), bg: page().bg, layers: [] }); S.page++; S.sel = []; commit(); } }, icon('plus', 16, 'currentColor', 2)),
      h('div', { class: 'grow' }),
      h('span', { class: 'dz-docsize' }, doc.w + ' × ' + doc.h + ' px'));
  }
  let thumbT = 0;
  function pageThumb(p, c) {
    const k = Math.min(64 / doc.w, 44 / doc.h);
    c.width = Math.max(1, Math.round(doc.w * k * 2)); c.height = Math.max(1, Math.round(doc.h * k * 2));
    c.style.width = c.width / 2 + 'px'; c.style.height = c.height / 2 + 'px';
    clearTimeout(thumbT);
    const g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
    try { renderPage(g, doc, p, { k: k * 2, ox: 0, oy: 0 }, assets, { store: pageStore }); } catch (e) { /* */ }
  }
  function dupPage(i) { const p = clone(doc.pages[i]); p.id = uid('p'); p.layers.forEach(reId); doc.pages.splice(i + 1, 0, p); S.page = i + 1; S.sel = []; commit(); }
  function movePage(i, d) { const [p] = doc.pages.splice(i, 1); doc.pages.splice(i + d, 0, p); S.page = i + d; commit(); }
  async function delPage(i) { if (doc.pages.length < 2) return; if (!(await confirmBox('Eliminare la pagina?', 'Puoi tornare indietro con Annulla.', 'Elimina', true))) return; doc.pages.splice(i, 1); S.page = Math.max(0, Math.min(S.page, doc.pages.length - 1)); S.sel = []; commit(); }

  // ------------------------------------------------------------ ridimensiona ed esporta
  function resizeDialog() {
    let w = doc.w, hh = doc.h, lock = true, scale = true;
    const ratio = doc.w / doc.h;
    const wi = h('input', { class: 'input', value: w, inputmode: 'numeric' }), hi = h('input', { class: 'input', value: hh, inputmode: 'numeric' });
    wi.addEventListener('input', () => { w = +wi.value || 1; if (lock) { hh = Math.round(w / ratio); hi.value = hh; } });
    hi.addEventListener('input', () => { hh = +hi.value || 1; if (lock) { w = Math.round(hh * ratio); wi.value = w; } });
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    bg.append(h('div', { class: 'modal', style: { width: 'min(420px, 94vw)' } }, h('h2', null, 'Ridimensiona la tela'),
      h('div', { class: 'row' }, h('label', { class: 'dz-mlab' }, 'Larghezza', wi), h('label', { class: 'dz-mlab' }, 'Altezza', hi)),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: true, onchange: (e) => { lock = e.target.checked; } }), 'Mantieni le proporzioni'),
      h('label', { class: 'dz-ochk' }, h('input', { type: 'checkbox', checked: true, onchange: (e) => { scale = e.target.checked; } }), 'Ridimensiona anche il contenuto'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'),
        h('button', { class: 'btn primary', onclick: () => { close(); resizeCanvas(w, hh, scale); } }, 'Applica'))));
    document.body.append(bg);
  }
  function exportDialog() {
    stopEdit(true);
    const st = { fmt: 'png', scale: 1, q: 92, pages: doc.pages.length > 1 ? 'all' : 'cur', busy: false };
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    const body = h('div', { class: 'dz-exp-b' });
    const paint = () => {
      const FM = [['png', 'PNG', 'Qualità piena, trasparenza'], ['jpg', 'JPG', 'Leggero, per i social'], ['webp', 'WebP', 'Leggerissimo, per il web'], ['pdf', 'PDF', 'Da stampare o inviare']];
      const pxW = Math.round(doc.w * st.scale), pxH = Math.round(doc.h * st.scale);
      rc(body, 
        h('label', { class: 'dz-mlab' }, 'Formato'),
        h('div', { class: 'dz-fmts' }, ...FM.map(([k, n, d]) => h('button', { class: 'dz-fmt' + (st.fmt === k ? ' on' : ''), onclick: () => { st.fmt = k; paint(); } }, h('b', null, n), h('small', null, d)))),
        h('label', { class: 'dz-mlab' }, 'Dimensione'),
        h('div', { class: 'dz-btnrow' }, ...[[0.5, '0,5×'], [1, '1×'], [2, '2×'], [3, '3×']].map(([k, n]) => h('button', { class: 'dz-ochip txt' + (st.scale === k ? ' on' : ''), onclick: () => { st.scale = k; paint(); } }, n)),
          h('span', { class: 'dz-note' }, pxW + ' × ' + pxH + ' px')),
        st.fmt === 'jpg' || st.fmt === 'webp' || st.fmt === 'pdf' ? slider('Qualità', st.q, 40, 100, 1, (v) => { st.q = v; }, '%', 'noop') : null,
        doc.pages.length > 1 ? h('div', null, h('label', { class: 'dz-mlab' }, 'Pagine'),
          h('div', { class: 'dz-btnrow' }, h('button', { class: 'dz-ochip txt' + (st.pages === 'all' ? ' on' : ''), onclick: () => { st.pages = 'all'; paint(); } }, 'Tutte (' + doc.pages.length + ')'),
            h('button', { class: 'dz-ochip txt' + (st.pages === 'cur' ? ' on' : ''), onclick: () => { st.pages = 'cur'; paint(); } }, 'Solo la pagina ' + (S.page + 1)))) : null,
        st.fmt === 'png' && doc.pages.some((p) => !p.bg) ? h('p', { class: 'dz-note' }, 'Lo sfondo trasparente resta trasparente.') : null,
        st.fmt !== 'png' && st.fmt !== 'webp' && doc.pages.some((p) => !p.bg) ? h('p', { class: 'dz-note' }, 'Il JPG e il PDF non hanno trasparenza: lo sfondo diventa bianco.') : null);
    };
    const go = h('button', { class: 'btn primary', onclick: async () => {
      if (st.busy) return; st.busy = true; go.disabled = true; go.textContent = 'Preparo…';
      try {
        await save();
        const list = st.pages === 'all' ? doc.pages : [page()];
        const parts = [], head = new DataView(new ArrayBuffer(4)); head.setUint32(0, list.length); parts.push(head.buffer);
        const mime = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', pdf: 'image/jpeg' }[st.fmt];
        for (const p of list) {
          const c = await pageCanvas(doc, p, st.scale, assets, { bg: mime === 'image/jpeg' ? '#FFFFFF' : null });
          const b = await new Promise((r) => c.toBlob(r, mime, st.q / 100));
          const buf = await b.arrayBuffer();
          const ln = new DataView(new ArrayBuffer(4)); ln.setUint32(0, buf.byteLength); parts.push(ln.buffer, buf);
        }
        const r = await fetch(`/api/d/${gid}/export?fmt=${st.fmt}&name=${encodeURIComponent(doc.name)}&token=${TOKEN}`, { method: 'PUT', body: new Blob(parts) });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error || 'Esportazione non riuscita');
        close();
        doneToast(j.paths);
      } catch (e) { toast(e.message, true); st.busy = false; go.disabled = false; go.textContent = 'Esporta'; }
    } }, 'Esporta');
    paint();
    bg.append(h('div', { class: 'modal dz-exp', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Esporta' },
      h('h2', null, 'Esporta la grafica'), body,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '6px' } }, h('button', { class: 'btn ghost', onclick: close }, 'Annulla'), go)));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }
  function doneToast(paths) {
    const el = h('div', { class: 'dz-done' }, icon('check', 15, '#34D399', 2.6),
      h('div', null, h('b', null, paths.length > 1 ? paths.length + ' immagini esportate' : 'Esportata'), h('small', { 'data-notr': '' }, paths[0].split(/[\\/]/).pop())),
      h('button', { class: 'btn sm', onclick: () => { post(`/api/d/${gid}/reveal`, { path: paths[0] }).catch(() => {}); el.remove(); } }, icon('folder', 13), 'Mostra nella cartella'),
      h('button', { class: 'dz-ib', 'aria-label': 'Chiudi', onclick: () => el.remove() }, icon('x', 14)));
    document.body.append(el);
    setTimeout(() => el.remove(), 9000);
  }

  // ------------------------------------------------------------ tastiera
  const isTyping = (t) => t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
  const onKey = (e) => {
    if (!alive || document.querySelector('.modal-bg')) return;
    if (isTyping(e.target)) return;
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    if (k === ' ' && !spaceDown) { spaceDown = true; stage.style.cursor = 'grab'; e.preventDefault(); return; }
    if (mod && k === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if (mod && k === 'y') { e.preventDefault(); redo(); return; }
    if (mod && (k === 'j' || k === 'd')) { e.preventDefault(); duplicateSel(); return; }
    if (mod && k === 'g') { e.preventDefault(); if (e.shiftKey) ungroup(); else groupSel(); return; }
    if (mod && k === 'a') { e.preventDefault(); select(layers().filter((l) => !l.locked).map((l) => l.id)); return; }
    if (mod && k === 'c') { copyLayers(); return; }
    if (mod && k === 'x') { copyLayers(); deleteSel(); return; }
    if (mod && k === 'e') { e.preventDefault(); exportDialog(); return; }
    if (mod && k === 's') { e.preventDefault(); save(); toast('Salvato'); return; }
    if (mod && (k === '0')) { e.preventDefault(); fit(); return; }
    if (mod && (k === '1')) { e.preventDefault(); zoomAt(1); return; }
    if (mod && (k === '=' || k === '+')) { e.preventDefault(); zoomAt(S.zoom * 1.25); return; }
    if (mod && k === '-') { e.preventDefault(); zoomAt(S.zoom / 1.25); return; }
    if (mod && k === ']') { e.preventDefault(); arrange(e.shiftKey ? 2 : 1); return; }
    if (mod && k === '[') { e.preventDefault(); arrange(e.shiftKey ? -2 : -1); return; }
    if (mod) return;
    if (k === 'delete' || k === 'backspace') { e.preventDefault(); deleteSel(); return; }
    if (k === 'escape') { if (S.crop) setTool('move'); else select([]); return; }
    if (k === 'enter' && S.crop) { applyCrop(); return; }
    if (k === 'enter' && one() && one().type === 'text') { e.preventDefault(); startEdit(one()); return; }
    if (k.startsWith('arrow') && S.sel.length) {
      e.preventDefault(); const d = e.shiftKey ? 10 : 1;
      for (const l of selLayers()) if (!l.locked) moveBy(l, k === 'arrowleft' ? -d : k === 'arrowright' ? d : 0, k === 'arrowup' ? -d : k === 'arrowdown' ? d : 0);
      commit('nudge'); return;
    }
    if (k === '[' ) { S.brush.size = Math.max(1, Math.round(S.brush.size / 1.2)); paintOpts(); draw(); return; }
    if (k === ']') { S.brush.size = Math.min(400, Math.round(S.brush.size * 1.2)); paintOpts(); draw(); return; }
    const map = { v: 'move', t: 'text', u: 'shape', b: 'brush', e: 'eraser', i: 'eyedrop', c: 'crop', h: 'hand' };
    if (map[k]) { setTool(map[k]); return; }
    if (k === 'z') { zoomAt(e.altKey ? S.zoom / 1.5 : S.zoom * 1.5); }
  };
  const onKeyUp = (e) => { if (e.key === ' ') { spaceDown = false; stage.style.cursor = S.tool === 'hand' ? 'grab' : ''; } };
  document.addEventListener('keydown', onKey);
  document.addEventListener('keyup', onKeyUp);
  const ro = new ResizeObserver(() => { const first = !S.fitted; if (first) { S.fitted = true; fit(); } else draw(); });
  ro.observe(stage);

  // ------------------------------------------------------------ partenza
  // font dei testi gia' presenti, poi ridisegno
  (function scan(list) { for (const l of list) { if (l.font) ensureFont(l.font).then(() => { dropCache(l.id); draw(); paintLayersSoon(); }); if (l.children) scan(l.children); } })(doc.pages.flatMap((p) => p.layers));
  hist.stack = [snap()]; hist.idx = 0;
  stage.__dz = { S, get doc() { return doc; }, toScr, commit };   // per i test automatici
  paintTools(); paintOpts(); refresh(true);
  onTitle && onTitle(doc.name);
  // aperta da "Rimuovi lo sfondo": l'immagine e' gia' scelta, si sceglie solo persona o oggetto
  if (autoCut) {
    const im = layers().find((l) => l.type === 'image');
    if (im) { S.sel = [im.id]; refresh(true); setTimeout(() => { const b = props.querySelector('.dz-aibox'); if (b) { b.classList.add('pulse'); b.scrollIntoView({ block: 'nearest' }); } }, 80); }
  }
  // nome della grafica (dalla barra in alto)
  const api = {
    rename: async (nm) => { doc.name = nm; await post(`/api/d/${gid}/meta`, { name: nm }); onTitle && onTitle(nm); },
    get name() { return doc.name; },
  };
  return {
    api,
    async cleanup() {
      alive = false;
      stopEdit(true);
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('keyup', onKeyUp);
      document.removeEventListener('paste', onPaste);
      window.removeEventListener('pagehide', onHide);
      window.removeEventListener('beforeunload', onHide);
      ro.disconnect();
      document.querySelectorAll('.dz-menu').forEach((x) => x.remove());
      clearTimeout(saveT);
      try { await save(); clearTimeout(coverT); await saveCover(); } catch (e) { /* */ }
      dropCache();
    },
  };
}
