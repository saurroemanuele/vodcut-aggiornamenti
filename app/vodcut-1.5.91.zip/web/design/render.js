// Grafica: disegno del documento. Ogni livello si disegna una volta nel suo riquadro (contenuto + filtri + maschera
// + effetti) e si tiene in memoria; spostarlo, ruotarlo o cambiarne l'opacita' non lo ridisegna.
import { hex2rgba } from './doc.js';
import { ensureFont, fontReady } from '../fonts.js';

// ---------------------------------------------------------------- immagini della grafica (file e tele in memoria)
export class Assets {
  constructor(urlOf, onReady) { this.urlOf = urlOf; this.onReady = onReady; this.map = new Map(); }
  get(name) {
    if (!name) return null;
    let a = this.map.get(name);
    if (!a) {
      a = { el: null, w: 0, h: 0, ready: false, ver: 0 };
      this.map.set(name, a);
      const im = new Image();
      im.decoding = 'async';
      im.onload = () => { a.el = im; a.w = im.naturalWidth; a.h = im.naturalHeight; a.ready = true; a.ver++; this.onReady && this.onReady(name); };
      im.onerror = () => { a.failed = true; };
      im.src = this.urlOf(name);
    }
    return a.ready ? a : null;
  }
  // tela in memoria (pittura in corso, maschere, immagini appena caricate): si usa subito, il file arriva dopo
  put(name, canvas) { const a = this.map.get(name) || {}; Object.assign(a, { el: canvas, w: canvas.width, h: canvas.height, ready: true, ver: (a.ver || 0) + 1 }); this.map.set(name, a); return a; }
  alias(from, to) { const a = this.map.get(from); if (a) this.map.set(to, a); }
  touch(name) { const a = this.map.get(name); if (a) a.ver++; }
  ver(name) { const a = this.map.get(name); return a ? a.ver : 0; }
}

// ---------------------------------------------------------------- colori e riempimenti (tinta unita o sfumatura)
export function fillStyle(g, fill, w, h) {
  if (!fill) return null;
  if (typeof fill === 'string') return fill;
  if (fill.type === 'linear' || fill.type === 'radial') {
    let gr;
    if (fill.type === 'radial') gr = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) / 2);
    else {
      const a = ((fill.angle || 0) - 90) * Math.PI / 180, r = (Math.abs(w * Math.cos(a)) + Math.abs(h * Math.sin(a))) / 2;
      gr = g.createLinearGradient(w / 2 - Math.cos(a) * r, h / 2 - Math.sin(a) * r, w / 2 + Math.cos(a) * r, h / 2 + Math.sin(a) * r);
    }
    for (const [o, c] of fill.stops || []) { try { gr.addColorStop(Math.max(0, Math.min(1, o)), c); } catch (e) { /* colore non valido */ } }
    return gr;
  }
  return '#000';
}
export const fillColor = (fill) => (typeof fill === 'string' ? fill : fill && fill.stops && fill.stops[0] ? fill.stops[0][1] : '#000000');

// ---------------------------------------------------------------- testo
const measure = document.createElement('canvas').getContext('2d');
export const fontOf = (l, k = 1) => `${l.italic ? 'italic ' : ''}${l.weight || 400} ${Math.max(1, l.size * k)}px "${l.font || 'Inter'}", -apple-system, "Segoe UI", Arial, sans-serif`;
function widthOf(g, s, letter) { return g.measureText(s).width + Math.max(0, s.length - 1) * (letter || 0); }
// righe del testo dentro la larghezza del livello (a capo sulle parole)
export function textLines(l) {
  if (l.font) ensureFont(l.font);
  measure.font = fontOf(l);
  const txt = l.upper ? String(l.text || '').toUpperCase() : String(l.text || '');
  const maxW = l.w;
  const out = [];
  for (const para of txt.split('\n')) {
    const words = para.split(/(\s+)/);
    let line = '';
    for (const w of words) {
      const test = line + w;
      if (line && widthOf(measure, test.trimEnd(), l.letter) > maxW && w.trim()) { out.push(line.trimEnd()); line = w.trimStart(); }
      else line = test;
      // parola piu' lunga della riga: si spezza
      while (widthOf(measure, line, l.letter) > maxW && line.length > 1) {
        let n = line.length - 1;
        while (n > 1 && widthOf(measure, line.slice(0, n), l.letter) > maxW) n--;
        out.push(line.slice(0, n)); line = line.slice(n);
      }
    }
    out.push(line);
  }
  return out;
}
export function textHeight(l) { return Math.max(1, Math.round(textLines(l).length * l.size * (l.lineH || 1.2))); }
// larghezza naturale (per il testo appena creato con un clic)
export function textNaturalWidth(l) {
  measure.font = fontOf(l);
  const txt = l.upper ? String(l.text || '').toUpperCase() : String(l.text || '');
  return Math.ceil(Math.max(1, ...txt.split('\n').map((s) => widthOf(measure, s, l.letter)))) + 2;
}
function drawText(g, l, k, cw) {
  g.font = fontOf(l, k);
  g.textBaseline = 'middle';
  const lines = textLines(l), lh = l.size * (l.lineH || 1.2) * k, sp = (l.letter || 0) * k;
  g.fillStyle = fillStyle(g, l.fill || l.color, cw, lines.length * lh) || '#000';
  lines.forEach((s, i) => {
    const y = (i + 0.5) * lh, w = widthOf(g, s, sp);
    let x = l.align === 'left' ? 0 : l.align === 'right' ? cw - w : (cw - w) / 2;
    if (!sp) { g.fillText(s, x, y); return; }
    for (const ch of s) { g.fillText(ch, x, y); x += g.measureText(ch).width + sp; }
  });
}

// ---------------------------------------------------------------- forme
export function shapePath(g, l, w, h) {
  g.beginPath();
  const k = l.kind;
  if (k === 'ellipse') g.ellipse(w / 2, h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
  else if (k === 'line') { g.moveTo(0, h / 2); g.lineTo(w, h / 2); }
  else if (k === 'triangle') { g.moveTo(w / 2, 0); g.lineTo(w, h); g.lineTo(0, h); g.closePath(); }
  else if (k === 'star' || k === 'poly') {
    const n = k === 'star' ? Math.max(3, l.sides || 5) : Math.max(3, l.sides || 6);
    const pts = k === 'star' ? n * 2 : n;
    for (let i = 0; i < pts; i++) {
      const a = -Math.PI / 2 + i * Math.PI * 2 / pts, r = k === 'star' && i % 2 ? (l.inner || 0.45) : 1;
      const x = w / 2 + Math.cos(a) * w / 2 * r, y = h / 2 + Math.sin(a) * h / 2 * r;
      if (i) g.lineTo(x, y); else g.moveTo(x, y);
    }
    g.closePath();
  } else {
    const r = Math.max(0, Math.min((l.radius || 0) * (w / Math.max(1, l.w)), w / 2, h / 2));
    if (g.roundRect && r) g.roundRect(0, 0, w, h, r); else g.rect(0, 0, w, h);
  }
}

// ---------------------------------------------------------------- filtri del livello e regolazioni
export function filterCss(f, k = 1) {
  if (!f) return 'none';
  const out = [];
  if (f.brightness) out.push(`brightness(${1 + f.brightness / 100})`);
  if (f.contrast) out.push(`contrast(${1 + f.contrast / 100})`);
  if (f.saturation) out.push(`saturate(${1 + f.saturation / 100})`);
  if (f.hue) out.push(`hue-rotate(${f.hue}deg)`);
  if (f.grayscale) out.push(`grayscale(${f.grayscale}%)`);
  if (f.sepia) out.push(`sepia(${f.sepia}%)`);
  if (f.invert) out.push(`invert(${f.invert}%)`);
  if (f.blur) out.push(`blur(${(f.blur * k).toFixed(2)}px)`);
  return out.length ? out.join(' ') : 'none';
}
export function adjustCss(l, k = 1) {
  const p = l.p || {};
  switch (l.kind) {
    case 'bc': return filterCss({ brightness: p.brightness, contrast: p.contrast });
    case 'hsl': return filterCss({ hue: p.hue, saturation: p.saturation, brightness: p.lightness });
    case 'bw': return `grayscale(${p.amount == null ? 100 : p.amount}%)`;
    case 'warm': { const a = p.amount || 0; return a >= 0 ? `sepia(${a * 0.6}%) saturate(${1 + a / 200})` : `hue-rotate(${a * 0.4}deg) saturate(${1 + a / 300})`; }
    case 'invert': return 'invert(100%)';
    case 'blur': return `blur(${((p.amount || 0) * k).toFixed(2)}px)`;
    default: return 'none';
  }
}

// ---------------------------------------------------------------- un livello: contenuto -> filtri -> maschera -> effetti
const cache = new Map();   // id -> { key, out }
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; };
const MAX_PX = 4096;
export function dropCache(id) { if (id) cache.delete(id); else cache.clear(); }

function contentKey(l, rs, assets) {
  const { x, y, rot, opacity, blend, visible, locked, name, flipX, flipY, ...rest } = l;
  return JSON.stringify(rest) + '|' + rs.toFixed(4) + '|' + (l.src ? assets.ver(l.src) : 0) + '|' + (l.mask && l.mask.src ? assets.ver(l.mask.src) : 0) + '|' + (l.font ? fontReady(l.font) : 1);
}

// scala del riquadro: quella della vista, ma mai oltre MAX_PX per lato (e mai oltre la risoluzione dell'immagine x2)
export function layerScale(l, k) {
  let rs = k;
  const big = Math.max(l.w, l.h) * rs;
  if (big > MAX_PX) rs *= MAX_PX / big;
  if ((l.type === 'image' || l.type === 'paint') && l.iw) rs = Math.min(rs, Math.max(1, 2 * l.iw / Math.max(1, l.w)));
  return Math.max(0.02, rs);
}

export function layerBitmap(l, k, assets, store = cache) {
  const rs = layerScale(l, k);
  const key = contentKey(l, rs, assets);
  const c0 = store.get(l.id);
  if (c0 && c0.key === key) return c0.out;
  const cw = Math.max(1, Math.round(l.w * rs)), ch = Math.max(1, Math.round(l.h * rs));
  let C = mk(cw, ch), g = C.getContext('2d');
  let ok = true;
  if (l.type === 'image' || l.type === 'paint') {
    const a = assets.get(l.src);
    if (a) g.drawImage(a.el, 0, 0, cw, ch); else if (l.src) ok = false;
  } else if (l.type === 'text') {
    drawText(g, l, rs, cw);
    if (l.font && !fontReady(l.font)) ok = false;
  } else if (l.type === 'shape') {
    shapePath(g, l, cw, ch);
    const lw = (l.strokeW || 0) * rs;
    if (l.kind !== 'line' && l.fill) { g.fillStyle = fillStyle(g, l.fill, cw, ch); g.fill(); }
    if (l.kind === 'line') {
      g.strokeStyle = fillStyle(g, l.fill || l.stroke || '#000', cw, ch); g.lineWidth = Math.max(1, ch * 0.9); g.lineCap = 'round'; g.stroke();
    } else if (lw > 0 && l.stroke) {
      g.save(); g.clip(); g.strokeStyle = fillStyle(g, l.stroke, cw, ch); g.lineWidth = lw * 2; shapePath(g, l, cw, ch); g.stroke(); g.restore();
    }
  }
  // filtri del livello
  const fc = filterCss(l.filters, rs);
  if (fc !== 'none') {
    const F = mk(cw, ch), fg = F.getContext('2d');
    fg.filter = fc; fg.drawImage(C, 0, 0); C = F; g = fg; g.filter = 'none';
  }
  // maschera: dove e' trasparente il livello sparisce (si dipinge con pennello e gomma)
  if (l.mask && l.mask.on !== false && l.mask.src) {
    const m = assets.get(l.mask.src);
    if (m) { g.globalCompositeOperation = 'destination-in'; g.drawImage(m.el, 0, 0, cw, ch); g.globalCompositeOperation = 'source-over'; } else ok = false;
  }
  // effetti: ombra, bagliore, contorno (sotto il contenuto)
  const fx = l.fx || {};
  const sh = fx.shadow && fx.shadow.on ? fx.shadow : null, gl = fx.glow && fx.glow.on ? fx.glow : null, st = fx.stroke && fx.stroke.on && fx.stroke.width > 0 ? fx.stroke : null;
  let pad = 0;
  if (sh) pad = Math.max(pad, (sh.blur * 1.5 + Math.max(Math.abs(sh.x), Math.abs(sh.y))) * rs);
  if (gl) pad = Math.max(pad, gl.blur * 1.5 * rs);
  if (st) pad = Math.max(pad, st.width * rs + 2);
  pad = Math.ceil(pad);
  let out = { cv: C, pad: 0, rs, ok };
  if (pad > 0) {
    const O = mk(cw + pad * 2, ch + pad * 2), og = O.getContext('2d');
    const sil = (color) => { const S = mk(cw, ch), sg = S.getContext('2d'); sg.drawImage(C, 0, 0); sg.globalCompositeOperation = 'source-in'; sg.fillStyle = color; sg.fillRect(0, 0, cw, ch); return S; };
    const far = 100000;
    if (sh) {
      og.save(); og.shadowColor = hex2rgba(sh.color, sh.opacity); og.shadowBlur = sh.blur * rs; og.shadowOffsetX = far + sh.x * rs; og.shadowOffsetY = sh.y * rs;
      og.drawImage(C, pad - far, pad); og.restore();
    }
    if (gl) {
      og.save(); og.shadowColor = hex2rgba(gl.color, gl.opacity); og.shadowBlur = gl.blur * rs; og.shadowOffsetX = far;
      const S = sil(gl.color); og.drawImage(S, pad - far, pad); og.shadowBlur = gl.blur * rs * 0.4; og.drawImage(S, pad - far, pad); og.restore();
    }
    if (st) {
      const S = sil(st.color), r = st.width * rs, n = Math.max(16, Math.min(64, Math.round(r * 2)));
      for (let rr = r; rr > 0; rr -= Math.max(1, r / 3)) for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; og.drawImage(S, pad + Math.cos(a) * rr, pad + Math.sin(a) * rr); }
    }
    og.drawImage(C, pad, pad);
    out = { cv: O, pad, rs, ok };
  }
  if (ok) store.set(l.id, { key, out });
  return out;
}

// ---------------------------------------------------------------- composizione
// view: { k: pixel della tela per pixel del documento, ox, oy: dove sta l'angolo (0,0) del documento }
function drawLayer(g, l, view, assets, store) {
  const bm = layerBitmap(l, view.k, assets, store);
  const s = view.k / bm.rs;
  g.save();
  g.globalAlpha = Math.max(0, Math.min(1, l.opacity == null ? 1 : l.opacity));
  g.globalCompositeOperation = l.blend && l.blend !== 'normal' ? l.blend : 'source-over';
  g.translate(view.ox + (l.x + l.w / 2) * view.k, view.oy + (l.y + l.h / 2) * view.k);
  if (l.rot) g.rotate(l.rot * Math.PI / 180);
  g.scale((l.flipX ? -1 : 1) * s, (l.flipY ? -1 : 1) * s);
  const cw = bm.cv.width - bm.pad * 2, ch = bm.cv.height - bm.pad * 2;
  g.imageSmoothingQuality = 'high';
  g.drawImage(bm.cv, -cw / 2 - bm.pad, -ch / 2 - bm.pad);
  g.restore();
  return bm.ok;
}

// disegna una lista di livelli (dal basso) su g; ritorna false se manca ancora qualcosa (immagini in arrivo)
export function renderLayers(g, layers, view, assets, opt = {}) {
  let ok = true;
  for (const l of layers) {
    if (!l.visible || (opt.hide && opt.hide.has(l.id))) continue;
    if (l.type === 'adjust') {
      // regolazione: cambia tutto quello che sta sotto (nello stesso gruppo), senza toccare i livelli
      const W = g.canvas.width, H = g.canvas.height;
      const T = mk(W, H), tg = T.getContext('2d');
      tg.filter = adjustCss(l, view.k); tg.drawImage(g.canvas, 0, 0);
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
      g.globalAlpha = l.opacity == null ? 1 : l.opacity;
      g.globalCompositeOperation = l.blend && l.blend !== 'normal' ? l.blend : 'source-over';
      if (opt.clip) { g.beginPath(); g.rect(opt.clip[0], opt.clip[1], opt.clip[2], opt.clip[3]); g.clip(); }
      g.drawImage(T, 0, 0); g.restore();
      continue;
    }
    if (l.type === 'group') {
      // gruppo "passante" (come in Photoshop): a opacita' piena e fusione normale i livelli dentro si fondono con quelli sotto
      if ((!l.blend || l.blend === 'normal') && (l.opacity == null || l.opacity >= 1)) { ok = renderLayers(g, l.children || [], view, assets, opt) && ok; continue; }
      const W = g.canvas.width, H = g.canvas.height;
      const T = mk(W, H), tg = T.getContext('2d');
      ok = renderLayers(tg, l.children || [], view, assets, opt) && ok;
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
      g.globalAlpha = l.opacity == null ? 1 : l.opacity;
      g.globalCompositeOperation = l.blend && l.blend !== 'normal' ? l.blend : 'source-over';
      g.drawImage(T, 0, 0); g.restore();
      continue;
    }
    ok = drawLayer(g, l, view, assets, opt.store || cache) && ok;
  }
  return ok;
}

// una pagina intera: sfondo + livelli, tagliata ai bordi del documento
export function renderPage(g, doc, page, view, assets, opt = {}) {
  const x = view.ox, y = view.oy, w = doc.w * view.k, hh = doc.h * view.k;
  g.save();
  g.beginPath(); g.rect(x, y, w, hh); g.clip();
  if (page.bg) { g.fillStyle = fillStyle(g, page.bg, w, hh) || '#fff'; g.save(); g.translate(x, y); g.fillRect(0, 0, w, hh); g.restore(); }
  const ok = renderLayers(g, page.layers || [], view, assets, { ...opt, clip: [x, y, w, hh] });
  g.restore();
  return ok;
}

// immagine finale di una pagina (esportazione, anteprime): aspetta immagini e font
export async function pageCanvas(doc, page, scale, assets, opt = {}) {
  const fonts = new Set();
  const srcs = new Set();
  (function scan(list) { for (const l of list || []) { if (l.font) fonts.add(l.font); if (l.src) srcs.add(l.src); if (l.mask && l.mask.src) srcs.add(l.mask.src); if (l.children) scan(l.children); } })(page.layers);
  await Promise.all([...fonts].map((f) => ensureFont(f).catch(() => null)));
  for (let i = 0; i < 100; i++) {
    const miss = [...srcs].filter((s) => !assets.get(s) && !(assets.map.get(s) || {}).failed);
    if (!miss.length) break;
    await new Promise((r) => setTimeout(r, 60));
  }
  const W = Math.max(1, Math.round(doc.w * scale)), H = Math.max(1, Math.round(doc.h * scale));
  const C = mk(W, H), g = C.getContext('2d');
  if (opt.bg) { g.fillStyle = opt.bg; g.fillRect(0, 0, W, H); }
  // l'esportazione non usa i riquadri calcolati per lo schermo: memoria a parte
  renderPage(g, doc, page, { k: scale, ox: 0, oy: 0 }, assets, { store: new Map() });
  return C;
}

// punto sul livello? (per le immagini con trasparenza conta il pixel, non il riquadro)
export function hitLayer(l, px, py, toLocal, assets) {
  const [x, y] = toLocal(l, px, py);
  if (x < 0 || y < 0 || x > l.w || y > l.h) return false;
  if (l.type === 'image' || l.type === 'paint') {
    const c = cache.get(l.id);
    if (!c) return l.type === 'image';
    const bm = c.out, cw = bm.cv.width - bm.pad * 2, ch = bm.cv.height - bm.pad * 2;
    try {
      const d = bm.cv.getContext('2d').getImageData(Math.floor(bm.pad + x / l.w * cw), Math.floor(bm.pad + y / l.h * ch), 1, 1).data;
      return d[3] > 12;
    } catch (e) { return true; }
  }
  return true;
}
