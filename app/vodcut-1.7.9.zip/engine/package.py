"""Progetto in un file .vodcut: per portarlo da un PC all'altro.

Il file e' uno zip con il progetto (tagli, zoom, testi, sottotitoli, impostazioni), le immagini dei
testi e l'analisi dell'audio. I file grandi (il VOD, le immagini e i suoni importati) NON sono dentro:
sull'altro PC si ricollegano (anche tutti insieme, indicando una cartella).
"""
import json
import os
import re
import time
import zipfile

from . import project as P
from .util import CACHE_DIR, IMPORTS_DIR, probe

FORMAT = 1
MEDIA_KINDS = {".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image", ".gif": "image", ".bmp": "image",
               ".mp4": "video", ".mov": "video", ".mkv": "video", ".webm": "video", ".m4v": "video", ".avi": "video", ".flv": "video", ".ts": "video",
               ".mp3": "audio", ".wav": "audio", ".m4a": "audio", ".aac": "audio", ".ogg": "audio", ".flac": "audio", ".opus": "audio"}


def _kind(path, is_source=False):
    if is_source:
        return "video"
    return MEDIA_KINDS.get(os.path.splitext(path or "")[1].lower(), "file")


def media_refs(proj):
    """Tutti i file esterni usati dal progetto: [{path, kind, name, source}] (senza doppioni).
    Le immagini dei testi non contano: viaggiano dentro al .vodcut."""
    out, seen = [], set()

    def add(path, source=False):
        if not path:
            return
        key = os.path.normcase(path)
        if key in seen:
            return
        seen.add(key)
        out.append({"path": path, "name": os.path.basename(path.replace("\\", "/")), "kind": _kind(path, source), "source": source})
    add(proj.get("source"), True)
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            if not c.get("isText"):
                add(c.get("file"))
    for i in proj.get("inserts") or []:
        add(i.get("file"))
    for a in proj.get("assets", []):
        add(a.get("path"))
    return out


def missing_files(proj):
    res = []
    for r in media_refs(proj):
        if not os.path.isfile(r["path"]):
            res.append(r)
    return res


def _own_text_png(path):
    """Il percorso vero se e' un'immagine di testo dell'app (dentro la cartella testi, .png), se no None."""
    if not isinstance(path, str) or not path:
        return None
    try:
        real = os.path.realpath(path)
        base = os.path.realpath(os.path.join(IMPORTS_DIR, "testi"))
    except (OSError, ValueError):
        return None
    if not real.lower().endswith(".png") or not os.path.normcase(real).startswith(os.path.normcase(base) + os.sep) or not os.path.isfile(real):
        return None
    return real


def export_package(proj, dest, cache_files=()):
    """Scrive il file .vodcut. cache_files: [(percorso sul disco, nome nello zip)]."""
    tmp = dest + ".part"
    refs = media_refs(proj)
    for r in refs:
        try:
            r["size"] = os.path.getsize(r["path"])
        except OSError:
            r["size"] = None
    meta = {"format": FORMAT, "app": "VODcut", "created": time.time(), "name": proj.get("name"), "files": refs}
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("vodcut.json", json.dumps(meta, ensure_ascii=False, indent=1))
        z.writestr("progetto.json", json.dumps(proj, ensure_ascii=False))
        for t in proj.get("tracks", []):
            for c in t.get("clips", []):
                # solo le immagini dei testi fatte dall'app (cartella testi, PNG): un progetto ricevuto da altri
                # non deve poter far finire nel pacchetto un file qualsiasi del PC
                f_ = _own_text_png(c.get("file")) if c.get("isText") else None
                if f_:
                    z.write(f_, "testi/" + os.path.basename(f_))
        for src, arc in cache_files:
            if os.path.isfile(src):
                z.write(src, arc)
    os.replace(tmp, dest)
    return dest


# percorsi che arrivano da un file di altri: niente cartelle di rete (\\server\...) ne' indirizzi web (http:, smb:, file:...)
# Windows, solo per controllare se esistono, si collegherebbe al server di chi ha creato il file e gli manderebbe le credenziali.
_PATH_KEYS = {"file", "path", "source", "src", "audio", "video", "image", "img", "music", "thumb", "poster", "cover", "logo", "mask", "font",
              "preview", "dir", "sheet", "first", "origSource"}
_BAD_PATH = re.compile(r"^(\\\\|//|\\\\\?\\|[A-Za-z][A-Za-z0-9+.\-]+:)")


def remote_path(v):
    """Cartella di rete o indirizzo, anche con le barre miste (una rovesciata e una dritta all'inizio): per Windows sono sempre di rete."""
    s = str(v or "").strip()
    return bool(_BAD_PATH.match(s)) or s.replace("/", "\\").startswith("\\\\")


def _safe_path(v):
    if not isinstance(v, str) or not v:
        return v
    if remote_path(v):
        return os.path.basename(v.replace("\\", "/").rstrip("/")) or ""   # resta solo il nome: lo si ricollega a mano
    return v


def _sanitize_paths(o):
    if isinstance(o, dict):
        for k, v in list(o.items()):
            if isinstance(v, str) and k in _PATH_KEYS:
                o[k] = _safe_path(v)
            elif isinstance(v, (dict, list)):
                _sanitize_paths(v)
    elif isinstance(o, list):
        for x in o:
            _sanitize_paths(x)


def import_package(path, wave_path, db_path):
    """Legge un .vodcut e crea il progetto su questo PC (con un id nuovo se serve)."""
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise ValueError("Questo file non e' un progetto NoonFrame valido")
    with z:
        names = set(z.namelist())
        if "progetto.json" not in names:
            raise ValueError("Questo file non e' un progetto NoonFrame valido")
        proj = json.loads(z.read("progetto.json").decode("utf-8"))
        old = str(proj.get("id") or "p")
        # l'id diventa un nome di file: da un file che arriva da fuori accettiamo solo lettere e numeri
        ok = re.fullmatch(r"p[A-Za-z0-9]{1,40}", old)
        pid = old if ok and not os.path.exists(P.path_for(old)) else P.new_id("p")
        proj["id"] = pid
        _sanitize_paths(proj)
        for k in ("parent", "parentName", "range"):   # da solo diventa un progetto normale
            proj.pop(k, None)
        proj.pop("verticals", None)
        # sicurezza: da un file che arriva da fuori non si tengono percorsi di destinazione o di file da aprire
        for k in ("lastExport", "exports", "lastExportDir"):
            proj.pop(k, None)
        if proj.get("stage") not in ("webcam", "style", "editor", "export", "done"):
            proj.pop("stage", None)
        ex = (proj.get("settings") or {}).get("export")
        if isinstance(ex, dict):
            for k in ("dir", "folder", "path"):
                ex.pop(k, None)
        # immagini dei testi
        d = os.path.join(IMPORTS_DIR, "testi")
        os.makedirs(d, exist_ok=True)
        for t in proj.get("tracks", []):
            for c in t.get("clips", []):
                if c.get("isText") and c.get("file"):
                    arc = "testi/" + os.path.basename(str(c["file"]).replace("\\", "/"))
                    ok_ = arc in names and arc.lower().endswith(".png") and z.getinfo(arc).file_size < 50 * 1024 * 1024
                    data = z.read(arc) if ok_ else b""
                    if data.startswith(b"\x89PNG") and len(data) < 50 * 1024 * 1024:
                        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", os.path.basename(arc))[-80:]
                        dest = os.path.join(d, f"{pid}_{safe}")
                        with open(dest, "wb") as f:
                            f.write(data)
                        c["file"] = dest
                    else:
                        c["file"] = ""   # niente immagine nel pacchetto: l'app ridisegna il testo (mai un percorso preso dal file)
        # analisi dell'audio (cosi' non va rifatta)
        for arc, dest in (("cache/wave.json", wave_path(pid)), ("cache/db.npy", db_path(pid))):
            if arc in names and z.getinfo(arc).file_size < 200 * 1024 * 1024:   # niente "zip bomba" che riempie la memoria
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(z.read(arc))
    proj["updated"] = time.time()
    # l'id vecchio compare nei nomi delle anteprime: nessun problema, vengono rifatte
    P.save(proj)
    return proj


def _replace_paths(proj, mapping):
    """mapping: {percorso vecchio (normcase): percorso nuovo}"""
    def fix(p):
        return mapping.get(os.path.normcase(p), p) if p else p
    proj["source"] = fix(proj.get("source"))
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            if not c.get("isText"):
                c["file"] = fix(c.get("file"))
    for a in proj.get("assets", []):
        a["path"] = fix(a.get("path"))
    for i in proj.get("inserts") or []:
        old = i.get("file")
        i["file"] = fix(old)
        if i["file"] != old:
            i.pop("preview", None)   # la copia per l'anteprima era dell'altro PC


def check_source(proj, new_path):
    """Il video principale deve essere lo stesso (stessa durata, al secondo)."""
    try:
        info = probe(new_path)
    except Exception:
        raise ValueError("Non riesco a leggere questo video")
    if not info.get("has_video"):
        raise ValueError("Questo file non contiene video")
    if abs(float(info.get("duration") or 0) - float(P.live_duration(proj) or 0)) > 1.5:
        raise ValueError("Questo non sembra lo stesso video: la durata è diversa")
    return True


def relink(proj, old_path, new_path):
    if not os.path.isfile(new_path):
        raise ValueError("File non trovato")
    if os.path.normcase(old_path) == os.path.normcase(proj.get("source") or ""):
        check_source(proj, new_path)
    _replace_paths(proj, {os.path.normcase(old_path): os.path.abspath(new_path)})
    return proj


def relink_folder(proj, folder, max_files=200000):
    """Cerca nella cartella (e sottocartelle) i file mancanti con lo stesso nome. Ritorna quanti ne ha trovati."""
    miss = missing_files(proj)
    if not miss:
        return 0
    want = {}
    for r in miss:
        want.setdefault(r["name"].lower(), []).append(r)
    found = {}
    n = 0
    for root, dirs, files in os.walk(folder):
        dirs[:] = [x for x in dirs if not x.startswith(".") and x.lower() not in ("$recycle.bin", "windows", "appdata")]
        for fn in files:
            n += 1
            if n > max_files:
                break
            lst = want.get(fn.lower())
            if not lst:
                continue
            full = os.path.join(root, fn)
            for r in lst:
                if os.path.normcase(r["path"]) in found:
                    continue
                if r["source"]:
                    try:
                        check_source(proj, full)
                    except ValueError:
                        continue
                found[os.path.normcase(r["path"])] = os.path.abspath(full)
        if n > max_files or len(found) == len(miss):
            break
    _replace_paths(proj, found)
    return len(found)


def safe_name(name):
    return re.sub(r'[\\/:*?"<>|]+', "_", name or "progetto").strip() or "progetto"

