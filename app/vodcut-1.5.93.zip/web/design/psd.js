// Grafica: apre i file di Photoshop (.psd) con i livelli (libreria ag-psd, MIT, caricata solo quando serve).
import { uid } from './doc.js';

let lib = null;
function loadLib() {
  if (lib) return lib;
  lib = new Promise((res, rej) => {
    if (window.agPsd) { res(window.agPsd); return; }
    const s = document.createElement('script');
    s.src = '/web/vendor/ag-psd.js';
    s.onload = () => (window.agPsd ? res(window.agPsd) : rej(new Error('Lettore PSD non disponibile')));
    s.onerror = () => { lib = null; rej(new Error('Lettore PSD non disponibile')); };
    document.head.append(s);
  });
  return lib;
}

const BLEND = { normal: 'normal', multiply: 'multiply', screen: 'screen', overlay: 'overlay', darken: 'darken', lighten: 'lighten',
  'color dodge': 'color-dodge', 'color burn': 'color-burn', 'hard light': 'hard-light', 'soft light': 'soft-light',
  difference: 'difference', exclusion: 'exclusion', hue: 'hue', saturation: 'saturation', color: 'color', luminosity: 'luminosity' };

// buf = ArrayBuffer del .psd; upload(canvas) -> nome del file nella grafica
export async function readPsd(buf, upload, onStep) {
  const ag = await loadLib();
  const psd = ag.readPsd(buf, { skipThumbnail: true, skipLinkedFilesData: true });
  let n = 0;
  const count = (list) => (list || []).reduce((a, l) => a + (l.children ? count(l.children) : 1), 0);
  const total = Math.max(1, count(psd.children));
  async function conv(list) {
    const out = [];
    for (const L of list || []) {
      const base = { id: uid(), name: (L.name || '').slice(0, 80), visible: !L.hidden, locked: false, opacity: L.opacity == null ? 1 : L.opacity,
        blend: BLEND[L.blendMode] || 'normal', rot: 0, flipX: false, flipY: false };
      if (L.children) {
        const kids = await conv(L.children);
        if (kids.length) out.push({ ...base, type: 'group', name: base.name || 'Gruppo', children: kids, open: false, x: 0, y: 0, w: 1, h: 1 });
        continue;
      }
      n++; onStep && onStep(n / total);
      const cv = L.canvas;
      if (!cv || !cv.width || !cv.height) continue;   // livello vuoto (o di sola regolazione)
      const file = await upload(cv);
      out.push({ ...base, type: 'image', name: base.name || 'Livello', src: file, iw: cv.width, ih: cv.height,
        x: L.left || 0, y: L.top || 0, w: cv.width, h: cv.height });
    }
    return out;
  }
  const layers = await conv(psd.children);
  // PSD senza livelli: solo l'immagine finale
  if (!layers.length && psd.canvas) {
    const file = await upload(psd.canvas);
    layers.push({ id: uid(), type: 'image', name: 'Immagine', visible: true, locked: false, opacity: 1, blend: 'normal', rot: 0, flipX: false, flipY: false,
      src: file, iw: psd.width, ih: psd.height, x: 0, y: 0, w: psd.width, h: psd.height });
  }
  return { w: psd.width, h: psd.height, layers };
}

// ---------------------------------------------------------------- salva come PSD (livelli separati, da aprire in Photoshop)
const BLEND_OUT = Object.fromEntries(Object.entries(BLEND).map(([k, v]) => [v, k]));
// render(page, layers) -> canvas della grandezza del documento con solo quei livelli
export async function writePsdBuffer(doc, page, renderOnly, composite) {
  const ag = await loadLib();
  const crop = (cv) => {
    const g = cv.getContext('2d'), d = g.getImageData(0, 0, cv.width, cv.height).data, w = cv.width, h = cv.height;
    let x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3]) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; y1 = y; }
    if (x1 < 0) return null;
    const o = document.createElement('canvas'); o.width = x1 - x0 + 1; o.height = y1 - y0 + 1;
    o.getContext('2d').drawImage(cv, x0, y0, o.width, o.height, 0, 0, o.width, o.height);
    return { canvas: o, left: x0, top: y0 };
  };
  const conv = (list) => {
    const out = [];
    for (const l of list || []) {
      if (l.type === 'adjust') continue;   // le regolazioni restano nell'immagine finale
      const base = { name: l.name || 'Livello', hidden: !l.visible, opacity: l.opacity == null ? 1 : l.opacity, blendMode: BLEND_OUT[l.blend || 'normal'] || 'normal' };
      if (l.type === 'group') { const kids = conv(l.children); if (kids.length) out.push({ ...base, children: kids, opened: true }); continue; }
      const c = crop(renderOnly([{ ...l, visible: true, opacity: 1, blend: 'normal' }]));
      if (c) out.push({ ...base, ...c });
    }
    return out;
  };
  const children = conv(page.layers);
  if (page.bg) {
    const bg = document.createElement('canvas'); bg.width = doc.w; bg.height = doc.h;
    const g = bg.getContext('2d'); g.fillStyle = typeof page.bg === 'string' ? page.bg : '#FFFFFF'; g.fillRect(0, 0, doc.w, doc.h);
    children.unshift({ name: 'Sfondo', canvas: bg, left: 0, top: 0 });
  }
  return ag.writePsd({ width: doc.w, height: doc.h, canvas: composite, children }, { generateThumbnail: false });
}
