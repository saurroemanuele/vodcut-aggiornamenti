// Noonframe - Storie AI: pagine (identità di ogni profilo), chiavi dei servizi AI dell'utente, storie scena per scena.
// Le chiavi non arrivano mai qui: l'interfaccia vede solo se ci sono e le ultime 4 cifre.
import { get, post, h, icon, toast, confirmBox, seg, pollJob, mediaUrl, fmt } from './lib.js';

const MOTIONS = [['zoomIn', 'Zoom avanti'], ['zoomOut', 'Zoom indietro'], ['panL', 'Verso sinistra'], ['panR', 'Verso destra'], ['panU', 'Verso l\'alto'], ['panD', 'Verso il basso']];
const DOES = { text: 'Testi', image: 'Immagini', voice: 'Voce' };
const PRESET_NAMES = { cinematic: 'Cinematico', anime: 'Anime', pixar: 'Animazione 3D', dark: 'Horror', comic: 'Fumetto', watercolor: 'Acquerello' };
const LANGS = [['it', 'Italiano'], ['en', 'English'], ['es', 'Español'], ['fr', 'Français'], ['de', 'Deutsch'], ['pt', 'Português']];
// come replaceChildren, ma salta le parti vuote (niente "null" a schermo)
const rc = (node, ...kids) => node.replaceChildren(...kids.flat().filter((k) => k != null && k !== false && k !== ''));
const usd = (x) => '$' + (x < 0.1 ? (+x || 0).toFixed(3) : (+x || 0).toFixed(2));
const secsOf = (t) => Math.max(1.2, (String(t || '').split(/\s+/).filter(Boolean).length) / 2.6);
const hueOf = (s) => { let x = 0; for (const c of String(s || '')) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };
const pageAv = (p, size = 36) => h('span', { class: 'ai-pav', style: { width: size + 'px', height: size + 'px', fontSize: Math.round(size * 0.42) + 'px', background: `hsl(${hueOf(p.name)} 70% 45%)` } },
  (p.name || '?').trim().charAt(0).toUpperCase());

export function studioRoutes(ctx) {
  const { app, topbar, nav, setTitle, setCleanup } = ctx;
  let S = null;   // stato: chiavi, pagine, storie
  const load = async () => { S = await get('/api/ai/state'); return S; };
  const keysReady = () => S && ['text', 'image', 'voice'].every((w) => Object.values(S.keys).some((k) => k.set && k.does.includes(w)));
  const missing = () => ['text', 'image', 'voice'].filter((w) => !Object.values(S.keys).some((k) => k.set && k.does.includes(w)));

  // ------------------------------------------------------------- chiavi AI
  function keysDialog(onDone) {
    const bg = h('div', { class: 'modal-bg' });
    const list = h('div', { class: 'ai-keys' });
    const close = () => { bg.remove(); onDone && onDone(); };
    const paint = () => rc(list, ...Object.entries(S.keys).map(([id, k]) => {
      const inp = h('input', { class: 'input', type: 'password', autocomplete: 'off', spellcheck: 'false', placeholder: k.set ? 'Chiave salvata ' + k.hint : 'Incolla la chiave', 'aria-label': 'Chiave ' + k.name });
      const state = !k.set ? h('span', { class: 'ai-kst none' }, 'Non collegato')
        : k.ok === false ? h('span', { class: 'ai-kst bad' }, icon('x', 11, 'currentColor', 3), 'Non funziona')
          : k.ok ? h('span', { class: 'ai-kst ok' }, icon('check', 11, 'currentColor', 3), 'Collegato') : h('span', { class: 'ai-kst' }, 'Salvata ' + k.hint);
      const save = h('button', { class: 'btn primary sm', onclick: async () => {
        if (!inp.value.trim()) return inp.focus();
        save.disabled = true;
        try { S.keys = await post('/api/ai/key', { provider: id, key: inp.value.trim() }); inp.value = '';
          try { S.keys = await post('/api/ai/key/test', { provider: id }); toast(k.name + ' collegato'); } catch (e) { S.keys[id].ok = false; toast(e.message, true); }
        } catch (e) { toast(e.message, true); }
        paint();
      } }, 'Salva');
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') save.click(); });
      return h('div', { class: 'ai-key' + (k.set ? ' on' : '') },
        h('div', { class: 'ai-kh' }, h('b', null, k.name), h('div', { class: 'ai-does' }, ...k.does.map((d) => h('span', null, DOES[d]))), h('div', { class: 'grow' }), state),
        h('div', { class: 'ai-krow' }, inp, save,
          k.set ? h('button', { class: 'btn sm ghost', 'data-tip': 'Prova la chiave', onclick: async () => { try { S.keys = await post('/api/ai/key/test', { provider: id }); toast('Funziona'); } catch (e) { toast(e.message, true); } await load(); paint(); } }, 'Prova') : null,
          k.set ? h('button', { class: 'iconbtn', 'aria-label': 'Togli la chiave', 'data-tip': 'Togli la chiave', onclick: async () => { S.keys = await post('/api/ai/key', { provider: id, key: '' }); paint(); } }, icon('trash', 14)) : null),
        h('button', { class: 'linkish ai-where', onclick: () => post('/api/openurl', { url: k.site }).catch(() => {}) }, 'Dove trovo la chiave?'));
    }));
    paint();
    bg.append(h('div', { class: 'modal ai-kmodal' },
      h('div', { class: 'ai-mh' }, h('h2', null, 'Chiavi AI'), h('button', { class: 'iconbtn', 'aria-label': 'Chiudi', onclick: close }, icon('x', 16))),
      h('div', { class: 'ai-trust' }, icon('shield', 18), h('div', null, h('b', null, 'Usi i tuoi account, paghi solo quello che usi.'),
        h('span', null, 'Le chiavi restano solo su questo computer, cifrate. Noonframe non le vede e non prende commissioni: ogni immagine o voce la paghi direttamente al servizio.'))),
      h('p', { class: 'ai-tip' }, 'Per iniziare bastano: uno per i testi (Anthropic, OpenAI o Gemini), uno per le immagini (fal.ai, Gemini o OpenAI) e uno per la voce (ElevenLabs o OpenAI). Solo OpenAI fa tutte e tre le cose.'),
      list,
      h('div', { class: 'crop-btns' }, h('button', { class: 'btn primary', onclick: close }, 'Fatto'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  // ------------------------------------------------------------- home: pagine e storie
  async function home(pid) {
    setTitle('Storie AI');
    await load();
    let sel = pid || (S.pages[0] && S.pages[0].id) || null;
    const side = h('aside', { class: 'ai-side' });
    const main = h('section', { class: 'ai-main' });
    const paint = () => {
      const keysOk = keysReady();
      rc(side, 
        h('div', { class: 'ai-sh' }, h('b', null, 'Pagine'), h('span', { class: 'wz-count' }, String(S.pages.length))),
        h('div', { class: 'ai-plist' }, ...S.pages.map((p) => h('button', { class: 'ai-pitem' + (p.id === sel ? ' on' : ''), onclick: () => { sel = p.id; paint(); } },
          pageAv(p, 30), h('span', null, h('b', { 'data-notr': '' }, p.name), h('small', { 'data-notr': '' }, p.handle ? '@' + p.handle : (p.niche || '').slice(0, 40)))))),
        h('button', { class: 'btn sm ai-newpage', onclick: () => nav('aipage', 'new') }, icon('plus', 14), 'Nuova pagina'),
        h('div', { class: 'grow' }),
        h('button', { class: 'ai-keysbtn' + (keysOk ? ' ok' : ''), onclick: () => keysDialog(() => { load().then(paint); }) },
          icon(keysOk ? 'check' : 'lock', 15, 'currentColor', 2.2), h('span', null, h('b', null, 'Chiavi AI'), h('small', null, keysOk ? 'Tutto collegato' : 'Mancano: ' + missing().map((w) => DOES[w]).join(', ')))),
        h('button', { class: 'linkish ai-manual', onclick: () => nav('story') }, 'Ho già immagini e voce: storia manuale'));
      const page = S.pages.find((p) => p.id === sel);
      if (!Object.values(S.keys).some((k) => k.set)) {
        rc(main, h('div', { class: 'ai-hero' },
          h('div', { class: 'ai-hero-art' }, h('i'), h('i'), h('i')),
          h('h1', null, 'Storie AI, con i tuoi account'),
          h('p', null, 'Scrivi un argomento: l\'AI scrive la storia, crea le immagini e la voce, e Noonframe monta il video 9:16 con sottotitoli e musica. Colleghi i tuoi servizi AI e paghi solo quello che usi: niente abbonamenti.'),
          h('div', { class: 'ai-steps3' }, ...[['lock', 'Collega le chiavi', 'OpenAI, Anthropic, Gemini, ElevenLabs o fal.ai'], ['user', 'Crea una pagina', 'Stile, personaggi e voci del tuo profilo'], ['film', 'Genera e monta', 'Da un argomento al video pronto']]
            .map(([ic, t, s], i) => h('div', null, h('span', { class: 'n' }, String(i + 1)), icon(ic, 18), h('b', null, t), h('small', null, s)))),
          h('button', { class: 'btn primary big', onclick: () => keysDialog(() => { load().then(paint); }) }, icon('lock', 15, '#fff'), 'Collega le chiavi AI')));
        return;
      }
      if (!page) {
        rc(main, h('div', { class: 'ai-hero' }, h('div', { class: 'ai-hero-art' }, h('i'), h('i'), h('i')),
          h('h1', null, 'Crea la tua prima pagina'),
          h('p', null, 'Una pagina è l\'identità di un profilo social: stile delle immagini, personaggi, voci e regole della narrazione. Ogni storia della pagina le usa, così il tuo stile resta sempre uguale.'),
          h('button', { class: 'btn primary big', onclick: () => nav('aipage', 'new') }, icon('plus', 15, '#fff'), 'Nuova pagina')));
        return;
      }
      const stories = S.stories.filter((x) => x.page === page.id);
      const STATUS = { script: 'Script', scene: 'Immagini', produzione: 'In lavorazione', montata: 'Montata' };
      rc(main, 
        h('div', { class: 'ai-phead' }, pageAv(page, 56),
          h('div', { class: 'ai-pwho' }, h('h1', { 'data-notr': '' }, page.name),
            h('div', { class: 'ai-pmeta' }, page.handle ? h('span', { 'data-notr': '' }, '@' + page.handle) : null,
              h('span', null, PRESET_NAMES[(page.style || {}).preset] || 'Stile personale'),
              h('span', null, (page.characters || []).length + ' personaggi'),
              h('span', { 'data-notr': '' }, (page.narrator || {}).name ? '🎙 ' + page.narrator.name : 'Voce da scegliere'))),
          h('div', { class: 'grow' }),
          h('button', { class: 'btn', onclick: () => nav('aipage', page.id) }, icon('sliders', 14), 'Modifica pagina'),
          h('button', { class: 'btn primary', onclick: () => newStory(page) }, icon('sparkle', 15, '#fff'), 'Nuova storia')),
        (page.characters || []).length ? h('div', { class: 'ai-cast' }, ...page.characters.map((c) => h('div', { class: 'ai-castc' },
          c.refs && c.refs[0] ? h('img', { src: mediaUrl(c.refs[0]), alt: '' }) : h('span', { class: 'ai-pav', style: { background: `hsl(${hueOf(c.name)} 55% 40%)` } }, c.name.charAt(0)),
          h('b', { 'data-notr': '' }, c.name)))) : null,
        h('div', { class: 'phead' }, h('h2', null, 'Storie'), h('span', { class: 'pcount' }, String(stories.length))),
        stories.length ? h('div', { class: 'ai-sgrid' }, ...stories.map((x) => h('div', { class: 'ai-scard', role: 'button', tabindex: '0', onclick: () => nav('aistory', x.id) },
          h('div', { class: 'ai-sthumb' }, x.thumb ? h('img', { src: mediaUrl(x.thumb), alt: '', loading: 'lazy' }) : h('span', null, icon('image', 22)),
            h('span', { class: 'ai-sst s-' + x.status }, STATUS[x.status] || x.status),
            h('button', { class: 'ai-sdel', 'aria-label': 'Elimina', 'data-tip': 'Elimina la storia', onclick: async (e) => {
              e.stopPropagation();
              if (!await confirmBox('Eliminare la storia?', 'Si cancellano script, immagini e voci generate. Il video già montato (se c\'è) resta tra i progetti.', 'Elimina', true)) return;
              await post('/api/ai/story/delete', { id: x.id }); await load(); paint();
            } }, icon('trash', 13, '#fff'))),
          h('b', { 'data-notr': '' }, x.title || 'Storia'),
          h('small', null, x.scenes + ' scene · ' + x.images + ' immagini · ' + x.voices + ' voci · ' + usd(x.cost)))))
          : h('div', { class: 'ai-empty' }, icon('sparkle', 22), h('b', null, 'Nessuna storia ancora'), h('span', null, 'Premi "Nuova storia": scrivi un argomento o lascia scegliere l\'AI.')));
    };
    paint();
    app.append(topbar(-1, null, false, { name: 'Storie AI', home: true }), h('main', { class: 'ai-home' }, side, main));
  }

  // ------------------------------------------------------------- nuova storia (finestra)
  function newStory(page) {
    if (!keysReady()) { toast('Collega prima le chiavi AI: mancano ' + missing().map((w) => DOES[w]).join(', '), true); return keysDialog(); }
    let mode = 0, dur = page.duration || 60;
    const MODES = ['Argomento', 'Scegli tu', 'Ho lo script'];
    const box = h('div', { class: 'ai-nsbody' });
    const topic = h('textarea', { class: 'input ai-ta', rows: 3, placeholder: 'Es. Una ragazza sente bussare alla porta, ma vive da sola…' });
    const script = h('textarea', { class: 'input ai-ta', rows: 9, placeholder: 'Incolla lo script: lo divido in scene senza cambiare le parole.' });
    const durs = h('div', { class: 'ai-durs' });
    const paintD = () => rc(durs, ...[30, 45, 60, 90].map((d) => h('button', { class: 'chip' + (d === dur ? ' on' : ''), onclick: () => { dur = d; paintD(); } }, d + ' s')));
    const paint = () => {
      paintD();
      rc(box, seg(MODES, mode, (i) => { mode = i; paint(); }),
        mode === 0 ? h('div', { class: 'field' }, h('label', null, 'Di cosa parla?'), topic)
          : mode === 1 ? h('p', { class: 'wz-p' }, 'L\'AI sceglie un argomento nuovo adatto alla pagina (evitando le storie già fatte) e scrive tutto.')
            : h('div', { class: 'field' }, h('label', null, 'Script'), script),
        mode !== 2 ? h('div', { class: 'field' }, h('label', null, 'Durata'), durs) : null);
      setTimeout(() => (mode === 0 ? topic : mode === 2 ? script : go).focus(), 30);
    };
    const bg = h('div', { class: 'modal-bg' });
    const msg = h('div', { class: 'ai-busy', hidden: true }, h('div', { class: 'spinner' }), h('span', null, 'Scrivo la storia…'));
    const go = h('button', { class: 'btn primary', onclick: async () => {
      go.disabled = true; msg.hidden = false;
      try {
        const job = await post('/api/ai/story/write', { page: page.id, mode: ['topic', 'auto', 'script'][mode], topic: topic.value, script: script.value, duration: dur });
        const r = await pollJob(job.id, (j) => { if (j.message) msg.lastChild.textContent = j.message + '…'; });
        if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
        bg.remove(); nav('aistory', r.result.story);
      } catch (e) { go.disabled = false; msg.hidden = true; toast(e.message, true); }
    } }, icon('sparkle', 14, '#fff'), 'Scrivi la storia');
    paint();
    bg.append(h('div', { class: 'modal ai-nsmodal' },
      h('div', { class: 'ai-mh' }, h('h2', null, 'Nuova storia'), h('span', { class: 'ai-pchip', 'data-notr': '' }, page.name), h('div', { class: 'grow' }),
        h('button', { class: 'iconbtn', 'aria-label': 'Chiudi', onclick: () => bg.remove() }, icon('x', 16))),
      box, msg, h('div', { class: 'crop-btns' }, h('button', { class: 'btn ghost', onclick: () => bg.remove() }, 'Annulla'), go)));
    document.body.append(bg);
  }

  // ------------------------------------------------------------- pagina (preset)
  async function pageEditor(pid) {
    await load();
    const isNew = !pid || pid === 'new';
    const P = isNew ? { name: 'Nuova pagina', handle: '', lang: 'it', niche: '', duration: 60, style: { preset: 'cinematic', prompt: S.presets.cinematic },
      narrative: {}, characters: [], narrator: {}, textCfg: {}, imageCfg: {}, voiceCfg: { stability: 0.5, similarity: 0.75, style: 0, speed: 1 }, edit: { captions: 'word', musicVol: 22 } }
      : JSON.parse(JSON.stringify(S.pages.find((p) => p.id === pid) || {}));
    if (!isNew && !P.id) { toast('Pagina non trovata', true); return nav('studio'); }
    setTitle(P.name || 'Pagina');
    let tab = 'id', dirty = false, voices = null;
    const TABS = [['id', 'Identità', 'user'], ['style', 'Stile', 'image'], ['cast', 'Personaggi', 'star'], ['story', 'Narrazione', 'text'], ['voice', 'Voci', 'speaker'], ['edit', 'Montaggio', 'film'], ['models', 'Modelli AI', 'sparkle']];
    const nav2 = h('nav', { class: 'ai-tabs' });
    const body = h('div', { class: 'ai-pbody' });
    const saveBtn = h('button', { class: 'btn primary', onclick: () => save(true) }, isNew ? 'Crea pagina' : 'Salva');
    const mark = () => { dirty = true; saveBtn.disabled = false; };
    async function save(leave) {
      saveBtn.disabled = true;
      try {
        const r = await post('/api/ai/page', P); Object.assign(P, r); dirty = false;
        await load();
        if (leave) { toast(isNew ? 'Pagina creata' : 'Pagina salvata'); nav('studio', P.id); }
        return r;
      } catch (e) { saveBtn.disabled = false; toast(e.message, true); }
    }
    const field = (label, el, note) => h('div', { class: 'field' }, h('label', null, label), el, note ? h('p', { class: 'field-note' }, note) : null);
    const inp = (obj, key, ph, max) => { const e = h('input', { class: 'input', value: obj[key] || '', placeholder: ph || '', maxlength: max || 200 }); e.addEventListener('input', () => { obj[key] = e.value; mark(); }); return e; };
    const ta = (obj, key, ph, rows) => { const e = h('textarea', { class: 'input ai-ta', rows: rows || 3, placeholder: ph || '' }); e.value = obj[key] || ''; e.addEventListener('input', () => { obj[key] = e.value; mark(); }); return e; };
    const selectEl = (opts, cur, onPick) => { const s = h('select', { class: 'input' }, ...opts.map(([v, l]) => h('option', { value: v, selected: v === cur ? true : null }, l))); s.addEventListener('change', () => { onPick(s.value); mark(); }); return s; };
    async function loadVoices() {
      const pv = (P.voiceCfg || {}).provider || (S.keys.elevenlabs.set ? 'elevenlabs' : S.keys.openai.set ? 'openai' : '');
      if (!pv) { voices = []; return; }
      try { voices = (await post('/api/ai/voices', { provider: pv })).voices; } catch (e) { voices = []; toast(e.message, true); }
    }
    const voicePicker = (cur, onPick) => {
      if (voices === null) { loadVoices().then(draw); return h('div', { class: 'ai-busy' }, h('div', { class: 'spinner' }), h('span', null, 'Carico le voci…')); }
      if (!voices.length) return h('p', { class: 'field-note' }, 'Collega ElevenLabs o OpenAI in Chiavi AI per scegliere le voci.');
      return selectEl([['', '— Scegli una voce —'], ...voices.map((v) => [v.id, v.name + (v.labels && Object.keys(v.labels).length ? ' · ' + Object.values(v.labels).slice(0, 3).join(', ') : '')])], cur && cur.id, (id) => {
        const v = voices.find((x) => x.id === id); onPick(v ? { id: v.id, name: v.name } : { id: '', name: '' });
      });
    };
    const T = {
      id: () => [h('h2', null, 'Identità'), h('p', { class: 'wz-p' }, 'Chi è questa pagina: il nome, il profilo social e di cosa parla.'),
        h('div', { class: 'prof-grid' }, field('Nome della pagina', inp(P, 'name', 'Es. Storie di paura', 60)), field('Username social', inp(P, 'handle', 'senza @', 40))),
        field('Nicchia e argomenti', ta(P, 'niche', 'Es. storie horror brevi ispirate a leggende urbane italiane, ambientate oggi', 3)),
        h('div', { class: 'prof-grid' }, field('Lingua dei video', selectEl(LANGS, P.lang || 'it', (v) => { P.lang = v; })),
          field('Durata media', selectEl([['30', '30 secondi'], ['45', '45 secondi'], ['60', '60 secondi'], ['90', '90 secondi'], ['120', '2 minuti']], String(P.duration || 60), (v) => { P.duration = +v; })))],
      style: () => {
        const st = P.style = P.style || {};
        const pr = ta(st, 'prompt', 'Descrivi lo stile delle immagini (in inglese funziona meglio)', 5);
        return [h('h2', null, 'Stile delle immagini'), h('p', { class: 'wz-p' }, 'È il "master prompt": viene aggiunto a ogni immagine, così tutte le storie della pagina hanno lo stesso aspetto.'),
          h('div', { class: 'ai-presets' }, ...Object.entries(S.presets).map(([k, v]) => h('button', { class: 'ai-preset' + (st.preset === k ? ' on' : ''), onclick: () => { st.preset = k; st.prompt = v; pr.value = v; mark(); draw(); } },
            h('i', { class: 'pv-' + k }), h('b', null, PRESET_NAMES[k] || k)))),
          field('Prompt di stile', pr, 'Puoi partire da uno stile qui sopra e modificarlo: palette, luce, epoca, tipo di inquadrature.')];
      },
      cast: () => [h('h2', null, 'Personaggi ricorrenti'),
        h('p', { class: 'wz-p' }, 'Descrivi l\'aspetto e aggiungi 1–4 foto di riferimento: le immagini useranno sempre la stessa faccia e gli stessi vestiti (con fal.ai Nano Banana, Gemini o OpenAI).'),
        ...(P.characters || []).map((c, i) => h('div', { class: 'ai-char' },
          h('div', { class: 'ai-refs' }, ...(c.refs || []).map((r) => h('div', { class: 'ai-ref' }, h('img', { src: mediaUrl(r), alt: '' }),
            h('button', { class: 'st-x', 'aria-label': 'Togli', onclick: async () => { try { const pg = await post('/api/ai/page/ref/remove', { page: P.id, char: c.id, path: r }); P.characters = pg.characters; draw(); } catch (e) { toast(e.message, true); } } }, icon('x', 11, '#fff', 2.6)))),
            (c.refs || []).length < 4 ? h('button', { class: 'ai-ref add', 'data-tip': 'Aggiungi una foto di riferimento', onclick: () => addRef(c) }, icon('plus', 18), h('small', null, 'Foto')) : null),
          h('div', { class: 'ai-cf' },
            h('div', { class: 'prof-grid' }, field('Nome', inp(c, 'name', 'Es. Emma', 40)), field('Ruolo', inp(c, 'role', 'Es. protagonista', 60))),
            field('Aspetto (in inglese)', ta(c, 'look', 'Es. young woman, 25, short black hair, green eyes, grey oversized hoodie', 2)),
            field('Personalità', ta(c, 'personality', 'Es. coraggiosa ma diffidente, ironica', 2)),
            field('Voce', voicePicker(c.voice, (v) => { c.voice = v; })),
            h('button', { class: 'linkish danger', onclick: () => { P.characters.splice(i, 1); mark(); draw(); } }, 'Togli il personaggio')))),
        h('button', { class: 'btn', onclick: () => { P.characters = [...(P.characters || []), { id: '', name: 'Nuovo personaggio', look: '', personality: '', role: '', voice: {}, refs: [] }]; mark(); draw(); } }, icon('plus', 14), 'Aggiungi personaggio')],
      story: () => { const n = P.narrative = P.narrative || {}; return [h('h2', null, 'Narrazione'), h('p', { class: 'wz-p' }, 'Come scrive l\'AI per questa pagina. Ricorda anche le storie già fatte, per non ripeterle.'),
        h('div', { class: 'prof-grid' }, field('Tipo di storie', inp(n, 'kind', 'Es. horror psicologico, mistero', 200)), field('Tono', inp(n, 'tone', 'Es. teso, sussurrato, ironico', 200))),
        h('div', { class: 'prof-grid' }, field('Come apre (hook)', inp(n, 'hook', 'Es. una domanda inquietante nei primi 2 secondi', 300)), field('Finale', inp(n, 'ending', 'Es. colpo di scena, finale aperto', 200))),
        h('div', { class: 'prof-grid' }, field('Punto di vista', selectEl([['terza persona', 'Terza persona'], ['prima persona', 'Prima persona'], ['seconda persona', 'Seconda persona (tu)']], n.pov || 'terza persona', (v) => { n.pov = v; })),
          field('Argomenti da evitare', inp(n, 'avoid', 'Es. violenza esplicita, politica', 300))),
        field('Regole di scrittura', ta(n, 'rules', 'Es. frasi brevi, niente parolacce, sempre un dettaglio sensoriale per scena', 3))]; },
      voice: () => { const vc = P.voiceCfg = P.voiceCfg || {}; const slider = (k, lbl, min, max, step) => { const e = h('input', { type: 'range', min, max, step, value: vc[k] ?? (k === 'speed' ? 1 : 0.5), class: 'crop-zoom' }); const out = h('span', { class: 'ai-sv' }, String(vc[k] ?? e.value)); e.addEventListener('input', () => { vc[k] = +e.value; out.textContent = e.value; mark(); }); return field(lbl, h('div', { class: 'crop-row' }, e, out)); };
        return [h('h2', null, 'Voci'), h('p', { class: 'wz-p' }, 'La voce del narratore e le impostazioni valgono per tutte le storie. Ogni personaggio può avere la sua voce (in Personaggi).'),
          field('Servizio', selectEl([['', 'Automatico'], ['elevenlabs', 'ElevenLabs'], ['openai', 'OpenAI']], vc.provider || '', (v) => { vc.provider = v; voices = null; draw(); })),
          field('Voce del narratore', voicePicker(P.narrator, (v) => { P.narrator = v; })),
          h('div', { class: 'prof-grid' }, slider('speed', 'Velocità', 0.7, 1.2, 0.05), slider('stability', 'Stabilità', 0, 1, 0.05)),
          h('div', { class: 'prof-grid' }, slider('similarity', 'Somiglianza alla voce', 0, 1, 0.05), slider('style', 'Espressività', 0, 1, 0.05))]; },
      edit: () => { const ed = P.edit = P.edit || {}; return [h('h2', null, 'Montaggio'), h('p', { class: 'wz-p' }, 'Come vengono montati i video: sottotitoli e musica di sottofondo (si abbassa da sola quando si parla).'),
        field('Sottotitoli', seg(['Parola per parola', 'Frase intera'], ed.captions === 'line' ? 1 : 0, (i) => { ed.captions = i ? 'line' : 'word'; mark(); draw(); })),
        field('Musica di sottofondo', h('div', { class: 'ai-music' }, icon('music', 16), h('span', { 'data-notr': '' }, ed.music ? ed.music.name : 'Nessuna'),
          h('div', { class: 'grow' }), h('button', { class: 'btn sm', onclick: pickMusic }, ed.music ? 'Cambia' : 'Scegli'),
          ed.music ? h('button', { class: 'iconbtn', 'aria-label': 'Togli', onclick: async () => { const pg = await post('/api/ai/page/music', { page: P.id, path: '' }); P.edit = pg.edit; draw(); } }, icon('x', 14)) : null),
        'Usa solo musica che hai il diritto di usare (tua, royalty free o con licenza).'),
        field('Volume della musica', (() => { const e = h('input', { type: 'range', min: 5, max: 60, step: 1, value: ed.musicVol || 22, class: 'crop-zoom' }); const o = h('span', { class: 'ai-sv' }, (ed.musicVol || 22) + '%'); e.addEventListener('input', () => { ed.musicVol = +e.value; o.textContent = e.value + '%'; mark(); }); return h('div', { class: 'crop-row' }, e, o); })())]; },
      models: () => { const mk = (what, cfgKey) => { const c = P[cfgKey] = P[cfgKey] || {}; const provs = Object.keys(S.models[what]).filter((p) => S.keys[p]); const list = h('datalist', { id: 'dl-' + what }, ...(S.models[what][c.provider] || []).map((m) => h('option', { value: m })));
        const mdl = h('input', { class: 'input', list: 'dl-' + what, value: c.model || '', placeholder: 'Modello consigliato' }); mdl.addEventListener('input', () => { c.model = mdl.value.trim(); mark(); });
        return h('div', { class: 'prof-grid' }, field(DOES[what], selectEl([['', 'Automatico (quello collegato)'], ...provs.map((p) => [p, S.keys[p].name + (S.keys[p].set ? '' : ' (chiave mancante)')])], c.provider || '', (v) => { c.provider = v; c.model = ''; draw(); })),
          field('Modello', h('div', null, mdl, list))); };
        return [h('h2', null, 'Modelli AI'), h('p', { class: 'wz-p' }, 'Quale servizio usa questa pagina per testi, immagini e voce. "Automatico" sceglie tra quelli che hai collegato. Puoi scrivere anche un modello nuovo appena esce.'),
          mk('text', 'textCfg'), mk('image', 'imageCfg'), mk('voice', 'voiceCfg'),
          h('p', { class: 'field-note' }, 'Per tenere uguali i personaggi con le foto di riferimento: fal.ai "nano-banana-2/edit", Gemini "flash-image" o OpenAI "gpt-image-1".')]; },
    };
    async function addRef(c) {
      if (!P.id || dirty) { const r = await save(false); if (!r) return; const cc = r.characters.find((x) => x.name === c.name) || r.characters[r.characters.length - 1]; c = cc; }
      try {
        const r = await post('/api/pick', { kind: 'media' });
        const f = (r.files || []).find((x) => x.kind === 'image'); if (!f) return;
        const pg = await post('/api/ai/page/ref', { page: P.id, char: c.id, path: f.path });
        P.characters = pg.characters; draw();
      } catch (e) { toast(e.message, true); }
    }
    async function pickMusic() {
      if (!P.id || dirty) { if (!await save(false)) return; }
      try {
        const r = await post('/api/pick', { kind: 'audio' }); const f = (r.files || [])[0]; if (!f) return;
        const pg = await post('/api/ai/page/music', { page: P.id, path: f.path }); P.edit = pg.edit; draw();
      } catch (e) { toast(e.message, true); }
    }
    function draw() {
      rc(nav2, ...TABS.map(([k, l, ic]) => h('button', { class: 'ai-tab' + (k === tab ? ' on' : ''), onclick: () => { tab = k; draw(); } }, icon(ic, 15), l)),
        h('div', { class: 'grow' }),
        !isNew ? h('button', { class: 'linkish danger ai-delpage', onclick: async () => {
          if (!await confirmBox('Eliminare la pagina?', 'Si cancellano il preset, i personaggi e le foto di riferimento. Le storie e i video restano.', 'Elimina', true)) return;
          await post('/api/ai/page/delete', { id: P.id }); nav('studio');
        } }, 'Elimina pagina') : null);
      rc(body, ...T[tab]().filter(Boolean));
      saveBtn.disabled = !dirty && !isNew;
    }
    app.append(topbar(-1, h('div', { class: 'ai-topact' }, h('button', { class: 'btn ghost', onclick: async () => {
      if (dirty && !await confirmBox('Uscire senza salvare?', 'Le modifiche alla pagina andranno perse.', 'Esci', true)) return; nav('studio', P.id);
    } }, 'Annulla'), saveBtn), false, { name: isNew ? 'Nuova pagina' : P.name, home: true }),
    h('main', { class: 'ai-page' }, nav2, h('div', { class: 'ai-pcard' }, body)));
    draw();
  }

  // ------------------------------------------------------------- storia: script → immagini → voce → video
  async function storyEditor(sid) {
    let D;
    try { D = await get('/api/ai/story?id=' + encodeURIComponent(sid)); } catch (e) { toast(e.message, true); return nav('studio'); }
    await load();
    let st = D.story, est = D.estimate;
    const page = D.page || { characters: [], name: '' };
    setTitle(st.title || 'Storia AI');
    let step = st.status === 'montata' ? 3 : ({ script: 0, scene: 1, produzione: 2 }[st.status] ?? 0);
    let busy = null;   // {kind, msg, prog}
    let saveT = 0;
    const STEPS = [['Script', 'Le frasi, scena per scena'], ['Immagini', 'Una per scena'], ['Voce', 'Narratore e personaggi'], ['Video', 'Montaggio automatico']];
    const head = h('div', { class: 'wz-steps' });
    const body = h('div', { class: 'wz-body ai-sbody' });
    const cost = h('div', { class: 'ai-cost' });
    const foot = h('div', { class: 'wz-foot' });
    const speakers = [['', 'Narratore'], ...(page.characters || []).map((c) => [c.name, c.name])];
    const persist = (now) => {
      clearTimeout(saveT);
      const doit = async () => { try { const r = await post('/api/ai/story/save', { id: st.id, title: st.title, scenes: st.scenes }); st = r.story; est = r.estimate; paintCost(); } catch (e) { toast(e.message, true); } };
      if (now) return doit();
      saveT = setTimeout(doit, 600);
    };
    const refresh = async () => { const r = await get('/api/ai/story?id=' + encodeURIComponent(st.id)); st = r.story; est = r.estimate; };
    function paintCost() {
      rc(cost, h('span', { 'data-tip': 'Quanto hai speso finora con i tuoi servizi (stima)' }, 'Speso ', h('b', null, usd(est.spent))),
        est.todo > 0 ? h('span', { 'data-tip': 'Stima di quello che manca: immagini ' + usd(est.imageUsd) + ' · voce ' + usd(est.voiceUsd) }, 'Da fare ~', h('b', null, usd(est.todo))) : null);
    }
    async function runJob(kind, url, payload, msg, after) {
      if (busy) return;
      busy = { kind, msg, prog: 0 }; draw();
      let tick = null;
      try {
        const job = await post(url, { story: st.id, ...payload });
        tick = setInterval(async () => { try { await refresh(); if (!busy) return; paintBody(); paintCost(); } catch (e) { /* */ } }, 2500);
        const r = await pollJob(job.id, (j) => { if (busy) { busy.prog = j.progress; busy.msg = j.message || msg; paintBusy(); } });
        if (r.status === 'error') throw new Error(r.error || 'Non riuscito');
        if (r.result && r.result.errors) toast(r.result.errors + ' non riuscite: ' + (r.result.first || ''), true);
        await refresh();
        busy = null; draw();
        after && after(r.result);
      } catch (e) { busy = null; await refresh().catch(() => {}); draw(); toast(e.message, true); }
      finally { clearInterval(tick); }
    }
    setCleanup(() => { clearTimeout(saveT); });
    const busyEl = h('div', { class: 'ai-jobbar', hidden: true });
    function paintBusy() {
      busyEl.hidden = !busy;
      if (!busy) return;
      rc(busyEl, h('div', { class: 'spinner' }), h('span', null, busy.msg || 'Lavoro…'), h('div', { class: 'progress' }, h('div', { style: { width: Math.round((busy.prog || 0) * 100) + '%' } })));
    }
    function drawHead() {
      rc(head, ...STEPS.map(([t, sub], k) => h('button', { class: 'wz-st' + (k === step ? ' on' : k < step ? ' done' : ''), disabled: busy ? true : null, onclick: () => { step = k; draw(); } },
        h('span', { class: 'n' }, k < step ? icon('check', 11, '#fff', 3.5) : String(k + 1)), h('span', { class: 't' }, h('b', null, t), h('small', null, sub)))));
    }
    // --- 1. script
    function stepScript() {
      const total = st.scenes.reduce((s, x) => s + ((x.audio && x.audio.text === x.text && x.audio.dur) || secsOf(x.text)), 0);
      const rows = st.scenes.map((sc, i) => {
        const txt = h('textarea', { class: 'ai-line', rows: 1, disabled: sc.locked ? true : null }); txt.value = sc.text;
        const fit = () => { txt.style.height = 'auto'; txt.style.height = txt.scrollHeight + 'px'; };
        txt.addEventListener('input', () => { sc.text = txt.value; fit(); persist(); });
        setTimeout(fit, 0);
        const sp = h('select', { class: 'ai-spk', disabled: sc.locked ? true : null }, ...speakers.map(([v, l]) => h('option', { value: v, selected: v === (sc.speaker || '') ? true : null }, l)));
        sp.addEventListener('change', () => { sc.speaker = sp.value; persist(); });
        return h('div', { class: 'ai-row' + (sc.locked ? ' locked' : '') },
          h('span', { class: 'ai-n' }, String(i + 1)),
          h('div', { class: 'ai-rmain' }, sp, txt, sc.error ? h('p', { class: 'ai-err' }, sc.error) : null),
          h('span', { class: 'ai-sec' }, secsOf(sc.text).toFixed(1) + ' s'),
          h('div', { class: 'ai-ract' },
            h('button', { class: 'iconbtn', 'data-tip': 'Riscrivi questa scena con l\'AI', disabled: sc.locked || busy ? true : null, onclick: () => rewrite(i) }, icon('wand', 14)),
            h('button', { class: 'iconbtn', 'data-tip': sc.locked ? 'Sblocca' : 'Blocca: non verrà più cambiata', onclick: () => { sc.locked = !sc.locked; persist(true); paintBody(); } }, icon(sc.locked ? 'lock' : 'unlock', 14)),
            h('button', { class: 'iconbtn', 'data-tip': 'Aggiungi una scena sotto', onclick: () => { st.scenes.splice(i + 1, 0, { id: '', speaker: '', text: '…', visual: '', motion: 'zoomIn' }); persist(true).then(paintBody); } }, icon('plus', 14)),
            h('button', { class: 'iconbtn', 'data-tip': 'Togli la scena', disabled: sc.locked || st.scenes.length < 2 ? true : null, onclick: () => { st.scenes.splice(i, 1); persist(true).then(paintBody); } }, icon('trash', 14))));
      });
      const title = h('input', { class: 'input big ai-title', value: st.title || '', 'aria-label': 'Titolo', maxlength: 120 });
      title.addEventListener('input', () => { st.title = title.value; persist(); });
      return [h('div', { class: 'ai-shead' }, title, h('span', { class: 'wz-count' }, st.scenes.length + ' scene · ~' + fmt(total))),
        h('p', { class: 'wz-p' }, 'Modifica le frasi come vuoi. La bacchetta riscrive una sola scena, il lucchetto la blocca. Ogni frase diventa una scena con la sua immagine.'),
        h('div', { class: 'ai-rows' }, ...rows)];
    }
    function rewrite(i) {
      const bg = h('div', { class: 'modal-bg' });
      const inp = h('input', { class: 'input', placeholder: 'Es. più misteriosa, più corta, aggiungi un dettaglio sul rumore' });
      const go = () => { bg.remove(); runJob('scene', '/api/ai/story/scene', { i, instruction: inp.value }, 'Riscrivo la scena ' + (i + 1)); };
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
      bg.append(h('div', { class: 'modal' }, h('h2', null, 'Riscrivi la scena ' + (i + 1)), h('p', { class: 'wz-p', 'data-notr': '' }, st.scenes[i].text),
        h('div', { class: 'field' }, h('label', null, 'Come la vuoi? (facoltativo)'), inp),
        h('div', { class: 'crop-btns' }, h('button', { class: 'btn ghost', onclick: () => bg.remove() }, 'Annulla'), h('button', { class: 'btn primary', onclick: go }, icon('wand', 14, '#fff'), 'Riscrivi'))));
      bg.addEventListener('click', (e) => { if (e.target === bg) bg.remove(); });
      document.body.append(bg); setTimeout(() => inp.focus(), 30);
    }
    // --- 2. immagini
    function stepImages() {
      const missingN = st.scenes.filter((x) => !(x.image && x.image.file)).length;
      const cards = st.scenes.map((sc, i) => {
        const f = sc.image && sc.image.file;
        const vis = h('textarea', { class: 'ai-vis', rows: 3, disabled: sc.locked ? true : null, placeholder: 'Cosa si vede (in inglese)' }); vis.value = sc.visual || '';
        vis.addEventListener('input', () => { sc.visual = vis.value; persist(); });
        const mot = (MOTIONS.find(([k]) => k === sc.motion) || MOTIONS[0])[1];
        return h('div', { class: 'ai-card' + (sc.locked ? ' locked' : '') + (sc.error ? ' err' : '') },
          h('div', { class: 'ai-pic' }, f ? h('img', { src: mediaUrl(f), alt: '', loading: 'lazy' }) : h('span', { class: 'ai-ph' }, busy && busy.kind === 'images' && !sc.locked ? h('div', { class: 'spinner' }) : icon('image', 22)),
            h('span', { class: 'st-num' }, String(i + 1)),
            sc.locked ? h('span', { class: 'ai-lk' }, icon('lock', 11, '#fff', 2.4)) : null),
          h('div', { class: 'ai-ctx', 'data-notr': '' }, sc.speaker ? h('b', null, sc.speaker + ': ') : null, sc.text),
          sc.error ? h('p', { class: 'ai-err' }, sc.error) : null,
          vis,
          h('div', { class: 'ai-cact' },
            h('button', { class: 'st-mot', 'data-tip': 'Clic: cambia movimento', onclick: () => { const ids = MOTIONS.map(([k]) => k); sc.motion = ids[(ids.indexOf(sc.motion) + 1) % ids.length]; persist(); paintBody(); } }, icon('sparkle', 11), mot),
            h('div', { class: 'grow' }),
            h('button', { class: 'iconbtn', 'data-tip': sc.locked ? 'Sblocca' : 'Blocca questa immagine', onclick: () => { sc.locked = !sc.locked; persist(true); paintBody(); } }, icon(sc.locked ? 'lock' : 'unlock', 14)),
            h('button', { class: 'btn sm', disabled: sc.locked || busy ? true : null, onclick: async () => { await persist(true); runJob('images', '/api/ai/story/images', { only: [i] }, 'Creo l\'immagine ' + (i + 1)); } },
              icon(f ? 'undo' : 'sparkle', 13), f ? 'Rifai' : 'Crea')));
      });
      return [h('div', { class: 'ai-shead' }, h('h2', null, 'Immagini'), h('div', { class: 'grow' }),
        h('button', { class: 'btn sm', disabled: busy ? true : null, 'data-tip': 'Rifà le descrizioni dalle frasi attuali (dopo averle cambiate)', onclick: async () => { await persist(true); runJob('visuals', '/api/ai/story/visuals', {}, 'Aggiorno le descrizioni'); } }, icon('wand', 13), 'Aggiorna descrizioni'),
        h('button', { class: 'btn primary sm', disabled: busy || !missingN ? true : null, onclick: async () => { await persist(true); runJob('images', '/api/ai/story/images', {}, 'Creo le immagini'); } },
          icon('sparkle', 13, '#fff'), missingN ? `Crea ${missingN} immagini · ~${usd(est.imageUsd)}` : 'Tutte pronte')),
        h('p', { class: 'wz-p' }, 'Ogni immagine usa lo stile della pagina e le foto dei personaggi. Puoi cambiare la descrizione e rifare solo quella scena.'),
        h('div', { class: 'ai-cards' }, ...cards)];
    }
    // --- 3. voce
    let playing = null;
    function stepVoice() {
      const stale = (x) => !(x.audio && x.audio.file) || x.audio.text !== x.text;
      const todo = st.scenes.filter(stale).length;
      const rows = st.scenes.map((sc, i) => {
        const a = sc.audio;
        const ok = a && a.file && a.text === sc.text;
        const play = h('button', { class: 'ai-play', disabled: !(a && a.file) ? true : null, 'aria-label': 'Ascolta', onclick: () => {
          if (playing) { playing.pause(); if (playing._i === i) { playing = null; paintBody(); return; } }
          playing = new Audio(mediaUrl(a.file)); playing._i = i; playing.play().catch(() => {}); playing.onended = () => { playing = null; paintBody(); }; paintBody();
        } }, icon(playing && playing._i === i ? 'pause' : 'play', 14, 'currentColor'));
        return h('div', { class: 'ai-row ai-vrow' + (sc.locked ? ' locked' : '') },
          h('span', { class: 'ai-n' }, String(i + 1)), play,
          h('div', { class: 'ai-rmain' }, h('div', { class: 'ai-ctx', 'data-notr': '' }, h('b', null, (sc.speaker || 'Narratore') + ' '), sc.text),
            sc.error ? h('p', { class: 'ai-err' }, sc.error) : !ok ? h('small', { class: 'ai-warn' }, a && a.file ? 'La frase è cambiata: la voce va rifatta' : 'Voce da creare') : null),
          h('span', { class: 'ai-sec' }, ok ? (a.dur || 0).toFixed(1) + ' s' : '—'),
          h('button', { class: 'btn sm', disabled: sc.locked || busy ? true : null, onclick: () => runJob('voices', '/api/ai/story/voices', { only: [i] }, 'Creo la voce ' + (i + 1)) }, icon(a && a.file ? 'undo' : 'sparkle', 13), a && a.file ? 'Rifai' : 'Crea'));
      });
      return [h('div', { class: 'ai-shead' }, h('h2', null, 'Voce'), h('div', { class: 'grow' }),
        h('button', { class: 'btn primary sm', disabled: busy || !todo ? true : null, onclick: () => runJob('voices', '/api/ai/story/voices', {}, 'Creo le voci') },
          icon('sparkle', 13, '#fff'), todo ? `Crea ${todo} voci · ~${usd(est.voiceUsd)}` : 'Tutte pronte')),
        h('p', { class: 'wz-p' }, 'Ogni frase ha la sua voce: il narratore della pagina o quella del personaggio. Se cambi una frase, rifai solo quella voce.'),
        h('div', { class: 'ai-rows' }, ...rows)];
    }
    // --- 4. video
    function stepVideo() {
      const imgs = st.scenes.filter((x) => x.image && x.image.file).length;
      const vcs = st.scenes.filter((x) => x.audio && x.audio.file && x.audio.text === x.text).length;
      const dur = st.scenes.reduce((s, x) => s + ((x.audio && x.audio.text === x.text && x.audio.dur) || secsOf(x.text)) + 0.12, 0);
      const ed = (page.edit || {});
      const chk = (ok, t, sub) => h('div', { class: 'ai-chk' + (ok ? ' ok' : '') }, icon(ok ? 'check' : 'info', 15, 'currentColor', 2.4), h('span', null, h('b', null, t), h('small', null, sub)));
      return [h('h2', null, 'Monta il video'),
        h('p', { class: 'wz-p' }, 'Noonframe mette immagini, voce, sottotitoli e musica sulla timeline, con un movimento diverso per ogni scena. Poi puoi rifinire tutto nell\'editor.'),
        h('div', { class: 'ai-sum' },
          chk(imgs === st.scenes.length, imgs + ' / ' + st.scenes.length + ' immagini', imgs === st.scenes.length ? 'Pronte' : 'Le mancanti le creo io'),
          chk(vcs === st.scenes.length, vcs + ' / ' + st.scenes.length + ' voci', vcs === st.scenes.length ? 'Pronte' : 'Le mancanti le creo io'),
          chk(true, 'Durata ~' + fmt(dur), 'Formato 9:16, 1080×1920'),
          chk(true, ed.captions === 'line' ? 'Sottotitoli a frasi' : 'Sottotitoli parola per parola', ed.music ? 'Musica: ' + ed.music.name : 'Senza musica')),
        st.project ? h('div', { class: 'ai-done' }, icon('check', 16, 'currentColor', 2.6), h('span', null, 'Video già montato. Puoi aprirlo o rifarlo con le modifiche.'),
          h('div', { class: 'grow' }), h('button', { class: 'btn', onclick: () => nav('editor', st.project) }, icon('film', 14), 'Apri nell\'editor')) : null,
        h('button', { class: 'btn primary big ai-build', disabled: busy ? true : null, onclick: () => runJob('build', '/api/ai/story/build', {}, 'Monto il video', (r) => { if (r && r.project) nav('editor', r.project); }) },
          icon('sparkle', 16, '#fff'), st.project ? 'Rifai il video' : 'Crea il video' + (est.todo > 0 ? ' · ~' + usd(est.todo) : ''))];
    }
    function paintBody() { rc(body, ...[stepScript, stepImages, stepVoice, stepVideo][step]().filter(Boolean)); }
    function draw() {
      drawHead(); paintBusy(); paintCost(); paintBody();
      rc(foot, h('button', { class: 'btn ghost', onclick: () => (step ? (step--, draw()) : nav('studio', st.page)) }, icon('left', 15), step ? 'Indietro' : 'Storie'),
        h('div', { class: 'grow' }), busyEl,
        step < 3 ? h('button', { class: 'btn primary', disabled: busy ? true : null, onclick: async () => { await persist(true); step++; post('/api/ai/story/save', { id: st.id, status: ['script', 'scene', 'produzione', 'montata'][Math.min(step, 2)] }).catch(() => {}); draw(); } }, 'Avanti', icon('chev', 13, 'currentColor', 2.4)) : null);
    }
    app.append(topbar(-1, cost, false, { name: page.name || 'Storie AI', home: true }),
      h('main', { class: 'wizard' }, head, h('div', { class: 'wz-card' }, body, foot)));
    draw();
  }

  return { home, page: pageEditor, story: storyEditor, keysDialog };
}
