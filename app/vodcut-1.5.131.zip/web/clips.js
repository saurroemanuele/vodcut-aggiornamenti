// NoonFrame - clip virali dalla live (stile Opus): l'AI trova i momenti migliori, ognuno e' gia' una clip verticale montata.
// Galleria con punteggio di viralita', titolo e motivo; anteprima al passaggio del mouse; ogni clip si apre nell'editor.
import { get, post, put, api, h, icon, toast, confirmBox, promptBox, pollJob, mediaUrl, thumbUrl, TOKEN } from './lib.js';
import { drawText } from './text.js';
import { ensureFont } from './fonts.js';

// scritta d'apertura delle clip: grande, bianca con contorno, l'ultima parola colorata
const HOOK_STYLE = { font: 'Montserrat', weight: 900, size: 0.056, color: '#FFFFFF', bold: true, upper: true, align: 'center', stroke: true,
  strokeColor: '#000000', strokeW: 0.16, shadow: true, hlColor: '#3DDC84', lineH: 1.06 };
const VW = 1080, VH = 1920;

export const scoreColor = (s) => (s == null ? 'var(--text3)' : s >= 90 ? '#3DDC84' : s >= 75 ? '#A3E635' : s >= 60 ? '#FFD60A' : '#FF9F43');
const mmss = (t) => { t = Math.max(0, Math.round(t || 0)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); };
const hms = (t) => { t = Math.max(0, Math.round(t || 0)); const hh = Math.floor(t / 3600); return (hh ? hh + ':' : '') + String(Math.floor(t / 60) % 60).padStart(hh ? 2 : 1, '0') + ':' + String(t % 60).padStart(2, '0'); };

function hookContent(txt) {
  const w = String(txt || '').trim().split(/\s+/).filter(Boolean);
  if (!w.length) return '';
  const last = w.length > 1 ? w.pop() : null;
  let lines = [w.join(' ')];
  // due righe quando e' lunga (si legge meglio sul telefono)
  if ((w.join(' ') + (last ? ' ' + last : '')).length > 16 && w.length > 1) {
    const k = Math.ceil(w.length / 2);
    lines = [w.slice(0, k).join(' '), w.slice(k).join(' ')];
  }
  if (last) lines[lines.length - 1] = (lines[lines.length - 1] + ' *' + last + '*').trim();
  return lines.join('\n');
}

// disegna la scritta d'apertura con lo stesso motore dei testi dell'editor e la salva nella clip
async function bakeHooks(cid) {
  const ch = await get('/api/p/' + cid);
  let changed = false;
  await ensureFont(HOOK_STYLE.font);
  for (const t of ch.tracks || []) {
    for (const c of t.clips || []) {
      if (!c.isText || (c.file && c.text && c.text.font)) continue;
      const spec = { ...HOOK_STYLE, content: c.hook ? hookContent(c.text && c.text.content) : String((c.text && c.text.content) || '') };
      const cv = drawText(spec, VH);
      const natW = cv.width / VW, ar = cv.height / cv.width;
      const w = Math.min(0.9, natW);
      const blob = await new Promise((res) => cv.toBlob(res, 'image/png'));
      const r = await fetch(`/api/p/${cid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: blob });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Scritta non salvata');
      Object.assign(c, { file: j.path, text: spec, natW, ar, pos: { x: +((1 - w) / 2).toFixed(4), y: c.pos && c.pos.y != null ? c.pos.y : 0.33, w: +w.toFixed(4) } });
      changed = true;
    }
  }
  if (changed) await put('/api/p/' + cid, ch);
}

async function findJob(pid, kind) {
  try { return (await get('/api/jobs')).find((j) => j.pid === pid && j.kind === kind) || null; } catch (e) { return null; }
}

export async function screenClips(pid, ctx) {
  const { app, nav, setTitle, setCleanup, topbar } = ctx;
  let data = await post(`/api/p/${pid}/cliplist`);
  const parent = await get('/api/p/' + pid);
  setTitle('Clip · ' + parent.name);
  let alive = true, sort = 'score', minScore = 0, selecting = false, query = '';
  const selected = new Set();
  let job = await findJob(pid, 'clips');
  let pjob = await findJob(pid, 'clipprev');
  const working = new Set();   // clip con l'anteprima in preparazione
  const queued = new Set();   // clip che aspettano le anteprime in corso

  app.innerHTML = '';
  const right = h('div', { class: 'row' });
  app.append(topbar(-1, right, false, { parentName: parent.name, parent: pid, name: 'Clip virali', icon: 'phone', parentTip: 'Torna al video della live' }));
  const page = h('main', { class: 'cg' });
  app.append(page);

  // ---------------------------------------------------------------- barra: cosa cercare, ordina, filtra, seleziona
  const qIn = h('input', { class: 'cg-q', placeholder: 'Cosa cercare? Es. spaventi, momenti divertenti, giocate epiche (facoltativo)', maxlength: '300',
    value: (data.run && data.run.prompt) || '', 'aria-label': 'Cosa cercare nella live' });
  const findBtn = h('button', { class: 'btn primary', onclick: () => start() }, icon('sparkle', 14, '#fff', 2.2), 'Trova le clip');
  const searchIn = h('input', { class: 'cg-search', placeholder: 'Cerca nei titoli', 'aria-label': 'Cerca nei titoli',
    oninput: () => { query = searchIn.value.trim().toLowerCase(); drawGrid(); } });
  const tools = h('div', { class: 'cg-tools' });
  const status = h('div', { class: 'cg-status', style: { display: 'none' } });
  const grid = h('div', { class: 'cg-grid' });
  const selBar = h('div', { class: 'cg-selbar', style: { display: 'none' } });
  page.append(h('div', { class: 'cg-head' },
    h('div', { class: 'cg-title' }, h('h1', null, 'Clip virali'), h('span', { class: 'cg-count' })),
    h('div', { class: 'cg-find' }, qIn, findBtn)), status, tools, grid, selBar);

  function drawTools() {
    const n = data.clips.length;
    page.querySelector('.cg-count').textContent = n ? String(n) : '';
    tools.style.display = n ? '' : 'none';
    tools.replaceChildren(...[
      h('div', { class: 'cg-tl' }, searchIn),
      h('div', { class: 'cg-tl' },
        h('div', { class: 'seg cg-seg', role: 'group', 'aria-label': 'Ordina' },
          ...[['score', 'Più virali'], ['time', 'Ordine nella live']].map(([k, l]) => h('button', { class: sort === k ? 'on' : '', type: 'button', onclick: () => { sort = k; drawTools(); drawGrid(); } }, l))),
        h('div', { class: 'seg cg-seg', role: 'group', 'aria-label': 'Punteggio minimo' },
          ...[[0, 'Tutte'], [70, '70+'], [85, '85+']].map(([k, l]) => h('button', { class: minScore === k ? 'on' : '', type: 'button', onclick: () => { minScore = k; drawTools(); drawGrid(); } }, l))),
        n ? h('button', { class: 'btn sm' + (selecting ? ' on' : ''), type: 'button', onclick: () => { selecting = !selecting; selected.clear(); drawTools(); drawGrid(); drawSel(); } },
          icon('check', 13, 'currentColor', 2.2), selecting ? 'Fine' : 'Seleziona') : null)].filter(Boolean));
  }

  function visible() {
    let l = data.clips.filter((c) => (c.score == null || c.score >= minScore) && (!query || String(c.name || '').toLowerCase().includes(query)));
    l = l.slice().sort((a, b) => (sort === 'time' ? a.a - b.a : (b.score ?? -1) - (a.score ?? -1) || a.a - b.a));
    return l;
  }

  // ---------------------------------------------------------------- scheda di una clip
  function card(c) {
    const pv = h('div', { class: 'cg-pv' });
    const posterSrc = c.poster ? mediaUrl(c.poster) + '&v=' + Math.round(c.previewAt || 0) : thumbUrl(pid, Math.min((data.duration || 1) - 0.5, c.a + 1), 480);
    const img = h('img', { class: 'cg-poster' + (c.poster ? '' : ' raw'), src: posterSrc, alt: '', loading: 'lazy', draggable: 'false' });
    pv.append(img);
    let vid = null;
    if (c.preview) {
      pv.addEventListener('pointerenter', () => {
        if (selecting) return;
        if (!vid) { vid = h('video', { class: 'cg-vid', src: mediaUrl(c.preview) + '&v=' + Math.round(c.previewAt || 0), muted: true, loop: true, playsinline: true, preload: 'auto' }); vid.muted = true; pv.append(vid); }
        vid.currentTime = 0; vid.play().catch(() => {});
      });
      pv.addEventListener('pointerleave', () => { if (vid) vid.pause(); });
    }
    if (working.has(c.id) || queued.has(c.id) || (!c.preview && (pjob || job))) pv.append(h('div', { class: 'cg-wait' }, h('span', { class: 'spinner sm' }), h('span', null, 'Preparo l\'anteprima')));
    else if (!c.preview) pv.append(h('div', { class: 'cg-wait soft' }, h('span', null, 'Anteprima non pronta')));
    if (c.edited) pv.append(h('span', { class: 'cg-badge' }, 'Modificato'));
    pv.append(h('span', { class: 'cg-time' }, h('b', null, mmss(c.dur)), h('span', null, 'da ' + hms(c.a))));
    if (selecting) pv.append(h('span', { class: 'cg-check' + (selected.has(c.id) ? ' on' : '') }, icon('check', 14, '#fff', 3)));
    const el = h('article', { class: 'cg-card' + (selected.has(c.id) ? ' sel' : ''), tabindex: '0', 'aria-label': c.name },
      pv,
      h('div', { class: 'cg-meta' },
        h('div', { class: 'cg-row' },
          h('b', { class: 'cg-score', style: { color: scoreColor(c.score) }, 'data-tip': 'Punteggio di viralità (0-100)' }, c.score != null ? String(c.score) : '–'),
          h('div', { class: 'cg-acts' },
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Esporta', 'data-tip': 'Esporta il video', onclick: (e) => { e.stopPropagation(); exportClips([c.id]); } }, icon('download', 17, 'currentColor', 2)),
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Modifica', 'data-tip': 'Modifica nell\'editor', onclick: (e) => { e.stopPropagation(); openClip(c); } }, icon('scissors', 17, 'currentColor', 2)),
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Altro', 'data-tip': 'Altro', onclick: (e) => { e.stopPropagation(); more(c, e.currentTarget); } }, icon('dots', 17, 'currentColor', 2)))),
        h('h3', { class: 'cg-name', 'data-notr': '' }, c.name),
        c.why ? h('p', { class: 'cg-why' }, c.why) : null));
    el.addEventListener('click', () => { if (selecting) { selected.has(c.id) ? selected.delete(c.id) : selected.add(c.id); drawGrid(); drawSel(); } else player(c); });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') el.click(); });
    return el;
  }

  function drawGrid() {
    const l = visible();
    if (!data.clips.length) { grid.replaceChildren(empty()); return; }
    if (!l.length) { grid.replaceChildren(h('div', { class: 'cg-none' }, 'Nessuna clip con questi filtri.')); return; }
    grid.replaceChildren(...l.map(card));
  }

  function empty() {
    const est = h('p', { class: 'cg-est' }, ' ');
    post(`/api/p/${pid}/clipestimate`).then((e) => {
      if (!alive) return;
      if (e.error) { est.textContent = e.error; return; }
      est.textContent = `Circa ${e.target} clip per questa live · lettura AI ~$${(+e.usd).toFixed(2)}` + (e.hasTranscript ? '' : ' · prima la trascrivo');
    }).catch(() => {});
    return h('div', { class: 'cg-empty' },
      h('div', { class: 'cg-empty-art' }, h('span'), h('span'), h('span')),
      h('h2', null, 'Le clip migliori della tua live, già montate'),
      h('p', null, 'L\'AI ascolta la live, trova i momenti che possono diventare virali e li trasforma in clip verticali: webcam sopra, gioco sotto, sottotitoli grandi e silenzi tolti. Ogni clip ha un punteggio e il motivo.'),
      est,
      h('button', { class: 'btn primary lg', onclick: () => start() }, icon('sparkle', 15, '#fff', 2.2), 'Trova le clip virali'));
  }

  function drawSel() {
    if (!selecting) { selBar.style.display = 'none'; return; }
    selBar.style.display = '';
    const n = selected.size;
    selBar.replaceChildren(h('span', null, n ? `${n} ${n === 1 ? 'clip selezionata' : 'clip selezionate'}` : 'Tocca le clip da scegliere'),
      h('button', { class: 'btn sm', type: 'button', onclick: () => { visible().forEach((c) => selected.add(c.id)); drawGrid(); drawSel(); } }, 'Tutte'),
      h('button', { class: 'btn sm danger', type: 'button', disabled: n ? null : true, onclick: () => removeClips([...selected]) }, icon('trash', 13, 'currentColor', 2), 'Elimina'),
      h('button', { class: 'btn sm primary', type: 'button', disabled: n ? null : true, onclick: () => exportClips([...selected]) }, icon('download', 13, '#fff', 2.2), 'Esporta'));
  }

  // ---------------------------------------------------------------- azioni
  async function openClip(c) {
    try { await bakeHooks(c.id); } catch (e) { /* la scritta la ridisegna l'editor */ }
    nav('editor', c.id);
  }
  async function exportClips(ids) {
    try {
      for (const id of ids) { const c = data.clips.find((x) => x.id === id); if (c && c.needsBake) await bakeHooks(id); }
    } catch (e) { return toast(e.message, true); }
    nav('export', pid, { vod: false, verticals: ids, back: pid, backTo: 'clips' });
  }
  async function rename(c) {
    const nm = await promptBox('Rinomina la clip', 'È anche il nome del file quando la esporti.', c.name, 'Rinomina');
    if (!nm || nm === c.name) return;
    try { await post(`/api/p/${c.id}/rename`, { name: nm }); await post(`/api/p/${pid}/cliprename`, { id: c.id, name: nm }); } catch (e) { return toast(e.message, true); }
    c.name = nm; drawGrid();
  }
  async function removeClips(ids) {
    const one = ids.length === 1;
    if (!await confirmBox(one ? 'Eliminare la clip?' : `Eliminare ${ids.length} clip?`, 'Il video della live resta com\'è.', 'Elimina', true)) return;
    for (const id of ids) {
      try { await api('DELETE', '/api/p/' + id); } catch (e) { /* gia' tolta */ }
      try { await post(`/api/p/${pid}/clipremove`, { id }); } catch (e) { /* */ }
    }
    data.clips = data.clips.filter((c) => !ids.includes(c.id));
    selected.clear(); drawTools(); drawGrid(); drawSel();
  }
  function more(c, at) {
    document.querySelectorAll('.popmenu').forEach((x) => x.remove());
    const it = (ic, label, fn, cls) => h('button', { class: 'pm-it' + (cls ? ' ' + cls : ''), role: 'menuitem', onclick: () => { close(); fn(); } },
      h('span', { class: 'pm-ic' }, icon(ic, 16, cls === 'danger' ? 'var(--danger)' : 'currentColor')), h('span', { class: 'pm-tx' }, h('b', null, label)));
    const m = h('div', { class: 'popmenu cg-menu', role: 'menu' },
      it('play', 'Guarda', () => player(c)), it('type', 'Rinomina', () => rename(c)), it('refresh', 'Aggiorna l\'anteprima', () => refresh([c.id])),
      it('trash', 'Elimina', () => removeClips([c.id]), 'danger'));
    document.body.append(m);
    const r = at.getBoundingClientRect();
    m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, r.right - m.offsetWidth)) + 'px';
    m.style.top = (r.bottom + m.offsetHeight + 8 < innerHeight ? r.bottom + 6 : r.top - m.offsetHeight - 6) + 'px';
    const close = () => { m.remove(); removeEventListener('pointerdown', out, true); };
    const out = (e) => { if (!m.contains(e.target)) close(); };
    setTimeout(() => addEventListener('pointerdown', out, true), 0);
  }

  // finestra per guardare una clip con l'audio, con il punteggio e il motivo
  function player(c) {
    const list = visible();
    let idx = list.findIndex((x) => x.id === c.id);
    const bg = h('div', { class: 'modal-bg cg-modal-bg' });
    const box = h('div', { class: 'cg-modal', role: 'dialog', 'aria-modal': 'true' });
    const close = () => { bg.remove(); removeEventListener('keydown', key); };
    const key = (e) => { if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') go(1); if (e.key === 'ArrowLeft') go(-1); };
    function go(d) { if (list.length < 2) return; idx = (idx + d + list.length) % list.length; draw(); }
    function draw() {
      const x = list[idx];
      const media = x.preview ? h('video', { class: 'cg-mvid', src: mediaUrl(x.preview) + '&v=' + Math.round(x.previewAt || 0), poster: x.poster ? mediaUrl(x.poster) : null, controls: true, autoplay: true, playsinline: true })
        : h('div', { class: 'cg-mnone' }, h('img', { src: thumbUrl(pid, x.a + 1, 640), alt: '' }), h('span', null, 'L\'anteprima non è ancora pronta'));
      box.replaceChildren(...[
        h('button', { class: 'iconbtn cg-mx', 'aria-label': 'Chiudi', onclick: close }, icon('x', 18, 'currentColor', 2)),
        list.length > 1 ? h('button', { class: 'iconbtn cg-mnav l', 'aria-label': 'Clip precedente', onclick: () => go(-1) }, icon('left', 20, 'currentColor', 2.2)) : null,
        h('div', { class: 'cg-mstage' }, media),
        h('div', { class: 'cg-minfo' },
          h('div', { class: 'cg-mscore' }, h('b', { style: { color: scoreColor(x.score) } }, x.score != null ? String(x.score) : '–'), h('span', null, 'su 100 di viralità')),
          h('h2', { 'data-notr': '' }, x.name),
          x.why ? h('p', { class: 'cg-mwhy' }, x.why) : null,
          h('dl', { class: 'cg-mfacts' },
            h('dt', null, 'Durata'), h('dd', null, mmss(x.dur)),
            h('dt', null, 'Nella live'), h('dd', null, hms(x.a) + ' – ' + hms(x.b)),
            x.hook ? h('dt', null, 'Scritta d\'apertura') : null, x.hook ? h('dd', { 'data-notr': '' }, x.hook) : null),
          h('div', { class: 'cg-mbtns' },
            h('button', { class: 'btn primary', onclick: () => { close(); openClip(x); } }, icon('scissors', 14, '#fff', 2), 'Modifica'),
            h('button', { class: 'btn', onclick: () => { close(); exportClips([x.id]); } }, icon('download', 14, 'currentColor', 2), 'Esporta'))),
        list.length > 1 ? h('button', { class: 'iconbtn cg-mnav r', 'aria-label': 'Clip successiva', onclick: () => go(1) }, icon('right', 20, 'currentColor', 2.2)) : null].filter(Boolean));
    }
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
    bg.append(box); document.body.append(bg); addEventListener('keydown', key); draw();
  }

  // ---------------------------------------------------------------- ricerca con l'AI e anteprime
  function showStatus(j, label) {
    status.style.display = '';
    const pct = Math.round((j.progress || 0) * 100);
    status.replaceChildren(...[h('span', { class: 'spinner sm' }),
      h('div', { class: 'cg-st-tx' }, h('b', null, label), h('span', null, j.message || '…')),
      h('div', { class: 'cg-st-bar' }, h('div', { style: { width: pct + '%' } })),
      h('span', { class: 'cg-st-pct' }, pct + '%'),
      j.kind === 'clips' ? h('button', { class: 'btn sm', onclick: () => post(`/api/jobs/${j.id}/cancel`).catch(() => {}) }, 'Annulla') : null].filter(Boolean));
  }
  async function start() {
    if (job) return;
    if (data.clips.some((c) => c.ai && c.edited) || data.clips.length) {
      if (!await confirmBox('Cerco di nuovo le clip?', 'Le clip dell\'AI che non hai modificato vengono sostituite. Quelle che hai modificato restano.', 'Cerca di nuovo')) return;
    }
    try { job = await post(`/api/p/${pid}/clips`, { prompt: qIn.value.trim() }); } catch (e) { return toast(e.message, true); }
    findBtn.disabled = true;
    await follow();
  }
  async function follow() {
    if (!job) return;
    findBtn.disabled = true;
    drawGrid();
    showStatus(job, 'L\'AI cerca le clip');
    let r;
    try { r = await pollJob(job.id, (j) => { if (alive) showStatus(j, 'L\'AI cerca le clip'); }); } catch (e) { r = { status: 'error', error: e.message }; }
    job = null; findBtn.disabled = false;
    if (!alive) return;
    status.style.display = 'none';
    if (r.status !== 'done') { if (r.error && !/annullat/i.test(r.error)) toast(r.error, true); await reload(); return; }
    toast(`${(r.result.clips || []).length} clip pronte da guardare`);
    await reload();
    await previews();
  }
  async function reload() {
    try { data = await post(`/api/p/${pid}/cliplist`); } catch (e) { return; }
    if (alive) { drawTools(); drawGrid(); drawSel(); }
  }
  async function refresh(ids) {
    for (const id of ids) {
      try { await bakeHooks(id); } catch (e) { /* */ }
    }
    await previews(ids);
  }
  // anteprime: prima le scritte d'apertura (le disegna l'app), poi i video leggeri, che compaiono uno alla volta
  const tried = new Set();   // anteprime gia' provate in questa visita (se una non riesce non si riprova all'infinito)
  async function previews(only) {
    const need = (only || data.clips.filter((c) => (!c.preview || c.edited || c.needsBake) && !tried.has(c.id + ':' + (c.updated || 0))).map((c) => c.id))
      .filter((id) => data.clips.some((c) => c.id === id));
    if (!need.length) return;
    if (pjob) { need.forEach((id) => queued.add(id)); drawGrid(); return; }   // dopo quelle in corso
    for (const id of need) {
      const c = data.clips.find((x) => x.id === id);
      if (c && c.needsBake) { try { await bakeHooks(id); } catch (e) { console.warn(e); } }
    }
    if (pjob) return;
    need.forEach((id) => { working.add(id); const c = data.clips.find((x) => x.id === id); if (c) tried.add(c.id + ':' + (c.updated || 0)); });
    drawGrid();
    try { pjob = await post(`/api/p/${pid}/clippreview`, { ids: need }); } catch (e) { working.clear(); return toast(e.message, true); }
    await followPrev();
  }
  async function followPrev() {
    if (!pjob) return;
    let lastDone = -1;
    showStatus(pjob, 'Preparo le anteprime');
    const timer = setInterval(async () => {
      try {
        const d = await post(`/api/p/${pid}/cliplist`);
        if (!alive) return;
        const ready = d.clips.filter((c) => c.preview && working.has(c.id)).map((c) => c.id);
        if (ready.length !== lastDone) { lastDone = ready.length; ready.forEach((id) => working.delete(id)); data = d; drawGrid(); }
      } catch (e) { /* */ }
    }, 4000);
    try { await pollJob(pjob.id, (j) => { if (alive) showStatus(j, 'Preparo le anteprime'); }); } catch (e) { /* */ }
    clearInterval(timer);
    pjob = null; working.clear();
    if (!alive) return;
    status.style.display = 'none';
    await reload();
    const next = [...queued].filter((id) => data.clips.some((c) => c.id === id && (!c.preview || c.edited || c.needsBake)));
    queued.clear();
    if (next.length) await previews(next);
  }

  setCleanup(() => { alive = false; });
  drawTools(); drawGrid(); drawSel();
  if (job) follow();
  else if (pjob) followPrev();
  else if (data.clips.some((c) => !c.preview || c.edited || c.needsBake)) previews();
}
