// NoonFrame - grafiche animate (motion graphics): numeri che contano, grafici che crescono, liste, confronti, passi.
// Disegnate su una tela a ogni fotogramma, come i testi animati (kinetic.js): in anteprima dal vivo, per l'esportazione
// l'app prepara i fotogrammi PNG. Stile moderno: schede scure in vetro, un colore d'accento, Inter.

// [id, nome, descrizione, esempio]
export const MOTION_TPLS = [
  ['numero', 'Numero', 'Una cifra che conta fino al valore', { title: 'Fatturato in un anno', value: '+240%' }],
  ['barre', 'Barre', 'Grafico a barre che cresce', { title: 'Clienti al mese', items: [{ label: 'Gen', value: '12' }, { label: 'Mar', value: '28' }, { label: 'Mag', value: '47' }, { label: 'Lug', value: '90' }] }],
  ['linea', 'Crescita', 'Linea che sale con il valore finale', { title: 'Iscritti', items: [{ value: '2' }, { value: '3' }, { value: '2.6' }, { value: '5' }, { value: '7' }, { value: '11' }], value: '11K' }],
  ['lista', 'Checklist', 'Punti che si spuntano uno alla volta', { title: 'Cosa serve', items: [{ label: 'Un\'offerta chiara' }, { label: 'Un canale di vendita' }, { label: 'Processi scritti' }] }],
  ['confronto', 'Confronto', 'Prima e dopo, o questo contro quello', { items: [{ label: 'Lavoro', value: 'Tempo = soldi' }, { label: 'Azienda', value: 'Sistemi = soldi' }] }],
  ['passi', 'Passi', 'Passaggi collegati da una linea', { title: 'Il metodo', items: [{ label: 'Offerta' }, { label: 'Traffico' }, { label: 'Vendita' }] }],
  ['progresso', 'Percentuale', 'Anello che si riempie', { title: 'Tasso di conversione', value: '68%' }],
  // ---- componenti premium
  ['imbuto', 'Imbuto', 'Da tanti a pochi, passo dopo passo', { title: 'Dai contatti ai clienti', items: [{ label: 'Visite', value: '10.000' }, { label: 'Contatti', value: '800' }, { label: 'Chiamate', value: '120' }, { label: 'Clienti', value: '30' }] }],
  ['tempo', 'Linea del tempo', 'Tappe in ordine, con data o numero', { title: 'Come è andata', items: [{ label: '2021', value: 'Da solo' }, { label: '2023', value: '5 persone' }, { label: '2025', value: '30 persone' }] }],
  ['freccia', 'Da… a…', 'Freccia che sale da un valore a un altro', { title: 'In 12 mesi', items: [{ label: '1.000€' }, { label: '10.000€' }], value: 'x10' }],
  ['equazione', 'Formula', 'A + B = risultato', { items: [{ label: 'Offerta' }, { label: 'Traffico' }], value: 'Vendite' }],
  ['proporzione', 'Proporzione', 'Omini che si colorano: 3 su 10', { title: 'Chi ce la fa', value: '3 su 10' }],
  ['ciclo', 'Ciclo', 'Passaggi che girano in cerchio', { title: 'Il volano', items: [{ label: 'Contenuti' }, { label: 'Pubblico' }, { label: 'Clienti' }, { label: 'Soldi' }] }],
  ['piramide', 'Piramide', 'Livelli dalla base alla cima', { title: 'Cosa conta', items: [{ label: 'Abitudini' }, { label: 'Sistemi' }, { label: 'Risultati' }] }],
  ['podio', 'Classifica', 'Primo, secondo, terzo', { title: 'I migliori', items: [{ label: 'TikTok', value: '1' }, { label: 'YouTube', value: '2' }, { label: 'Instagram', value: '3' }] }],
  ['citazione', 'Citazione', 'Una frase grande, parola per parola', { title: 'Il tempo è la vera moneta', value: 'Naval' }],
  ['torta', 'Torta', 'Fette che si riempiono con le percentuali', { title: 'Dove vanno i soldi', items: [{ label: 'Team', value: '50%' }, { label: 'Ads', value: '30%' }, { label: 'Tool', value: '20%' }] }],
];
export const motionName = (id) => (MOTION_TPLS.find((m) => m[0] === id) || [0, 'Grafica'])[1];
export const MOTION_ACCENTS = ['#4F8CFF', '#8B7CFF', '#22C58B', '#FFB020', '#FF5C7A', '#FFFFFF'];

const cl = (x) => Math.max(0, Math.min(1, x));
const eOut = (p) => 1 - Math.pow(1 - cl(p), 3);
const eInOut = (p) => { p = cl(p); return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; };
const eBack = (p) => { p = cl(p); const c1 = 1.4, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
const FONT = 'Inter, "Plus Jakarta Sans", system-ui, sans-serif';

function hexA(hex, a) {
  let x = String(hex || '#4F8CFF').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
}
function mix(hex, k) {   // schiarisce verso il bianco
  let x = String(hex || '#4F8CFF').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  const f = (i) => Math.round(parseInt(x.slice(i, i + 2), 16) * (1 - k) + 255 * k);
  return `rgb(${f(0)},${f(2)},${f(4)})`;
}
// "12", "1.200", "+40%", "10K€" -> {pre, num, dec, post}
export function parseNum(s) {
  const m = String(s ?? '').match(/^(\D*?)(-?\d[\d.,]*)(.*)$/);
  if (!m) return null;
  let raw = m[2], dec = 0;
  if (/,\d{1,2}$/.test(raw)) { dec = raw.split(',')[1].length; raw = raw.replace(/\./g, '').replace(',', '.'); }
  else if (/\.\d{1,2}$/.test(raw) && !/\.\d{3}/.test(raw)) { dec = raw.split('.')[1].length; }
  else raw = raw.replace(/[.,]/g, '');
  const num = parseFloat(raw);
  return Number.isFinite(num) ? { pre: m[1], num, dec, post: m[3], sep: /\d\.\d{3}/.test(m[2]) } : null;
}
function fmtNum(p, v) {
  let s = v.toFixed(p.dec);
  if (p.sep) s = s.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  if (p.dec && /,/.test(String(p.num))) s = s.replace('.', ',');
  return p.pre + s + p.post;
}
function counting(val, k) {
  const p = parseNum(val);
  if (!p) return String(val ?? '');
  return fmtNum(p, p.num * eOut(k));
}
function rr(g, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function fitText(g, txt, maxW, size, weight) {
  let s = size;
  g.font = `${weight} ${s}px ${FONT}`;
  while (s > 6 && g.measureText(txt).width > maxW) { s *= 0.92; g.font = `${weight} ${s}px ${FONT}`; }
  return s;
}
// scheda in vetro scuro con bordo sottile e luce in alto
function card(g, x, y, w, h, u, acc, k) {
  g.save();
  g.globalAlpha = cl(k * 1.4);
  g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 6 * u; g.shadowOffsetY = 2 * u;
  rr(g, x, y, w, h, 3.2 * u);
  const bg = g.createLinearGradient(0, y, 0, y + h);
  bg.addColorStop(0, 'rgba(24,30,46,.92)'); bg.addColorStop(1, 'rgba(10,13,22,.92)');
  g.fillStyle = bg; g.fill();
  g.shadowColor = 'transparent';
  // bagliore del colore d'accento in un angolo
  const gl = g.createRadialGradient(x + w * 0.85, y, 0, x + w * 0.85, y, w * 0.7);
  gl.addColorStop(0, hexA(acc, 0.28)); gl.addColorStop(1, hexA(acc, 0));
  g.save(); rr(g, x, y, w, h, 3.2 * u); g.clip(); g.fillStyle = gl; g.fillRect(x, y, w, h); g.restore();
  rr(g, x + 0.5, y + 0.5, w - 1, h - 1, 3.2 * u);
  const bd = g.createLinearGradient(0, y, 0, y + h);
  bd.addColorStop(0, 'rgba(255,255,255,.22)'); bd.addColorStop(1, 'rgba(255,255,255,.06)');
  g.strokeStyle = bd; g.lineWidth = Math.max(1, 0.18 * u); g.stroke();
  g.restore();
}
function title(g, txt, x, y, maxW, u, k) {
  if (!txt) return;
  g.save();
  g.globalAlpha = cl(k * 2);
  const s = fitText(g, String(txt).toUpperCase(), maxW, 2.3 * u, 700);
  g.fillStyle = 'rgba(255,255,255,.62)';
  g.textBaseline = 'top';
  g.fillText(String(txt).toUpperCase(), x + (1 - eOut(k)) * 2 * u, y);
  g.restore();
  return s;
}

// dimensioni della tela per ogni modello (in unita' = 1% dell'altezza del video)
const SIZE = { numero: [44, 26], barre: [56, 38], linea: [56, 34], lista: [52, 0], confronto: [64, 26], passi: [70, 26], progresso: [40, 30] };

// stile pulito (di base): niente schede, testi grandi con ombra morbida, come nei video montati a mano
const CSIZE = { numero: [70, 34], barre: [74, 46], linea: [74, 42], lista: [70, 0], confronto: [96, 30], passi: [96, 30], progresso: [48, 42],
  imbuto: [72, 54], tempo: [100, 26], freccia: [84, 48], equazione: [100, 26], proporzione: [72, 46], ciclo: [66, 60], piramide: [72, 52], podio: [72, 50], citazione: [92, 34], torta: [84, 48] };

// dopo quanti secondi la grafica e' ferma (gli elementi compaiono quando vengono detti)
export function motionSettle(spec) {
  const ts = (spec.items || []).map((i) => +i.t || 0);
  return Math.max(2.05, ...ts.map((x) => x + 0.9));
}

export function motionSize(spec, H) {
  const u = H / 100;
  if (spec.style !== 'scheda' || !SIZE[spec.tpl]) {
    const [w, h0] = CSIZE[spec.tpl] || CSIZE.numero;
    const n = Math.max(1, Math.min(5, (spec.items || []).length || 3));
    const h = spec.tpl === 'lista' ? 12 + n * 8 : h0;
    const pad = 4;
    return [Math.round((w + pad * 2) * u), Math.round((h + pad * 2) * u), u, pad * u];
  }
  const [w, h0] = SIZE[spec.tpl] || SIZE.numero;
  const n = Math.max(1, Math.min(5, (spec.items || []).length || 3));
  const h = spec.tpl === 'lista' ? 11 + n * 7.2 : h0;
  const pad = 4;   // spazio per l'ombra
  return [Math.round((w + pad * 2) * u), Math.round((h + pad * 2) * u), u, pad * u];
}

// disegna la grafica al tempo t (secondi dall'inizio della clip) sulla tela cv
// componenti premium nello stile "scheda": il disegno pulito sopra una scheda scura in vetro che entra per prima
let _pcOff = null;
function drawPremiumCard(spec, H, t, dur, cv) {
  cv = cv || document.createElement('canvas');
  const off = _pcOff || (_pcOff = document.createElement('canvas'));
  drawClean(spec, H, Math.max(0, t - 0.15), dur, off);
  if (cv.width !== off.width) cv.width = off.width;
  if (cv.height !== off.height) cv.height = off.height;
  const g = cv.getContext('2d'), u = H / 100, P = 2.2 * u, W0 = cv.width, H0 = cv.height;
  g.clearRect(0, 0, W0, H0);
  const kin = eOut(t / 0.5);
  if (kin <= 0) return cv;
  g.save();
  const sc = 0.94 + 0.06 * eBack(t / 0.55);
  g.translate(W0 / 2, H0 / 2 + (1 - kin) * 3 * u); g.scale(sc, sc); g.translate(-W0 / 2, -H0 / 2);
  card(g, P, P, W0 - 2 * P, H0 - 2 * P, u, spec.accent || '#4F8CFF', kin);
  g.globalAlpha = kin; g.drawImage(off, 0, 0);
  g.restore();
  return cv;
}

export function drawMotion(spec, H, t, dur, cv) {
  if (spec.style === 'scheda' && !SIZE[spec.tpl]) return drawPremiumCard(spec, H, t, dur, cv);
  if (spec.style !== 'scheda' || !SIZE[spec.tpl]) return drawClean(spec, H, t, dur, cv);
  cv = cv || document.createElement('canvas');
  const [W0, H0, u, P] = motionSize(spec, H);
  if (cv.width !== W0) cv.width = W0;
  if (cv.height !== H0) cv.height = H0;
  const g = cv.getContext('2d');
  g.clearRect(0, 0, W0, H0);
  const acc = spec.accent || '#4F8CFF';
  const w = W0 - 2 * P, h = H0 - 2 * P, x = P, y = P;
  // entrata della scheda (0,5 s); l'uscita la fa la clip (dissolvenza), cosi' dopo 2 s il fotogramma e' fermo
  const kin = eOut(t / 0.5);
  const k = kin;
  if (k <= 0) return cv;
  g.save();
  const sc = 0.92 + 0.08 * eBack(t / 0.55);
  g.globalAlpha = k;
  g.translate(W0 / 2, H0 / 2 + (1 - kin) * 3 * u); g.scale(sc, sc); g.translate(-W0 / 2, -H0 / 2);
  card(g, x, y, w, h, u, acc, kin);
  const T = Math.max(0, t - 0.2);   // il contenuto parte dopo la scheda
  const it = (spec.items || []).slice(0, 5);
  g.textBaseline = 'alphabetic';
  const tp = spec.tpl;
  if (tp === 'numero') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    const v = counting(spec.value, T / 1.1);
    const s = fitText(g, String(spec.value || ''), w - 6.4 * u, 11 * u, 800);
    g.font = `800 ${s}px ${FONT}`;
    const gr = g.createLinearGradient(0, y + 8 * u, 0, y + 20 * u);
    gr.addColorStop(0, '#FFFFFF'); gr.addColorStop(1, mix(acc, 0.35));
    g.fillStyle = gr;
    g.fillText(v, x + 3.2 * u, y + 19 * u);
    const bw = (w - 6.4 * u) * eInOut((T - 0.3) / 0.9);
    rr(g, x + 3.2 * u, y + h - 4 * u, w - 6.4 * u, 0.8 * u, 0.4 * u); g.fillStyle = 'rgba(255,255,255,.08)'; g.fill();
    if (bw > 0) { const bg = g.createLinearGradient(x, 0, x + w, 0); bg.addColorStop(0, acc); bg.addColorStop(1, mix(acc, 0.45)); rr(g, x + 3.2 * u, y + h - 4 * u, bw, 0.8 * u, 0.4 * u); g.fillStyle = bg; g.fill(); }
  } else if (tp === 'barre') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    const vals = it.map((i) => (parseNum(i.value) || { num: 0 }).num);
    const mx = Math.max(1e-6, ...vals.map(Math.abs));
    const n = Math.max(1, it.length), gx = x + 3.2 * u, gw = w - 6.4 * u, base = y + h - 6 * u, top = y + 11 * u;
    const bw = Math.min(8 * u, gw / n * 0.56), step = gw / n;
    g.strokeStyle = 'rgba(255,255,255,.07)'; g.lineWidth = Math.max(1, 0.12 * u);
    for (let l = 0; l < 3; l++) { const ly = top + (base - top) * l / 3; g.beginPath(); g.moveTo(gx, ly); g.lineTo(gx + gw, ly); g.stroke(); }
    it.forEach((i, j) => {
      const kk = eOut((T - 0.15 - j * 0.12) / 0.8);
      const bh = (base - top) * (vals[j] / mx) * kk;
      const bx = gx + step * j + (step - bw) / 2;
      const last = j === n - 1;
      const gr = g.createLinearGradient(0, base - bh, 0, base);
      if (last) { gr.addColorStop(0, mix(acc, 0.35)); gr.addColorStop(1, acc); } else { gr.addColorStop(0, 'rgba(255,255,255,.34)'); gr.addColorStop(1, 'rgba(255,255,255,.12)'); }
      if (bh > 0.5) { rr(g, bx, base - bh, bw, bh, 1.1 * u); g.fillStyle = gr; g.fill(); }
      if (last && bh > 0.5) { g.save(); g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 4 * u; rr(g, bx, base - bh, bw, bh, 1.1 * u); g.fillStyle = hexA(acc, 0.25); g.fill(); g.restore(); }
      g.globalAlpha = k * cl(kk * 1.5);
      g.font = `700 ${2.4 * u}px ${FONT}`; g.textAlign = 'center';
      g.fillStyle = last ? '#fff' : 'rgba(255,255,255,.8)';
      g.fillText(counting(i.value, kk), bx + bw / 2, base - bh - 1.2 * u);
      g.font = `600 ${2 * u}px ${FONT}`; g.fillStyle = 'rgba(255,255,255,.55)';
      g.fillText(String(i.label || '').slice(0, 12), bx + bw / 2, base + 3 * u);
      g.globalAlpha = k; g.textAlign = 'left';
    });
  } else if (tp === 'linea') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 20 * u, u, T / 0.4);
    const vals = it.map((i) => (parseNum(i.value) || { num: 0 }).num);
    if (vals.length < 2) vals.unshift(0);
    const mn = Math.min(...vals), mx = Math.max(...vals), rg = Math.max(1e-6, mx - mn);
    const gx = x + 3.2 * u, gw = w - 6.4 * u, top = y + 11 * u, base = y + h - 4 * u;
    const pts = vals.map((v, j) => [gx + gw * j / (vals.length - 1), base - (base - top) * (v - mn) / rg]);
    const pr = eInOut((T - 0.1) / 1.2);
    const upto = pr * (pts.length - 1), ni = Math.floor(upto), fr = upto - ni;
    const path = pts.slice(0, ni + 1);
    if (ni < pts.length - 1) path.push([pts[ni][0] + (pts[ni + 1][0] - pts[ni][0]) * fr, pts[ni][1] + (pts[ni + 1][1] - pts[ni][1]) * fr]);
    if (path.length > 1) {
      const ar = g.createLinearGradient(0, top, 0, base); ar.addColorStop(0, hexA(acc, 0.35)); ar.addColorStop(1, hexA(acc, 0));
      g.beginPath(); g.moveTo(path[0][0], base); path.forEach(([px, py]) => g.lineTo(px, py)); g.lineTo(path[path.length - 1][0], base); g.closePath(); g.fillStyle = ar; g.fill();
      g.beginPath(); path.forEach(([px, py], j) => (j ? g.lineTo(px, py) : g.moveTo(px, py)));
      g.strokeStyle = mix(acc, 0.2); g.lineWidth = 0.7 * u; g.lineJoin = 'round'; g.lineCap = 'round';
      g.save(); g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 3 * u; g.stroke(); g.restore();
      const [ex, ey] = path[path.length - 1];
      const pulse = 1;
      g.beginPath(); g.arc(ex, ey, 1.2 * u * pulse, 0, Math.PI * 2); g.fillStyle = '#fff'; g.fill();
      g.beginPath(); g.arc(ex, ey, 2.4 * u * pulse, 0, Math.PI * 2); g.fillStyle = hexA(acc, 0.3); g.fill();
    }
    if (spec.value) {
      g.globalAlpha = k * cl((T - 0.9) / 0.4);
      const s = fitText(g, String(spec.value), 16 * u, 5 * u, 800);
      g.font = `800 ${s}px ${FONT}`; g.textAlign = 'right'; g.fillStyle = '#fff';
      g.fillText(counting(spec.value, (T - 0.2) / 1.1), x + w - 3.2 * u, y + 7.6 * u);
      g.textAlign = 'left'; g.globalAlpha = k;
    }
  } else if (tp === 'lista') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    it.forEach((i, j) => {
      const kk = eOut((T - 0.2 - j * 0.28) / 0.45);
      const ry = y + 9.5 * u + j * 7.2 * u;
      g.globalAlpha = k * kk;
      const ox = (1 - kk) * 4 * u;
      rr(g, x + 2.4 * u + ox, ry, w - 4.8 * u, 5.8 * u, 1.6 * u); g.fillStyle = 'rgba(255,255,255,.05)'; g.fill();
      const cx = x + 5.6 * u + ox, cy = ry + 2.9 * u, ck = eOut((T - 0.35 - j * 0.28) / 0.35);
      g.beginPath(); g.arc(cx, cy, 1.7 * u, 0, Math.PI * 2); g.fillStyle = ck > 0 ? acc : 'rgba(255,255,255,.15)'; g.fill();
      if (ck > 0) {
        g.beginPath(); g.moveTo(cx - 0.8 * u, cy); const p1 = [cx - 0.2 * u, cy + 0.7 * u], p2 = [cx + 0.9 * u, cy - 0.7 * u];
        g.lineTo(cx - 0.8 * u + (p1[0] - cx + 0.8 * u) * cl(ck * 2), cy + (p1[1] - cy) * cl(ck * 2));
        if (ck > 0.5) g.lineTo(p1[0] + (p2[0] - p1[0]) * cl(ck * 2 - 1), p1[1] + (p2[1] - p1[1]) * cl(ck * 2 - 1));
        g.strokeStyle = '#fff'; g.lineWidth = 0.45 * u; g.lineCap = 'round'; g.lineJoin = 'round'; g.stroke();
      }
      const s = fitText(g, String(i.label || ''), w - 13 * u, 2.3 * u, 650);
      g.font = `650 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textBaseline = 'middle';
      g.fillText(String(i.label || ''), x + 8.8 * u + ox, cy + 0.1 * u); g.textBaseline = 'alphabetic';
    });
    g.globalAlpha = k;
  } else if (tp === 'confronto') {
    const a = it[0] || {}, b = it[1] || {};
    const cw = (w - 9 * u) / 2;
    [[a, x + 2.4 * u, false, -1], [b, x + 6.6 * u + cw, true, 1]].forEach(([o, cx, good, dir], j) => {
      const kk = eOut((T - 0.1 - j * 0.25) / 0.55);
      g.globalAlpha = k * kk;
      const ox = (1 - kk) * 5 * u * dir;
      rr(g, cx + ox, y + 2.4 * u, cw, h - 4.8 * u, 2.2 * u);
      g.fillStyle = good ? hexA(acc, 0.16) : 'rgba(255,255,255,.04)'; g.fill();
      if (good) { g.strokeStyle = hexA(acc, 0.55); g.lineWidth = Math.max(1, 0.18 * u); g.stroke(); }
      const ic = [cx + ox + 3.6 * u, y + 7 * u];
      g.beginPath(); g.arc(ic[0], ic[1], 1.8 * u, 0, Math.PI * 2); g.fillStyle = good ? acc : 'rgba(255,90,110,.85)'; g.fill();
      g.strokeStyle = '#fff'; g.lineWidth = 0.45 * u; g.lineCap = 'round'; g.beginPath();
      if (good) { g.moveTo(ic[0] - 0.8 * u, ic[1]); g.lineTo(ic[0] - 0.15 * u, ic[1] + 0.7 * u); g.lineTo(ic[0] + 0.9 * u, ic[1] - 0.7 * u); }
      else { g.moveTo(ic[0] - 0.7 * u, ic[1] - 0.7 * u); g.lineTo(ic[0] + 0.7 * u, ic[1] + 0.7 * u); g.moveTo(ic[0] + 0.7 * u, ic[1] - 0.7 * u); g.lineTo(ic[0] - 0.7 * u, ic[1] + 0.7 * u); }
      g.stroke();
      let s = fitText(g, String(o.label || ''), cw - 9 * u, 3 * u, 800);
      g.font = `800 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textBaseline = 'middle';
      g.fillText(String(o.label || ''), cx + ox + 6.6 * u, ic[1] + 0.1 * u);
      s = fitText(g, String(o.value || ''), cw - 5 * u, 2.2 * u, 550);
      g.font = `550 ${s}px ${FONT}`; g.fillStyle = good ? 'rgba(255,255,255,.9)' : 'rgba(255,255,255,.55)';
      g.fillText(String(o.value || ''), cx + ox + 2.4 * u, y + 14.5 * u); g.textBaseline = 'alphabetic';
    });
    // VS al centro
    const kv = eBack((T - 0.45) / 0.4);
    if (kv > 0) {
      g.globalAlpha = k;
      const vx = x + w / 2, vy = y + h / 2;
      g.save(); g.translate(vx, vy); g.scale(kv, kv);
      g.beginPath(); g.arc(0, 0, 2.8 * u, 0, Math.PI * 2); g.fillStyle = '#0B0F18'; g.fill(); g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = Math.max(1, 0.18 * u); g.stroke();
      g.font = `800 ${2 * u}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff'; g.fillText('VS', 0, 0.1 * u);
      g.restore(); g.textAlign = 'left'; g.textBaseline = 'alphabetic';
    }
  } else if (tp === 'passi') {
    title(g, spec.title, x + 3.2 * u, y + 3 * u, w - 6.4 * u, u, T / 0.4);
    const n = Math.max(1, it.length), gx = x + 7 * u, gw = w - 14 * u, cy = y + 13 * u;
    const lp = eInOut((T - 0.2) / (0.28 * n + 0.2));
    g.strokeStyle = 'rgba(255,255,255,.12)'; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(gx, cy); g.lineTo(gx + gw, cy); g.stroke();
    const lg = g.createLinearGradient(gx, 0, gx + gw, 0); lg.addColorStop(0, acc); lg.addColorStop(1, mix(acc, 0.4));
    g.strokeStyle = lg; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(gx, cy); g.lineTo(gx + gw * (n > 1 ? lp : 1), cy); g.stroke();
    it.forEach((i, j) => {
      const px = n > 1 ? gx + gw * j / (n - 1) : gx + gw / 2;
      const kk = eBack((T - 0.2 - j * 0.28) / 0.4);
      if (kk <= 0) return;
      g.save(); g.translate(px, cy); g.scale(kk, kk);
      g.beginPath(); g.arc(0, 0, 2.6 * u, 0, Math.PI * 2);
      const cg = g.createLinearGradient(0, -2.6 * u, 0, 2.6 * u); cg.addColorStop(0, mix(acc, 0.3)); cg.addColorStop(1, acc);
      g.fillStyle = cg; g.shadowColor = hexA(acc, 0.7); g.shadowBlur = 3 * u; g.fill(); g.shadowBlur = 0;
      g.font = `800 ${2.2 * u}px ${FONT}`; g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(j + 1), 0, 0.15 * u);
      g.restore();
      g.globalAlpha = k * cl(kk);
      const s = fitText(g, String(i.label || ''), gw / n + 4 * u, 2.1 * u, 650);
      g.font = `650 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textAlign = 'center'; g.fillText(String(i.label || ''), px, cy + 6.4 * u);
      g.textAlign = 'left'; g.globalAlpha = k;
    });
  } else if (tp === 'progresso') {
    const p = parseNum(spec.value) || { num: 0 };
    const pct = Math.max(0, Math.min(100, p.num)) / 100;
    const cx = x + w / 2, cy = y + h / 2 - 1.5 * u, r = Math.min(w, h) * 0.3;
    const pr = eInOut((T - 0.1) / 1.2);
    g.lineCap = 'round';
    g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.strokeStyle = 'rgba(255,255,255,.08)'; g.lineWidth = 1.4 * u; g.stroke();
    if (pr > 0) {
      const ag = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r); ag.addColorStop(0, mix(acc, 0.4)); ag.addColorStop(1, acc);
      g.save(); g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 3 * u;
      g.beginPath(); g.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * pct * pr); g.strokeStyle = ag; g.lineWidth = 1.4 * u; g.stroke(); g.restore();
    }
    const s = fitText(g, String(spec.value || ''), r * 1.5, r * 0.62, 800);
    g.font = `800 ${s}px ${FONT}`; g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(counting(spec.value, (T - 0.1) / 1.2), cx, cy + 0.2 * u);
    if (spec.title) { const s2 = fitText(g, String(spec.title), w - 6 * u, 1.9 * u, 650); g.font = `650 ${s2}px ${FONT}`; g.fillStyle = 'rgba(255,255,255,.62)'; g.fillText(String(spec.title), cx, y + h - 3 * u); }
    g.textAlign = 'left'; g.textBaseline = 'alphabetic';
  }
  g.restore();
  return cv;
}

// dati puliti (dall'AI o dal pannello): testi corti, al massimo 5 elementi
export function cleanMotion(m) {
  const tpl = MOTION_TPLS.some((x) => x[0] === (m && m.tpl)) ? m.tpl : 'numero';
  const items = Array.isArray(m && m.items) ? m.items.slice(0, 5).map((i) => {
    const o = { label: String((i && i.label) || '').slice(0, 40), value: String((i && i.value) ?? '').slice(0, 20) };
    if (i && i.t != null && isFinite(+i.t)) o.t = +(+i.t).toFixed(2);
    return o;
  }) : [];
  return { tpl, title: String((m && m.title) || '').slice(0, 48), value: String((m && m.value) ?? '').slice(0, 16), items, accent: (m && m.accent) || '#4F8CFF',
    style: m && m.style === 'scheda' ? 'scheda' : 'pulito' };
}

// ---------------------------------------------------------------- stile pulito
// quando compare l'elemento i: al tempo detto nel video (item.t) o uno dopo l'altro
const revealAt = (spec, i, base = 0.25, gap = 0.3) => {
  const it = (spec.items || [])[i];
  return it && it.t != null && isFinite(+it.t) ? Math.max(0.05, +it.t) : base + i * gap;
};
function shadowed(g, u, fn) {
  g.save();
  g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = 3.2 * u; g.shadowOffsetY = 0.6 * u;
  fn();
  g.restore();
}
function bigText(g, txt, x, y, size, weight, color, align = 'center') {
  g.font = `${weight} ${size}px ${FONT}`; g.textAlign = align; g.textBaseline = 'middle';
  g.fillStyle = color; g.fillText(txt, x, y);
}
function popScale(k) { return 0.6 + 0.4 * eBack(k); }

function drawClean(spec, H, t, dur, cv) {
  cv = cv || document.createElement('canvas');
  const [W0, H0, u, P] = motionSize(spec, H);
  if (cv.width !== W0) cv.width = W0;
  if (cv.height !== H0) cv.height = H0;
  const g = cv.getContext('2d');
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(0, 0, W0, H0);
  const acc = spec.accent || '#4F8CFF';
  const w = W0 - 2 * P, h = H0 - 2 * P, x = P, y = P;
  const it = (spec.items || []).slice(0, 5);
  const tp = spec.tpl;
  const titleK = eOut(t / 0.35);
  const drawTitle = (ty, size = 2.8) => {
    if (!spec.title) return;
    g.save(); g.globalAlpha = titleK;
    const s2 = fitText(g, String(spec.title).toUpperCase(), w * 0.9, size * u, 800);
    shadowed(g, u, () => { g.font = `800 ${s2}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = 'rgba(255,255,255,.85)';
      g.letterSpacing = '0.12em'; g.fillText(String(spec.title).toUpperCase(), x + w / 2, ty + (1 - titleK) * 1.5 * u); });
    g.restore();
  };
  if (tp === 'passi') {
    drawTitle(y + 3 * u);
    const n = Math.max(1, it.length), cy = y + h * 0.6;
    const labels = it.map((i) => String(i.label || i.value || ''));
    const sz = Math.min(12 * u, (w * 0.8) / Math.max(1, labels.reduce((m, l) => m + Math.max(2, l.length), 0) * 0.62 + (n - 1) * 1.6));
    g.font = `900 ${sz}px ${FONT}`;
    const ws = labels.map((l) => g.measureText(l).width), arrow = sz * 1.6;
    const total = ws.reduce((a, b) => a + b, 0) + arrow * (n - 1);
    let px = x + (w - total) / 2;
    labels.forEach((l, i) => {
      const k = eOut((t - revealAt(spec, i)) / 0.35);
      const cx = px + ws[i] / 2;
      if (k > 0) {
        const last = i === n - 1;
        g.save(); g.globalAlpha = cl(k * 1.4);
        g.translate(cx, cy); const sc = popScale(k); g.scale(sc, sc);
        shadowed(g, u, () => {
          if (last) { g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 5 * u; }
          const gr = g.createLinearGradient(0, -sz / 2, 0, sz / 2);
          gr.addColorStop(0, last ? mix(acc, 0.35) : '#FFFFFF'); gr.addColorStop(1, last ? acc : '#DDE3EE');
          bigText(g, l, 0, 0, sz, 900, gr);
        });
        g.restore();
      }
      px += ws[i];
      if (i < n - 1) {
        // freccia che si allunga verso il prossimo
        const ka = eInOut((t - revealAt(spec, i) - 0.15) / Math.max(0.25, (revealAt(spec, i + 1) - revealAt(spec, i)) * 0.8));
        if (ka > 0) {
          const ax0 = px + arrow * 0.18, ax1 = px + arrow * (0.18 + 0.64 * ka);
          shadowed(g, u, () => {
            g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = sz * 0.09; g.lineCap = 'round';
            g.beginPath(); g.moveTo(ax0, cy); g.lineTo(ax1, cy); g.stroke();
            if (ka > 0.9) { g.beginPath(); g.moveTo(ax1 - sz * 0.22, cy - sz * 0.2); g.lineTo(ax1, cy); g.lineTo(ax1 - sz * 0.22, cy + sz * 0.2); g.stroke(); }
          });
        }
        px += arrow;
      }
    });
  } else if (tp === 'numero') {
    drawTitle(y + 4 * u);
    const k = eOut(t / 0.4);
    g.save(); g.globalAlpha = cl(k * 1.5);
    const s = fitText(g, String(spec.value || ''), w * 0.92, 17 * u, 900);
    const cy = y + h * 0.58;
    g.translate(x + w / 2, cy); const sc = popScale(k); g.scale(sc, sc);
    shadowed(g, u, () => {
      g.shadowColor = hexA(acc, 0.7); g.shadowBlur = 6 * u;
      const gr = g.createLinearGradient(0, -s / 2, 0, s / 2); gr.addColorStop(0, '#FFFFFF'); gr.addColorStop(1, mix(acc, 0.25));
      bigText(g, counting(spec.value, (t - 0.1) / 1.1), 0, 0, s, 900, gr);
    });
    g.restore();
    const bw = w * 0.36 * eInOut((t - 0.4) / 0.7);
    if (bw > 0) { rr(g, x + w / 2 - bw / 2, y + h - 3.5 * u, bw, 0.9 * u, 0.45 * u); g.fillStyle = acc; g.fill(); }
  } else if (tp === 'barre') {
    drawTitle(y + 3 * u);
    const vals = it.map((i) => (parseNum(i.value) || { num: 0 }).num);
    const mx = Math.max(1e-6, ...vals.map(Math.abs));
    const n = Math.max(1, it.length), gw = w * 0.84, gx = x + (w - gw) / 2, base = y + h - 6 * u, top = y + 12 * u;
    const step = gw / n, bw = Math.min(10 * u, step * 0.55);
    shadowed(g, u, () => { g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 0.35 * u; g.beginPath(); g.moveTo(gx - 1 * u, base); g.lineTo(gx + gw + 1 * u, base); g.stroke(); });
    it.forEach((i, j) => {
      const kk = eOut((t - revealAt(spec, j, 0.2, 0.18)) / 0.7);
      const bh = (base - top) * (vals[j] / mx) * kk;
      const bx = gx + step * j + (step - bw) / 2, last = j === n - 1;
      if (bh > 0.5) shadowed(g, u, () => {
        if (last) { g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 5 * u; }
        const gr = g.createLinearGradient(0, base - bh, 0, base);
        if (last) { gr.addColorStop(0, mix(acc, 0.35)); gr.addColorStop(1, acc); } else { gr.addColorStop(0, 'rgba(255,255,255,.95)'); gr.addColorStop(1, 'rgba(255,255,255,.65)'); }
        rr(g, bx, base - bh, bw, bh, 1.4 * u); g.fillStyle = gr; g.fill();
      });
      if (kk > 0) {
        g.save(); g.globalAlpha = cl(kk * 1.5);
        shadowed(g, u, () => { bigText(g, counting(i.value, kk), bx + bw / 2, base - bh - 2.4 * u, 3.2 * u, 900, '#fff');
          bigText(g, String(i.label || '').slice(0, 12), bx + bw / 2, base + 2.8 * u, 2.4 * u, 700, 'rgba(255,255,255,.9)'); });
        g.restore();
      }
    });
  } else if (tp === 'linea') {
    drawTitle(y + 3 * u);
    const vals = it.map((i) => (parseNum(i.value) || { num: 0 }).num);
    if (vals.length < 2) vals.unshift(0);
    const mn = Math.min(...vals), mx = Math.max(...vals), rg = Math.max(1e-6, mx - mn);
    const gx = x + w * 0.06, gw = w * 0.7, top = y + 12 * u, base = y + h - 5 * u;
    const pts = vals.map((v, j) => [gx + gw * j / (vals.length - 1), base - (base - top) * (v - mn) / rg]);
    const pr = eInOut((t - 0.15) / 1.3), upto = pr * (pts.length - 1), ni = Math.floor(upto), fr = upto - ni;
    const path = pts.slice(0, ni + 1);
    if (ni < pts.length - 1) path.push([pts[ni][0] + (pts[ni + 1][0] - pts[ni][0]) * fr, pts[ni][1] + (pts[ni + 1][1] - pts[ni][1]) * fr]);
    if (path.length > 1) {
      const ar = g.createLinearGradient(0, top, 0, base); ar.addColorStop(0, hexA(acc, 0.4)); ar.addColorStop(1, hexA(acc, 0));
      g.beginPath(); g.moveTo(path[0][0], base); path.forEach(([px2, py]) => g.lineTo(px2, py)); g.lineTo(path[path.length - 1][0], base); g.closePath(); g.fillStyle = ar; g.fill();
      shadowed(g, u, () => { g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 4 * u;
        g.beginPath(); path.forEach(([px2, py], j) => (j ? g.lineTo(px2, py) : g.moveTo(px2, py)));
        g.strokeStyle = mix(acc, 0.25); g.lineWidth = 1 * u; g.lineJoin = 'round'; g.lineCap = 'round'; g.stroke(); });
      const [ex, ey] = path[path.length - 1];
      g.beginPath(); g.arc(ex, ey, 1.6 * u, 0, Math.PI * 2); g.fillStyle = '#fff'; g.fill();
    }
    if (spec.value) {
      const k = eOut((t - 1.1) / 0.4);
      if (k > 0) { g.save(); g.globalAlpha = k; const s = fitText(g, String(spec.value), w * 0.26, 9 * u, 900);
        shadowed(g, u, () => bigText(g, counting(spec.value, (t - 0.2) / 1.2), x + w * 0.99, top + 3 * u, s, 900, '#fff', 'right')); g.restore(); }
    }
  } else if (tp === 'lista') {
    drawTitle(y + 3 * u);
    it.forEach((i, j) => {
      const k = eOut((t - revealAt(spec, j)) / 0.4);
      if (k <= 0) return;
      const ry = y + 11 * u + j * 8 * u, ox = (1 - k) * 4 * u;
      g.save(); g.globalAlpha = cl(k * 1.4);
      const cx = x + w * 0.12 + ox, cy = ry + 3 * u;
      shadowed(g, u, () => { g.beginPath(); g.arc(cx, cy, 2.2 * u, 0, Math.PI * 2); g.fillStyle = acc; g.fill(); });
      g.strokeStyle = '#fff'; g.lineWidth = 0.6 * u; g.lineCap = 'round'; g.lineJoin = 'round';
      g.beginPath(); g.moveTo(cx - 1 * u, cy); g.lineTo(cx - 0.25 * u, cy + 0.85 * u); g.lineTo(cx + 1.1 * u, cy - 0.85 * u); g.stroke();
      const s = fitText(g, String(i.label || ''), w * 0.78, 4 * u, 800);
      shadowed(g, u, () => bigText(g, String(i.label || ''), cx + 4 * u, cy + 0.1 * u, s, 800, '#fff', 'left'));
      g.restore();
    });
  } else if (tp === 'confronto') {
    const a = it[0] || {}, b = it[1] || {};
    const cy = y + h * 0.42;
    [[a, x + w * 0.25, false, 0], [b, x + w * 0.75, true, 1]].forEach(([o, cx, good, j]) => {
      const k = eOut((t - revealAt(spec, j, 0.15, 0.45)) / 0.45);
      if (k <= 0) return;
      g.save(); g.globalAlpha = cl(k * 1.4);
      g.translate(cx, cy); const sc = popScale(k); g.scale(sc, sc);
      const s = fitText(g, String(o.label || ''), w * 0.36, 7 * u, 900);
      shadowed(g, u, () => {
        if (good) { g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 5 * u; }
        bigText(g, String(o.label || ''), 0, 0, s, 900, good ? mix(acc, 0.2) : 'rgba(255,255,255,.75)');
      });
      // segno sopra: croce rossa o spunta
      const iy = -s * 0.95;
      g.lineWidth = 0.8 * u; g.lineCap = 'round'; g.strokeStyle = good ? acc : '#FF5C7A'; g.beginPath();
      if (good) { g.moveTo(-1.4 * u, iy); g.lineTo(-0.3 * u, iy + 1.1 * u); g.lineTo(1.6 * u, iy - 1.1 * u); }
      else { g.moveTo(-1.1 * u, iy - 1.1 * u); g.lineTo(1.1 * u, iy + 1.1 * u); g.moveTo(1.1 * u, iy - 1.1 * u); g.lineTo(-1.1 * u, iy + 1.1 * u); }
      shadowed(g, u, () => g.stroke());
      if (!good && k > 0.6) {   // la parte "sbagliata" viene barrata
        const sw = g.measureText(String(o.label || '')).width;
        g.strokeStyle = 'rgba(255,92,122,.9)'; g.lineWidth = 0.55 * u; g.beginPath(); g.moveTo(-sw / 2, 0); g.lineTo(-sw / 2 + sw * eOut((k - 0.6) / 0.4), 0); g.stroke();
      }
      if (o.value) { const s2 = fitText(g, String(o.value), w * 0.4, 2.8 * u, 600); shadowed(g, u, () => bigText(g, String(o.value), 0, s * 0.85, s2, 600, 'rgba(255,255,255,.85)')); }
      g.restore();
    });
    const kv = eBack((t - 0.4) / 0.35);
    if (kv > 0) shadowed(g, u, () => { g.save(); g.translate(x + w / 2, cy); g.scale(kv, kv); bigText(g, 'VS', 0, 0, 3.2 * u, 900, 'rgba(255,255,255,.7)'); g.restore(); });
  } else if (tp === 'progresso') {
    const p = parseNum(spec.value) || { num: 0 };
    const pct = Math.max(0, Math.min(100, p.num)) / 100;
    const cx = x + w / 2, cy = y + h * 0.46, r = Math.min(w, h) * 0.32;
    const pr = eInOut((t - 0.1) / 1.2);
    g.lineCap = 'round';
    shadowed(g, u, () => { g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 1.8 * u; g.stroke(); });
    if (pr > 0) { g.save(); g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 4 * u;
      g.beginPath(); g.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * pct * pr); g.strokeStyle = acc; g.lineWidth = 1.8 * u; g.stroke(); g.restore(); }
    const s = fitText(g, String(spec.value || ''), r * 1.5, r * 0.7, 900);
    shadowed(g, u, () => bigText(g, counting(spec.value, (t - 0.1) / 1.2), cx, cy, s, 900, '#fff'));
    if (spec.title) { const s2 = fitText(g, String(spec.title).toUpperCase(), w * 0.95, 2.6 * u, 800); shadowed(g, u, () => bigText(g, String(spec.title).toUpperCase(), cx, y + h - 2 * u, s2, 800, 'rgba(255,255,255,.85)')); }
  } else drawPremium(g, spec, t, x, y, w, h, u, acc, it, drawTitle);
  return cv;
}

// ---------------------------------------------------------------- componenti premium (stile pulito: testi grandi, ombra morbida, un colore)
const lbl = (i) => String((i && (i.label || i.value)) || '');
function drawPremium(g, spec, t, x, y, w, h, u, acc, it, drawTitle) {
  const tp = spec.tpl, n = Math.max(1, it.length);
  if (tp === 'imbuto') {
    drawTitle(y + 3 * u);
    const top = y + 8 * u, bot = y + h - 2 * u, rowH = (bot - top) / n, maxW = w * 0.62, minW = w * 0.2;
    it.forEach((i, j) => {
      const k = eOut((t - revealAt(spec, j, 0.2, 0.3)) / 0.45);
      if (k <= 0) return;
      const w0 = maxW - (maxW - minW) * (j / n), w1 = maxW - (maxW - minW) * ((j + 1) / n), ry = top + rowH * j, cx = x + w * 0.36, gap = rowH * 0.1;
      g.save(); g.globalAlpha = cl(k * 1.3); g.translate(0, (1 - k) * 2 * u);
      const last = j === n - 1;
      const gr = g.createLinearGradient(0, ry, 0, ry + rowH);
      if (last) { gr.addColorStop(0, mix(acc, 0.3)); gr.addColorStop(1, acc); } else { gr.addColorStop(0, hexA('#FFFFFF', 0.9 - j * 0.12)); gr.addColorStop(1, hexA('#FFFFFF', 0.7 - j * 0.12)); }
      shadowed(g, u, () => { if (last) { g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 5 * u; }
        g.beginPath(); g.moveTo(cx - w0 / 2, ry + gap / 2); g.lineTo(cx + w0 / 2, ry + gap / 2); g.lineTo(cx + w1 / 2, ry + rowH - gap / 2); g.lineTo(cx - w1 / 2, ry + rowH - gap / 2); g.closePath(); g.fillStyle = gr; g.fill(); });
      const val = i.value ? counting(i.value, k) : '';
      if (val) { const sv = fitText(g, val, w1 * 0.9, rowH * 0.42, 900); bigText(g, val, cx, ry + rowH / 2, sv, 900, last ? '#fff' : '#111827'); }
      const sl = fitText(g, String(i.label || ''), w * 0.3, Math.min(3.4 * u, rowH * 0.36), 800);
      shadowed(g, u, () => bigText(g, String(i.label || ''), cx + maxW / 2 + 2.5 * u, ry + rowH / 2, sl, 800, last ? mix(acc, 0.2) : '#fff', 'left'));
      g.restore();
    });
  } else if (tp === 'tempo') {
    drawTitle(y + 3 * u);
    const lx = x + w * 0.06, lw = w * 0.88, ly = y + h * 0.58;
    const lp = eInOut((t - 0.15) / (0.35 * n + 0.3));
    shadowed(g, u, () => { g.strokeStyle = 'rgba(255,255,255,.3)'; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(lx, ly); g.lineTo(lx + lw, ly); g.stroke(); });
    const lg = g.createLinearGradient(lx, 0, lx + lw, 0); lg.addColorStop(0, mix(acc, 0.4)); lg.addColorStop(1, acc);
    g.save(); g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 3 * u; g.strokeStyle = lg; g.lineWidth = 0.7 * u; g.lineCap = 'round';
    g.beginPath(); g.moveTo(lx, ly); g.lineTo(lx + lw * lp, ly); g.stroke(); g.restore();
    it.forEach((i, j) => {
      const px = lx + lw * (n > 1 ? (j + 0.5) / n : 0.5), k = eBack((t - revealAt(spec, j, 0.3, 0.35)) / 0.4);
      if (k <= 0) return;
      g.save(); g.translate(px, ly); g.scale(k, k);
      g.beginPath(); g.arc(0, 0, 1.6 * u, 0, Math.PI * 2); g.fillStyle = '#fff'; g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 4 * u; g.fill();
      g.beginPath(); g.arc(0, 0, 0.8 * u, 0, Math.PI * 2); g.fillStyle = acc; g.fill(); g.restore();
      g.save(); g.globalAlpha = cl(k);
      const sl = fitText(g, String(i.label || ''), lw / n * 0.92, 5.2 * u, 900);
      shadowed(g, u, () => bigText(g, String(i.label || ''), px, ly - 6 * u - (1 - cl(k)) * 2 * u, sl, 900, j === n - 1 ? mix(acc, 0.25) : '#fff'));
      if (i.value) { const sv = fitText(g, String(i.value), lw / n * 0.92, 2.8 * u, 650); shadowed(g, u, () => bigText(g, String(i.value), px, ly + 5.2 * u, sv, 650, 'rgba(255,255,255,.88)')); }
      g.restore();
    });
  } else if (tp === 'freccia') {
    drawTitle(y + 3 * u);
    const a = lbl(it[0]), b = lbl(it[1]);
    const x0 = x + w * 0.16, y0 = y + h * 0.82, x1 = x + w * 0.8, y1 = y + h * 0.3;
    const pr = eInOut((t - 0.25) / 1.0);
    const cxp = x0 + (x1 - x0) * 0.55, cyp = y0 - (y0 - y1) * 0.05;   // curva che accelera verso l'alto
    const pt = (q) => [(1 - q) * (1 - q) * x0 + 2 * (1 - q) * q * cxp + q * q * x1, (1 - q) * (1 - q) * y0 + 2 * (1 - q) * q * cyp + q * q * y1];
    if (pr > 0) {
      g.save(); g.lineCap = 'round'; g.lineJoin = 'round';
      const lg = g.createLinearGradient(x0, y0, x1, y1); lg.addColorStop(0, 'rgba(255,255,255,.85)'); lg.addColorStop(1, acc);
      g.shadowColor = hexA(acc, 0.85); g.shadowBlur = 5 * u; g.strokeStyle = lg; g.lineWidth = 1.5 * u;
      g.beginPath(); for (let q = 0; q <= pr + 1e-6; q += 0.02) { const [px, py] = pt(Math.min(q, pr)); if (q === 0) g.moveTo(px, py); else g.lineTo(px, py); } g.stroke();
      const [hx, hy] = pt(pr), [bx, by] = pt(Math.max(0, pr - 0.04)), ang = Math.atan2(hy - by, hx - bx);
      g.translate(hx, hy); g.rotate(ang); g.fillStyle = acc; g.beginPath(); g.moveTo(2.4 * u, 0); g.lineTo(-1.6 * u, -1.9 * u); g.lineTo(-1.6 * u, 1.9 * u); g.closePath(); g.fill();
      g.restore();
    }
    const ka = eOut((t - 0.15) / 0.4), kb = eOut((t - 1.05) / 0.4);
    if (a && ka > 0) { g.save(); g.globalAlpha = ka; const s1 = fitText(g, a, w * 0.34, 6 * u, 900); shadowed(g, u, () => bigText(g, a, x0, y0 + 4.5 * u, s1, 900, 'rgba(255,255,255,.9)')); g.restore(); }
    if (b && kb > 0) { g.save(); g.globalAlpha = kb; g.translate(x1, y1 - 5 * u); const sc = popScale(kb); g.scale(sc, sc); const s2 = fitText(g, b, w * 0.4, 8 * u, 900);
      shadowed(g, u, () => { g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 6 * u; const gr = g.createLinearGradient(0, -s2 / 2, 0, s2 / 2); gr.addColorStop(0, '#fff'); gr.addColorStop(1, mix(acc, 0.25)); bigText(g, b, 0, 0, s2, 900, gr); }); g.restore(); }
    if (spec.value) { const kv = eBack((t - 1.35) / 0.4); if (kv > 0) { g.save(); g.translate(x + w * 0.5, y + h * 0.5); g.scale(kv, kv);
      const sv = fitText(g, String(spec.value), w * 0.2, 5 * u, 900); rr(g, -sv * 1.3, -sv * 0.75, sv * 2.6, sv * 1.5, sv * 0.75); g.fillStyle = acc; g.shadowColor = hexA(acc, 0.7); g.shadowBlur = 4 * u; g.fill(); g.shadowBlur = 0;
      bigText(g, String(spec.value), 0, 0.05 * sv, sv, 900, '#fff'); g.restore(); } }
  } else if (tp === 'equazione') {
    const parts = [];
    it.forEach((i, j) => { parts.push([lbl(i), false]); parts.push([j < it.length - 1 ? '+' : '=', 'op']); });
    if (!it.length) parts.push(['?', false], ['=', 'op']);
    parts.push([String(spec.value || ''), true]);
    const sz0 = Math.min(9 * u, (w * 0.92) / Math.max(1, parts.reduce((m, [p2, op]) => m + (op === 'op' ? 2 : Math.max(2, p2.length)), 0) * 0.6));
    let sz2 = sz0; g.font = `900 ${sz2}px ${FONT}`;
    const wOf = (z) => parts.reduce((m, [p2, op]) => m + (op === 'op' ? z * 1.5 : g.measureText(p2).width), 0) + z * 0.35 * (parts.length - 1);
    const tw = wOf(sz2); if (tw > w * 0.94) { sz2 *= (w * 0.94) / tw; g.font = `900 ${sz2}px ${FONT}`; }
    const sz = sz2;
    const ws = parts.map(([p2, op]) => (op === 'op' ? sz * 1.5 : g.measureText(p2).width));
    const gapX = sz * 0.35, total = ws.reduce((a2, b2) => a2 + b2, 0) + gapX * (parts.length - 1);
    let px = x + (w - total) / 2; const cy = y + h * 0.55;
    parts.forEach(([p2, kind], j) => {
      const k = eBack((t - (0.15 + j * 0.22)) / 0.4), cx = px + ws[j] / 2;
      if (k > 0) {
        g.save(); g.globalAlpha = cl(k * 1.4); g.translate(cx, cy); const sc = kind === true ? popScale(k) * 1.06 : popScale(k); g.scale(sc, sc);
        shadowed(g, u, () => {
          if (kind === true) { g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 6 * u; const gr = g.createLinearGradient(0, -sz / 2, 0, sz / 2); gr.addColorStop(0, mix(acc, 0.35)); gr.addColorStop(1, acc); bigText(g, p2, 0, 0, sz, 900, gr); }
          else bigText(g, p2, 0, 0, kind === 'op' ? sz * 0.9 : sz, 900, kind === 'op' ? 'rgba(255,255,255,.7)' : '#fff');
        });
        g.restore();
      }
      px += ws[j] + gapX;
    });
    if (spec.title) drawTitle(y + 3 * u);
  } else if (tp === 'proporzione') {
    drawTitle(y + 3 * u);
    const m = String(spec.value || '').match(/(\d+[.,]?\d*)\s*(?:su|\/|of|out of)\s*(\d+)/i), pc = parseNum(spec.value);
    let on, tot;
    if (m) { on = parseFloat(m[1].replace(',', '.')); tot = parseInt(m[2], 10); } else { tot = 10; on = pc ? Math.round(Math.max(0, Math.min(100, pc.num)) / 10) : 3; }
    tot = Math.max(2, Math.min(20, tot)); on = Math.max(0, Math.min(tot, on));
    const cols = tot > 10 ? 10 : tot, rows = Math.ceil(tot / cols), cw = w * 0.86 / cols, chh = Math.min(cw * 1.6, (h - 18 * u) / rows), sx = x + (w - cw * cols) / 2, sy = y + 9 * u;
    for (let i = 0; i < tot; i++) {
      const c = i % cols, r = Math.floor(i / cols), k = eBack((t - 0.15 - i * 0.04) / 0.35), lit = i < on && t > 0.6 + i * 0.08;
      if (k <= 0) continue;
      const px = sx + cw * (c + 0.5), py = sy + chh * r, s2 = Math.min(cw, chh / 1.6) * 0.42 * k;
      g.save(); g.fillStyle = lit ? acc : 'rgba(255,255,255,.35)'; if (lit) { g.shadowColor = hexA(acc, 0.9); g.shadowBlur = 3 * u; }
      g.beginPath(); g.arc(px, py + s2 * 0.9, s2 * 0.75, 0, Math.PI * 2); g.fill();
      rr(g, px - s2 * 1.05, py + s2 * 1.85, s2 * 2.1, s2 * 1.9, s2 * 0.9); g.fill(); g.restore();
    }
    const kv = eOut((t - 0.8) / 0.4);
    if (kv > 0 && spec.value) { g.save(); g.globalAlpha = kv; const sv = fitText(g, String(spec.value), w * 0.8, 6.5 * u, 900); shadowed(g, u, () => bigText(g, String(spec.value), x + w / 2, y + h - 4.5 * u, sv, 900, '#fff')); g.restore(); }
  } else if (tp === 'ciclo') {
    drawTitle(y + 3 * u);
    const cx = x + w / 2, cy = y + h * 0.56, R = Math.min(w, h) * 0.32, rot = t * 0.25;
    const kr = eInOut((t - 0.1) / 1.0);
    g.save(); g.strokeStyle = hexA(acc, 0.9); g.lineWidth = 0.7 * u; g.lineCap = 'round'; g.shadowColor = hexA(acc, 0.8); g.shadowBlur = 3 * u;
    for (let j = 0; j < n; j++) {
      const a0 = -Math.PI / 2 + (j / n) * Math.PI * 2 + 0.32 + rot * 0.1, a1 = -Math.PI / 2 + ((j + 1) / n) * Math.PI * 2 - 0.32 + rot * 0.1, e = a0 + (a1 - a0) * kr;
      if (kr <= 0) break;
      g.beginPath(); g.arc(cx, cy, R, a0, e); g.stroke();
      if (kr > 0.95) { const hx = cx + R * Math.cos(e), hy = cy + R * Math.sin(e), tg = e + Math.PI / 2; g.save(); g.translate(hx, hy); g.rotate(tg); g.fillStyle = acc; g.beginPath(); g.moveTo(1.4 * u, 0); g.lineTo(-1 * u, -1.1 * u); g.lineTo(-1 * u, 1.1 * u); g.closePath(); g.fill(); g.restore(); }
    }
    g.restore();
    it.forEach((i, j) => {
      const a = -Math.PI / 2 + (j / n) * Math.PI * 2 + rot * 0.1, px = cx + R * Math.cos(a), py = cy + R * Math.sin(a), k = eBack((t - revealAt(spec, j, 0.2, 0.25)) / 0.4);
      if (k <= 0) return;
      g.save(); g.translate(px, py); g.scale(k, k);
      const s2 = fitText(g, String(i.label || ''), w * 0.34, 3.6 * u, 900); g.font = `900 ${s2}px ${FONT}`; const tw = g.measureText(String(i.label || '')).width;
      rr(g, -tw / 2 - 1.6 * u, -s2 * 0.85, tw + 3.2 * u, s2 * 1.7, s2 * 0.85); g.fillStyle = j === 0 ? acc : 'rgba(12,16,26,.85)'; g.shadowColor = 'rgba(0,0,0,.5)'; g.shadowBlur = 3 * u; g.fill(); g.shadowBlur = 0;
      g.strokeStyle = hexA('#FFFFFF', 0.25); g.lineWidth = Math.max(1, 0.15 * u); g.stroke();
      bigText(g, String(i.label || ''), 0, 0.05 * s2, s2, 900, '#fff'); g.restore();
    });
  } else if (tp === 'piramide') {
    drawTitle(y + 3 * u);
    const top = y + 8 * u, bot = y + h - 1 * u, lh = (bot - top) / n, cx = x + w / 2, bw = w * 0.82;
    for (let j = 0; j < n; j++) {   // dalla base (primo elemento) alla cima
      const i = it[j], k = eOut((t - revealAt(spec, j, 0.2, 0.32)) / 0.45);
      if (k <= 0) continue;
      const lvl = n - 1 - j, yb = top + lh * (lvl + 1), yt = top + lh * lvl, wb = bw * (lvl + 1) / n, wt = bw * lvl / n, last = j === n - 1, gap = lh * 0.06;
      g.save(); g.globalAlpha = cl(k * 1.3); g.translate(0, (1 - k) * 3 * u);
      const gr = g.createLinearGradient(0, yt, 0, yb);
      if (last) { gr.addColorStop(0, mix(acc, 0.35)); gr.addColorStop(1, acc); } else { gr.addColorStop(0, hexA('#FFFFFF', 0.92 - j * 0.1)); gr.addColorStop(1, hexA('#FFFFFF', 0.72 - j * 0.1)); }
      shadowed(g, u, () => { if (last) { g.shadowColor = hexA(acc, 0.85); g.shadowBlur = 5 * u; }
        g.beginPath(); g.moveTo(cx - wt / 2, yt + gap); g.lineTo(cx + wt / 2, yt + gap); g.lineTo(cx + wb / 2, yb - gap); g.lineTo(cx - wb / 2, yb - gap); g.closePath(); g.fillStyle = gr; g.fill(); });
      const lab = String(i.label || ''), sl = fitText(g, lab, Math.max(wb * 0.7, w * 0.22), Math.min(3.6 * u, lh * 0.42), 900);
      if (last && wt < w * 0.05) shadowed(g, u, () => bigText(g, lab, cx + wb / 2 + 2 * u, (yt + yb) / 2 + lh * 0.12, sl, 900, mix(acc, 0.2), 'left'));
      else bigText(g, lab, cx, (yt + yb) / 2 + lh * 0.04, sl, 900, last ? '#fff' : '#111827');
      g.restore();
    }
  } else if (tp === 'podio') {
    drawTitle(y + 3 * u);
    const order = [1, 0, 2].filter((k2) => it[k2]), base = y + h - 7 * u, gw = w * 0.78, colW = gw / 3, gx = x + (w - gw) / 2, hs = [0.75, 1, 0.55];
    order.forEach((k2, pos) => {
      const i = it[k2], rank = k2 + 1, kk = eOut((t - (0.2 + (2 - k2) * 0.3)) / 0.55), bh = (base - (y + 16 * u)) * hs[pos] * kk, bx = gx + colW * pos + colW * 0.12, bw = colW * 0.76, first = rank === 1;
      if (bh > 0.5) shadowed(g, u, () => { if (first) { g.shadowColor = hexA(acc, 0.85); g.shadowBlur = 6 * u; }
        const gr = g.createLinearGradient(0, base - bh, 0, base); if (first) { gr.addColorStop(0, mix(acc, 0.35)); gr.addColorStop(1, acc); } else { gr.addColorStop(0, 'rgba(255,255,255,.92)'); gr.addColorStop(1, 'rgba(255,255,255,.6)'); }
        rr(g, bx, base - bh, bw, bh, 1.2 * u); g.fillStyle = gr; g.fill(); });
      if (kk > 0.3) {
        g.save(); g.globalAlpha = cl((kk - 0.3) / 0.5);
        bigText(g, String(rank), bx + bw / 2, base - bh + 4 * u, Math.min(6 * u, bw * 0.5), 900, first ? '#fff' : '#111827');
        const sl = fitText(g, String(i.label || ''), colW * 0.98, 3.2 * u, 800); shadowed(g, u, () => bigText(g, String(i.label || ''), bx + bw / 2, base - bh - 3 * u, sl, 800, first ? mix(acc, 0.2) : '#fff'));
        g.restore();
      }
    });
    shadowed(g, u, () => { g.strokeStyle = 'rgba(255,255,255,.6)'; g.lineWidth = 0.35 * u; g.beginPath(); g.moveTo(gx, base); g.lineTo(gx + gw, base); g.stroke(); });
  } else if (tp === 'citazione') {
    const words = String(spec.title || '').split(/\s+/).filter(Boolean);
    const kq = eBack(t / 0.45);
    if (kq > 0) { g.save(); g.translate(x + w * 0.06, y + h * 0.3); g.scale(kq, kq); bigText(g, '\u201C', 0, 0, 20 * u, 900, hexA(acc, 0.95)); g.restore(); }
    // a capo automatico in 2 righe al massimo
    let sz = 7 * u, lines;
    for (let tries = 0; tries < 14; tries++) {
      g.font = `800 ${sz}px ${FONT}`; lines = [[]]; let lw = 0;
      for (const wd of words) { const ww = g.measureText(wd + ' ').width; if (lw + ww > w * 0.8 && lines[lines.length - 1].length) { lines.push([]); lw = 0; } lines[lines.length - 1].push(wd); lw += ww; }
      if (lines.length <= 2) break; sz *= 0.9;
    }
    let wi = 0; const lh2 = sz * 1.15, y0 = y + h * 0.44 - (lines.length - 1) * lh2 / 2;
    lines.forEach((ln, li) => {
      let px = x + w * 0.14;
      ln.forEach((wd) => { const k = eOut((t - 0.3 - wi * 0.12) / 0.35); g.font = `800 ${sz}px ${FONT}`; const ww = g.measureText(wd + ' ').width;
        if (k > 0) { g.save(); g.globalAlpha = cl(k * 1.3); shadowed(g, u, () => bigText(g, wd, px, y0 + li * lh2 + (1 - k) * 1.5 * u, sz, 800, '#fff', 'left')); g.restore(); }
        px += ww; wi++; });
    });
    if (spec.value) { const ka = eOut((t - 0.5 - wi * 0.12) / 0.4); if (ka > 0) { g.save(); g.globalAlpha = ka; const sa = fitText(g, '— ' + spec.value, w * 0.6, 3 * u, 700); shadowed(g, u, () => bigText(g, '— ' + spec.value, x + w * 0.14, y + h - 4 * u, sa, 700, mix(acc, 0.3), 'left')); g.restore(); } }
  } else if (tp === 'torta') {
    drawTitle(y + 3 * u);
    const vals = it.map((i) => Math.max(0, (parseNum(i.value) || { num: 1 }).num)), sum = vals.reduce((a2, b2) => a2 + b2, 0) || 1;
    const cx = x + w * 0.3, cy = y + h * 0.56, R = Math.min(w * 0.24, h * 0.36), pr = eInOut((t - 0.15) / 1.1);
    const cols = [acc, 'rgba(255,255,255,.92)', 'rgba(255,255,255,.6)', 'rgba(255,255,255,.38)', 'rgba(255,255,255,.22)'];
    let a0 = -Math.PI / 2;
    g.save(); g.lineWidth = R * 0.42; g.lineCap = 'butt';
    vals.forEach((v, j) => { const a1 = a0 + (v / sum) * Math.PI * 2 * pr; g.beginPath(); g.arc(cx, cy, R * 0.79, a0, a1); g.strokeStyle = cols[j % cols.length];
      if (j === 0) { g.shadowColor = hexA(acc, 0.85); g.shadowBlur = 4 * u; } else g.shadowBlur = 0; g.stroke(); a0 = a1 + (pr > 0.98 ? 0.02 : 0); });
    g.restore();
    it.forEach((i, j) => {
      const k = eOut((t - 0.4 - j * 0.2) / 0.4); if (k <= 0) return;
      const ly = y + 13 * u + j * Math.min(8 * u, (h - 16 * u) / n), lx = x + w * 0.6 + (1 - k) * 3 * u;
      g.save(); g.globalAlpha = cl(k * 1.3);
      g.beginPath(); g.arc(lx, ly, 1.3 * u, 0, Math.PI * 2); g.fillStyle = cols[j % cols.length]; g.fill();
      const sv = fitText(g, String(i.value || ''), w * 0.14, 4 * u, 900); shadowed(g, u, () => bigText(g, String(i.value || ''), lx + 2.8 * u, ly, sv, 900, j === 0 ? mix(acc, 0.2) : '#fff', 'left'));
      g.font = `900 ${sv}px ${FONT}`; const vw = g.measureText(String(i.value || '')).width;
      const sl = fitText(g, String(i.label || ''), w * 0.36 - vw, 3 * u, 700); shadowed(g, u, () => bigText(g, String(i.label || ''), lx + 4.4 * u + vw, ly, sl, 700, 'rgba(255,255,255,.88)', 'left'));
      g.restore();
    });
  }
}
