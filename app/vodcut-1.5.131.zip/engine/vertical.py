"""Formato verticale (9:16): cosa si vede e dove.

La live e' orizzontale: in verticale lo schermo alto si riempie con dei pezzi della live
(la webcam, il gioco, tutto il video con lo sfondo sfocato). Stessa matematica di web/lib.js (vertRegions).
Ogni pezzo: d = dove va sullo schermo (0..1), s = che parte della live (pixel), blur = sfondo sfocato.
"""

V_ASPECT = 9 / 16
LAYOUTS = ("split", "game", "cam", "fit", "free")
DEFAULT = {"layout": "split", "camH": 0.4, "gameX": 0.5}


def is_vertical(proj):
    return (proj.get("format") or "16:9") == "9:16"


def settings(proj):
    v = dict(DEFAULT, **(proj.get("vert") or {}))
    cam = (proj.get("webcam") or {}).get("box")
    if v["layout"] in ("split", "cam") and not cam:
        v["layout"] = "fit"      # senza webcam: tutto il video con lo sfondo sfocato
    v["camH"] = max(0.2, min(0.7, float(v.get("camH") or 0.4)))
    v["gameX"] = max(0.0, min(1.0, float(v.get("gameX") if v.get("gameX") is not None else 0.5)))
    v["pad"] = clamp_pad(v.get("pad"))
    return v


def clamp_pad(p):
    """Barre nere sopra e sotto (0..0.2 dello schermo ciascuna)."""
    try:
        return max(0.0, min(0.2, float(p or 0)))
    except (TypeError, ValueError):
        return 0.0


def cover_rect(r, a):
    """Il rettangolo piu' grande con proporzione a (larghezza/altezza) dentro r, centrato."""
    x, y, w, h = r
    if w / h > a:
        nw = h * a
        x += (w - nw) / 2
        w = nw
    else:
        nh = w / a
        y += (h - nh) / 2
        h = nh
    return [x, y, w, h]


def game_rect(W, H, a, gx):
    w = min(W, H * a)
    h = w / a
    x = min(max(0.0, gx * W - w / 2), W - w)
    return [x, (H - h) / 2, w, h]


def regions(kind, W, H, cam=None, camH=0.4, gameX=0.5, rect=None, pad=0.0, boxes=None):
    """kind: split | game | cam | fit | rect (inquadratura scelta a mano).
    pad: barre nere sopra e sotto; il contenuto sta nella fascia in mezzo (come vertRegions in web/lib.js)."""
    pad = clamp_pad(pad)
    regs = _regions(kind, W, H, cam, camH, gameX, rect, V_ASPECT / (1 - 2 * pad))
    if pad:
        for r in regs:
            d = r["d"]
            r["d"] = [d[0], pad + d[1] * (1 - 2 * pad), d[2], d[3] * (1 - 2 * pad)]
    return apply_boxes(regs, boxes)


def apply_boxes(regs, boxes):
    """Pezzi spostati o ingranditi a mano: boxes[role] = [x, y, w] (stessa forma, altra posizione e grandezza)."""
    if not boxes:
        return regs
    out = []
    for r in regs:
        b = boxes.get(r.get("role")) if r.get("role") else None
        if b and not r.get("blur"):
            d = r["d"]
            r = dict(r, d=[float(b[0]), float(b[1]), float(b[2]), float(b[2]) * d[3] / d[2]])
        out.append(r)
    # spostati a mano: la webcam sta sopra il gioco (se si sovrappongono si vede lei)
    out.sort(key=lambda r: 1 if r.get("role") == "cam" else 0)
    return out


def _regions(kind, W, H, cam, camH, gameX, rect, a):
    if kind == "split" and cam:
        return [{"d": [0, 0, 1, camH], "s": cover_rect(list(cam), a / camH), "role": "cam"},
                {"d": [0, camH, 1, 1 - camH], "s": game_rect(W, H, a / (1 - camH), gameX), "role": "game"}]
    if kind == "cam" and cam:
        return [{"d": [0, 0, 1, 1], "s": cover_rect(list(cam), a), "role": "cam"}]
    if kind == "rect" and rect:
        return [{"d": [0, 0, 1, 1], "s": cover_rect(list(rect), a), "role": "main"}]
    if kind == "game":
        return [{"d": [0, 0, 1, 1], "s": game_rect(W, H, a, gameX), "role": "game"}]
    if kind == "free":
        # libero: tutto il video (alto come lo schermo) e la webcam intera sopra (come vertRegions0 in web/lib.js)
        gw = (W / H) / a
        gx = min(0.0, max(1 - gw, 0.5 - gw * gameX))
        out = [{"d": [gx, 0, gw, 1], "s": [0, 0, W, H], "role": "game"}]   # dietro: nero
        if cam:
            cw = 0.9
            out.append({"d": [(1 - cw) / 2, 0.04, cw, cw * a * cam[3] / cam[2]], "s": list(cam), "role": "cam"})
        return out
    # fit: tutto il video, sopra lo stesso video ingrandito e sfocato
    fh = a * H / W
    return [{"d": [0, 0, 1, 1], "s": cover_rect([0, 0, W, H], a), "blur": True},
            {"d": [0, (1 - fh) / 2, 1, fh], "s": [0, 0, W, H], "role": "main"}]


def _even(v):
    return max(2, int(round(v / 2.0)) * 2)


def graph(regs, OW, OH, inp, out, pre="v"):
    """Righe di filtro ffmpeg che compongono lo schermo verticale OW x OH dai pezzi."""
    parts = []
    regs = [c for c in (visible_part(r) for r in regs) if c]
    n = len(regs)
    srcs = [f"{pre}s{i}" for i in range(n)]
    lines = []
    if n > 1:
        lines.append(f"[{inp}]split={n}" + "".join(f"[{s}]" for s in srcs))
    else:
        srcs = [inp]
    if not regs:
        return [f"[{inp}]scale={OW}:{OH},drawbox=c=black:t=fill[{out}]"]
    for i, r in enumerate(regs):
        x, y, w, h = r["s"]
        dx, dy = int(round(r["d"][0] * OW)), int(round(r["d"][1] * OH))
        dw, dh = _even(r["d"][2] * OW), _even(r["d"][3] * OH)
        dw = min(dw, max(2, (OW - dx) // 2 * 2))
        dh = min(dh, max(2, (OH - dy) // 2 * 2))
        ch = f"[{srcs[i]}]crop={max(2, int(round(w)))}:{max(2, int(round(h)))}:{int(round(x))}:{int(round(y))},scale={dw}:{dh}:flags=lanczos,setsar=1"
        if r.get("blur"):
            rad = max(4, int(min(dw, dh) / 22))
            ch += f",boxblur={rad}:2,eq=brightness=-0.07"
        lab = f"{pre}r{i}"
        lines.append(ch + f"[{lab}]")
        parts.append((lab, dx, dy, dw, dh))
    # il primo pezzo fa da base (allargato a tutto lo schermo), gli altri ci vanno sopra
    lab, dx, dy, dw, dh = parts[0]
    if (dx, dy, dw, dh) != (0, 0, OW, OH):
        lines.append(f"[{lab}]pad={OW}:{OH}:{dx}:{dy}:black[{pre}b0]")
        cur = f"{pre}b0"
    else:
        cur = lab
    for k, (lab, dx, dy, dw, dh) in enumerate(parts[1:], 1):
        nxt = out if k == len(parts) - 1 else f"{pre}b{k}"
        lines.append(f"[{cur}][{lab}]overlay={dx}:{dy}[{nxt}]")
        cur = nxt
    if cur != out:
        lines.append(f"[{cur}]null[{out}]")
    return lines


def visible_part(r):
    """La parte di un pezzo che sta dentro lo schermo (spostandolo a mano puo' uscire dai bordi)."""
    dx, dy, dw, dh = r["d"]
    x0, y0, x1, y1 = max(0.0, dx), max(0.0, dy), min(1.0, dx + dw), min(1.0, dy + dh)
    if x1 - x0 < 1e-3 or y1 - y0 < 1e-3:
        return None
    if (x0, y0, x1, y1) == (dx, dy, dx + dw, dy + dh):
        return r
    sx, sy, sw, sh = r["s"]
    kx, ky = sw / dw, sh / dh
    return dict(r, d=[x0, y0, x1 - x0, y1 - y0], s=[sx + (x0 - dx) * kx, sy + (y0 - dy) * ky, (x1 - x0) * kx, (y1 - y0) * ky])


def out_size(proj, quality):
    """Dimensioni del video verticale: il lato corto come la qualita' scelta (mai sopra la live)."""
    q = {"540p": 540, "720p": 720, "1080p": 1080, "1440p": 1440, "4K": 2160, "2160p": 2160}.get(quality, 1080)
    q = min(q, int(proj["height"]))
    ow = _even(q)
    return ow, _even(ow * 16 / 9)


def on_screen(regs, box):
    bx, by, bw, bh = box
    cx, cy = bx + bw / 2, by + bh / 2
    cand = [r for r in regs if not r.get("blur")]
    r = next((q for q in cand if q["s"][0] <= cx <= q["s"][0] + q["s"][2] and q["s"][1] <= cy <= q["s"][1] + q["s"][3]), None)
    if r is None:
        r = max(cand, key=lambda q: q["d"][2] * q["d"][3])
    kx, ky = r["d"][2] / r["s"][2], r["d"][3] / r["s"][3]
    return [r["d"][0] + (bx - r["s"][0]) * kx, r["d"][1] + (by - r["s"][1]) * ky, bw * kx, bh * ky]


def anim_regions(base, box, p, frm=None, pad=0.0):
    """Come vertAnimRegs in web/lib.js: il riquadro parte da dove si vede (frm) e si allarga a tutto schermo
    fino a mostrare box (l'inquadratura finale)."""
    if p <= 0.0005:
        return base
    f = list(frm or box)
    d0 = on_screen(base, f)
    d = [v + (w - v) * p for v, w in zip(d0, [0, pad, 1, 1 - 2 * pad])]
    mid = [v + (w - v) * p for v, w in zip(f, box)]
    s = cover_rect(mid, (d[2] / d[3]) * V_ASPECT)
    top = {"d": d, "s": s}
    return [top] if abs(p - 1) < 1e-3 else base + [top]


def vert_rect(W, H, r, a=V_ASPECT):
    x, y, w = float(r[0]), float(r[1]), float(r[2])
    w = max(W / 16.0, min(H * a, w))
    hh = w / a
    return [min(max(0.0, x), W - w), min(max(0.0, y), H - hh), w, hh]


def zoom_boxes(z, W, H, cam, custom_rect, a=V_ASPECT):
    """(da dove parte, cosa mostra alla fine) per lo zoom verticale. Come vertZoomBoxes in web/lib.js."""
    frm = custom_rect(W, H, z["rect"]) if z.get("kind") == "custom" and z.get("rect") else cam
    if not frm:
        return None
    return list(frm), (vert_rect(W, H, z["vrect"], a) if z.get("vrect") else list(frm))


def vzoom(z):
    return dict(z, **{"in": z.get("vin") or "fast", "out": z.get("vout") or "fast"})


def seg_layout(proj, t, vset):
    """Impaginazione nel punto t: quella della clip, se ne ha una sua, se no quella di tutto il progetto."""
    for c in proj.get("segs") or []:
        if c["a"] <= t < c["b"]:
            o = c.get("vlay")
            if o:
                v = dict(vset, **o)
                v["pad"] = clamp_pad(v.get("pad"))
                cam = (proj.get("webcam") or {}).get("box")
                if v.get("layout") in ("split", "cam") and not cam:
                    v["layout"] = "fit"
                return v
            break
    return vset


def compose(frame, regs, OW, OH, sx=1.0, sy=1.0):
    """Schermo verticale di un fotogramma (per i pezzi animati). frame: BGR della live."""
    import cv2
    import numpy as np
    canvas = np.zeros((OH, OW, 3), np.uint8)
    for r in regs:
        dx, dy, dw, dh = r["d"][0] * OW, r["d"][1] * OH, r["d"][2] * OW, r["d"][3] * OH
        x, y, w, h = r["s"][0] * sx, r["s"][1] * sy, r["s"][2] * sx, r["s"][3] * sy
        if w < 1 or h < 1 or dw < 1 or dh < 1:
            continue
        kx, ky = dw / w, dh / h
        M = np.array([[kx, 0, dx - x * kx], [0, ky, dy - y * ky]], np.float32)
        x0, y0 = max(0, int(np.floor(dx))), max(0, int(np.floor(dy)))
        x1, y1 = min(OW, int(np.ceil(dx + dw))), min(OH, int(np.ceil(dy + dh)))
        if x1 <= x0 or y1 <= y0:
            continue
        out = cv2.warpAffine(frame, M, (OW, OH), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        part = out[y0:y1, x0:x1]
        if r.get("blur"):
            k = max(4, int(min(dw, dh) / 22)) * 2 + 1
            part = cv2.blur(cv2.blur(part, (k, k)), (k, k))
            part = (part.astype(np.float32) * 0.93).astype(np.uint8)
        canvas[y0:y1, x0:x1] = part
    return canvas
