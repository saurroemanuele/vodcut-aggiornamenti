"""Effetti su misura: l'AI scrive il codice di un'animazione (canvas 2D) che NoonFrame disegna sopra il video.
Il codice gira in una sandbox senza rete e senza accesso all'app (web/fxbox.html): qui si scrive solo il testo."""
import json
import re

from . import ai

STYLES = {
    "olografico": "hologram: cyan/teal light, additive blending ('lighter'), thin glowing wireframe lines, scanlines, subtle flicker, "
                  "floating particles, depth via transparency, like a sci-fi HUD",
    "premium": "premium After Effects motion design: clean geometric shapes, smooth easing (outExpo/outBack), staggered reveals, "
               "subtle glow, elegant thin typography, a single accent color on white/soft grey, lots of negative space",
    "neon": "neon: saturated magenta/cyan/violet strokes with strong glow (shadowBlur), light trails, energetic but tidy",
    "minimal": "minimal: few white shapes and lines, crisp, calm easing, one small accent, Apple-keynote feeling",
    "cinematico": "cinematic VFX: light rays, lens flare, sparks/embers, volumetric glow, dramatic scale, golden/orange accents",
}

SYSTEM = """You are a senior motion designer who writes JavaScript canvas animations for a video editor.
Write ONE function that draws one frame of an overlay effect on top of a video:

function effect(ctx, t, W, H, p) { ... }

- ctx: CanvasRenderingContext2D of a W x H transparent canvas (already cleared every frame). Draw ONLY the effect:
  the background must stay transparent (the video is underneath). Never fill the whole canvas with an opaque color.
- t: seconds since the effect started (0 .. p.dur). p.k = t / p.dur (0..1).
- p: { dur, k, fps, accent (css color), accent2, text (string, may be empty), seed (number),
       anchor: {x, y} center of the effect in 0..1 canvas coordinates (default 0.5, 0.5),
       size: suggested size as a fraction of min(W,H) (default 0.5),
       box: null or {x, y, w, h} in 0..1 canvas coordinates: the SAFE AREA. If set, compose the whole design to fill this
            rectangle nicely (centered on it, with margins) and draw NOTHING outside it: everything outside is cut away
            (the speaker's face is there). Text must fit inside it too,
       hand: null or {x, y (palm center), open (0..1, 1 = open palm), visible (bool), tip: {x, y} (index fingertip),
              seen (0..1, smooth visibility: multiply the effect alpha by it), size (palm length as a fraction of H), gesture: "aperta" | "pugno" | "indice" | "vittoria" | "pollice" | ""}
              in 0..1 canvas coordinates, it follows the speaker's real hand every frame }
  If p.hand is not null, attach the effect to the hand (e.g. floating just above the open palm: y - size * 0.9)
  instead of p.anchor, scale it with p.hand.size, and make it react: grow/appear with p.hand.open, follow p.hand.tip for
  "pointing" ideas. Multiply the effect opacity by p.hand.seen so it fades in/out with the hand (x, y stay at the last known place).
  If p.hand is null (preview without video), draw it at p.anchor as if an open hand were there.
- Helpers already in scope (use them, do not redefine): E (easing: E.outCubic, E.inOutCubic, E.outBack, E.outExpo, E.inOutSine,
  E.outElastic), lerp(a,b,x), clamp(x,a,b), rand(seed) -> deterministic function returning 0..1, noise(x, y) -> 0..1 smooth,
  rr(ctx, x, y, w, h, r) rounded-rect path, TAU.
- Deterministic: never use Math.random() or Date; use rand(p.seed).
- Performance: must draw a frame in a few milliseconds (at most ~400 particles, no per-pixel loops, no getImageData).
- No DOM, no images, no network, no async, no globals: only ctx drawing. Use system fonts:
  '600 40px -apple-system, "Segoe UI", Inter, Arial, sans-serif' (scale sizes with min(W,H)).
- Always: an entrance animation (first ~0.5 s), life in the middle (subtle continuous motion), and an exit (last ~0.35 s)
  so the effect never pops in or out. Scale everything relative to min(W, H). Keep text short and legible.
- Words: draw only the text in p.text (and numbers/words explicitly given in the request), in the language of the video.
  Never invent labels in another language. Text must be big and legible: white or very light with a soft dark shadow,
  at least 5% of min(W,H) tall, never dark text on the video.
- Make it look PREMIUM, like After Effects, never like cheap clip-art: smooth easing, layered depth, glow with shadowBlur,
  thin crisp lines, restrained palette, motion that follows physics. Reset shadowBlur/globalAlpha/composite after use.

Answer ONLY with JSON: {"name": "short Italian name", "code": "function effect(ctx, t, W, H, p) { ... }", "dur": seconds}"""


def _parse(raw):
    s = raw.strip()
    m = re.search(r"\{.*\}", s, re.S)
    obj = None
    if m:
        try:
            obj = json.loads(m.group(0))
        except Exception:
            obj = None
    if not obj:
        # a volte il modello risponde con il codice in un blocco ```js
        cm = re.search(r"```(?:js|javascript)?\s*(function\s+effect.*?)```", s, re.S)
        if cm:
            obj = {"name": "Effetto", "code": cm.group(1)}
    if not obj or "function effect" not in str(obj.get("code") or ""):
        raise ai.AIError("L'AI non ha scritto un effetto valido: riprova")
    code = str(obj["code"])
    if len(code) > 40000:
        raise ai.AIError("Effetto troppo lungo: riprova con una descrizione più semplice")
    return {"name": str(obj.get("name") or "Effetto")[:48], "code": code, "dur": obj.get("dur")}


def generate(cfg, prompt, dur=3.0, style="premium", text="", aspect=16 / 9, prev=None, error=None, hand=False, cancel=None, refs=None):
    """-> {name, code, dur, usd}. prev = codice di prima (modifica); error = errore del codice di prima (correzione).
    refs = immagini di esempio (screenshot) da cui prendere stile e idea."""
    st = STYLES.get(style) or STYLES["premium"]
    user = [f"Effect to create: {prompt.strip()[:1500]}",
            f"Visual style: {st}",
            f"Duration: {float(dur):.1f} s. Canvas aspect ratio: {aspect:.3f} (W/H).",
            f"Text to show (optional, keep it exactly): {text.strip()[:120]}" if text and text.strip() else "No text unless the effect really needs one word.",
            "IMPORTANT: this effect must follow the speaker's real hand (p.hand: palm, fingertip, openness, gesture) and fade with p.hand.seen." if hand else "Center the effect on p.anchor."]
    if prev:
        user.append("Current code of the effect (modify it as requested, keep what works):\n" + prev[:30000])
    if error:
        user.append("The current code throws this error, fix it: " + str(error)[:500])
    if refs:
        user.append("REFERENCE: the attached image(s) show the look the user wants. Recreate that animation style as closely as possible "
                    "(composition, shapes, colors, typography, mood, how elements are arranged), animated with a premium entrance, life and exit. "
                    "Keep the user's own text/data, not the text in the reference.")
    u = "\n".join(user)
    raw = ai.text(cfg, SYSTEM, u, max_tokens=8000, cancel=cancel, images=refs or None)
    out = _parse(raw)
    try:
        d = float(out.get("dur") or dur)
    except (TypeError, ValueError):
        d = float(dur)
    out["dur"] = max(1.0, min(15.0, d if not prev else float(dur)))
    out["usd"] = ai.text_usd(cfg.get("model"), SYSTEM, u, raw)
    return out


def estimate_usd(model):
    """Quanto costa circa scrivere un'animazione su misura con questo modello (risposta di ~3.500 token, a volte una correzione)."""
    c = ai.text_cost(model, (len(SYSTEM) + 1400) / 3.5, 3500)
    # scrittura + controllo visivo (4 fotogrammi e riscrittura) + qualche correzione
    return round(c * 2.3 + 0.016, 4) if c is not None else 0.1


REVIEW = """You are the art director reviewing an overlay animation written as a canvas function (see the code).
You get 4 frames of it rendered on top of the real video (at 20%, 45%, 70% and 95% of the duration) and the code.
Check like a demanding After Effects designer: is it beautiful and premium? Is every text legible (big enough, light on dark,
never cut, never overlapping)? Does it stay inside the safe area and never cover the speaker's face? Is it well composed
(balanced, centered in its area, good margins), are the colors harmonious with the accent, is it clear what it means?
Is it empty, too small, too busy, cheap-looking, or broken? Then rewrite the function fixing EVERY problem you see
(you may redesign it completely if it is weak). Same signature, same rules as before (transparent background, deterministic,
fast, entrance/exit, only the given text).
Answer ONLY with JSON: {"ok": true|false (true only if it was already excellent), "issues": ["short", "list"], "code": "function effect(ctx, t, W, H, p) { ... }"}"""


def review(cfg, code, frames, prompt="", text="", cancel=None):
    """Controllo visivo: l'AI guarda i fotogrammi dell'animazione sopra il video e la corregge. -> {code, ok, issues, usd}"""
    u = (f"What the animation must show: {prompt.strip()[:1200]}\n"
         + (f"Text it must show (exactly): {text.strip()[:120]}\n" if text and text.strip() else "")
         + "Current code:\n" + str(code)[:30000])
    raw = ai.text(cfg, SYSTEM + "\n\n" + REVIEW, u, max_tokens=8000, cancel=cancel, images=frames)
    out = None
    m = re.search(r"\{.*\}", raw.strip(), re.S)
    if m:
        try:
            out = json.loads(m.group(0))
        except Exception:
            out = None
    usd = ai.text_usd(cfg.get("model"), SYSTEM + REVIEW, u, raw) + 0.004 * len(frames or [])
    if not out or "function effect" not in str(out.get("code") or ""):
        return {"code": code, "ok": True, "issues": [], "usd": usd}
    return {"code": str(out["code"])[:40000], "ok": bool(out.get("ok")), "issues": [str(x)[:80] for x in (out.get("issues") or [])][:8], "usd": usd}
