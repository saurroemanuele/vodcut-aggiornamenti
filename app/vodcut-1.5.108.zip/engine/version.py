"""Versione dell'app.

VERSION: sale a ogni aggiornamento.
RUNTIME: sale solo quando cambia quello che sta sotto al codice (Python, librerie, ffmpeg). Un aggiornamento
che chiede un RUNTIME piu' alto di quello installato non si puo' applicare da solo: serve l'installer completo.
"""
VERSION = "1.5.108"
RUNTIME = 1
