"""Progetto: tutto quello che l'utente decide, in un JSON.

Tutti i tempi sono nel tempo del VOD originale (secondi). I tagli vengono tolti solo
all'esportazione, cosi' l'editor puo' sempre rimettere tutto.
"""
import json
import os
import time
import uuid

from .util import PROJECTS_DIR, probe

DEFAULT_SETTINGS = {
    "norm": True,        # volume uguale su tutto il video (-14 LUFS)
    "duck": True,        # musica che si abbassa quando parli
    "denoise": False,    # riduzione rumore (per ora non mostrata)
    "bleep": False,      # bip sulle parolacce (per ora non mostrato)
    "burnSubs": False,   # sottotitoli impressi nel video
    "srt": False,        # file .srt accanto al video (per ora non mostrato)
    "chapters": False,   # capitoli per la descrizione (per ora non mostrati)
    "quality": "1080p",  # 1080p | 1440p | 4K
    "showSubs": True,    # traccia sottotitoli visibile = sottotitoli nel video
}


def new_id(prefix=""):
    return prefix + uuid.uuid4().hex[:8]


def path_for(pid):
    return os.path.join(PROJECTS_DIR, pid + ".json")


def create(source, name=None):
    info = probe(source)
    if not info["has_video"]:
        raise ValueError("Il file non contiene video.")
    pid = new_id("p")
    dur = info["duration"]
    proj = {
        "id": pid,
        "name": name or os.path.splitext(os.path.basename(source))[0],
        "source": os.path.abspath(source),
        "created": time.time(),
        "updated": time.time(),
        "duration": dur,
        "width": info["width"], "height": info["height"], "fps": info["fps"],
        "vcodec": info.get("vcodec"),
        "hasAudio": info["has_audio"],
        "stage": "webcam",          # webcam -> style -> editor
        "webcam": None,              # {"box":[x,y,w,h], "confidence":..}
        "style": {"cuts": 1, "zooms": 1},
        "analysis": None,
        "zooms": [], "cuts": [], "segs": [],
        "transcript": {"status": "none", "segments": []},
        "tracks": [{
            "id": "live", "name": "Audio live", "type": "live", "vol": 100, "mute": False,
            "clips": [{"id": new_id("a"), "a": 0.0, "b": dur, "vol": 100, "mute": False, "fin": False, "fout": False}],
        }],
        "settings": dict(DEFAULT_SETTINGS),
        "lastExport": None,
    }
    save(proj)
    return proj


def load(pid):
    for i in range(40):
        try:
            with open(path_for(pid), encoding="utf-8") as f:
                p = json.load(f)
            break
        except PermissionError:
            if i == 39:
                raise
            time.sleep(0.05)
    s = dict(DEFAULT_SETTINGS)
    s.update(p.get("settings") or {})
    p["settings"] = s
    return ensure_segs(p)


def save(proj):
    proj["updated"] = time.time()
    tmp = path_for(proj["id"]) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(proj, f, ensure_ascii=False)
    for i in range(60):  # su Windows il file puo' essere aperto da un'altra lettura: riprova
        try:
            os.replace(tmp, path_for(proj["id"]))
            break
        except PermissionError:
            if i == 59:
                raise
            time.sleep(0.05)


def delete(pid):
    try:
        os.remove(path_for(pid))
    except OSError:
        pass


def list_projects():
    out = []
    for fn in os.listdir(PROJECTS_DIR):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(PROJECTS_DIR, fn), encoding="utf-8") as f:
                p = json.load(f)
            if p.get("parent"):
                continue   # le clip verticali stanno dentro il loro VOD
            out.append({"id": p["id"], "name": p["name"], "duration": p["duration"], "updated": p.get("updated", 0),
                        "stage": p.get("stage"), "exported": bool(p.get("lastExport")),
                        "exists": os.path.exists(p["source"])})
        except Exception:
            continue
    out.sort(key=lambda x: -x["updated"])
    return out


# ---------------------------------------------------------------- tagli effettivi
def new_seg(a, b, **kw):
    s = {"id": new_id("s"), "a": round(a, 3), "b": round(b, 3), "removed": False, "auto": False,
         "vol": 100, "mute": False, "fin": False, "fout": False}
    s.update(kw)
    return s


def build_segs(proj):
    """Pezzi del video (video + audio insieme), dal vecchio formato tagli + clip audio."""
    dur = proj["duration"]
    cuts = [c for c in proj.get("cuts", []) if c["b"] > c["a"]]
    live = next((t for t in proj.get("tracks", []) if t.get("type") == "live"), None)
    lclips = live["clips"] if live else []
    pts = {0.0, dur}
    for c in cuts:
        pts.update([max(0.0, min(dur, c["a"])), max(0.0, min(dur, c["b"]))])
    for c in lclips:
        pts.update([max(0.0, min(dur, c["a"])), max(0.0, min(dur, c["b"]))])
    pts = sorted(pts)
    segs = []
    for a, b in zip(pts, pts[1:]):
        if b - a < 0.01:
            continue
        mid = (a + b) / 2
        cut = next((c for c in cuts if c["a"] <= mid <= c["b"]), None)
        lc = next((c for c in lclips if c["a"] <= mid <= c["b"]), None) or {}
        segs.append(new_seg(a, b, removed=bool(cut and cut.get("on", True)), auto=bool(cut and cut.get("kind") == "auto"),
                            vol=lc.get("vol", 100), mute=bool(lc.get("mute")), fin=bool(lc.get("fin")), fout=bool(lc.get("fout"))))
    return segs


def ensure_segs(proj):
    if not proj.get("segs"):
        proj["segs"] = build_segs(proj)
    proj.setdefault("assets", [])
    proj["layers"] = norm_layers(proj)
    return proj


def norm_layers(proj):
    """Ordine dei livelli video, dall'alto verso il basso. Il video e' sempre la base."""
    ov = ["ov:" + t["id"] for t in proj.get("tracks", []) if t.get("type") == "overlay"]
    fxk = [("fx" if t["id"] == "fx" else "fx:" + t["id"]) for t in (proj.get("fxTracks") or [{"id": "fx"}])]
    cur = [x for x in (proj.get("layers") or ["subs", "zoom", "fx"]) if x in ("subs", "zoom", "fx") or x in ov or x in fxk]
    for k in ("subs", "zoom", "fx"):
        if k not in cur:
            cur.append(k)
    for k in fxk:
        if k not in cur:
            cur.insert(max(0, cur.index("fx")), k)
    for k in ov:
        if k not in cur:
            cur.insert(0, k)
    return cur + ["video"]


def segs_from_auto_cuts(dur, cuts):
    segs, t = [], 0.0
    for a, b in sorted(cuts):
        if a > t + 0.01:
            segs.append(new_seg(t, a))
        segs.append(new_seg(a, b, removed=True, auto=True))
        t = b
    if dur > t + 0.01:
        segs.append(new_seg(t, dur))
    return segs


def removed_ranges(proj):
    """Intervalli tolti dal video: pezzi tolti + parole cancellate nel testo."""
    ensure_segs(proj)
    r = [(s["a"], s["b"]) for s in proj["segs"] if s.get("removed") and s["b"] > s["a"]]
    for seg in proj.get("transcript", {}).get("segments", []):
        for w in seg.get("words", []):
            if w.get("del"):
                r.append((w["a"], w["b"]))
    r.sort()
    merged = []
    for a, b in r:
        if merged and a <= merged[-1][1] + 0.05:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def keep_segments(proj):
    dur = proj["duration"]
    keep, t = [], 0.0
    for a, b in removed_ranges(proj):
        a, b = max(0.0, a), min(dur, b)
        if a > t + 0.02:
            keep.append((t, a))
        t = max(t, b)
    if dur - t > 0.02:
        keep.append((t, dur))
    return keep


def all_filters(proj):
    """Filtri delle tracce + quelli messi direttamente sulle clip video (filtro e colori della clip).
    Quelli delle clip vanno per primi: stanno subito sopra il video."""
    out = []
    for c in proj.get("segs") or []:
        if c.get("gone") or c.get("removed"):
            continue
        fx = c.get("fx")
        if fx and fx.get("type"):
            out.append({"id": "sf_" + c["id"], "type": fx["type"], "k": fx.get("k", 100), "a": c["a"], "b": c["b"],
                        "track": "fx", "mask": {"type": "all"}})
        adj = c.get("adj") or {}
        if any(adj.get(k) for k in ("bri", "con", "sat", "temp", "tint", "shad", "high")):
            out.append({"id": "sa_" + c["id"], "type": "adjust", "adj": adj, "k": 100, "a": c["a"], "b": c["b"],
                        "track": "fx", "mask": {"type": "all"}})
    return out + list(proj.get("filters") or [])


def seg_speed(proj, t):
    """Velocita' della clip al tempo t (1 = normale)."""
    for c in proj.get("segs") or []:
        if c["a"] <= t < c["b"]:
            try:
                return max(0.25, min(4.0, float(c.get("speed") or 1)))
            except (TypeError, ValueError):
                return 1.0
    return 1.0


def split_by_speed(proj, keep):
    """Divide i pezzi da tenere dove cambia la velocita': [(a, b, velocita')]."""
    bounds = sorted({x for c in proj.get("segs") or [] for x in (c["a"], c["b"])})
    out = []
    for a, b in keep:
        pts = [a] + [x for x in bounds if a + 0.02 < x < b - 0.02] + [b]
        for x, y in zip(pts, pts[1:]):
            sp = seg_speed(proj, (x + y) / 2)
            if out and abs(out[-1][1] - x) < 1e-6 and out[-1][2] == sp:
                out[-1] = (out[-1][0], y, sp)
            else:
                out.append((x, y, sp))
    return out


def make_time_mapper(keep):
    """Tempo originale -> tempo nel video finale (None se tagliato). keep: (a, b) o (a, b, velocita')."""
    starts, acc = [], 0.0
    for k in keep:
        a, b = k[0], k[1]
        sp = k[2] if len(k) > 2 else 1.0
        starts.append((a, b, acc, sp))
        acc += (b - a) / sp

    def f(t):
        for a, b, off, sp in starts:
            if a <= t <= b:
                return off + (t - a) / sp
        return None
    return f, acc


def shift_after(proj, t0, dt):
    """Video inserito in mezzo (al tempo t0, lungo dt): quello che viene dopo si sposta avanti.
    La clip che contiene t0 si divide in due e in mezzo nasce la clip nuova."""
    def sh(x):
        return x + dt if x >= t0 - 1e-6 else x
    for z in proj.get("zooms", []) + proj.get("filters", []) + proj.get("cuts", []):
        z["a"], z["b"] = sh(z["a"]), sh(z["b"])
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            c["a"] = sh(c["a"])
            if "b" in c:
                c["b"] = sh(c["b"])
    for seg in (proj.get("transcript") or {}).get("segments", []):
        seg["a"], seg["b"] = sh(seg["a"]), sh(seg["b"])
        for w in seg.get("words", []):
            w["a"], w["b"] = sh(w["a"]), sh(w["b"])
    segs = []
    for c in proj.get("segs", []):
        if c["b"] <= t0 + 1e-6:
            segs.append(c)
        elif c["a"] >= t0 - 1e-6:
            c["a"] += dt
            c["b"] += dt
            segs.append(c)
        else:   # la clip viene divisa nel punto dove entra il video nuovo
            c2 = dict(c, id=new_id("s"), a=t0 + dt, b=c["b"] + dt)
            c["b"] = t0
            segs += [c, c2]
    segs.append(new_seg(t0, t0 + dt))
    segs.sort(key=lambda x: x["a"])
    proj["segs"] = segs


def shift_times(proj, dt):
    """Sposta avanti di dt secondi tutto quello che sta sulla timeline (video aggiunto all'inizio)."""
    if not dt:
        return
    for z in proj.get("zooms", []):
        z["a"] += dt
        z["b"] += dt
    for f in proj.get("filters", []):
        f["a"] += dt
        f["b"] += dt
    for c in proj.get("cuts", []):
        c["a"] += dt
        c["b"] += dt
    for s in proj.get("segs", []):
        s["a"] += dt
        s["b"] += dt
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            c["a"] += dt
            if "b" in c:
                c["b"] += dt
    for seg in (proj.get("transcript") or {}).get("segments", []):
        seg["a"] += dt
        seg["b"] += dt
        for w in seg.get("words", []):
            w["a"] += dt
            w["b"] += dt


# ---------------------------------------------------------------- video inseriti nella traccia principale
# Un video aggiunto all'inizio, alla fine o in mezzo NON viene unito alla live: resta un file a parte.
# La timeline continua a usare un solo tempo ("tempo della timeline"); qui si calcola quale file c'e'
# in ogni istante e in che punto di quel file.
def live_duration(proj):
    ins = proj.get("inserts") or []
    return proj.get("liveDuration") or (proj["duration"] - sum(i["dur"] for i in ins))


def pieces(proj):
    """[{t0, t1, file, off, live, ins}] in ordine: la live (a pezzi) e i video inseriti."""
    ins = sorted(proj.get("inserts") or [], key=lambda x: x["at"])
    out, T, L = [], 0.0, 0.0
    live_d = live_duration(proj)
    for i in ins:
        if i["at"] > T + 1e-6:
            out.append({"t0": T, "t1": i["at"], "file": proj["source"], "off": L, "live": True, "ins": None})
            L += i["at"] - T
            T = i["at"]
        out.append({"t0": T, "t1": T + i["dur"], "file": i["file"], "off": i.get("offset", 0.0), "live": False, "ins": i})
        T += i["dur"]
    if live_d - L > 1e-3 or not out:
        out.append({"t0": T, "t1": T + (live_d - L), "file": proj["source"], "off": L, "live": True, "ins": None})
    return out


def piece_at(proj, t, pcs=None):
    pcs = pcs or pieces(proj)
    for p in pcs:
        if t < p["t1"] - 1e-6:
            return p
    return pcs[-1]


def live_to_timeline(proj, lt):
    """Istante della live -> istante sulla timeline (per la trascrizione della live)."""
    for p in pieces(proj):
        if p["live"] and p["off"] - 1e-6 <= lt < p["off"] + (p["t1"] - p["t0"]) + 1e-6:
            return p["t0"] + (lt - p["off"])
    return lt


def insert_video(proj, at, info):
    """Mette un video nella timeline al tempo 'at'. info: {file, dur, w, h, hasAudio, name, preview?}.
    Se 'at' cade dentro un altro video inserito, va prima o dopo quello (il piu' vicino)."""
    at = max(0.0, min(proj["duration"], float(at)))
    for i in proj.get("inserts") or []:
        if i["at"] < at < i["at"] + i["dur"]:
            at = i["at"] if at - i["at"] < i["at"] + i["dur"] - at else i["at"] + i["dur"]
    if at < 0.3:
        at = 0.0
    elif at > proj["duration"] - 0.3:
        at = proj["duration"]
    proj.setdefault("liveDuration", live_duration(proj))
    dt = info["dur"]
    shift_after(proj, at, dt)
    for i in proj.get("inserts") or []:
        if i["at"] >= at - 1e-6:
            i["at"] += dt
    rec = {"id": new_id("v"), "at": at, "dur": dt, "offset": 0.0, "file": info["file"], "name": info.get("name"),
           "w": info.get("w"), "h": info.get("h"), "hasAudio": bool(info.get("hasAudio")), "vcodec": info.get("vcodec")}
    if info.get("preview"):
        rec["preview"] = info["preview"]
    proj.setdefault("inserts", []).append(rec)
    proj["inserts"].sort(key=lambda x: x["at"])
    proj["duration"] = proj["duration"] + dt
    return rec


def remove_interval(proj, t0, dt):
    """Il contrario di shift_after: toglie dalla timeline il tratto [t0, t0+dt] e sposta indietro quello che segue."""
    t1 = t0 + dt

    def sh(x):
        return x - dt if x >= t1 - 1e-6 else min(x, t0)
    for z in proj.get("zooms", []) + proj.get("filters", []) + proj.get("cuts", []):
        z["a"], z["b"] = sh(z["a"]), sh(z["b"])
    for k in ("zooms", "filters", "cuts"):
        proj[k] = [z for z in proj.get(k, []) if z["b"] - z["a"] > 0.05]
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            c["a"] = sh(c["a"])
            if "b" in c:
                c["b"] = sh(c["b"])
    tr = proj.get("transcript") or {}
    segs_t = []
    for seg in tr.get("segments", []):
        if seg["a"] >= t0 - 1e-6 and seg["b"] <= t1 + 1e-6:
            continue
        seg["a"], seg["b"] = sh(seg["a"]), sh(seg["b"])
        seg["words"] = [w for w in seg.get("words", []) if not (w["a"] >= t0 - 1e-6 and w["b"] <= t1 + 1e-6)]
        for w in seg["words"]:
            w["a"], w["b"] = sh(w["a"]), sh(w["b"])
        segs_t.append(seg)
    if tr:
        tr["segments"] = segs_t
    out = []
    for c in proj.get("segs", []):
        a, b = sh(c["a"]), sh(c["b"])
        if b - a > 0.02:
            c["a"], c["b"] = a, b
            out.append(c)
    proj["segs"] = out


def repair_merged(proj, orig_duration):
    """Progetti dove un video era stato UNITO alla live (versione vecchia): si torna alla live originale
    e si toglie il pezzo aggiunto (va rimesso trascinandolo, ora non si unisce piu'). Ritorna True se ha riparato."""
    src, orig = proj.get("source") or "", proj.get("origSource")
    if not orig or " (montato" not in os.path.basename(src) or not os.path.exists(orig) or proj.get("inserts"):
        return None
    dt = proj["duration"] - orig_duration
    if dt < 0.05:
        proj["source"] = orig
        proj["duration"] = orig_duration
        proj.pop("origSource", None)
        return (orig_duration, 0.0)
    # dove era finito il video aggiunto: una clip lunga esattamente come lui (di solito l'ultima o la prima)
    at = orig_duration
    cand = [c for c in proj.get("segs", []) if abs((c["b"] - c["a"]) - dt) < 0.15]
    if cand:
        last = [c for c in cand if abs(c["b"] - proj["duration"]) < 0.2]
        first = [c for c in cand if c["a"] < 0.05]
        at = (last or first or cand)[0]["a"]
    remove_interval(proj, at, dt)
    proj["source"] = orig
    proj["duration"] = orig_duration
    if proj.get("segs"):
        proj["segs"][-1]["b"] = min(proj["segs"][-1]["b"], orig_duration)
    proj.pop("origSource", None)
    return (at, dt)


def split_segs_at(segs, points):
    """Divide le clip nei punti dati (i bordi dei video inseriti: ogni video resta una clip a se')."""
    out = []
    for c in segs:
        cuts = [p for p in sorted(points) if c["a"] + 0.02 < p < c["b"] - 0.02]
        a = c["a"]
        for p in cuts:
            out.append(dict(c, id=new_id("s"), a=a, b=p))
            a = p
        out.append(dict(c, a=a) if cuts else c)
    return out
