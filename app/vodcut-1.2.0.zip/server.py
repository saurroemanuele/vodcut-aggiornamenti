"""VODcut - server locale. Avvia l'app: python server.py

Gira solo su questo PC (127.0.0.1). L'interfaccia e' in web/ e si apre in una
finestra di Edge/Chrome in modalita' app.
"""
import json
import math
import mimetypes
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


# con pythonw (senza finestra nera) stdout/stderr non esistono: scriviamo su un file di log
if sys.stdout is None or sys.stderr is None:
    # il log sta nella cartella dell'app, cosi' si trova subito
    # (anche quando gira un aggiornamento: il log resta nella cartella dell'app installata)
    _lp = os.path.join(os.environ.get("VODCUT_BASE") or os.path.dirname(os.path.abspath(__file__)), "vodcut.log")
    try:   # il log non cresce all'infinito: oltre 5 MB si tiene solo l'ultima parte
        if os.path.getsize(_lp) > 5_000_000:
            os.replace(_lp, _lp[:-4] + "-vecchio.log")
    except OSError:
        pass
    _log = open(_lp, "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _log
    sys.stderr = sys.stderr or _log


def _fatal(msg):
    print(msg)
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, msg, "VODcut", 0x10)
        except Exception:
            pass
    sys.exit(1)


def _boot_update():
    """Aggiornamenti automatici: se e' gia' stata scaricata una versione piu' nuova, parte quella."""
    if os.environ.get("VODCUT_BOOTED") or "--no-update" in sys.argv:
        return
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        sys.path.insert(0, here)
        from engine import updater
        updater.boot(here)
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()


_boot_update()


def _repair_opencv():
    """OpenCV a volte si rompe (due versioni installate insieme): lo sistemiamo prima di caricarlo.
    Si prova una volta sola: se non basta, l'app parte lo stesso (senza bloccare ogni avvio)."""
    nw = 0x08000000 if sys.platform == "win32" else 0
    mark = os.path.join(os.path.expanduser("~"), "VODcut", "opencv-controllato-2.txt")
    if os.path.exists(mark):
        return
    chk = [sys.executable, "-c", "import cv2, sys; print(cv2.__version__, cv2.__file__); "
           "sys.exit(0 if hasattr(cv2, 'FaceDetectorYN') or hasattr(cv2, 'CascadeClassifier') else 3)"]
    try:
        c = subprocess.run(chk, capture_output=True, creationflags=nw, timeout=60)
    except Exception:
        return
    if c.returncode == 0:
        return
    why = ((c.stderr.decode(errors="ignore").strip().splitlines() or [""])[-1] or c.stdout.decode(errors="ignore").strip())[:200]
    print(f"[app] OpenCV incompleto ({why}): lo reinstallo (una volta sola, circa un minuto)", flush=True)
    pip = [sys.executable, "-m", "pip"]
    subprocess.run(pip + ["uninstall", "-y", "opencv-python-headless", "opencv-contrib-python", "opencv-contrib-python-headless"],
                   capture_output=True, creationflags=nw)
    r = subprocess.run(pip + ["install", "--force-reinstall", "--no-deps", "opencv-python<5"], capture_output=True, creationflags=nw)
    c = subprocess.run(chk, capture_output=True, creationflags=nw)
    ok = c.returncode == 0
    print("[app] OpenCV " + ("sistemato " + c.stdout.decode(errors="ignore").strip() if ok else "ancora rotto: " + (c.stdout.decode(errors="ignore") + c.stderr.decode(errors="ignore") + r.stderr.decode(errors="ignore"))[-600:]), flush=True)
    try:
        os.makedirs(os.path.dirname(mark), exist_ok=True)
        with open(mark, "w") as f:
            f.write("ok" if ok else "tentato")
    except OSError:
        pass


_repair_opencv()

try:
    import numpy as np
    import cv2  # noqa: F401
except ImportError as _e:
    _fatal(f"Manca una libreria ({_e.name}). Fai doppio clic su INSTALLA.bat e poi riapri VODcut.")

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)


from engine import analyze as A  # noqa: E402
from engine import package as PK  # noqa: E402
from engine import project as P  # noqa: E402
from engine import render as R  # noqa: E402
from engine import transcribe as T  # noqa: E402
from engine import vertical as VT
from engine import face as FACE  # noqa: E402
from engine import story as ST  # noqa: E402
from engine import webcam as W  # noqa: E402
from engine.util import (APP_DIR, CACHE_DIR, EXPORTS_DIR, IMPORTS_DIR, NO_WINDOW, ffmpeg_bin, ffprobe_bin, load_settings,  # noqa: E402
                         nvenc_ok, popen, probe, save_settings, tempdir)

from engine import feedback as FB  # noqa: E402
from engine import updater as UPD  # noqa: E402
from engine.version import VERSION  # noqa: E402


def _code_stamp():
    """Data dell'ultima modifica del codice: serve a riavviare il server dopo un aggiornamento."""
    root = os.path.dirname(os.path.abspath(__file__))
    m = 0.0
    for d, _, files in os.walk(root):
        if "__pycache__" in d:
            continue
        for f in files:
            if f.endswith((".py", ".js", ".css", ".html")):
                m = max(m, os.path.getmtime(os.path.join(d, f)))
    return m


CODE_STAMP = _code_stamp()
WEB = os.path.join(ROOT, "web")
TOKEN = secrets.token_hex(16)
PORT = int(os.environ.get("VODCUT_PORT", "8765"))
LAST_PING = [time.time()]
LOCK = threading.Lock()

# ------------------------------------------------------------------ job in background
JOBS = {}


class Job:
    def __init__(self, kind, pid=None):
        self.id = "j" + secrets.token_hex(5)
        self.kind, self.pid = kind, pid
        self.status, self.progress, self.message = "running", 0.0, ""
        self.result, self.error = None, None
        self.cancelled = False
        self.log = []
        JOBS[self.id] = self

    def to_json(self):
        return {"id": self.id, "kind": self.kind, "pid": self.pid, "status": self.status,
                "progress": round(self.progress, 4), "message": self.message, "result": self.result,
                "error": self.error}


def start_job(kind, pid, fn):
    # un solo job per tipo per progetto
    for j in JOBS.values():
        if j.kind == kind and j.pid == pid and j.status == "running":
            return j
    job = Job(kind, pid)

    def runner():
        try:
            job.result = fn(job)
            job.status = "done" if not job.cancelled else "cancelled"
            job.progress = 1.0
        except R.Cancelled:
            job.status = "cancelled"
        except Exception as e:  # errore leggibile per l'interfaccia
            job.status = "cancelled" if job.cancelled else "error"
            job.error = str(e) or e.__class__.__name__
            traceback.print_exc()
    threading.Thread(target=runner, daemon=True).start()
    return job


def running_jobs():
    return [j for j in JOBS.values() if j.status == "running"]


# ------------------------------------------------------------------ cache analisi
def ckey(pid):
    """Le clip verticali (id "<vod>_v...") usano le cache del VOD da cui vengono: stessa live, niente lavoro doppio."""
    return pid.split("_v")[0]


def wave_path(pid):
    return os.path.join(CACHE_DIR, ckey(pid) + "_wave.json")


def db_path(pid):
    return os.path.join(CACHE_DIR, ckey(pid) + "_db.npy")


PREVIEW_OK = ("h264", "vp8", "vp9")


def job_prepare(job, pid):
    """Webcam + volume dell'audio (appena importato il VOD)."""
    proj = P.load(pid)
    src = proj["source"]
    if proj.get("kind") in ("blank", "story"):   # video di base nero: niente copia leggera, niente webcam
        return _prepare_audio(job, pid, proj)
    # anteprima fluida: per video piu' grandi di 720p (o in formati che l'anteprima non legge)
    # si prepara subito, in parallelo, una copia leggera a 720p
    if int(proj["height"]) > 720 or (proj.get("vcodec") and proj["vcodec"] not in PREVIEW_OK):
        hq = min(720, int(proj["height"]))
        start_job(f"proxy{hq}", pid, lambda j: job_proxy(j, pid, hq))
    if proj.get("kind") in ("video", "blank", "story"):
        return _prepare_audio(job, pid, proj)
    job.message = "Cerco la tua webcam"
    remembered = load_settings().get("webcam")
    try:
        cam = W.detect_webcam(src)
    except Exception:
        traceback.print_exc()
        cam = None
    if not cam:  # nessuna stima: riquadro standard in alto a destra, l'utente lo sistema
        w = int(proj["width"] * 0.24)
        cam = {"box": [proj["width"] - w - int(proj["width"] * 0.01), int(proj["height"] * 0.01), w, int(w * 9 / 16)],
               "confidence": 0.0}
    if remembered and remembered.get("size") == [proj["width"], proj["height"]] and (not cam or cam["confidence"] < 0.6):
        cam = {"box": remembered["box"], "confidence": 1.0, "remembered": True}
    with LOCK:  # la webcam si vede subito, l'audio continua in background
        cur = P.load(pid)
        if not cur.get("webcam"):
            cur["webcam"] = cam
            P.save(cur)
    job.progress = 0.3
    return _prepare_audio(job, pid, proj)


def _prepare_audio(job, pid, proj):
    src = proj["source"]
    if proj.get("hasAudio", True):
        job.message = "Ascolto l'audio"
        db = A.loudness_track(src, progress=lambda x: setattr(job, "progress", 0.3 + 0.7 * x),
                              duration=proj["duration"], cancel=lambda: job.cancelled)
    else:
        db = np.full(int(proj["duration"] / A.HOP) + 1, -90.0, np.float32)
    np.save(db_path(pid), db)
    with open(wave_path(pid), "w") as f:
        json.dump({"perSec": 5, "peaks": A.waveform(db, 5)}, f)
    with LOCK:
        proj = P.load(pid)
        proj["analysis"] = dict(proj.get("analysis") or {}, ready=True)
        P.save(proj)
    return {"webcam": proj.get("webcam")}


# ------------------------------------------------------------------ progetti senza VOD: video normale, vuoto, storia
FORMATS = {"16:9": (1920, 1080), "9:16": (1080, 1920), "1:1": (1080, 1080), "4:5": (1080, 1350)}


def base_path(name):
    d = os.path.join(IMPORTS_DIR, "basi")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, name + ".mp4")


def finish_plain(proj, kind):
    """Progetto che va dritto all'editor: niente webcam, niente tagli e zoom automatici."""
    proj["kind"] = kind
    proj["stage"] = "editor"
    proj["webcam"] = None
    proj["analysis"] = {"ready": True}
    proj["format"] = "native"
    P.save(proj)
    return proj


def create_blank(fmt, dur, name):
    W_, H_ = FORMATS.get(fmt, FORMATS["16:9"])
    dur = max(2.0, min(3600.0, float(dur or 30)))
    src = base_path("vuoto_" + secrets.token_hex(4))
    ST.make_base(src, W_, H_, dur, None, ffmpeg_bin(), NO_WINDOW)
    proj = P.create(src, name=name or "Progetto vuoto")
    proj["hasAudio"] = False
    return finish_plain(proj, "blank")


def job_story_voice(job, data):
    """Voce della storia: trascrizione, tempi di ogni battuta e differenze rispetto allo script."""
    lines = [dict(b) for b in data.get("lines") or [] if (b.get("text") or "").strip()]
    voice = (data.get("voice") or "").strip()
    if not os.path.isfile(voice):
        raise RuntimeError("File della voce non trovato")
    vdur = probe(voice)["duration"]
    if not T.available():
        est = ST.estimate(lines)
        k = vdur / (est[-1][1] or 1)
        return {"dur": vdur, "times": [[round(a * k, 2), round(b * k, 2)] for a, b in est], "report": None,
                "note": "Trascrizione non installata: tempi divisi in proporzione al testo"}
    while GPU["state"] == "installing" and not job.cancelled:
        job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
        time.sleep(1)
    job.message = "Ascolto la voce"
    tr = T.transcribe(voice, vdur, progress=lambda x: setattr(job, "progress", 0.05 + 0.9 * x), cancel=lambda: job.cancelled,
                      log=lambda m: setattr(job, "message", m))
    words = [w for sg in tr.get("segments", []) for w in sg.get("words", [])]
    if not words:
        raise RuntimeError("Nella voce non ho sentito parole")
    times = ST.align(lines, words, vdur)
    regs = ST.speech_regions(words, vdur)
    return {"dur": vdur, "times": times, "report": ST.check_voice(lines, words),
            "words": [[w["w"], round(float(w["a"]), 3), round(float(w["b"]), 3)] for w in words],
            "regions": regs, "trimDur": round(sum(b - a for a, b in regs), 2), "timesTrim": ST.trim_times(regs, times)}


def job_story(job, data):
    """Storia con immagini: tempi (dalla voce o dal testo), video di base 9:16 con la voce, poi l'editor fa il resto."""
    lines = [dict(b) for b in data.get("lines") or [] if (b.get("text") or "").strip()]
    if not lines:
        raise RuntimeError("Lo script e' vuoto")
    voice = (data.get("voice") or "").strip() or None
    if voice and not os.path.isfile(voice):
        raise RuntimeError("File della voce non trovato")
    words = None      # parole della voce [{w, a, b}] (dal controllo della voce, o si trascrive qui)
    times = None
    if voice:
        vdur = probe(voice)["duration"]
        words = [{"w": w[0], "a": w[1], "b": w[2]} for w in data.get("words") or []] or None
        if not words and T.available():
            while GPU["state"] == "installing" and not job.cancelled:
                job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
                time.sleep(1)
            job.message = "Ascolto la voce"
            tr = T.transcribe(voice, vdur, progress=lambda x: setattr(job, "progress", 0.05 + 0.25 * x), cancel=lambda: job.cancelled,
                              log=lambda m: setattr(job, "message", m))
            words = [w for sg in tr.get("segments", []) for w in sg.get("words", [])] or None
        if words:
            times = ST.align(lines, words, vdur)
        else:   # voce senza trascrizione: le battute si dividono la durata in proporzione al testo
            est = ST.estimate(lines)
            k = vdur / (est[-1][1] or 1)
            times = [[round(a * k, 2), round(b * k, 2)] for a, b in est]
    else:
        times = ST.estimate(lines)
    swords = ST.script_words(lines, words) if words else None
    # voce senza i silenzi lunghi tra una frase e l'altra
    if voice and words and data.get("trim"):
        regs = ST.speech_regions(words, vdur)
        job.message = "Tolgo i silenzi dalla voce"
        job.progress = 0.3
        tv = base_path("voce_" + secrets.token_hex(4))[:-4] + ".wav"
        ST.trim_audio(voice, tv, regs, ffmpeg_bin(), NO_WINDOW)
        voice = tv
        times = ST.trim_times(regs, times)
        swords = [[[w, ST.map_time(regs, a), max(ST.map_time(regs, b), ST.map_time(regs, a) + 0.05)] for w, a, b in ln] for ln in swords]
    total = round(max(times[-1][1], 1.0), 2)
    job.message = "Preparo il video"
    job.progress = 0.4
    src = base_path("storia_" + secrets.token_hex(4))
    W_, H_ = FORMATS.get(data.get("format") or "9:16", FORMATS["9:16"])
    ST.make_base(src, W_, H_, total, voice, ffmpeg_bin(), NO_WINDOW, progress=lambda x: setattr(job, "progress", 0.4 + 0.55 * x))
    proj = P.create(src, name=(data.get("name") or "Storia").strip()[:120])
    proj["hasAudio"] = bool(voice)
    imgs = data.get("images") or []
    mots = data.get("motions") or []
    out = []
    ars = {}
    for f in set(x for x in imgs if x):
        try:
            mi = media_info(f)
            ars[f] = (mi["h"] / mi["w"]) if mi.get("w") else 16 / 9
        except Exception:
            pass
    for i, (b, (a, e)) in enumerate(zip(lines, times)):
        f = imgs[i] if i < len(imgs) and imgs[i] and imgs[i] in ars else ""
        out.append({"speaker": b.get("speaker") or "", "text": b["text"].strip(), "a": a, "b": e, "file": f, "ar": ars.get(f),
                    "motion": mots[i] if i < len(mots) and mots[i] else ST.MOTIONS[i % len(ST.MOTIONS)]})
    if swords:
        for ln, ws in zip(out, swords):
            ln["words"] = ws
    proj["story"] = {"lines": out, "colors": data.get("colors") or {}, "pending": True, "voice": voice or "",
                     "captions": data.get("captions") if data.get("captions") in ("line", "word") and swords else "line"}
    finish_plain(proj, "story")
    start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
    return {"project": proj["id"]}


SUB_VERT = {"size": 0.034, "y": 0.74, "maxChars": 22}


def set_format(proj, fmt):
    """Orizzontale <-> verticale: i sottotitoli si adattano (ognuno dei due formati ricorda il suo stile)."""
    old = proj.get("format") or "16:9"
    if old == fmt:
        return
    st = proj.get("subStyle") or {}
    proj["subStyle_" + old.replace(":", "x")] = {k: st.get(k) for k in ("size", "y", "maxChars") if st.get(k) is not None}
    saved = proj.get("subStyle_" + fmt.replace(":", "x"))
    base = saved if saved else (SUB_VERT if fmt == "9:16" else {"size": 0.055, "y": 0.92, "maxChars": 38})
    proj["subStyle"] = dict(st, **base)
    proj["format"] = fmt


def create_vertical(pid, ranges, name):
    """Clip verticale dal VOD: una copia del progetto che mostra solo i pezzi scelti (anche lontani tra loro,
    uno dopo l'altro); il resto e' tolto dalla timeline. Da qui in poi e' indipendente dal VOD."""
    import copy
    src = P.load(pid)
    if src.get("parent"):
        raise ValueError("Questa e' gia' una clip verticale")
    D = float(src["duration"])
    rs = sorted([max(0.0, float(a)), min(D, float(b))] for a, b in ranges if float(b) - float(a) > 0.05)
    merged = []
    for a, b in rs:
        if merged and a <= merged[-1][1] + 1e-6:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    if not merged or sum(b - a for a, b in merged) < 0.5:
        raise ValueError("La clip e' troppo corta")
    ch = copy.deepcopy(src)
    ch["id"] = pid + "_v" + secrets.token_hex(3)
    ch["name"] = (name or "Clip verticale").strip()[:120] or "Clip verticale"
    ch["parent"] = pid
    ch["parentName"] = src.get("name")
    ch["ranges"] = merged
    ch["range"] = [merged[0][0], merged[-1][1]]
    ch["created"] = time.time()
    ch["lastExport"] = None
    ch["stage"] = "editor"
    ch.pop("verticals", None)
    set_format(ch, "9:16")
    ch["vert"] = dict(VT.DEFAULT, **(src.get("vert") or {}))
    eps = 1e-6
    segs = P.split_segs_at(ch.get("segs") or [], [x for r in merged for x in r])
    inr = lambda x0, x1: any(x0 >= a - eps and x1 <= b + eps for a, b in merged)
    for c in segs:
        if not inr(c["a"], c["b"]):
            c["removed"] = True
            c["gone"] = True
    ch["segs"] = segs
    inside = lambda x0, x1: any(x1 > a + eps and x0 < b - eps for a, b in merged)
    ch["zooms"] = [z for z in ch.get("zooms") or [] if inside(z["a"], z["b"])]
    ch["filters"] = [f for f in ch.get("filters") or [] if inside(f["a"], f["b"])]
    for t in ch.get("tracks") or []:
        if t.get("type") in ("overlay", "sound"):
            t["clips"] = [c for c in t.get("clips") or [] if inside(c["a"], c["a"] + float(c.get("dur") or 0))]
    P.save(ch)
    return {"id": ch["id"], "name": ch["name"], "a": merged[0][0], "b": merged[-1][1], "ranges": merged,
            "dur": round(sum(b - a for a, b in merged), 2)}


def export_items(pid, want):
    """Cosa esportare: il VOD e/o alcune sue clip verticali. -> [(progetto, cartella)] e la cartella che le contiene."""
    proj = P.load(pid)
    E = R.export_opts(proj)
    base = E.get("dir") if E.get("dir") and os.path.isdir(E.get("dir")) else EXPORTS_DIR
    vids = [v for v in (proj.get("verticals") or []) if v.get("id") in set(want.get("verticals") or [])]
    subs = []
    for v in vids:
        try:
            subs.append(P.load(v["id"]))
        except Exception:
            continue
    with_vod = bool(want.get("vod", True))
    safe = lambda n: re.sub(r'[\\/:*?"<>|]+', "_", n).strip(" .") or "video"
    folder = None
    if with_vod and subs:
        folder = R.unique_dir(base, safe(proj["name"]))
        items = [(proj, folder)] + [(c, os.path.join(folder, "Clip verticali")) for c in subs]
    elif not with_vod and len(subs) > 1:
        folder = R.unique_dir(base, safe(proj["name"]) + " - Clip verticali")
        items = [(c, folder) for c in subs]
    else:
        items = [(proj, base)] if with_vod else [(c, base) for c in subs]
    # le clip verticali si esportano con le stesse impostazioni scelte per il VOD (qualita', codec…)
    out = []
    for p_, d in items:
        q = dict(p_)
        q["settings"] = dict(p_.get("settings") or {})
        q["settings"]["export"] = dict(E, dir=d)
        q["settings"]["quality"] = (proj.get("settings") or {}).get("quality") or q["settings"].get("quality")
        out.append(q)
    return out, folder


def propose_into(proj, cut_level, zoom_level):
    db = timeline_db(proj)
    cuts, zooms, stats = A.propose(db, proj["duration"], cut_level, zoom_level)
    proj["style"] = {"cuts": cut_level, "zooms": zoom_level}
    proj["cuts"] = []
    proj["segs"] = P.split_segs_at(P.segs_from_auto_cuts(proj["duration"], cuts), [m["t0"] for m in P.pieces(proj)[1:]])
    proj["zooms"] = [{"id": P.new_id("z"), "a": a, "b": b, "on": True, "level": 2.8, "in": "snap", "out": "cut",
                      "auto": True} for a, b in zooms]
    proj["analysis"] = {"ready": True, **stats}
    proj["stage"] = "editor"
    return proj


# ------------------------------------------------------------------ accelerazione NVIDIA per i sottotitoli
# L'installer non la mette (sarebbe 1 GB in piu' per tutti): se c'e' una scheda NVIDIA, l'app la scarica
# da sola in sottofondo la prima volta. La trascrizione, se sta arrivando, la aspetta.
GPU = {"state": "idle", "msg": ""}   # idle | installing | ready | none | failed


def _gpu_libs_ok():
    import site
    for sp in site.getsitepackages():
        base = os.path.join(sp, "nvidia")
        if os.path.isdir(os.path.join(base, "cublas")) and os.path.isdir(os.path.join(base, "cudnn")):
            return True
    return False


def ensure_gpu_bg():
    if sys.platform != "win32":
        GPU["state"] = "none"
        return
    if _gpu_libs_ok():
        GPU["state"] = "ready"
        return
    if not shutil.which("nvidia-smi"):
        GPU["state"] = "none"
        return
    mark = os.path.join(os.path.expanduser("~"), "VODcut", "nvidia-tentativo.txt")
    try:
        if os.path.exists(mark) and time.time() - os.path.getmtime(mark) < 86400:
            GPU["state"] = "failed"   # riprova domani, non a ogni avvio
            return
    except OSError:
        pass

    def run():
        GPU["state"] = "installing"
        print("[app] Scheda NVIDIA: scarico l'accelerazione per i sottotitoli (una volta sola, circa 1 GB)", flush=True)
        py = os.path.join(os.path.dirname(sys.executable), "python.exe")
        if not os.path.exists(py):
            py = sys.executable
        try:
            r = subprocess.run([py, "-m", "pip", "install", "--disable-pip-version-check", "--no-warn-script-location",
                                "nvidia-cublas-cu12", "nvidia-cudnn-cu12==9.*"], capture_output=True, creationflags=NO_WINDOW, timeout=3600)
            ok = r.returncode == 0 and _gpu_libs_ok()
        except Exception as e:
            ok, r = False, None
            print("[app] accelerazione NVIDIA: " + str(e), flush=True)
        GPU["state"] = "ready" if ok else "failed"
        print("[app] Accelerazione NVIDIA " + ("pronta" if ok else "non installata: i sottotitoli useranno il processore"), flush=True)
        if not ok:
            try:
                os.makedirs(os.path.dirname(mark), exist_ok=True)
                with open(mark, "w", encoding="utf-8") as f:
                    f.write((r.stderr.decode(errors="ignore")[-2000:] if r else "errore"))
            except OSError:
                pass
    threading.Thread(target=run, daemon=True).start()


def job_face(job, pid):
    """Tracciamento del viso nella webcam (verticale): la webcam ritagliata segue la faccia."""
    proj = P.load(pid)
    cam = (proj.get("webcam") or {}).get("box")
    if not cam:
        raise RuntimeError("Imposta prima il riquadro della webcam")
    path = FACE.path_for(pid)
    data = FACE.load(path)
    if data.get("cam") != cam or data.get("step") != FACE.STEP:
        data = {"cam": cam, "step": FACE.STEP, "pts": {}, "done": []}
    todo = FACE.missing(data, FACE.live_ranges(proj, P.pieces(proj)))
    total = sum(b - a for a, b in todo) or 1
    W, H = int(proj["width"]), int(proj["height"])
    done_s = 0.0
    job.message = "Cerco il viso nella webcam"

    def check():
        if job.cancelled:
            raise RuntimeError("Annullato")
    for a, b in todo:
        def on_frame(k, a=a):
            job.progress = min(0.99, (done_s + k * FACE.STEP) / total)
        pts = FACE.track_range(proj["source"], cam, W, H, a, b, ffmpeg_bin(), popen, check, on_frame)
        i0 = int(round(a / FACE.STEP))
        for k, pt in enumerate(pts):
            if pt:
                data["pts"][str(i0 + k)] = pt
        data["done"].append([a, b])
        done_s += b - a
        FACE.save(path, data)
    FACE.save(path, data)
    job.progress = 1.0
    return {"points": len(data["pts"])}


def job_transcribe(job, pid):
    # l'accelerazione NVIDIA sta arrivando: meglio aspettarla (poi va molte volte piu' veloce)
    while GPU["state"] == "installing" and not job.cancelled:
        job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
        time.sleep(1)
    try:
        return _job_transcribe(job, pid)
    except Exception as e:
        with LOCK:
            proj = P.load(pid)
            proj["transcript"] = {"status": "error", "error": str(e), "segments": []}
            P.save(proj)
        raise


def _job_transcribe(job, pid):
    proj = P.load(pid)
    job.message = "Preparo la trascrizione (la prima volta scarica il modello)"

    def prog(x):
        job.progress = x
        job.message = "Trascrivo"
    ins = proj.get("inserts") or []
    live_d = P.live_duration(proj)
    tot = live_d + sum(i["dur"] for i in ins)
    res = T.transcribe(proj["source"], live_d, progress=lambda x: prog(x * live_d / tot), cancel=lambda: job.cancelled,
                       log=lambda m: setattr(job, "message", m))
    if ins:
        # la live e' a pezzi sulla timeline: i tempi si spostano; poi si trascrivono i video inseriti
        _shift_tr(res, lambda x: P.live_to_timeline(proj, x))
        done = live_d
        for i in ins:
            try:
                tr = T.transcribe(i["file"], i["dur"] + i.get("offset", 0), progress=lambda x, d0=done, d1=i["dur"]: prog((d0 + x * d1) / tot),
                                  cancel=lambda: job.cancelled, log=lambda m: None)
                off = i.get("offset", 0)
                tr["segments"] = [sg for sg in tr.get("segments", []) if sg["b"] > off and sg["a"] < off + i["dur"]]
                _shift_tr(tr, lambda x, a=i["at"], o=off, d=i["dur"]: a + max(0.0, min(d, x - o)))
                res["segments"] += tr["segments"]
            except Exception:
                traceback.print_exc()
            done += i["dur"]
        res["segments"].sort(key=lambda x: x["a"])
    with LOCK:  # l'utente puo' aver modificato altro nel frattempo
        proj = P.load(pid)
        proj["transcript"] = res
        P.save(proj)
    return {"segments": len(res["segments"])}


def _stream_info(path):
    out = subprocess.check_output([ffprobe_bin(), "-v", "error", "-show_entries",
                                   "stream=codec_type,codec_name,time_base,sample_rate,channels", "-of", "json", path],
                                  creationflags=NO_WINDOW)
    v = a = None
    for st in json.loads(out).get("streams", []):
        if st.get("codec_type") == "video" and not v:
            v = st
        elif st.get("codec_type") == "audio" and not a:
            a = st
    return v or {}, a or {}


def keyframe_near(path, t, window=6.0):
    """Fotogramma chiave del video vicino al tempo t: li' si puo' tagliare senza ricodificare."""
    try:
        out = subprocess.run([ffprobe_bin(), "-v", "error", "-select_streams", "v:0", "-read_intervals", f"{max(0, t - window):.2f}%{t + window:.2f}",
                              "-show_entries", "packet=pts_time,flags", "-of", "csv=p=0", path], capture_output=True, text=True,
                             creationflags=NO_WINDOW).stdout
        ks = [float(l.split(",")[0]) for l in out.splitlines() if "K" in l.split(",")[-1] and l.split(",")[0] not in ("", "N/A")]
    except Exception:
        ks = []
    return min(ks, key=lambda k: abs(k - t)) if ks else t


def job_transcribe_range(job, pid, A, B):
    """Sottotitoli solo di un pezzo della timeline (A..B): si trascrive quel pezzo e si sostituisce quello che c'era."""
    while GPU["state"] == "installing" and not job.cancelled:
        job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
        time.sleep(1)
    proj = P.load(pid)
    lang = (proj.get("transcript") or {}).get("language")
    parts = []
    for pc in P.pieces(proj):
        lo, hi = max(A, pc["t0"]), min(B, pc["t1"])
        if hi - lo > 0.2:
            parts.append((pc, lo, hi))
    tot = sum(hi - lo for _, lo, hi in parts) or 1
    new, done = [], 0.0
    job.message = "Preparo la trascrizione"
    work = tempdir()
    try:
        for k, (pc, lo, hi) in enumerate(parts):
            ss = pc["off"] + (lo - pc["t0"])
            wav = os.path.join(work, f"r{k}.wav")
            subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{ss:.3f}", "-i", pc["file"], "-t", f"{hi - lo:.3f}",
                            "-vn", "-ac", "1", "-ar", "16000", wav], creationflags=NO_WINDOW, check=True)

            def prog(x, d0=done, d1=hi - lo):
                job.progress = min(0.99, (d0 + x * d1) / tot)
                job.message = "Trascrivo"
            tr = T.transcribe(wav, hi - lo, progress=prog, cancel=lambda: job.cancelled, language=lang,
                              log=lambda m: setattr(job, "message", m))
            _shift_tr(tr, lambda x, o=lo, d=hi - lo: round(o + max(0.0, min(d, x)), 2))
            new += tr.get("segments", [])
            lang = lang or tr.get("language")
            done += hi - lo
    finally:
        shutil.rmtree(work, ignore_errors=True)
    with LOCK:
        proj = P.load(pid)
        cur = proj.get("transcript") or {}
        keep = []
        for sg in (cur.get("segments") or []) if cur.get("status") == "done" else []:
            ws = [w for w in sg.get("words", []) if not (w["a"] >= A - 0.05 and w["b"] <= B + 0.05)]
            if ws:
                keep.append(dict(sg, a=ws[0]["a"], b=ws[-1]["b"], words=ws))
        segs = sorted(keep + new, key=lambda x: x["a"])
        proj["transcript"] = {**(cur if cur.get("status") == "done" else {}), "status": "done", "language": lang,
                              "segments": segs, "rev": int(cur.get("rev") or 0) + 1}
        P.save(proj)
    return {"segments": len(new), "words": sum(len(sg["words"]) for sg in new)}


def _shift_tr(tr, f):
    for sg in tr.get("segments", []):
        sg["a"], sg["b"] = f(sg["a"]), f(sg["b"])
        for w in sg.get("words", []):
            w["a"], w["b"] = f(w["a"]), f(w["b"])
    return tr


def ins_proxy_path(pid, clip):
    import hashlib
    k = hashlib.md5(os.path.normcase(os.path.abspath(clip)).encode("utf-8")).hexdigest()[:10]
    return os.path.join(CACHE_DIR, "proxy", f"{ckey(pid)}_ins_{k}.mp4")


def clip_key(clip):
    import hashlib
    st = os.stat(clip)
    return hashlib.md5(f"{os.path.normcase(os.path.abspath(clip))}|{st.st_size}|{int(st.st_mtime)}".encode("utf-8")).hexdigest()[:12]


def clip_db_path(clip):
    return os.path.join(CACHE_DIR, "clips", clip_key(clip) + "_db.npy")


def clip_db(clip, dur, has_audio):
    """Volume dell'audio di un video inserito (tenuto in cache: si calcola una volta sola)."""
    p = clip_db_path(clip)
    if os.path.exists(p):
        try:
            return np.load(p)
        except Exception:
            pass
    db = None
    if has_audio:
        try:
            db = np.asarray(A.loudness_track(clip, duration=dur), np.float32)
        except Exception:
            traceback.print_exc()
    if db is None:
        db = np.full(int(round(dur / A.HOP)) + 1, -90.0, np.float32)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    np.save(p, db)
    return db


def timeline_db(proj):
    """Volume dell'audio lungo tutta la timeline: la live a pezzi + i video inseriti."""
    live = np.load(db_path(proj["id"]))
    if not proj.get("inserts"):
        return live
    out = []
    for m in P.pieces(proj):
        a, n = int(round(m["off"] / A.HOP)), int(round((m["t1"] - m["t0"]) / A.HOP))
        if m["live"]:
            part = live[a:a + n]
        else:
            try:
                part = clip_db(m["file"], m["ins"]["dur"] + m["off"], m["ins"].get("hasAudio"))[a:a + n]
            except Exception:
                part = np.zeros(0, np.float32)
        if len(part) < n:
            part = np.concatenate([part, np.full(n - len(part), -90.0, np.float32)])
        out.append(part)
    return np.concatenate(out) if out else live


def job_prepinsert(job, pid, clip):
    """Prepara un video da mettere nella traccia principale. Il progetto NON viene toccato:
    lo mette in timeline l'editor, subito (cosi' e' fluido e si puo' annullare)."""
    proj = P.load(pid)
    ci = probe(clip)
    if not ci["has_video"]:
        raise RuntimeError("Il file scelto non contiene video")
    fps = float(proj.get("fps") or 30)
    clip_d = math.floor(float(ci["duration"] or 0) * fps) / fps   # durata a fotogrammi interi
    if clip_d < 0.1:
        raise RuntimeError("Il video scelto e' troppo corto")
    info = {"file": os.path.abspath(clip), "dur": clip_d, "w": ci.get("width"), "h": ci.get("height"),
            "hasAudio": bool(ci.get("has_audio")), "vcodec": ci.get("vcodec"), "name": os.path.basename(clip)}
    # copia leggera per l'anteprima solo se serve (video grande o formato che l'anteprima non legge)
    if int(ci.get("height") or 0) > 760 or (ci.get("vcodec") and ci["vcodec"] not in PREVIEW_OK):
        out = ins_proxy_path(pid, clip)
        if not os.path.exists(out):
            os.makedirs(os.path.dirname(out), exist_ok=True)
            part = out + ".part.mp4"
            job.message = "Preparo l'anteprima del video"
            vf = f"fps={min(30.0, fps):g},scale=-2:{min(720, int(ci.get('height') or 720))}"
            encs = []
            if nvenc_ok():
                encs.append(["-c:v", "h264_nvenc", "-preset", "p1", "-rc", "vbr", "-cq", "30", "-b:v", "0", "-pix_fmt", "yuv420p"])
            encs.append(["-c:v", "libx264", "-preset", "ultrafast", "-crf", "27", "-tune", "fastdecode", "-pix_fmt", "yuv420p"])
            ok, err = False, ""
            for enc in encs:
                pr = subprocess.Popen([ffmpeg_bin(), "-v", "error", "-y", "-i", clip, "-vf", vf, *enc, "-c:a", "aac", "-b:a", "128k",
                                       "-ac", "2", "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", part],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
                for line in pr.stdout:
                    if job.cancelled:
                        pr.kill()
                        raise R.Cancelled()
                    m = re.match(rb"out_time_(?:us|ms)=(\d+)", line)
                    if m:
                        job.progress = min(0.8, 0.8 * int(m.group(1)) / 1e6 / max(0.1, clip_d))
                pr.wait()
                if pr.returncode == 0:
                    os.replace(part, out)
                    ok = True
                    break
                err = pr.stderr.read().decode(errors="ignore")[-300:]
            if not ok:
                raise RuntimeError("Non riesco a leggere questo video: " + err)
        info["preview"] = out
    job.message = "Ascolto l'audio del video"
    job.progress = max(job.progress, 0.85)
    db = clip_db(clip, clip_d, ci.get("has_audio"))[:int(round(clip_d / A.HOP)) + 1]
    info["peaks"] = A.waveform(db, 5)
    job.progress = 1.0
    return info


def job_insert_transcript(job, pid, clip, dur, offset=0.0):
    """Trascrizione di un video inserito (tempi dal suo inizio): l'editor la mette al posto giusto."""
    job.message = "Trascrivo il video aggiunto"
    tr = T.transcribe(clip, dur + offset, progress=lambda x: setattr(job, "progress", x), cancel=lambda: job.cancelled, log=lambda m: None)
    segs = [sg for sg in tr.get("segments", []) if sg["b"] > offset and sg["a"] < offset + dur]
    return {"segments": _shift_tr({"segments": segs}, lambda x: max(0.0, min(dur, x - offset)))["segments"]}


def job_export(job, pid, want=None):
    if want and (want.get("verticals") or want.get("vod") is False):
        return job_export_many(job, pid, want)
    proj = P.load(pid)

    def lg(m):
        job.log.append(m)
        print(f"[export] {time.strftime('%H:%M:%S')} {m}", flush=True)
    t0 = time.time()
    lg(f"inizio: {proj.get('name')} · {proj.get('duration', 0):.0f} s · video inseriti: {len(proj.get('inserts') or [])}")
    try:
        res = R.render(proj, progress=lambda x, m: (setattr(job, "progress", x), setattr(job, "message", m)),
                       cancel=lambda: job.cancelled, log=lg)
    except R.Cancelled:
        raise
    except Exception as e:
        # l'errore resta scritto: si puo' mandare a chi ti aiuta
        det = traceback.format_exc()
        print("[export] ERRORE\n" + det, flush=True)
        try:
            with open(os.path.join(APP_DIR, "ultimo-errore-export.txt"), "w", encoding="utf-8") as f:
                f.write(f"VODcut {VERSION} · {time.strftime('%Y-%m-%d %H:%M:%S')}\nProgetto: {proj.get('name')}\n\n"
                        + "\n".join(job.log[-30:]) + "\n\n" + det)
        except OSError:
            pass
        raise RuntimeError(str(e) or e.__class__.__name__)
    lg(f"fatto in {time.time() - t0:.0f} s")
    with LOCK:
        proj = P.load(pid)
        proj["lastExport"] = {**res, "at": time.time()}
        P.save(proj)
    return res


def job_export_many(job, pid, want):
    """VOD e clip verticali in un colpo solo, uno dopo l'altro (in una cartella se sono piu' di uno)."""
    items, folder = export_items(pid, want)
    if not items:
        raise RuntimeError("Niente da esportare")

    def lg(m):
        job.log.append(m)
        print(f"[export] {time.strftime('%H:%M:%S')} {m}", flush=True)
    n = len(items)
    files = []
    for i, q in enumerate(items):
        os.makedirs(q["settings"]["export"]["dir"], exist_ok=True)
        tag = f"{i + 1} di {n} · {q['name']}" if n > 1 else q["name"]
        lg(f"inizio: {tag}")
        try:
            res = R.render(q, progress=lambda x, m, i=i: (setattr(job, "progress", (i + x) / n), setattr(job, "message", (f"Video {i + 1} di {n} · " if n > 1 else "") + m)),
                           cancel=lambda: job.cancelled, log=lg)
        except R.Cancelled:
            raise
        except Exception as e:
            det = traceback.format_exc()
            print("[export] ERRORE\n" + det, flush=True)
            try:
                with open(os.path.join(APP_DIR, "ultimo-errore-export.txt"), "w", encoding="utf-8") as f:
                    f.write(f"VODcut {VERSION} · {time.strftime('%Y-%m-%d %H:%M:%S')}\nProgetto: {q.get('name')}\n\n"
                            + "\n".join(job.log[-30:]) + "\n\n" + det)
            except OSError:
                pass
            raise RuntimeError(f"{q['name']}: {e}" if n > 1 else (str(e) or e.__class__.__name__))
        files.append({"name": q["name"], "vertical": bool(q.get("parent")), **res})
        with LOCK:
            try:
                cur = P.load(q["id"])
                cur["lastExport"] = {**res, "at": time.time()}
                P.save(cur)
            except Exception:
                pass
    res = {**files[0], "files": files, "folder": folder}
    with LOCK:
        proj = P.load(pid)
        proj["lastExport"] = {**res, "at": time.time()}
        P.save(proj)
    return res


def job_download(job, url):
    try:
        import yt_dlp
    except ImportError:
        raise RuntimeError("Per importare da link serve yt-dlp. Riesegui INSTALLA.bat.")
    job.message = "Scarico il VOD"

    def hook(d):
        if job.cancelled:
            raise RuntimeError("annullato")
        if d.get("status") == "downloading":
            tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if tot:
                job.progress = min(0.98, d.get("downloaded_bytes", 0) / tot)
    opts = {"outtmpl": os.path.join(IMPORTS_DIR, "%(title).80s [%(id)s].%(ext)s"), "progress_hooks": [hook],
            "format": "bv*[height<=1080]+ba/b[height<=1080]/best", "merge_output_format": "mp4", "quiet": True,
            "noprogress": True, "ffmpeg_location": shutil.which("ffmpeg")}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        path = ydl.prepare_filename(info)
        if not os.path.exists(path):
            path = os.path.splitext(path)[0] + ".mp4"
    proj = P.create(path, name=info.get("title"))
    return {"project": proj["id"]}


# ------------------------------------------------------------------ utilita'
NATIVE = {"win": None}   # finestra nativa (pywebview), se c'e'


_DIALOG_EN = {"Video, immagini e suoni": "Videos, images and sounds", "Video immagini e suoni": "Videos images and sounds", "Immagini": "Images", "Suoni": "Sounds",
              "Tutti i file": "All files", "Progetto VODcut": "VODcut project", "Dove salvo il video?": "Where should I save the video?",
              "Importa video, immagini e suoni": "Import videos, images and sounds", "Scegli uno o piu' suoni": "Choose one or more sounds",
              "Apri un progetto VODcut": "Open a VODcut project", "Salva il progetto": "Save the project",
              "Dov'è questo file?": "Where is this file?", "Scegli il VOD": "Choose the VOD",
              "Selettore file non disponibile": "File picker not available", "Video": "Videos", "Audio": "Audio"}


def _L(s):
    """Testi delle finestre di Windows (scegli file, salva) nella lingua dell'app."""
    if load_settings().get("lang") != "en":
        return s
    head, sep, rest = s.partition(" (")
    return _DIALOG_EN.get(head, head) + sep + rest


def pick_file_native(kind):
    """Selettore file di Windows dalla finestra dell'app (non serve tkinter)."""
    import webview
    win = NATIVE["win"]
    FD = getattr(webview, "FileDialog", None)
    OPEN = FD.OPEN if FD else 10
    FOLDER = FD.FOLDER if FD else 20
    if kind == "folder":
        r = win.create_file_dialog(FOLDER)
        print(f"[pick] cartella: {r!r}", flush=True)
        if isinstance(r, str):   # alcune versioni di pywebview danno il percorso e non una lista
            return (r or None), None
        return (r[0] if r else None), None
    if kind == "media":
        r = win.create_file_dialog(OPEN, allow_multiple=True, file_types=(
            _L("Video immagini e suoni (*.mp4;*.mkv;*.mov;*.webm;*.m4v;*.avi;*.flv;*.ts;*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp;*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac)"),
            _L("Video (*.mp4;*.mkv;*.mov;*.webm;*.m4v;*.avi;*.flv;*.ts)"), _L("Immagini (*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp)"),
            _L("Suoni (*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac)"), _L("Tutti i file (*.*)")))
        return list(r or []), None
    if kind == "audio":
        r = win.create_file_dialog(OPEN, allow_multiple=True, file_types=(_L("Audio (*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac)"), _L("Tutti i file (*.*)")))
        return list(r or []), None
    if kind == "project-open":
        r = win.create_file_dialog(OPEN, file_types=(_L("Progetto VODcut (*.vodcut)"), _L("Tutti i file (*.*)")))
        return (r[0] if r else None), None
    if kind.startswith("project-save:"):
        SAVE = FD.SAVE if FD else 30
        r = win.create_file_dialog(SAVE, save_filename=kind.split(":", 1)[1] + ".vodcut", file_types=(_L("Progetto VODcut (*.vodcut)"),))
        r = r[0] if isinstance(r, (list, tuple)) else r
        return (r or None), None
    if kind in ("relink-image", "relink-audio", "relink-file"):
        ft = {"relink-image": (_L("Immagini (*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp)"), _L("Tutti i file (*.*)")),
              "relink-audio": (_L("Audio (*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac;*.opus)"), _L("Tutti i file (*.*)"))}.get(kind, (_L("Tutti i file (*.*)"),))
        r = win.create_file_dialog(OPEN, file_types=ft)
        return (r[0] if r else None), None
    r = win.create_file_dialog(OPEN, file_types=(_L("Video (*.mp4;*.mkv;*.mov;*.flv;*.ts;*.webm)"), _L("Tutti i file (*.*)")))
    return (r[0] if r else None), None


def pick_file(kind):
    """Finestra nativa per scegliere un file (quella dell'app, se no tkinter)."""
    if NATIVE["win"] is not None:
        try:
            return pick_file_native(kind)
        except Exception:
            traceback.print_exc()
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None, _L("Selettore file non disponibile")
    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
    except Exception:
        return None, _L("Selettore file non disponibile")
    if kind == "folder":
        path = filedialog.askdirectory(title=_L("Dove salvo il video?"), mustexist=True)
        root.destroy()
        return path or None, None
    if kind == "media":
        types = [(_L("Video, immagini e suoni"), "*.mp4 *.mkv *.mov *.webm *.m4v *.avi *.flv *.ts *.png *.jpg *.jpeg *.webp *.gif *.bmp *.mp3 *.wav *.m4a *.aac *.ogg *.flac"),
                 (_L("Video"), "*.mp4 *.mkv *.mov *.webm *.m4v *.avi *.flv *.ts"),
                 (_L("Immagini"), "*.png *.jpg *.jpeg *.webp *.gif *.bmp"), (_L("Suoni"), "*.mp3 *.wav *.m4a *.aac *.ogg *.flac"),
                 (_L("Tutti i file"), "*.*")]
        paths = filedialog.askopenfilenames(title=_L("Importa video, immagini e suoni"), filetypes=types)
        root.destroy()
        return list(paths), None
    if kind == "audio":
        types = [(_L("Audio"), "*.mp3 *.wav *.m4a *.aac *.ogg *.flac"), (_L("Tutti i file"), "*.*")]
        paths = filedialog.askopenfilenames(title=_L("Scegli uno o piu' suoni"), filetypes=types)
        root.destroy()
        return list(paths), None
    if kind == "project-open":
        path = filedialog.askopenfilename(title=_L("Apri un progetto VODcut"), filetypes=[(_L("Progetto VODcut"), "*.vodcut"), (_L("Tutti i file"), "*.*")])
        root.destroy()
        return path or None, None
    if kind.startswith("project-save:"):
        path = filedialog.asksaveasfilename(title=_L("Salva il progetto"), initialfile=kind.split(":", 1)[1] + ".vodcut",
                                            defaultextension=".vodcut", filetypes=[(_L("Progetto VODcut"), "*.vodcut")])
        root.destroy()
        return path or None, None
    if kind in ("relink-image", "relink-audio", "relink-file"):
        path = filedialog.askopenfilename(title=_L("Dov'è questo file?"))
        root.destroy()
        return path or None, None
    types = [(_L("Video"), "*.mp4 *.mkv *.mov *.flv *.ts *.webm"), (_L("Tutti i file"), "*.*")]
    path = filedialog.askopenfilename(title=_L("Scegli il VOD"), filetypes=types)
    root.destroy()
    return path or None, None


IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")
AUD_EXT = (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".opus")
VID_EXT = (".mp4", ".mkv", ".mov", ".webm", ".m4v", ".avi", ".flv", ".ts")


def media_info(path):
    """Video, immagine o suono da usare nel progetto (Media)."""
    ext = os.path.splitext(path)[1].lower()
    name = os.path.basename(path)
    if ext in IMG_EXT:
        info = probe(path)
        return {"path": path, "name": name, "kind": "image", "w": info.get("width", 0), "h": info.get("height", 0)}
    info = probe(path)
    if ext in AUD_EXT or (info.get("has_audio") and not info.get("has_video")):
        return {"path": path, "name": name, "kind": "audio", "duration": info["duration"]}
    if info.get("has_video") and info.get("duration", 0) > 0:
        return {"path": path, "name": name, "kind": "video", "duration": info["duration"], "w": info.get("width", 0),
                "h": info.get("height", 0), "hasAudio": bool(info.get("has_audio")), "vcodec": info.get("vcodec")}
    raise ValueError("Formato non supportato: usa video (mp4, mov…), immagini (png, jpg…) o suoni (mp3, wav…)")


def media_thumb(path, t=1.0, h=180):
    """Anteprima di un video importato (per i Media e la timeline)."""
    d = os.path.join(CACHE_DIR, "mthumbs")
    os.makedirs(d, exist_ok=True)
    key = re.sub(r"\W", "_", os.path.abspath(path))[-120:]
    fn = os.path.join(d, f"{key}_{int(t * 10)}_{h}.jpg")
    if not os.path.exists(fn):
        subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{max(0, t):.2f}", "-i", path, "-frames:v", "1",
                        "-vf", f"scale=-2:{h}", "-q:v", "5", fn], creationflags=NO_WINDOW)
        if not os.path.exists(fn):   # video piu' corto del secondo scelto
            subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-i", path, "-frames:v", "1", "-vf", f"scale=-2:{h}", "-q:v", "5", fn],
                           creationflags=NO_WINDOW)
    return fn


_REMBG = {}


def job_removebg(job, path):
    """Toglie lo sfondo da un'immagine (rembg, tutto in locale). La prima volta installa lo strumento e scarica il modello."""
    nw = 0x08000000 if sys.platform == "win32" else 0
    try:
        import rembg  # noqa: F401
    except ImportError:
        job.message = "Installo lo strumento (solo la prima volta, qualche minuto)"
        job.progress = 0.05
        r = subprocess.run([sys.executable, "-m", "pip", "install", "rembg[cpu]"], capture_output=True, creationflags=nw)
        if r.returncode != 0:
            raise RuntimeError("Installazione non riuscita: " + r.stderr.decode(errors="ignore")[-300:])
        import importlib
        importlib.invalidate_caches()
    import rembg
    if "s" not in _REMBG:
        job.message = "Preparo il modello (la prima volta lo scarico, circa 170 MB)"
        job.progress = 0.3
        _REMBG["s"] = rembg.new_session("isnet-general-use")
    job.message = "Rimuovo lo sfondo"
    job.progress = 0.7
    with open(path, "rb") as f:
        data = rembg.remove(f.read(), session=_REMBG["s"])
    base = os.path.splitext(os.path.basename(path))[0]
    os.makedirs(IMPORTS_DIR, exist_ok=True)
    out = os.path.join(IMPORTS_DIR, f"{base} (senza sfondo).png")
    i = 2
    while os.path.exists(out):
        out = os.path.join(IMPORTS_DIR, f"{base} (senza sfondo {i}).png")
        i += 1
    with open(out, "wb") as f:
        f.write(data)
    return media_info(out)


def proxy_path(pid, h):
    return os.path.join(CACHE_DIR, "proxy", f"{ckey(pid)}_{int(h)}.mp4")


def job_proxy(job, pid, h):
    """Copia leggera del VOD per l'anteprima (qualita' scelta, max 30 fps, un keyframe al secondo)."""
    proj = P.load(pid)
    out = proxy_path(pid, h)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    part = out + ".part.mp4"
    fps = min(30.0, proj.get("fps") or 30.0)
    g = str(int(round(fps)))
    vf = f"fps={fps:g},scale=-2:{int(h)}"
    base = [ffmpeg_bin(), "-v", "error", "-y", "-i", proj["source"], "-vf", vf]
    tail = ["-t", f"{P.live_duration(proj) + 0.5:.3f}",   # mai piu' lunga della live (file con tempi rovinati)
            "-c:a", "aac", "-b:a", "128k", "-ac", "2", "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", part]
    encs = []
    if nvenc_ok():
        encs.append(["-c:v", "h264_nvenc", "-preset", "p1", "-rc", "vbr", "-cq", "30", "-b:v", "0", "-g", g, "-pix_fmt", "yuv420p"])
    encs.append(["-c:v", "libx264", "-preset", "ultrafast", "-crf", "27", "-g", g, "-tune", "fastdecode", "-pix_fmt", "yuv420p"])
    dur = max(0.1, P.live_duration(proj))
    err = ""
    for enc in encs:
        job.message = "Preparo l'anteprima leggera"
        # priorita' bassa: la copia per l'anteprima non deve rallentare il resto del PC
        pr = subprocess.Popen(base + enc + tail, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              creationflags=NO_WINDOW | (0x4000 if sys.platform == "win32" else 0))
        for line in pr.stdout:
            if job.cancelled:
                pr.kill()
                raise R.Cancelled()
            m = re.match(rb"out_time_(?:us|ms)=(\d+)", line)
            if m:
                job.progress = min(0.99, int(m.group(1)) / 1e6 / dur)
        pr.wait()
        if pr.returncode == 0:
            os.replace(part, out)
            return {"path": out}
        err = pr.stderr.read().decode(errors="ignore")[-300:]
    raise RuntimeError("Anteprima leggera non riuscita: " + err)


def open_path(path, reveal=False):
    if not os.path.exists(path):
        return False
    if sys.platform == "win32":
        if reveal:
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        else:
            os.startfile(path)  # noqa
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", path] if reveal else ["open", path])
    else:
        subprocess.Popen(["xdg-open", os.path.dirname(path) if reveal else path])
    return True


_MEDIA_CACHE = {}  # file progetto -> (mtime, set di file consentiti)


PICKED = set()   # file scelti dall'utente in questa sessione (anteprime prima di creare il progetto)


def allow_picked(paths):
    for x in paths or []:
        if x:
            PICKED.add(os.path.normcase(os.path.abspath(x)))


def allowed_media(path):
    """Solo file che fanno parte di un progetto (niente accesso libero al disco)."""
    key = os.path.normcase(os.path.abspath(path))
    if key in PICKED:
        return True
    if key.startswith(os.path.normcase(os.path.abspath(IMPORTS_DIR)) + os.sep):
        return True
    if key.startswith(os.path.normcase(os.path.abspath(os.path.join(CACHE_DIR, "proxy"))) + os.sep) and key.endswith(".mp4"):
        return True
    for fn in os.listdir(P.PROJECTS_DIR):
        if not fn.endswith(".json"):
            continue
        fp = os.path.join(P.PROJECTS_DIR, fn)
        try:
            mt = os.path.getmtime(fp)
            cached = _MEDIA_CACHE.get(fp)
            if not cached or cached[0] != mt:
                with open(fp, encoding="utf-8") as f:
                    pj = json.load(f)
                files = [pj.get("source")] + [c.get("file") for t in pj.get("tracks", []) for c in t.get("clips", [])]
                files += [a.get("path") for a in pj.get("assets", [])]
                files += [ln.get("file") for ln in (pj.get("story") or {}).get("lines", [])]
                files += [i.get(k) for i in pj.get("inserts") or [] for k in ("file", "preview")]
                if pj.get("lastExport"):
                    files.append(pj["lastExport"].get("path"))
                cached = (mt, {os.path.normcase(os.path.abspath(x)) for x in files if x})
                _MEDIA_CACHE[fp] = cached
        except Exception:
            continue
        if key in cached[1]:
            return True
    return False


def thumb(pid, t, h):
    proj = P.load(pid)
    d = os.path.join(CACHE_DIR, "thumbs", ckey(pid))
    os.makedirs(d, exist_ok=True)
    m = P.piece_at(proj, t)
    st = max(0.0, m["off"] + t - m["t0"])   # istante dentro al file (la live o un video inserito)
    key = "live" if m["live"] else m["ins"]["id"]
    fn = os.path.join(d, f"{key}_{int(st * 10)}_{h}.jpg")
    if not os.path.exists(fn):
        subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{st:.2f}", "-i", m["file"],
                        "-frames:v", "1", "-vf", f"scale=-2:{h}", "-q:v", "5", fn], creationflags=NO_WINDOW)
    return fn


def strip_dir(pid):
    """Miniature della live (i video inseriti usano le loro, al volo)."""
    return os.path.join(CACHE_DIR, "thumbs", ckey(pid), "src_live")


def _live_strip(pid, proj=None):
    """(cartella, intervallo, file) delle miniature della live, o None se non sono pronte."""
    d = strip_dir(pid)
    old = os.path.join(CACHE_DIR, "thumbs", ckey(pid), "strip")
    if not os.path.exists(os.path.join(d, "done.txt")) and os.path.exists(os.path.join(old, "done.txt")):
        # versioni prima: la striscia vecchia era della live (senza video inseriti): si tiene
        proj = proj or P.load(pid)
        if not proj.get("inserts"):
            try:
                with open(os.path.join(old, "done.txt")) as f:
                    v = f.read().strip()
                iv = float(v) if v not in ("", "ok") else max(1.0, round(P.live_duration(proj) / 300.0, 2))
                os.replace(old, d)
                with open(os.path.join(d, "done.txt"), "w") as f:
                    f.write(str(iv))
            except (OSError, ValueError):
                pass
    if not os.path.exists(os.path.join(d, "done.txt")):
        return None
    ent = _STRIP_CACHE.get(d)
    mt = os.path.getmtime(os.path.join(d, "done.txt"))
    if not ent or ent[0] != mt:
        with open(os.path.join(d, "done.txt")) as f:
            try:
                iv = float(f.read().strip())
            except ValueError:
                iv = 1.0
        ent = (mt, iv, sorted(x for x in os.listdir(d) if x.endswith(".jpg")))
        _STRIP_CACHE[d] = ent
    return d, ent[1], ent[2]


_STRIP_CACHE = {}


def strip_info(pid, dur):
    interval = max(1.0, round(dur / 300.0, 2))  # al massimo ~300 miniature sulla timeline
    ls = _live_strip(pid)
    return {"ready": bool(ls), "interval": interval, "count": int(dur // interval) + 1}


def strip_tile(pid, i):
    """Miniatura numero i della timeline: dalla live o dal video inserito che c'e' in quel punto."""
    proj = P.load(pid)
    iv = max(1.0, round(proj["duration"] / 300.0, 2))
    t = i * iv
    m = P.piece_at(proj, t)
    st = max(0.0, m["off"] + t - m["t0"])
    if m["live"]:
        ls = _live_strip(pid, proj)
        if not ls or not ls[2]:
            return None
        d, siv, files = ls
        return os.path.join(d, files[max(0, min(len(files) - 1, int(round(st / siv))))])
    f = m["ins"].get("file")
    return media_thumb(f, round(st, 1), 120) if f and os.path.exists(f) else None


def job_thumbs(job, pid):
    """Tutte le miniature della live in una sola passata (solo keyframe: velocissimo)."""
    proj = P.load(pid)
    d = strip_dir(pid)
    iv = max(1.0, round(P.live_duration(proj) / 300.0, 2))
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d, exist_ok=True)
    cmd = [ffmpeg_bin(), "-v", "error", "-y", "-skip_frame", "nokey", "-i", proj["source"], "-an",
           "-vf", f"fps=1/{iv},scale=-2:120", "-fps_mode", "vfr", "-q:v", "6", os.path.join(d, "%05d.jpg")]
    r = subprocess.run(cmd, creationflags=NO_WINDOW, capture_output=True)
    if r.returncode != 0:  # ffmpeg vecchi: -vsync al posto di -fps_mode
        cmd[cmd.index("-fps_mode")] = "-vsync"
        subprocess.run(cmd, creationflags=NO_WINDOW, capture_output=True)
    with open(os.path.join(d, "done.txt"), "w") as f:
        f.write(str(iv))
    return strip_info(pid, proj["duration"])


LICENSE_VER = "1.0"


def license_ok():
    """Licenza accettata: nell'installer (file segnaposto) o nell'app, la prima volta."""
    return load_settings().get("licenza") == LICENSE_VER or os.path.exists(os.path.join(APP_DIR, "licenza-accettata.txt"))


def env_info():
    return {"version": VERSION, "ffmpeg": bool(shutil.which("ffmpeg")), "gpu": nvenc_ok(),
            "whisper": T.available(), "ytdlp": _has("yt_dlp"), "exportsDir": EXPORTS_DIR, "appDir": APP_DIR,
            "licenseOk": license_ok(), "licenseVer": LICENSE_VER, "badges": load_settings().get("badges") or {},
            "autoUpdate": load_settings().get("autoUpdate") is not False, "platform": UPD.PLATFORM}


def _has(mod):
    try:
        __import__(mod)
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ HTTP
MIME = {".js": "text/javascript", ".css": "text/css", ".html": "text/html", ".json": "application/json",
        ".mp4": "video/mp4", ".m4v": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm", ".mkv": "video/x-matroska",
        ".m4a": "audio/mp4", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".ogg": "audio/ogg", ".flac": "audio/flac",
        ".aac": "audio/aac", ".jpg": "image/jpeg", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon"}


class H(BaseHTTPRequestHandler):
    server_version = "VODcut"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *a):
        # diagnostica leggera: registra le richieste (tranne quelle continue)
        try:
            line = fmt % a
            if "/api/ping" not in line and "/api/jobs/" not in line and "/tile" not in line:
                print(f"[http] {time.strftime('%H:%M:%S')} {self.server.server_address[1]} {line[:160]}", flush=True)
        except Exception:
            pass

    # --- risposte
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
            pass  # la finestra ha cambiato pagina prima della risposta

    def err(self, msg, code=400):
        self.send_json({"error": msg}, code)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def send_file(self, path, ctype=None, cache=False, nostore=False):
        if not os.path.isfile(path):
            return self.err("non trovato", 404)
        size = os.path.getsize(path)
        # tabella fissa: su Windows il registro puo' dire .js = text/plain (pagina bianca)
        ctype = ctype or MIME.get(os.path.splitext(path)[1].lower()) or mimetypes.guess_type(path)[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    if m.group(2):
                        end = min(size - 1, int(m.group(2)))
                elif m.group(2):
                    start = max(0, size - int(m.group(2)))
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        else:
            self.send_response(200)
        length = end - start + 1
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store" if nostore else ("max-age=3600" if cache else "no-cache"))
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(path, "rb") as f:
            f.seek(start)
            left = length
            try:
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
                pass

    def blocked(self):
        """Solo l'app stessa puo' parlare con il server. Blocca i siti web aperti nel browser che provano a
        chiamare 127.0.0.1 (anche con il trucco del "DNS rebinding"): controlla Host, Origin e Sec-Fetch-Site."""
        port = self.server.server_address[1]
        ok_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        host = (self.headers.get("Host") or "").lower()
        bad = host not in ok_hosts
        origin = self.headers.get("Origin")
        if origin and origin.lower() not in {"http://" + h for h in ok_hosts}:
            bad = True
        if (self.headers.get("Sec-Fetch-Site") or "").lower() in ("cross-site", "same-site"):
            bad = True
        if bad:
            print(f"[sicurezza] richiesta bloccata: host={host!r} origin={origin!r} {self.command} {self.path[:80]}", flush=True)
            self.err("non autorizzato", 403)
        return bad

    def authed(self, qs=None):
        tok = self.headers.get("X-Token") or (qs or {}).get("token", [None])[0]
        return tok == TOKEN

    # --- routing
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        if self.blocked():
            return
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        path = u.path
        if path in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), encoding="utf-8") as f:
                html = f.read().replace("__TOKEN__", TOKEN).replace("__VERSION__", VERSION)
            body = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if path.startswith("/web/"):
            fp = os.path.normpath(os.path.join(WEB, path[5:]))
            if not fp.startswith(WEB + os.sep):
                return self.err("no", 403)
            return self.send_file(fp, nostore=True)
        if path == "/api/ping":
            LAST_PING[0] = time.time()
            if qs.get("ui"):
                UPD.mark_ok()   # la finestra ha caricato l'app: questa versione funziona
            return self.send_json({"ok": True, "app": "vodcut", "stamp": CODE_STAMP, "upd": UPD.status()})
        if path == "/api/restart-if-stale":
            # un avvio con codice piu' nuovo chiede al vecchio server di chiudersi
            newer = float(qs.get("stamp", ["0"])[0])
            if newer > CODE_STAMP + 1 and not running_jobs():
                self.send_json({"ok": True, "restarting": True})
                threading.Thread(target=lambda: (time.sleep(0.3), os._exit(0)), daemon=True).start()
                return
            return self.send_json({"ok": True, "restarting": False})
        if not self.authed(qs):
            return self.err("non autorizzato", 403)
        try:
            return self.route_get(path, qs)
        except FileNotFoundError:
            return self.err("Progetto non trovato", 404)
        except Exception as e:
            traceback.print_exc()
            return self.err(str(e), 500)

    def route_get(self, path, qs):
        if path == "/api/env":
            return self.send_json(env_info())
        if path == "/api/projects":
            return self.send_json(P.list_projects())
        if path == "/api/jobs":
            return self.send_json([j.to_json() for j in JOBS.values() if j.status == "running"])
        m = re.match(r"^/api/jobs/(\w+)$", path)
        if m:
            j = JOBS.get(m.group(1))
            return self.send_json(j.to_json()) if j else self.err("job non trovato", 404)
        if path == "/api/mthumb":
            p_ = qs.get("path", [""])[0]
            if not allowed_media(p_) or not os.path.isfile(p_):
                return self.err("file non consentito", 403)
            fn = media_thumb(p_, float(qs.get("t", ["1"])[0]))
            if not os.path.exists(fn):
                return self.err("anteprima non disponibile", 404)
            return self.send_file(fn, "image/jpeg", cache=True)
        if path == "/media":
            p = qs.get("path", [""])[0]
            t0 = time.time()
            if not allowed_media(p):
                return self.err("file non consentito", 403)
            t1 = time.time()
            self.send_file(p)
            print(f"[media] {time.strftime('%H:%M:%S')} range={self.headers.get('Range')} check={t1 - t0:.2f}s "
                  f"tot={time.time() - t0:.2f}s {os.path.basename(p)}", flush=True)
            return
        m = re.match(r"^/api/p/(\w+)(/.*)?$", path)
        if m:
            pid, sub = m.group(1), m.group(2) or ""
            if sub == "":
                proj = P.load(pid)
                if proj.get("origSource") and " (montato" in os.path.basename(proj.get("source") or ""):
                    # versione vecchia: il video aggiunto era stato unito alla live (lento e a volte si bloccava)
                    try:
                        with LOCK:
                            cur = P.load(pid)
                            rep = P.repair_merged(cur, float(probe(cur["origSource"])["duration"]))
                            if rep:
                                cur["repairNote"] = True
                                P.save(cur)
                                for j in JOBS.values():
                                    if j.pid == pid and j.status == "running" and j.kind.startswith("proxy"):
                                        j.cancelled = True
                                shutil.rmtree(strip_dir(pid), ignore_errors=True)
                                try:
                                    wf = wave_path(pid)
                                    db = np.load(db_path(pid))
                                    k0, k1 = int(round(rep[0] / A.HOP)), int(round((rep[0] + rep[1]) / A.HOP))
                                    db = np.concatenate([db[:k0], db[k1:]])
                                    np.save(db_path(pid), db)
                                    with open(wf, "w") as f:
                                        json.dump({"perSec": 5, "peaks": A.waveform(db, 5)}, f)
                                except Exception:
                                    traceback.print_exc()
                        proj = P.load(pid)
                    except Exception:
                        traceback.print_exc()
                for i in proj.get("inserts") or []:   # copia per l'anteprima sparita (altro PC, cache pulita)
                    if i.get("preview") and not os.path.exists(i["preview"]):
                        i.pop("preview")
                if "vcodec" not in proj:   # progetti creati prima: il formato si legge una volta sola
                    try:
                        proj["vcodec"] = probe(proj["source"]).get("vcodec")
                        with LOCK:
                            cur = P.load(pid)
                            cur["vcodec"] = proj["vcodec"]
                            P.save(cur)
                    except Exception:
                        pass
                return self.send_json(proj)
            if sub == "/face":
                d = FACE.load(FACE.path_for(pid))
                return self.send_json({"step": d.get("step", FACE.STEP), "cam": d.get("cam"), "pts": d.get("pts") or {}, "done": d.get("done") or []})
            if sub == "/missing":
                return self.send_json(PK.missing_files(P.load(pid)))
            if sub == "/wave":
                try:
                    with open(wave_path(pid)) as f:
                        return self.send_json(json.load(f))
                except FileNotFoundError:
                    return self.send_json({"perSec": 5, "peaks": []})
            if sub == "/clipwave":
                proj = P.load(pid)
                ins = next((i for i in proj.get("inserts") or [] if i.get("id") == qs.get("id", [""])[0]), None)
                if not ins or not os.path.exists(ins.get("file", "")):
                    return self.send_json({"perSec": 5, "peaks": []})
                db = clip_db(ins["file"], ins["dur"] + ins.get("offset", 0), ins.get("hasAudio"))
                return self.send_json({"perSec": 5, "peaks": A.waveform(db, 5)})
            if sub == "/thumb":
                t = float(qs.get("t", ["0"])[0])
                h = int(qs.get("h", ["90"])[0])
                return self.send_file(thumb(pid, t, min(720, h)), "image/jpeg", cache=True)
            if sub == "/strip":
                info = strip_info(pid, P.load(pid)["duration"])
                if not info["ready"]:
                    start_job("thumbs", pid, lambda j: job_thumbs(j, pid))
                return self.send_json(info)
            if sub == "/proxy":
                hq = int(qs.get("h", ["720"])[0])
                pp = proxy_path(pid, hq)
                if os.path.exists(pp):
                    return self.send_json({"ready": True, "path": pp})
                last = [j for j in JOBS.values() if j.kind == f"proxy{hq}" and j.pid == pid]
                if last and last[-1].status == "error" and not qs.get("retry"):
                    return self.send_json({"ready": False, "error": last[-1].error})
                j = start_job(f"proxy{hq}", pid, lambda j: job_proxy(j, pid, hq))
                return self.send_json({"ready": False, "job": j.to_json()})
            if sub == "/tile":
                fp = strip_tile(pid, int(qs.get("i", ["0"])[0]))
                if not fp or not os.path.exists(fp):
                    return self.err("anteprima non disponibile", 404)
                return self.send_file(fp, "image/jpeg", cache=True)
            if sub == "/frame":
                t = float(qs.get("t", ["0"])[0])
                return self.send_file(thumb(pid, t, 720), "image/jpeg", cache=True)
        return self.err("non trovato", 404)

    def do_PUT(self):
        if self.blocked():
            return
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        if not self.authed(qs):
            return self.err("non autorizzato", 403)
        if u.path == "/api/upload":
            # trascina e rilascia: il browser manda il file, lo salviamo in VODcut/importati
            name = os.path.basename(qs.get("name", ["video.mp4"])[0]) or "video.mp4"
            name = re.sub(r'[\\/:*?"<>|]+', "_", name)
            dest = os.path.join(IMPORTS_DIR, name)
            base, ext = os.path.splitext(dest)
            i = 2
            while os.path.exists(dest):
                dest = f"{base} ({i}){ext}"
                i += 1
            n = int(self.headers.get("Content-Length") or 0)
            with open(dest, "wb") as f:
                left = n
                while left > 0:
                    chunk = self.rfile.read(min(4 << 20, left))
                    if not chunk:
                        break
                    f.write(chunk)
                    left -= len(chunk)
            kind = qs.get("kind", ["video"])[0]
            if kind == "project":
                try:
                    proj = PK.import_package(dest, wave_path, db_path)
                except Exception as e:
                    return self.err(str(e))
                finally:
                    try:
                        os.remove(dest)
                    except OSError:
                        pass
                return self.send_json({"project": proj, "missing": PK.missing_files(proj)})
            if kind == "asset":
                try:
                    return self.send_json(media_info(dest))
                except Exception as e:
                    return self.err(str(e))
            if kind == "audio":
                return self.send_json({"path": dest, "duration": probe(dest)["duration"], "name": name})
            try:
                proj = P.create(dest)
            except Exception as e:
                return self.err(f"Non riesco ad aprire il file: {e}")
            start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
            return self.send_json(proj)
        m = re.match(r"^/api/p/(\w+)/textimg$", u.path)
        if m:
            # testo disegnato dall'app: un PNG per ogni versione (i vecchi servono ad Annulla)
            pid = m.group(1)
            clip = re.sub(r"\W", "", qs.get("clip", ["t"])[0])[:24] or "t"
            d = os.path.join(IMPORTS_DIR, "testi")
            os.makedirs(d, exist_ok=True)
            n = int(self.headers.get("Content-Length") or 0)
            data = self.rfile.read(n)
            if not data.startswith(b"\x89PNG"):
                return self.err("immagine non valida")
            name = f"{pid}_{clip}_{secrets.token_hex(3)}.png"
            dest = os.path.join(d, name)
            with open(dest, "wb") as f:
                f.write(data)
            return self.send_json({"path": dest})
        m = re.match(r"^/api/p/(\w+)$", u.path)
        if m:
            data = self.body_json()
            if data.get("id") != m.group(1):
                return self.err("id diverso")
            with LOCK:
                cur = P.load(m.group(1))
                # campi che decide solo il server
                for k in ("source", "duration", "width", "height", "fps", "hasAudio", "created"):
                    data[k] = cur[k]
                # video inseriti nella traccia principale (li mette l'editor): la durata segue
                ins = [i for i in (data.get("inserts") or []) if isinstance(i, dict) and i.get("file") and float(i.get("dur") or 0) > 0]
                live_d = cur.get("liveDuration") or P.live_duration(cur)
                if ins or cur.get("inserts"):
                    data["inserts"] = ins
                    data["liveDuration"] = live_d
                    data["duration"] = live_d + sum(float(i["dur"]) for i in ins)
                # la trascrizione in corso non va sovrascritta da un salvataggio vecchio
                if cur.get("transcript", {}).get("status") == "done" and data.get("transcript", {}).get("status") != "done":
                    data["transcript"] = cur["transcript"]
                # sottotitoli rifatti su un pezzo mentre l'editor salvava: vince la versione piu' nuova
                elif int((cur.get("transcript") or {}).get("rev") or 0) > int((data.get("transcript") or {}).get("rev") or 0):
                    data["transcript"] = cur["transcript"]
                P.save(data)
            return self.send_json({"ok": True, "updated": data["updated"]})
        return self.err("non trovato", 404)

    def do_DELETE(self):
        u = urllib.parse.urlparse(self.path)
        if not self.authed():
            return self.err("non autorizzato", 403)
        m = re.match(r"^/api/p/(\w+)$", u.path)
        if m:
            pid = m.group(1)
            # con il VOD se ne vanno anche le sue clip verticali
            try:
                for v in P.load(pid).get("verticals") or []:
                    P.delete(v.get("id", ""))
            except Exception:
                pass
            P.delete(pid)
            return self.send_json({"ok": True})
        return self.err("non trovato", 404)

    def do_POST(self):
        if self.blocked():
            return
        u = urllib.parse.urlparse(self.path)
        if not self.authed():
            return self.err("non autorizzato", 403)
        try:
            data = self.body_json()
            return self.route_post(u.path, data)
        except FileNotFoundError:
            return self.err("Progetto non trovato", 404)
        except Exception as e:
            traceback.print_exc()
            return self.err(str(e), 500)

    def route_post(self, path, data):
        if path == "/api/update/check":
            return self.send_json(UPD.check(force=True))
        if path == "/api/feedback":
            proj = None
            pid = str(data.get("pid") or "")
            if data.get("project") and re.match(r"^p\w+$", pid):
                try:
                    proj = P.load(pid)
                except Exception:
                    proj = None
            rep = FB.build(data, proj, {"gpu": nvenc_ok(), "lang": load_settings().get("lang")})
            FB.save(rep)
            left = FB.send_pending()
            return self.send_json({"ok": True, "id": rep["id"], "sent": left == 0, "queued": left})
        if path == "/api/openurl":
            url = str(data.get("url") or "")
            if not url.startswith("https://"):
                return self.err("indirizzo non valido")
            import webbrowser
            webbrowser.open(url)
            return self.send_json({"ok": True})
        if path == "/api/update/restart":
            if running_jobs() and not data.get("force"):
                return self.send_json({"ok": False, "busy": True})
            self.send_json({"ok": True})
            UPD.restart(PORT)
            return
        if path == "/api/pick":
            res, err = pick_file(data.get("kind", "video"))
            if err:
                return self.send_json({"error": err, "fallback": True})
            if data.get("kind") in ("media", "audio", "image-many"):
                allow_picked(res if isinstance(res, list) else [res])
            if data.get("kind") == "media":
                out, bad = [], []
                for p_ in res or []:
                    try:
                        out.append(media_info(p_))
                    except Exception:
                        bad.append(os.path.basename(p_))
                return self.send_json({"files": out, "skipped": bad})
            if data.get("kind") == "audio":
                out = []
                for p_ in res or []:
                    try:
                        out.append({"path": p_, "name": os.path.basename(p_), "duration": probe(p_)["duration"]})
                    except Exception:
                        pass
                return self.send_json({"files": out})
            return self.send_json({"path": res})
        # ---- progetto in un file .vodcut (per passarlo da un PC all'altro)
        if path == "/api/import-project":
            p_ = (data.get("path") or "").strip().strip('"')
            if not os.path.isfile(p_):
                return self.err("File non trovato")
            try:
                proj = PK.import_package(p_, wave_path, db_path)
            except Exception as e:
                return self.err(str(e))
            return self.send_json({"project": proj, "missing": PK.missing_files(proj)})
        m_ = re.match(r"^/api/p/(\w+)/(export-project|relink|relink-folder)$", path)
        if m_:
            pid, act = m_.group(1), m_.group(2)
            with LOCK:
                proj = P.load(pid)
                try:
                    if act == "export-project":
                        dest = (data.get("path") or "").strip()
                        if not dest:
                            return self.err("Scegli dove salvare")
                        if not dest.lower().endswith(".vodcut"):
                            dest += ".vodcut"
                        PK.export_package(proj, dest, [(wave_path(pid), "cache/wave.json"), (db_path(pid), "cache/db.npy")])
                        return self.send_json({"path": dest, "files": PK.media_refs(proj)})
                    if act == "relink":
                        PK.relink(proj, data.get("old") or "", (data.get("new") or "").strip().strip('"'))
                        found = 1
                    else:
                        folder = (data.get("folder") or "").strip()
                        if not os.path.isdir(folder):
                            return self.err("Cartella non trovata")
                        found = PK.relink_folder(proj, folder)
                except ValueError as e:
                    return self.err(str(e))
                P.save(proj)
            return self.send_json({"found": found, "missing": PK.missing_files(proj), "project": proj})
        if path == "/api/removebg":
            p_ = (data.get("path") or "").strip()
            if not os.path.isfile(p_) or os.path.splitext(p_)[1].lower() not in IMG_EXT:
                return self.err("Serve un'immagine")
            return self.send_json(start_job("removebg", None, lambda j: job_removebg(j, p_)).to_json())
        if path == "/api/probe-media":
            p_ = (data.get("path") or "").strip().strip('"')
            if not os.path.isfile(p_):
                return self.err("File non trovato")
            try:
                return self.send_json(media_info(p_))
            except Exception as e:
                return self.err(str(e))
        if path == "/api/probe-audio":
            p_ = data.get("path", "")
            if not os.path.isfile(p_):
                return self.err("File non trovato")
            return self.send_json({"path": p_, "name": os.path.basename(p_), "duration": probe(p_)["duration"]})
        if path == "/api/projects":
            src = (data.get("source") or "").strip().strip('"')
            if not os.path.isfile(src):
                return self.err("File non trovato: " + src)
            try:
                proj = P.create(src)
            except Exception as e:
                return self.err(f"Non riesco ad aprire il file: {e}")
            if data.get("kind") == "video":
                finish_plain(proj, "video")
            start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
            return self.send_json(proj)
        if path == "/api/projects/blank":
            try:
                proj = create_blank(data.get("format"), data.get("dur"), (data.get("name") or "").strip())
            except Exception as e:
                return self.err(f"Non riesco a creare il progetto: {e}")
            start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
            return self.send_json(proj)
        if path == "/api/story/parse":
            return self.send_json({"lines": ST.parse(data.get("text") or "")})
        if path == "/api/story/images":
            files = data.get("files") or ST.list_images((data.get("folder") or "").strip())
            if data.get("folder"):
                print(f"[story] cartella {data.get('folder')!r}: {len(files)} immagini", flush=True)
            files = [f for f in files if os.path.isfile(f)]
            allow_picked(files)
            out = []
            for f in files:
                try:
                    out.append(media_info(f))
                except Exception:
                    pass
            lines = data.get("lines") or []
            match = ST.match_images([o["path"] for o in out], lines) if lines else []
            return self.send_json({"files": out, "match": match})
        if path == "/api/story/voice":
            if data.get("voice"):
                allow_picked([data["voice"]])
            return self.send_json(start_job("storyvoice", None, lambda j: job_story_voice(j, data)).to_json())
        if path == "/api/story/create":
            if data.get("voice"):
                allow_picked([data["voice"]])
            return self.send_json(start_job("story", None, lambda j: job_story(j, data)).to_json())
        if path == "/api/import-url":
            url = (data.get("url") or "").strip()
            if not re.match(r"^https?://", url):
                url = "https://" + url
            j = start_job("download", None, lambda j: job_download(j, url))
            return self.send_json(j.to_json())
        if path == "/api/clientlog":
            print(f"[app] {time.strftime('%H:%M:%S')} {str(data.get('msg'))[:300]}", flush=True)
            return self.send_json({"ok": True})
        if path == "/api/open":
            ok = open_path(data.get("path", ""), bool(data.get("reveal")))
            return self.send_json({"ok": ok})
        if path == "/api/settings":
            s = load_settings()
            s.update(data)
            save_settings(s)
            return self.send_json(s)
        m = re.match(r"^/api/jobs/(\w+)/cancel$", path)
        if m:
            j = JOBS.get(m.group(1))
            if j:
                j.cancelled = True
            return self.send_json({"ok": True})
        m = re.match(r"^/api/p/(\w+)/(\w[\w-]*)$", path)
        if m:
            pid, act = m.group(1), m.group(2)
            if act == "prepare":
                return self.send_json(start_job("prepare", pid, lambda j: job_prepare(j, pid)).to_json())
            if act == "face":
                return self.send_json(start_job("face", pid, lambda j: job_face(j, pid)).to_json())
            if act == "redetect":
                def jd(j):
                    return W.detect_webcam(P.load(pid)["source"])
                return self.send_json(start_job("webcam", pid, jd).to_json())
            if act == "propose":
                with LOCK:
                    proj = P.load(pid)
                    if not os.path.exists(db_path(pid)):
                        return self.err("Analisi dell'audio non ancora pronta")
                    locked = bool((proj.get("analysis") or {}).get("ready"))  # il formato si sceglie una volta sola
                    propose_into(proj, int(data.get("cuts", 1)), int(data.get("zooms", 1)))
                    if not locked and data.get("format") in ("16:9", "9:16") and data.get("format") != (proj.get("format") or "16:9"):
                        set_format(proj, data["format"])
                    if data.get("vlayout") in VT.LAYOUTS:
                        proj["vert"] = dict(proj.get("vert") or {}, layout=data["vlayout"])
                    P.save(proj)
                return self.send_json(proj)
            if act == "transcribe":
                if not T.available():
                    return self.err("Trascrizione non installata: riesegui INSTALLA.bat")
                with LOCK:
                    proj = P.load(pid)
                    proj["transcript"] = {"status": "running", "segments": []}
                    P.save(proj)
                return self.send_json(start_job("transcribe", pid, lambda j: job_transcribe(j, pid)).to_json())
            if act == "transcriberange":
                if not T.available():
                    return self.err("Trascrizione non installata: riesegui INSTALLA.bat")
                a, b = float(data.get("a", 0)), float(data.get("b", 0))
                if b - a < 0.3:
                    return self.err("Pezzo troppo corto")
                return self.send_json(start_job("trrange", pid, lambda j: job_transcribe_range(j, pid, a, b)).to_json())
            if act == "prepinsert":
                clip = (data.get("path") or "").strip().strip('"')
                if not os.path.isfile(clip):
                    return self.err("File non trovato: " + clip)
                return self.send_json(start_job("prepinsert:" + clip, pid, lambda j: job_prepinsert(j, pid, clip)).to_json())
            if act == "inserttranscript":
                clip = (data.get("path") or "").strip()
                if not os.path.isfile(clip) or not T.available():
                    return self.err("File non trovato: " + clip)
                d_, o_ = float(data.get("dur") or 0), float(data.get("offset") or 0)
                return self.send_json(start_job("instr:" + clip, pid, lambda j: job_insert_transcript(j, pid, clip, d_, o_)).to_json())
            if act == "export":
                want = data if (data.get("verticals") or data.get("vod") is False) else None
                return self.send_json(start_job("export", pid, lambda j: job_export(j, pid, want)).to_json())
            if act == "rename":
                with LOCK:
                    cur = P.load(pid)
                    cur["name"] = (data.get("name") or cur["name"]).strip()[:120] or cur["name"]
                    P.save(cur)
                return self.send_json({"ok": True, "name": cur["name"]})
            if act == "vertical":
                try:
                    rg = data.get("ranges") or [[data.get("a", 0), data.get("b", 0)]]
                    return self.send_json(create_vertical(pid, rg, data.get("name")))
                except ValueError as e:
                    return self.err(str(e))
        return self.err("non trovato", 404)


def port_in_use_by_us(port):
    """True se VODcut gia' gira su questa porta con lo stesso codice.
    Se gira una versione vecchia (dopo un aggiornamento), la chiude e ritorna False."""
    import urllib.request
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=1) as r:
            j = json.loads(r.read())
    except Exception:
        return False
    if j.get("app") != "vodcut":
        return False
    if j.get("stamp", 0) + 1 < CODE_STAMP:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/restart-if-stale?stamp={CODE_STAMP}", timeout=2) as r:
                if json.loads(r.read()).get("restarting"):
                    time.sleep(1.0)
                    return False
        except Exception:
            time.sleep(1.0)
            return False
    return True


def free_port(start):
    # prima riprova la porta solita per qualche secondo (il vecchio server si sta chiudendo)
    for _ in range(15):
        with socket.socket() as s:
            if sys.platform != "win32":
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", start))
                return start
            except OSError:
                time.sleep(0.2)
    for p in range(start, start + 50):
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return start


def open_window(url):
    """Apre l'app in una finestra pulita di Edge o Chrome (modalita' app)."""
    cands = []
    if sys.platform == "win32":
        pf = [os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.environ.get("ProgramFiles", r"C:\Program Files"),
              os.environ.get("LocalAppData", "")]
        for base in pf:
            cands += [os.path.join(base, r"Microsoft\Edge\Application\msedge.exe"),
                      os.path.join(base, r"Google\Chrome\Application\chrome.exe")]
    else:
        cands += [shutil.which(x) or "" for x in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge")]
    prof = os.path.join(APP_DIR, "finestra")
    for c in cands:
        if c and os.path.exists(c):
            subprocess.Popen([c, f"--app={url}", f"--user-data-dir={prof}", "--window-size=1440,920",
                              "--no-first-run", "--no-default-browser-check", "--autoplay-policy=no-user-gesture-required"])
            return
    import webbrowser
    webbrowser.open(url)


# ------------------------------------------------------------------ finestra nativa (senza barra di Windows)
def have_webview():
    if sys.platform != "win32":
        return False
    try:
        import webview  # noqa: F401
        return True
    except Exception:
        return False


def install_webview_bg():
    """La finestra nativa usa pywebview: se manca si installa in silenzio (vale dal prossimo avvio)."""
    if sys.platform != "win32":
        return
    nw = 0x08000000

    def run():
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "pywebview"], capture_output=True, creationflags=nw, timeout=900)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


class WinApi:
    """Comandi della finestra chiamati dalla barra in alto (riduci, ingrandisci, chiudi, sposta, ridimensiona)."""

    def __init__(self):
        self._win = None
        self._max = None
        self._fs = False

    def _form(self):
        return self._win.native

    def _hwnd(self):
        return self._form().Handle.ToInt32()

    def _ui(self, fn):
        from System import Func, Type  # noqa: F401  (pythonnet, gia' caricato da pywebview)
        f = self._form()
        if f.InvokeRequired:
            f.Invoke(Func[Type](fn))
        else:
            fn()

    def setup(self):
        """Attiva le zone di trascinamento native (Aero Snap) se WebView2 le supporta."""
        res = {"nc": False}

        def go():
            f = self._form()
            try:
                # doppio clic sulla barra (gestito da Windows): ingrandisce senza coprire la barra delle app
                from System.Windows.Forms import Screen
                f.MaximizedBounds = Screen.FromControl(f).WorkingArea
            except Exception:
                pass
        try:
            self._ui(go)
        except Exception:
            pass
        self.set_icon()
        try:
            res["max"] = self.is_max()
        except Exception:
            res["max"] = False
        return res

    def set_icon(self):
        """Icona di VODcut sulla finestra e nella barra delle app (invece di quella di Python)."""
        ico = os.path.join(ROOT, "vodcut.ico")
        if not os.path.exists(ico):
            return

        def go():
            from System.Drawing import Icon
            self._form().Icon = Icon(ico)
        try:
            self._ui(go)
        except Exception:
            pass

    def minimize(self):
        self._win.minimize()

    def close(self):
        self._win.destroy()

    def toggle_maximize(self):
        """Ingrandisce / ripristina come fa Windows (cosi' trascinando la barra torna piccola da sola)."""
        from System.Windows.Forms import FormWindowState, Screen
        f = self._form()
        out = {}

        def go():
            try:
                f.MaximizedBounds = Screen.FromControl(f).WorkingArea   # la barra delle app resta visibile
            except Exception:
                pass
            if f.WindowState == FormWindowState.Maximized:
                f.WindowState = FormWindowState.Normal
                out["max"] = False
            else:
                f.WindowState = FormWindowState.Maximized
                out["max"] = True
        self._ui(go)
        self._max = None
        return out.get("max", False)

    def start_drag(self):
        """Spostamento della finestra fatto da Windows (come trascinare una barra del titolo vera):
        funziona anche l'aggancio ai bordi e, se e' ingrandita, torna piccola seguendo il mouse."""
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.SendMessageW.restype = wintypes.LPARAM
        h = self._form().Handle.ToInt64()

        def go():
            u.ReleaseCapture()
            u.SendMessageW(h, 0x00A1, 2, 0)   # WM_NCLBUTTONDOWN sulla "barra del titolo"
        self._ui(go)
        return True

    def is_max(self):
        from System.Windows.Forms import FormWindowState
        return self._form().WindowState == FormWindowState.Maximized

    def set_bounds(self, x, y, w, h, dpr):
        """Sposta/ridimensiona (coordinate CSS dello schermo, convertite in pixel veri)."""
        import ctypes
        try:
            if self.is_max():
                return
        except Exception:
            pass
        k = float(dpr or 1)
        flags = 0x0044 if w else 0x0045   # senza w/h: solo spostamento
        ctypes.windll.user32.SetWindowPos(self._hwnd(), 0, int(round(x * k)), int(round(y * k)),
                                          int(round((w or 0) * k)), int(round((h or 0) * k)), flags)

    def fullscreen(self, on):
        on = bool(on)
        if on != self._fs:
            self._fs = on
            self._win.toggle_fullscreen()
        return self._fs


def run_native_window(url):
    """Finestra dell'app senza la barra del titolo di Windows: la barra in alto la disegna VODcut."""
    import webview
    try:  # la barra delle app raggruppa VODcut come app a se' (non come "Python")
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("VODcut.App")
    except Exception:
        pass
    api = WinApi()
    win = webview.create_window("VODcut", url, width=1440, height=920, min_size=(1000, 640), frameless=True, easy_drag=False,
                                background_color="#161618", js_api=api, text_select=True, zoomable=False)
    api._win = win
    NATIVE["win"] = win
    try:
        win.events.shown += lambda: api.set_icon()
    except Exception:
        pass
    try:
        webview.settings["DRAG_REGION_SELECTOR"] = ".vodcut-no-drag-region"
    except Exception:
        pass
    ico = os.path.join(ROOT, "vodcut.ico")
    try:
        webview.start(gui="edgechromium", private_mode=False, storage_path=os.path.join(APP_DIR, "finestra-app"),
                      icon=ico if os.path.exists(ico) else None)
    except TypeError:
        webview.start(gui="edgechromium", private_mode=False, storage_path=os.path.join(APP_DIR, "finestra-app"))


def watchdog(httpd):
    """Chiude il server quando la finestra e' chiusa da un po' e non c'e' lavoro in corso."""
    while True:
        time.sleep(10)
        if time.time() - LAST_PING[0] > 240 and not running_jobs():
            httpd.shutdown()
            return


def main():
    global PORT
    if not shutil.which("ffmpeg"):
        _fatal("Manca ffmpeg. Fai doppio clic su INSTALLA.bat e poi riapri VODcut.")
    no_window = "--no-window" in sys.argv
    native = not no_window and have_webview()
    # doppio clic su un file .vodcut: l'app si apre e lo importa
    open_arg = next((a for a in sys.argv[1:] if a.lower().endswith(".vodcut") and os.path.isfile(a)), None)
    qs_open = ("?open=" + urllib.parse.quote(os.path.abspath(open_arg))) if open_arg else ""
    if not no_window and not native:
        install_webview_bg()
    if port_in_use_by_us(PORT):
        # gia' aperta: apri solo un'altra finestra
        if not no_window:
            url = f"http://127.0.0.1:{PORT}/{qs_open}"
            if native:
                try:
                    run_native_window(url)
                    return
                except Exception:
                    traceback.print_exc()
            open_window(url)
        return
    PORT = free_port(PORT)
    ensure_gpu_bg()
    if "--no-update" not in sys.argv:
        UPD.start_background(load_settings)
    FB.start_background()
    class Server(ThreadingHTTPServer):
        def handle_error(self, request, client_address):
            if isinstance(sys.exc_info()[1], (ConnectionResetError, BrokenPipeError, ConnectionAbortedError)):
                return
            super().handle_error(request, client_address)
    httpd = Server(("127.0.0.1", PORT), H)
    httpd.daemon_threads = True
    url = f"http://127.0.0.1:{PORT}/{qs_open}"
    print(f"VODcut {VERSION} su {url}")
    if native:
        # il server gira in un thread, la finestra nativa tiene il thread principale
        srv = threading.Thread(target=httpd.serve_forever, daemon=True)
        srv.start()
        try:
            run_native_window(url)
        except Exception:
            traceback.print_exc()
            open_window(url)
            threading.Thread(target=watchdog, args=(httpd,), daemon=True).start()
            srv.join()
            return
        # finestra chiusa: se c'e' un lavoro in corso (es. esportazione) lo lascia finire
        while running_jobs():
            time.sleep(1)
        httpd.shutdown()
        return
    if not no_window:
        threading.Timer(0.4, lambda: open_window(url)).start()
    if "--keep-alive" not in sys.argv:
        threading.Thread(target=watchdog, args=(httpd,), daemon=True).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
