"""Effetti su misura: l'AI scrive il codice di un'animazione (canvas 2D) che NoonFrame disegna sopra il video.
Il codice gira in una sandbox senza rete e senza accesso all'app (web/fxbox.html): qui si scrive solo il testo."""
import json
import re

from . import ai

STYLES = {
    "olografico": "hologram: cyan/teal light, additive blending ('lighter'), thin glowing wireframe lines, scanlines, subtle flicker, "
                  "floating particles, depth via transparency, like a sci-fi HUD",
    "premium": "premium After Effects motion design: clean geometric shapes, smooth easing (outExpo/outBack), staggered reveals, "
               "subtle glow, elegant thin typography, a single accent color on white/soft grey, lots of negative space",
    "neon": "neon: saturated magenta/cyan/violet strokes with strong glow (shadowBlur), light trails, energetic but tidy",
    "minimal": "minimal: few white shapes and lines, crisp, calm easing, one small accent, Apple-keynote feeling",
    "cinematico": "cinematic VFX: light rays, lens flare, sparks/embers, volumetric glow, dramatic scale, golden/orange accents",
}

SYSTEM = """You are a senior motion designer who writes JavaScript canvas animations for a video editor.
Write ONE function that draws one frame of an overlay effect on top of a video:

function effect(ctx, t, W, H, p) { ... }

- ctx: CanvasRenderingContext2D of a W x H transparent canvas (already cleared every frame). Draw ONLY the effect:
  the background must stay transparent (the video is underneath). Never fill the whole canvas with an opaque color.
- t: seconds since the effect started (0 .. p.dur). p.k = t / p.dur (0..1).
- p: { dur, k, fps, accent (css color), accent2, text (string, may be empty), seed (number),
       anchor: {x, y} center of the effect in 0..1 canvas coordinates (default 0.5, 0.5),
       size: suggested size as a fraction of min(W,H) (default 0.5),
       hand: null or {x, y, open (0..1), visible (bool)} in 0..1 coordinates, follows the speaker's hand every frame }
  If p.hand && p.hand.visible, attach the effect to the hand (e.g. floating above the open palm) instead of p.anchor.
- Helpers already in scope (use them, do not redefine): E (easing: E.outCubic, E.inOutCubic, E.outBack, E.outExpo, E.inOutSine,
  E.outElastic), lerp(a,b,x), clamp(x,a,b), rand(seed) -> deterministic function returning 0..1, noise(x, y) -> 0..1 smooth,
  rr(ctx, x, y, w, h, r) rounded-rect path, TAU.
- Deterministic: never use Math.random() or Date; use rand(p.seed).
- Performance: must draw a frame in a few milliseconds (at most ~400 particles, no per-pixel loops, no getImageData).
- No DOM, no images, no network, no async, no globals: only ctx drawing. Use system fonts:
  '600 40px -apple-system, "Segoe UI", Inter, Arial, sans-serif' (scale sizes with min(W,H)).
- Always: an entrance animation (first ~0.5 s), life in the middle (subtle continuous motion), and an exit (last ~0.35 s)
  so the effect never pops in or out. Scale everything relative to min(W, H). Keep text short and legible.
- Make it look PREMIUM, like After Effects, never like cheap clip-art: smooth easing, layered depth, glow with shadowBlur,
  thin crisp lines, restrained palette, motion that follows physics. Reset shadowBlur/globalAlpha/composite after use.

Answer ONLY with JSON: {"name": "short Italian name", "code": "function effect(ctx, t, W, H, p) { ... }", "dur": seconds}"""


def _parse(raw):
    s = raw.strip()
    m = re.search(r"\{.*\}", s, re.S)
    obj = None
    if m:
        try:
            obj = json.loads(m.group(0))
        except Exception:
            obj = None
    if not obj:
        # a volte il modello risponde con il codice in un blocco ```js
        cm = re.search(r"```(?:js|javascript)?\s*(function\s+effect.*?)```", s, re.S)
        if cm:
            obj = {"name": "Effetto", "code": cm.group(1)}
    if not obj or "function effect" not in str(obj.get("code") or ""):
        raise ai.AIError("L'AI non ha scritto un effetto valido: riprova")
    code = str(obj["code"])
    if len(code) > 40000:
        raise ai.AIError("Effetto troppo lungo: riprova con una descrizione più semplice")
    return {"name": str(obj.get("name") or "Effetto")[:48], "code": code, "dur": obj.get("dur")}


def generate(cfg, prompt, dur=3.0, style="premium", text="", aspect=16 / 9, prev=None, error=None, hand=False, cancel=None):
    """-> {name, code, dur, usd}. prev = codice di prima (modifica); error = errore del codice di prima (correzione)."""
    st = STYLES.get(style) or STYLES["premium"]
    user = [f"Effect to create: {prompt.strip()[:1500]}",
            f"Visual style: {st}",
            f"Duration: {float(dur):.1f} s. Canvas aspect ratio: {aspect:.3f} (W/H).",
            f"Text to show (optional, keep it exactly): {text.strip()[:120]}" if text and text.strip() else "No text unless the effect really needs one word.",
            "The speaker's hand position is available in p.hand: make the effect follow it." if hand else "Center the effect on p.anchor."]
    if prev:
        user.append("Current code of the effect (modify it as requested, keep what works):\n" + prev[:30000])
    if error:
        user.append("The current code throws this error, fix it: " + str(error)[:500])
    u = "\n".join(user)
    raw = ai.text(cfg, SYSTEM, u, max_tokens=8000, cancel=cancel)
    out = _parse(raw)
    try:
        d = float(out.get("dur") or dur)
    except (TypeError, ValueError):
        d = float(dur)
    out["dur"] = max(1.0, min(15.0, d if not prev else float(dur)))
    out["usd"] = ai.text_usd(cfg.get("model"), SYSTEM, u, raw)
    return out
