// VODcut - testi animati "cinetici": ogni lettera o parola si muove da sola (come nei pack professionali).
// Il testo si ridisegna a ogni fotogramma su una tela di grandezza fissa. In anteprima si disegna dal vivo;
// per l'esportazione l'app prepara i fotogrammi (PNG) e il video li usa uguali, pixel per pixel.
import { TEXT_DEFAULT } from './text.js';
import { fontReady } from './fonts.js';

// [id, nome, descrizione, per lettere o parole, durata dell'entrata (s)]
export const KINETICS = [
  ['highlight', 'Evidenziatore', 'Il riquadro colorato si allarga dietro le parole *evidenziate*', 'word'],
  ['stomp', 'Colpi', 'Ogni parola arriva con un colpo, una dopo l\'altra', 'word'],
  ['words', 'Parole pop', 'Le parole saltano fuori una alla volta', 'word'],
  ['rise', 'Sale dal basso', 'Le parole salgono da una fessura, pulite', 'word'],
  ['karaoke', 'Karaoke', 'Le parole si accendono una dopo l\'altra', 'word'],
  ['letters', 'Lettere che saltano', 'Ogni lettera rimbalza al suo posto', 'char'],
  ['type', 'Macchina da scrivere', 'Lettera per lettera, con il cursore', 'char'],
  ['blur', 'Messa a fuoco', 'Le lettere arrivano sfocate e si stringono', 'char'],
  ['zoom', 'Zoom lettere', 'Le lettere arrivano da grandi', 'char'],
  ['flip', 'Ribalta 3D', 'Le lettere girano su se stesse', 'char'],
  ['slide', 'Scorre', 'Le lettere scivolano dentro da sinistra', 'char'],
  ['scramble', 'Decodifica', 'Lettere a caso che diventano il testo', 'char'],
  ['wave', 'Onda', 'Le lettere ondeggiano sempre', 'char'],
  ['rainbow', 'Arcobaleno', 'I colori scorrono sulle lettere', 'char'],
  ['shine', 'Riflesso', 'Un lampo di luce passa sul testo', 'char'],
  ['neon', 'Neon che si accende', 'Sfarfalla e poi resta acceso', 'char'],
  ['glitch', 'Glitch', 'Righe spostate e colori separati', 'char'],
  ['vhs', 'VHS', 'Come una vecchia cassetta', 'char'],
];
export const kineticName = (id) => (KINETICS.find((k) => k[0] === id) || [0, ''])[1];

const clamp = (x) => Math.max(0, Math.min(1, x));
const eOut = (p) => 1 - Math.pow(1 - clamp(p), 3);
const eBack = (p) => { p = clamp(p); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
const eElastic = (p) => { p = clamp(p); if (p === 0 || p === 1) return p; return Math.pow(2, -10 * p) * Math.sin((p * 10 - 0.75) * (2 * Math.PI) / 3) + 1; };
const rnd = (n) => { const x = Math.sin(n * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); };
function hexA(hex, a) {
  let x = (hex || '#000').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
}

// impaginazione: lettere con posizione, parole, righe (uguale al testo fermo, piu' spazio intorno per i movimenti)
const layouts = new Map();
function layout(t, H) {
  // se il font arriva dopo, le misure cambiano: la chiave tiene conto di quando e' pronto
  let ready = true;
  try { ready = fontReady(t.font); } catch (e) { /* */ }
  const key = JSON.stringify([t, H, ready]);
  const hit = layouts.get(key);
  if (hit) return hit;
  const px = Math.max(8, Math.round(t.size * H));
  const font = `${t.italic ? 'italic ' : ''}${t.weight || (t.bold ? '700' : '400')} ${px}px "${t.font}", Arial, sans-serif`;
  const m = document.createElement('canvas').getContext('2d');
  m.font = font;
  const ls = (t.spacing || 0) * px;
  if (ls && 'letterSpacing' in m) m.letterSpacing = ls + 'px';
  const useHl = !!(t.hlColor || t.hlBox);
  const lh = px * t.lineH;
  const lines = String(t.content || ' ').split('\n').map((l) => (t.upper ? l.toUpperCase() : l));
  const chars = [], words = [], hlRuns = [];
  const widths = [];
  lines.forEach((raw, li) => {
    // *parole* evidenziate
    let s = '', hlMask = [];
    if (useHl) {
      let on = false;
      for (const ch of raw) { if (ch === '*') { on = !on; continue; } s += ch; hlMask.push(on); }
    } else { s = raw; hlMask = [...raw].map(() => false); }
    const arr = [...s];
    let pre = '';
    const xs = [];
    for (const ch of arr) { xs.push(m.measureText(pre).width); pre += ch; }
    const lw = Math.max(m.measureText(s).width, m.measureText(' ').width);
    widths.push(lw);
    let word = null;
    arr.forEach((ch, i) => {
      const w = m.measureText(ch).width;
      const u = { ch, x: xs[i], w, line: li, hl: hlMask[i], word: -1, idx: chars.length };
      if (ch.trim()) {
        if (!word) { word = { i: words.length, line: li, x0: xs[i], x1: xs[i] + w, hl: hlMask[i], chars: [] }; words.push(word); }
        word.x1 = xs[i] + w; word.chars.push(u); u.word = word.i;
      } else word = null;
      chars.push(u);
    });
    // riquadri delle parti evidenziate
    let run = null;
    arr.forEach((ch, i) => {
      if (hlMask[i]) { if (!run) { run = { line: li, x0: xs[i], x1: xs[i] }; hlRuns.push(run); } run.x1 = xs[i] + m.measureText(ch).width; }
      else run = null;
    });
  });
  const sw = t.stroke ? t.strokeW * px : 0;
  const sw2 = t.stroke2 ? (t.stroke2W || 0.1) * px : 0;
  const hard = t.hard ? (t.hardD || 0.08) * px : 0;
  const glow = t.glow ? (t.glowR || 0.35) * px : 0;
  const pad = Math.ceil((t.box || t.lineBox ? 0.35 * px : 0) + sw + sw2 + hard + glow + 0.2 * px + (t.shadow ? 0.08 * px : 0) + 2 + px * 0.55);
  const tw = Math.max(...widths, 1), th = lh * lines.length;
  const W = Math.ceil(tw + pad * 2), Hc = Math.ceil(th + pad * 2);
  const xOff = (li) => (t.align === 'left' ? pad : t.align === 'right' ? W - pad - widths[li] : (W - widths[li]) / 2);
  const yAt = (li) => pad + lh * li + lh / 2;
  for (const u of chars) { u.X = xOff(u.line) + u.x; u.Y = yAt(u.line); u.cx = u.X + u.w / 2; }
  for (const w of words) { w.X0 = xOff(w.line) + w.x0; w.X1 = xOff(w.line) + w.x1; w.cx = (w.X0 + w.X1) / 2; w.Y = yAt(w.line); }
  for (const r of hlRuns) { r.X0 = xOff(r.line) + r.x0; r.X1 = xOff(r.line) + r.x1; r.Y = yAt(r.line); }
  const L = { px, font, ls, lh, chars, words, hlRuns, widths, W, H: Hc, pad, xOff, yAt, sw, sw2, hard, glow, nLines: lines.length };
  if (layouts.size > 60) layouts.clear();
  layouts.set(key, L);
  return L;
}

// stato di ogni lettera al tempo tr: {dx, dy, sc, sx, sy, rot, op, blur, ch, color, px, py (perno)}
function states(kind, L, t, tr, dur) {
  const n = L.chars.length, nw = Math.max(1, L.words.length), px = L.px;
  const out = [];
  const inT = Math.min(dur * 0.7, kind === 'type' ? 0.055 * n : kind === 'karaoke' ? dur : 0.9);
  for (const u of L.chars) {
    const w = u.word >= 0 ? L.words[u.word] : null;
    const s = { dx: 0, dy: 0, sc: 1, sx: 1, sy: 1, rot: 0, op: 1, blur: 0, ch: u.ch, color: null, pvx: u.cx, pvy: u.Y };
    const ci = u.idx, wi = w ? w.i : 0;
    if (w && KIND_MODE[kind] === 'word') { s.pvx = w.cx; s.pvy = w.Y; }
    const cStag = Math.min(0.045, inT / Math.max(1, n)), wStag = Math.min(0.2, (inT * 0.9) / nw);
    if (kind === 'letters') { const p = (tr - ci * cStag) / 0.45; s.sc = Math.max(0, eBack(p)); s.dy = (1 - eOut(p)) * px * 0.5; s.op = clamp(p * 3); }
    else if (kind === 'words') { const p = (tr - wi * wStag) / 0.38; s.sc = Math.max(0, 0.4 + 0.6 * eBack(p)); s.op = clamp(p * 3); }
    else if (kind === 'stomp') {
      const p = (tr - wi * Math.max(0.16, wStag)) / 0.2; s.sc = 1 + 1.6 * (1 - eOut(p)); s.op = clamp(p * 2.2);
      const k = tr - wi * Math.max(0.16, wStag) - 0.2;   // piccolo tremolio all'arrivo
      if (k > 0 && k < 0.18) { const a = (1 - k / 0.18) * px * 0.05; s.dx = (rnd(wi * 7 + Math.floor(tr * 60)) - 0.5) * a * 2; s.dy = (rnd(wi * 13 + Math.floor(tr * 60)) - 0.5) * a * 2; }
    } else if (kind === 'rise') { const p = (tr - wi * Math.min(0.09, wStag)) / 0.55; s.dy = (1 - eOut(p)) * L.lh * 1.05; s.clip = true; }
    else if (kind === 'karaoke') {
      const k = tr / Math.max(0.3, dur * 0.85) * nw;
      s.op = 1; s.color = wi < k ? (t.hlColor || '#FFD60A') : null; s.dim = wi >= k;
      if (wi < k && wi > k - 1) s.sc = 1 + 0.07 * Math.sin(Math.PI * (k - wi));
    } else if (kind === 'type') { const k = tr / Math.max(0.2, inT) * n; s.op = ci < k ? 1 : 0; }
    else if (kind === 'blur') { const p = (tr - ci * cStag) / 0.5; const e = eOut(p); s.op = clamp(p * 1.6); s.blur = (1 - e) * px * 0.22; s.dx = (u.cx - L.W / 2) * 0.35 * (1 - e); }
    else if (kind === 'zoom') { const p = (tr - ci * cStag) / 0.45; const e = eOut(p); s.sc = 1 + 1.6 * (1 - e); s.op = clamp(p * 2); s.blur = (1 - e) * px * 0.12; }
    else if (kind === 'flip') { const p = (tr - ci * cStag) / 0.5; const e = eBack(p); s.sx = Math.cos((1 - clamp(e)) * Math.PI / 2) * (e > 1 ? e : 1); s.op = clamp(p * 2.5); s.dy = -(1 - eOut(p)) * px * 0.15; }
    else if (kind === 'slide') { const p = (tr - ci * cStag) / 0.42; const e = eOut(p); s.dx = -(1 - e) * px * 1.4; s.op = clamp(p * 2); s.blur = (1 - e) * px * 0.08; }
    else if (kind === 'scramble') {
      const done = 0.25 + ci * cStag * 1.4;
      if (tr < done && u.ch.trim()) { const pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#%&@$'; s.ch = pool[Math.floor(rnd(ci * 31 + Math.floor(tr * 20)) * pool.length)]; s.op = tr < ci * cStag * 0.6 ? 0 : 0.85; s.color = t.hlColor || null; }
    } else if (kind === 'wave') { const p = (tr - ci * cStag * 0.5) / 0.4; s.op = clamp(p * 2); s.dy = Math.sin(tr * 4.2 - ci * 0.55) * px * 0.1 * clamp(tr / 0.6); }
    else if (kind === 'rainbow') { const p = (tr - ci * cStag * 0.5) / 0.35; s.op = clamp(p * 2); s.color = `hsl(${(ci * 24 + tr * 140) % 360},95%,62%)`; s.dy = Math.sin(tr * 3 - ci * 0.4) * px * 0.04; }
    else if (kind === 'highlight') { const p = (tr - wi * Math.min(0.07, wStag)) / 0.35; s.op = clamp(p * 2.5); s.dy = (1 - eOut(p)) * px * 0.25; }
    else if (kind === 'shine' || kind === 'neon' || kind === 'glitch' || kind === 'vhs') { const p = tr / 0.35; s.op = kind === 'neon' ? 1 : clamp(p); }
    out.push(s);
  }
  return out;
}
const KIND_MODE = Object.fromEntries(KINETICS.map((k) => [k[0], k[3]]));

function drawUnits(g, L, t, st, pass) {
  const off = pass === 'hard' ? L.hard : 0;
  L.chars.forEach((u, i) => {
    const s = st[i];
    if (s.op <= 0.004 || !s.ch.trim()) return;
    const copies = s.blur > 0.6 ? 6 : 1;
    for (let k = 0; k < copies; k++) {
      g.save();
      if (s.clip) { g.beginPath(); g.rect(0, u.Y - L.lh * 0.62, L.W, L.lh * 1.24); g.clip(); }
      const ox = copies > 1 ? Math.cos(k / copies * Math.PI * 2) * s.blur : 0, oy = copies > 1 ? Math.sin(k / copies * Math.PI * 2) * s.blur * 0.6 : 0;
      g.globalAlpha = Math.min(1, s.op * (s.dim ? 0.55 : 1)) / (copies > 1 ? copies * 0.55 : 1);
      g.translate(s.pvx + s.dx + off + ox, s.pvy + s.dy + off + oy);
      if (s.rot) g.rotate(s.rot);
      g.scale(s.sc * s.sx, s.sc * s.sy);
      g.translate(-s.pvx, -s.pvy);
      const x = u.X;
      if (pass === 'hard') { g.fillStyle = t.hardColor || '#000'; if (L.sw2 || L.sw) { g.strokeStyle = t.hardColor || '#000'; g.lineWidth = (L.sw + L.sw2) * 2; g.strokeText(s.ch, x, u.Y); } g.fillText(s.ch, x, u.Y); }
      else if (pass === 'stroke2') { g.strokeStyle = t.stroke2Color || '#000'; g.lineWidth = (L.sw + L.sw2) * 2; g.strokeText(s.ch, x, u.Y); }
      else if (pass === 'stroke') { g.strokeStyle = u.hl && t.hlStroke ? t.hlStroke : t.strokeColor; g.lineWidth = L.sw * 2; g.strokeText(s.ch, x, u.Y); }
      else if (pass === 'shadow') { g.fillStyle = 'rgba(0,0,0,.5)'; g.fillText(s.ch, x + L.px * 0.05, u.Y + L.px * 0.05); }
      else {
        let fill = s.color || (u.hl && t.hlColor ? t.hlColor : t.color);
        if (!s.color && !(u.hl && t.hlColor) && t.grad && t.grad.length > 1) {
          const gr = g.createLinearGradient(0, u.Y - L.px * 0.5, 0, u.Y + L.px * 0.5);
          t.grad.forEach((col, j) => gr.addColorStop(j / (t.grad.length - 1), col));
          fill = gr;
        }
        if (pass === 'glow') { g.shadowColor = t.glowColor || t.color; g.shadowBlur = L.glow * (s.glowK ?? 1); }
        g.fillStyle = fill; g.fillText(s.ch, x, u.Y);
        if (pass === 'glow') g.fillText(s.ch, x, u.Y);
      }
      g.restore();
    }
  });
}

// tela gia' pronta (si riusa in anteprima: niente tele nuove a ogni fotogramma)
export function kineticSize(t0, H) {
  const t = { ...TEXT_DEFAULT, ...(t0 || {}) };
  const L = layout(t, H);
  return { w: L.W, h: L.H };
}

export function drawKinetic(t0, H, tr, dur, kind, canvas) {
  const t = { ...TEXT_DEFAULT, ...(t0 || {}) };
  const L = layout(t, H);
  const c = canvas || document.createElement('canvas');
  if (c.width !== L.W || c.height !== L.H) { c.width = L.W; c.height = L.H; }
  const g = c.getContext('2d');
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(0, 0, c.width, c.height);
  g.font = L.font; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.miterLimit = 2; g.textAlign = 'left';
  if (L.ls && 'letterSpacing' in g) g.letterSpacing = '0px';   // le lettere sono gia' messe al loro posto una per una
  const st = states(kind, L, t, Math.max(0, tr), Math.max(0.3, dur));
  const anyOp = st.reduce((a, s) => Math.max(a, s.op), 0);
  // neon: sfarfalla e poi resta acceso (con un respiro leggero)
  let glowK = 1, globalA = 1;
  if (kind === 'neon') {
    const f = [1, 0, 1, 0.2, 1, 1, 0, 1, 1, 1];
    globalA = tr < 0.9 ? f[Math.floor(tr / 0.09) % f.length] * (0.6 + 0.4 * rnd(Math.floor(tr * 30))) : 1;
    glowK = 0.85 + 0.15 * Math.sin(tr * 5);
    st.forEach((s) => { s.glowK = glowK; });
  }
  g.globalAlpha = 1;
  // sfondo del testo
  if (t.box) {
    const bx = L.pad - Math.max(0.35 * L.px, 0), r = Math.min(L.H / 2, t.boxR * L.px);
    g.save(); g.globalAlpha = anyOp * globalA;
    g.fillStyle = hexA(t.boxColor, (t.boxOp ?? 80) / 100);
    const x0 = Math.min(...L.widths.map((w, i) => L.xOff(i))) - 0.35 * L.px, x1 = Math.max(...L.widths.map((w, i) => L.xOff(i) + w)) + 0.35 * L.px;
    const y0 = L.yAt(0) - L.lh / 2 - 0.3 * L.px, y1 = L.yAt(L.nLines - 1) + L.lh / 2 + 0.3 * L.px;
    const k = kind === 'highlight' || kind === 'words' || kind === 'stomp' ? eBack(tr / 0.35) : 1;
    const cx = (x0 + x1) / 2;
    g.beginPath(); g.roundRect(cx - (cx - x0) * k, y0, (x1 - x0) * k, y1 - y0, r); g.fill(); g.restore();
    void bx;
  }
  if (t.lineBox) {
    g.save(); g.fillStyle = hexA(t.boxColor, (t.boxOp ?? 100) / 100);
    const bp = 0.28 * L.px, r = (t.boxR ?? 0.25) * L.px;
    L.widths.forEach((w, i) => {
      const lineOp = Math.max(0, ...L.chars.map((u, j) => (u.line === i ? st[j].op : 0)));
      const k = eBack((tr - i * 0.12) / 0.35);
      g.globalAlpha = lineOp * globalA;
      const x = L.xOff(i) - bp, cx = x + (w + bp * 2) / 2, ww = (w + bp * 2) * Math.max(0, k);
      g.beginPath(); g.roundRect(cx - ww / 2, L.yAt(i) - L.lh / 2 + L.px * 0.04, ww, L.lh - L.px * 0.08, r); g.fill();
    });
    g.restore();
  }
  // riquadro dietro le parole evidenziate: con "Evidenziatore" si allarga da sinistra
  if (t.hlBox) {
    const hp = 0.14 * L.px;
    L.hlRuns.forEach((r, i) => {
      const firstChar = L.chars.findIndex((u) => u.line === r.line && u.hl && Math.abs(u.X - r.X0) < 1);
      const op = firstChar >= 0 ? st[firstChar].op : 1;
      let k = 1;
      if (kind === 'highlight') k = eOut((tr - 0.25 - i * 0.18) / 0.35);
      else if (op < 1) k = op;
      if (k <= 0.001) return;
      g.save(); g.globalAlpha = globalA;
      g.translate(r.X0 - hp, r.Y);
      g.rotate(((t.hlTilt ?? -2) * Math.PI) / 180);
      g.fillStyle = t.hlBoxColor || '#FFD60A';
      g.beginPath(); g.roundRect(0, -L.px * 0.52, (r.X1 - r.X0 + hp * 2) * k, L.px * 1.04, L.px * 0.14); g.fill();
      g.restore();
    });
  }
  g.globalAlpha = globalA;
  if (L.hard) drawUnits(g, L, t, st, 'hard');
  if (L.sw2) drawUnits(g, L, t, st, 'stroke2');
  if (L.glow) drawUnits(g, L, t, st, 'glow');
  else if (t.shadow && !L.hard) drawUnits(g, L, t, st, 'shadow');
  if (L.sw) drawUnits(g, L, t, st, 'stroke');
  drawUnits(g, L, t, st, 'fill');
  // cursore della macchina da scrivere
  if (kind === 'type') {
    const k = tr / Math.max(0.2, Math.min(dur * 0.7, 0.055 * L.chars.length)) * L.chars.length;
    const last = L.chars[Math.min(L.chars.length - 1, Math.max(0, Math.ceil(k) - 1))];
    const typed = Math.min(dur * 0.7, 0.055 * L.chars.length);
    // il cursore lampeggia un po' dopo aver finito di scrivere, poi sparisce
    if (last && tr < typed + 1.4 && (tr < typed + 0.1 || Math.floor(tr * 2.2) % 2 === 0)) {
      g.fillStyle = t.hlColor || t.color; g.globalAlpha = 1;
      g.fillRect((k >= 1 ? last.X + last.w : last.X) + L.px * 0.04, last.Y - L.px * 0.42, Math.max(2, L.px * 0.07), L.px * 0.84);
    }
  }
  g.globalAlpha = 1;
  // effetti su tutto il testo
  if (kind === 'shine') {
    const per = 2.4, ph = ((tr - 0.3) % per) / per;
    if (tr > 0.3 && ph < 0.45) {
      const x = -L.W * 0.3 + (L.W * 1.6) * (ph / 0.45);
      g.save(); g.globalCompositeOperation = 'source-atop';
      const gr = g.createLinearGradient(x - L.px, 0, x + L.px, L.H * 0.3);
      gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,.85)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, L.W, L.H); g.restore();
    }
  } else if (kind === 'glitch' || kind === 'vhs') {
    const f = Math.floor(tr * 30);
    const burst = kind === 'glitch' ? (tr < 0.5 || (tr % 1.7) < 0.22) : true;
    const amp = kind === 'glitch' ? (burst ? 1 : 0.15) : 0.35;
    const snap = document.createElement('canvas'); snap.width = L.W; snap.height = L.H;
    snap.getContext('2d').drawImage(c, 0, 0);
    const tint = (col) => { const x = document.createElement('canvas'); x.width = L.W; x.height = L.H; const q = x.getContext('2d'); q.drawImage(snap, 0, 0); q.globalCompositeOperation = 'source-in'; q.fillStyle = col; q.fillRect(0, 0, L.W, L.H); return x; };
    const d = L.px * 0.06 * amp * (0.6 + rnd(f));
    g.clearRect(0, 0, L.W, L.H);
    g.globalAlpha = 0.75; g.drawImage(tint('#FF2A55'), -d, 0); g.drawImage(tint('#00E5FF'), d, 0);
    g.globalAlpha = 1;
    // righe spostate
    const bands = kind === 'glitch' && burst ? 7 : 3;
    let y = 0;
    for (let b = 0; b < bands && y < L.H; b++) {
      const hh = L.H / bands * (0.5 + rnd(f * 3 + b));
      const sh = (rnd(f * 7 + b * 11) - 0.5) * L.px * (kind === 'glitch' ? 0.5 * amp : 0.06);
      g.drawImage(snap, 0, y, L.W, hh, sh, y, L.W, hh);
      y += hh;
    }
    if (y < L.H) g.drawImage(snap, 0, y, L.W, L.H - y, 0, y, L.W, L.H - y);
    if (kind === 'vhs') {
      g.save(); g.globalCompositeOperation = 'source-atop';
      g.fillStyle = 'rgba(0,0,0,.28)';
      for (let yy = (f % 3); yy < L.H; yy += Math.max(3, Math.round(L.px * 0.06))) g.fillRect(0, yy, L.W, Math.max(1, L.px * 0.02));
      g.fillStyle = `rgba(255,255,255,${0.05 + 0.08 * rnd(f)})`; g.fillRect(0, 0, L.W, L.H);
      g.restore();
    }
  }
  return c;
}

// quanti fotogrammi servono (tutta la clip: alcuni effetti continuano sempre)
export const KINETIC_FPS = (fps) => Math.max(24, Math.min(60, Math.round(fps || 30)));
