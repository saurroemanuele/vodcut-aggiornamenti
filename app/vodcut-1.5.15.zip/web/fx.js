// VODcut - filtri sul video con maschera a pixel (anteprima).
// Stessi numeri dell'esportazione (engine/fx.py): look da fx_looks.json, parametri in fxParams().

export const FX_LIST = [
  { id: 'cine', name: 'Cinematico', kind: 'look' },
  { id: 'vivid', name: 'Gaming', kind: 'look' },
  { id: 'neon', name: 'Neon', kind: 'look' },
  { id: 'warm', name: 'Caldo', kind: 'look' },
  { id: 'cool', name: 'Freddo', kind: 'look' },
  { id: 'matte', name: 'Pellicola', kind: 'look' },
  { id: 'vintage', name: 'Vintage', kind: 'look' },
  { id: 'bw', name: 'Bianco e nero', kind: 'look' },
  { id: 'blur', name: 'Sfocatura', kind: 'fx' },
  { id: 'pixel', name: 'Pixel', kind: 'fx' },
  { id: 'glow', name: 'Bagliore', kind: 'fx' },
  { id: 'vignette', name: 'Vignettatura', kind: 'fx' },
  { id: 'grain', name: 'Grana', kind: 'fx' },
  { id: 'glitch', name: 'Glitch RGB', kind: 'fx' },
  { id: 'vhs', name: 'VHS', kind: 'fx' },
  { id: 'adjust', name: 'Regola colori', kind: 'adjust' },
];
// regolazioni colore: stessi calcoli di engine/fx.py adjust_look()
export const ADJ_KEYS = [['bri', 'Luminosità'], ['con', 'Contrasto'], ['sat', 'Saturazione'], ['temp', 'Temperatura'], ['tint', 'Tinta'], ['shad', 'Ombre'], ['high', 'Luci']];
export function adjustLook(adj) {
  const v = (k) => Math.max(-1, Math.min(1, ((adj || {})[k] || 0) / 100));
  const b = v('bri'), c = v('con'), T = v('temp'), Ti = v('tint'), sh = v('shad'), hi = v('high');
  const g = Math.pow(2, -0.9 * b), cc = c >= 0 ? 1 + 0.7 * c : 1 + 0.5 * c;
  const curve = [];
  for (let i = 0; i <= 16; i++) {
    let y = Math.pow(i / 16, g);
    y = 0.5 + (y - 0.5) * cc;
    const ws = y > 0 && y < 0.6 ? Math.sin(Math.PI * y / 0.6) : 0;
    const wh = y > 0.4 && y < 1 ? Math.sin(Math.PI * (y - 0.4) / 0.6) : 0;
    y += 0.18 * sh * ws + 0.18 * hi * wh;
    curve.push(+Math.max(0, Math.min(1, y)).toFixed(5));
  }
  return {
    sat: 1 + v('sat'),
    mix: [[1 + 0.12 * T + 0.04 * Ti, 0, 0], [0, 1 - 0.08 * Ti, 0], [0, 0, 1 - 0.12 * T + 0.04 * Ti]],
    r: curve, g: curve, b: curve,
  };
}
const adjKey = (adj) => ADJ_KEYS.map(([k]) => Math.round((adj || {})[k] || 0)).join('_').replace(/-/g, 'm');
export const fxName = (id) => (FX_LIST.find((f) => f.id === id) || { name: id }).name;

let LOOKS = null;
export async function loadLooks() {
  if (LOOKS) return LOOKS;
  try { LOOKS = await (await fetch('/web/fx_looks.json')).json(); } catch (e) { LOOKS = {}; }
  return LOOKS;
}

export function fxParams(typ, k, W) {
  return {
    blur: { sigma: Math.max(0.5, k * 0.02 * W) },
    pixel: { block: Math.max(2, Math.round(k * 0.045 * W)) },
    glow: { sigma: 0.012 * W, op: k * 0.8 },
    vignette: {},
    grain: { amt: Math.round(k * 28) },
    glitch: { d: Math.max(1, Math.round(k * 0.008 * W)) },
    vhs: { d: Math.max(1, Math.round(k * 0.004 * W)), sat: 1 - 0.25 * k, sigma: 0.0006 * W, amt: Math.round(k * 14) },
  }[typ] || {};
}

// ---------------------------------------------------------------- filtri SVG (usati dal canvas)
let svgDefs = null;
const made = new Set();
function defs() {
  if (!svgDefs) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '0'); svg.setAttribute('height', '0');
    svg.style.position = 'absolute'; svg.style.pointerEvents = 'none';
    svgDefs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    svg.append(svgDefs); document.body.append(svg);
  }
  return svgDefs;
}
function el(tag, attrs, kids = []) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  kids.forEach((k) => e.append(k));
  return e;
}
function filterEl(id, kids) {
  if (made.has(id)) return `url(#${id})`;
  defs().append(el('filter', { id, x: '0', y: '0', width: '100%', height: '100%', 'color-interpolation-filters': 'sRGB' }, kids));
  made.add(id);
  return `url(#${id})`;
}
const satM = (s) => [
  [0.213 + 0.787 * s, 0.715 - 0.715 * s, 0.072 - 0.072 * s],
  [0.213 - 0.213 * s, 0.715 + 0.285 * s, 0.072 - 0.072 * s],
  [0.213 - 0.213 * s, 0.715 - 0.715 * s, 0.072 + 0.928 * s]];
const mul = (A, B) => A.map((r) => [0, 1, 2].map((j) => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j]));
function lookFilter(id, k, adj) {
  const lk = id === 'adjust' ? adjustLook(adj) : (LOOKS || {})[id];
  if (!lk) return 'none';
  if (id === 'adjust') id = 'adj-' + adjKey(adj);
  const kk = Math.round(k * 100) / 100;
  let m = satM(lk.sat ?? 1);
  if (lk.mix) m = mul(lk.mix, m);
  const vals = [...m[0], 0, 0, ...m[1], 0, 0, ...m[2], 0, 0, 0, 0, 0, 1, 0].map((v) => +v.toFixed(6)).join(' ');
  return filterEl(`fxl-${id}-${Math.round(kk * 100)}`, [
    el('feColorMatrix', { in: 'SourceGraphic', type: 'matrix', values: vals, result: 'm' }),
    el('feComponentTransfer', { in: 'm', result: 'c' }, ['R', 'G', 'B'].map((c) => el('feFunc' + c, { type: 'table', tableValues: lk[c.toLowerCase()].join(' ') }))),
    el('feComposite', { in: 'c', in2: 'SourceGraphic', operator: 'arithmetic', k1: '0', k2: String(kk), k3: String(1 - kk), k4: '0' }),
  ]);
}
function blurFilter(px) {
  const p = Math.max(0.1, Math.round(px * 10) / 10);
  return filterEl(`fxb-${String(p).replace('.', '_')}`, [el('feGaussianBlur', { in: 'SourceGraphic', stdDeviation: String(p), edgeMode: 'duplicate' })]);
}
function chanFilter(ch) {
  const r = ch === 'r' ? 1 : 0, g = ch === 'g' ? 1 : 0, b = ch === 'b' ? 1 : 0;
  return filterEl('fxc-' + ch, [el('feColorMatrix', { type: 'matrix', values: `${r} 0 0 0 0  0 ${g} 0 0 0  0 0 ${b} 0 0  0 0 0 1 0` })]);
}

// ---------------------------------------------------------------- filtri "a mano" (Safari / Mac)
// Il motore di Safari (anche la finestra di VODcut su Mac) non applica i filtri SVG ai canvas ne' come backdrop-filter:
// li facciamo noi, pixel per pixel e con il canvas (stesso risultato, senza filtri del browser).
let _soft = null;
export function softFx() {
  if (_soft !== null) return _soft;
  if (/[?&]softfx=1/.test(location.search)) return (_soft = true);   // per provare il motore del Mac su Windows
  try {
    const src = document.createElement('canvas'); src.width = src.height = 4;
    const sg = src.getContext('2d'); sg.fillStyle = '#ff0000'; sg.fillRect(0, 0, 4, 4);
    const c = document.createElement('canvas'); c.width = c.height = 4;
    const g = c.getContext('2d');
    g.filter = chanFilter('b');   // tiene solo il blu: un quadrato rosso deve diventare nero
    g.drawImage(src, 0, 0);
    const d = g.getImageData(1, 1, 1, 1).data;
    _soft = !(d[0] < 60 && d[3] > 200);
  } catch (e) { _soft = true; }
  return _soft;
}
// sfocatura veloce: rimpicciolisce e riallarga (due passaggi), molto vicina a una gaussiana
export function softBlur(cv, sigma) {
  if (!(sigma > 0.4)) return;
  const w = cv.width, h = cv.height, f = Math.max(1, sigma / 1.6);
  const sw = Math.max(1, Math.round(w / f)), sh = Math.max(1, Math.round(h / f));
  const t = softBlur.t || (softBlur.t = document.createElement('canvas'));
  const u = softBlur.u || (softBlur.u = document.createElement('canvas'));
  t.width = sw; t.height = sh; u.width = Math.max(1, Math.round(sw / 2)); u.height = Math.max(1, Math.round(sh / 2));
  const tg = t.getContext('2d'), ug = u.getContext('2d');
  tg.imageSmoothingEnabled = ug.imageSmoothingEnabled = true; tg.imageSmoothingQuality = ug.imageSmoothingQuality = 'high';
  tg.drawImage(cv, 0, 0, sw, sh);
  if (f > 3) { ug.drawImage(t, 0, 0, u.width, u.height); tg.clearRect(0, 0, sw, sh); tg.drawImage(u, 0, 0, sw, sh); }
  const g = cv.getContext('2d');
  g.save(); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high'; g.globalCompositeOperation = 'copy'; g.drawImage(t, 0, 0, w, h); g.restore();
}
function lutOf(vals) {
  const n = vals.length - 1, out = new Uint8ClampedArray(256);
  for (let i = 0; i < 256; i++) {
    const c = i / 255, kk = Math.min(n - 1, Math.floor(c * n)), v = vals[kk] + (c * n - kk) * (vals[kk + 1] - vals[kk]);
    out[i] = Math.round(v * 255);
  }
  return out;
}
// look / regola colori: matrice colori + curve, mescolati con l'originale (k), come il filtro SVG
export function softLook(cv, id, k, adj) {
  const lk = id === 'adjust' ? adjustLook(adj) : (LOOKS || {})[id];
  if (!lk) return;
  let m = satM(lk.sat ?? 1);
  if (lk.mix) m = mul(lk.mix, m);
  const R = lutOf(lk.r), G = lutOf(lk.g), B = lutOf(lk.b);
  const g = cv.getContext('2d'), id2 = g.getImageData(0, 0, cv.width, cv.height), d = id2.data, k1 = 1 - k;
  const [a0, a1, a2] = m[0], [b0, b1, b2] = m[1], [c0, c1, c2] = m[2];
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], gg = d[i + 1], b = d[i + 2];
    const nr = a0 * r + a1 * gg + a2 * b, ng = b0 * r + b1 * gg + b2 * b, nb = c0 * r + c1 * gg + c2 * b;
    d[i] = k * R[nr < 0 ? 0 : nr > 255 ? 255 : nr | 0] + k1 * r;
    d[i + 1] = k * G[ng < 0 ? 0 : ng > 255 ? 255 : ng | 0] + k1 * gg;
    d[i + 2] = k * B[nb < 0 ? 0 : nb > 255 ? 255 : nb | 0] + k1 * b;
  }
  g.putImageData(id2, 0, 0);
}
function softSat(cv, sat) {
  const m = satM(sat), g = cv.getContext('2d'), id2 = g.getImageData(0, 0, cv.width, cv.height), d = id2.data;
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], gg = d[i + 1], b = d[i + 2];
    d[i] = m[0][0] * r + m[0][1] * gg + m[0][2] * b; d[i + 1] = m[1][0] * r + m[1][1] * gg + m[1][2] * b; d[i + 2] = m[2][0] * r + m[2][1] * gg + m[2][2] * b;
  }
  g.putImageData(id2, 0, 0);
}
// un solo canale (rosso, verde o blu) di un'immagine, senza filtri
function softChan(src, ch, out) {
  out.width = src.width; out.height = src.height;
  const g = out.getContext('2d');
  g.globalCompositeOperation = 'copy'; g.drawImage(src, 0, 0);
  g.globalCompositeOperation = 'multiply'; g.fillStyle = ch === 'r' ? '#ff0000' : ch === 'g' ? '#00ff00' : '#0000ff'; g.fillRect(0, 0, out.width, out.height);
  g.globalCompositeOperation = 'source-over';
  return out;
}

// ---------------------------------------------------------------- maschera
const smooth = (u) => u * u * (3 - 2 * u);
export function drawMask(mask, cw, ch, W, H) {
  const c = document.createElement('canvas'); c.width = cw; c.height = ch;
  const g = c.getContext('2d');
  const shape = document.createElement('canvas'); shape.width = cw; shape.height = ch;
  const s = shape.getContext('2d');
  s.fillStyle = '#fff'; s.strokeStyle = '#fff';
  const t = mask.type || 'all';
  if (t === 'rect') s.fillRect(mask.x * cw, mask.y * ch, mask.w * cw, mask.h * ch);
  else if (t === 'ellipse') { s.beginPath(); s.ellipse((mask.x + mask.w / 2) * cw, (mask.y + mask.h / 2) * ch, mask.w * cw / 2, mask.h * ch / 2, 0, 0, Math.PI * 2); s.fill(); }
  else if (t === 'brush') {
    s.lineCap = 'round'; s.lineJoin = 'round';
    for (const st of mask.strokes || []) {
      s.globalCompositeOperation = st.erase ? 'destination-out' : 'source-over';
      const lw = Math.max(1, (st.r || 0.03) * 2 * cw);
      const pts = st.pts || [];
      if (pts.length === 1) { s.beginPath(); s.arc(pts[0][0] * cw, pts[0][1] * ch, lw / 2, 0, Math.PI * 2); s.fill(); continue; }
      s.lineWidth = lw; s.beginPath();
      pts.forEach(([x, y], i) => (i ? s.lineTo(x * cw, y * ch) : s.moveTo(x * cw, y * ch)));
      s.stroke();
    }
    s.globalCompositeOperation = 'source-over';
  } else { g.fillStyle = '#fff'; g.fillRect(0, 0, cw, ch); return c; }
  const sig = (mask.feather ?? 0.15) * Math.min(W, H) * 0.25 * (cw / W);
  if (mask.invert) { g.fillStyle = '#fff'; g.fillRect(0, 0, cw, ch); g.globalCompositeOperation = 'destination-out'; }
  if (sig > 0.3 && softFx()) softBlur(shape, sig);
  else if (sig > 0.3) g.filter = `blur(${sig.toFixed(2)}px)`;
  g.drawImage(shape, 0, 0);
  g.filter = 'none'; g.globalCompositeOperation = 'source-over';
  return c;
}

// ---------------------------------------------------------------- renderer
export class FxRenderer {
  constructor(canvas, W, H) {
    this.c = canvas; this.W = W; this.H = H;
    this.tmp = document.createElement('canvas'); this.tmp2 = document.createElement('canvas');
    this.small = document.createElement('canvas');
    this.noise = document.createElement('canvas'); this.noise.width = this.noise.height = 192;
    this.masks = new Map(); this.vigs = new Map();
  }
  size(cw, ch) {
    for (const x of [this.c, this.tmp, this.tmp2]) if (x.width !== cw || x.height !== ch) { x.width = cw; x.height = ch; }
  }
  mask(f, cw, ch) {
    const key = JSON.stringify(f.mask) + '|' + cw + 'x' + ch;
    let m = this.masks.get(f.id);
    if (!m || m.key !== key) { m = { key, c: drawMask(f.mask, cw, ch, this.W, this.H) }; this.masks.set(f.id, m); }
    return m.c;
  }
  vignette(k, cw, ch) {
    const key = k.toFixed(3) + '|' + cw + 'x' + ch;
    let v = this.vigs.get(key);
    if (v) return v;
    v = document.createElement('canvas'); v.width = cw; v.height = ch;
    const g = v.getContext('2d'), id = g.createImageData(cw, ch), d = id.data;
    for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
      const dx = (x + 0.5 - cw / 2) / (cw / 2), dy = (y + 0.5 - ch / 2) / (ch / 2);
      const r = Math.sqrt(dx * dx + dy * dy) / Math.SQRT2, u = Math.min(1, Math.max(0, (r - 0.35) / 0.6));
      const f = Math.round((1 - k * 0.85 * smooth(u)) * 255), i = (y * cw + x) * 4;
      d[i] = d[i + 1] = d[i + 2] = f; d[i + 3] = 255;
    }
    g.putImageData(id, 0, 0);
    if (this.vigs.size > 8) this.vigs.clear();
    this.vigs.set(key, v);
    return v;
  }
  grain(dst, alpha) {
    const n = this.noise, g = n.getContext('2d'), id = g.createImageData(n.width, n.height), d = id.data;
    for (let i = 0; i < d.length; i += 4) { const v = Math.random() * 255; d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255; }
    g.putImageData(id, 0, 0);
    const x = dst.getContext('2d');
    x.save(); x.globalCompositeOperation = 'overlay'; x.globalAlpha = alpha;
    x.fillStyle = x.createPattern(n, 'repeat'); x.translate(-Math.random() * 192, -Math.random() * 192);
    x.fillRect(0, 0, dst.width + 192, dst.height + 192); x.restore();
  }
  // applica un effetto: legge src, scrive dst (stessa dimensione)
  effect(typ, k, src, dst, adj) {
    const cw = src.width, ch = src.height, s = cw / this.W, p = fxParams(typ, k, this.W);
    const g = dst.getContext('2d');
    if (softFx()) return this.softEffect(typ, k, src, dst, adj, s, p);
    g.save(); g.clearRect(0, 0, cw, ch);
    if (typ === 'adjust') { g.filter = lookFilter('adjust', k, adj); g.drawImage(src, 0, 0); g.restore(); return; }
    if (FX_LIST.find((f) => f.id === typ && f.kind === 'look')) { g.filter = lookFilter(typ, k); g.drawImage(src, 0, 0); }
    else if (typ === 'blur') { g.filter = blurFilter(p.sigma * s); g.drawImage(src, 0, 0); }
    else if (typ === 'pixel') {
      const sw = Math.max(1, Math.floor(this.W / p.block)), sh = Math.max(1, Math.floor(this.H / p.block));
      this.small.width = sw; this.small.height = sh;
      const sg = this.small.getContext('2d'); sg.imageSmoothingEnabled = true; sg.imageSmoothingQuality = 'high'; sg.drawImage(src, 0, 0, sw, sh);
      g.imageSmoothingEnabled = false; g.drawImage(this.small, 0, 0, cw, ch);
    } else if (typ === 'glow') {
      g.drawImage(src, 0, 0);
      g.globalCompositeOperation = 'screen'; g.globalAlpha = p.op; g.filter = blurFilter(p.sigma * s); g.drawImage(src, 0, 0);
    } else if (typ === 'vignette') {
      g.drawImage(src, 0, 0); g.globalCompositeOperation = 'multiply'; g.drawImage(this.vignette(k, cw, ch), 0, 0);
    } else if (typ === 'grain') { g.drawImage(src, 0, 0); g.restore(); this.grain(dst, p.amt / 28 * 0.4); return; }
    else if (typ === 'glitch' || typ === 'vhs') {
      g.fillStyle = '#000'; g.fillRect(0, 0, cw, ch);
      g.globalCompositeOperation = 'lighter';
      g.filter = chanFilter('r'); g.drawImage(src, -p.d * s, 0);
      g.filter = chanFilter('g'); g.drawImage(src, 0, 0);
      g.filter = chanFilter('b'); g.drawImage(src, p.d * s, 0);
      if (typ === 'vhs') {
        g.restore();
        const t2 = this.tmp2.getContext('2d');
        t2.save(); t2.clearRect(0, 0, cw, ch); t2.filter = `saturate(${p.sat.toFixed(3)}) ${blurFilter(Math.max(0.3, p.sigma) * s)}`; t2.drawImage(dst, 0, 0); t2.restore();
        g.save(); g.clearRect(0, 0, cw, ch); g.drawImage(this.tmp2, 0, 0); g.restore();
        this.grain(dst, p.amt / 28 * 0.4);
        return;
      }
    } else g.drawImage(src, 0, 0);
    g.restore();
  }
  // stessi effetti senza i filtri del browser (Safari / Mac)
  softEffect(typ, k, src, dst, adj, s, p) {
    const cw = src.width, ch = src.height, g = dst.getContext('2d');
    if (dst.width !== cw || dst.height !== ch) { dst.width = cw; dst.height = ch; }
    g.save(); g.globalCompositeOperation = 'copy'; g.globalAlpha = 1; g.drawImage(src, 0, 0); g.restore();
    const isLook = FX_LIST.some((f) => f.id === typ && f.kind === 'look');
    if (isLook || typ === 'adjust') softLook(dst, typ, k, adj);
    else if (typ === 'blur') softBlur(dst, p.sigma * s);
    else if (typ === 'pixel') {
      const sw = Math.max(1, Math.floor(this.W / p.block)), sh = Math.max(1, Math.floor(this.H / p.block));
      this.small.width = sw; this.small.height = sh;
      const sg = this.small.getContext('2d'); sg.imageSmoothingEnabled = true; sg.imageSmoothingQuality = 'high'; sg.drawImage(src, 0, 0, sw, sh);
      g.save(); g.imageSmoothingEnabled = false; g.globalCompositeOperation = 'copy'; g.drawImage(this.small, 0, 0, cw, ch); g.restore();
    } else if (typ === 'glow') {
      const t = this.tmp2; t.width = cw; t.height = ch;
      const tg = t.getContext('2d'); tg.globalCompositeOperation = 'copy'; tg.drawImage(src, 0, 0); tg.globalCompositeOperation = 'source-over';
      softBlur(t, p.sigma * s);
      g.save(); g.globalCompositeOperation = 'screen'; g.globalAlpha = p.op; g.drawImage(t, 0, 0); g.restore();
    } else if (typ === 'vignette') {
      g.save(); g.globalCompositeOperation = 'multiply'; g.drawImage(this.vignette(k, cw, ch), 0, 0); g.restore();
    } else if (typ === 'grain') this.grain(dst, p.amt / 28 * 0.4);
    else if (typ === 'glitch' || typ === 'vhs') {
      this.ch = this.ch || [document.createElement('canvas'), document.createElement('canvas'), document.createElement('canvas')];
      const [cr, cg, cb] = [softChan(src, 'r', this.ch[0]), softChan(src, 'g', this.ch[1]), softChan(src, 'b', this.ch[2])];
      g.save(); g.globalCompositeOperation = 'copy'; g.fillStyle = '#000'; g.fillRect(0, 0, cw, ch);
      g.globalCompositeOperation = 'lighter';
      g.drawImage(cr, -p.d * s, 0); g.drawImage(cg, 0, 0); g.drawImage(cb, p.d * s, 0); g.restore();
      if (typ === 'vhs') { softSat(dst, p.sat); softBlur(dst, Math.max(0.3, p.sigma) * s); this.grain(dst, p.amt / 28 * 0.4); }
    }
  }
  // disegna il fotogramma con i filtri attivi. Ritorna false se non c'e' niente da fare
  render(video, filters, maxW = 1600) {
    if (!filters.length || video.readyState < 2) return false;
    const r = (this.c.parentElement || this.c).getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const cw = Math.max(2, Math.min(maxW, Math.round(r.width * dpr))), ch = Math.max(2, Math.round(cw * this.H / this.W));
    this.size(cw, ch);
    const out = this.c.getContext('2d');
    out.save(); out.filter = 'none'; out.globalCompositeOperation = 'copy'; out.drawImage(video, 0, 0, cw, ch); out.restore();
    for (const f of filters) {
      const k = Math.max(0, Math.min(1, (f.k ?? 100) / 100));
      this.effect(f.type, k, this.c, this.tmp, f.adj);
      const masked = f.mask && f.mask.type && f.mask.type !== 'all';
      if (masked) {
        const t = this.tmp.getContext('2d');
        t.save(); t.globalCompositeOperation = 'destination-in'; t.drawImage(this.mask(f, cw, ch), 0, 0); t.restore();
        out.drawImage(this.tmp, 0, 0);
      } else { out.save(); out.globalCompositeOperation = 'copy'; out.drawImage(this.tmp, 0, 0); out.restore(); }
    }
    return true;
  }
  // miniatura: un filtro sul fotogramma attuale
  thumb(video, typ, canvas) {
    const cw = canvas.width, ch = canvas.height;
    const src = document.createElement('canvas'); src.width = cw; src.height = ch;
    try { src.getContext('2d').drawImage(video, 0, 0, cw, ch); } catch (e) { return; }
    const save = this.W;
    this.effect(typ, 1, src, canvas);
    this.W = save;
  }
}

// ---------------------------------------------------------------- filtri come livello (backdrop-filter)
// Il filtro agisce su tutto quello che sta SOTTO di lui (video, immagini, sottotitoli),
// come nell'esportazione. s = pixel dell'anteprima per pixel del VOD.
const r1 = (v) => Math.round(v * 10) / 10;
function vignetteURL(k, aspect) {
  const cw = 320, ch = Math.max(2, Math.round(320 / aspect));
  const c = document.createElement('canvas'); c.width = cw; c.height = ch;
  const g = c.getContext('2d'), id = g.createImageData(cw, ch), d = id.data;
  for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
    const dx = (x + 0.5 - cw / 2) / (cw / 2), dy = (y + 0.5 - ch / 2) / (ch / 2);
    const r = Math.sqrt(dx * dx + dy * dy) / Math.SQRT2, u = Math.min(1, Math.max(0, (r - 0.35) / 0.6));
    const f = Math.round((1 - k * 0.85 * smooth(u)) * 255), i = (y * cw + x) * 4;
    d[i] = d[i + 1] = d[i + 2] = f; d[i + 3] = 255;
  }
  g.putImageData(id, 0, 0);
  return c.toDataURL('image/png');
}
function chanOffset(name, d) {
  // separa i canali e li sposta: rosso a sinistra, blu a destra
  const m = (r, g, b) => `${r} 0 0 0 0  0 ${g} 0 0 0  0 0 ${b} 0 0  0 0 0 1 0`;
  return [
    el('feColorMatrix', { in: 'SourceGraphic', type: 'matrix', values: m(1, 0, 0), result: name + 'r0' }),
    el('feOffset', { in: name + 'r0', dx: String(-d), dy: '0', result: name + 'r' }),
    el('feColorMatrix', { in: 'SourceGraphic', type: 'matrix', values: m(0, 1, 0), result: name + 'g' }),
    el('feColorMatrix', { in: 'SourceGraphic', type: 'matrix', values: m(0, 0, 1), result: name + 'b0' }),
    el('feOffset', { in: name + 'b0', dx: String(d), dy: '0', result: name + 'b' }),
    el('feComposite', { in: name + 'r', in2: name + 'g', operator: 'arithmetic', k1: '0', k2: '1', k3: '1', k4: '0', result: name + 'rg' }),
    el('feComposite', { in: name + 'rg', in2: name + 'b', operator: 'arithmetic', k1: '0', k2: '1', k3: '1', k4: '0', result: name }),
  ];
}
function grainNodes(inName, alpha, seed, name) {
  return [
    el('feTurbulence', { type: 'fractalNoise', baseFrequency: '0.9', numOctaves: '1', seed: String(seed), result: name + 'n0' }),
    el('feColorMatrix', { in: name + 'n0', type: 'matrix', values: '0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0 0 0 0 1', result: name + 'n' }),
    el('feBlend', { in: name + 'n', in2: inName, mode: 'overlay', result: name + 'o' }),
    el('feComposite', { in: name + 'o', in2: inName, operator: 'arithmetic', k1: '0', k2: String(alpha), k3: String(1 - alpha), k4: '0', result: name }),
  ];
}
export function backdropFilter(typ, k, s, W, H, seed = 1, adj = null) {
  const p = fxParams(typ, k, W);
  if (typ === 'adjust') return lookFilter(typ, k, adj);
  if (FX_LIST.find((f) => f.id === typ && f.kind === 'look')) return lookFilter(typ, k);
  if (typ === 'blur') return blurFilter(p.sigma * s);
  if (typ === 'pixel') {
    const b = Math.max(2, Math.round(p.block * s)), hb = Math.floor(b / 2);
    return filterEl(`fxp-${b}`, [
      el('feFlood', { x: String(hb), y: String(hb), width: '1', height: '1', 'flood-color': '#000', result: 'f' }),
      el('feComposite', { in: 'f', width: String(b), height: String(b), result: 'c' }),
      el('feTile', { in: 'c', result: 't' }),
      el('feComposite', { in: 'SourceGraphic', in2: 't', operator: 'in', result: 'd' }),
      el('feMorphology', { in: 'd', operator: 'dilate', radius: String(hb) }),
    ]);
  }
  if (typ === 'glow') {
    const sg = r1(p.sigma * s), op = Math.round(p.op * 100) / 100;
    return filterEl(`fxg-${String(sg).replace('.', '_')}-${Math.round(op * 100)}`, [
      el('feGaussianBlur', { in: 'SourceGraphic', stdDeviation: String(sg), edgeMode: 'duplicate', result: 'b' }),
      el('feBlend', { in: 'b', in2: 'SourceGraphic', mode: 'screen', result: 's' }),
      el('feComposite', { in: 's', in2: 'SourceGraphic', operator: 'arithmetic', k1: '0', k2: String(op), k3: String(1 - op), k4: '0' }),
    ]);
  }
  if (typ === 'vignette') {
    const kk = Math.round(k * 100);
    return filterEl(`fxv-${kk}-${Math.round(W / H * 100)}`, [
      el('feImage', { href: vignetteURL(kk / 100, W / H), x: '0', y: '0', width: '100%', height: '100%', preserveAspectRatio: 'none', result: 'v' }),
      el('feBlend', { in: 'SourceGraphic', in2: 'v', mode: 'multiply' }),
    ]);
  }
  if (typ === 'grain') {
    const a = Math.round(p.amt / 28 * 0.4 * 100) / 100;
    return filterEl(`fxn-${Math.round(a * 100)}-${seed}`, grainNodes('SourceGraphic', a, seed, 'g'));
  }
  if (typ === 'glitch') { const d = r1(p.d * s); return filterEl(`fxx-${String(d).replace('.', '_')}`, chanOffset('x', d)); }
  if (typ === 'vhs') {
    const d = r1(p.d * s), sat = Math.round(p.sat * 100) / 100, sg = r1(Math.max(0.3, p.sigma) * s), a = Math.round(p.amt / 28 * 0.4 * 100) / 100;
    return filterEl(`fxh-${String(d).replace('.', '_')}-${Math.round(sat * 100)}-${String(sg).replace('.', '_')}-${seed}`, [
      ...chanOffset('x', d),
      el('feColorMatrix', { in: 'x', type: 'saturate', values: String(sat), result: 'sa' }),
      el('feGaussianBlur', { in: 'sa', stdDeviation: String(sg), edgeMode: 'duplicate', result: 'bl' }),
      ...grainNodes('bl', a, seed, 'gr'),
    ]);
  }
  return 'none';
}
