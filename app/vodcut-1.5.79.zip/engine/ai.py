"""Storie AI: collegamento ai servizi di intelligenza artificiale con le chiavi dell'utente.

Ogni utente mette le SUE chiavi (OpenAI, Anthropic, Google Gemini, ElevenLabs, fal.ai): i costi sono suoi e
NoonFrame non vede niente. Le chiavi restano solo su questo computer, cifrate con l'utente di Windows (DPAPI)
o in un file leggibile solo dall'utente su Mac, e non vengono mai mandate all'interfaccia, nei log o nelle
segnalazioni. Le chiamate partono dal computer direttamente verso il servizio scelto.

Tutti i servizi hanno la stessa forma per il resto dell'app:
- text(cfg, system, user) -> testo (JSON quando serve)
- image(cfg, prompt, refs) -> (bytes, estensione)
- speech(cfg, text) -> (bytes mp3, parole [[parola, inizio, fine]] oppure None)
"""
import base64
import json
import math
import mimetypes
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .util import APP_DIR
from .version import VERSION

KEYS_PATH = os.path.join(APP_DIR, "ai-chiavi.json")
_LOCK = threading.RLock()

PROVIDERS = {
    "openai": {"name": "OpenAI", "does": ["text", "image", "voice"], "site": "https://platform.openai.com/api-keys"},
    "anthropic": {"name": "Anthropic (Claude)", "does": ["text"], "site": "https://console.anthropic.com/settings/keys"},
    "gemini": {"name": "Google Gemini", "does": ["text", "image"], "site": "https://aistudio.google.com/apikey"},
    "elevenlabs": {"name": "ElevenLabs", "does": ["voice"], "site": "https://elevenlabs.io/app/settings/api-keys"},
    "fal": {"name": "fal.ai", "does": ["image", "video"], "site": "https://fal.ai/dashboard/keys"},
}

# modelli proposti (l'utente puo' scriverne un altro nella pagina)
MODELS = {
    "text": {"openai": ["gpt-5-mini", "gpt-5", "gpt-4.1-mini"],
             "anthropic": ["claude-sonnet-5", "claude-haiku-4-5-20251001", "claude-opus-5-5"],
             "gemini": ["gemini-2.5-flash", "gemini-2.5-pro"]},
    "image": {"fal": ["fal-ai/nano-banana-2/edit", "fal-ai/flux/dev", "fal-ai/flux/schnell"],
              "openai": ["gpt-image-1"],
              "gemini": ["gemini-3.1-flash-image", "gemini-2.5-flash-image"]},
    "voice": {"elevenlabs": ["eleven_multilingual_v2", "eleven_v3", "eleven_flash_v2_5"],
              "openai": ["gpt-4o-mini-tts"]},
    "video": {"fal": []},   # riempita sotto con tutto il catalogo (VIDEO_INFO)
}
OPENAI_VOICES = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer"]

# testo: prezzi pubblici per 1 milione di token (input, output) in dollari, settembre 2026.
# think = token di "ragionamento" in piu' che alcuni modelli fanno (si pagano come output).
# tier = qualita' per analisi e scrittura lunga (5 = la migliore).
TEXT_INFO = {
    "claude-opus-5-5": {"name": "Claude Opus 5.5", "in": 4.0, "out": 20.0, "think": 0, "tier": 5,
                        "why": "Il più bravo a capire cosa rende forte un video e a scrivere regole precise. Costa di più."},
    "claude-sonnet-5": {"name": "Claude Sonnet 5", "in": 2.0, "out": 10.0, "think": 0, "tier": 4,
                        "why": "Quasi come Opus nell'analisi, a metà prezzo. Ottimo in italiano."},
    "claude-haiku-4-5-20251001": {"name": "Claude Haiku 4.5", "in": 1.0, "out": 5.0, "think": 0, "tier": 3,
                                  "why": "Veloce e corretto, ma coglie meno sfumature."},
    "gpt-5": {"name": "GPT-5", "in": 1.25, "out": 10.0, "think": 4000, "tier": 4,
              "why": "Analisi molto buona. Ragiona prima di rispondere: paghi anche quei token."},
    "gpt-5-mini": {"name": "GPT-5 mini", "in": 0.25, "out": 2.0, "think": 3000, "tier": 3,
                   "why": "Costa pochissimo e va bene per pochi video. Meno fine sui dettagli."},
    "gpt-4.1-mini": {"name": "GPT-4.1 mini", "in": 0.40, "out": 1.60, "think": 0, "tier": 2,
                     "why": "Economico ma più vecchio: regole più generiche."},
    "gemini-2.5-pro": {"name": "Gemini 2.5 Pro", "in": 1.25, "out": 10.0, "think": 3000, "tier": 4,
                       "why": "Molto buono con tanti video insieme (legge testi lunghissimi)."},
    "gemini-2.5-flash": {"name": "Gemini 2.5 Flash", "in": 0.30, "out": 2.50, "think": 2000, "tier": 3,
                         "why": "Economico e veloce, buono per iniziare."},
}


# video AI (fal.ai, audio spento: la voce la mette NoonFrame). Prezzi e parametri presi dalle pagine /api di fal.ai
# (settembre 2026). Si paga la durata della clip, non quella della frase: si chiede sempre la clip piu' corta possibile.
#   usd_s = dollari al secondo alla risoluzione indicata; per_video = prezzo fisso per durata (sostituisce usd_s)
#   durs = durate accettate; fmt = come si manda la durata ("str" "5", "int" 5, "s" "5s"); fixed = niente durata (clip fissa)
#   img = campo dell'immagine di partenza; res = (campo, valore); audio = campo per spegnere l'audio
#   ar = rapporti accettati (si sceglie il piu' vicino all'immagine); neg = manda il negative prompt
_R = lambda a, b, st=1: list(range(a, b + 1, st))
_AR3 = ["16:9", "9:16"]
_AR7 = ["21:9", "16:9", "4:3", "1:1", "3:4", "9:16"]
VIDEO_INFO = {
    # --- Kling
    "fal-ai/kling-video/v3/standard/image-to-video": {"brand": "Kling", "name": "Kling 3.0 Standard", "usd_s": 0.084, "durs": _R(3, 15), "tier": 3, "res_lbl": "1080p",
        "img": "start_image_url", "audio": "generate_audio", "neg": True, "why": "Il miglior rapporto qualità/prezzo: clip anche da 3 secondi, volti stabili."},
    "fal-ai/kling-video/v3/pro/image-to-video": {"brand": "Kling", "name": "Kling 3.0 Pro", "usd_s": 0.112, "durs": _R(3, 15), "tier": 4, "res_lbl": "1080p",
        "img": "start_image_url", "audio": "generate_audio", "neg": True, "why": "Movimenti molto naturali e volti fedeli. Una delle migliori."},
    "fal-ai/kling-video/v3/turbo/standard/image-to-video": {"brand": "Kling", "name": "Kling 3.0 Turbo Standard", "usd_s": 0.112, "durs": _R(3, 15), "tier": 3, "res_lbl": "720p",
        "img": "image_url", "why": "Più veloce da generare, 720p."},
    "fal-ai/kling-video/v3/turbo/pro/image-to-video": {"brand": "Kling", "name": "Kling 3.0 Turbo Pro", "usd_s": 0.14, "durs": _R(3, 15), "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "why": "Qualità Pro, generazione più rapida."},
    "fal-ai/kling-video/o3/standard/image-to-video": {"brand": "Kling", "name": "Kling O3 Standard", "usd_s": 0.084, "durs": _R(3, 15), "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "audio": "generate_audio", "neg": True, "why": "Segue bene le indicazioni della scena. Stesso prezzo di Kling 3 Standard."},
    "fal-ai/kling-video/v2.6/pro/image-to-video": {"brand": "Kling", "name": "Kling 2.6 Pro", "usd_s": 0.07, "durs": [5, 10], "tier": 3, "res_lbl": "1080p",
        "img": "start_image_url", "audio": "generate_audio", "neg": True, "why": "Molto bella, ma clip da almeno 5 secondi (paghi anche quello che non usi)."},
    "fal-ai/kling-video/v2.5-turbo/pro/image-to-video": {"brand": "Kling", "name": "Kling 2.5 Turbo Pro", "usd_s": 0.07, "durs": [5, 10], "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "neg": True, "why": "Veloce e affidabile. Clip da 5 o 10 secondi."},
    # --- ByteDance Seedance
    "bytedance/seedance-2.5/image-to-video": {"brand": "Seedance", "name": "Seedance 2.5", "usd_s": 0.473, "durs": _R(4, 30), "tier": 5, "res_lbl": "720p",
        "img": "image_url", "res": ("resolution", "720p"), "audio": "generate_audio", "why": "L'ultima di ByteDance: la più realistica, fino a 30 secondi. Cara."},
    "bytedance/seedance-2.5/image-to-video@1080p": {"brand": "Seedance", "name": "Seedance 2.5 · 1080p", "usd_s": 1.164, "durs": _R(4, 30), "tier": 5, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "why": "Seedance 2.5 in Full HD. La più cara di tutte."},
    "bytedance/seedance-2.0/image-to-video": {"brand": "Seedance", "name": "Seedance 2.0", "usd_s": 0.3034, "durs": _R(4, 15), "tier": 5, "res_lbl": "720p",
        "img": "image_url", "res": ("resolution", "720p"), "audio": "generate_audio", "ar": ["auto"], "why": "Cinematografica, ottima con persone e azione."},
    "bytedance/seedance-2.0/image-to-video@1080p": {"brand": "Seedance", "name": "Seedance 2.0 · 1080p", "usd_s": 0.682, "durs": _R(4, 15), "tier": 5, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "ar": ["auto"], "why": "Seedance 2.0 in Full HD."},
    "bytedance/seedance-2.0/fast/image-to-video": {"brand": "Seedance", "name": "Seedance 2.0 Fast", "usd_s": 0.2419, "durs": _R(4, 15), "tier": 4, "res_lbl": "720p",
        "img": "image_url", "res": ("resolution", "720p"), "audio": "generate_audio", "ar": ["auto"], "why": "Seedance 2.0 più veloce ed economica (max 720p)."},
    "fal-ai/bytedance/seedance/v1.5/pro/image-to-video": {"brand": "Seedance", "name": "Seedance 1.5 Pro", "usd_s": 0.0583, "durs": _R(4, 12), "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "ar": ["auto"], "why": "Buona ed economica in 1080p."},
    "fal-ai/bytedance/seedance/v1/pro/image-to-video": {"brand": "Seedance", "name": "Seedance 1.0 Pro", "usd_s": 0.148, "durs": _R(2, 12), "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "ar": ["auto"], "why": "Clip anche da 2 secondi."},
    "fal-ai/bytedance/seedance/v1/pro/fast/image-to-video": {"brand": "Seedance", "name": "Seedance 1.0 Pro Fast", "usd_s": 0.0486, "durs": _R(2, 12), "tier": 2, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "ar": ["auto"], "why": "Tra le più economiche in 1080p, clip da 2 secondi."},
    # --- Google Veo
    "fal-ai/veo3.1/image-to-video": {"brand": "Veo", "name": "Veo 3.1", "usd_s": 0.20, "durs": [4, 6, 8], "fmt": "s", "tier": 5, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "ar": ["auto"], "why": "Google: realismo altissimo. Clip da 4, 6 o 8 secondi."},
    "fal-ai/veo3.1/fast/image-to-video": {"brand": "Veo", "name": "Veo 3.1 Fast", "usd_s": 0.10, "durs": [4, 6, 8], "fmt": "s", "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "ar": ["auto"], "why": "Veo 3.1 a metà prezzo, qualità ancora molto alta."},
    "fal-ai/veo3.1/lite/image-to-video": {"brand": "Veo", "name": "Veo 3.1 Lite", "usd_s": 0.05, "durs": [4, 6, 8], "fmt": "s", "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "ar": ["auto"], "why": "La Veo economica: ottimo rapporto qualità/prezzo."},
    # --- MiniMax / Hailuo
    "minimax/h3-max/image-to-video": {"brand": "MiniMax", "name": "MiniMax H3 Max", "usd_s": 0.16, "durs": _R(5, 15), "fmt": "int", "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080P"), "extra": {"prompt_expansion_mode": "balanced"}, "why": "Nuova di MiniMax, molto dinamica."},
    "minimax/h3-max-turbo/image-to-video": {"brand": "MiniMax", "name": "MiniMax H3 Max Turbo", "usd_s": 0.08, "durs": _R(5, 15), "fmt": "int", "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080P"), "extra": {"prompt_expansion_mode": "balanced"}, "why": "H3 Max più veloce e a metà prezzo."},
    "fal-ai/minimax/hailuo-2.3/pro/image-to-video": {"brand": "MiniMax", "name": "Hailuo 2.3 Pro", "per_video": {6: 0.49}, "durs": [6], "fixed": True, "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "why": "Clip fissa da 6 secondi, 1080p."},
    "fal-ai/minimax/hailuo-2.3/standard/image-to-video": {"brand": "MiniMax", "name": "Hailuo 2.3 Standard", "per_video": {6: 0.28, 10: 0.56}, "durs": [6, 10], "tier": 3, "res_lbl": "768p",
        "img": "image_url", "why": "Clip da 6 o 10 secondi, 768p."},
    "fal-ai/minimax/hailuo-2.3-fast/pro/image-to-video": {"brand": "MiniMax", "name": "Hailuo 2.3 Fast Pro", "per_video": {6: 0.33}, "durs": [6], "fixed": True, "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "why": "Veloce, clip fissa da 6 secondi."},
    "fal-ai/minimax/hailuo-2.3-fast/standard/image-to-video": {"brand": "MiniMax", "name": "Hailuo 2.3 Fast Standard", "per_video": {6: 0.19, 10: 0.32}, "durs": [6, 10], "tier": 2, "res_lbl": "768p",
        "img": "image_url", "why": "Economica, 768p."},
    "fal-ai/minimax/hailuo-02/pro/image-to-video": {"brand": "MiniMax", "name": "Hailuo 02 Pro", "per_video": {6: 0.48}, "durs": [6], "fixed": True, "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "why": "Clip fissa da 6 secondi, 1080p."},
    "fal-ai/minimax/hailuo-02/standard/image-to-video": {"brand": "MiniMax", "name": "Hailuo 02 Standard", "usd_s": 0.045, "durs": [6, 10], "tier": 2, "res_lbl": "768p",
        "img": "image_url", "res": ("resolution", "768P"), "why": "Economica, 768p."},
    # --- Wan (Alibaba)
    "alibaba/wan-3.0/image-to-video": {"brand": "Wan", "name": "Wan 3.0", "usd_s": 0.20, "durs": _R(2, 30), "fmt": "int", "tier": 4, "res_lbl": "1080p",
        "img": "start_image_url", "res": ("resolution", "1080p"), "audio": "audio", "why": "Clip da 2 a 30 secondi, 1080p."},
    "alibaba/wan-3.0-prime/image-to-video": {"brand": "Wan", "name": "Wan 3.0 Prime", "usd_s": 0.28, "durs": _R(2, 30), "fmt": "int", "tier": 5, "res_lbl": "1080p",
        "img": "start_image_url", "res": ("resolution", "1080p"), "audio": "audio", "why": "La Wan migliore."},
    "wan/v2.6/image-to-video": {"brand": "Wan", "name": "Wan 2.6", "usd_s": 0.15, "durs": [5, 10, 15], "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "neg": True, "why": "Clip da 5, 10 o 15 secondi."},
    "fal-ai/wan-25-preview/image-to-video": {"brand": "Wan", "name": "Wan 2.5", "usd_s": 0.15, "durs": [5, 10], "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "neg": True, "why": "Clip da 5 o 10 secondi."},
    # --- LTX (Lightricks)
    "fal-ai/ltx-2.3/image-to-video/fast": {"brand": "LTX", "name": "LTX-2.3 Fast", "usd_s": 0.06, "durs": _R(6, 20, 2), "tier": 2, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "extra": {"fps": "25"}, "why": "Tra le più economiche. Movimento semplice, a volte i volti cambiano un po'."},
    "fal-ai/ltx-2.3/image-to-video": {"brand": "LTX", "name": "LTX-2.3", "usd_s": 0.08, "durs": [6, 8, 10], "tier": 2, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "extra": {"fps": "25"}, "why": "Economica, 1080p."},
    "lightricks/ltx-2.5/image-to-video/fast": {"brand": "LTX", "name": "LTX-2.5 Fast", "usd_s": 0.13, "durs": _R(6, 20, 2), "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "extra": {"fps": "25"}, "why": "LTX nuova, più stabile."},
    "lightricks/ltx-2.5/image-to-video/pro": {"brand": "LTX", "name": "LTX-2.5 Pro", "usd_s": 0.17, "durs": [6, 8, 10], "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "extra": {"fps": "25"}, "why": "La LTX migliore."},
    # --- altri
    "fal-ai/pixverse/v6/image-to-video": {"brand": "PixVerse", "name": "PixVerse V6", "usd_s": 0.09, "durs": _R(1, 15), "fmt": "int", "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio_switch", "why": "Clip anche da 1 secondo: non paghi niente in più."},
    "fal-ai/pixverse/v5.5/image-to-video": {"brand": "PixVerse", "name": "PixVerse V5.5", "per_video": {5: 0.40, 8: 0.80}, "durs": [5, 8], "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio_switch", "why": "Clip da 5 o 8 secondi."},
    "fal-ai/vidu/q3/image-to-video": {"brand": "Vidu", "name": "Vidu Q3", "usd_s": 0.154, "durs": _R(1, 16), "fmt": "int", "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "audio", "why": "Clip da 1 secondo in su."},
    "fal-ai/vidu/q3/image-to-video/turbo": {"brand": "Vidu", "name": "Vidu Q3 Turbo", "usd_s": 0.077, "durs": _R(1, 16), "fmt": "int", "tier": 3, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "audio", "why": "Economica, clip da 1 secondo in su."},
    "xai/grok-imagine-video/v1.5/image-to-video": {"brand": "Grok", "name": "Grok Imagine 1.5", "usd_s": 0.25, "usd_fix": 0.01, "durs": _R(4, 15), "fmt": "int", "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "why": "xAI. L'audio lo crea sempre (lo togliamo noi)."},
    "blackforestlabs/flux-3/image-to-video": {"brand": "FLUX", "name": "FLUX 3 Video", "usd_s": 0.29, "durs": _R(5, 20), "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "audio": "generate_audio", "ar": ["auto"], "why": "Black Forest Labs, immagini molto pulite."},
    "luma/agent/ray/v3.2/image-to-video": {"brand": "Luma", "name": "Luma Ray 3.2", "per_video": {5: 1.20}, "durs": [5], "fmt": "s", "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "ar": ["16:9", "9:16", "4:3", "3:4", "1:1", "21:9"], "why": "Luma: luce e camera da film. Clip da 5 secondi."},
    "fal-ai/luma-dream-machine/ray-2/image-to-video": {"brand": "Luma", "name": "Luma Ray 2", "per_video": {5: 2.00, 9: 4.00}, "durs": [5, 9], "fmt": "s", "tier": 4, "res_lbl": "1080p",
        "img": "image_url", "res": ("resolution", "1080p"), "ar": ["16:9", "9:16", "4:3", "3:4", "21:9", "9:21"], "why": "Luma Ray 2 in 1080p: molto cara."},
    # --- versioni in risoluzione piu' bassa: costano molto meno (per TikTok/Reels il 720p basta quasi sempre)
    "fal-ai/veo3.1/lite/image-to-video@720p": {"brand": "Veo", "name": "Veo 3.1 Lite · 720p", "usd_s": 0.03, "durs": [4, 6, 8], "fmt": "s", "tier": 3, "res_lbl": "720p", "cheap": True,
        "img": "image_url", "res": ("resolution", "720p"), "audio": "generate_audio", "ar": ["auto"], "why": "Qualità Google a 3 centesimi al secondo. Clip da 4, 6 o 8 secondi."},
    "fal-ai/bytedance/seedance/v1/pro/fast/image-to-video@720p": {"brand": "Seedance", "name": "Seedance 1.0 Pro Fast · 720p", "usd_s": 0.0216, "durs": _R(2, 12), "tier": 2, "res_lbl": "720p", "cheap": True,
        "img": "image_url", "res": ("resolution", "720p"), "ar": ["auto"], "why": "La più economica: circa 2 centesimi al secondo, clip da 2 secondi."},
    "fal-ai/bytedance/seedance/v1.5/pro/image-to-video@720p": {"brand": "Seedance", "name": "Seedance 1.5 Pro · 720p", "usd_s": 0.0259, "durs": _R(4, 12), "tier": 3, "res_lbl": "720p", "cheap": True,
        "img": "image_url", "res": ("resolution", "720p"), "audio": "generate_audio", "ar": ["auto"], "why": "Molto economica e più recente della 1.0."},
    "fal-ai/pixverse/v6/image-to-video@720p": {"brand": "PixVerse", "name": "PixVerse V6 · 720p", "usd_s": 0.045, "durs": _R(1, 15), "fmt": "int", "tier": 3, "res_lbl": "720p", "cheap": True,
        "img": "image_url", "res": ("resolution", "720p"), "audio": "generate_audio_switch", "why": "Clip da 1 secondo: paghi solo la frase."},
    "fal-ai/pixverse/v6/image-to-video@540p": {"brand": "PixVerse", "name": "PixVerse V6 · 540p", "usd_s": 0.035, "durs": _R(1, 15), "fmt": "int", "tier": 2, "res_lbl": "540p", "cheap": True,
        "img": "image_url", "res": ("resolution", "540p"), "audio": "generate_audio_switch", "why": "Economica, clip da 1 secondo, qualità più bassa."},
    "fal-ai/vidu/q3/image-to-video/turbo@540p": {"brand": "Vidu", "name": "Vidu Q3 Turbo · 540p", "usd_s": 0.035, "durs": _R(1, 16), "fmt": "int", "tier": 2, "res_lbl": "540p", "cheap": True,
        "img": "image_url", "res": ("resolution", "540p"), "audio": "audio", "why": "Economica, clip da 1 secondo."},
    "minimax/h3-max-turbo/image-to-video@768p": {"brand": "MiniMax", "name": "MiniMax H3 Max Turbo · 768p", "usd_s": 0.04, "durs": _R(5, 15), "fmt": "int", "tier": 3, "res_lbl": "768p", "cheap": True,
        "img": "image_url", "res": ("resolution", "768P"), "extra": {"prompt_expansion_mode": "balanced"}, "why": "Movimento dinamico a 4 centesimi al secondo (clip da 5 s)."},
    "alibaba/wan-3.0/image-to-video@720p": {"brand": "Wan", "name": "Wan 3.0 · 720p", "usd_s": 0.10, "durs": _R(2, 30), "fmt": "int", "tier": 3, "res_lbl": "720p", "cheap": True,
        "img": "start_image_url", "res": ("resolution", "720p"), "audio": "audio", "why": "Wan 3.0 a metà prezzo."},
}
# modelli tolti da fal.ai -> il sostituto piu' vicino
VIDEO_ALIAS = {"fal-ai/ltx-2/image-to-video/fast": "fal-ai/ltx-2.3/image-to-video/fast",
               "fal-ai/ltxv-2/image-to-video": "fal-ai/ltx-2.3/image-to-video",
               "fal-ai/veo3/image-to-video": "fal-ai/veo3.1/image-to-video"}
VIDEO_DEFAULT = "fal-ai/bytedance/seedance/v1/pro/fast/image-to-video@720p"   # il piu' economico che si muove bene: ~2 centesimi al secondo
VIDEO_NEG = "text, subtitles, captions, letters, words, writing, watermark, logo, blur, distort, low quality, extra limbs, deformed face"
NO_TEXT = "Absolutely no text anywhere: no subtitles, no captions, no letters, no words, no writing, no watermark, no logos."


MODELS["video"]["fal"] = [VIDEO_DEFAULT] + [k for k in VIDEO_INFO if k != VIDEO_DEFAULT]


def video_model(m):
    """Modello valido (con i sostituti di quelli tolti da fal.ai)."""
    m = VIDEO_ALIAS.get(m or "", m or "")
    return m if m in VIDEO_INFO else VIDEO_DEFAULT


def video_clip(model, seconds):
    """(secondi fatturati, dollari) di una clip per una frase lunga 'seconds'."""
    info = VIDEO_INFO[video_model(model)]
    need = max(1.0, float(seconds or 0))
    ok = [d for d in info["durs"] if d >= need - 0.15]
    sec = ok[0] if ok else info["durs"][-1]
    usd = (info.get("per_video") or {}).get(sec)
    if usd is None:
        usd = sec * info.get("usd_s", 0.1) + info.get("usd_fix", 0)
    return sec, round(usd, 4)


def _nearest_ar(opts, ar):
    if not opts:
        return None
    if "auto" in opts:
        return "auto"
    def val(s):
        a, b = s.split(":")
        return float(a) / float(b)
    return min(opts, key=lambda s: abs(val(s) - ar))


# scene che PARLANO: immagine del personaggio + la sua battuta -> clip con la bocca a tempo (lip sync).
# La clip dura quanto l'audio (si paga al secondo di video); prezzi dalle pagine /api di fal.ai (settembre 2026).
TALK_INFO = {
    "fal-ai/kling-video/ai-avatar/v2/standard": {"brand": "Kling", "name": "Kling Avatar 2 Standard", "usd_s": 0.0562, "tier": 3, "res_lbl": "1080p",
        "prompt": True, "why": "Il più economico. Va bene anche con personaggi animati, cartoni e animali."},
    "fal-ai/kling-video/ai-avatar/v2/pro": {"brand": "Kling", "name": "Kling Avatar 2 Pro", "usd_s": 0.115, "tier": 4, "res_lbl": "1080p",
        "prompt": True, "why": "Labbra più precise e viso più dettagliato. Anche personaggi animati."},
    "fal-ai/bytedance/omnihuman/v1.5": {"brand": "ByteDance", "name": "OmniHuman 1.5", "usd_s": 0.16, "tier": 5, "res_lbl": "1080p", "max": 30,
        "prompt": True, "res": ("resolution", "1080p"), "why": "Il più realistico con persone vere: si muovono anche testa, corpo e mani."},
    "veed/fabric-1.0": {"brand": "VEED", "name": "VEED Fabric 1.0", "usd_s": 0.15, "tier": 4, "res_lbl": "720p", "max": 60,
        "res": ("resolution", "720p"), "why": "Funziona con persone, animali, cartoni, anime e plastilina."},
    "veed/fabric-1.0@480p": {"brand": "VEED", "name": "VEED Fabric 1.0 · 480p", "usd_s": 0.08, "tier": 3, "res_lbl": "480p", "max": 60,
        "res": ("resolution", "480p"), "why": "Fabric a metà prezzo, in qualità più bassa."},
    "fal-ai/creatify/aurora": {"brand": "Creatify", "name": "Creatify Aurora", "usd_s": 0.14, "ceil": True, "tier": 4, "res_lbl": "720p",
        "prompt": True, "res": ("resolution", "720p"), "why": "Molto espressivo. Si paga a secondi interi."},
    "fal-ai/heygen/avatar4/image-to-video": {"brand": "HeyGen", "name": "HeyGen Avatar IV", "usd_s": 0.10, "tier": 4, "res_lbl": "1080p",
        "res": ("resolution", "1080p"), "extra": {"aspect_ratio": "auto", "talking_style": "expressive"}, "why": "Parlato molto naturale. Serve un viso ben visibile."},
}
TALK_DEFAULT = "fal-ai/kling-video/ai-avatar/v2/standard"
for _i in TALK_INFO.values():   # per la finestra dei modelli: durata libera (quella della battuta)
    _i.setdefault("durs", list(range(1, 61)))
    _i["cont"] = True


def talk_model(m):
    return m if m in TALK_INFO else TALK_DEFAULT


def talk_cost(model, seconds):
    import math
    i = TALK_INFO[talk_model(model)]
    sec = max(0.5, float(seconds or 0))
    if i.get("ceil"):
        sec = math.ceil(sec)
    return round(sec * i["usd_s"], 4)


def talk_video(cfg, image_path, audio_path, prompt, cancel=None):
    """Clip in cui il personaggio dell'immagine dice la battuta (bocca a tempo con l'audio). -> bytes mp4."""
    if (cfg.get("provider") or "fal") != "fal":
        raise AIError("Per le scene che parlano serve fal.ai")
    k = _key("fal")
    m = talk_model(cfg.get("talkModel") or cfg.get("model") or "")
    i = TALK_INFO[m]
    body = {"image_url": "data:%s;base64,%s" % _data_uri(image_path)}
    with open(audio_path, "rb") as f:
        body["audio_url"] = "data:audio/mpeg;base64," + base64.b64encode(f.read()).decode()
    if i.get("prompt") and prompt:
        body["prompt"] = prompt[:900]
    if i.get("res"):
        body[i["res"][0]] = i["res"][1]
    body.update(i.get("extra") or {})
    res = fal_run(m.split("@")[0], body, k, cancel=cancel, timeout=1800)
    v = res.get("video") or ((res.get("videos") or [None])[0]) or {}
    u = v.get("url") if isinstance(v, dict) else None
    if not u or not u.startswith("https://"):
        raise AIError("fal.ai non ha restituito il video")
    return _req("GET", u, want="bytes", provider="fal", timeout=300)


def video_body(model, uri, sec, prompt, ar=16 / 9):
    """Richiesta per fal.ai secondo lo schema del modello (audio sempre spento)."""
    m = video_model(model)
    i = VIDEO_INFO[m]
    b = {"prompt": prompt, i.get("img", "image_url"): uri}
    if not i.get("fixed"):
        f = i.get("fmt", "str")
        b["duration"] = int(sec) if f == "int" else (f"{int(sec)}s" if f == "s" else str(int(sec)))
    if i.get("res"):
        b[i["res"][0]] = i["res"][1]
    if i.get("audio"):
        b[i["audio"]] = False
    a = _nearest_ar(i.get("ar"), ar)
    if a:
        b["aspect_ratio"] = a
    if i.get("neg"):
        b["negative_prompt"] = VIDEO_NEG
    b.update(i.get("extra") or {})
    return m.split("@")[0], b


def text_cost(model, tokens_in, tokens_out):
    i = TEXT_INFO.get(model)
    if not i:
        return None
    return (tokens_in * i["in"] + (tokens_out + i["think"]) * i["out"]) / 1e6


# immagini: prezzo per immagine del modello usato (fal: pagine dei modelli, settembre 2026; OpenAI/Google: listini ufficiali)
IMAGE_PRICE = {"fal-ai/nano-banana-2/edit": 0.08, "fal-ai/nano-banana-2": 0.08, "fal-ai/flux/dev": 0.025, "fal-ai/flux/schnell": 0.003,
               "gpt-image-1": 0.25, "gemini-3.1-flash-image": 0.067, "gemini-2.5-flash-image": 0.039}


def image_price(provider, model):
    m = model or (MODELS["image"].get(provider) or [""])[0]
    return IMAGE_PRICE.get(m, PRICE["image"].get(provider, 0.08))


def text_usd(model, system, user, out):
    """Costo di una risposta di testo, contando i token dalla lunghezza (circa 3,5 caratteri a token)."""
    c = text_cost(model, len(system or "") / 3.5 + len(user or "") / 3.5, len(out or "") / 3.5)
    return round(c, 4) if c is not None else PRICE["text"]


# costi indicativi in dollari (solo una stima: il costo vero lo decide il servizio con il tuo piano)
PRICE = {
    "text": 0.02,                                    # una storia intera (script + scene)
    "image": {"openai": 0.25, "fal": 0.08, "gemini": 0.067},
    "voice_char": {"elevenlabs": 0.00018, "openai": 0.000015},
    "video_sec": {"fal": 0.084},
}


class AIError(Exception):
    code = 0


# ------------------------------------------------------------------ chiavi (mai in chiaro fuori da qui)
def _keychain(op, provider, secret=None):
    """Mac: le chiavi nel Portachiavi di macOS (come le password), non in un file."""
    import subprocess
    svc = "Noonframe AI"   # nome del Portachiavi: non cambiarlo (le chiavi salvate si perderebbero)
    try:
        if op == "set":
            r = subprocess.run(["security", "add-generic-password", "-a", provider, "-s", svc, "-w", secret, "-U"],
                               capture_output=True, timeout=10)
            return r.returncode == 0
        if op == "get":
            r = subprocess.run(["security", "find-generic-password", "-a", provider, "-s", svc, "-w"], capture_output=True, timeout=10)
            return r.stdout.decode().strip() if r.returncode == 0 else ""
        if op == "del":
            subprocess.run(["security", "delete-generic-password", "-a", provider, "-s", svc], capture_output=True, timeout=10)
            return True
    except Exception:
        return "" if op == "get" else False


def _seal(s, provider=""):
    import sys
    if sys.platform == "darwin" and provider and _keychain("set", provider, s):
        return "keychain:" + provider
    from .account import _seal as seal
    return seal(s)


def _unseal(s):
    if s.startswith("keychain:"):
        return _keychain("get", s.split(":", 1)[1])
    from .account import _unseal as unseal
    return unseal(s)


def _load_keys():
    try:
        with open(KEYS_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_keys(d):
    os.makedirs(APP_DIR, exist_ok=True)
    tmp = KEYS_PATH + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(d, f)
    os.replace(tmp, KEYS_PATH)
    try:
        os.chmod(KEYS_PATH, 0o600)
    except OSError:
        pass


# ------------------------------------------------------------------ crediti NoonFrame
# Con i crediti le chiamate a fal.ai, ElevenLabs e Claude passano dal server di NoonFrame (funzione "ai"), che usa
# le sue chiavi e scala i crediti dell'account. Le chiavi dell'utente restano dove sono e tornano a valere spegnendoli.
CREDIT_PROVIDERS = ("fal", "elevenlabs", "anthropic")
CREDIT_HOSTS = {"queue.fal.run": "fal", "api.elevenlabs.io": "elevenlabs", "api.anthropic.com": "anthropic"}
CREDITS_PER_USD = 200
_CREDITS = {"balance": None, "at": 0}


def _account():
    from . import account
    return account


def credits_wanted():
    return bool((_load_keys().get("_credits") or {}).get("on"))


def credits_on():
    """Crediti accesi e account collegato (senza account non si possono usare)."""
    if not credits_wanted():
        return False
    try:
        return bool(_account().status().get("signedIn"))
    except Exception:
        return False


def set_credits(on):
    with _LOCK:
        d = _load_keys()
        d["_credits"] = {"on": bool(on)}
        _save_keys(d)
    return credits_status(refresh=bool(on))


def credits_status(refresh=False):
    acc = _account()
    try:
        logged = bool(acc.status().get("signedIn"))
    except Exception:
        logged = False
    out = {"on": credits_wanted(), "loggedIn": logged, "balance": _CREDITS["balance"], "perUsd": CREDITS_PER_USD}
    if not logged or not out["on"]:
        return out
    if refresh:
        try:
            r = _credits_call({"op": "balance"}, timeout=15)
            _CREDITS.update(balance=int(r.get("balance") or 0), at=time.time(), error=None)
            out["balance"] = _CREDITS["balance"]
        except AIError as e:
            out["error"] = str(e)
    elif (_CREDITS["balance"] is None or time.time() - _CREDITS["at"] > 60) and not _CREDITS.get("busy"):
        def bg():   # aggiorna il saldo senza far aspettare la pagina
            _CREDITS["busy"] = True
            try:
                r = _credits_call({"op": "balance"}, timeout=15)
                _CREDITS.update(balance=int(r.get("balance") or 0), error=None)
            except AIError as e:
                _CREDITS["error"] = str(e)
            finally:
                _CREDITS.update(at=time.time(), busy=False)
        threading.Thread(target=bg, daemon=True).start()
    if _CREDITS.get("error"):
        out["error"] = _CREDITS["error"]
    return out


def _credits_url():
    return _account().SUPABASE_URL.rstrip("/") + "/functions/v1/ai"


def _credits_headers():
    acc = _account()
    tok = acc._token()
    if not tok:
        raise AIError("Accedi a NoonFrame per usare i crediti")
    return {"Authorization": "Bearer " + tok, "apikey": acc.SUPABASE_KEY, "Content-Type": "application/json",
            "User-Agent": f"NoonFrame/{VERSION}"}


def _credits_call(env, timeout=60):
    req = urllib.request.Request(_credits_url(), data=json.dumps(env).encode("utf-8"), method="POST", headers=_credits_headers())
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read() or b"{}")
        except Exception:
            j = {}
        raise AIError(((j.get("error") or {}).get("message") if isinstance(j.get("error"), dict) else None) or f"Crediti NoonFrame: errore {e.code}")
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise AIError(f"Crediti NoonFrame: nessuna connessione ({getattr(e, 'reason', e)})")


def keys_status():
    d = _load_keys()
    out = {}
    cr = credits_on()
    for p, info in PROVIDERS.items():
        e = d.get(p) or {}
        via = cr and p in CREDIT_PROVIDERS
        out[p] = {"name": info["name"], "does": info["does"], "site": info["site"], "set": bool(e.get("key")) or via,
                  "own": bool(e.get("key")), "credits": via,
                  "hint": e.get("hint") or "", "ok": True if via else e.get("ok"), "checked": e.get("checked"),
                  "workspace": e.get("workspace") or "", "needWorkspace": bool(e.get("needWorkspace"))}
    return out


def set_key(provider, key):
    if provider not in PROVIDERS:
        raise AIError("Servizio sconosciuto")
    key = (key or "").strip()
    with _LOCK:
        d = _load_keys()
        if not key:
            if (d.get(provider) or {}).get("key", "").startswith("keychain:"):
                _keychain("del", provider)
            d.pop(provider, None)
            _save_keys(d)
            return keys_status()
        if len(key) < 12 or len(key) > 400 or not re.fullmatch(r"[A-Za-z0-9_\-.:/+=]+", key):
            raise AIError("Questa chiave non sembra valida: copiala di nuovo dal sito del servizio")
        d[provider] = {"key": _seal(key, provider), "hint": "…" + key[-4:], "ok": None, "checked": None,
                       **({"workspace": d[provider]["workspace"]} if (d.get(provider) or {}).get("workspace") else {})}
        _save_keys(d)
    return keys_status()


def set_workspace(provider, ws):
    """Anthropic: alcune chiavi (di organizzazione) vogliono anche l'ID del workspace (wrkspc_...). Non e' un segreto."""
    ws = (ws or "").strip()
    if ws and not re.fullmatch(r"wrkspc_[A-Za-z0-9]{6,64}", ws):
        raise AIError("L'ID del workspace inizia con wrkspc_ : copialo da console.anthropic.com → Settings → Workspaces")
    with _LOCK:
        d = _load_keys()
        e = d.setdefault(provider, {})
        if ws:
            e["workspace"] = ws
        else:
            e.pop("workspace", None)
        e["ok"] = None
        _save_keys(d)
    return keys_status()


def _anth(k):
    h = {"x-api-key": k, "anthropic-version": "2023-06-01"}
    ws = (_load_keys().get("anthropic") or {}).get("workspace")
    if ws:
        h["anthropic-workspace-id"] = ws
    return h


def _key(provider):
    if provider in CREDIT_PROVIDERS and credits_on():
        return "nf-credits"     # la chiave vera la mette il server di NoonFrame
    e = _load_keys().get(provider) or {}
    k = _unseal(e.get("key") or "")
    if not k:
        raise AIError(f"Manca la chiave di {PROVIDERS[provider]['name']}: aggiungila in Storie AI → Chiavi AI")
    return k


def _mark(provider, ok):
    with _LOCK:
        d = _load_keys()
        if provider in d:
            d[provider]["ok"] = ok
            d[provider]["checked"] = time.time()
            _save_keys(d)


def test_key(provider):
    """Una chiamata leggera per sapere se la chiave funziona (non costa niente)."""
    k = _key(provider)
    try:
        if provider == "openai":
            _req("GET", "https://api.openai.com/v1/models", {"Authorization": "Bearer " + k}, provider=provider)
        elif provider == "anthropic":
            _req("GET", "https://api.anthropic.com/v1/models", _anth(k), provider=provider)
        elif provider == "gemini":
            _req("GET", "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1", {"x-goog-api-key": k}, provider=provider)
        elif provider == "elevenlabs":
            _req("GET", "https://api.elevenlabs.io/v1/voices", {"xi-api-key": k}, provider=provider)
        elif provider == "fal":
            # nessuna chiamata gratuita: si chiede lo stato di una richiesta che non esiste (401 = chiave sbagliata)
            try:
                _req("GET", "https://queue.fal.run/fal-ai/flux/requests/00000000-0000-0000-0000-000000000000/status",
                     {"Authorization": "Key " + k}, provider=provider)
            except AIError as e:
                if getattr(e, "code", 0) not in (404, 422, 400):
                    raise
    except AIError as e:
        _mark(provider, False)
        if provider == "anthropic" and "workspace" in str(e).lower():
            with _LOCK:
                d = _load_keys()
                if provider in d:
                    d[provider]["needWorkspace"] = True
                    _save_keys(d)
            raise AIError("Questa chiave Anthropic è dell'organizzazione e vuole anche l'ID del workspace: incollalo nel campo qui sotto "
                          "(console.anthropic.com → Settings → Workspaces, inizia con wrkspc_). In alternativa crea una chiave dentro un workspace.")
        raise
    _mark(provider, True)
    return keys_status()


# ------------------------------------------------------------------ richieste
def _ssl():
    try:
        from .updater import _ssl_ctx
        return _ssl_ctx()
    except Exception:
        return None


EL_PERMS = {"voices_write": "Voices → Write (aggiungere e creare voci)", "voices_read": "Voices → Read",
            "text_to_voice": "Voice Generation / Text to Voice → Access (creare voci dalla descrizione)",
            "text_to_speech": "Text to Speech → Access", "user_read": "User → Read", "models_read": "Models → Read"}


def _friendly(provider, code, msg):
    name = PROVIDERS.get(provider, {}).get("name", provider)
    m = (msg or "").lower()
    print(f"[ai] {provider} errore {code}: {(msg or '')[:300]}", flush=True)   # il messaggio vero, per le segnalazioni
    if provider == "elevenlabs":
        perm = next((x for x in re.findall(r"permission[s]?\W+([a-z_]+)", m) if x in EL_PERMS), "")
        if "missing_permission" in m or perm:
            what = EL_PERMS.get(perm, "il permesso che manca")
            return (f"ElevenLabs: la tua chiave è limitata e non può fare questa operazione (manca «{perm or 'permesso'}»). "
                    f"Su elevenlabs.io apri Developers → API Keys, modifica la chiave e abilita {what}, "
                    "oppure crea una chiave senza restrizioni e incollala di nuovo in Chiavi AI.")
        if "free_users_not_allowed" in m or ("free" in m and "library" in m):
            return ("ElevenLabs: con il piano gratuito le voci della libreria non si possono usare dalle app (solo sul loro sito). "
                    "Usa \"Crea voce\" (funziona anche gratis) o passa al piano Starter.")
        if "unusual_activity" in m or "unusual activity" in m:
            return ("ElevenLabs ha bloccato il piano gratuito del tuo account per \"attività insolita\" (succede con VPN o più account gratuiti). "
                    "Si sblocca con un piano a pagamento, anche Starter.")
        if "quota_exceeded" in m or "quota" in m:
            return "ElevenLabs: hai finito i crediti del mese. Ricaricali o passa a un piano più grande"
        if "voice_limit" in m or "voice limit" in m or "maximum amount of custom voices" in m or "custom voices" in m:
            return "ElevenLabs: hai finito i posti voce del tuo piano. Elimina una voce che non usi su elevenlabs.io (Voices) o passa a un piano più grande"
    if code in (401, 403) and ("key" in m or "auth" in m or "permission" in m or "unauthor" in m or code == 401):
        return f"{name}: la chiave non è valida o non ha i permessi. Controllala in Chiavi AI"
    if provider == "fal" and ("locked" in m or "exhausted" in m or "balance" in m):
        return "fal.ai: hai finito il credito (account bloccato per saldo esaurito). Ricaricalo su fal.ai → Billing e riprova: le scene già fatte restano"
    if code == 402 or "credit" in m or "quota" in m or "balance" in m or "billing" in m or "insufficient" in m:
        return f"{name}: credito finito o fatturazione non attiva sul tuo account"
    if code == 429:
        return f"{name}: troppe richieste in poco tempo. Riprovo tra poco"
    if "safety" in m or "content_policy" in m or "moderation" in m or "blocked" in m:
        return f"{name}: il servizio ha rifiutato questo contenuto (regole di sicurezza). Cambia la descrizione della scena"
    if code and code >= 500:
        return f"{name} non risponde bene in questo momento (errore {code}). Riprova tra poco"
    return f"{name}: {msg or 'errore ' + str(code)}"[:300]


def _req(method, url, headers=None, body=None, raw=None, timeout=120, provider="", want="json"):
    """Le letture (stato della coda, risultati, voci...) si riprovano da sole se il servizio ha un intoppo (502/503/504 o
    rete): non costano niente. Gli invii (POST) no, per non pagare due volte la stessa generazione."""
    tries = 3 if method == "GET" else 1
    for k in range(tries):
        try:
            return _req_once(method, url, headers, body, raw, timeout, provider, want)
        except AIError as e:
            if k == tries - 1 or getattr(e, "code", 0) not in (0, 502, 503, 504):
                raise
            time.sleep((3, 8)[k])


def _req_once(method, url, headers=None, body=None, raw=None, timeout=120, provider="", want="json"):
    host = urllib.parse.urlparse(url).netloc
    if host in CREDIT_HOSTS and raw is None and credits_on():
        return _req_credits(method, url, body, timeout, provider or CREDIT_HOSTS[host], want)
    mock = os.environ.get("NOONFRAME_AI_MOCK")     # solo per le prove automatiche: tutte le chiamate a un server finto
    if mock:
        u = urllib.parse.urlparse(url)
        url = mock.rstrip("/") + "/" + u.netloc + u.path + ("?" + u.query if u.query else "")
    h = {"User-Agent": f"NoonFrame/{VERSION}"}
    h.update(headers or {})
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        h["Content-Type"] = "application/json"
    elif raw is not None:
        data = raw
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
            b = r.read()
            if want == "bytes":
                return b
            return json.loads(b) if b else {}
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read() or b"{}")
        except Exception:
            j = {}
        err = j.get("error") if isinstance(j, dict) else None
        msg = (err.get("message") if isinstance(err, dict) else err) or (j.get("detail") if isinstance(j, dict) else None) \
            or (j.get("message") if isinstance(j, dict) else None) or ""
        if isinstance(msg, (list, dict)):
            msg = json.dumps(msg)[:200]
        x = AIError(_friendly(provider, e.code, str(msg)))
        x.code = e.code
        raise x
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        x = AIError(f"{PROVIDERS.get(provider, {}).get('name', provider)}: nessuna connessione ({getattr(e, 'reason', e)})")
        x.code = 0
        raise x


def _req_credits(method, url, body, timeout, provider, want):
    """La stessa chiamata, ma passando dal server di NoonFrame (crediti)."""
    env = {"op": "call", "method": method, "url": url, "body": body}
    req = urllib.request.Request(_credits_url(), data=json.dumps(env).encode("utf-8"), method="POST", headers=_credits_headers())
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_ssl()) as r:
            left = r.headers.get("x-nf-credits")
            if left not in (None, ""):
                _CREDITS.update(balance=int(float(left)), at=time.time())
            b = r.read()
            if want == "bytes":
                return b
            return json.loads(b) if b else {}
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read() or b"{}")
        except Exception:
            j = {}
        if isinstance(j, dict) and j.get("code"):   # errore del servizio crediti: il messaggio e' gia' per l'utente
            x = AIError(str((j.get("error") or {}).get("message") or "Crediti NoonFrame: errore"))
            x.code = e.code
            raise x
        err = j.get("error") if isinstance(j, dict) else None
        msg = (err.get("message") if isinstance(err, dict) else err) or (j.get("detail") if isinstance(j, dict) else None) \
            or (j.get("message") if isinstance(j, dict) else None) or ""
        if isinstance(msg, (list, dict)):
            msg = json.dumps(msg)[:200]
        x = AIError(_friendly(provider, e.code, str(msg)))
        x.code = e.code
        raise x
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        x = AIError(f"Crediti NoonFrame: nessuna connessione ({getattr(e, 'reason', e)})")
        x.code = 0
        raise x


def _retry(fn, tries=3, cancel=None, only_busy=False):
    """Riprova solo per gli errori temporanei (troppe richieste, server giu', rete).
    only_busy: solo 'troppe richieste' (429), per le richieste che costano e non vanno ripetute."""
    for k in range(tries):
        try:
            return fn()
        except AIError as e:
            code = getattr(e, "code", 0)
            again = code == 429 if only_busy else (code == 429 or code == 0 or code >= 500)
            if k == tries - 1 or not again:
                raise
            if cancel and cancel():
                raise
            time.sleep(2 + k * 4)


def _repair_json(t):
    """Aggiusta gli errori tipici dei modelli: virgolette non protette dentro le frasi (dialoghi: disse "ciao"),
    a capo dentro le stringhe, virgole in piu' prima di } o ]."""
    out, i, n, ins = [], 0, len(t), False
    while i < n:
        c = t[i]
        if not ins:
            if c == '"':
                ins = True
            out.append(c)
        else:
            if c == "\\" and i + 1 < n:
                out.append(t[i:i + 2]); i += 2; continue
            if c == '"':
                j = i + 1
                while j < n and t[j] in " \t\r\n":
                    j += 1
                if j >= n or t[j] in ",}]:":
                    ins = False
                    out.append(c)
                else:
                    out.append('\\"')   # virgoletta dentro la frase
            elif c == "\n":
                out.append("\\n")
            elif c == "\r":
                pass
            elif c == "\t":
                out.append(" ")
            else:
                out.append(c)
        i += 1
    r = "".join(out)
    return re.sub(r",(\s*[}\]])", r"\1", r)


def parse_json(txt):
    """Il JSON della risposta (anche se il modello ci mette intorno ``` o due righe di testo, o sbaglia le virgolette)."""
    t = (txt or "").strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t)
    a, b = t.find("{"), t.rfind("}")
    cands = [t] + ([t[a:b + 1]] if a >= 0 and b > a else [])
    for c in cands + [_repair_json(x) for x in cands]:
        try:
            return json.loads(c)
        except Exception:
            continue
    raise AIError("La risposta dell'AI non è nel formato giusto: riprova")


# ------------------------------------------------------------------ testo
def text(cfg, system, user, max_tokens=6000, cancel=None, images=None):
    """images: immagini (jpg/png sul computer) da far guardare al modello insieme al testo."""
    p, model = cfg.get("provider") or "openai", cfg.get("model") or ""
    k = _key(p)
    imgs = [_data_uri(x) for x in (images or []) if x and os.path.isfile(x)][:12]
    if p == "openai":
        content = user if not imgs else [*({"type": "image_url", "image_url": {"url": f"data:{m};base64,{d}"}} for m, d in imgs),
                                         {"type": "text", "text": user}]
        body = {"model": model or MODELS["text"]["openai"][0], "response_format": {"type": "json_object"},
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": content}]}
        r = _retry(lambda: _req("POST", "https://api.openai.com/v1/chat/completions", {"Authorization": "Bearer " + k}, body,
                                timeout=240, provider=p), cancel=cancel)
        return r["choices"][0]["message"]["content"]
    if p == "anthropic":
        content = user if not imgs else [*({"type": "image", "source": {"type": "base64", "media_type": m, "data": d}} for m, d in imgs),
                                         {"type": "text", "text": user}]
        body = {"model": model or MODELS["text"]["anthropic"][0], "max_tokens": max_tokens, "system": system,
                "messages": [{"role": "user", "content": content}],
                # niente "ragionamento" nascosto: consumava tutti i token e la risposta arrivava vuota (e dopo minuti)
                "thinking": {"type": "disabled"}}
        try:
            r = _retry(lambda: _req("POST", "https://api.anthropic.com/v1/messages", _anth(k),
                                    body, timeout=240, provider=p), cancel=cancel)
        except AIError as e:
            if getattr(e, "code", 0) != 400 and "thinking" not in str(e).lower():
                raise
            body.pop("thinking", None)   # modello che non accetta l'opzione: si chiede senza
            r = _retry(lambda: _req("POST", "https://api.anthropic.com/v1/messages", _anth(k),
                                    body, timeout=240, provider=p), cancel=cancel)
        out = "".join(b.get("text", "") for b in r.get("content", []) if b.get("type") == "text")
        if not out.strip():
            print("[ai] anthropic: risposta senza testo, stop_reason:", r.get("stop_reason"), "blocchi:",
                  [b.get("type") for b in r.get("content", [])], flush=True)
        return out
    if p == "gemini":
        m = model or MODELS["text"]["gemini"][0]
        parts = [{"inlineData": {"mimeType": m, "data": d}} for m, d in imgs] + [{"text": user}]
        body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": [{"role": "user", "parts": parts}],
                "generationConfig": {"responseMimeType": "application/json"}}
        r = _retry(lambda: _req("POST", f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(m)}:generateContent",
                                {"x-goog-api-key": k}, body, timeout=240, provider=p), cancel=cancel)
        return "".join(pt.get("text", "") for pt in ((r.get("candidates") or [{}])[0].get("content") or {}).get("parts", []))
    raise AIError("Servizio non adatto a scrivere testi")


# ------------------------------------------------------------------ immagini
def _data_uri(path):
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as f:
        return mime, base64.b64encode(f.read()).decode()


def _ext_of(b):
    if b[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return ".webp"
    return ".png"


def image(cfg, prompt, refs=None, ratio="9:16", cancel=None):
    """-> (bytes dell'immagine, estensione). refs: immagini dei personaggi per tenerli uguali tra le scene."""
    p, model = cfg.get("provider") or "fal", cfg.get("model") or ""
    refs = [r for r in (refs or []) if r and os.path.isfile(r)][:4]
    k = _key(p)
    if p == "openai":
        m = model or "gpt-image-1"
        size = "1024x1536" if ratio == "9:16" else "1536x1024" if ratio == "16:9" else "1024x1024"
        if refs:
            bnd = "----nf" + uuid.uuid4().hex
            parts = []
            for key, val in (("model", m), ("prompt", prompt), ("size", size), ("n", "1")):
                parts.append(f'--{bnd}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{val}\r\n'.encode())
            for r in refs:
                mime = mimetypes.guess_type(r)[0] or "image/png"
                with open(r, "rb") as f:
                    parts.append(f'--{bnd}\r\nContent-Disposition: form-data; name="image[]"; filename="{os.path.basename(r)}"\r\n'
                                 f'Content-Type: {mime}\r\n\r\n'.encode() + f.read() + b"\r\n")
            parts.append(f"--{bnd}--\r\n".encode())
            res = _retry(lambda: _req("POST", "https://api.openai.com/v1/images/edits",
                                      {"Authorization": "Bearer " + k, "Content-Type": "multipart/form-data; boundary=" + bnd},
                                      raw=b"".join(parts), timeout=300, provider=p), cancel=cancel)
        else:
            res = _retry(lambda: _req("POST", "https://api.openai.com/v1/images/generations", {"Authorization": "Bearer " + k},
                                      {"model": m, "prompt": prompt, "size": size, "n": 1}, timeout=300, provider=p), cancel=cancel)
        d = (res.get("data") or [{}])[0]
        if d.get("b64_json"):
            b = base64.b64decode(d["b64_json"])
        elif d.get("url"):
            b = _req("GET", d["url"], want="bytes", provider=p)
        else:
            raise AIError("OpenAI non ha restituito l'immagine")
        return b, _ext_of(b)
    if p == "gemini":
        m = model or MODELS["image"]["gemini"][0]
        parts = [{"text": prompt}]
        for r in refs:
            mime, data = _data_uri(r)
            parts.append({"inline_data": {"mime_type": mime, "data": data}})
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(m)}:generateContent"
        body = {"contents": [{"role": "user", "parts": parts}],
                "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": ratio}}}
        try:
            r = _retry(lambda: _req("POST", url, {"x-goog-api-key": k}, body, timeout=300, provider=p), cancel=cancel)
        except AIError as e:
            if getattr(e, "code", 0) != 400:
                raise
            body["generationConfig"] = {"responseModalities": ["TEXT", "IMAGE"]}   # modello che non accetta il formato
            r = _retry(lambda: _req("POST", url, {"x-goog-api-key": k}, body, timeout=300, provider=p), cancel=cancel)
        for pt in ((r.get("candidates") or [{}])[0].get("content") or {}).get("parts", []):
            inl = pt.get("inlineData") or pt.get("inline_data")
            if inl and inl.get("data"):
                b = base64.b64decode(inl["data"])
                return b, _ext_of(b)
        raise AIError("Gemini non ha restituito l'immagine (forse ha rifiutato la richiesta): cambia la descrizione")
    if p == "fal":
        m = model or MODELS["image"]["fal"][0]
        body = {"prompt": prompt, "num_images": 1}
        if "flux" in m:
            body["image_size"] = "portrait_16_9" if ratio == "9:16" else "landscape_16_9" if ratio == "16:9" else "square_hd"
        else:
            body["aspect_ratio"] = ratio
        if refs and m.endswith("/edit"):
            body["image_urls"] = ["data:%s;base64,%s" % _data_uri(r) for r in refs]
        elif m.endswith("/edit"):
            m = m[:-5]      # senza personaggi di riferimento: stesso modello, da solo testo
        # un'immagine ci mette 10-40 secondi: se dopo 2 minuti e mezzo e' ancora ferma la richiesta e' incastrata
        # su fal.ai -> la annullo e la rimando una volta (in coda non si paga)
        try:
            res = fal_run(m, body, k, cancel=cancel, timeout=150)
        except AIError as e:
            if getattr(e, "code", None) != "timeout":
                raise
            print(f"[ai] fal {m}: immagine bloccata, la rimando", flush=True)
            res = fal_run(m, body, k, cancel=cancel, timeout=180)
        imgs = res.get("images") or ([res["image"]] if res.get("image") else [])
        if not imgs or not imgs[0].get("url"):
            raise AIError("fal.ai non ha restituito l'immagine")
        u = imgs[0]["url"]
        if not (u.startswith("https://") or u.startswith("data:image/")):
            raise AIError("fal.ai ha restituito un indirizzo non valido")
        b = base64.b64decode(u.split(",", 1)[1]) if u.startswith("data:") else _req("GET", u, want="bytes", provider=p, timeout=180)
        return b, _ext_of(b)
    raise AIError("Servizio non adatto a creare immagini")


_TL = threading.local()   # _TL.cb(stato): chi sta aspettando fal.ai vuole sapere se e' in coda o in lavorazione


def fal_run(model, body, key, cancel=None, timeout=600):
    hdr = {"Authorization": "Key " + key}
    # l'invio non si ripete se la rete cade: fal potrebbe averlo gia' ricevuto e si pagherebbe due volte
    sub = _retry(lambda: _req("POST", "https://queue.fal.run/" + model, hdr, body, provider="fal", timeout=300), cancel=cancel, only_busy=True)
    status_url = sub.get("status_url") or f"https://queue.fal.run/{model}/requests/{sub['request_id']}/status"
    resp_url = sub.get("response_url") or f"https://queue.fal.run/{model}/requests/{sub['request_id']}"
    cancel_url = sub.get("cancel_url") or f"https://queue.fal.run/{model}/requests/{sub.get('request_id')}/cancel"

    def stop():
        try:
            _req("PUT", cancel_url, hdr, provider="fal", timeout=20)
        except AIError:
            pass

    t0, last = time.time(), None
    while True:
        if cancel and cancel():
            stop()
            raise AIError("Annullato")
        st = _retry(lambda: _req("GET", status_url, hdr, provider="fal", timeout=30))
        s_ = st.get("status")
        if s_ != last:   # per le segnalazioni: quanto resta in coda e quanto in lavorazione
            cb = getattr(_TL, "cb", None)
            if cb:
                try:
                    cb(s_)
                except Exception:
                    pass
            print(f"[ai] fal {model}: {s_} dopo {time.time() - t0:.0f}s" + (f" (posizione {st.get('queue_position')})" if st.get("queue_position") is not None else ""), flush=True)
            last = s_
        if s_ == "COMPLETED":
            break
        if s_ in ("FAILED", "ERROR"):
            raise AIError("fal.ai: generazione non riuscita" + (": " + str(st.get("error"))[:200] if st.get("error") else ""))
        if time.time() - t0 > timeout:
            stop()
            e = AIError("fal.ai ci sta mettendo troppo" + (" (è ancora in coda)" if s_ == "IN_QUEUE" else "") + ": riprova tra poco")
            e.code = "timeout"
            raise e
        time.sleep(1.5)
    return _retry(lambda: _req("GET", resp_url, hdr, provider="fal", timeout=90))


# ------------------------------------------------------------------ video (un'immagine che si anima)
def video(cfg, image_path, prompt, seconds=5, cancel=None):
    """Clip video AI a partire dall'immagine della scena (senza audio: la voce la mette NoonFrame). -> (bytes mp4, secondi)."""
    p, model = cfg.get("provider") or "fal", cfg.get("model") or ""
    if p != "fal":
        raise AIError("Per i video AI serve fal.ai")
    k = _key(p)
    m = video_model(model)
    uri = "data:%s;base64,%s" % _data_uri(image_path)
    sec, _ = video_clip(m, seconds)
    ar = 16 / 9
    try:
        from PIL import Image
        with Image.open(image_path) as im:
            ar = im.width / max(1, im.height)
    except Exception:
        pass
    endpoint, body = video_body(m, uri, sec, prompt, ar)
    m = endpoint
    res = fal_run(m, body, k, cancel=cancel, timeout=1200)
    v = res.get("video") or ((res.get("videos") or [None])[0]) or {}
    u = v.get("url") if isinstance(v, dict) else None
    if not u or not u.startswith("https://"):
        raise AIError("fal.ai non ha restituito il video")
    return _req("GET", u, want="bytes", provider=p, timeout=300), sec


# ------------------------------------------------------------------ voce
def voices(provider):
    if provider == "openai":
        return [{"id": v, "name": v.capitalize(), "labels": {}, "preview": ""} for v in OPENAI_VOICES]
    if provider == "elevenlabs":
        r = _req("GET", "https://api.elevenlabs.io/v1/voices", {"xi-api-key": _key("elevenlabs")}, provider="elevenlabs")
        out = []
        for v in r.get("voices", []):
            lab = v.get("labels") or {}
            out.append({"id": v.get("voice_id"), "name": v.get("name") or "", "preview": v.get("preview_url") or "",
                        "labels": {k: lab.get(k) for k in ("gender", "age", "accent", "description", "use_case") if lab.get(k)},
                        "langs": _vlangs(v)})
        _VOICES_CACHE["elevenlabs"] = out
        return out
    raise AIError("Servizio non adatto alle voci")


def _vlangs(v):
    """Lingue verificate di una voce ElevenLabs: {codice: {accent, preview}}."""
    out = {}
    for x in v.get("verified_languages") or []:
        lang = str(x.get("language") or "")[:5]
        if lang and lang not in out:
            out[lang] = {"accent": x.get("accent") or "", "preview": x.get("preview_url") or ""}
    return out


_SHARED = {}   # voice_id -> anteprima, dall'ultima ricerca nella libreria


def shared_voices(lang="it", gender="", search=""):
    """Voci della libreria pubblica di ElevenLabs in una lingua (madrelingua, con campione in quella lingua)."""
    q = {"language": (lang or "it")[:5], "page_size": "40", "sort": "trending"}
    if gender in ("male", "female"):
        q["gender"] = gender
    if search:
        q["search"] = str(search)[:60]
    r = _req("GET", "https://api.elevenlabs.io/v1/shared-voices?" + urllib.parse.urlencode(q), {"xi-api-key": _key("elevenlabs")}, provider="elevenlabs")
    out = []
    for v in r.get("voices") or []:
        langs = _vlangs(v)
        prev = (langs.get(q["language"]) or {}).get("preview") or v.get("preview_url") or ""
        vid, owner = str(v.get("voice_id") or ""), str(v.get("public_owner_id") or "")
        if not vid or not owner:
            continue
        _SHARED[vid] = prev
        out.append({"id": vid, "owner": owner, "name": v.get("name") or "", "gender": v.get("gender") or "", "age": v.get("age") or "",
                    "accent": (langs.get(q["language"]) or {}).get("accent") or v.get("accent") or "", "description": (v.get("description") or "")[:200],
                    "useCase": v.get("use_case") or "", "descriptive": v.get("descriptive") or ""})
    return out


def add_shared(owner, voice_id, name):
    """Aggiunge una voce della libreria alle voci dell'account ElevenLabs e la restituisce pronta da usare."""
    if not re.fullmatch(r"[A-Za-z0-9]{6,80}", owner or "") or not re.fullmatch(r"[A-Za-z0-9]{6,64}", voice_id or ""):
        raise AIError("Voce non valida")
    r = _req("POST", f"https://api.elevenlabs.io/v1/voices/add/{owner}/{voice_id}", {"xi-api-key": _key("elevenlabs")},
             {"new_name": (str(name or "Voce") + "")[:60]}, provider="elevenlabs")
    _VOICES_CACHE.pop("elevenlabs", None)
    return {"id": r.get("voice_id") or voice_id, "name": str(name or "")[:60]}


# frasi per ascoltare le voci create dalla descrizione (ElevenLabs vuole almeno 100 caratteri)
DESIGN_TEXT = {"it": "Ciao, sono io. Ascoltami bene, perché questa è la voce che sentirai in tutte le mie storie. A volte parlo piano, a volte mi arrabbio, a volte rido. Ti piace?",
               "en": "Hi, it's me. Listen closely, because this is the voice you'll hear in all my stories. Sometimes I speak softly, sometimes I get angry, sometimes I laugh. Do you like it?",
               "es": "Hola, soy yo. Escúchame bien, porque esta es la voz que oirás en todas mis historias. A veces hablo bajito, a veces me enfado, a veces me río. ¿Te gusta?",
               "fr": "Salut, c'est moi. Écoute-moi bien, parce que c'est la voix que tu entendras dans toutes mes histoires. Parfois je parle doucement, parfois je m'énerve, parfois je ris. Ça te plaît ?",
               "de": "Hallo, ich bin's. Hör gut zu, denn das ist die Stimme, die du in all meinen Geschichten hören wirst. Manchmal spreche ich leise, manchmal werde ich wütend, manchmal lache ich. Gefällt sie dir?",
               "pt": "Olá, sou eu. Ouve bem, porque esta é a voz que vais ouvir em todas as minhas histórias. Às vezes falo baixinho, às vezes irrito-me, às vezes rio. Gostas?"}
LANG_EN = {"it": "Italian", "en": "English", "es": "Spanish", "fr": "French", "de": "German", "pt": "Portuguese"}


def design_voice(description, lang="it", text=None):
    """Voce nuova da una descrizione (ElevenLabs Voice Design): 3 proposte da ascoltare prima di sceglierne una.
    Si paga solo la frase di prova (i caratteri letti), salvare la voce e' gratis."""
    desc = " ".join(str(description or "").split())
    if len(desc) < 10:
        raise AIError("Descrivi la voce con qualche parola in più (età, carattere, accento, come parla)")
    lg = (lang or "it")[:2]
    # la lingua in apertura: ElevenLabs consiglia di dirla subito, se no la voce "scivola" verso l'inglese
    full = f"Native {LANG_EN.get(lg, 'Italian')} speaker. {desc}"[:1000]
    if len(full) < 20:
        full = (full + " Clear, natural voice.")[:1000]
    txt = str(text or "").strip() or DESIGN_TEXT.get(lg, DESIGN_TEXT["it"])
    if len(txt) < 100:
        txt = (txt + " " + DESIGN_TEXT.get(lg, DESIGN_TEXT["it"]))[:1000]
    r = _req("POST", "https://api.elevenlabs.io/v1/text-to-voice/design?output_format=mp3_44100_128", {"xi-api-key": _key("elevenlabs")},
             {"voice_description": full, "model_id": "eleven_ttv_v3", "text": txt[:1000], "auto_generate_text": False},
             provider="elevenlabs", timeout=180)
    d = os.path.join(APP_DIR, "cache", "voci")
    os.makedirs(d, exist_ok=True)
    out = []
    for pv in r.get("previews") or []:
        gid = str(pv.get("generated_voice_id") or "")
        if not re.fullmatch(r"[A-Za-z0-9_\-]{4,80}", gid) or not pv.get("audio_base_64"):
            continue
        path = os.path.join(d, f"design-{gid}.mp3")
        with open(path, "wb") as f:
            f.write(base64.b64decode(pv["audio_base_64"]))
        out.append({"id": gid, "path": path, "dur": pv.get("duration_secs")})
    if not out:
        raise AIError("ElevenLabs non ha creato nessuna voce: prova a descriverla in un altro modo")
    return {"previews": out, "description": full}


def save_designed(gid, name, description, lang="it", others=None):
    """Salva nell'account ElevenLabs la voce scelta tra le proposte."""
    if not re.fullmatch(r"[A-Za-z0-9_\-]{4,80}", gid or ""):
        raise AIError("Voce non valida")
    desc = str(description or "").strip()[:1000]
    if len(desc) < 20:
        desc = (desc + " Clear, natural voice for stories.")[:1000]
    body = {"voice_name": (str(name or "Voce").strip() or "Voce")[:60], "voice_description": desc, "generated_voice_id": gid,
            "labels": {"language": (lang or "it")[:2], "made_with": "noonframe"}}
    oth = [x for x in (others or []) if isinstance(x, str) and re.fullmatch(r"[A-Za-z0-9_\-]{4,80}", x) and x != gid]
    if oth:
        body["played_not_selected_voice_ids"] = oth[:5]
    r = _req("POST", "https://api.elevenlabs.io/v1/text-to-voice", {"xi-api-key": _key("elevenlabs")}, body, provider="elevenlabs", timeout=120)
    _VOICES_CACHE.pop("elevenlabs", None)
    vid = str(r.get("voice_id") or "")
    if not vid:
        raise AIError("ElevenLabs non ha salvato la voce")
    return {"id": vid, "name": body["voice_name"]}


SAMPLE_TEXT = {"it": "Ciao! Questa è la mia voce. Ecco come suonerà la tua prossima storia: ascolta il ritmo, le pause e il tono.",
               "en": "Hi! This is my voice. Here's how your next story will sound: listen to the pace, the pauses and the tone.",
               "es": "¡Hola! Esta es mi voz. Así sonará tu próxima historia: escucha el ritmo, las pausas y el tono.",
               "fr": "Salut ! Voici ma voix. Voilà comment sonnera ta prochaine histoire : écoute le rythme, les pauses et le ton.",
               "de": "Hallo! Das ist meine Stimme. So klingt deine nächste Geschichte: hör auf Tempo, Pausen und Ton.",
               "pt": "Olá! Esta é a minha voz. É assim que a tua próxima história vai soar: ouve o ritmo, as pausas e o tom."}
_VOICES_CACHE = {}


def voice_sample(provider, voice_id, settings=None, lang="it", custom=False, model=""):
    """Un file mp3 per ascoltare una voce. ElevenLabs: prima il campione gratuito del servizio;
    'custom' = frase di prova con le impostazioni della pagina (costa pochissimo)."""
    import hashlib
    d = os.path.join(APP_DIR, "cache", "voci")
    os.makedirs(d, exist_ok=True)
    voice_id = str(voice_id or "")
    if provider not in ("elevenlabs", "openai") or not re.fullmatch(r"[A-Za-z0-9_\-]{1,64}", voice_id or "x"):
        raise AIError("Voce non valida")
    if provider == "elevenlabs" and not custom:
        lg = (lang or "it")[:5]
        out = os.path.join(d, f"el-{voice_id}-{lg}.mp3")
        if os.path.isfile(out):
            return out
        if voice_id in _SHARED:
            url = _SHARED[voice_id]
        else:
            v = next((x for x in _VOICES_CACHE.get("elevenlabs") or [] if x["id"] == voice_id), None)
            if not v:
                v = next((x for x in voices("elevenlabs") if x["id"] == voice_id), None)
            v = v or {}
            # il campione nella lingua della pagina; quello "normale" e' quasi sempre in inglese
            url = ((v.get("langs") or {}).get(lg) or {}).get("preview") or (v.get("preview") if lg == "en" else "")
        if not url:
            custom = True
        url = url or ""
        host = urllib.parse.urlparse(url).netloc
        if url.startswith("https://") and (host.endswith("googleapis.com") or host.endswith("elevenlabs.io") or host.endswith("cloudfront.net")):
            data = _req("GET", url, {}, provider="elevenlabs", want="bytes")
            with open(out, "wb") as f:
                f.write(data)
            return out
        custom = True                       # nessun campione: si prova con la frase
    st = {k: float(v) for k, v in (settings or {}).items() if k in ("speed", "stability", "similarity", "style") and v is not None}
    text_ = SAMPLE_TEXT.get(lang or "it", SAMPLE_TEXT["it"])
    key = hashlib.sha1(json.dumps([provider, voice_id, st, text_, model]).encode()).hexdigest()[:16]
    out = os.path.join(d, f"s-{key}.mp3")
    if os.path.isfile(out):
        return out
    audio, _ = speech({"provider": provider, "model": model}, text_, voice_id, st, lang)
    with open(out, "wb") as f:
        f.write(audio)
    return out


def _words_from_alignment(al):
    """Caratteri con i loro tempi -> parole [[parola, inizio, fine]]."""
    chars = al.get("characters") or []
    a = al.get("character_start_times_seconds") or []
    b = al.get("character_end_times_seconds") or []
    words, cur, ca, cb = [], "", None, None
    for ch, s, e in zip(chars, a, b):
        if ch.isspace():
            if cur:
                words.append([cur, round(ca, 3), round(cb, 3)])
            cur, ca, cb = "", None, None
            continue
        if not cur:
            ca = s
        cur += ch
        cb = e
    if cur:
        words.append([cur, round(ca, 3), round(cb, 3)])
    return words


def speech(cfg, text_, voice_id, settings=None, lang="", cancel=None):
    """-> (mp3 bytes, parole con i tempi oppure None)."""
    p, model = cfg.get("provider") or "elevenlabs", cfg.get("model") or ""
    st = settings or {}
    k = _key(p)
    if p == "elevenlabs":
        if not voice_id:
            raise AIError("Scegli una voce ElevenLabs nella pagina")
        body = {"text": text_, "model_id": model or MODELS["voice"]["elevenlabs"][0],
                "voice_settings": {"stability": float(st.get("stability", 0.5)), "similarity_boost": float(st.get("similarity", 0.75)),
                                   "style": float(st.get("style", 0.0)), "speed": float(st.get("speed", 1.0))}}
        if lang and len(lang) == 2 and "multilingual_v2" not in body["model_id"]:
            body["language_code"] = lang
        r = _retry(lambda: _req("POST", f"https://api.elevenlabs.io/v1/text-to-speech/{urllib.parse.quote(voice_id)}/with-timestamps"
                                "?output_format=mp3_44100_128", {"xi-api-key": k}, body, timeout=180, provider=p), cancel=cancel)
        audio = base64.b64decode(r.get("audio_base64") or "")
        if not audio:
            raise AIError("ElevenLabs non ha restituito l'audio")
        return audio, _words_from_alignment(r.get("alignment") or r.get("normalized_alignment") or {}) or None
    if p == "openai":
        body = {"model": model or "gpt-4o-mini-tts", "voice": voice_id or "alloy", "input": text_, "response_format": "mp3"}
        if st.get("instructions"):
            body["instructions"] = str(st["instructions"])[:500]
        if st.get("speed"):
            body["speed"] = float(st["speed"])
        audio = _retry(lambda: _req("POST", "https://api.openai.com/v1/audio/speech", {"Authorization": "Bearer " + k}, body,
                                    timeout=180, provider=p, want="bytes"), cancel=cancel)
        return audio, None
    raise AIError("Servizio non adatto alle voci")


def redact(s):
    """Per log e segnalazioni: toglie tutto quello che somiglia a una chiave."""
    s = re.sub(r"\b(sk-[A-Za-z0-9_\-]{12,})", "sk-***", s or "")
    s = re.sub(r"\bAIza[0-9A-Za-z_\-]{20,}", "AIza***", s)
    s = re.sub(r"(?i)(xi-api-key|x-api-key|x-goog-api-key|authorization)([\"':=\s]+)(Bearer |Key )?[A-Za-z0-9_\-.:]{8,}", r"\1\2***", s)
    return s


# ------------------------------------------------------------------ trascrizione con l'AI (piu' precisa di quella sul computer)
def cloud_transcriber():
    """Il servizio da usare per la trascrizione AI (con le chiavi dell'utente): OpenAI (Whisper) o ElevenLabs (Scribe). None se nessuno."""
    for p in ("openai", "elevenlabs"):
        e = _load_keys().get(p) or {}
        if e.get("key"):
            return p
    return None


def _multipart(fields, fname, fbytes, ftype):
    import uuid as _uuid
    bd = "----nf" + _uuid.uuid4().hex
    out = []
    for k, v in fields:
        out.append(f'--{bd}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    out.append(f'--{bd}\r\nContent-Disposition: form-data; name="file"; filename="{fname}"\r\nContent-Type: {ftype}\r\n\r\n'.encode())
    out.append(fbytes)
    out.append(f"\r\n--{bd}--\r\n".encode())
    return b"".join(out), "multipart/form-data; boundary=" + bd


def _group_words(words):
    """Parole -> frasi (come la trascrizione sul computer): si va a capo sulle pause e sui punti."""
    segs, cur = [], []
    for w in words:
        if cur and (w["a"] - cur[-1]["b"] > 0.8 or (cur[-1]["w"][-1:] in ".?!" and len(cur) > 3) or len(cur) >= 24):
            segs.append({"a": cur[0]["a"], "b": cur[-1]["b"], "words": cur})
            cur = []
        cur.append(w)
    if cur:
        segs.append({"a": cur[0]["a"], "b": cur[-1]["b"], "words": cur})
    return segs


def transcribe_cloud(path, duration, progress=None, cancel=None, language=None, log=print):
    """Trascrizione con l'AI: l'audio va a OpenAI o ElevenLabs a pezzi da 10 minuti, le parole tornano con i tempi."""
    import subprocess
    import tempfile
    from .util import ffmpeg_bin
    p = cloud_transcriber()
    if not p:
        raise AIError("Per la trascrizione AI serve una chiave OpenAI o ElevenLabs in Storie AI → Chiavi AI")
    k = _key(p)
    step = 600.0
    words, lang = [], language
    n = max(1, int(math.ceil((duration or step) / step)))
    tmp = tempfile.mkdtemp(prefix="nf_tr_")
    try:
        for i in range(n):
            if cancel and cancel():
                raise AIError("annullato")
            t0 = i * step
            part = os.path.join(tmp, f"p{i}.mp3")
            r = subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{t0:.3f}", "-t", f"{step:.3f}", "-i", path, "-vn", "-ac", "1",
                                "-ar", "16000", "-b:a", "48k", part], capture_output=True, stdin=subprocess.DEVNULL)
            if r.returncode != 0 or not os.path.exists(part) or os.path.getsize(part) < 2000:
                continue
            with open(part, "rb") as f:
                audio = f.read()
            log(f"Trascrivo con l'AI ({i + 1}/{n})")
            if p == "openai":
                fields = [("model", "whisper-1"), ("response_format", "verbose_json"), ("timestamp_granularities[]", "word"),
                          ("timestamp_granularities[]", "segment")] + ([("language", lang)] if lang else [])
                body, ct = _multipart(fields, "audio.mp3", audio, "audio/mpeg")
                j = _retry(lambda: _req("POST", "https://api.openai.com/v1/audio/transcriptions",
                                        {"Authorization": "Bearer " + k, "Content-Type": ct}, raw=body, timeout=600, provider=p), cancel=cancel)
                lang = lang or {"italian": "it", "english": "en", "spanish": "es", "french": "fr", "german": "de"}.get(str(j.get("language") or "").lower(), None)
                ws = [{"w": str(w.get("word") or "").strip(), "a": float(w.get("start") or 0), "b": float(w.get("end") or 0)} for w in j.get("words") or []]
                # Whisper non mette la punteggiatura sulle parole: si prende dal testo delle frasi
                txt = " ".join(str(s.get("text") or "") for s in j.get("segments") or []).split()
                ti = 0
                for w in ws:
                    for tj in range(ti, min(len(txt), ti + 4)):
                        if re.sub(r"\W", "", txt[tj].lower()) == re.sub(r"\W", "", w["w"].lower()):
                            w["w"], ti = txt[tj], tj + 1
                            break
            else:
                fields = [("model_id", "scribe_v1"), ("timestamps_granularity", "word"), ("tag_audio_events", "false")] + \
                         ([("language_code", lang)] if lang else [])
                body, ct = _multipart(fields, "audio.mp3", audio, "audio/mpeg")
                j = _retry(lambda: _req("POST", "https://api.elevenlabs.io/v1/speech-to-text",
                                        {"xi-api-key": k, "Content-Type": ct}, raw=body, timeout=600, provider=p), cancel=cancel)
                lang = lang or (str(j.get("language_code") or "")[:2] or None)
                ws = [{"w": str(w.get("text") or "").strip(), "a": float(w.get("start") or 0), "b": float(w.get("end") or 0)}
                      for w in j.get("words") or [] if w.get("type", "word") == "word"]
            for w in ws:
                if w["w"]:
                    words.append({"w": w["w"], "a": round(t0 + w["a"], 2), "b": round(t0 + max(w["a"], w["b"]), 2), "del": False})
            if progress:
                progress(min(0.99, (i + 1) / n))
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    if not words:
        raise AIError("La trascrizione AI non ha trovato parole in questo video")
    return {"status": "done", "language": lang, "segments": _group_words(words), "by": p}


def transcribe_cloud_usd(provider, duration):
    return round((duration / 60) * (0.006 if provider == "openai" else 0.0067), 3)
