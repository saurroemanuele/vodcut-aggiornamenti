// Paywall (foglio breve, stile v2): testata sfumata col motivo per cui si e' aperto, Mensile/Annuale, due piani da
// scegliere (Pro prima e gia' scelto, poi il piu' economico), un solo pulsante col prezzo dentro, poi il pagamento di
// sempre (checkout.js). Listino, offerte e costo di un'ora di live arrivano dal server. Chi ha gia' un piano (o non ha
// fatto l'accesso) va alla pagina "Crediti e piani".
import { h, icon } from './lib.js';
import { t as tx } from './i18n.js';
import { loadCatalog, creditsDialog, nf, eur, liveHours, topPlan } from './credits.js';
import { purchase, planOffer, yearSave, periodSwitch, hoursHero } from './plans.js';

// cosa l'ha aperto: la frase sotto il titolo
const WHY = {
  ai: 'L\'Assistente AI è incluso in tutti i piani.',
  '': 'Crediti nuovi ogni mese per trovare le clip e usare l\'Assistente AI.',
};

export async function openPaywall(o = {}) {
  if (document.querySelector('.pw-bg')) return;
  let c = null;
  try { c = await loadCatalog(true); } catch (e) { /* sotto: la pagina dei piani dice cosa non va */ }
  const plans = ((c && c.catalog) || {}).plans || [];
  const top = topPlan(plans);
  if (!c || !c.signedIn || (c.plan && c.plan !== 'free') || !top) return creditsDialog('plans');
  const other = plans.filter((p) => p.id !== top.id).sort((a, b) => a.price - b.price)[0];
  const opts = [top, other].filter(Boolean);
  const hc = c.hourCredits, hasYear = opts.some((p) => p.priceYear), save = yearSave(opts);
  let pick = top.id, period = 'month', busy = false;

  const body = h('div', { class: 'pw-body' });
  const sheet = h('div', { class: 'pw', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Passa a un piano' },
    h('button', { class: 'pw-x', type: 'button', 'aria-label': 'Chiudi', onclick: () => close() }, icon('x', 14, 'currentColor', 2.2)), body);
  const bg = h('div', { class: 'modal-bg pw-bg' }, sheet);
  const close = () => { if (busy) return; bg.remove(); removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.co-bg')) { e.stopPropagation(); close(); } };

  // il prezzo di un piano col periodo scelto: al mese, il mensile barrato se si risparmia, cosa si paga oggi
  const priceOf = (p) => {
    const y = period === 'year' && p.priceYear, po = !y ? planOffer(c, p.id) : null;
    return { y, po, month: y ? p.priceYear / 12 : po ? po.price : p.price, pay: y ? p.priceYear : po ? po.price : p.price };
  };

  function paint() {
    const sel = opts.find((p) => p.id === pick) || top, sp = priceOf(sel);
    const row = (p) => {
      const on = p.id === pick, pr = priceOf(p);
      return h('button', { type: 'button', class: 'pw-opt' + (on ? ' on' : ''), role: 'radio', 'aria-checked': String(on), onclick: () => { pick = p.id; paint(); } },
        h('span', { class: 'pw-radio' }, h('i')),
        h('span', { class: 'pw-mid' },
          h('span', { class: 'pw-nm' }, h('b', { 'data-notr': '' }, p.name), p.id === top.id ? h('em', null, 'Il più scelto') : null),
          hoursHero(p.monthly, hc, 'pw-hrs', 'di live al mese'),
          liveHours(p.monthly, hc) ? h('small', null, h('span', { 'data-notr': '' }, nf(p.monthly)), ' ', h('span', null, 'crediti al mese')) : null),
        h('span', { class: 'pw-pr' }, h('b', { class: 'tnum', 'data-notr': '' }, eur(pr.month)), h('small', null, pr.po ? 'il primo mese' : 'al mese'),
          pr.y || pr.po ? h('s', { 'data-notr': '' }, eur(p.price)) : null));
    };
    const cta = h('button', { type: 'button', class: 'pw-cta' },
      h('span', null, 'Continua con'), ' ', h('span', { 'data-notr': '' }, sel.name), ' · ', h('span', { 'data-notr': '' }, eur(sp.pay)), ' ',
      h('span', null, sp.y ? 'l\'anno' : sp.po ? 'il primo mese' : 'al mese'));
    cta.onclick = async () => {
      const det = nf(sel.monthly) + ' ' + tx('crediti ogni mese');   // va alla pagina di pagamento gia' tradotto
      const info = { kind: 'plan', name: 'NoonFrame ' + sel.name, plan: sel.name, det, price: eur(sp.pay) };
      busy = true;
      const r = sp.po ? await purchase(c, 'offer', sp.po.id, null, info, cta) : await purchase(c, 'plan', sel.id, sp.y ? 'year' : 'month', info, cta);
      busy = false;
      if (r && (r.paid || r.changed || r.fallback)) close();
    };
    body.replaceChildren(
      h('div', { class: 'pw-hero' },
        h('span', { class: 'pw-kick' }, 'PASSA A UN PIANO'),
        h('h2', null, 'Più ore di live, più clip.'),
        h('p', null, WHY[o.why] || WHY[''])),
      h('div', { class: 'pw-bar' },
        hasYear ? periodSwitch(period, save > 0 ? '−' + save + '%' : '', (k) => { period = k; paint(); }) : h('span'),
        h('span', null, 'Disdici quando vuoi')),
      h('div', { class: 'pw-opts', role: 'radiogroup' }, ...opts.map(row)),
      h('div', { class: 'pw-perks' }, ...['Crediti nuovi ogni mese', 'Assistente AI incluso', 'Clip dal web in priorità'].map((k) => h('span', null, icon('check', 12, 'currentColor', 2.6), h('span', null, k)))),
      cta,
      h('div', { class: 'pw-foot' },
        hc ? h('span', null, h('span', null, '1 ora di live ≈'), ' ', h('span', { 'data-notr': '' }, nf(hc)), ' ', h('span', null, 'crediti')) : h('span', null, 'Prezzi IVA inclusa'),
        h('button', { type: 'button', class: 'linkish', onclick: () => { close(); creditsDialog('plans'); } }, 'Tutti i piani e le ricariche')));
  }

  paint();
  addEventListener('keydown', onKey, true);
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  sheet.querySelector('.pw-cta').focus({ preventScroll: true });
}
