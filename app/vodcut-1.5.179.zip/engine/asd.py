"""Chi sta parlando: guarda la faccia (la bocca) e ascolta l'audio insieme.

Rete neurale piccola (Light-ASD, licenza MIT, Liao Junhua 2023; circa 1 milione di parametri) in formato ONNX,
inclusa nell'app (engine/models/light_asd.onnx). Per ogni persona riceve il pezzo del viso attorno alla bocca
(112x112 in grigi, 25 fotogrammi al secondo) e l'audio (MFCC, 100 al secondo) e dice, fotogramma per fotogramma,
quanto e' probabile che sia lei a parlare: numero > 0 = parla, < 0 = no.
Funziona anche con chi ascolta muovendo la bocca (risate, smorfie): conta se la bocca va a tempo con la voce.
"""
import os
import threading

import numpy as np

MODEL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "light_asd.onnx")
FPS = 25
SR = 16000
_SESS = None
_LOCK = threading.Lock()


def available():
    if not os.path.exists(MODEL):
        return False
    try:
        import onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def _session():
    global _SESS
    with _LOCK:
        if _SESS is None:
            import onnxruntime as ort
            so = ort.SessionOptions()
            so.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 2) // 2))
            so.log_severity_level = 3
            _SESS = ort.InferenceSession(MODEL, so, providers=["CPUExecutionProvider"])
    return _SESS


def _mel_bank(nfilt=26, nfft=512, sr=SR):
    mel = lambda hz: 2595 * np.log10(1 + hz / 700.0)   # noqa: E731
    hz = lambda m: 700 * (10 ** (m / 2595.0) - 1)       # noqa: E731
    pts = np.linspace(mel(0), mel(sr / 2), nfilt + 2)
    b = np.floor((nfft + 1) * hz(pts) / sr)
    fb = np.zeros((nfilt, nfft // 2 + 1))
    for j in range(nfilt):
        for i in range(int(b[j]), int(b[j + 1])):
            fb[j, i] = (i - b[j]) / (b[j + 1] - b[j])
        for i in range(int(b[j + 1]), int(b[j + 2])):
            fb[j, i] = (b[j + 2] - i) / (b[j + 2] - b[j + 1])
    return fb


_FB = None
_DCT = None


def mfcc(sig, sr=SR, numcep=13, nfilt=26, nfft=512):
    """MFCC come python_speech_features.mfcc con i valori usati per allenare la rete (finestre di 25 ms ogni 10 ms,
    pre-enfasi 0,97, lifter 22, primo coefficiente = log dell'energia). sig: float, mono, 16 kHz."""
    global _FB, _DCT
    if _FB is None:
        _FB = _mel_bank(nfilt, nfft, sr)
        n = np.arange(nfilt)
        k = np.arange(numcep)[:, None]
        d = np.cos(np.pi * k * (2 * n + 1) / (2 * nfilt)) * np.sqrt(2.0 / nfilt)
        d[0] /= np.sqrt(2.0)
        _DCT = d.T                                   # (nfilt, numcep), DCT-II ortonormale
    sig = np.asarray(sig, dtype=np.float64)
    sig = np.append(sig[0] if len(sig) else 0.0, sig[1:] - 0.97 * sig[:-1])
    flen, fstep = int(round(0.025 * sr)), int(round(0.010 * sr))
    n = 1 if len(sig) <= flen else 1 + int(np.ceil((len(sig) - flen) / fstep))
    pad = np.concatenate([sig, np.zeros(max(0, (n - 1) * fstep + flen - len(sig)))])
    idx = np.arange(flen)[None, :] + (np.arange(n) * fstep)[:, None]
    frames = pad[idx]
    pspec = (np.abs(np.fft.rfft(frames, nfft)) ** 2) / nfft
    energy = pspec.sum(axis=1)
    energy = np.where(energy == 0, np.finfo(float).eps, energy)
    feat = pspec @ _FB.T
    feat = np.where(feat == 0, np.finfo(float).eps, feat)
    feat = np.log(feat) @ _DCT
    lift = 1 + 11.0 * np.sin(np.pi * np.arange(numcep) / 22.0)
    feat = feat * lift
    feat[:, 0] = np.log(energy)
    return feat.astype(np.float32)


def face_crop(gray, cx, cy, bs, size=112):
    """Il pezzo di viso che la rete si aspetta: quadrato di lato 1,4*bs centrato poco sotto il centro del viso
    (bocca e mento), 112x112. bs = meta' del lato maggiore del riquadro del viso. Fuori dall'immagine: grigio 110."""
    import cv2
    h, w = gray.shape[:2]
    half = 0.7 * bs
    x0, y0 = int(round(cx - half)), int(round(cy + 0.4 * bs - half))
    x1, y1 = int(round(cx + half)), int(round(cy + 0.4 * bs + half))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return np.full((size, size), 110, np.uint8)
    if x0 < 0 or y0 < 0 or x1 > w or y1 > h:
        p = max(0, -x0, -y0, x1 - w, y1 - h)
        gray = cv2.copyMakeBorder(gray, p, p, p, p, cv2.BORDER_CONSTANT, value=110)
        x0, x1, y0, y1 = x0 + p, x1 + p, y0 + p, y1 + p
    return cv2.resize(gray[y0:y1, x0:x1], (size, size), interpolation=cv2.INTER_AREA)


def scores(audio, faces, chunks=(4.0,)):
    """Punteggio "sta parlando" per ogni fotogramma (25 al secondo) di una persona.
    audio: mono 16 kHz dello stesso pezzo, valori come int16 (-32768..32767, come per l'allenamento);
    faces: (T, 112, 112) uint8. Media di piu' passate con pezzi di
    lunghezze diverse (piu' stabile, come fanno gli autori). Ritorna array (T,)."""
    s = _session()
    T = int(len(faces))
    if T < 2:
        return np.zeros(T, np.float32)
    m = mfcc(audio)
    # stessa durata: 4 righe di audio per fotogramma
    L = min(T, len(m) // 4)
    if L < 2:
        return np.zeros(T, np.float32)
    m = m[:L * 4]
    v = np.asarray(faces[:L], dtype=np.float32)
    acc = np.zeros(L, np.float64)
    for d in chunks:
        n = max(2, int(round(d * FPS)))
        out = np.zeros(L, np.float64)
        for i0 in range(0, L, n):
            i1 = min(L, i0 + n)
            if i1 - i0 < 2:      # ultimo pezzo di un fotogramma solo: stesso valore del precedente
                out[i0:i1] = out[i0 - 1] if i0 else 0.0
                continue
            r = s.run(None, {"audio": m[i0 * 4:i1 * 4][None], "video": v[i0:i1][None]})[0]
            out[i0:i1] = r[:i1 - i0]
        acc += out
    res = np.zeros(T, np.float32)
    res[:L] = acc / len(chunks)
    if L < T:
        res[L:] = res[L - 1]
    return res
