"""Storie AI: pagine (identita' di ogni profilo social) e storie generate con l'AI, scena per scena.

Una PAGINA e' il preset fisso di un profilo: stile delle immagini, personaggi (con foto di riferimento), voci,
regole della narrazione, sottotitoli e musica. Ogni storia nuova usa la sua pagina, cosi' lo stile non cambia.

Una STORIA e' una cartella in ~/VODcut/storie-ai/<id> con storia.json e i file generati. Ogni scena ha il suo
stato: si puo' rigenerare o bloccare una sola scena (o una sola battuta) senza rifare il resto. Se qualcosa si
interrompe, si riparte da dove era arrivato: i file gia' fatti restano.
"""
import json
import os
import re
import secrets
import shutil
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from . import ai
from .util import APP_DIR, NO_WINDOW, ffmpeg_bin, probe

PAGES_DIR = os.path.join(APP_DIR, "pagine")
STORIES_DIR = os.path.join(APP_DIR, "storie-ai")
_LOCKS = {}
_GLOCK = threading.Lock()
MOTIONS = ["zoomIn", "zoomOut", "panL", "panR", "panU", "panD"]

STYLE_PRESETS = {
    "cinematic": "Cinematic photorealistic still, dramatic lighting, shallow depth of field, rich color grading, 35mm film look",
    "anime": "High quality anime illustration, clean line art, expressive characters, vibrant cel shading, detailed backgrounds",
    "pixar": "3D animated film style, soft global illumination, appealing stylized characters, warm colors, high detail render",
    "dark": "Dark horror atmosphere, desaturated palette, heavy shadows, fog, eerie cold light, cinematic composition",
    "comic": "Graphic novel illustration, bold ink outlines, halftone shading, strong contrast, dynamic panels",
    "watercolor": "Soft watercolor painting, delicate textures, pastel palette, gentle light, storybook illustration",
}


def _lock(key):
    with _GLOCK:
        return _LOCKS.setdefault(key, threading.RLock())


def _sid(x):
    x = str(x or "")
    if not re.fullmatch(r"[a-z]{1,2}[0-9a-f]{6,20}", x):
        raise ValueError("Identificativo non valido")
    return x


def _write(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def _read(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------------ pagine
def _page_path(pid):
    return os.path.join(PAGES_DIR, _sid(pid), "pagina.json")


def page_defaults():
    return {"name": "Nuova pagina", "handle": "", "lang": "it", "niche": "", "duration": 60,
            "style": {"preset": "cinematic", "prompt": STYLE_PRESETS["cinematic"]},
            "narrative": {"kind": "", "tone": "", "hook": "", "avoid": "", "rules": "", "pov": "terza persona", "ending": ""},
            "characters": [], "narrator": {"id": "", "name": ""},
            "textCfg": {"provider": "", "model": ""}, "imageCfg": {"provider": "", "model": ""},
            "voiceCfg": {"provider": "", "model": "", "stability": 0.5, "similarity": 0.75, "style": 0.0, "speed": 1.0},
            "videoCfg": {"provider": "", "model": "", "share": "few", "talkModel": "", "dialog": "talk", "lipsync": False},
            "edit": {"captions": "word", "music": None, "musicVol": 22}, "history": [],
            "product": {"name": "", "what": "", "audience": "", "benefits": "", "offer": "", "cta": ""}}


def list_pages():
    out = []
    try:
        names = os.listdir(PAGES_DIR)
    except OSError:
        return out
    for n in names:
        try:
            p = _read(os.path.join(PAGES_DIR, n, "pagina.json"))
            out.append(p)
        except Exception:
            continue
    out.sort(key=lambda p: p.get("created") or 0)
    return out


def get_page(pid):
    return _read(_page_path(pid))


def _clean_str(v, n):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v or ""))[:n]


def save_page(data):
    """Crea o aggiorna una pagina (solo i campi conosciuti, con limiti di lunghezza)."""
    pid = data.get("id") or ("pg" + secrets.token_hex(5))
    with _lock(pid):
        try:
            cur = get_page(pid)
        except (FileNotFoundError, ValueError):
            if data.get("id"):
                _sid(pid)
            cur = page_defaults()
            cur.update({"id": pid, "created": time.time()})
        base = page_defaults()
        for k in ("name", "handle", "lang", "niche"):
            if k in data:
                cur[k] = _clean_str(data[k], 2000 if k == "niche" else 80)
        if "duration" in data:
            cur["duration"] = max(15, min(180, int(data.get("duration") or 60)))
        for grp, lim in (("style", 2500), ("narrative", 1500), ("textCfg", 80), ("imageCfg", 80), ("voiceCfg", 200), ("videoCfg", 80),
                         ("narrator", 120), ("edit", 400), ("product", 1500)):
            if isinstance(data.get(grp), dict):
                g = dict(cur.get(grp) or base[grp])
                for k, v in data[grp].items():
                    if k not in base[grp] and grp != "edit":
                        continue
                    if isinstance(v, bool):
                        g[k] = v
                    elif isinstance(v, (int, float)):
                        g[k] = max(0.0, min(4.0, float(v))) if grp == "voiceCfg" else v
                    elif isinstance(v, dict) and grp == "edit" and k == "music":
                        g[k] = {"file": str(v.get("file") or ""), "name": _clean_str(v.get("name"), 120)} if v.get("file") and os.path.isfile(str(v.get("file"))) else None
                    elif v is None:
                        g[k] = None
                    else:
                        g[k] = _clean_str(v, lim)
                cur[grp] = g
        if isinstance(data.get("characters"), list):
            chars = []
            old = {c["id"]: c for c in cur.get("characters") or []}
            for c in data["characters"][:12]:
                cid = c.get("id") if re.fullmatch(r"ch[0-9a-f]{6,12}", str(c.get("id") or "")) else "ch" + secrets.token_hex(4)
                prev = old.get(cid) or {}
                refs = [r for r in (c.get("refs") if isinstance(c.get("refs"), list) else prev.get("refs") or [])
                        if isinstance(r, str) and os.path.isfile(r) and r.startswith(os.path.join(PAGES_DIR, pid))][:4]
                chars.append({"id": cid, "name": _clean_str(c.get("name"), 40).strip() or "Personaggio",
                              "look": _clean_str(c.get("look"), 1200), "personality": _clean_str(c.get("personality"), 600),
                              "role": _clean_str(c.get("role"), 120),
                              "voice": {"id": _clean_str((c.get("voice") or {}).get("id"), 120), "name": _clean_str((c.get("voice") or {}).get("name"), 120)},
                              "refs": refs})
            cur["characters"] = chars
        cur["updated"] = time.time()
        _write(_page_path(pid), cur)
        return cur


def delete_page(pid):
    d = os.path.join(PAGES_DIR, _sid(pid))
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    return True


def add_ref(pid, cid, src):
    """Foto di riferimento di un personaggio: copiata nella cartella della pagina."""
    import cv2
    import numpy as np
    p = get_page(pid)
    ch = next((c for c in p.get("characters") or [] if c["id"] == cid), None)
    if not ch:
        raise ValueError("Personaggio non trovato: salva la pagina e riprova")
    if len(ch.get("refs") or []) >= 4:
        raise ValueError("Al massimo 4 foto per personaggio")
    # OpenCV (gia' dentro l'app); np.fromfile/tofile per i percorsi con lettere accentate su Windows
    try:
        im = cv2.imdecode(np.fromfile(src, dtype=np.uint8), cv2.IMREAD_COLOR)
    except Exception:
        im = None
    if im is None:
        raise ValueError("Non è un'immagine valida")
    h_, w_ = im.shape[:2]
    k = min(1.0, 1536 / max(h_, w_))
    if k < 1:
        im = cv2.resize(im, (int(w_ * k), int(h_ * k)), interpolation=cv2.INTER_AREA)
    d = os.path.join(PAGES_DIR, pid, "riferimenti")
    os.makedirs(d, exist_ok=True)
    dst = os.path.join(d, f"{cid}_{secrets.token_hex(3)}.jpg")
    ok, buf = cv2.imencode(".jpg", im, [cv2.IMWRITE_JPEG_QUALITY, 92])
    if not ok:
        raise ValueError("Non riesco a salvare la foto")
    buf.tofile(dst)
    ch.setdefault("refs", []).append(dst)
    return save_page({"id": pid, "characters": p["characters"]})


def add_screen(pid, src):
    """Screen dell'app del prodotto: finiscono sullo schermo del telefono nelle scene che mostrano l'app."""
    import cv2
    import numpy as np
    with _lock(pid):
        p = get_page(pid)
        scr = list(p.get("screens") or [])
        if len(scr) >= 8:
            raise ValueError("Al massimo 8 screen")
        try:
            im = cv2.imdecode(np.fromfile(src, dtype=np.uint8), cv2.IMREAD_COLOR)
        except Exception:
            im = None
        if im is None:
            raise ValueError("Non è un'immagine valida")
        h_, w_ = im.shape[:2]
        k = min(1.0, 1600 / max(h_, w_))
        if k < 1:
            im = cv2.resize(im, (int(w_ * k), int(h_ * k)), interpolation=cv2.INTER_AREA)
        d = os.path.join(PAGES_DIR, pid, "prodotto")
        os.makedirs(d, exist_ok=True)
        dst = os.path.join(d, f"screen_{secrets.token_hex(3)}.png")
        ok, buf = cv2.imencode(".png", im)
        if not ok:
            raise ValueError("Non riesco a salvare lo screen")
        buf.tofile(dst)
        p["screens"] = scr + [dst]
        _write(_page_path(pid), p)
    return get_page(pid)


def remove_screen(pid, path):
    with _lock(pid):
        p = get_page(pid)
        scr = [x for x in p.get("screens") or [] if x != path]
        if path in (p.get("screens") or []) and path.startswith(os.path.join(PAGES_DIR, pid)):
            try:
                os.remove(path)
            except OSError:
                pass
        p["screens"] = scr
        _write(_page_path(pid), p)
    return get_page(pid)


def remove_ref(pid, cid, path):
    p = get_page(pid)
    for c in p.get("characters") or []:
        if c["id"] == cid and path in (c.get("refs") or []):
            c["refs"].remove(path)
            try:
                if path.startswith(os.path.join(PAGES_DIR, pid)):
                    os.remove(path)
            except OSError:
                pass
    return save_page({"id": pid, "characters": p["characters"]})


# ------------------------------------------------------------------ servizi scelti (quelli con la chiave, se la pagina non dice)
def pick(page, what):
    keys = ai.keys_status()
    cfg = dict(page.get({"text": "textCfg", "image": "imageCfg", "voice": "voiceCfg", "video": "videoCfg"}[what]) or {})
    order = {"text": ["anthropic", "openai", "gemini"], "image": ["fal", "gemini", "openai"], "voice": ["elevenlabs", "openai"], "video": ["fal"]}[what]
    if not cfg.get("provider") or not keys.get(cfg["provider"], {}).get("set"):
        cfg["provider"] = next((p for p in order if keys[p]["set"]), "")
        cfg["model"] = ""
    if not cfg["provider"]:
        need = {"text": "OpenAI, Anthropic o Gemini", "image": "fal.ai, Gemini o OpenAI", "voice": "ElevenLabs o OpenAI", "video": "fal.ai"}[what]
        raise ai.AIError(f"Per questo passaggio serve una chiave di {need}: aggiungila in Chiavi AI")
    if not cfg.get("model"):
        cfg["model"] = ai.MODELS[what][cfg["provider"]][0]
    return cfg


# ------------------------------------------------------------------ storie
def _story_dir(sid):
    return os.path.join(STORIES_DIR, _sid(sid))


def _story_path(sid):
    return os.path.join(_story_dir(sid), "storia.json")


def get_story(sid):
    st = _read(_story_path(sid))
    if "lipsync" not in st:
        # storie di prima: le scene che parlano erano tutte con il lip sync
        set_lipsync(st, any(x.get("kind") == "talk" for x in st.get("scenes") or []))
    return st


def save_story(st):
    st["updated"] = time.time()
    _write(_story_path(st["id"]), st)
    return st


def list_stories(pid=None):
    out = []
    try:
        names = os.listdir(STORIES_DIR)
    except OSError:
        return out
    for n in names:
        try:
            s = _read(os.path.join(STORIES_DIR, n, "storia.json"))
        except Exception:
            continue
        if pid and s.get("page") != pid:
            continue
        sc = s.get("scenes") or []
        out.append({"id": s["id"], "page": s.get("page"), "title": s.get("title"), "status": s.get("status"), "created": s.get("created"),
                    "updated": s.get("updated"), "scenes": len(sc), "images": sum(1 for x in sc if (x.get("image") or {}).get("file")),
                    "voices": sum(1 for x in sc if (x.get("audio") or {}).get("file")), "project": s.get("project"), "look": s.get("look") or "video",
                    "cost": round(sum(c.get("usd", 0) for c in s.get("costs") or []), 3),
                    "thumb": next(((x.get("image") or {}).get("file") for x in sc if (x.get("image") or {}).get("file")), None)})
    out.sort(key=lambda s: s.get("updated") or 0, reverse=True)
    return out


def delete_story(sid):
    d = _story_dir(sid)
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    return True


def story_files(st):
    """File che l'interfaccia puo' mostrare (immagini e voci della storia)."""
    out = []
    if (st.get("ownVoice") or {}).get("file"):
        out.append(st["ownVoice"]["file"])
    for sc in st.get("scenes") or []:
        for k in ("image", "audio", "video"):
            f = (sc.get(k) or {}).get("file")
            if f:
                out.append(f)
    return out


def _cost(st, kind, provider, model, usd, units=None):
    st.setdefault("costs", []).append({"at": time.time(), "kind": kind, "provider": provider, "model": model,
                                       "usd": round(float(usd), 4), "units": units, "estimate": True})


def estimate(st, page):
    """Costo stimato di quello che manca da fare (dollari, indicativo)."""
    keys = ai.keys_status()
    try:
        ic = pick(page, "image")["provider"]
    except ai.AIError:
        ic = "fal"
    try:
        vc = pick(page, "voice")["provider"]
    except ai.AIError:
        vc = "elevenlabs"
    sc = st.get("scenes") or []
    imgs = sum(1 for i, x in enumerate(sc) if not (x.get("image") or {}).get("file") and not joined(sc, i))
    chars = sum(len(x.get("text") or "") for x in sc
                if not (x.get("audio") or {}).get("file") or (x.get("audio") or {}).get("text") != x.get("text"))
    if st.get("ownVoice"):
        chars = 0
    durs = group_durations(st)
    vids = [i for i, x in enumerate(sc) if x.get("kind") == "video" and not joined(sc, i) and not _video_ok(x, st)]
    talks = [i for i, x in enumerate(sc) if x.get("kind") == "talk" and not joined(sc, i) and not _video_ok(x, st)]
    tm = ai.talk_model((page.get("videoCfg") or {}).get("talkModel") or "")
    try:
        vm = ai.video_model(pick(page, "video")["model"])
    except ai.AIError:
        vm = ai.VIDEO_DEFAULT
    # scene che parlano: con il lip sync si paga il modello apposta, senza (bocca che si muove) e' una clip normale
    talk_usd = sum(ai.talk_cost(sc[i].get("talkModel") or tm, durs[i]) if sc[i].get("lip") else ai.video_clip(scene_model(sc[i], vm), durs[i])[1]
                   for i in talks)
    clips = [ai.video_clip(scene_model(sc[i], vm), durs[i]) for i in vids]
    vid_sec = sum(c[0] for c in clips)
    try:
        im_cfg = pick(page, "image")
        img_one = ai.image_price(im_cfg["provider"], im_cfg["model"])
    except ai.AIError:
        img_one = ai.PRICE["image"].get(ic, 0.08)
    img_usd = imgs * img_one
    v_usd = chars * ai.PRICE["voice_char"].get(vc, 0.0002)
    vid_usd = sum(c[1] for c in clips) + talk_usd
    spent = sum(c.get("usd", 0) for c in st.get("costs") or [])
    return {"images": imgs, "imageUsd": round(img_usd, 3), "chars": chars, "voiceUsd": round(v_usd, 3), "imageProvider": ic,
            "voiceProvider": vc, "videos": len(vids) + len(talks), "videoSec": vid_sec, "videoUsd": round(vid_usd, 3), "videoModel": vm,
            "videoPrice": (ai.VIDEO_INFO.get(vm) or {}).get("usd_s", 0.1),
            "videoPerScene": {sc[i]["id"]: {"model": scene_model(sc[i], vm), "sec": c[0], "usd": c[1]} for i, c in zip(vids, clips)},
            "talks": len(talks), "talkUsd": round(talk_usd, 3), "talkModel": tm, "lipsync": bool(st.get("lipsync")), "look": st.get("look") or "video",
            "todo": round(img_usd + v_usd + vid_usd, 3), "credits": ai.credits_on(),
            "todoCredits": int(-(-(img_usd + v_usd + vid_usd) * ai.CREDITS_PER_USD // 1)), "spent": round(spent, 3), "keys": {k: v["set"] for k, v in keys.items()},
            "durations": [round(d, 2) for d in scene_durations(st)], "groupDurations": [round(d, 2) for d in durs], "pauses": [round(pause_after(sc, i), 2) for i in range(len(sc))]}


AI_KINDS = ("video", "talk")   # scene che diventano una clip fatta da fal.ai


# ---- piu' battute nella stessa clip: una scena con "join" continua la clip della scena prima
def joined(scenes, i):
    return i > 0 and bool(scenes[i].get("join"))


def group_of(scenes, i):
    """Indici della clip che contiene la scena i (la prima e' quella che la crea)."""
    a = i
    while a > 0 and scenes[a].get("join"):
        a -= 1
    b = a + 1
    while b < len(scenes) and scenes[b].get("join"):
        b += 1
    return list(range(a, b))


def group_text(scenes, i):
    return "\n".join((scenes[k].get("text") or "").strip() for k in group_of(scenes, i))


def group_durations(st, durs=None):
    """Durata della clip per ogni scena che la crea (somma delle sue battute); 0 per quelle unite."""
    durs = durs or scene_durations(st)
    sc = st.get("scenes") or []
    return [0.0 if joined(sc, i) else sum(durs[k] for k in group_of(sc, i)) for i in range(len(sc))]


def _video_ok(sc, st=None):
    v = sc.get("video") or {}
    if not (v.get("file") and os.path.isfile(v["file"]) and v.get("image") == (sc.get("image") or {}).get("file")):
        return False
    text = sc.get("text")
    if st is not None:
        scs = st.get("scenes") or []
        i = next((k for k, x in enumerate(scs) if x.get("id") == sc.get("id")), None)
        if i is not None:
            ids = [scs[k]["id"] for k in group_of(scs, i)]
            if (v.get("group") or [sc.get("id")]) != ids:   # clip fatta per altre battute: va rifatta
                return False
            text = group_text(scs, i)
    talk = v.get("talk")
    if sc.get("kind") == "talk":   # la clip che parla va rifatta se cambia la battuta (voce)
        if not talk or talk.get("text") != text:
            return False
        if not sc.get("lip"):      # bocca che si muove: basta la frase
            return talk.get("mode") == "mouth"
        return talk.get("mode") != "mouth" and talk.get("audio") == (sc.get("audio") or {}).get("file")
    return not talk


def scene_model(sc, default):
    """Modello video della scena: quello scelto solo per lei, altrimenti quello della pagina."""
    m = sc.get("videoModel")
    return ai.video_model(m) if m else ai.video_model(default)


PAUSE_MAX = 2.0


def pause_after(scenes, i):
    """Silenzio dopo la battuta i: scelto a mano, altrimenti automatico (domanda, esclamazione, sospensione,
    cambio di chi parla: un attimo di respiro; tra frasi dello stesso personaggio: quasi niente)."""
    sc = scenes[i]
    p = sc.get("pause")
    if isinstance(p, (int, float)) and not isinstance(p, bool):
        return max(0.0, min(PAUSE_MAX, float(p)))
    if i >= len(scenes) - 1:
        return 0.12
    t = (sc.get("text") or "").strip()
    nxt = scenes[i + 1]
    if t.endswith(("…", "...")):
        return 0.6
    if t.endswith(("?", "!")):
        return 0.45
    if (sc.get("speaker") or "").strip().lower() != (nxt.get("speaker") or "").strip().lower():
        return 0.3
    return 0.12


def scene_durations(st):
    """Quanto dura ogni scena: dalla voce vera (generata o registrata) oppure stimata dal testo."""
    own = st.get("ownVoice") or {}
    if own.get("times") and len(own["times"]) == len(st["scenes"]):
        return [max(0.5, b - a) for a, b in own["times"]]
    out = []
    scs = st["scenes"]
    for i, s in enumerate(scs):
        a = s.get("audio") or {}
        if a.get("file") and a.get("text") == s.get("text") and a.get("dur"):
            out.append(float(a["dur"]) + pause_after(scs, i))
        else:
            out.append(max(1.2, len((s.get("text") or "").split()) / 2.6) + pause_after(scs, i))
    return out


SHARES = {"none": 0.0, "few": 0.25, "half": 0.5, "all": 1.0}


def is_dialog(sc):
    """Battuta detta da un personaggio (non dal narratore)."""
    return speaker_key(sc.get("speaker")) not in NARRATOR_NAMES


def set_lipsync(st, on):
    """Scene che parlano: con il lip sync (labbra a tempo, modello apposta) o solo la bocca che si muove (clip normale, costa meno)."""
    st["lipsync"] = bool(on)
    for sc in st.get("scenes") or []:
        sc["lip"] = bool(on)


def choose_videos(st, share, dialog=None):
    """Quali scene diventano video AI: le piu' importanti (apertura, azione, climax), le altre restano immagini animate.
    dialog="talk": le battute dei personaggi diventano scene che parlano; le quote valgono per le altre."""
    dialog = dialog or st.get("dialog") or "talk"
    st["dialog"] = dialog
    set_lipsync(st, st.get("lipsync"))
    n = len(st["scenes"])
    want = round(n * SHARES.get(share, 0.25))
    if share == "few":
        want = max(1, min(want, 4))
    def score(i):   # importanza scritta dall'AI, poi l'apertura (hook) e il climax (verso i 3/4 della storia)
        return (st["scenes"][i].get("importance") or 2) * 10 + (5 if i == 0 else 0) + (3 if 0.6 * n <= i <= 0.9 * n else 0) - i * 0.01
    order = sorted(range(n), key=score, reverse=True)
    pick = set(order[:want])
    for i, sc in enumerate(st["scenes"]):
        if not sc.get("locked"):
            sc["kind"] = "talk" if dialog == "talk" and is_dialog(sc) else ("video" if i in pick else "image")
    sync_groups(st)
    st["videoShare"] = share
    return st


def sync_groups(st):
    """Le battute unite nella stessa clip hanno lo stesso tipo: parla se qualcuno parla, se no quello della prima."""
    scs = st.get("scenes") or []
    if scs:
        scs[0].pop("join", None)
    i = 0
    while i < len(scs):
        g = group_of(scs, i)
        if len(g) > 1:
            kinds = [scs[k].get("kind") for k in g]
            k0 = "talk" if "talk" in kinds and (st.get("dialog") or "talk") == "talk" else ("video" if "video" in kinds or "talk" in kinds else scs[g[0]].get("kind"))
            for k in g:
                scs[k]["kind"] = k0
                scs[k]["lip"] = bool(st.get("lipsync"))
        i = g[-1] + 1
    return st


# ------------------------------------------------------------------ testo della storia (prompt)
LANG_NAME = {"it": "italiano", "en": "English", "es": "español", "fr": "français", "de": "Deutsch", "pt": "português"}


def _bible(page):
    n = page.get("narrative") or {}
    chars = page.get("characters") or []
    parts = [f"Pagina: {page.get('name')}" + (f" (@{page['handle']})" if page.get("handle") else ""),
             f"Nicchia e argomenti: {page.get('niche') or 'libera'}"]
    for k, lbl in (("kind", "Tipo di storie"), ("tone", "Tono"), ("hook", "Come aprire (hook)"), ("pov", "Punto di vista"),
                   ("ending", "Tipo di finale"), ("rules", "Regole di scrittura"), ("avoid", "Argomenti da evitare")):
        if n.get(k):
            parts.append(f"{lbl}: {n[k]}")
    if chars:
        parts.append("Personaggi ricorrenti (usa questi nomi esatti):")
        for c in chars:
            parts.append(f"- {c['name']}: {c.get('role') or ''} {c.get('personality') or ''}".strip())
    pr = page.get("product") or {}
    if pr.get("name") or pr.get("what"):
        parts.append("PRODOTTO DA PROMUOVERE (usa solo queste informazioni, non inventarne altre):")
        for k, lbl in (("name", "Nome"), ("what", "Cos'è e cosa fa"), ("audience", "Per chi è"), ("benefits", "Benefici"),
                       ("offer", "Prezzo / offerta"), ("cta", "Invito all'azione")):
            if pr.get(k):
                parts.append(f"- {lbl}: {pr[k]}")
    if page.get("screens") and (pr.get("name") or pr.get("what")):
        parts.append("Abbiamo gli screen veri dell'app: quando una scena mostra l'app metti \"app\": true e nel visual descrivi "
                     "una persona (o una mano) che tiene lo smartphone con lo schermo ben visibile verso la camera. Mostra l'app "
                     "almeno in una scena (di solito quando si parla del prodotto o nell'invito all'azione).")
    hist = [h.get("title") for h in (page.get("history") or [])[-40:] if h.get("title")]
    if hist:
        parts.append("Storie già pubblicate da NON ripetere (né titoli, né hook, né finali simili): " + "; ".join(hist))
    return "\n".join(parts)


SCHEMA = """Rispondi SOLO con un oggetto JSON, senza testo prima o dopo:
{"title": "titolo breve della storia",
 "scenes": [
   {"speaker": "NARRATORE oppure il nome esatto di un personaggio che parla",
    "text": "la frase detta a voce in questa scena (breve: 6-22 parole)",
    "visual": "in INGLESE: cosa si vede nell'immagine (soggetto, azione, ambiente, luce, emozione). Nomina i personaggi con il loro nome. Niente testo scritto nell'immagine.",
    "characters": ["nomi dei personaggi che si vedono"],
    "shot": "in inglese: tipo di inquadratura (es. close-up, medium shot, wide shot, low angle)",
    "motion": "uno tra zoomIn, zoomOut, panL, panR, panU, panD",
    "importance": 1, 2 o 3 (3 = momento chiave con un'azione o un movimento che merita un vero video: apertura, colpo di scena, climax),
    "app": true SOLO se nella scena si vede lo schermo del telefono con l'app del prodotto (altrimenti false)}
 ]}"""


def _system(page, lang, fmt=None):
    ln = LANG_NAME.get(lang or page.get("lang") or "it", lang or "italiano")
    extra = ""
    if fmt and fmt.get("prompt"):
        extra = ("\n\nSEGUI QUESTO FORMATO (ricavato da video che funzionano; prendi la struttura, mai le frasi). "
                 "Se contrasta con la struttura generica qui sotto, vale il formato:\n" + fmt["prompt"][:9000] + "\n")
    return extra + (f"Sei lo sceneggiatore di video brevi verticali (TikTok, Reels, Shorts) per questa pagina social.\n{_bible(page)}\n\n"
            f"Scrivi in {ln} il testo parlato. Struttura: HOOK (la prima scena deve incuriosire subito) → contesto → sviluppo → "
            "escalation → climax → finale. Frasi naturali da dire a voce, senza ripetizioni, con ritmo. Distingui narrazione e dialoghi "
            "con lo speaker. Non inventare fatti, citazioni o fonti reali e non usare persone reali: se la storia sembra vera, "
            "mantienila chiaramente narrativa. Ogni scena dura 3-5 secondi.\n\n" + SCHEMA)


def _scenes_from(obj, page):
    names = {c["name"].lower(): c["name"] for c in page.get("characters") or []}
    out = []
    for i, s in enumerate(obj.get("scenes") or []):
        t = _clean_str(s.get("text"), 400).strip()
        if not t:
            continue
        sp = _clean_str(s.get("speaker"), 40).strip()
        sp = names.get(sp.lower(), "" if sp.upper() in ("NARRATORE", "NARRATOR", "") else sp)
        chars = [names[c.lower()] for c in (s.get("characters") or []) if isinstance(c, str) and c.lower() in names]
        mo = s.get("motion") if s.get("motion") in MOTIONS else MOTIONS[i % len(MOTIONS)]
        out.append({"id": "sc" + secrets.token_hex(4), "speaker": sp, "text": t, "visual": _clean_str(s.get("visual"), 1200),
                    "shot": _clean_str(s.get("shot"), 120), "characters": chars, "motion": mo, "locked": False,
                    "importance": max(1, min(3, int(s.get("importance") or 2))) if str(s.get("importance") or "2").isdigit() else 2, "kind": "image",
                    "app": bool(s.get("app") is True or str(s.get("app")).lower() == "true"),
                    "image": None, "audio": None, "error": None})
    if not out:
        raise ai.AIError("L'AI non ha scritto nessuna scena: riprova")
    return out


JSON_RETRY = ("\n\nIMPORTANTE: la risposta di prima non era JSON valido. Rispondi SOLO con il JSON, completo. "
              "Dentro le frasi non usare mai le virgolette doppie \": per i dialoghi usa « » oppure le virgolette singole.")


def _ask_json(cfg, system, user, cancel=None, max_tokens=12000):
    """Testo -> JSON; se il modello sbaglia il formato, riprova una volta chiedendo JSON pulito."""
    raw = ai.text(cfg, system, user, max_tokens=max_tokens, cancel=cancel)
    usd = ai.text_usd(cfg.get("model"), system, user, raw)
    try:
        obj = ai.parse_json(raw)
        obj["_usd"] = usd
        return obj
    except ai.AIError:
        print("[ai] JSON non valido, riprovo. Inizio risposta:", (raw or "")[:200].replace("\n", " "), flush=True)
    raw = ai.text(cfg, system, user + JSON_RETRY, max_tokens=max_tokens, cancel=cancel)
    obj = ai.parse_json(raw)
    obj["_usd"] = usd + ai.text_usd(cfg.get("model"), system, user, raw)
    return obj


def write_story(page, mode, topic, script, duration, lang, cancel=None, fmt=None):
    """Scrive la storia divisa in scene. mode: auto (sceglie l'AI) | topic (argomento dato) | script (testo gia' scritto).
    fmt: formato imparato da video di riferimento (struttura, ritmo, regole)."""
    from . import formats as FM
    cfg = pick(page, "text")
    per = (FM.scene_sec(fmt) if fmt else None) or 4
    n = max(4, min(60, round((duration or page.get("duration") or 60) / per)))
    if mode == "script":
        user = ("Dividi QUESTO script in scene senza cambiare le parole (puoi solo spezzare le frasi). Per ogni scena scrivi "
                f"visual, shot, characters e motion.\n\nSCRIPT:\n{script}")
    elif mode == "topic":
        user = f"Scrivi una storia originale di circa {duration} secondi (circa {n} scene) su questo argomento: {topic}"
    else:
        user = (f"Scegli tu un argomento nuovo, adatto alla pagina, e scrivi una storia originale di circa {duration} secondi "
                f"(circa {n} scene).")
    if fmt and mode == "script":
        user += f"\n\nDividi in scene di circa {per:.1f} secondi (come nel formato)."
    obj = _ask_json(cfg, _system(page, lang, fmt), user, cancel=cancel)
    return {"title": _clean_str(obj.get("title"), 120) or (topic or "Storia")[:60], "scenes": _scenes_from(obj, page), "cfg": cfg,
            "usd": obj.get("_usd", ai.PRICE["text"])}


def rewrite_scene(page, st, i, instruction, cancel=None):
    cfg = pick(page, "text")
    ctx = "\n".join(f"{k + 1}. {(s.get('speaker') or 'NARRATORE')}: {s['text']}" for k, s in enumerate(st["scenes"]))
    user = (f"Questa è la storia attuale:\n{ctx}\n\nRiscrivi SOLO la scena {i + 1}" + (f" seguendo questa indicazione: {instruction}" if instruction else
            " rendendola più forte") + ". Rispondi con lo stesso JSON ma con una sola scena in \"scenes\".")
    obj = _ask_json(cfg, _system(page, st.get("lang"), _story_fmt(st)), user, cancel=cancel)
    sc = _scenes_from(obj, page)[0]
    return sc, cfg


def refresh_visuals(page, st, cancel=None):
    """Dopo aver cambiato il testo a mano: nuove descrizioni delle immagini per le scene non bloccate."""
    cfg = pick(page, "text")
    ctx = "\n".join(f"{k + 1}. {(s.get('speaker') or 'NARRATORE')}: {s['text']}" for k, s in enumerate(st["scenes"]))
    user = ("Per OGNUNA di queste scene (stesso numero e stesso testo, non cambiarlo) scrivi visual, shot, characters e motion. "
            f"Rispondi con il JSON, una scena per riga dello script, nello stesso ordine.\n\n{ctx}")
    obj = _ask_json(cfg, _system(page, st.get("lang"), _story_fmt(st)), user, cancel=cancel)
    return obj.get("scenes") or [], cfg


def _story_fmt(st):
    if not st.get("format"):
        return None
    try:
        from . import formats as FM
        return FM.get(st["format"])
    except Exception:
        return None


def image_prompt(page, sc):
    style = ((page.get("style") or {}).get("prompt") or "").strip()
    chars = [c for c in page.get("characters") or [] if c["name"] in (sc.get("characters") or [])]
    parts = []
    if style:
        parts.append(style.rstrip(".") + ".")
    parts.append((sc.get("visual") or sc.get("text") or "").strip().rstrip(".") + ".")
    if sc.get("shot"):
        parts.append(sc["shot"].strip().rstrip(".") + ".")
    for c in chars:
        if c.get("look"):
            parts.append(f"{c['name']} looks exactly like this: {c['look'].strip().rstrip('.')}.")
    who = (sc.get("speaker") or "").strip()
    if sc.get("kind") == "talk":
        parts.append(f"{who or 'The speaking character'} is talking, facing the camera, face and mouth clearly visible, medium close-up.")
    crefs = [r for c in chars for r in (c.get("refs") or [])]
    screens = [x for x in page.get("screens") or [] if os.path.isfile(x)] if sc.get("app") else []
    if screens:
        parts.append("A smartphone is clearly visible with its screen facing the camera. The phone screen shows EXACTLY the app interface "
                     "from the app screenshot reference image (same layout, colors, icons and text), sharp and undistorted.")
        parts.append("Vertical 9:16 composition. Keep the same characters, faces and outfits as the character reference images. "
                     "No captions, no watermark: the only text allowed is the app interface on the phone screen.")
        return " ".join(parts), (screens[:2] + crefs)[:4]
    parts.append("Vertical 9:16 composition. Keep the same characters, faces and outfits as the reference images. "
                 "No text, no letters, no captions, no watermark, no logos.")
    return " ".join(parts), crefs[:4]


NARRATOR_NAMES = ("", "narratore", "narrator", "voce narrante", "voce fuori campo")


def speaker_key(sp):
    return str(sp or "").strip().lower()


# voci standard di ElevenLabs (disponibili su ogni account): il narratore ha la sua, gli altri personaggi si alternano
EL_DEFAULT_NARRATOR = "JBFqnCBsd6RMkjVDRZzb"   # George
EL_DEFAULT_CAST = ["EXAVITQu4vr4xnSDxMaL", "pNInz6obpgDQGcFmaJgB", "XB0fDUnXU5powFXDhCwa", "TX3LPaxmHKxFdv7VOQHJ", "21m00Tcm4TlvDq8ikWAM"]


def default_voice(who):
    k = speaker_key(who or "")
    if not k or k in NARRATOR_NAMES:
        return EL_DEFAULT_NARRATOR
    import zlib
    return EL_DEFAULT_CAST[zlib.crc32(k.encode("utf-8")) % len(EL_DEFAULT_CAST)]


def voice_for(page, sc, cast=None):
    """La voce di una battuta: prima la scelta fatta nella storia ("chi parla"), poi il personaggio con lo stesso
    nome, poi il narratore della pagina."""
    k = speaker_key(sc.get("speaker")) or "narratore"
    m = (cast or {}).get(k) or {}
    chars = page.get("characters") or []
    if m.get("voice", {}).get("id"):
        return m["voice"]["id"]
    if m.get("char"):
        c = next((c for c in chars if c.get("id") == m["char"]), None)
        if c and (c.get("voice") or {}).get("id"):
            return c["voice"]["id"]
    if not m.get("narrator") and k not in NARRATOR_NAMES:
        c = next((c for c in chars if (c.get("name") or "").strip().lower() == k), None)
        if c and (c.get("voice") or {}).get("id"):
            return c["voice"]["id"]
    return (page.get("narrator") or {}).get("id") or ""


def set_cast(sid, cast):
    """Chi parla nella storia: {"ragazza": {"char": id} | {"voice": {id, name}} | {"narrator": true}}."""
    out = {}
    for k, v in (cast or {}).items() if isinstance(cast, dict) else []:
        k = speaker_key(k)[:40]
        if not isinstance(v, dict):
            continue
        if v.get("narrator"):
            out[k] = {"narrator": True}
        elif v.get("char"):
            out[k] = {"char": _clean_str(v["char"], 40)}
        elif isinstance(v.get("voice"), dict) and v["voice"].get("id"):
            out[k] = {"voice": {"id": _clean_str(v["voice"]["id"], 120), "name": _clean_str(v["voice"].get("name"), 120)}}
    with _lock(sid):
        st = get_story(sid)
        try:
            page = get_page(st["page"])
        except Exception:
            page = {}
        st["cast"] = out
        for sc in st.get("scenes") or []:        # voce cambiata: la battuta va rifatta (lo vede anche l'interfaccia)
            a = sc.get("audio") or {}
            if a.get("file"):
                a["stale"] = a.get("voice") != voice_for(page, sc, out)
        save_story(st)
    return st


# ------------------------------------------------------------------ produzione (immagini e voci in parallelo)
# cosa si sta creando adesso, scena per scena (per mostrarlo sulle schede): {storia: {scena: {what, state, since}}}
WORKING = {}
_WLOCK = threading.Lock()


def working(sid):
    with _WLOCK:
        return {k: dict(v) for k, v in (WORKING.get(sid) or {}).items()}


def _w_set(sid, scid, **kw):
    with _WLOCK:
        e = WORKING.setdefault(sid, {}).setdefault(scid, {})
        e.update(kw)


def _w_del(sid, scid):
    with _WLOCK:
        (WORKING.get(sid) or {}).pop(scid, None)


def _run_tracked(sid, scenes, what, fn, todo, workers):
    """Esegue fn(i) sulle scene, tenendo aggiornato lo stato di ognuna: in attesa -> inviata -> in coda / in creazione."""
    for i in todo:
        _w_set(sid, scenes[i]["id"], what=what, state="wait", since=time.time())

    def run(i):
        scid = scenes[i]["id"]
        _w_set(sid, scid, state="sent", since=time.time())
        ai._TL.cb = lambda s_: _w_set(sid, scid, state={"IN_QUEUE": "queue", "IN_PROGRESS": "progress"}.get(s_, "progress"))
        try:
            return fn(i)
        finally:
            ai._TL.cb = None
            _w_del(sid, scid)
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(run, todo))
    finally:
        for i in todo:
            _w_del(sid, scenes[i]["id"])


def gen_images(sid, only=None, progress=None, cancel=None, workers=3):
    """Crea le immagini che mancano (o quelle scelte). Le scene bloccate non si toccano."""
    with _lock(sid):
        st = get_story(sid)
        page = get_page(st["page"])
    cfg = pick(page, "image")
    todo = [i for i, s in enumerate(st["scenes"]) if not s.get("locked") and
            ((only is None and not (s.get("image") or {}).get("file") and not joined(st["scenes"], i)) or (only is not None and i in only))]
    if not todo:
        return {"done": 0, "errors": 0}
    d = os.path.join(_story_dir(sid), "immagini")
    os.makedirs(d, exist_ok=True)
    done = [0]
    errors = []
    halt = [False]   # credito finito: inutile continuare con le altre scene

    def one(i):
        if (cancel and cancel()) or halt[0]:
            return
        sc = st["scenes"][i]
        prompt, refs = image_prompt(page, sc)
        try:
            b, ext = ai.image(cfg, prompt, refs, "9:16", cancel=cancel)
            path = os.path.join(d, f"{i + 1:02d}_{sc['id']}_{secrets.token_hex(2)}{ext}")
            with open(path, "wb") as f:
                f.write(b)
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    old = (s2.get("image") or {}).get("file")
                    s2["image"] = {"file": path, "prompt": prompt, "provider": cfg["provider"], "model": cfg["model"], "at": time.time()}
                    s2["error"] = None
                    _cost(cur, "image", cfg["provider"], cfg["model"], ai.image_price(cfg["provider"], cfg["model"]), 1)
                    save_story(cur)
                    if old and old != path and os.path.dirname(old) == d:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
        except ai.AIError as e:
            errors.append(str(e))
            if "credito" in str(e) or "crediti" in str(e) or "bloccato" in str(e):
                halt[0] = True
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    s2["error"] = str(e)
                    save_story(cur)
        done[0] += 1
        if progress:
            progress(done[0] / len(todo), f"Immagini {done[0]} / {len(todo)}")

    _run_tracked(sid, st["scenes"], "image", one, todo, workers)
    if errors and len(errors) == len(todo):
        raise ai.AIError(errors[0])
    return {"done": len(todo) - len(errors), "errors": len(errors), "first": errors[0] if errors else None}


def gen_voices(sid, only=None, progress=None, cancel=None, workers=2):
    with _lock(sid):
        st = get_story(sid)
        page = get_page(st["page"])
    cfg = pick(page, "voice")
    vs = page.get("voiceCfg") or {}
    todo = []
    for i, s in enumerate(st["scenes"]):
        a = s.get("audio") or {}
        want = voice_for(page, s, st.get("cast")) or (default_voice(s.get("speaker")) if cfg["provider"] == "elevenlabs" else None)
        stale = a.get("file") and (a.get("text") != s["text"] or (a.get("voice") or None) != (want or None))
        if s.get("locked") and a.get("file"):
            continue
        if (only is None and (not a.get("file") or stale)) or (only is not None and i in only):
            todo.append(i)
    if not todo:
        return {"done": 0, "errors": 0}
    d = os.path.join(_story_dir(sid), "voci")
    os.makedirs(d, exist_ok=True)
    done = [0]
    errors = []
    halt = [False]   # credito finito: inutile continuare con le altre scene

    def one(i):
        if (cancel and cancel()) or halt[0]:
            return
        sc = st["scenes"][i]
        vid = voice_for(page, sc, st.get("cast"))
        try:
            if not vid and cfg["provider"] == "elevenlabs":
                # nessuna voce scelta: invece di fermarsi si usa una voce standard di ElevenLabs (la si cambia quando si vuole)
                who = (sc.get("speaker") or "").strip()
                vid = default_voice(who)
            b, words = ai.speech(cfg, sc["text"], vid or "alloy", vs, st.get("lang") or page.get("lang"), cancel=cancel)
            path = os.path.join(d, f"{i + 1:02d}_{sc['id']}_{secrets.token_hex(2)}.mp3")
            with open(path, "wb") as f:
                f.write(b)
            dur = probe(path)["duration"]
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    old = (s2.get("audio") or {}).get("file")
                    s2["audio"] = {"file": path, "dur": round(dur, 3), "words": words, "text": sc["text"], "voice": vid,
                                   "provider": cfg["provider"], "model": cfg["model"], "at": time.time()}
                    s2["error"] = None
                    _cost(cur, "voice", cfg["provider"], cfg["model"], len(sc["text"]) * ai.PRICE["voice_char"].get(cfg["provider"], 0.0002), len(sc["text"]))
                    save_story(cur)
                    if old and old != path and os.path.dirname(old) == d:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
        except ai.AIError as e:
            errors.append(str(e))
            if "credito" in str(e) or "crediti" in str(e) or "bloccato" in str(e):
                halt[0] = True
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    s2["error"] = str(e)
                    save_story(cur)
        done[0] += 1
        if progress:
            progress(done[0] / len(todo), f"Voci {done[0]} / {len(todo)}")

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(one, todo))
    if errors and len(errors) == len(todo):
        raise ai.AIError(errors[0])
    return {"done": len(todo) - len(errors), "errors": len(errors), "first": errors[0] if errors else None}


def gen_videos(sid, only=None, progress=None, cancel=None, workers=2):
    """Clip video AI per le scene scelte (dall'immagine gia' approvata). Durata: 5 o 10 secondi secondo la frase."""
    with _lock(sid):
        st = get_story(sid)
        page = get_page(st["page"])
    cfg = pick(page, "video")
    sdurs = scene_durations(st)
    durs = group_durations(st, sdurs)      # una clip copre tutte le battute unite a lei
    scs = st["scenes"]
    own = st.get("ownVoice") or {}
    own_times = own.get("times") if own.get("file") and len(own.get("times") or []) == len(scs) else None
    todo = [i for i, s in enumerate(scs) if s.get("kind") in AI_KINDS and (s.get("image") or {}).get("file") and not joined(scs, i)
            and ((only is None and not _video_ok(s, st) and not (s.get("locked") and (s.get("video") or {}).get("file")))
                 or (only is not None and i in only))]
    if not todo:
        return {"done": 0, "errors": 0}
    d = os.path.join(_story_dir(sid), "video")
    os.makedirs(d, exist_ok=True)
    done = [0]
    errors = []
    halt = [False]   # credito finito: inutile continuare con le altre scene

    def talk_audio(i, sc):
        """Le battute da far dire nella clip: le loro voci + le pause (la clip copre tutte le battute unite)."""
        g = group_of(scs, i)
        if own_times:
            src, ss, ln = own["file"], float(own_times[g[0]][0]), max(0.5, float(own_times[g[-1]][1]) - float(own_times[g[0]][0]))
        else:
            for k in g:
                a = scs[k].get("audio") or {}
                if not (a.get("file") and os.path.isfile(a["file"]) and a.get("text") == scs[k].get("text")):
                    raise ai.AIError("Per far parlare il personaggio serve prima la sua voce: creala nel passaggio Voce")
            if len(g) == 1:
                src, ss, ln = scs[i]["audio"]["file"], 0.0, durs[i]
            else:   # piu' battute: le voci in fila, ognuna con la sua pausa
                src = os.path.join(d, f"gruppo_{sc['id']}.wav")
                cmd = [ffmpeg_bin(), "-y", "-v", "error"]
                for k in g:
                    cmd += ["-i", scs[k]["audio"]["file"]]
                filt = "".join(f"[{n}:a]aresample=44100,aformat=sample_fmts=s16:channel_layouts=mono,apad=whole_dur={sdurs[k]:.4f},atrim=end={sdurs[k]:.4f},asetpts=N/SR/TB[a{n}];"
                               for n, k in enumerate(g))
                filt += "".join(f"[a{n}]" for n in range(len(g))) + f"concat=n={len(g)}:v=0:a=1[out]"
                r = subprocess.run(cmd + ["-filter_complex", filt, "-map", "[out]", "-c:a", "pcm_s16le", src], capture_output=True, creationflags=NO_WINDOW)
                if r.returncode != 0:
                    raise ai.AIError("Non riesco a unire le voci della clip: " + r.stderr.decode(errors="ignore")[-200:])
                ss, ln = 0.0, durs[i]
        out = os.path.join(d, f"parla_{sc['id']}.mp3")
        cmd = [ffmpeg_bin(), "-y", "-v", "error", "-ss", f"{ss:.3f}", "-i", src, "-af", f"apad=whole_dur={ln:.3f},atrim=end={ln:.3f}",
               "-ac", "1", "-ar", "44100", "-c:a", "libmp3lame", "-b:a", "128k", out]
        r = subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW)
        if r.returncode != 0:
            raise ai.AIError("Non riesco a preparare la voce della scena: " + r.stderr.decode(errors="ignore")[-200:])
        return out, src, ln

    tcfg = dict(cfg, talkModel=ai.talk_model((page.get("videoCfg") or {}).get("talkModel") or ""))

    def one(i):
        if (cancel and cancel()) or halt[0]:
            return
        sc = st["scenes"][i]
        img = sc["image"]["file"]
        if sc.get("kind") == "talk" and sc.get("lip"):
            return one_talk(i, sc, img)
        mot = {"zoomIn": "slow push-in camera", "zoomOut": "slow pull-back camera", "panL": "slow pan to the left", "panR": "slow pan to the right",
               "panU": "slow tilt up", "panD": "slow tilt down"}.get(sc.get("motion"), "subtle camera movement")
        who = (sc.get("speaker") or "").strip()
        g = group_of(scs, i)
        talkers = []
        for k in g:
            w = (scs[k].get("speaker") or "").strip()
            if is_dialog(scs[k]) and w and w not in talkers:
                talkers.append(w)
        if sc.get("kind") == "talk" and len(talkers) > 1:
            # piu' battute di personaggi diversi nella stessa clip: parlano a turno
            names = ", ".join(talkers[:-1]) + " and " + talkers[-1]
            say = (f"{names} are having a conversation, taking turns: when one of them talks the mouth and lips move clearly, "
                   "the others listen with the mouth closed and react naturally. Natural facial expressions and small head movements.")
        elif sc.get("kind") == "talk" and (talkers or is_dialog(sc)):
            who = talkers[0] if talkers else who
            # bocca che si muove (senza lip sync): parla solo chi dice la battuta, poi si doppia con la voce
            say = (f"{who} is speaking to someone: {who}'s mouth and lips move continuously and clearly as if talking, "
                   "natural facial expressions and small head movements while speaking. "
                   f"Only {who} talks: every other character keeps the mouth closed and listens.")
        else:
            # narratore (voce fuori campo) o nessuno che parla: nessuna bocca si muove
            say = "Nobody is speaking: every character keeps the mouth closed, no talking, no lip movement."
        vis = (sc.get('visual') or sc.get('text') or '').strip().rstrip('.')
        more = [(scs[k].get("visual") or "").strip().rstrip(".") for k in g[1:] if (scs[k].get("visual") or "").strip()]
        if more:   # la clip continua: quello che succede dopo, nella stessa inquadratura
            vis += ". Then, in the same shot: " + ". Then: ".join(more[:3])
        prompt = f"{vis}. {say} {mot}, natural realistic motion, cinematic, consistent faces. {ai.NO_TEXT}"
        scfg = dict(cfg, model=scene_model(sc, cfg.get("model")))
        try:
            b, sec = ai.video(scfg, img, prompt, durs[i], cancel=cancel)
            path = os.path.join(d, f"{i + 1:02d}_{sc['id']}_{secrets.token_hex(2)}.mp4")
            with open(path, "wb") as f:
                f.write(b)
            try:
                vdur = probe(path)["duration"]
            except Exception:
                vdur = float(sec)
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    old = (s2.get("video") or {}).get("file")
                    s2["video"] = {"file": path, "dur": round(vdur, 3), "image": img, "provider": scfg["provider"], "model": scfg["model"], "at": time.time(),
                                   "group": [scs[k]["id"] for k in g]}
                    if sc.get("kind") == "talk":
                        s2["video"]["talk"] = {"mode": "mouth", "text": group_text(scs, i)}
                    s2["error"] = None
                    _cost(cur, "talk" if sc.get("kind") == "talk" else "video", scfg["provider"], scfg["model"], ai.video_clip(scfg["model"], durs[i])[1], sec)
                    save_story(cur)
                    if old and old != path and os.path.dirname(old) == d:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
        except ai.AIError as e:
            errors.append(str(e))
            if "credito" in str(e) or "crediti" in str(e) or "bloccato" in str(e):
                halt[0] = True
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    s2["error"] = str(e)
                    save_story(cur)
        done[0] += 1
        if progress:
            progress(done[0] / len(todo), f"Video {done[0]} / {len(todo)}")

    def one_talk(i, sc, img):
        m = ai.talk_model(sc.get("talkModel") or tcfg["talkModel"])
        who = (sc.get("speaker") or "").strip()
        # la battuta NON va nel prompt: alcuni modelli la scrivono sul video come sottotitolo (lettere a caso)
        prompt = (f"{who + ' is' if who else 'The character is'} talking naturally, with natural lip sync, natural facial expressions "
                  "and subtle head and body movement. Keep the same face, clothes and background. " + ai.NO_TEXT)
        try:
            apath, src, ln = talk_audio(i, sc)
            b = ai.talk_video(dict(tcfg, talkModel=m), img, apath, prompt, cancel=cancel)
            path = os.path.join(d, f"{i + 1:02d}_{sc['id']}_parla_{secrets.token_hex(2)}.mp4")
            with open(path, "wb") as f:
                f.write(b)
            try:
                vdur = probe(path)["duration"]
            except Exception:
                vdur = ln
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    old = (s2.get("video") or {}).get("file")
                    s2["video"] = {"file": path, "dur": round(vdur, 3), "image": img, "provider": "fal", "model": m, "at": time.time(),
                                   "group": [scs[k]["id"] for k in group_of(scs, i)],
                                   "talk": {"mode": "lip", "audio": (sc.get("audio") or {}).get("file"), "text": group_text(scs, i), "len": round(ln, 3)}}
                    s2["error"] = None
                    _cost(cur, "talk", "fal", m, ai.talk_cost(m, ln), round(ln, 2))
                    save_story(cur)
                    if old and old != path and os.path.dirname(old) == d:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
        except ai.AIError as e:
            errors.append(str(e))
            if "credito" in str(e) or "crediti" in str(e) or "bloccato" in str(e):
                halt[0] = True
            with _lock(sid):
                cur = get_story(sid)
                s2 = next((x for x in cur["scenes"] if x["id"] == sc["id"]), None)
                if s2 is not None:
                    s2["error"] = str(e)
                    save_story(cur)
        done[0] += 1
        if progress:
            progress(done[0] / len(todo), f"Video {done[0]} / {len(todo)}")

    _run_tracked(sid, st["scenes"], "video", one, todo, workers)
    if errors and len(errors) == len(todo):
        raise ai.AIError(errors[0])
    return {"done": len(todo) - len(errors), "errors": len(errors), "first": errors[0] if errors else None}


def join_voices(st, gap=None):
    """Una sola traccia voce dalle battute, con i tempi esatti di ogni scena e di ogni parola.
    Dopo ogni battuta una pausa (automatica o scelta nella scena): niente tagli netti dove serve respiro."""
    sc = st["scenes"]
    gaps = [gap if gap is not None else pause_after(sc, k) for k in range(len(sc))]
    if not all((s.get("audio") or {}).get("file") and os.path.isfile(s["audio"]["file"]) for s in sc):
        return None
    d = _story_dir(st["id"])
    out = os.path.join(d, "voce_completa.wav")
    cmd = [ffmpeg_bin(), "-y", "-v", "error"]
    for s in sc:
        cmd += ["-i", s["audio"]["file"]]
    # ogni battuta lunga ESATTAMENTE quanto dicono i tempi (voce + pausa): gli mp3 decodificati sono qualche
    # centesimo piu' corti della durata dichiarata e, sommati su 30 battute, voce e scene/sottotitoli si sfasavano
    lens = [float(s["audio"].get("dur") or probe(s["audio"]["file"])["duration"]) + gaps[k] for k, s in enumerate(sc)]
    filt = "".join(f"[{k}:a]aresample=44100,aformat=sample_fmts=s16:channel_layouts=mono,apad=whole_dur={lens[k]:.4f},atrim=end={lens[k]:.4f},asetpts=N/SR/TB[a{k}];"
                   for k in range(len(sc)))
    filt += "".join(f"[a{k}]" for k in range(len(sc))) + f"concat=n={len(sc)}:v=0:a=1[out]"
    cmd += ["-filter_complex", filt, "-map", "[out]", "-c:a", "pcm_s16le", out]
    r = subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW)
    if r.returncode != 0:
        raise RuntimeError("Non riesco a unire le voci: " + r.stderr.decode(errors="ignore")[-300:])
    times, words, t = [], [], 0.0
    have_words = True
    for k, s in enumerate(sc):
        dur = float(s["audio"].get("dur") or probe(s["audio"]["file"])["duration"])
        seg = dur + gaps[k]
        times.append([round(t, 3), round(t + seg, 3)])
        ws = s["audio"].get("words")
        if ws:
            words += [[w, round(a + t, 3), round(b + t, 3)] for w, a, b in ws]
        else:
            have_words = False
        t += seg
    return {"voice": out, "times": times, "words": words if have_words else None, "dur": round(t, 3)}
