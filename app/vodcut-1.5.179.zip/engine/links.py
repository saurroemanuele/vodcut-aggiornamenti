"""Link incollati a mano: prima di scaricare li rimette a posto come fa il browser, e traduce gli errori del
download in frasi che si capiscono.

Esempi di link che arrivano davvero: "www.youtube.com\\watch?v=…" (barra rovesciata), "https:/www…",
"youtube.com/watch?v=…&list=…&t=12s", testo intorno al link ("guarda qui https://…"), il percorso di un file
del computer incollato nel campo del link. Il link giusto per YouTube, Twitch e Kick e' lo stesso che usa il sito.
"""
import os
import re
from urllib.parse import parse_qs, urlsplit, urlunsplit

class LinkError(RuntimeError):
    """Errore gia' scritto per chi usa l'app. detail: l'errore tecnico (per il log e per il sito)."""

    def __init__(self, msg, detail=None):
        super().__init__(msg)
        self.detail = detail


# "https", "htps", "ttps", "https:/", "https//"… davanti al link
_HTTPS = {"https", "htps", "ttps", "htttps", "hhttps", "httsp", "htpps", "httpss", "hhtps"}
_HTTP = {"http", "htp", "ttp", "htttp", "hhttp"}
_JUNK = "\u200b\u200c\u200d\u200e\u200f\u2060\ufeff"

PROBLEMS = {
    "empty": "Incolla il link del video.",
    "notlink": "Questo non sembra un link: copialo dalla barra degli indirizzi del browser e incollalo qui.",
    "channel": "Questo link porta al canale, non a un video: apri il video o la live che vuoi e copia il suo link.",
    "playlist": "Questo link è un canale o una playlist: apri il video che vuoi e copia il suo link.",
    "nofile": "Non trovo questo file sul computer: controlla il percorso, oppure usa «Scegli un file».",
}


def is_local(s):
    """Percorso di un file del computer (C:\\…, \\\\server\\…, file:///…, /Users/…), non un link."""
    s = str(s or "").strip().strip('"').strip("'")
    return bool(re.match(r"^(?:[A-Za-z]:[\\/]|\\\\[^\\]|file:/|~[\\/]|/(?:Users|home|Volumes|mnt|media|tmp|private)/)", s))


def local_path(s):
    s = str(s or "").strip().strip('"').strip("'")
    if s.lower().startswith("file:"):
        from urllib.request import url2pathname
        s = url2pathname(urlsplit(s).path)
        if re.match(r"^/[A-Za-z]:", s):      # file:///C:/… letto fuori da Windows
            s = s[1:]
    return os.path.expanduser(s)


def _pick(s):
    """Il pezzo che e' il link, se intorno c'e' altro testo."""
    m = re.search(r"(?<![A-Za-z])h?t?tps?:?[/\\]{1,3}[^\s<>\"'`]+", s, re.I)
    if m:
        return m.group(0)
    for tok in re.split(r"\s+", s):
        if re.search(r"[A-Za-z0-9\-]\.[A-Za-z]{2,}(?::\d+)?(?:[/\\?#]|$)", tok):
            return tok
    return s


def normalize(raw):
    """(link, problema). problema: None se il link va bene, "local" se e' il percorso di un file del computer
    (il link e' allora il percorso), altrimenti la frase da mostrare."""
    s = str(raw or "")
    for ch in _JUNK:
        s = s.replace(ch, "")
    s = s.replace("\u00a0", " ").strip()
    if not s:
        return "", PROBLEMS["empty"]
    if is_local(s):
        return local_path(s), "local"
    s = _pick(s).strip("<>[](){}\"'`“”‘’«»")
    s = s.rstrip(".,;:!?")
    # la barra rovesciata nei link e' una barra normale (lo fa anche il browser)
    s = s.replace("\\", "/")
    m = re.match(r"^([A-Za-z]{3,7})(:?/*|:)", s)
    if m and m.group(2):
        sch = m.group(1).lower()
        if sch in _HTTPS or sch in _HTTP:
            s = ("https://" if sch in _HTTPS else "http://") + s[m.end():].lstrip("/")
    if not re.match(r"^[A-Za-z][A-Za-z0-9+.\-]*://", s):
        s = "https://" + s.lstrip("/")
    try:
        u = urlsplit(s)
    except ValueError:
        return s, PROBLEMS["notlink"]
    host = (u.hostname or "").lower().rstrip(".")
    if u.scheme.lower() not in ("http", "https") or not host or " " in s or "." not in host:
        return s, PROBLEMS["notlink"]
    netloc = u.netloc.split("@")[-1].lower().rstrip(".")
    s = urlunsplit((u.scheme.lower(), netloc, u.path or "/", u.query, u.fragment))
    canon, prob = _known(host, u)
    return (canon or s), prob


def _known(host, u):
    """Link giusto per YouTube, Twitch e Kick (come sul sito). (link o None, problema o None)."""
    h = re.sub(r"^(?:www|m|mobile|go)\.", "", host)
    p = re.sub(r"/+$", "", u.path or "")
    q = parse_qs(u.query or "")
    if h in ("youtube.com", "music.youtube.com", "youtube-nocookie.com", "gaming.youtube.com"):
        v = (q.get("v") or [""])[0]
        m = re.match(r"^/(?:live|shorts|embed|v|e)/([\w\-]{11})$", p)
        vid = v if re.fullmatch(r"[\w\-]{11}", v or "") else (m.group(1) if m else None)
        if vid:
            return "https://www.youtube.com/watch?v=" + vid, None
        if re.match(r"^/(?:@[^/]+|channel/[\w\-]+|c/[^/]+|user/[^/]+)(?:/(?:videos|streams|featured|shorts|live)?)?$", p) and not p.endswith("/live"):
            return None, PROBLEMS["channel"]
        return None, None
    if h == "youtu.be":
        m = re.match(r"^/([\w\-]{11})$", p)
        return ("https://www.youtube.com/watch?v=" + m.group(1), None) if m else (None, None)
    if h in ("twitch.tv", "player.twitch.tv"):
        m = re.match(r"^/(?:\w{2,30}/)?(?:videos?|v)/(\d{5,14})$", p)
        vid = m.group(1) if m else None
        if not vid and h == "player.twitch.tv":
            vv = re.sub(r"^v", "", (q.get("video") or [""])[0])
            vid = vv if re.fullmatch(r"\d{5,14}", vv) else None
        if vid:
            return "https://www.twitch.tv/videos/" + vid, None
        if h == "twitch.tv" and re.match(r"^/\w{2,30}(?:/(?:videos|about|schedule|home))?$", p) and "/clip/" not in p:
            return None, PROBLEMS["channel"]
        return None, None
    if h == "kick.com":
        m = re.match(r"^/([A-Za-z0-9_\-]{2,30})/videos/([0-9a-fA-F\-]{8,40})$", p)
        if m:
            return f"https://kick.com/{m.group(1)}/videos/{m.group(2)}", None
        if re.match(r"^/[A-Za-z0-9_\-]{2,30}(?:/videos)?$", p) and not q.get("clip"):
            return None, PROBLEMS["channel"]
    return None, None


# ------------------------------------------------------------------ errori del download
def problem(err):
    """Frase per chi scarica, dall'errore di yt-dlp (o della rete). None se non lo riconosco."""
    s = str(err or "")
    low = s.lower()

    def has(*ks):
        return any(k in low for k in ks)
    if has("no space left", "errno 28", "not enough space", "spazio insufficiente"):
        return "Il disco è pieno: libera un po' di spazio e riprova."
    if "ffmpeg" in low and has("not found", "not installed", "could not find"):
        return "Per unire audio e video serve ffmpeg e non lo trovo: reinstalla NoonFrame dal sito e riprova."
    if has("getaddrinfo", "name or service not known", "nodename nor servname", "temporary failure in name resolution",
           "no address associated", "failed to resolve", "errno 11001", "errno 11002", "errno -2]", "errno -3]",
           "name resolution", "could not resolve host", "proxyerror", "tunnel connection failed", "connect tunnel failed",
           "unable to connect to proxy", "could not resolve proxy"):
        return ("Non riesco a raggiungere il sito: controlla che il computer sia connesso a internet "
                "(a volte lo blocca una VPN o un antivirus) e riprova.")
    if has("certificate verify failed", "certificate_verify_failed", "ssl: ", "sslerror", "ssl error", "_ssl.c",
           "eof occurred in violation of protocol", "ssl connect error", "ssl certificate problem"):
        return ("La connessione sicura al sito non è riuscita: di solito è un antivirus che controlla le pagine web, "
                "oppure l'ora del computer è sbagliata. Controlla e riprova.")
    if has("timed out", "timeout", "connection refused", "connection reset", "connection aborted", "remote end closed",
           "network is unreachable", "errno 10060", "errno 10061", "errno 10054", "errno 10065", "errno 101]",
           "errno 110]", "errno 111]", "errno 113]", "incompleteread", "connection broken", "failed to connect",
           "recv failure", "send failure"):
        return "Il sito non risponde o la connessione si è interrotta: controlla internet e riprova tra poco."
    if has("is not a valid url"):
        return PROBLEMS["notlink"]
    if has("unsupported url"):
        return ("Da questo link non si scarica un video: usa il link della pagina del video (YouTube, Twitch, Kick, TikTok…), "
                "oppure scaricalo e trascinalo qui.")
    if has("confirm your age", "age-restricted", "age restricted", "inappropriate for some users"):
        return "YouTube chiede di confermare l'età per questo video: scaricalo dal browser e trascinalo qui."
    if has("not a bot", "sign in to confirm"):
        return "YouTube chiede di confermare che non sei un bot: riprova tra qualche minuto, oppure scarica il video e trascinalo qui."
    if has("private video", "video is private", "is private", "members-only", "members only", "join this channel",
           "subscriber-only", "subscribers-only", "subscriber only", "subscribers only", "only for subscribers", "sub-only",
           "only available for registered users", "requires authentication", "login required", "log in to", "sign in to view"):
        return "Questo video è privato o riservato agli abbonati: se è tuo rendilo visibile a tutti, oppure scaricalo e trascinalo qui."
    if has("available in your country", "geo restrict", "geo-restrict", "not available from your location", "blocked it in your country"):
        return "Questo video non si può guardare dal tuo paese: scaricalo in un altro modo e trascinalo qui."
    if has("live event will begin", "premieres in", "is_upcoming", "this live event", "not started yet"):
        return "La live non è ancora iniziata: riprova quando è finita e il video è disponibile."
    if has("not currently live", "is offline", "channel is not live"):
        return PROBLEMS["channel"]
    if has("http error 429", "too many requests"):
        return "Il sito sta limitando i download: riprova tra qualche minuto."
    if has("http error 404", "404: not found", "video unavailable", "video is unavailable", "does not exist",
           "has been removed", "no longer available", "this video is not available", "not found"):
        return "Non trovo questo video: controlla il link (deve essere il video o il VOD, non la pagina del canale)."
    if has("http error 403", "403: forbidden", "forbidden"):
        return "Il sito non ha lasciato scaricare questo video: riprova tra poco, oppure scaricalo e trascinalo qui."
    if has("requested format is not available", "no video formats found"):
        return "Non trovo un video scaricabile a questo link: controlla che sia la pagina del video, oppure scaricalo e trascinalo qui."
    return None


def tidy(err):
    """Errore che non riconosco: senza "ERROR: [sito] id:" davanti, che non dice niente a chi legge."""
    s = str(err or "").strip()
    s = re.sub(r"^(?:ERROR:\s*)?(?:\[[\w:\-]+\]\s*[^:]{0,120}:\s*)?", "", s).strip()
    s = s.split("\n")[0].strip()
    # via i consigli per chi usa yt-dlp da terminale e i pezzi tecnici tra parentesi
    s = re.split(r"\s*\(caused by |\s*See https?://|;\s*please report this issue|\s+Confirm you are on the latest version|"
                 r"\s+Use --|\s+Set --", s)[0].strip().rstrip(".,;:") or s
    if len(s) > 200:
        s = s[:200].rsplit(" ", 1)[0] + "…"
    return ("Download non riuscito: " + s) if s else "Download non riuscito"
