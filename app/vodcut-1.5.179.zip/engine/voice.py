"""Chi parla, a orecchio: l'impronta della voce (speaker embedding) di un pezzo di parlato.

Serve alla regia delle clip con piu' persone: la rete che guarda le bocche a volte sbaglia (persona di profilo, chi
mangia o sorride mentre parla un altro). Due pezzi con la stessa voce sono la stessa persona: se la regia li dava a due
persone diverse, li' non si va a tutto schermo su nessuno.

Modello: WeSpeaker ResNet34-LM addestrato su VoxCeleb (CC BY 4.0, https://github.com/wenet-e2e/wespeaker), ONNX,
~26 MB, scaricato la prima volta dal nostro repo (o dall'originale).
Le caratteristiche (fbank 80, come Kaldi) sono calcolate qui con numpy.
"""
import os
import threading

import numpy as np

MODEL_URLS = ["https://raw.githubusercontent.com/saurroemanuele/vodcut-aggiornamenti/main/modelli/voce_wespeaker_resnet34.onnx",
              "https://github.com/k2-fsa/sherpa-onnx/releases/download/speaker-recongition-models/wespeaker_en_voxceleb_resnet34_LM.onnx"]
MODEL_NAME = "wespeaker_resnet34_LM.onnx"
MODEL_BYTES = 26530550
SR = 16000

_LOCK = threading.Lock()
_SESS = {"s": None, "failed": False}


def model_path():
    from .util import APP_DIR
    return os.path.join(APP_DIR, "modelli", MODEL_NAME)


def available():
    try:
        import onnxruntime  # noqa: F401
    except Exception:
        return False
    return os.path.isfile(model_path()) or not _SESS["failed"]


def ensure_model(log=print, timeout=60):
    """Il modello della voce sul computer (si scarica una volta, ~26 MB). True se c'e'."""
    p = model_path()
    if os.path.isfile(p) and os.path.getsize(p) == MODEL_BYTES:
        return True
    if _SESS["failed"]:
        return False
    import urllib.request
    tmp = p + ".part"
    os.makedirs(os.path.dirname(p), exist_ok=True)
    log("Scarico il modello della voce (una volta sola, 26 MB)")
    for url in MODEL_URLS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "NoonFrame"})
            with urllib.request.urlopen(req, timeout=timeout) as r, open(tmp, "wb") as f:
                while True:
                    b = r.read(1 << 16)
                    if not b:
                        break
                    f.write(b)
            if os.path.getsize(tmp) != MODEL_BYTES:
                raise RuntimeError("download incompleto")
            os.replace(tmp, p)
            return True
        except Exception as e:
            print("[voce] modello non scaricato da", url.split("/")[2], ":", str(e)[:160], flush=True)
            try:
                os.remove(tmp)
            except OSError:
                pass
    _SESS["failed"] = True
    return False


def _session():
    with _LOCK:
        if _SESS["s"] is None:
            import onnxruntime as ort
            o = ort.SessionOptions()
            o.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 4) // 2))
            o.log_severity_level = 3
            _SESS["s"] = ort.InferenceSession(model_path(), sess_options=o, providers=["CPUExecutionProvider"])
        return _SESS["s"]


_MEL = {}


def _mel_banks(n_fft=512, n_mels=80, sr=SR, lo=20.0, hi=0.0):
    """Banco di filtri mel come Kaldi (scala 1127*ln(1+f/700), triangoli nel dominio mel)."""
    key = (n_fft, n_mels)
    if key in _MEL:
        return _MEL[key]
    hi = sr / 2 + hi if hi <= 0 else hi
    mel = lambda f: 1127.0 * np.log(1.0 + f / 700.0)   # noqa: E731
    ml, mh = mel(lo), mel(hi)
    delta = (mh - ml) / (n_mels + 1)
    nb = n_fft // 2
    freqs = np.arange(nb) * (sr / n_fft)
    mf = mel(freqs)
    banks = np.zeros((n_mels, nb + 1), np.float32)
    for m in range(n_mels):
        left, center, right = ml + m * delta, ml + (m + 1) * delta, ml + (m + 2) * delta
        up = (mf - left) / (center - left)
        down = (right - mf) / (right - center)
        banks[m, :nb] = np.maximum(0.0, np.minimum(up, down))
    _MEL[key] = banks
    return banks


def fbank(x):
    """Fbank 80 come torchaudio.compliance.kaldi.fbank (finestra di Hamming 25 ms, passo 10 ms, senza dither), con la
    media tolta (come fa WeSpeaker). x: campioni float alla scala int16, 16 kHz. -> [T, 80]"""
    x = np.asarray(x, np.float64)
    fl, fs_ = 400, 160
    if len(x) < fl:
        return np.zeros((0, 80), np.float32)
    n = 1 + (len(x) - fl) // fs_
    idx = np.arange(fl)[None, :] + fs_ * np.arange(n)[:, None]
    fr = x[idx]
    fr = fr - fr.mean(axis=1, keepdims=True)                       # via la componente continua
    pre = fr.copy()
    pre[:, 1:] = fr[:, 1:] - 0.97 * fr[:, :-1]                      # pre-enfasi
    pre[:, 0] = fr[:, 0] - 0.97 * fr[:, 0]
    win = 0.54 - 0.46 * np.cos(2 * np.pi * np.arange(fl) / (fl - 1))
    spec = np.abs(np.fft.rfft(pre * win, n=512, axis=1)) ** 2       # [n, 257]
    mel = spec @ _mel_banks().T
    feats = np.log(np.maximum(mel, np.finfo(np.float32).eps)).astype(np.float32)
    return feats - feats.mean(axis=0, keepdims=True)


def embed(x):
    """Impronta della voce (256 numeri, lunghezza 1) di un pezzo di audio (float alla scala int16, 16 kHz)."""
    f = fbank(x)
    if len(f) < 50:            # meno di mezzo secondo: troppo poco per riconoscere una voce
        return None
    out = _session().run(None, {"feats": f[None, :, :]})[0][0].astype(np.float32)
    nrm = float(np.linalg.norm(out))
    return out / nrm if nrm > 0 else None


def read_audio(path, off, dur):
    """Audio mono 16 kHz alla scala int16 (float32) da off per dur secondi."""
    import subprocess
    from .util import ffmpeg_bin, NO_WINDOW
    r = subprocess.run([ffmpeg_bin(), "-nostdin", "-v", "error", "-ss", f"{max(0.0, off):.3f}", "-i", path, "-t", f"{dur:.3f}",
                        "-vn", "-sn", "-ac", "1", "-ar", str(SR), "-f", "s16le", "-"], stdin=subprocess.DEVNULL, capture_output=True,
                       timeout=120, creationflags=NO_WINDOW)
    return np.frombuffer(r.stdout, np.int16).astype(np.float32)


def clusters(embs, thr=0.5):
    """Gruppi di voci: unione per somiglianza media (coseno) finche' due gruppi si somigliano piu' di thr.
    embs: [vettore o None]. -> etichetta di gruppo per ognuno (-1 = senza voce)."""
    idx = [i for i, e in enumerate(embs) if e is not None]
    lab = [-1] * len(embs)
    if not idx:
        return lab
    E = np.stack([embs[i] for i in idx])
    S = E @ E.T
    groups = [[k] for k in range(len(idx))]
    while len(groups) > 1:
        best, bp = None, None
        for x in range(len(groups)):
            for y in range(x + 1, len(groups)):
                v = float(S[np.ix_(groups[x], groups[y])].mean())
                if best is None or v > best:
                    best, bp = v, (x, y)
        if best is None or best < thr:
            break
        x, y = bp
        groups[x] += groups[y]
        groups.pop(y)
    for g, members in enumerate(sorted(groups, key=lambda m: -len(m))):
        for k in members:
            lab[idx[k]] = g
    return lab
