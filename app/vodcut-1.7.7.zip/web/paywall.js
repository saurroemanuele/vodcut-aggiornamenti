// Paywall (foglio breve, stile v2): testata sfumata col motivo per cui si e' aperto, Mensile/Annuale, due piani da
// scegliere (Pro prima e gia' scelto, poi il piu' economico), un solo pulsante col prezzo dentro, poi il pagamento di
// sempre (checkout.js). Listino, offerte e costo di un'ora di live arrivano dal server. Chi ha gia' un piano (o non ha
// fatto l'accesso) va alla pagina "Crediti e piani".
import { h, icon } from './lib.js';
import { t as tx } from './i18n.js';
import { loadCatalog, creditsDialog, nf, eur, liveHours, topPlan, upTrack } from './credits.js';
import { purchase, planOffer, yearSave, periodSwitch, hoursHero, planTone } from './plans.js';

// cosa l'ha aperto: la frase sotto il titolo
const WHY = {
  ai: 'L\'Assistente AI è incluso in tutti i piani.',
  '': 'Crediti nuovi ogni mese per trovare le clip e usare l\'Assistente AI.',
};
// i momenti in cui si propone l'abbonamento a chi e' gratis: [in alto, titolo, frase]. Qui Starter e' gia' scelto e c'e' un'alternativa
const UP = {
  export: ['TOGLI IL WATERMARK', 'Esporta senza watermark, in 1080p.', 'Con un piano le tue clip escono pulite, fino a 4K e 60 fps.'],
  first_clip: ['LA TUA CLIP È PRONTA', 'Pubblicala senza watermark.', 'Con un piano esporti in 1080p senza il marchio NoonFrame e hai crediti nuovi ogni mese.'],
  low_credits: ['CREDITI QUASI FINITI', 'Ti restano pochi crediti.', 'Con un piano hai crediti nuovi ogni mese, senza watermark e in 1080p.'],
  zero_credits: ['CREDITI FINITI', 'Hai usato tutti i crediti.', 'Con un piano hai crediti nuovi ogni mese, senza watermark e in 1080p.'],
};
const TRACKED = new Set([...Object.keys(UP), 'ai']);

export async function openPaywall(o = {}) {
  if (document.querySelector('.pw-bg')) return;
  let c = null;
  try { c = await loadCatalog(true); } catch (e) { /* sotto: la pagina dei piani dice cosa non va */ }
  const plans = ((c && c.catalog) || {}).plans || [];
  const top = topPlan(plans);
  if (!c || !c.signedIn || (c.plan && c.plan !== 'free') || !top) { if (o.alt) o.alt.run(); else creditsDialog('plans'); return; }
  const up = UP[o.why], where = o.why === 'ai' ? 'locked_feature' : o.why;
  const cheap = plans.slice().sort((a, b) => a.price - b.price)[0];
  // nei momenti "UP" il primo, gia' scelto, e' il piano piu' economico (Starter, con l'offerta del primo mese se c'e')
  const first = up && cheap ? cheap : top;
  const other = up ? (first.id !== top.id ? top : plans.find((p) => p.id !== first.id)) : plans.filter((p) => p.id !== top.id).sort((a, b) => a.price - b.price)[0];
  const opts = [first, other].filter(Boolean);
  const hc = c.hourCredits, hasYear = opts.some((p) => p.priceYear), save = yearSave(opts);
  let pick = first.id, period = 'month', busy = false;
  // l'alternativa sotto il pulsante: "Esporta con watermark" (dall'export) o la ricarica piu' piccola (crediti finiti o quasi)
  const pack = (((c.catalog || {}).packs) || []).slice().sort((a, b) => a.price - b.price)[0];
  const alt = o.alt || (pack && (o.why === 'low_credits' || o.why === 'zero_credits') ? { label: 'Oppure ricarica', price: eur(pack.price), run: () => {
    const info = { kind: 'pack', name: nf(pack.credits) + ' ' + tx('crediti'), det: nf(pack.credits) + ' ' + tx('crediti'), price: eur(pack.price) };
    return purchase(c, 'pack', pack.id, null, info);
  } } : null);
  if (TRACKED.has(o.why) && !o.seen) upTrack('upsell.view', where);

  const body = h('div', { class: 'pw-body' });
  const sheet = h('div', { class: 'pw', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Passa a un piano' },
    h('button', { class: 'pw-x', type: 'button', 'aria-label': 'Chiudi', onclick: () => close() }, icon('x', 14, 'currentColor', 2.2)), body);
  const bg = h('div', { class: 'modal-bg pw-bg' }, sheet);
  const close = () => { if (busy) return; bg.remove(); removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.co-bg')) { e.stopPropagation(); close(); } };

  // il prezzo di un piano col periodo scelto: al mese, il mensile barrato se si risparmia, cosa si paga oggi
  const priceOf = (p) => {
    const y = period === 'year' && p.priceYear, po = !y ? planOffer(c, p.id) : null;
    return { y, po, month: y ? p.priceYear / 12 : po ? po.price : p.price, pay: y ? p.priceYear : po ? po.price : p.price };
  };

  function paint() {
    const sel = opts.find((p) => p.id === pick) || top, sp = priceOf(sel);
    const row = (p) => {
      const on = p.id === pick, pr = priceOf(p);
      return h('button', { type: 'button', class: 'pw-opt ' + planTone(plans, p) + (on ? ' on' : ''), role: 'radio', 'aria-checked': String(on), onclick: () => { pick = p.id; paint(); } },
        h('span', { class: 'pw-radio' }, h('i')),
        h('span', { class: 'pw-mid' },
          h('span', { class: 'pw-nm' }, h('b', { 'data-notr': '' }, p.name), p.id === top.id ? h('em', null, 'Il più scelto') : null),
          hoursHero(p.monthly, hc, 'pw-hrs', 'di live al mese'),
          liveHours(p.monthly, hc) ? h('small', null, h('span', { 'data-notr': '' }, nf(p.monthly)), ' ', h('span', null, 'crediti al mese')) : null),
        h('span', { class: 'pw-pr' }, h('b', { class: 'tnum', 'data-notr': '' }, eur(pr.month)), h('small', null, pr.po ? 'il primo mese' : 'al mese'),
          pr.y || pr.po ? h('s', { 'data-notr': '' }, eur(p.price)) : null));
    };
    // il pulsante prende il colore del piano scelto
    const cta = h('button', { type: 'button', class: 'pw-cta ' + planTone(plans, sel) },
      h('span', null, 'Continua con'), ' ', h('span', { 'data-notr': '' }, sel.name), ' · ', h('span', { 'data-notr': '' }, eur(sp.pay)), ' ',
      h('span', null, sp.y ? 'l\'anno' : sp.po ? 'il primo mese' : 'al mese'));
    cta.onclick = async () => {
      if (TRACKED.has(o.why)) upTrack('upsell.click', where);
      const det = nf(sel.monthly) + ' ' + tx('crediti ogni mese');   // va alla pagina di pagamento gia' tradotto
      const info = { kind: 'plan', name: 'NoonFrame ' + sel.name, plan: sel.name, det, price: eur(sp.pay) };
      busy = true;
      const r = sp.po ? await purchase(c, 'offer', sp.po.id, null, info, cta) : await purchase(c, 'plan', sel.id, sp.y ? 'year' : 'month', info, cta);
      busy = false;
      if (r && (r.paid || r.changed || r.fallback)) close();
    };
    const altBtn = alt ? h('button', { type: 'button', class: 'linkish pw-alt', onclick: async () => {
      if (o.alt) { close(); o.alt.run(); return; }
      busy = true; const r = await alt.run(); busy = false;
      if (r && (r.paid || r.fallback)) close();
    } }, h('span', null, alt.label), alt.price ? h('span', { 'data-notr': '' }, ' · ' + alt.price) : null) : null;
    body.replaceChildren(
      h('div', { class: 'pw-hero' },
        h('span', { class: 'pw-kick' }, up ? up[0] : 'PASSA A UN PIANO'),
        h('h2', null, up ? up[1] : 'Più ore di live, più clip.'),
        h('p', null, up ? up[2] : WHY[o.why] || WHY[''])),
      h('div', { class: 'pw-bar' },
        hasYear ? periodSwitch(period, save > 0 ? '−' + save + '%' : '', (k) => { period = k; paint(); }) : h('span'),
        h('span', null, 'Disdici quando vuoi')),
      h('div', { class: 'pw-opts', role: 'radiogroup' }, ...opts.map(row)),
      h('div', { class: 'pw-perks' }, ...['Senza watermark, fino a 4K', 'Crediti nuovi ogni mese', 'Assistente AI incluso'].map((k) => h('span', null, icon('check', 12, 'currentColor', 2.6), h('span', null, k)))),
      cta, altBtn,
      h('div', { class: 'pw-foot' },
        hc ? h('span', null, h('span', null, '1 ora di live ≈'), ' ', h('span', { 'data-notr': '' }, nf(hc)), ' ', h('span', null, 'crediti')) : h('span', null, 'Prezzi IVA inclusa'),
        h('button', { type: 'button', class: 'linkish', onclick: () => { close(); creditsDialog('plans'); } }, 'Tutti i piani e le ricariche')));
  }

  paint();
  addEventListener('keydown', onKey, true);
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  sheet.querySelector('.pw-cta').focus({ preventScroll: true });
}
