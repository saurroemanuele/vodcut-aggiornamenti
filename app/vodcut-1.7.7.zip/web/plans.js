// Crediti e piani (21a, stile paywall v2): le ore di live sono il numero principale e i crediti stanno nella riga sotto,
// Pro e' il piano in evidenza, ogni piano ha il suo colore, abbonamenti mensili o annuali (l'annuale mostrato come prezzo
// al mese) e sotto le ricariche. Il listino arriva sempre dal server (lo decide il pannello admin), e anche il costo di
// un'ora di live (hourCredits, scritto in fondo alla pagina): senza, si mostrano solo i crediti. "Passa a…" e le ricariche aprono
// il foglio di pagamento dentro l'app; se non e' ancora attivo, il pagamento si apre nel browser come prima.
// Si usa come pagina (barra laterale) o, nell'editor, in un foglio grande.
import { post, h, icon, toast, confirmBox } from './lib.js';
import { locale, byLang, t as tx } from './i18n.js';
import { coin, loadCatalog, openPortal, nf, eur, liveHours, topPlan } from './credits.js';
import { openCheckout } from './checkout.js';

const day = (iso) => { try { return new Date(iso).toLocaleDateString(locale(), { day: 'numeric', month: 'long' }); } catch (e) { return ''; } };
const MO = () => byLang({ it: '/mese', en: '/month', fr: '/mois', de: '/Monat', pt: '/mês', es: '/mes' });
const YR = () => byLang({ it: '/anno', en: '/year', fr: '/an', de: '/Jahr', pt: '/ano', es: '/año' });
const kids = (...a) => a.flat().filter((x) => x != null && x !== false && x !== '');
const tick = () => icon('check', 13, 'currentColor', 2.6);

// offerta sul primo mese di un piano (personale o per tutti, solo per chi non ha un piano): la piu' conveniente
export const planOffer = (c, pid) => (c && c.plan && c.plan !== 'free' ? null
  : ((c && c.catalog && c.catalog.offers) || []).filter((o) => o.kind === 'plan' && o.plan === pid).sort((a, b) => a.price - b.price)[0] || null);
// "−17%" / "2 mesi gratis": quanto si risparmia con l'annuale (il massimo tra i piani)
export const yearSave = (plans) => Math.max(0, ...plans.map((p) => (p.priceYear && p.price ? Math.round((1 - p.priceYear / (p.price * 12)) * 100) : 0)));
// il colore di ogni piano (app.css .t-g/.t-b/.t-v): Starter verde, Pro blu, Ultimate viola; un piano nuovo lo prende dalla posizione
const TONE = { starter: 'g', pro: 'b', ultimate: 'v' };
export const planTone = (plans, p) => 't-' + (TONE[p.id] || 'gbv'[Math.max(0, plans.indexOf(p)) % 3]);
const freeMonths = (plans) => Math.max(0, ...plans.map((p) => (p.priceYear && p.price ? Math.round(12 - p.priceYear / p.price) : 0)));

// Mensile / Annuale (pillola): extra = il badge verde sull'annuale
export function periodSwitch(period, extra, pick) {
  const b = (k, label, x) => h('button', { type: 'button', class: k === period ? 'on' : '', role: 'tab', 'aria-selected': String(k === period), onclick: () => pick(k) }, label, x || null);
  return h('div', { class: 'pl-per', role: 'tablist' }, b('month', 'Mensile'), b('year', 'Annuale', extra ? h('em', null, extra) : null));
}

// acquisto: foglio di pagamento nell'app; se non e' attivo, la pagina di Stripe nel browser (come prima).
// c = il catalogo di adesso. Risponde quello che dice il foglio di pagamento ({ paid }, { changed }, { fallback }) o null
export async function purchase(c, kind, id, per, info, btn) {
  if (btn) btn.disabled = true;
  let r = null;
  try {
    const item = per === 'year' ? { kind, id, period: per } : { kind, id };
    // chi ha gia' un abbonamento cambia piano su quello: Stripe addebita subito la differenza, quindi prima si dice quanto
    if (kind === 'plan' && c && c.plan && c.plan !== 'free' && !(await okChange(item, info))) { if (btn) btn.disabled = false; return null; }
    r = await openCheckout(item, info);
    if (r.fallback) {
      const b = await post('/api/ai/buy', { item });
      if (b.changed) toast('Piano cambiato');
      else if (b.opened) { toast('Completa il pagamento nella pagina che si è aperta nel browser'); waitBrowser(c); }
    } else if (r.changed) toast('Piano cambiato');
  } catch (e) { toast(e.message, true); }
  if (btn) btn.disabled = false;
  return r;
}
// anteprima del cambio di piano (dal server, con i conti di Stripe) e conferma con l'importo di oggi
async function okChange(item, info) {
  const pv = await post('/api/ai/planpreview', { item });
  if (!pv || !pv.change) return true;   // niente da cambiare (abbonamento nuovo): si paga nel foglio come sempre
  const due = pv.dueCents, price = eur((pv.priceCents || 0) / 100) + (pv.period === 'year' ? YR() : MO());
  const when = pv.renewsAt ? day(new Date(pv.renewsAt).toISOString()) : '';
  const name = (info && info.plan) || pv.plan;
  const sure = due != null && !!when;   // anteprima di Stripe non riuscita: la conferma senza l'importo esatto
  const text = !sure ? 'Oggi paghi solo la differenza per i giorni che restano, con lo stesso metodo di pagamento dell\'abbonamento. Poi il piano costa ' + price + '.'
    : due > 0 ? 'Oggi paghi ' + eur(due / 100) + ' per i giorni che restano, con lo stesso metodo di pagamento dell\'abbonamento. Dal ' + when + ' il piano costa ' + price + '.'
      : 'Il cambio vale da subito: quello che hai già pagato del piano di adesso diventa uno sconto sui prossimi rinnovi. Dal ' + when + ' il piano costa ' + price + '.';
  return confirmBox('Passare a ' + name + '?', text, sure && due > 0 ? 'Paga ' + eur(due / 100) : 'Cambia piano');
}
// pagamento nel browser: il saldo si aggiorna da solo appena Stripe conferma (al massimo 15 minuti)
function waitBrowser(c) {
  const b0 = c ? { balance: c.balance, plan: c.plan } : null, t0 = Date.now();
  const go = async () => {
    try {
      const n = await loadCatalog(true);
      if (b0 && (n.balance !== b0.balance || n.plan !== b0.plan)) { window.dispatchEvent(new CustomEvent('nf-credits-changed')); toast('Pagamento ricevuto'); return; }
    } catch (e) { /* riprova */ }
    if (Date.now() - t0 < 15 * 60 * 1000) setTimeout(go, 4000);
  };
  setTimeout(go, 3000);
}

// le ore (o, se il server non dice quanto costa un'ora, i crediti) come numero grande, con la sua etichetta accanto
export function hoursHero(credits, hc, cls, label) {
  const hrs = liveHours(credits, hc);
  return h('div', { class: cls }, hrs ? h('b', null, hrs) : h('b', { 'data-notr': '' }, nf(credits)), h('span', null, hrs ? label : (label === 'di live' ? 'crediti' : 'crediti al mese')));
}

// opts: { tab: 'plans'|'packs', onClose() se e' in un foglio }
export function plansView(opts = {}) {
  const root = h('div', { class: 'pl' });
  let period = 'month', c = null, toPacks = opts.tab === 'packs';
  const head = h('header', { class: 'pl-head' });
  const body = h('div', { class: 'pl-body' });
  root.append(head, body);

  async function load(force) {
    try { c = await loadCatalog(force); } catch (e) { body.replaceChildren(h('p', { class: 'pl-err' }, e.message)); return; }
    paint();
  }
  async function buy(kind, id, per, info, btn) {
    await purchase(c, kind, id, per, info, btn);
    await load(true);
  }

  function paint() {
    if (!c) return;
    const close = opts.onClose ? h('button', { class: 'pl-x', type: 'button', 'aria-label': 'Chiudi', onclick: opts.onClose }, icon('x', 14, 'currentColor', 2.2)) : null;
    if (!c.signedIn) {
      head.replaceChildren(...kids(h('div', { class: 'pl-tt' }, h('h1', null, 'Crediti e piani')), close));
      body.replaceChildren(h('div', { class: 'pl-empty' }, coin(34), h('h2', null, 'Accedi per usare i crediti'), h('p', null, 'I crediti sono legati al tuo account: accedi dalla foto profilo in alto a destra.')));
      return;
    }
    const cat = c.catalog || {}, plans = cat.plans || [], packs = cat.packs || [];
    const hc = c.hourCredits;
    const cur = c.plan || 'free', paid = cur !== 'free';
    const mine = plans.find((p) => p.id === cur);
    const top = topPlan(plans);
    const hasYear = plans.some((p) => p.priceYear);
    if (!hasYear) period = 'month';
    const yearly = period === 'year';
    const fm = freeMonths(plans), save = yearSave(plans);

    head.replaceChildren(...kids(
      h('div', { class: 'pl-tt' }, h('h1', null, 'Crediti e piani'), h('p', null, 'I crediti servono per l\'AI e le Clip veloci. Montare a mano è sempre gratis.')),
      close));

    // il tuo piano e i crediti che hai (con le ore di live che ci stanno)
    const frac = paid && mine && mine.monthly ? (c.monthly || 0) / mine.monthly : (c.balance || 0) / Math.max(c.balance || 0, 120);
    const balHrs = liveHours(c.balance, hc);
    const me = h('div', { class: 'pl-me' + (paid && mine ? ' ' + planTone(plans, mine) : '') },
      h('div', { class: 'pl-me-l' }, h('span', null, 'Il tuo piano'),
        h('b', { 'data-notr': '' }, paid ? c.planName || (mine || {}).name || cur : byLang({ it: 'Gratis', en: 'Free', fr: 'Gratuit', de: 'Kostenlos', pt: 'Grátis', es: 'Gratis' })),
        h('small', null, paid && c.nextGrant ? h('span', null, h('span', null, 'Crediti nuovi il'), ' ', h('span', { 'data-notr': '' }, day(c.nextGrant)))
          : paid ? 'Crediti nuovi ogni mese' : 'Con un piano hai crediti nuovi ogni mese')),
      h('div', { class: 'pl-me-r' },
        h('div', { class: 'pl-me-row' }, h('b', null, h('span', { 'data-notr': '' }, nf(c.balance)), ' ', h('span', null, 'crediti')),
          balHrs ? h('span', null, h('span', null, balHrs), ' ', h('span', null, 'di live')) : null),
        h('div', { class: 'pl-me-bar' }, h('i', { style: { width: (Math.max(0, Math.min(1, frac)) * 100).toFixed(1) + '%' } }))));

    // abbonamenti
    const plansHead = h('div', { class: 'pl-sh' },
      h('div', null, h('h2', null, 'Abbonamenti'), h('p', null, 'Crediti nuovi ogni mese. Disdici quando vuoi.')),
      hasYear ? periodSwitch(period, fm >= 2 ? fm + ' ' + byLang({ it: 'mesi gratis', en: 'months free', fr: 'mois offerts', de: 'Monate gratis', pt: 'meses grátis', es: 'meses gratis' }) : save > 0 ? '−' + save + '%' : '', (k) => { period = k; paint(); }) : null);
    const grid = h('div', { class: 'pl-grid' }, ...plans.map((p) => {
      const isMine = p.id === cur, hl = !isMine && top && p.id === top.id, y = yearly && p.priceYear, po = !yearly ? planOffer(c, p.id) : null;
      const price = y ? p.priceYear / 12 : po ? po.price : p.price;
      const det = nf(p.monthly) + ' ' + tx('crediti ogni mese');   // va alla pagina di pagamento gia' tradotto
      const btn = h('button', { type: 'button', class: 'pl-btn' + (isMine ? ' mine' : hl ? ' main' : ''), disabled: isMine ? true : null },
        isMine ? 'Piano attuale' : h('span', null, h('span', null, 'Passa a'), ' ', h('span', { 'data-notr': '' }, p.name)));
      if (!isMine) {
        btn.onclick = () => (po
          ? buy('offer', po.id, null, { kind: 'plan', name: 'NoonFrame ' + p.name, plan: p.name, det, price: eur(po.price) }, btn)
          : buy('plan', p.id, y ? 'year' : 'month', { kind: 'plan', name: 'NoonFrame ' + p.name, plan: p.name, det, price: eur(y ? p.priceYear : p.price) }, btn));
      }
      return h('div', { class: 'pl-card ' + planTone(plans, p) + (isMine ? ' mine' : hl ? ' hl' : '') },
        h('div', { class: 'pl-top' }, h('b', { class: 'pl-name', 'data-notr': '' }, p.name),
          isMine ? h('span', { class: 'pl-badge' }, 'Il tuo piano') : hl ? h('span', { class: 'pl-badge main' }, 'Il più scelto') : null),
        h('div', null, hoursHero(p.monthly, hc, 'pl-hrs', 'di live al mese'),
          liveHours(p.monthly, hc) ? h('div', { class: 'pl-crl' }, h('span', { 'data-notr': '' }, nf(p.monthly)), ' ', h('span', null, 'crediti al mese')) : null),
        h('i', { class: 'pl-div' }),
        h('div', null,
          h('div', { class: 'pl-price' }, h('b', { class: 'tnum', 'data-notr': '' }, eur(price)), h('span', null, MO()),
            y || po ? h('s', { 'data-notr': '' }, eur(p.price)) : null),
          h('div', { class: 'pl-bill' }, y ? h('span', null, h('span', { 'data-notr': '' }, eur(p.priceYear)), ' ', h('span', null, 'fatturati ogni anno'))
            : po ? h('span', null, h('span', null, 'il primo mese, poi'), ' ', h('span', { 'data-notr': '' }, eur(p.price) + MO())) : 'Fatturato ogni mese')),
        h('ul', { class: 'pl-perks' }, ...(p.perks || []).slice(0, 4).map((k) => h('li', null, tick(), h('span', { 'data-notr': '' }, k)))),
        btn);
    }));

    // ricariche: una tantum, la scheda intera e' il pulsante
    const per100 = (k) => (k.price / k.credits) * 100;
    const best = packs.reduce((b, k) => (!b || per100(k) < per100(b) ? k : b), null);
    const packsBox = packs.length ? h('section', { class: 'pl-packs' },
      h('div', { class: 'pl-sh' }, h('div', null, h('h2', null, 'Ricarica crediti'), h('p', null, 'Una tantum, senza abbonamento. I crediti ricaricati non scadono.'))),
      h('div', { class: 'pl-pgrid' }, ...packs.map((k, i) => {
        const tag = best && k.id === best.id ? 'Il migliore' : i === 1 && packs.length > 2 ? 'Conviene' : null;
        const card = h('button', { type: 'button', class: 'pl-pack' },
          h('span', { class: 'pl-ptag' }, tag ? h('em', null, tag) : null),
          hoursHero(k.credits, hc, 'pl-phrs', 'di live'),
          h('span', { class: 'pl-pcr' }, h('span', { 'data-notr': '' }, nf(k.credits)), ' ', h('span', null, 'crediti'), ' · ', h('span', null, 'non scadono')),
          h('span', { class: 'pl-pfoot' }, h('b', { class: 'tnum', 'data-notr': '' }, eur(k.price)),
            h('small', null, h('span', { 'data-notr': '' }, eur(per100(k))), ' ', h('span', null, 'ogni 100'))));
        card.onclick = () => buy('pack', k.id, null, { kind: 'pack', name: nf(k.credits) + ' ' + tx('crediti'), det: tx('Ricarica · non scadono'), price: eur(k.price) }, card);
        return card;
      }))) : null;

    // la base delle "≈ ore": quanti crediti costa trovare le clip in un'ora di live
    const foot = h('div', { class: 'pl-foot' },
      hc ? h('span', null, icon('clock', 12, 'currentColor', 2), h('span', null, h('span', null, '1 ora di live ≈'), ' ', h('span', { 'data-notr': '' }, nf(hc)), ' ', h('span', null, 'crediti'))) : null,
      h('span', null, icon('lock', 12, 'currentColor', 2), 'Pagamento sicuro con Stripe'), h('span', null, 'Prezzi IVA inclusa'), h('span', null, 'Disdici quando vuoi'),
      // anche senza abbonamento: le ricariche comprate e le loro ricevute
      h('button', { type: 'button', class: 'linkish pl-manage', onclick: () => openPortal() }, paid ? 'Gestisci abbonamento' : 'I tuoi pagamenti'));
    body.replaceChildren(...kids(me, plans.length ? plansHead : null, plans.length ? grid : null, packsBox, foot));
    // aperta da "Ricarica": si parte dalle ricariche
    if (toPacks && packsBox) { toPacks = false; requestAnimationFrame(() => packsBox.scrollIntoView({ block: 'start' })); }
  }

  body.append(h('div', { class: 'pl-load' }, h('div', { class: 'spinner' })));
  load(true);
  const onChange = () => { if (!root.isConnected) { removeEventListener('nf-credits-changed', onChange); return; } load(true); };
  addEventListener('nf-credits-changed', onChange);
  return root;
}

// nell'editor: la stessa pagina in un foglio grande (cosi' non si lascia il montaggio)
export function plansSheet(tab) {
  const bg = h('div', { class: 'modal-bg pl-bg' });
  const close = () => { bg.remove(); removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('.co-bg')) { e.stopPropagation(); close(); } };
  addEventListener('keydown', onKey, true);
  bg.append(h('div', { class: 'pl-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Crediti e piani' }, plansView({ tab, onClose: close })));
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
}
