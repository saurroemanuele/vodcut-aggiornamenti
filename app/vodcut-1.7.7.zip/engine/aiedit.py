"""Montaggio con l'AI: stili di montaggio (pronti o imparati dai video di riferimento) e il piano delle modifiche.

L'AI non tocca il progetto: legge la trascrizione (parole numerate con i tempi) e lo stile, e propone un piano
(tagli, zoom, sottotitoli, scritte, grafiche). L'editor lo mostra, l'utente sceglie e lo applica (si annulla in un colpo).
Le pause si trovano qui, senza AI (gratis): sono i buchi tra una parola e l'altra.
"""
import json
import os
import re
import subprocess

from . import ai
from .util import NO_WINDOW, ffmpeg_bin

FONTS = ["Montserrat", "Poppins", "Inter", "TikTok Sans", "Bebas Neue", "Anton", "Oswald", "Archivo Black", "Kanit", "Rubik",
         "Lilita One", "Luckiest Guy", "Bangers", "Titan One", "Outfit", "Sora", "Space Grotesk", "Unbounded", "Playfair Display",
         "Russo One", "Teko", "Orbitron", "Permanent Marker", "Arial", "Impact"]

# ------------------------------------------------------------------ stili pronti
PRESETS = {
    "business": {
        "name": "Finanza e business", "icon": "chart",
        "summary": "Ritmo serrato da YouTube business: niente pause, zoom sui numeri e sulle frasi forti, parole chiave colorate, grafiche pulite con cifre e icone.",
        "pace": {"pauses": "tutte", "max_pause_sec": 0.3, "cut_every_sec": 3, "notes": "togli esitazioni, ripetizioni e frasi ricominciate"},
        "zoom": {"per_min": 2.5, "level": 1.35, "style": "lento", "when": "numeri, cifre, promesse, frasi forti e cambi di argomento"},
        "captions": {"on": True, "mode": "poche", "position": "basso", "font": "Montserrat", "upper": False, "color": "#FFFFFF",
                     "highlight": "#FFD60A", "effect": "highlight", "box": False, "stroke": True, "size": "medi"},
        "texts": {"per_min": 1.5, "when": "numeri importanti, titoli dei capitoli, concetti chiave in 2-4 parole", "color": "#FFFFFF", "box": True},
        "graphics": {"per_min": 1.5, "when": "quando si parla di soldi, crescita, strumenti, aziende, concetti astratti",
                     "types": ["icone 3D", "grafici", "banconote e monete", "loghi generici"],
                     "prompt_style": "clean professional finance style, restrained colors"},
        "broll": {"per_min": 0.5, "when": "esempi concreti"},
        "hook": "prima frase subito, zoom sul volto nei primi 2 secondi, titolo grande con la promessa",
        "rules": ["mai più di 3 secondi senza un cambio (zoom, scritta o grafica)", "le cifre vanno sempre anche a schermo"],
    },
    "gaming": {
        "name": "Gaming", "icon": "play",
        "summary": "Montaggio energico da gaming: tagli rapidissimi, zoom a scatto sulle reazioni, sottotitoli grandi e colorati, scritte meme.",
        "pace": {"pauses": "tutte", "max_pause_sec": 0.25, "cut_every_sec": 2, "notes": "togli le parti morte senza azione o reazione"},
        "zoom": {"per_min": 10, "level": 1.4, "style": "scatto", "when": "reazioni, urla, momenti epici, battute"},
        "captions": {"on": True, "mode": "parola", "position": "centro", "font": "Luckiest Guy", "upper": True, "color": "#FFFFFF",
                     "highlight": "#3DDC84", "effect": "pop", "box": False, "stroke": True, "size": "grandi"},
        "texts": {"per_min": 2, "when": "reazioni e momenti comici, stile meme (es. \"NO WAY\", \"GG\")", "color": "#FFD60A", "box": False},
        "graphics": {"per_min": 1, "when": "momenti comici o epici",
                     "types": ["emoji 3D", "effetti cartoon"], "prompt_style": "bold cartoon sticker, thick outline, vibrant saturated colors"},
        "broll": {"per_min": 0, "when": ""},
        "hook": "parti dal momento più epico, poi il contesto",
        "rules": ["energia sempre alta", "ogni reazione forte ha zoom o scritta"],
    },
    "live": {
        "name": "Live Twitch e Kick", "icon": "play",
        "summary": "Per i VOD delle live: l'AI guarda parole e volume, tiene i momenti forti (reazioni, battute, giocate), toglie attese e tempi morti, zoom sulla webcam nelle reazioni e scritte meme.",
        "pace": {"pauses": "tutte", "max_pause_sec": 0.4, "cut_every_sec": 3, "notes": "togli attese, menu, caricamenti, silenzi senza azione"},
        "zoom": {"per_min": 2, "level": 1.4, "style": "scatto", "when": "reazioni forti, urli, risate, momenti epici"},
        "captions": {"on": True, "mode": "poche", "position": "basso", "font": "Montserrat", "upper": True, "color": "#FFFFFF",
                     "highlight": "#3DDC84", "effect": "pop", "box": False, "stroke": True, "size": "medi"},
        "texts": {"per_min": 0.6, "when": "solo i momenti piu' forti, stile meme", "color": "#FFD60A", "box": False},
        "graphics": {"per_min": 0, "when": "", "types": [], "prompt_style": ""},
        "broll": {"per_min": 0, "when": ""},
        "hook": "parti da un momento forte",
        "rules": ["mai tempi morti", "ogni reazione forte ha uno zoom"],
    },
    "story": {
        "name": "Storytelling", "icon": "text",
        "summary": "Racconto coinvolgente: ritmo che respira nei momenti di tensione, zoom lenti sulle frasi emotive, sottotitoli puliti.",
        "pace": {"pauses": "lunghe", "max_pause_sec": 0.7, "cut_every_sec": 4, "notes": "tieni le pause drammatiche, togli solo quelle morte"},
        "zoom": {"per_min": 3, "level": 1.2, "style": "morbido", "when": "rivelazioni, frasi emotive, colpi di scena"},
        "captions": {"on": True, "mode": "poche", "position": "basso", "font": "Poppins", "upper": False, "color": "#FFFFFF",
                     "highlight": "#FF9F5A", "effect": "highlight", "box": False, "stroke": True, "size": "medi"},
        "texts": {"per_min": 0.5, "when": "luoghi, date, nomi importanti", "color": "#FFFFFF", "box": False},
        "graphics": {"per_min": 1, "when": "per illustrare luoghi, oggetti e momenti del racconto",
                     "types": ["illustrazioni"], "prompt_style": "cinematic illustration, moody lighting, rich colors"},
        "broll": {"per_min": 1, "when": "descrizioni di luoghi e scene"},
        "hook": "apri con la frase più misteriosa o il momento più forte",
        "rules": ["non spezzare le frasi emotive"],
    },
    "podcast": {
        "name": "Podcast e interviste", "icon": "speaker",
        "summary": "Pulito e leggibile: togli pause lunghe ed errori, zoom leggeri su chi dice la cosa importante, sottotitoli a frase.",
        "pace": {"pauses": "lunghe", "max_pause_sec": 0.8, "cut_every_sec": 6, "notes": "togli solo errori e pause lunghe, mai il ragionamento"},
        "zoom": {"per_min": 2, "level": 1.15, "style": "morbido", "when": "le frasi citabili"},
        "captions": {"on": True, "mode": "frase", "position": "basso", "font": "Inter", "upper": False, "color": "#FFFFFF",
                     "highlight": "#6CB2FF", "effect": "none", "box": True, "stroke": False, "size": "piccoli"},
        "texts": {"per_min": 0.3, "when": "nome dell'ospite e argomenti", "color": "#FFFFFF", "box": True},
        "graphics": {"per_min": 0, "when": "", "types": [], "prompt_style": ""},
        "broll": {"per_min": 0, "when": ""},
        "hook": "apri con la frase più forte dell'intervista",
        "rules": ["niente effetti invadenti"],
    },
}
LEVELS = {"scatto": ("snap", "cut"), "morbido": ("smooth", "smooth"), "lento": ("ramp", "cut")}


def presets():
    return [{"id": "p:" + k, "name": v["name"], "icon": v.get("icon"), "summary": v["summary"], "builtin": True} for k, v in PRESETS.items()]


def style_by_id(sid):
    """"p:business" -> stile pronto; "f:<formato>" -> stile imparato dai video di un formato."""
    sid = str(sid or "p:business")
    if sid.startswith("s:"):
        from . import account as ACC
        for x in ACC.shared_styles():
            if str(x.get("id")) == sid[2:] and isinstance(x.get("style"), dict):
                return dict(clean_style(x["style"]), name=x.get("name"))
        raise ai.AIError("Questo stile della community non è più disponibile: scegline un altro")
    if sid.startswith("f:"):
        from . import formats as FM
        fm = FM.get(sid[2:])
        st = fm.get("editStyle")
        if not st:
            raise ai.AIError("Questo formato non ha ancora uno stile di montaggio: aprilo in Formati e premi \"Analizza lo stile\"")
        return dict(st, name=fm.get("name"))
    return PRESETS.get(sid[2:] if sid.startswith("p:") else sid) or PRESETS["business"]


# ------------------------------------------------------------------ stile imparato dai video di riferimento
def style_grid(path, dur, shots, out, n=8):
    """8 fotogrammi del video (uno per inquadratura, sparsi) in una griglia 4x2: l'AI ci vede sottotitoli, zoom, grafiche."""
    import cv2
    import numpy as np
    if os.path.isfile(out):
        return out
    pts = sorted(set([min(dur - 0.1, (a + b) / 2) for a, b in zip([0.0] + list(shots), list(shots) + [dur]) if b - a > 0.15]))
    if len(pts) > n:
        pts = [pts[round(i * (len(pts) - 1) / (n - 1))] for i in range(n)]
    while len(pts) < n:
        pts.append(dur * (len(pts) + 0.5) / n)
    pts = sorted(pts)[:n]
    tiles = []
    for t in pts:
        r = subprocess.run([ffmpeg_bin(), "-v", "error", "-ss", f"{max(0.0, t):.2f}", "-i", path, "-frames:v", "1", "-vf", "scale=420:-2",
                            "-f", "image2pipe", "-c:v", "png", "-"], capture_output=True, creationflags=NO_WINDOW)
        im = cv2.imdecode(np.frombuffer(r.stdout, np.uint8), cv2.IMREAD_COLOR) if r.stdout else None
        if im is not None:
            tiles.append(im)
    if not tiles:
        return None
    h = max(t.shape[0] for t in tiles)
    tiles = [cv2.copyMakeBorder(t, 0, h - t.shape[0], 0, 0, cv2.BORDER_CONSTANT, value=(20, 20, 20)) for t in tiles]
    while len(tiles) % 4:
        tiles.append(np.full_like(tiles[0], 20))
    rows = [np.hstack(tiles[i:i + 4]) for i in range(0, len(tiles), 4)]
    grid = np.vstack(rows)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    cv2.imwrite(out, grid, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return out


def _pauses(segs):
    gaps = []
    for x, y in zip(segs, segs[1:]):
        g = float(y["a"]) - float(x["b"])
        if g > 0.25:
            gaps.append(g)
    return gaps


STYLE_SCHEMA = (
    '{"summary": "2-3 frasi: com\'è montato e perché funziona",'
    ' "pace": {"pauses": "tutte|lunghe|nessuna", "max_pause_sec": 0.3, "cut_every_sec": 2.5, "notes": "come tagliano"},'
    ' "zoom": {"per_min": 6, "level": 1.25, "style": "scatto|morbido|lento", "when": "su cosa zoomano"},'
    ' "captions": {"on": true, "mode": "parola|poche|frase", "position": "centro|basso", "font": "uno tra: ' + ", ".join(FONTS) + '",'
    ' "upper": false, "color": "#FFFFFF", "highlight": "#FFD60A", "effect": "highlight|pop|none", "box": false, "stroke": true, "size": "piccoli|medi|grandi"},'
    ' "texts": {"per_min": 1.5, "when": "quando compaiono scritte oltre ai sottotitoli", "color": "#FFFFFF", "box": true},'
    ' "graphics": {"per_min": 1.5, "when": "quando compaiono grafiche/immagini", "types": ["tipi di grafiche"],'
    ' "prompt_style": "stile visivo delle grafiche in inglese, per un generatore di immagini"},'
    ' "broll": {"per_min": 0.5, "when": "quando usano spezzoni di altre scene"},'
    ' "hook": "come montano i primi 3 secondi", "rules": ["3-6 regole di montaggio concrete"]}')


def analyze_style(fm, cfg, cancel=None):
    """Lo stile di montaggio dei video pronti di un formato: numeri misurati + fotogrammi guardati dall'AI."""
    from . import formats as FM
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto" and v.get("path") and os.path.isfile(v["path"])]
    if not vids:
        raise ai.AIError("Nessun video pronto: aggiungi e analizza almeno un video di riferimento")
    order = {"top": 0, "ok": 1, "new": 2, "": 2, "flop": 3}
    vids.sort(key=lambda v: order.get(v.get("rating") or "", 2))
    vids = vids[:6]
    grids, lines = [], []
    for n, v in enumerate(vids, 1):
        dur = min(float(v.get("dur") or 0) or 1.0, FM.SAMPLE_SEC)
        shots = v.get("shots") or []
        g = style_grid(v["path"], dur, shots, os.path.join(FM._dir(fm["id"]), "video", v["id"], "stile.jpg"))
        if g:
            grids.append(g)
        segs = v.get("transcript") or []
        gaps = _pauses(segs)
        lines.append(f"VIDEO {n} (immagine {len(grids)}): durata {dur:.0f}s · {len(shots)} cambi di inquadratura (uno ogni {dur / max(1, len(shots)):.1f}s, "
                     f"{len(shots) / dur * 60:.0f} al minuto) · {v.get('wps') or '?'} parole al secondo · pause oltre 0,25s: {len(gaps)} "
                     f"(media {sum(gaps) / len(gaps) if gaps else 0:.2f}s) · risultato: {v.get('rating') or 'non indicato'}\n"
                     f"Inizio: {' '.join(s['t'] for s in segs if s['a'] < 6)[:240]}")
    system = ("Sei un montatore video esperto di YouTube, TikTok e Reels. Ricevi i numeri misurati di alcuni video di riferimento e, per ognuno, "
              "una griglia di 8 fotogrammi presi in momenti diversi. Guarda i fotogrammi con attenzione: come sono fatti i sottotitoli (font, colori, "
              "maiuscole, parole evidenziate, posizione, quante parole per volta), se l'inquadratura cambia (zoom, punch-in), scritte e grafiche a "
              "schermo, b-roll, colori. Ricava lo STILE DI MONTAGGIO comune, da riusare su video nuovi. Scrivi in italiano (tranne prompt_style in inglese). "
              "Rispondi SOLO con JSON:\n" + STYLE_SCHEMA)
    user = f"Tipo di video: {FM.KINDS.get(fm.get('kind'), fm.get('kind'))}\n\n" + "\n\n".join(lines)
    raw = ai.text(cfg, system, user, max_tokens=3000, cancel=cancel, images=grids)
    st = ai.parse_json(raw)
    if not isinstance(st, dict):
        raise ai.AIError("L'AI non ha risposto con uno stile valido: riprova")
    st["from"] = {"videos": len(vids), "grids": len(grids)}
    return clean_style(st)


def estimate_style(fm):
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"][:6]
    return {"videos": len(vids), "tokensIn": 1500 + 1700 * len(vids), "tokensOut": 1200}


def _num(v, lo, hi, d):
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return d


def clean_captions(c):
    """Lo stile dei sottotitoli con valori sicuri (font della lista, colori #RRGGBB, scelte ammesse)."""
    hexc = lambda x, d: x if isinstance(x, str) and re.match(r"^#[0-9a-fA-F]{6}$", x) else d
    return {"on": c.get("on") is not False, "mode": c.get("mode") if c.get("mode") in ("parola", "poche", "frase") else "poche",
            "position": c.get("position") if c.get("position") in ("centro", "basso") else "basso",
            "font": c.get("font") if c.get("font") in FONTS else "Montserrat", "upper": bool(c.get("upper")),
            "color": hexc(c.get("color"), "#FFFFFF"), "highlight": hexc(c.get("highlight"), "#FFD60A"),
            "effect": c.get("effect") if c.get("effect") in ("highlight", "pop", "none") else "highlight",
            "box": bool(c.get("box")), "stroke": c.get("stroke") is not False,
            "size": c.get("size") if c.get("size") in ("piccoli", "medi", "grandi") else "medi"}


def clean_style(st):
    """Valori sicuri (l'AI a volte sbaglia i tipi o esagera)."""
    b = PRESETS["business"]
    out = {"summary": str(st.get("summary") or "")[:600]}
    p = st.get("pace") or {}
    out["pace"] = {"pauses": p.get("pauses") if p.get("pauses") in ("tutte", "lunghe", "nessuna") else "tutte",
                   "max_pause_sec": _num(p.get("max_pause_sec"), 0.15, 2.0, 0.35), "cut_every_sec": _num(p.get("cut_every_sec"), 0.5, 30, 3),
                   "notes": str(p.get("notes") or "")[:300]}
    z = st.get("zoom") or {}
    out["zoom"] = {"per_min": _num(z.get("per_min"), 0, 30, 4), "level": _num(z.get("level"), 1.05, 2.0, 1.25),
                   "style": z.get("style") if z.get("style") in LEVELS else "scatto", "when": str(z.get("when") or "")[:300]}
    out["captions"] = clean_captions(st.get("captions") or {})
    hexc = lambda x, d: x if isinstance(x, str) and re.match(r"^#[0-9a-fA-F]{6}$", x) else d
    t = st.get("texts") or {}
    out["texts"] = {"per_min": _num(t.get("per_min"), 0, 10, 1), "when": str(t.get("when") or "")[:300], "color": hexc(t.get("color"), "#FFFFFF"),
                    "box": bool(t.get("box"))}
    g = st.get("graphics") or {}
    out["graphics"] = {"per_min": _num(g.get("per_min"), 0, 10, 1), "when": str(g.get("when") or "")[:300],
                       "types": [str(x)[:60] for x in (g.get("types") or [])][:6] if isinstance(g.get("types"), list) else [],
                       "prompt_style": str(g.get("prompt_style") or b["graphics"]["prompt_style"])[:300]}
    r = st.get("broll") or {}
    out["broll"] = {"per_min": _num(r.get("per_min"), 0, 10, 0), "when": str(r.get("when") or "")[:300]}
    out["hook"] = str(st.get("hook") or "")[:300]
    out["rules"] = [str(x)[:200] for x in (st.get("rules") or [])][:8] if isinstance(st.get("rules"), list) else []
    if st.get("from"):
        out["from"] = st["from"]
    return out


# ------------------------------------------------------------------ il piano delle modifiche
def words_of(proj):
    """Le parole ancora nel video (non tagliate), in ordine, con i tempi della timeline."""
    out = []
    for si, sg in enumerate(((proj.get("transcript") or {}).get("segments")) or []):
        for wi, w in enumerate(sg.get("words") or []):
            if w.get("del"):
                continue
            t = str(w.get("w") or "").strip()
            if t:
                out.append({"w": t, "a": float(w.get("a", 0)), "b": float(w.get("b", 0)), "k": f"{si}_{wi}"})
    return out


def removed_ranges(proj):
    rs = [(float(s["a"]), float(s["b"])) for s in proj.get("segs") or [] if s.get("removed")]
    return sorted(rs)


def _inside(t, rs):
    return any(a - 0.01 <= t <= b + 0.01 for a, b in rs)


AMOUNTS = {"pochi": 0.5, "normali": 1.0, "tanti": 1.8}


def clean_levels(lv):
    """Le scelte del pannello AI: quanto tagliare e quanti zoom/scritte/grafiche, che tipi di grafica."""
    lv = lv if isinstance(lv, dict) else {}
    out = {"pauses": lv.get("pauses") if lv.get("pauses") in ("silenzi", "stile", "tutte") else "stile",
           "cuts": lv.get("cuts") if lv.get("cuts") in ("leggeri", "normali", "decisi") else "normali"}
    for k in ("zooms", "texts", "graphics", "motions"):
        out[k] = lv.get(k) if lv.get(k) in AMOUNTS else "normali"
    out["mtpls"] = [k for k in (lv.get("mtpls") or []) if k in MOTION_TPLS] or list(MOTION_TPLS)
    out["mkind"] = lv.get("mkind") if lv.get("mkind") in ("custom", "tpl") else "custom"   # animazioni su misura o modelli pronti
    out["maccent"] = lv.get("maccent") if re.fullmatch(r"#[0-9A-Fa-f]{6}", str(lv.get("maccent") or "")) else "#4F8CFF"
    out["zstyle"] = lv.get("zstyle") if lv.get("zstyle") in ("auto", "lento", "morbido", "scatto") else "auto"
    out["gstyle"] = lv.get("gstyle") if lv.get("gstyle") in ICON_STYLES else "pro"
    out["looks"] = [k for k in (lv.get("looks") or []) if k in TEXT_LOOKS] or list(DEFAULT_LOOKS)
    kinds = [k for k in (lv.get("gkinds") or []) if k in GRAPHIC_KINDS]
    out["gkinds"] = kinds or list(GRAPHIC_KINDS)
    return out


def find_pauses(words, style, dur, rs, level="stile"):
    """Buchi tra le parole piu' lunghi di quanto vuole lo stile (+ silenzio all'inizio e alla fine)."""
    p = style.get("pace") or {}
    mx = float(p.get("max_pause_sec") or 0.35)
    if p.get("pauses") == "lunghe":
        mx = max(mx, 0.7)
    # i silenzi lunghi non servono mai: anche con "nessuna" (o uno stile letto male dai reference) si tolgono sopra 1,2 s
    mx = 1.2 if p.get("pauses") == "nessuna" else min(mx, 0.7)
    if level == "silenzi":
        mx = 1.0
    elif level == "tutte":
        mx = 0.3
    pad = 0.08
    out = []
    if words and words[0]["a"] > 0.6:
        out.append((0.0, max(0.0, words[0]["a"] - 0.15)))
    for x, y in zip(words, words[1:]):
        a, b = x["b"] + pad, y["a"] - pad
        if y["a"] - x["b"] > mx and b - a > 0.12:
            out.append((a, b))
    if words and dur - words[-1]["b"] > 0.8:
        out.append((words[-1]["b"] + 0.3, dur))
    return [(round(a, 3), round(b, 3)) for a, b in out if not (_inside(a, rs) and _inside(b, rs))]


PLAN_SCHEMA = (
    '{"summary": "2 frasi: cosa hai fatto e perché",'
    ' "cuts": [{"from": 12, "to": 19, "why": "ripetizione|errore|frase ricominciata|parte morta|fuori tema"}],'
    ' "zooms": [{"from": 40, "to": 52, "why": "breve motivo"}],'
    ' "texts": [{"from": 80, "to": 86, "text": "SCRITTA *BREVE*", "look": "uno dei look ammessi", "why": "breve motivo"}],'
    ' "motions": [{"from": 60, "to": 66, "tpl": "numero|barre|linea|lista|confronto|passi|progresso", "title": "titolo breve", "value": "+40%",'
    ' "items": [{"label": "etichetta", "value": "12"}]}],'
    ' "graphics": [{"from": 120, "to": 131, "kind": "icona|grafico|tabella|schema|freccia|emoji", "prompt": "english description of the graphic asset",'
    ' "label": "etichette brevi nella lingua del video (solo grafico/tabella/schema)", "place": "centro|alto|lato", "why": "breve motivo"}]}')

MOTION_SCHEMA_TPL = ('"motions": [{"from": 60, "to": 66, "tpl": "numero|barre|linea|lista|confronto|passi|progresso", "title": "titolo breve", "value": "+40%",'
                     ' "items": [{"label": "etichetta", "value": "12"}]}]')
MOTION_SCHEMA_FX = ('"motions": [{"from": 60, "to": 66, "tpl": "id del componente (oppure ometti e usa idea)", "title": "titolo breve", "value": "+40%",'
                    ' "items": [{"label": "etichetta", "value": "12"}]}, {"from": 90, "to": 96, "idea": "english description of the custom animation",'
                    ' "text": "max 3 parole", "why": "breve motivo"}]')
assert MOTION_SCHEMA_TPL in PLAN_SCHEMA

# look dei titoli animati (text.js TITLE_PRESETS) e tipi di grafica
TEXT_LOOKS = ("guru", "yellow", "punch", "orange", "premium", "breaking", "greenhl", "caption", "wow", "clean", "tag", "minimal")
DEFAULT_LOOKS = ("clean", "tag", "caption", "guru")
# grafiche animate disegnate da NoonFrame (web/motion.js): gratis, niente AI per le immagini
MOTION_TPLS = {
    "numero": "numero = una cifra che conta (value: la cifra con simboli, es. \"+40%\" o \"10.000€\"; title: di cosa)",
    "barre": "barre = grafico a barre (items: 2-5 con label corta e value numerico)",
    "linea": "linea = crescita nel tempo (items: 3-6 value numerici in ordine; value: il valore finale da mostrare)",
    "lista": "lista = checklist (items: 2-4 label brevi)",
    "confronto": "confronto = due colonne, la seconda e' quella giusta (2 items: label = nome, value = frase brevissima)",
    "passi": "passi = passaggi di un metodo (items: 2-5 label di 1-2 parole)",
    "progresso": "progresso = percentuale in un anello (value: es. \"68%\"; title)",
    "imbuto": "imbuto = da tanti a pochi, un funnel (items: 3-5 fasi con label e value numerico decrescente; title)",
    "tempo": "tempo = linea del tempo (items: 2-5 tappe con label = anno o data e value = cosa e' successo in 1-3 parole; title)",
    "freccia": "freccia = da un valore a un altro (2 items: label = valore di partenza e di arrivo; value: il salto, es. \"x10\"; title)",
    "equazione": "equazione = formula A + B = risultato (items: 2-3 label di 1-2 parole; value: il risultato)",
    "proporzione": "proporzione = omini che si colorano (value: es. \"3 su 10\" o \"30%\"; title: chi sono)",
    "ciclo": "ciclo = passaggi che si ripetono in cerchio, un volano (items: 3-5 label di 1-2 parole; title)",
    "piramide": "piramide = livelli dalla base alla cima (items: 3-4 label, il primo e' la base; title)",
    "podio": "podio = classifica primo-secondo-terzo (items: 3 label in ordine dal primo; title)",
    "citazione": "citazione = una frase forte detta nel video, grande (title: la frase, max 8 parole; value: chi l'ha detta o vuoto)",
    "torta": "torta = ripartizione in percentuali (items: 2-4 label con value percentuale; title)",
}


def clean_motion(m, accent="#4F8CFF"):
    m = m if isinstance(m, dict) else {}
    items = [{"label": str((i or {}).get("label") or "")[:40], "value": str((i or {}).get("value") if (i or {}).get("value") is not None else "")[:20]}
             for i in (m.get("items") or [])[:5] if isinstance(i, dict)]
    for i, src in zip(items, [x for x in (m.get("items") or [])[:5] if isinstance(x, dict)]):
        if isinstance(src.get("t"), (int, float)):
            i["t"] = float(src["t"])
    return {"tpl": m.get("tpl") if m.get("tpl") in MOTION_TPLS else "numero", "title": str(m.get("title") or "")[:72 if m.get("tpl") == "citazione" else 48],
            "value": str(m.get("value") if m.get("value") is not None else "")[:16], "items": items, "accent": accent}
# stili delle grafiche (le anteprime sono nel pannello AI dell'editor)
ICON_STYLES = {
    "pro": "premium corporate style: flat vector with subtle gradients, deep navy, white and one accent color, thin clean shapes, minimal, "
           "serious and elegant like a McKinsey or Apple keynote slide, NOT cartoonish, NOT playful",
    "line": "minimal line icon style: thin uniform white strokes with one accent color, lots of negative space, elegant and technical",
    "glass": "glassmorphism style: frosted translucent glass panels, soft blue and violet glow, modern fintech app look, elegant",
    "flat": "flat design: solid simple shapes, bold but balanced colors, no gradients, clean like a modern infographic",
    "3d": "glossy 3D render with soft studio lighting, colorful and friendly",
    "neon": "neon style: dark shapes with glowing cyan and magenta outlines, futuristic tech look",
}
GRAPHIC_KINDS = {
    "icona": "a single icon",
    "grafico": "a clean modern infographic chart (bar chart or rising line chart) with bold colors",
    "tabella": "a clean modern table / checklist card, like a sleek app UI card",
    "schema": "a simple diagram with rounded boxes connected by arrows",
    "freccia": "a bold arrow",
    "emoji": "an emoji-style sticker",
}


RETRY = ("\n\nIMPORTANTE: la risposta di prima non era JSON valido o era troppo lunga. Rispondi SOLO con il JSON, completo e "
         "chiuso, senza testo prima o dopo. \"why\" di massimo 3 parole. Meglio meno elementi ma un JSON valido.")


def read_plan(raw):
    """Il piano dalla risposta dell'AI, anche se e' tagliata a meta' (risposta troppo lunga): si tengono gli elementi completi."""
    try:
        obj = ai.parse_json(raw)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    t = raw or ""
    keys = ["summary", "cuts", "zooms", "texts", "graphics"]
    pos = sorted((t.find('"' + k + '"'), k) for k in keys if t.find('"' + k + '"') >= 0)
    if not pos:
        return None
    out = {}
    for n, (p, k) in enumerate(pos):
        end = pos[n + 1][0] if n + 1 < len(pos) else len(t)
        part = t[p:end]
        if k == "summary":
            m = re.search(r'"summary"\s*:\s*"((?:[^"\\]|\\.)*)"', part)
            out["summary"] = json.loads('"' + m.group(1) + '"') if m else ""
            continue
        items = []
        for m in re.finditer(r"\{[^{}]*\}", part):
            try:
                items.append(json.loads(m.group(0)))
            except Exception:
                try:
                    items.append(json.loads(ai._repair_json(m.group(0))))
                except Exception:
                    continue
        out[k] = items
    return out if any(out.get(k) for k in keys[1:]) or out.get("summary") else None


def _chunks(words, size=1500):
    for i in range(0, len(words), size):
        yield i, words[i:i + size]


FILLERS = {"ehm", "eh", "ehh", "ehmm", "uhm", "um", "umm", "uh", "mmm", "mm", "mh", "emm", "ahm", "hmm", "ah"}


def _fillers(words, rs):
    """Esitazioni (ehm, uhm...) tagliate sempre, senza AI: sono parole da sole."""
    out = []
    for w in words:
        t = re.sub(r"[^\wàèéìòù]", "", w["w"].lower())
        if t in FILLERS and w["b"] - w["a"] < 1.5 and not _inside((w["a"] + w["b"]) / 2, rs):
            out.append({"type": "cut", "a": round(w["a"] - 0.03, 3), "b": round(w["b"] + 0.03, 3), "why": "esitazione", "text": w["w"]})
    return out


# modelli per le immagini del montaggio AI (si sceglie nello studio). transparent: lo sfondo arriva gia' trasparente
GRAPHIC_MODELS = [
    {"id": "ideogram", "provider": "fal", "model": "fal-ai/ideogram/v3/generate-transparent", "name": "Ideogram 3", "usd": 0.06,
     "note": "Sfondo già trasparente e bordi puliti, scrive bene i testi", "transparent": True},
    {"id": "recraft", "provider": "fal", "model": "fal-ai/recraft/v3/text-to-image", "name": "Recraft V3", "usd": 0.04,
     "note": "Fatto per icone e grafiche da designer"},
    {"id": "nano", "provider": "fal", "model": "fal-ai/nano-banana-2", "name": "Nano Banana 2", "usd": 0.08, "note": "Google, versatile"},
    {"id": "flux", "provider": "fal", "model": "fal-ai/flux/dev", "name": "FLUX dev", "usd": 0.025, "note": "Il più economico"},
    {"id": "gptimage", "provider": "openai", "model": "gpt-image-1", "name": "GPT Image", "usd": 0.25, "note": "OpenAI, molto preciso"},
    {"id": "gemini", "provider": "gemini", "model": "gemini-2.5-flash-image", "name": "Gemini Flash Image", "usd": 0.039, "note": "Google, economico"},
]


def graphic_models():
    keys = ai.keys_status()
    return [dict(m, ok=bool(keys.get(m["provider"], {}).get("set"))) for m in GRAPHIC_MODELS]


def graphic_cfg(mid):
    m = next((x for x in GRAPHIC_MODELS if x["id"] == mid), None)
    return {"provider": m["provider"], "model": m["model"], "transparent": bool(m.get("transparent"))} if m else None


NUMW = {"0": "zero", "1": "uno", "2": "due", "3": "tre", "4": "quattro", "5": "cinque", "6": "sei", "7": "sette", "8": "otto", "9": "nove",
        "10": "dieci", "20": "venti", "30": "trenta", "50": "cinquanta", "100": "cento", "1000": "mille"}


def _norm(x):
    return re.sub(r"[^\wàèéìòù%]", "", str(x).lower())


def _sync_motion(items, words):
    """Gli elementi di una grafica animata compaiono quando vengono detti (tempo della parola nel video)."""
    for it in items:
        if it["type"] != "motion" or not it["mg"].get("items"):
            continue
        ws = [w for w in words if it["a"] - 0.5 <= w["a"] <= it["b"] + 4]
        found, pos = [], 0
        for el in it["mg"]["items"]:
            cands = set()
            for txt in (el.get("label"), el.get("value")):
                for tok in str(txt or "").split():
                    n = _norm(tok)
                    if not n:
                        continue
                    cands.add(n)
                    num = re.match(r"^(\d+)", n)
                    if num:
                        cands.add(num.group(1))
                        if num.group(1) in NUMW:
                            cands.add(NUMW[num.group(1)])
            t = None
            for j in range(pos, len(ws)):
                if _norm(ws[j]["w"]) in cands:
                    t, pos = ws[j]["a"] - it["a"], j + 1
                    break
            found.append(t)
        if not any(t is not None for t in found):
            continue
        # quelli non trovati: in mezzo tra i vicini
        last = 0.2
        for i, t in enumerate(found):
            if t is None:
                nxt = next((x for x in found[i + 1:] if x is not None), None)
                found[i] = last + 0.35 if nxt is None else (last + nxt) / 2
            last = found[i] = max(0.05, found[i])
        for el, t in zip(it["mg"]["items"], found):
            el["t"] = round(t, 2)
        it["b"] = round(min(it["a"] + 9, max(it["b"], it["a"] + max(found) + 1.4)), 3)


def _sync_fx(items, words):
    """Animazioni su misura e grafiche: partono quando si dice la parola chiave (non qualche secondo prima o dopo)."""
    for it in items:
        if it["type"] not in ("fx", "motion"):
            continue
        key = it.get("text") if it["type"] == "fx" else (it.get("mg") or {}).get("value") or (it.get("mg") or {}).get("title")
        toks = []
        for tok in str(key or "").replace("*", " ").split():
            n = _norm(tok)
            if not n or len(n) < 2:
                continue
            toks.append(n)
            num = re.match(r"^(\d+)", n)
            if num:
                toks.append(num.group(1))
                if num.group(1) in NUMW:
                    toks.append(NUMW[num.group(1)])
        if not toks:
            continue
        ws = [w for w in words if it["a"] - 4 <= w["a"] <= it["b"] + 2]
        hit = next((w for w in ws if _norm(w["w"]) in toks), None)
        if not hit:
            continue
        ln = it["b"] - it["a"]
        a = max(0.0, hit["a"] - 0.35)   # appena prima della parola: si vede mentre lo dici
        it["a"], it["b"] = round(a, 3), round(a + max(3.0, ln), 3)


def _prev_lines(prev, words, lo, hi):
    """Il piano attuale (da modificare con la chat) scritto con gli indici delle parole di questa parte."""
    def idx(t):
        best, bd = lo, 1e9
        for i in range(lo, hi + 1):
            d = abs(words[i]["a"] - t)
            if d < bd:
                best, bd = i, d
        return best
    out = []
    for it in prev or []:
        try:
            a, b = float(it.get("a")), float(it.get("b"))
        except (TypeError, ValueError):
            continue
        if b < words[lo]["a"] - 1 or a > words[hi]["b"] + 1 or it.get("type") == "pause":
            continue
        extra = it.get("text") or it.get("title") or it.get("prompt") or ""
        out.append(f"- {it.get('type')} {idx(a)}-{idx(b)}" + (f" \"{str(extra)[:60]}\"" if extra else "") + (f" ({it.get('tpl')})" if it.get("tpl") else ""))
    return out[:120]


INTENT_KINDS = ("pauses", "cuts", "zooms", "texts", "graphics", "motions")


def intent(proj, style, prompt, cfg, vertical=False, cancel=None):
    """Una richiesta scritta nella chat: prima si capisce cosa chiede davvero (solo lo stile dei sottotitoli? tagli? zoom?
    una domanda?), poi si fa solo quello. Costa poco: legge la richiesta e l'inizio del parlato.
    -> {"reply", "do": {pauses, cuts, ...}, "full", "captions": {...} | None, "why", "usd"}"""
    words = words_of(proj)
    dur = float(proj.get("duration") or (words[-1]["b"] if words else 0))
    sample = " ".join(w["w"] for w in words[:350])
    cur = style.get("captions") or {}
    system = (
        "Sei l'Assistente AI di NoonFrame, un editor video per creator. L'utente ti scrive una richiesta su un video: capisci cosa vuole "
        "davvero e decidi cosa fare, SOLO quello che chiede.\n"
        "Strumenti (do):\n"
        "- pauses: togliere pause e silenzi\n- cuts: tagliare errori, ripetizioni, parti lente o un pezzo preciso\n"
        "- zooms: zoom sulle frasi chiave\n- texts: titoli e scritte a schermo\n- graphics: immagini e icone sopra il video\n"
        "- motions: grafiche animate (numeri, elenchi, confronti)\n"
        "In piu' captions: lo stile dei sottotitoli (font, grandezza, colori, maiuscolo, quante parole alla volta, effetto, posizione).\n"
        "REGOLE:\n"
        "- Se parla di font, sottotitoli, colori o stile delle scritte: compila captions e lascia tutti i do a false.\n"
        "- Se chiede consigli sullo stile (\"le impostazioni che mi consigli\"): scegli captions adatti al tipo di video, al pubblico e al "
        "formato, e lascia i do a false (gli altri strumenti li proponi nella risposta, non li usi).\n"
        "- Se chiede di montare il video in generale (\"montalo\", \"rendilo piu' dinamico\", \"fai tu\"): full = true.\n"
        "- Se chiede una cosa precisa (\"togli l'intro\", \"meno zoom\", \"un titolo quando parlo del prezzo\"): metti true SOLO gli strumenti che servono.\n"
        "- Se e' una domanda sul video o qualcosa che questi strumenti non fanno: rispondi in reply e lascia tutto false.\n"
        "CONSIGLI PER I SOTTOTITOLI: gaming, reaction e live: font d'impatto (Bebas Neue, Anton, Luckiest Guy, Bangers, Russo One, Lilita One, "
        "Teko), grandi, maiuscolo, una parola o poche alla volta, parola detta in un colore acceso, effetto pop, contorno. Podcast e interviste: "
        "Montserrat o Poppins, medi, poche parole, parola evidenziata. Business, tutorial e formazione: Inter, Montserrat o Outfit, sobri, "
        "poche parole o frase intera. Vlog e lifestyle: Poppins, Kanit o Rubik. In verticale (9:16) stanno meglio al centro, in orizzontale in basso.\n"
        "reply: 1 o 2 frasi brevi nella STESSA LINGUA della richiesta, dirette, senza elenchi: cosa fai e perche' "
        "(es. \"Per un video gaming ti metto Bebas Neue grande e in maiuscolo, una parola alla volta con la parola detta in giallo: "
        "si legge al volo anche da telefono.\"). Non promettere cose che non fai.\n"
        "Rispondi SOLO con JSON: {\"reply\": \"...\", \"full\": false, \"do\": {\"pauses\": false, \"cuts\": false, \"zooms\": false, "
        "\"texts\": false, \"graphics\": false, \"motions\": false}, \"captions\": null oppure {\"font\": \"uno tra " + ", ".join(FONTS) + "\", "
        "\"size\": \"piccoli|medi|grandi\", \"position\": \"centro|basso\", \"mode\": \"parola|poche|frase\", \"upper\": true, "
        "\"color\": \"#FFFFFF\", \"highlight\": \"#FFD60A\", \"effect\": \"highlight|pop|none\", \"box\": false, \"stroke\": true, "
        "\"why\": \"motivo in massimo 8 parole, nella lingua della richiesta\"}}")
    user = (f"RICHIESTA: {prompt.strip()[:800]}\n\nVIDEO: {'verticale 9:16' if vertical else 'orizzontale'}, {dur / 60:.1f} minuti. "
            f"Stile di montaggio scelto: {style.get('name') or ''}. Sottotitoli di adesso: {json.dumps(cur, ensure_ascii=False)}.\n"
            f"INIZIO DEL PARLATO: {sample}")
    raw = ai.text(cfg, system, user, max_tokens=900, cancel=cancel)
    usd = ai.text_usd(cfg.get("model"), system, user, raw)
    try:
        obj = ai.parse_json(raw)
    except Exception:
        obj = None
    if not isinstance(obj, dict):
        raise ai.AIError("L'AI ha risposto in modo non leggibile: riprova")
    d = obj.get("do") if isinstance(obj.get("do"), dict) else {}
    c = obj.get("captions") if isinstance(obj.get("captions"), dict) else None
    return {"reply": str(obj.get("reply") or "").strip()[:500], "full": bool(obj.get("full")),
            "do": {k: d.get(k) is True for k in INTENT_KINDS}, "captions": clean_captions(c) if c else None,
            "why": str((c or {}).get("why") or "").strip()[:120], "usd": round(usd, 4)}


def plan(proj, style, prompt="", opts=None, cfg=None, cancel=None, progress=None, prev=None):
    """-> {"summary", "items": [...], "usd"}; items: {id, type, a, b, ...} in tempi della timeline.
    prev: il piano attuale (lista di elementi) quando si chiede una modifica con la chat."""
    opts = opts or {}
    lv = opts.get("lv") or clean_levels(None)
    words = words_of(proj)
    if len(words) < 5:
        raise ai.AIError("Serve la trascrizione del video: premi \"Trascrivi il video\" e riprova")
    dur = float(proj.get("duration") or words[-1]["b"])
    rs = removed_ranges(proj)
    items = []
    if opts.get("pauses", True):
        for a, b in find_pauses(words, style, dur, rs, lv["pauses"]):
            items.append({"type": "pause", "a": a, "b": b, "why": "pausa"})
    if opts.get("cuts", True):
        items += _fillers(words, rs)
    want_ai = any(opts.get(k, True) for k in ("cuts", "zooms", "texts", "graphics", "motions"))
    summary, usd = "", 0.0
    if want_ai:
        minutes = max(0.3, (words[-1]["b"] - words[0]["a"]) / 60)
        z, t, g = style.get("zoom") or {}, style.get("texts") or {}, style.get("graphics") or {}
        amt = lambda k, per: max(1, round(float(per or 1) * minutes * AMOUNTS[lv[k]])) if opts.get(k, True) else 0
        n_z, n_t, n_g = amt("zooms", z.get("per_min")), amt("texts", t.get("per_min")), amt("graphics", g.get("per_min"))
        n_m = amt("motions", (style.get("motions") or {}).get("per_min") or 1.2)
        cut_rule = {"leggeri": "Tagli LEGGERI: togli solo errori evidenti, frasi ricominciate e ripetizioni; tieni il resto. ",
                    "normali": "", "decisi": "Tagli DECISI: togli tutto il superfluo (riempitivi, giri di parole, ripetizioni di concetti), "
                                           "di solito dal 20 al 35% del parlato, senza perdere il filo. "}[lv["cuts"]]
        kinds_rule = ("" if len(lv["gkinds"]) == len(GRAPHIC_KINDS) else
                      "Grafiche: kind SOLO tra " + ", ".join(lv["gkinds"]) + ". ")
        LD = {"clean": "clean = bianco elegante con la parola chiave colorata", "tag": "tag = etichetta scura arrotondata",
              "caption": "caption = didascalia bianca", "minimal": "minimal = piccolo e spaziato, molto sobrio",
              "guru": "guru = parola evidenziata gialla", "yellow": "yellow = parole gialle a colpi", "punch": "punch = riquadro rosso",
              "orange": "orange = arancio luminoso", "premium": "premium = oro luminoso", "breaking": "breaking = barra rossa",
              "greenhl": "greenhl = parola verde", "wow": "wow = titolo 3D cartoon"}
        looks_desc = ", ".join(LD[k] for k in lv.get("looks") or DEFAULT_LOOKS if k in LD)
        system = ("Sei il miglior montatore di YouTube: i tuoi video tengono l'attenzione dal primo all'ultimo secondo e sembrano fatti da "
                  "un professionista, mai da un software. Ricevi la trascrizione: ogni parola ha un numero (indice); ogni riga inizia con il tempo "
                  "in secondi e le pause lunghe sono segnate. Prepara il montaggio seguendo lo STILE, usando SOLO gli indici delle parole.\n"
                  "COME RAGIONI: prima capisci di cosa parla il video e qual e' il messaggio; poi togli tutto cio' che non serve a quel messaggio; "
                  "infine aggiungi pochi elementi visivi SOLO dove rendono piu' chiaro o piu' forte un concetto preciso.\n"
                  "- cuts: frasi ricominciate (tieni SOLO l'ultima versione completa, togli i tentativi prima), ripetizioni dello stesso concetto, "
                  "divagazioni, riempitivi (\"allora\", \"diciamo\", \"praticamente\", \"cioe'\", \"niente\", \"quindi niente\"), saluti e intro "
                  "lente che non dicono niente (il video deve partire dalla prima frase che conta). INTRO E FINALE CON CURA: all'inizio togli solo i "
                  "saluti puri (\"ciao ragazzi, bentornati sul canale\"): la prima frase che resta deve essere COMPLETA e far capire subito di cosa "
                  "parla il video, mai iniziare a meta' frase; nel finale non tagliare la conclusione ne' l'invito finale, al massimo i saluti dopo. "
                  "Rileggi sempre come suona il video dopo i tagli: ogni frase deve collegarsi alla precedente e avere senso. Taglia sempre frasi o pezzi di frase interi, dalla "
                  "prima all'ultima parola da togliere comprese: mai lasciare una frase a meta'. Se un concetto viene detto due volte, tieni la "
                  "versione migliore.\n"
                  "- zooms: pochi, solo sulle frasi chiave (la promessa, il numero, la lezione). Ognuno copre tutta la frase: 4-10 secondi. Mai due "
                  "zoom a meno di 10 secondi di distanza.\n"
                  "- texts: TITOLI come quelli dei capitoli di un video YouTube: 2-4 parole che riassumono il punto che inizia li', "
                  "comprensibili anche senza audio. Buoni: \"ERRORE N.1\", \"DELEGA I *PROCESSI*\", \"*+30%* DI FATTURATO\", "
                  "\"IL METODO IN *3 STEP*\". Da NON fare: parole prese a caso dalla frase (\"il trappolone\", \"spesso i founder\"), slang, "
                  "frasi lunghe, ripetere i sottotitoli. Mettili solo all'inizio di un nuovo punto o su un numero importante. Tra asterischi la "
                  "parola da evidenziare. look: scegli tra " + looks_desc + ".\n"
                  + (("- motions: ANIMAZIONI SU MISURA in stile After Effects, disegnate apposta per quel momento. Hai due modi:\n"
                      "  1) COMPONENTI PREMIUM gia' pronti (preferiscili quando bastano: sono perfetti e leggibili): scrivi \"tpl\" e i suoi campi, "
                      "usando SOLO numeri e parole detti davvero, testi brevissimi nella lingua del video. tpl: " + ", ".join(
                          MOTION_TPLS[k] for k in lv["mtpls"]) + ".\n"
                      "  2) Solo se nessun componente rende l'idea (una metafora, un oggetto, un movimento particolare): ANIMAZIONE SU MISURA, quando nel video si dice un "
                      "dato, un processo, un confronto, una metafora o un concetto che si puo' far VEDERE. Per ognuna scrivi \"idea\": in inglese, "
                      "2-3 frasi che descrivono l'animazione precisa (cosa appare, come si muove, cosa rappresenta; es. \"a small snowball rolls "
                      "down a slope growing bigger and bigger, coins stick to it, the label grows with it\"), "
                      "mai generica; \"text\": massimo 3 parole o un numero detto davvero (nella lingua del video, o vuoto). Durata 3-6 secondi. "
                      "Preferiscile alle immagini.\n") if lv.get("mkind") == "custom" else
                     ("- motions: grafiche animate disegnate dall'app quando nel video si dice un dato concreto, un elenco, un confronto o dei passaggi. "
                      "Usa SOLO numeri e parole detti davvero, testi brevissimi nella lingua del video. tpl: " + ", ".join(
                          MOTION_TPLS[k] for k in lv["mtpls"]) + ". Durata 3-6 secondi. Preferiscile alle immagini.\n")) +
                  "- graphics: immagini PNG sopra il video, NON foto: kind = icona, grafico, tabella, schema, freccia, emoji. prompt in inglese che "
                  "descrive l'oggetto (es. \"stack of gold coins\"). label: per grafico/tabella/schema le poche parole o numeri da scrivere. "
                  "place: \"centro\", \"alto\" (piccola in alto), \"lato\" (di fianco a chi parla). Solo per concetti che un'immagine spiega meglio.\n"
                  "- TEMPI GIUSTI per texts, motions e graphics: \"from\" e' l'indice della PRIMA parola della frase in cui dici quel "
                  "concetto o quel numero (deve comparire mentre lo dici, mai prima ne' dopo), \"to\" l'ultima parola di quella frase. "
                  "Se il dato arriva a fine frase, parti comunque dall'inizio della frase che lo contiene.\n"
                  "- REGOLE DI PULIZIA: un solo elemento a schermo alla volta (scritta, grafica animata o immagine), almeno 8 secondi tra un elemento e "
                  "il successivo; niente elementi nei primi 3 secondi; distribuisci lungo tutto il video; niente zoom o elementi dentro le parti che "
                  "tagli. Meglio pochi elementi azzeccati che tanti a caso.\n"
                  "- Se c'e' un PIANO ATTUALE e una RICHIESTA: modifica il piano come chiede la richiesta e tieni uguale tutto il resto.\n"
                  "- Risposta compatta: \"why\" di massimo 3 parole, nessun campo in piu'. Il JSON deve essere completo e chiuso.\n"
                  "Rispondi SOLO con JSON:\n" + (PLAN_SCHEMA.replace(MOTION_SCHEMA_TPL, MOTION_SCHEMA_FX) if lv.get("mkind") == "custom" else PLAN_SCHEMA))
        sty = json.dumps({k: style.get(k) for k in ("summary", "pace", "zoom", "texts", "graphics", "broll", "hook", "rules")}, ensure_ascii=False)
        ask = (f"STILE:\n{sty}\n\nQuantità indicative per tutto il video ({minutes:.1f} minuti): circa {n_z} zoom, {n_t} scritte, {n_g} grafiche. "
               + (("Tagli: sì. " + cut_rule) if opts.get("cuts", True) else "Tagli: NO, lista cuts vuota. ") + kinds_rule
               + ("" if n_z else "Zoom: NO. ") + ("" if n_t else "Scritte: NO. ") + ("" if n_g else "Grafiche: NO. ") + (f"Grafiche animate: circa {n_m}. " if n_m else "Grafiche animate (motions): NO. ")
               + (f"\nRICHIESTA DELL'UTENTE (ha la precedenza): {prompt.strip()[:800]}" if (prompt or "").strip() else "")
               + ("\n(Font e stile dei sottotitoli sono gia' scelti a parte: ignora quella parte della richiesta.)" if opts.get("capsDone") else ""))
        parts = list(_chunks(words))
        failed = []
        for ci, (off, ws) in enumerate(parts):
            if cancel and cancel():
                raise ai.AIError("Annullato")
            if progress:
                progress(0.1 + 0.8 * ci / len(parts), ("Preparo le modifiche che hai chiesto" if (prompt or "").strip() else "L'AI prepara il montaggio")
                         + (f" ({ci + 1}/{len(parts)})" if len(parts) > 1 else ""))
            lines, cur, last, lastw = [], [], None, ""
            for i, w in enumerate(ws):
                gi = off + i
                gap = w["a"] - last if last is not None else 0
                if last is None or gap > 0.9 or len(cur) >= 16 or (lastw[-1:] in ".?!" and len(cur) > 3):
                    if cur:
                        lines.append(" ".join(cur))
                    cur = [f"[{w['a']:.1f}]" + (f" (pausa {gap:.1f}s)" if gap > 0.9 else "")]
                cur.append(f"{gi}:{w['w']}")
                last, lastw = w["b"], w["w"]
            if cur:
                lines.append(" ".join(cur))
            frac = len(ws) / len(words)
            part = f"\nPARTE {ci + 1} di {len(parts)} del video: usa circa il {round(frac * 100)}% delle quantità." if len(parts) > 1 else ""
            pv = _prev_lines(prev, words, off, off + len(ws) - 1) if prev else []
            user = ask + part + ("\n\nPIANO ATTUALE (modificalo secondo la richiesta):\n" + "\n".join(pv) if pv else "") + "\n\nTRASCRIZIONE:\n" + "\n".join(lines)
            raw = ai.text(cfg, system, user, max_tokens=12000, cancel=cancel)
            usd += ai.text_usd(cfg.get("model"), system, user, raw)
            obj = read_plan(raw)
            if obj is None:   # risposta rotta: si riprova una volta chiedendo JSON pulito e piu' corto
                print("[aiedit] risposta non leggibile, riprovo. Inizio:", (raw or "")[:300].replace("\n", " "), flush=True)
                raw = ai.text(cfg, system, user + RETRY, max_tokens=12000, cancel=cancel)
                usd += ai.text_usd(cfg.get("model"), system, user, raw)
                obj = read_plan(raw)
            if obj is None:
                # una parte andata male non deve buttare via tutto il lavoro: si va avanti con le altre
                print("[aiedit] ancora non leggibile. Inizio:", (raw or "")[:300].replace("\n", " "), flush=True)
                failed.append(ci)
                continue
            summary = summary or str(obj.get("summary") or "")
            items += _items_from(obj, words, off, off + len(ws) - 1, opts, style, rs)
        if failed and len(failed) == len(parts):
            raise ai.AIError("L'AI ha risposto in modo non leggibile: riprova")
        if failed:
            summary = (summary + " " if summary else "") + (f"(Una parte del video su {len(parts)} non è stata montata dall'AI: puoi ripetere solo quella con la chat.)"
                                                           if len(failed) == 1 else f"({len(failed)} parti su {len(parts)} non sono state montate dall'AI: riprova con la chat.)")
    _sync_fx(items, words)
    _sync_motion(items, words)
    items = _fit_zooms(_tidy(items, dur), rs, dur)
    for n, it in enumerate(items):
        it["id"] = f"i{n}"
    return {"summary": summary, "items": items, "usd": round(usd, 4), "words": len(words)}


def _items_from(obj, words, lo, hi, opts, style, rs):
    out = []

    def rng(x):
        try:
            i, j = int(x.get("from")), int(x.get("to", x.get("from")))
        except (TypeError, ValueError):
            return None
        i, j = max(lo, min(hi, i)), max(lo, min(hi, j))
        if j < i:
            i, j = j, i
        return words[i]["a"], words[j]["b"]
    # frasi: dove inizia e finisce ognuna (punto, domanda, esclamazione o pausa vera)
    def _ends(k):
        return k >= len(words) - 1 or words[k]["w"][-1:] in ".?!" or words[k + 1]["a"] - words[k]["b"] > 0.6
    def _starts(k):
        return k <= 0 or _ends(k - 1)
    last_start = max((k for k in range(len(words)) if _starts(k)), default=0)

    def fix_cut(x):
        """Tagli che non spezzano le frasi: se un taglio di piu' di 3 parole inizia o finisce a meta' frase, si allarga alla frase
        intera quando ne copre gia' la maggior parte, se no si ferma al bordo della frase. La conclusione finale non si tocca."""
        try:
            i, j = int(x.get("from")), int(x.get("to", x.get("from")))
        except (TypeError, ValueError):
            return None
        i, j = max(lo, min(hi, i)), max(lo, min(hi, j))
        if j < i:
            i, j = j, i
        if j - i + 1 > 3:
            if not _starts(i):
                s0 = i
                while not _starts(s0):
                    s0 -= 1
                e0 = i
                while not _ends(e0):
                    e0 += 1
                if (min(j, e0) - i + 1) >= 0.6 * (e0 - s0 + 1):
                    i = s0
                else:
                    i = e0 + 1
            if j < len(words) and not _ends(j):
                e1 = j
                while not _ends(e1):
                    e1 += 1
                s1 = j
                while not _starts(s1):
                    s1 -= 1
                if (j - max(i, s1) + 1) >= 0.6 * (e1 - s1 + 1):
                    j = e1
                else:
                    j = s1 - 1
            if j < i:
                return None
        # la frase finale (conclusione, saluto con invito) resta sempre: niente finale tagliato a meta'
        if j >= last_start and i < len(words) - 1:
            j = last_start - 1
            if j < i:
                return None
        return words[i]["a"], words[j]["b"], i, j

    if opts.get("cuts", True):
        for x in obj.get("cuts") or []:
            fx_ = fix_cut(x) if isinstance(x, dict) else None
            r = (fx_[0], fx_[1]) if fx_ else None
            if r and 0.15 < r[1] - r[0] < 90:
                out.append({"type": "cut", "a": round(r[0] - 0.04, 3), "b": round(r[1] + 0.04, 3), "why": str(x.get("why") or "")[:60],
                            "text": " ".join(w["w"] for w in words if r[0] <= w["a"] and w["b"] <= r[1])[:160]})
    lv = opts.get("lv") or {}
    zst = lv.get("zstyle") if lv.get("zstyle") in LEVELS else (style.get("zoom") or {}).get("style", "morbido")
    if opts.get("zooms", True):
        for x in obj.get("zooms") or []:
            r = rng(x) if isinstance(x, dict) else None
            if r:
                a, b = r[0], max(r[1], r[0] + 4.5)
                b = min(b, a + 12)
                out.append({"type": "zoom", "a": round(a, 3), "b": round(b, 3), "why": str(x.get("why") or "")[:80],
                            "level": (style.get("zoom") or {}).get("level", 1.25), "style": zst})
    if opts.get("texts", True):
        for x in obj.get("texts") or []:
            r = rng(x) if isinstance(x, dict) else None
            txt = str((x or {}).get("text") or "").strip()[:48]
            if r and txt:
                oklooks = lv.get("looks") or list(DEFAULT_LOOKS)
                look = x.get("look") if x.get("look") in oklooks else oklooks[len(out) % len(oklooks)]
                out.append({"type": "text", "a": round(r[0], 3), "b": round(min(max(r[1], r[0] + 2.0), r[0] + 4.5), 3), "text": txt, "look": look,
                            "why": str(x.get("why") or "")[:80]})
    if opts.get("motions", True):
        oktpl = lv.get("mtpls") or list(MOTION_TPLS)
        for x in obj.get("motions") or []:
            r = rng(x) if isinstance(x, dict) else None
            idea = str((x or {}).get("idea") or "").strip()[:700] if isinstance(x, dict) else ""
            if r and idea and lv.get("mkind") == "custom" and x.get("tpl") not in oktpl:
                # animazione su misura: il codice lo scrive l'AI quando si applica il montaggio (web: aiFx)
                out.append({"type": "fx", "a": round(r[0], 3), "b": round(min(max(r[1], r[0] + 3.0), r[0] + 6.0), 3), "idea": idea,
                            "text": str(x.get("text") or "").strip()[:40], "accent": lv.get("maccent") or "#4F8CFF", "why": str(x.get("why") or "")[:80]})
                continue
            if r and x.get("tpl") in oktpl:
                out.append({"type": "motion", "a": round(r[0], 3), "b": round(min(max(r[1], r[0] + 3.0), r[0] + 6.5), 3),
                            "mg": clean_motion(x, lv.get("maccent") or "#4F8CFF"), "why": str(x.get("why") or "")[:80]})
    if opts.get("graphics", True):
        ps = (style.get("graphics") or {}).get("prompt_style") or ""
        for x in obj.get("graphics") or []:
            r = rng(x) if isinstance(x, dict) else None
            pr = str((x or {}).get("prompt") or "").strip()[:400]
            if r and pr:
                place = x.get("place") if x.get("place") in ("centro", "alto", "lato") else "centro"
                ok_k = (opts.get("lv") or {}).get("gkinds") or list(GRAPHIC_KINDS)
                kind = x.get("kind") if x.get("kind") in ok_k else ok_k[0]
                out.append({"type": "graphic", "a": round(r[0], 3), "b": round(min(max(r[1], r[0] + 2.0), r[0] + 5), 3), "prompt": pr,
                            "kind": kind, "gstyle": lv.get("gstyle") or "pro", "label": str(x.get("label") or "").strip()[:60] if kind in ("grafico", "tabella", "schema") else "",
                            "style": ps, "place": place, "why": str(x.get("why") or "")[:80]})
    return out


def _fit_zooms(items, rs, dur, min_keep=4.5, max_len=12.0):
    """Zoom che si vedono davvero: almeno 4,5 s di video rimasto (i pezzi tagliati dentro non contano) e fine sul taglio
    successivo se e' vicino, cosi' il ritorno indietro cade su un salto e non si nota."""
    cuts = sorted([(i["a"], i["b"]) for i in items if i["type"] in ("cut", "pause")] + list(rs))
    def kept(a, b):
        k = b - a
        for x, y in cuts:
            k -= max(0.0, min(b, y) - max(a, x))
        return k
    zs = sorted([i for i in items if i["type"] == "zoom"], key=lambda i: i["a"])
    for n, z in enumerate(zs):
        lim = min(dur, zs[n + 1]["a"] - 0.3 if n + 1 < len(zs) else dur, z["a"] + max_len)
        b = z["b"]
        while kept(z["a"], b) < min_keep and b < lim:
            b = min(lim, b + 0.25)
        nxt = next((x for x, y in cuts if x >= b - 0.05), None)
        if nxt is not None and nxt - b < 2.5 and nxt <= lim:
            b = nxt
        z["b"] = round(max(z["b"], b), 3)
    return items


def _tidy(items, dur):
    """Niente sovrapposizioni dove non servono, niente effetti dentro le parti tagliate, ordine per tempo."""
    cuts = sorted([(i["a"], i["b"]) for i in items if i["type"] in ("cut", "pause")])
    merged = []
    for a, b in cuts:
        if merged and a <= merged[-1][1] + 0.02:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    cut_in = lambda t: any(a <= t <= b for a, b in merged)
    out, zooms, texts = [], [], []
    for it in sorted(items, key=lambda x: (x["a"], {"motion": 1, "fx": 1, "text": 2, "graphic": 3}.get(x["type"], 0))):
        it["a"], it["b"] = max(0.0, it["a"]), min(dur, it["b"])
        if it["b"] - it["a"] < 0.1:
            continue
        if it["type"] in ("zoom", "text", "graphic", "motion", "fx") and cut_in((it["a"] + it["b"]) / 2):
            continue
        if it["type"] == "zoom":
            if zooms and it["a"] < zooms[-1]["b"] + 0.3:
                continue
            zooms.append(it)
        if it["type"] == "text":
            if texts and it["a"] < texts[-1]["b"] + 0.2:
                continue
            texts.append(it)
        if it["type"] in ("motion", "fx", "graphic", "text"):
            # un solo elemento a schermo alla volta, con un po' di respiro tra uno e l'altro
            if any(o["type"] in ("motion", "fx", "graphic", "text") and it["a"] < o["b"] + 2.5 and o["a"] < it["b"] + 2.5 for o in out):
                continue
        out.append(it)
    return out


def subs_patch(style, vertical):
    """Lo stile dei sottotitoli per l'editor (subStyle)."""
    c = style.get("captions") or {}
    size = {"piccoli": (0.045, 0.030), "medi": (0.058, 0.040), "grandi": (0.075, 0.052)}[c.get("size") or "medi"][1 if vertical else 0]
    y = {"centro": (0.62, 0.62), "basso": (0.88, 0.74)}[c.get("position") or "basso"][1 if vertical else 0]
    mc = {"parola": 1, "poche": 18, "frase": 22 if vertical else 38}[c.get("mode") or "poche"]
    return {"font": c.get("font") or "Montserrat", "size": size, "y": y, "maxChars": mc, "upper": bool(c.get("upper")),
            "color": c.get("color") or "#FFFFFF", "hiColor": c.get("highlight") or "#FFD60A", "effect": c.get("effect") or "none",
            "box": bool(c.get("box")), "boxColor": "#000000", "boxOp": 65, "stroke": bool(c.get("stroke", True)), "strokeColor": "#000000",
            "strokeW": 0.12, "bold": True, "shadow": not c.get("box")}


# ------------------------------------------------------------------ grafiche generate (anche con lo sfondo trasparente)
GREEN = "on a solid pure bright green (#00FF00) background, isolated subject, no shadow on the background, nothing else"


def key_green(src, dst):
    """Toglie lo sfondo verde (chroma key) e salva un PNG trasparente, con i bordi puliti."""
    import cv2
    import numpy as np
    im = cv2.imread(src, cv2.IMREAD_COLOR)
    if im is None:
        raise ai.AIError("Immagine non leggibile")
    f = im.astype(np.float32)
    b, g, r = f[..., 0], f[..., 1], f[..., 2]
    gv = g - np.maximum(r, b)                      # quanto e' "verde" il pixel
    alpha = 1.0 - np.clip((gv - 40.0) / 70.0, 0.0, 1.0)
    alpha = cv2.GaussianBlur(alpha, (3, 3), 0)
    # niente alone verde sui bordi (despill)
    g2 = np.minimum(g, np.maximum(r, b) + 12)
    out = np.dstack([b, g2, r, alpha * 255.0]).clip(0, 255).astype(np.uint8)
    ys, xs = np.where(alpha > 0.05)
    if len(xs):
        pad = 6
        y0, y1 = max(0, ys.min() - pad), min(out.shape[0], ys.max() + pad)
        x0, x1 = max(0, xs.min() - pad), min(out.shape[1], xs.max() + pad)
        out = out[y0:y1, x0:x1]
    cv2.imwrite(dst, sticker(out))
    return dst


def trim_alpha(src, dst):
    """PNG gia' trasparente (modelli con sfondo trasparente): si taglia solo il vuoto intorno."""
    import cv2
    import numpy as np
    im = cv2.imread(src, cv2.IMREAD_UNCHANGED)
    if im is None:
        raise ai.AIError("Immagine non leggibile")
    if im.ndim == 2 or im.shape[2] == 3:   # il servizio non l'ha resa trasparente: la si tratta come le altre
        return key_green(src, dst)
    ys, xs = np.where(im[..., 3] > 12)
    if len(xs):
        pad = 8
        im = im[max(0, ys.min() - pad):ys.max() + pad, max(0, xs.min() - pad):xs.max() + pad]
    cv2.imwrite(dst, im)
    return dst


def sticker(rgba, border=0.045):
    """Bordo bianco e ombra morbida intorno al soggetto (stile sticker): il ritaglio sembra voluto e si stacca dal video."""
    import cv2
    import numpy as np
    h, w = rgba.shape[:2]
    bw = max(3, int(max(h, w) * border))
    pad = bw * 3
    big = np.zeros((h + 2 * pad, w + 2 * pad, 4), np.float32)
    big[pad:pad + h, pad:pad + w] = rgba.astype(np.float32)
    a = big[..., 3] / 255.0
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * bw + 1, 2 * bw + 1))
    ring = cv2.GaussianBlur(cv2.dilate((a > 0.35).astype(np.float32), k), (5, 5), 0)
    shadow = cv2.GaussianBlur(ring, (0, 0), bw * 1.2)
    shadow = np.roll(shadow, bw // 2, axis=0) * 0.45
    out = np.zeros_like(big)
    # ombra -> bordo bianco -> soggetto
    out[..., 3] = shadow * 255
    ra = ring[..., None]
    out[..., :3] = out[..., :3] * (1 - ra) + 255 * ra
    out[..., 3] = np.maximum(out[..., 3], ring * 255)
    sa = a[..., None]
    out[..., :3] = out[..., :3] * (1 - sa) + big[..., :3] * sa
    out[..., 3] = np.maximum(out[..., 3], a * 255)
    return out.clip(0, 255).astype(np.uint8)


def graphic(cfg, it, outdir, vertical, cancel=None):
    """Crea la grafica di un elemento del piano -> percorso del file (PNG)."""
    os.makedirs(outdir, exist_ok=True)
    full = it.get("place") == "pieno"
    style = (it.get("style") or "").strip()
    kind = it.get("kind") if it.get("kind") in GRAPHIC_KINDS else ""
    if kind and not full:
        # asset grafico (icona, grafico, tabella...): mai una foto o una scena
        label = (it.get("label") or "").strip()
        words = (f'The only text allowed is exactly: "{label}" (spelled exactly like this, big and legible). No other text, no watermark.'
                 if label else ai.NO_TEXT)
        look = ICON_STYLES.get(it.get("gstyle") or "pro", ICON_STYLES["pro"])
        clear = bool(cfg.get("transparent"))
        prompt = (f"{GRAPHIC_KINDS[kind]}: {it['prompt'].rstrip('.')}. Graphic asset for a YouTube video overlay. Style: {look}. "
                  f"Not a photo, no realistic scene, no people. " + (f"{words} Isolated on a transparent background." if clear else
                                                                     f"Do not use any green color in the graphic. {words} {GREEN}."))
        b, ext = ai.image(cfg, prompt, None, ratio="1:1", cancel=cancel)
        import secrets
        base = os.path.join(outdir, "ai_" + secrets.token_hex(4))
        with open(base + ext, "wb") as f:
            f.write(b)
        png = trim_alpha(base + ext, base + "_trasparente.png") if clear else key_green(base + ext, base + "_trasparente.png")
        try:
            os.remove(base + ext)
        except OSError:
            pass
        return png
    prompt = it["prompt"].rstrip(".") + ". " + (style + ". " if style else "")
    if full:
        prompt += "Full frame cinematic shot. " + ai.NO_TEXT
        ratio = "9:16" if vertical else "16:9"
    else:
        prompt += GREEN + ". " + ai.NO_TEXT
        ratio = "1:1"
    b, ext = ai.image(cfg, prompt, None, ratio=ratio, cancel=cancel)
    import secrets
    base = os.path.join(outdir, "ai_" + secrets.token_hex(4))
    raw = base + ext
    with open(raw, "wb") as f:
        f.write(b)
    if full:
        return raw
    png = key_green(raw, base + "_trasparente.png")
    try:
        os.remove(raw)
    except OSError:
        pass
    return png


# ------------------------------------------------------------------ stile delle immagini (reference per le Storie AI)
def _small(path, out, side=640):
    import cv2
    im = cv2.imread(path, cv2.IMREAD_COLOR)
    if im is None:
        return None
    h, w = im.shape[:2]
    k = side / max(h, w)
    if k < 1:
        im = cv2.resize(im, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    cv2.imwrite(out, im, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return out


def analyze_image_style(fm, cfg, cancel=None):
    """Le immagini di riferimento -> lo stile visivo in un prompt (inglese) da usare come stile di una pagina delle Storie AI."""
    from . import formats as FM
    imgs = [v["path"] for v in fm.get("videos") or [] if v.get("image") and v.get("path") and os.path.isfile(v["path"])][:10]
    if not imgs:
        raise ai.AIError("Carica almeno un'immagine di riferimento")
    d = os.path.join(FM._dir(fm["id"]), "stile-immagini")
    os.makedirs(d, exist_ok=True)
    small = [x for x in (_small(p, os.path.join(d, f"{i}.jpg")) for i, p in enumerate(imgs)) if x]
    system = ("Sei un art director. Guarda le immagini di riferimento e descrivi lo STILE VISIVO comune (non il contenuto), così che un generatore "
              "di immagini possa creare immagini nuove nello stesso stile: tecnica (foto, 3D, anime, illustrazione…), luce, colori, grana, "
              "inquadrature, atmosfera, dettagli ricorrenti. Rispondi SOLO con JSON:\n"
              '{"summary": "2 frasi in italiano sullo stile", "prompt": "style prompt in English, 40-80 words, only style (no subject)",'
              ' "palette": ["#RRGGBB", "... 3-6 colori"], "rules": ["3-5 regole in italiano, es. inquadrature strette sui volti"]}')
    raw = ai.text(cfg, system, f"{len(small)} immagini di riferimento. Categoria: {fm.get('niche') or '-'}", max_tokens=1500, cancel=cancel, images=small)
    st = ai.parse_json(raw)
    if not isinstance(st, dict) or not st.get("prompt"):
        raise ai.AIError("L'AI non ha risposto con uno stile valido: riprova")
    pal = [x for x in (st.get("palette") or []) if isinstance(x, str) and re.match(r"^#[0-9a-fA-F]{6}$", x)][:6]
    return {"summary": str(st.get("summary") or "")[:500], "prompt": str(st["prompt"])[:800], "palette": pal,
            "rules": [str(x)[:200] for x in (st.get("rules") or [])][:6], "images": len(small)}


def estimate(proj, cfg):
    """Quanto costa, piu' o meno, far leggere il video all'AI (il piano). Le grafiche si pagano a parte, una per una."""
    words = words_of(proj)
    n = len(words)
    chunks = max(1, -(-n // 1500))
    tin = (sum(len(w["w"]) + 6 for w in words) + chunks * 5200) / 3.3
    tout = chunks * 2200
    usd = ai.text_cost(cfg.get("model"), tin, tout)
    return {"words": n, "planUsd": round(usd if usd is not None else 0.02 * chunks, 4), "chunks": chunks}
