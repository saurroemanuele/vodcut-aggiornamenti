// NoonFrame - clip virali dalla live (stile Opus): l'AI trova i momenti migliori, ognuno e' gia' una clip verticale montata.
// Galleria con punteggio di viralita', titolo e motivo; anteprima al passaggio del mouse; ogni clip si apre nell'editor.
import { get, post, put, api, h, icon, toast, confirmBox, promptBox, pollJob, mediaUrl, thumbUrl, TOKEN } from './lib.js';
import { drawText } from './text.js';
import { pickRange } from './rangepick.js';
import { ensureFont } from './fonts.js';
import { HOOK_STYLE, hookStyle, hookContent, savedHook, openStyleWizard, badgeLogosReady, setLookCache } from './clipstyle.js';

const VW = 1080, VH = 1920;

export const scoreColor = (s) => (s == null ? 'var(--text3)' : s >= 90 ? '#3DDC84' : s >= 75 ? '#A3E635' : s >= 60 ? '#FFD60A' : '#FF9F43');
const mmss = (t) => { t = Math.max(0, Math.round(t || 0)); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); };
const hms = (t) => { t = Math.max(0, Math.round(t || 0)); const hh = Math.floor(t / 3600); return (hh ? hh + ':' : '') + String(Math.floor(t / 60) % 60).padStart(hh ? 2 : 1, '0') + ':' + String(t % 60).padStart(2, '0'); };

// dove va la scritta d'apertura: quando si vede solo la webcam (zoom sulla cam o impaginazione "solo cam")
// sta in alto, sopra la testa; con cam sopra e gioco sotto sta sulla linea tra i due
function hookY(ch, c) {
  const a = c.a || 0, b = a + (c.dur || 3.2);
  // due persone una sopra l'altra (regia delle chiamate / live a confronto): il titolo sulla linea in mezzo
  const seg = (ch.segs || []).find((s) => !s.removed && s.a <= a + 0.1 && a + 0.1 < s.b);
  if (seg && seg.vlay && seg.vlay.layout === 'stack') return 'mid';
  const lay = (ch.vert && ch.vert.layout) || 'split';
  const zoomed = (ch.zooms || []).some((z) => z.on !== false && z.a < b && a < z.b);
  return lay === 'split' && !zoomed ? 0.33 : 0.07;
}

// disegna la scritta d'apertura con lo stesso motore dei testi dell'editor e la salva nella clip
export async function bakeHooks(cid, force) {
  const ch = await get('/api/p/' + cid);
  let changed = false;
  const hk = await savedHook();
  const st = hookStyle(hk);
  await ensureFont(st.font);
  const anim = hk.anim && hk.anim !== 'none' ? { in: hk.anim, inDur: 0.35 } : null;   // come entra il titolo
  for (const t of ch.tracks || []) {
    for (const c of t.clips || []) {
      // badge social dello stile delle clip: si disegna con il logo della piattaforma, dove l'hai messo
      if (c.clipBadge && c.isText && c.text && c.text.badge) {
        if (c.file && !force) continue;
        await badgeLogosReady();
        await ensureFont(c.text.font);
        const cv = drawText(c.text, VH);
        const natW = cv.width / VW, ar = cv.height / cv.width;
        const blob = await new Promise((res) => cv.toBlob(res, 'image/png'));
        const r = await fetch(`/api/p/${cid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: blob });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error || 'Badge non salvato');
        const p0 = c.pos || {}, hh = natW * ar * VW / VH;
        Object.assign(c, { file: j.path, natW, ar, pos: { x: +Math.max(0, Math.min(1 - natW, p0.x ?? 0.05)).toFixed(4), y: +Math.max(0, Math.min(1 - hh, p0.y ?? 0.05)).toFixed(4), w: +natW.toFixed(4) } });
        changed = true;
        continue;
      }
      const old = c.hook && c.text && c.text.font && c.text.v !== HOOK_STYLE.v;   // scritte fatte con lo stile vecchio: si ridisegnano
      if (!c.isText || (c.file && c.text && c.text.font && !(force && c.hook) && !old)) continue;
      const raw = String((c.text && c.text.content) || '').replace(/\*/g, '').replace(/\n/g, ' ');
      const spec = { ...st, content: c.hook ? hookContent(raw) : String((c.text && c.text.content) || '') };
      const cv = drawText(spec, VH);
      const natW = cv.width / VW, ar = cv.height / cv.width;
      const w = Math.min(0.9, natW);
      const blob = await new Promise((res) => cv.toBlob(res, 'image/png'));
      const r = await fetch(`/api/p/${cid}/textimg?clip=${c.id}&token=${TOKEN}`, { method: 'PUT', body: blob });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Scritta non salvata');
      const p0 = c.pos || {};
      const autoY = c.hook && (p0.auto || p0.y == null || !c.file || (old && Math.abs(p0.y - 0.33) < 0.005));
      let y = autoY ? hookY(ch, c) : p0.y;
      if (y === 'mid') y = +Math.max(0.05, 0.5 - (w * ar * VW / VH) / 2).toFixed(4);
      Object.assign(c, { file: j.path, text: spec, natW, ar, pos: { x: +((1 - w) / 2).toFixed(4), y, w: +w.toFixed(4), ...(autoY ? { auto: true } : {}) } });
      if (c.hook) { if (anim) c.anim = anim; else delete c.anim; }
      changed = true;
    }
  }
  // titolo d'apertura e badge social mai uno sopra l'altro: il titolo (messo in automatico) va sotto il badge, o sopra
  const all = (ch.tracks || []).flatMap((t) => t.clips || []);
  const badges = all.filter((c) => c.clipBadge && c.file && c.pos);
  for (const hc of all.filter((c) => c.hook && c.file && c.pos && c.pos.auto)) {
    const hH = (hc.pos.w ?? hc.natW ?? 0.86) * (hc.ar || 0.2) * VW / VH;
    let y = hc.pos.y;
    for (const bc of badges) {
      if (!(bc.a < hc.a + (hc.dur || 3.2) && hc.a < bc.a + (bc.dur || 0))) continue;
      const by = bc.pos.y, bh = bc.pos.w * (bc.ar || 0.2) * VW / VH;
      if (y < by + bh + 0.01 && y + hH > by - 0.01) y = by + bh / 2 < 0.5 ? by + bh + 0.015 : Math.max(0.02, by - hH - 0.015);
    }
    y = +Math.max(0.02, Math.min(0.98 - hH, y)).toFixed(4);
    if (y !== hc.pos.y) { hc.pos = { ...hc.pos, y }; changed = true; }
  }
  if (changed) await put('/api/p/' + cid, ch);
}

async function findJob(pid, kind) {
  try { return (await get('/api/jobs')).find((j) => j.pid === pid && j.kind === kind) || null; } catch (e) { return null; }
}

export async function screenClips(pid, ctx) {
  const { app, nav, setTitle, setCleanup, topbar } = ctx;
  let data = await post(`/api/p/${pid}/cliplist`);
  const parent = await get('/api/p/' + pid);
  setTitle('Clip · ' + parent.name);
  let alive = true, sort = 'score', minScore = 0, selecting = false, query = '';
  const selected = new Set();
  let job = await findJob(pid, 'clips');
  let pjob = await findJob(pid, 'clipprev');
  const working = new Set();   // clip con l'anteprima in preparazione
  const queued = new Set();   // clip che aspettano le anteprime in corso

  app.innerHTML = '';
  const right = h('div', { class: 'row' });
  app.append(topbar(-1, right, false, { parentName: parent.name, parent: pid, name: 'Clip virali', icon: 'phone', parentTip: 'Torna al video della live' }));
  const page = h('main', { class: 'cg' });
  app.append(page);

  // ---------------------------------------------------------------- barra: cosa cercare, ordina, filtra, seleziona
  const qIn = h('input', { class: 'cg-q', placeholder: 'Cosa cercare? Es. spaventi, momenti divertenti, giocate epiche (facoltativo)', maxlength: '300',
    value: (data.run && data.run.prompt) || '', 'aria-label': 'Cosa cercare nella live' });
  const findBtn = h('button', { class: 'btn primary', onclick: () => start() }, icon('sparkle', 14, '#fff', 2.2), 'Trova le clip');
  const subsBtn = h('button', { class: 'btn', 'data-tip': 'Titolo d\'apertura, sottotitoli e badge social delle clip: font, grandezze, colori e animazioni', onclick: () => lookBox() }, icon('text', 14, 'currentColor', 2), 'Stile');
  const zoomBtn = h('button', { class: 'btn', 'data-tip': 'Quanti zoom sulla webcam in ogni clip', onclick: () => zoomBox() }, icon('zoomin', 14, 'currentColor', 2), 'Zoom');
  // lingua della live scelta prima di cercare: trascrizione, sottotitoli, titoli e scritte in quella lingua
  const findLang = h('select', { class: 'cg-lang cg-flang', 'aria-label': 'Lingua della live', 'data-tip': 'In che lingua parli nella live: sottotitoli, titoli e scritte delle clip escono in questa lingua' },
    h('option', { value: '' }, 'Lingua: automatica'),
    ...Object.entries(data.langs || { it: 'italiano', en: 'inglese' }).map(([k, v]) => h('option', { value: k, selected: k === data.subLang ? true : null }, v.charAt(0).toUpperCase() + v.slice(1))));
  const layBtn = h('button', { class: 'btn', 'data-tip': 'Come si vede il video nelle clip verticali: a tutto schermo o intero con lo sfondo sfocato', onclick: () => layoutBox() }, icon('phone', 14, 'currentColor', 2), 'Formato');
  if (!data.webcam) zoomBtn.style.display = 'none';   // senza webcam gli zoom sulla webcam non ci sono
  const manualBtn = h('button', { class: 'btn', 'data-tip': 'Crea una clip da un momento qualsiasi della live, anche uno che l\'AI non ha preso', onclick: () => manualBox() }, icon('plus', 14, 'currentColor', 2.2), 'Clip a mano');
  const searchIn = h('input', { class: 'cg-search', placeholder: 'Cerca nei titoli', 'aria-label': 'Cerca nei titoli',
    oninput: () => { query = searchIn.value.trim().toLowerCase(); drawGrid(); } });
  const tools = h('div', { class: 'cg-tools' });
  const status = h('div', { class: 'cg-status', style: { display: 'none' } });
  const grid = h('div', { class: 'cg-grid' });
  const selBar = h('div', { class: 'cg-selbar', style: { display: 'none' } });
  page.append(h('div', { class: 'cg-head' },
    h('div', { class: 'cg-title' }, h('h1', null, 'Clip virali'), h('span', { class: 'cg-count' })),
    h('div', { class: 'cg-find' }, qIn, findLang, layBtn, subsBtn, zoomBtn, manualBtn, findBtn)), status, tools, grid, selBar);
  if (data.kind === 'blank' || data.kind === 'story') page.querySelector('.cg-find').style.display = 'none';   // progetto vuoto: niente da cercare

  // stile delle clip: titolo d'apertura, sottotitoli e badge social (gli stessi passaggi di prima di cercare le clip),
  // per le prossime clip e, se ce ne sono, per quelle gia' fatte
  // sfondo dell'anteprima dello stile: un momento della clip migliore messo in verticale come nella clip (o, prima
  // delle clip, un fotogramma della live con la webcam sopra il gioco); e dove vanno li' i sottotitoli in automatico
  async function lookFrame() {
    try {
      const c = data.clips[0];
      if (c) {
        const ch = await api('GET', `/api/p/${c.id}`);
        const segs = (ch.segs || []).filter((s) => !s.removed);
        const rs = ch.ranges || [[c.a, c.b]];
        const a = rs[0][0], b = rs[rs.length - 1][1];
        let t = a + Math.min(Math.max(2.5, (b - a) * 0.45), Math.max(0.5, b - a - 0.5));
        const sg = segs.find((s) => s.a <= t && t < s.b) || segs.find((s) => s.a > t) || segs[0];
        if (sg && !(sg.a <= t && t < sg.b)) t = Math.min(sg.b - 0.05, sg.a + 0.4);
        const cam = (ch.webcam || {}).box || null;
        const lay = { ...(ch.vert || {}), ...((sg && sg.vlay) || {}) };
        const split = lay.layout === 'split' && !!cam;
        const autoSub = sg && sg.vlay && sg.vlay.subY ? { y: sg.vlay.subY } : split ? { camH: lay.camH ?? 0.4 } : { y: 0.8 };
        const hookY = lay.layout === 'stack' ? 'mid' : split ? 0.33 : 0.07;
        if (ch.width && ch.height) return { frame: { src: thumbUrl(pid, t, 720), W: ch.width, H: ch.height, lay, cam }, autoSub, hookY, cam: split };
      }
    } catch (e) { /* sotto: un fotogramma della live */ }
    const t = Math.max(1, (data.duration || 60) * 0.3);
    if (data.webcamBox && data.width && data.height) {
      return { frame: { src: thumbUrl(pid, t, 720), W: data.width, H: data.height, lay: { layout: 'split', camH: 0.4, gameX: 0.5 }, cam: data.webcamBox }, autoSub: { camH: 0.4 }, hookY: 0.33, cam: true };
    }
    return { frame: thumbUrl(pid, t, 640), autoSub: { y: 0.8 }, hookY: 0.07, cam: false };
  }
  async function lookBox(opts = {}) {
    const has = data.clips.length > 0 && !opts.search;
    const fr = await lookFrame();
    return new Promise((resolve) => {
      openStyleWizard({
        title: 'Stile delle clip',
        lead: opts.search ? 'Scegli come escono le clip: titolo d\'apertura, sottotitoli e badge social. Resta salvato anche per le prossime live.'
          : 'Titolo d\'apertura, sottotitoli e badge social: vale per le prossime clip' + (has ? ' e per quelle già fatte.' : '.'),
        frame: fr.frame, cam: fr.cam, autoSub: fr.autoSub, hookY: fr.hookY,
        finalLabel: opts.search ? 'Trova le clip' : has ? 'Applica a tutte le clip' : 'Salva',
        quick: opts.search ? 'Usa lo stile salvato' : null,
        onCancel: () => resolve(false),
        onFinish: async (look, presets) => {
          const r = await post(`/api/p/${pid}/cliplook`, { look, presets, apply: has });
          setLookCache(look, presets);
          resolve(true);
          if (has && alive) {
            toast('Stile aggiornato in ' + r.clips + ' clip: rifaccio le anteprime');
            (async () => {
              for (const c of data.clips) { try { await bakeHooks(c.id, true); } catch (e) { console.warn(e); } }
              await reload();
              await previews(data.clips.map((c) => c.id));
            })();
          }
        },
      });
    });
  }

  // quanti zoom sulla webcam per clip (con lo swoosh): automatico, nessuno o un numero preciso
  function zoomBox() {
    let n = data.clipZooms ?? 'auto';
    const bg = h('div', { class: 'modal-bg' });
    const opts = [['auto', 'Auto'], [0, 'Nessuno'], [1, '1'], [2, '2'], [3, '3'], [4, '4'], [5, '5']];
    const seg = h('div', { class: 'seg cg-seg cg-zseg', role: 'group', 'aria-label': 'Zoom per clip' });
    const hint = h('p', { class: 'muted', style: { margin: '10px 0 0' } });
    const draw = () => {
      seg.replaceChildren(...opts.map(([k, l]) => h('button', { type: 'button', class: String(n) === String(k) ? 'on' : '', onclick: () => { n = k; draw(); } }, l)));
      hint.textContent = n === 'auto' ? 'Da 1 a 3 in base alla durata della clip.'
        : n === 0 ? 'Le clip escono senza zoom e senza swoosh.'
          : `Fino a ${n} zoom per clip. Lo zoom si fa solo quando parla o reagisce lo streamer: se nella clip ci sono meno momenti così, gli zoom saranno meno.`;
    };
    draw();
    const close = () => bg.remove();
    const has = data.clips.length > 0;
    const save = async () => {
      let r;
      try { r = await post(`/api/p/${pid}/clipzooms`, { n, apply: has }); } catch (e) { return toast(e.message, true); }
      data.clipZooms = n; close();
      if (has) { toast('Zoom aggiornati in ' + r.clips + ' clip: rifaccio le anteprime'); await reload(); await previews(data.clips.map((c) => c.id)); }
      else toast('Salvato: le prossime clip avranno questi zoom');
    };
    bg.append(h('div', { class: 'modal cg-zmodal', role: 'dialog', 'aria-label': 'Zoom nelle clip' },
      h('h2', null, 'Zoom nelle clip'),
      h('div', { class: 'cg-slbl' }, 'Zoom sulla webcam per ogni clip'), seg, hint,
      h('p', { class: 'muted', style: { margin: '8px 0 0' } }, has ? 'Vale per tutte le clip di questa live e per le prossime. Gli zoom che hai messo a mano restano.' : 'Lo scegli adesso e le clip escono già così.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px', marginTop: '14px' } },
        h('button', { class: 'btn ghost', type: 'button', onclick: close }, 'Annulla'),
        h('button', { class: 'btn primary', type: 'button', onclick: save }, has ? 'Salva e applica' : 'Salva'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  // formato delle clip verticali: scelto subito, prima di creare le clip, e cambiabile dopo per tutte insieme
  function layoutBox() {
    let lay = data.clipLayout || 'auto';
    const cam = !!data.webcam;
    const OPTS = [
      ['auto', 'Automatico', cam ? 'Webcam sopra e gioco sotto. Se nella scena c\'è solo la webcam, la persona a tutto schermo.'
        : 'La persona a tutto schermo quando si vede bene (podcast, intervista, camera fissa), se no il video intero.'],
      ['full', 'Tutto schermo', cam ? 'Solo il gioco, a tutto schermo.' : 'Il video riempie lo schermo verticale, centrato sulla persona che si vede di più.'],
      ['fit', 'Intero', 'Tutto il video al centro, con lo stesso video sfocato sopra e sotto.']];
    const bg = h('div', { class: 'modal-bg' });
    const tiles = h('div', { class: 'cg-lays', role: 'radiogroup', 'aria-label': 'Formato delle clip' });
    const hint = h('p', { class: 'muted', style: { margin: '12px 0 0', minHeight: '38px' } });
    const draw = () => {
      tiles.replaceChildren(...OPTS.map(([k, name]) => h('button', { type: 'button', role: 'radio', 'aria-checked': String(lay === k), class: 'cg-lay' + (lay === k ? ' on' : ''), onclick: () => { lay = k; draw(); } },
        h('i', { class: 'cg-lay-pic ' + k + (cam ? ' cam' : '') }, h('b'), h('u')), h('span', null, name))));
      hint.textContent = OPTS.find(([k]) => k === lay)[2];
    };
    draw();
    const close = () => bg.remove();
    const has = data.clips.length > 0;
    const saveBtn = h('button', { class: 'btn primary', type: 'button' }, has ? 'Salva e applica' : 'Salva');
    saveBtn.onclick = async () => {
      saveBtn.disabled = true;
      let r;
      try { r = await post(`/api/p/${pid}/cliplayout`, { layout: lay, apply: has }); } catch (e) { saveBtn.disabled = false; return toast(e.message, true); }
      data.clipLayout = lay;
      if (!r.id) { close(); return toast('Salvato: le prossime clip escono in questo formato'); }
      saveBtn.textContent = 'Cambio il formato…';
      const res = await pollJob(r.id, (j) => { saveBtn.textContent = j.message || 'Cambio il formato…'; });
      close();
      if (res.status !== 'done') return toast(res.error || 'Formato non cambiato', true);
      toast('Formato cambiato in ' + res.result.clips + ' clip: rifaccio le anteprime');
      await reload(); await previews(data.clips.map((c) => c.id));
    };
    bg.append(h('div', { class: 'modal cg-zmodal', role: 'dialog', 'aria-label': 'Formato delle clip' },
      h('h2', null, 'Formato delle clip'), tiles, hint,
      h('p', { class: 'muted', style: { margin: '6px 0 0' } }, has ? 'Vale per tutte le clip di questa live e per le prossime. Nell\'editor puoi sempre cambiarlo per una clip sola.' : 'Lo scegli adesso e le clip escono già così.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px', marginTop: '14px' } },
        h('button', { class: 'btn ghost', type: 'button', onclick: close }, 'Annulla'), saveBtn)));
    bg.addEventListener('click', (e) => { if (e.target === bg && !saveBtn.disabled) close(); });
    document.body.append(bg);
  }

  function drawTools() {
    const n = data.clips.length;
    findLang.style.display = n ? 'none' : '';
    page.querySelector('.cg-count').textContent = n ? String(n) : '';
    tools.style.display = n ? '' : 'none';
    tools.replaceChildren(...[
      h('div', { class: 'cg-tl' }, searchIn),
      h('div', { class: 'cg-tl' },
        h('div', { class: 'seg cg-seg', role: 'group', 'aria-label': 'Ordina' },
          ...[['score', 'Più virali'], ['time', 'Ordine nella live']].map(([k, l]) => h('button', { class: sort === k ? 'on' : '', type: 'button', onclick: () => { sort = k; drawTools(); drawGrid(); } }, l))),
        h('div', { class: 'seg cg-seg', role: 'group', 'aria-label': 'Punteggio minimo' },
          ...[[0, 'Tutte'], [70, '70+'], [85, '85+']].map(([k, l]) => h('button', { class: minScore === k ? 'on' : '', type: 'button', onclick: () => { minScore = k; drawTools(); drawGrid(); } }, l))),
        langSel(),
        n ? h('button', { class: 'btn sm' + (selecting ? ' on' : ''), type: 'button', onclick: () => { selecting = !selecting; selected.clear(); drawTools(); drawGrid(); drawSel(); } },
          icon('check', 13, 'currentColor', 2.2), selecting ? 'Fine' : 'Seleziona') : null)].filter(Boolean));
  }
  // lingua delle clip: sottotitoli riscritti nella lingua scelta, titoli e scritte tradotti
  function langSel() {
    const L = data.langs || { it: 'italiano', en: 'inglese' };
    const sel = h('select', { class: 'cg-lang', 'aria-label': 'Lingua delle clip', 'data-tip': 'Lingua di sottotitoli, titoli e scritte delle clip' },
      ...Object.entries(L).map(([k, v]) => h('option', { value: k, selected: k === data.lang ? true : null }, v.charAt(0).toUpperCase() + v.slice(1))));
    sel.addEventListener('change', async () => {
      const lang = sel.value;
      if (!await confirmBox('Clip in ' + L[lang] + '?', 'Riscrivo i sottotitoli delle clip ascoltando di nuovo l\'audio in ' + L[lang] + ' (gratis, sul tuo computer) e traduco titoli e scritte d\'apertura con l\'AI.', 'Cambia lingua')) { sel.value = data.lang; return; }
      let j;
      try { j = await post(`/api/p/${pid}/cliplang`, { lang }); } catch (e) { sel.value = data.lang; return toast(e.message, true); }
      showStatus(j, 'Cambio la lingua delle clip');
      let r;
      try { r = await pollJob(j.id, (x) => { if (alive) showStatus(x, 'Cambio la lingua delle clip'); }); } catch (e) { r = { status: 'error', error: e.message }; }
      if (!alive) return;
      status.style.display = 'none';
      if (r.status !== 'done') { toast(r.error || 'Lingua non cambiata', true); await reload(); return; }
      toast(r.result && r.result.translated ? 'Clip in ' + L[lang] + ': sottotitoli e titoli aggiornati' : 'Sottotitoli in ' + L[lang] + ' (titoli non tradotti: serve una chiave AI)');
      await reload();
      await previews(data.clips.map((c) => c.id));
    });
    return sel;
  }
  function visible() {
    let l = data.clips.filter((c) => (c.score == null || c.score >= minScore) && (!query || String(c.name || '').toLowerCase().includes(query)));
    l = l.slice().sort((a, b) => (sort === 'time' ? a.a - b.a : (b.score ?? -1) - (a.score ?? -1) || a.a - b.a));
    return l;
  }

  // ---------------------------------------------------------------- dove funziona meglio (TikTok, Reels, Shorts)
  const PF_NAME = { tiktok: 'TikTok', reels: 'Reels', shorts: 'Shorts' };
  function bestPf(c) {
    if (!c.pf) return null;
    const e = Object.entries(c.pf).filter(([k]) => PF_NAME[k]).sort((a, b) => b[1] - a[1]);
    return e.length && e[0][1] - (e[1] ? e[1][1] : 0) >= 3 ? e[0] : null;   // quasi pari: nessuna piattaforma in evidenza
  }
  function pfBox(c) {
    if (!c.pf) return null;
    const best = bestPf(c);
    return h('div', { class: 'cg-pfbox' },
      h('div', { class: 'cg-pfh' }, 'Dove funziona meglio'),
      ...Object.keys(PF_NAME).map((k) => h('div', { class: 'cg-pfrow' + (best && best[0] === k ? ' best' : '') },
        h('span', null, PF_NAME[k]),
        h('div', { class: 'cg-pfbar' }, h('div', { style: { width: (c.pf[k] || 0) + '%' } })),
        h('b', null, String(c.pf[k] ?? '–')))),
      c.pfWhy ? h('p', { class: 'cg-pfwhy' }, c.pfWhy) : null,
      h('p', { class: 'cg-pfnote' }, 'Stima dell\'AI su cosa piace di solito su ogni piattaforma: provala dove ha il punteggio più alto.'));
  }

  // ---------------------------------------------------------------- clip a mano e clip allungata (o accorciata) nella live
  function manualBox() {
    if (job) return toast('Aspetta che l\'AI finisca di cercare le clip', true);
    const D = +data.duration || 0;
    pickRange({ pid, duration: D, source: data.source, vcodec: data.vcodec, a: 0, b: Math.min(D, 30), marks: data.clips.map((c) => [c.a, c.b]),
      title: 'Clip a mano', okLabel: 'Crea la clip', withName: true,
      intro: 'Scegli un momento qualsiasi della live, anche uno che l\'AI non ha preso. La clip esce montata come le altre: webcam e gioco, sottotitoli e zoom.',
      run: async ({ a, b, name }, busy) => {
        const j = await post(`/api/p/${pid}/clipmanual`, { a, b, name });
        const r = await pollJob(j.id, (x) => busy(x.message));
        if (r.status !== 'done') throw new Error(r.error || 'Clip non creata');
        toast('Clip creata: la trovi nella galleria');
        await reload();
        await previews([r.result.clip.id]);
      } });
  }
  // la clip dell'AI ha tagliato l'inizio che serve a capire (o finisce troppo presto): si allunga nella live, le modifiche restano
  function extendBox(c) {
    if (job) return toast('Aspetta che l\'AI finisca di cercare le clip', true);
    const D = +data.duration || 0;
    pickRange({ pid, duration: D, source: data.source, vcodec: data.vcodec, a: c.a, b: c.b, from: [c.a, c.b],
      marks: data.clips.filter((x) => x.id !== c.id).map((x) => [x.a, x.b]), maxDur: 300,
      title: 'Allunga o accorcia la clip', okLabel: 'Salva',
      intro: 'Sposta l\'inizio prima per aggiungere il contesto che serve, o la fine dopo per arrivare al finale. Quello che hai già modificato nella clip resta.',
      run: async ({ a, b }, busy) => {
        busy('Aggiorno la clip…');
        const j = await post(`/api/p/${c.id}/clipextend`, { a, b });
        const r = await pollJob(j.id, (x) => busy(x.message));
        if (r.status !== 'done') throw new Error(r.error || 'Clip non aggiornata');
        toast('Clip aggiornata: ' + mmss(r.result.dur));
        await reload();
        await previews([c.id]);
      } });
  }

  // ---------------------------------------------------------------- scheda di una clip
  function card(c) {
    const pv = h('div', { class: 'cg-pv' });
    const posterSrc = c.poster ? mediaUrl(c.poster) + '&v=' + Math.round(c.previewAt || 0) : thumbUrl(pid, Math.min((data.duration || 1) - 0.5, c.a + 1), 480);
    const img = h('img', { class: 'cg-poster' + (c.poster ? '' : ' raw'), src: posterSrc, alt: '', loading: 'lazy', draggable: 'false' });
    pv.append(img);
    let vid = null;
    if (c.preview) {
      pv.addEventListener('pointerenter', () => {
        if (selecting) return;
        if (!vid) { vid = h('video', { class: 'cg-vid', src: mediaUrl(c.preview) + '&v=' + Math.round(c.previewAt || 0), muted: true, loop: true, playsinline: true, preload: 'auto' }); vid.muted = true; pv.append(vid); }
        vid.currentTime = 0; vid.play().catch(() => {});
      });
      pv.addEventListener('pointerleave', () => { if (vid) vid.pause(); });
    }
    if (working.has(c.id) || queued.has(c.id) || (!c.preview && (pjob || job))) pv.append(h('div', { class: 'cg-wait' }, h('span', { class: 'spinner sm' }), h('span', null, c.preview ? 'Aggiorno l\'anteprima' : 'Preparo l\'anteprima')));
    else if (!c.preview) pv.append(h('div', { class: 'cg-wait soft' }, h('span', null, 'Anteprima non pronta')));
    if (c.manual) pv.append(h('span', { class: 'cg-badge' }, 'A mano'));
    else if (c.edited) pv.append(h('span', { class: 'cg-badge' }, 'Modificato'));
    const best = bestPf(c);
    if (best) pv.append(h('span', { class: 'cg-pf', 'data-tip': 'Dove questa clip può funzionare meglio secondo l\'AI' }, PF_NAME[best[0]]));
    pv.append(h('span', { class: 'cg-time' }, h('b', null, mmss(c.dur)), h('span', null, 'da ' + hms(c.a))));
    if (selecting) pv.append(h('span', { class: 'cg-check' + (selected.has(c.id) ? ' on' : '') }, icon('check', 14, '#fff', 3)));
    const el = h('article', { class: 'cg-card' + (selected.has(c.id) ? ' sel' : ''), tabindex: '0', 'aria-label': c.name },
      pv,
      h('div', { class: 'cg-meta' },
        h('div', { class: 'cg-row' },
          h('b', { class: 'cg-score', style: { color: scoreColor(c.score) }, 'data-tip': 'Punteggio di viralità (0-100)' }, c.score != null ? String(c.score) : '–'),
          h('div', { class: 'cg-acts' },
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Esporta', 'data-tip': 'Esporta il video', onclick: (e) => { e.stopPropagation(); exportClips([c.id]); } }, icon('download', 17, 'currentColor', 2)),
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Modifica', 'data-tip': 'Modifica nell\'editor', onclick: (e) => { e.stopPropagation(); openClip(c); } }, icon('scissors', 17, 'currentColor', 2)),
            h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Altro', 'data-tip': 'Altro', onclick: (e) => { e.stopPropagation(); more(c, e.currentTarget); } }, icon('dots', 17, 'currentColor', 2)))),
        h('h3', { class: 'cg-name', 'data-notr': '' }, c.name),
        c.why ? h('p', { class: 'cg-why' }, c.why) : null));
    el.addEventListener('click', () => { if (selecting) { selected.has(c.id) ? selected.delete(c.id) : selected.add(c.id); drawGrid(); drawSel(); } else player(c); });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') el.click(); });
    return el;
  }

  function drawGrid() {
    const l = visible();
    if (!data.clips.length) { grid.replaceChildren(empty()); return; }
    if (!l.length) { grid.replaceChildren(h('div', { class: 'cg-none' }, 'Nessuna clip con questi filtri.')); return; }
    grid.replaceChildren(...l.map(card));
  }

  function empty() {
    if (data.kind === 'blank' || data.kind === 'story') {
      // progetto vuoto: niente live da leggere, si spiega come arrivarci invece di far partire una ricerca che fallisce
      return h('div', { class: 'cg-empty' },
        h('div', { class: 'cg-empty-art' }, h('span'), h('span'), h('span')),
        h('h2', null, 'Le clip AI partono da una live o da un video lungo'),
        h('p', null, 'Questo è un progetto vuoto, quindi non c\'è niente da cui tirare fuori le clip. Importa la tua live (o un podcast, un video lungo) dalla Home come nuovo progetto: l\'AI trova i momenti migliori e li monta in verticale, con sottotitoli e titoli.'),
        h('button', { class: 'btn primary lg', onclick: () => nav('home') }, icon('upload', 15, '#fff', 2.2), 'Importa una live'));
    }
    const est = h('p', { class: 'cg-est' }, ' ');
    post(`/api/p/${pid}/clipestimate`).then((e) => {
      if (!alive) return;
      if (e.error) { est.textContent = e.error; return; }
      est.textContent = `Circa ${e.target} clip per questa live · lettura AI ~$${(+e.usd).toFixed(2)}` + (e.hasTranscript ? '' : ' · prima la trascrivo');
    }).catch(() => {});
    return h('div', { class: 'cg-empty' },
      h('div', { class: 'cg-empty-art' }, h('span'), h('span'), h('span')),
      h('h2', null, 'Le clip migliori della tua live, già montate'),
      h('p', null, 'L\'AI ascolta la live, trova i momenti che possono diventare virali e li trasforma in clip verticali: webcam sopra, gioco sotto, sottotitoli grandi e silenzi tolti. Ogni clip ha un punteggio e il motivo.'),
      est,
      h('button', { class: 'btn primary lg', onclick: () => start() }, icon('sparkle', 15, '#fff', 2.2), 'Trova le clip virali'));
  }

  function drawSel() {
    if (!selecting) { selBar.style.display = 'none'; return; }
    selBar.style.display = '';
    const n = selected.size;
    selBar.replaceChildren(h('span', null, n ? `${n} ${n === 1 ? 'clip selezionata' : 'clip selezionate'}` : 'Tocca le clip da scegliere'),
      h('button', { class: 'btn sm', type: 'button', onclick: () => { visible().forEach((c) => selected.add(c.id)); drawGrid(); drawSel(); } }, 'Tutte'),
      h('button', { class: 'btn sm danger', type: 'button', disabled: n ? null : true, onclick: () => removeClips([...selected]) }, icon('trash', 13, 'currentColor', 2), 'Elimina'),
      h('button', { class: 'btn sm primary', type: 'button', disabled: n ? null : true, onclick: () => exportClips([...selected]) }, icon('download', 13, '#fff', 2.2), 'Esporta'));
  }

  // ---------------------------------------------------------------- azioni
  async function openClip(c) {
    try { await bakeHooks(c.id); } catch (e) { /* la scritta la ridisegna l'editor */ }
    nav('editor', c.id);
  }
  async function exportClips(ids) {
    try {
      for (const id of ids) { const c = data.clips.find((x) => x.id === id); if (c && c.needsBake) await bakeHooks(id); }
    } catch (e) { return toast(e.message, true); }
    nav('export', pid, { vod: false, verticals: ids, back: pid, backTo: 'clips' });
  }
  async function rename(c) {
    const nm = await promptBox('Rinomina la clip', 'È anche il nome del file quando la esporti.', c.name, 'Rinomina');
    if (!nm || nm === c.name) return;
    try { await post(`/api/p/${c.id}/rename`, { name: nm }); await post(`/api/p/${pid}/cliprename`, { id: c.id, name: nm }); } catch (e) { return toast(e.message, true); }
    c.name = nm; drawGrid();
  }
  async function removeClips(ids) {
    const one = ids.length === 1;
    if (!await confirmBox(one ? 'Eliminare la clip?' : `Eliminare ${ids.length} clip?`, 'Il video della live resta com\'è.', 'Elimina', true)) return;
    for (const id of ids) {
      try { await api('DELETE', '/api/p/' + id); } catch (e) { /* gia' tolta */ }
      try { await post(`/api/p/${pid}/clipremove`, { id }); } catch (e) { /* */ }
    }
    data.clips = data.clips.filter((c) => !ids.includes(c.id));
    selected.clear(); drawTools(); drawGrid(); drawSel();
  }
  function more(c, at) {
    document.querySelectorAll('.popmenu').forEach((x) => x.remove());
    const it = (ic, label, fn, cls) => h('button', { class: 'pm-it' + (cls ? ' ' + cls : ''), role: 'menuitem', onclick: () => { close(); fn(); } },
      h('span', { class: 'pm-ic' }, icon(ic, 16, cls === 'danger' ? 'var(--danger)' : 'currentColor')), h('span', { class: 'pm-tx' }, h('b', null, label)));
    const m = h('div', { class: 'popmenu cg-menu', role: 'menu' },
      it('play', 'Guarda', () => player(c)), it('expand', 'Allunga o accorcia', () => extendBox(c)), it('type', 'Rinomina', () => rename(c)), it('refresh', 'Aggiorna l\'anteprima', () => refresh([c.id])),
      it('trash', 'Elimina', () => removeClips([c.id]), 'danger'));
    document.body.append(m);
    const r = at.getBoundingClientRect();
    m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, r.right - m.offsetWidth)) + 'px';
    m.style.top = (r.bottom + m.offsetHeight + 8 < innerHeight ? r.bottom + 6 : r.top - m.offsetHeight - 6) + 'px';
    // si chiude cliccando fuori, scorrendo la pagina, ridimensionando, con Esc o cambiando schermata
    const close = () => { m.remove(); removeEventListener('pointerdown', out, true); removeEventListener('scroll', close, true); removeEventListener('wheel', close, true);
      removeEventListener('resize', close); removeEventListener('keydown', esc, true); menuClose = null; };
    const out = (e) => { if (!m.contains(e.target)) close(); };
    const esc = (e) => { if (e.key === 'Escape') close(); };
    menuClose = close;
    setTimeout(() => { if (!m.isConnected) return; addEventListener('pointerdown', out, true); addEventListener('scroll', close, true); addEventListener('wheel', close, { capture: true, passive: true });
      addEventListener('resize', close); addEventListener('keydown', esc, true); }, 0);
  }

  // finestra per guardare una clip con l'audio, con il punteggio e il motivo
  function player(c) {
    const list = visible();
    let idx = list.findIndex((x) => x.id === c.id);
    const bg = h('div', { class: 'modal-bg cg-modal-bg' });
    const box = h('div', { class: 'cg-modal', role: 'dialog', 'aria-modal': 'true' });
    const close = () => { bg.remove(); removeEventListener('keydown', key); };
    const key = (e) => { if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') go(1); if (e.key === 'ArrowLeft') go(-1); };
    function go(d) { if (list.length < 2) return; idx = (idx + d + list.length) % list.length; draw(); }
    function draw() {
      const x = list[idx];
      const media = x.preview ? h('video', { class: 'cg-mvid', src: mediaUrl(x.preview) + '&v=' + Math.round(x.previewAt || 0), poster: x.poster ? mediaUrl(x.poster) : null, controls: true, autoplay: true, playsinline: true })
        : h('div', { class: 'cg-mnone' }, h('img', { src: thumbUrl(pid, x.a + 1, 640), alt: '' }), h('span', null, 'L\'anteprima non è ancora pronta'));
      box.replaceChildren(...[
        h('button', { class: 'iconbtn cg-mx', 'aria-label': 'Chiudi', onclick: close }, icon('x', 18, 'currentColor', 2)),
        list.length > 1 ? h('button', { class: 'iconbtn cg-mnav l', 'aria-label': 'Clip precedente', onclick: () => go(-1) }, icon('left', 20, 'currentColor', 2.2)) : null,
        h('div', { class: 'cg-mstage' }, media),
        h('div', { class: 'cg-minfo' },
          h('div', { class: 'cg-mscore' }, h('b', { style: { color: scoreColor(x.score) } }, x.score != null ? String(x.score) : '–'), h('span', null, 'su 100 di viralità')),
          h('h2', { 'data-notr': '' }, x.name),
          x.why ? h('p', { class: 'cg-mwhy' }, x.why) : null,
          pfBox(x),
          h('dl', { class: 'cg-mfacts' },
            h('dt', null, 'Durata'), h('dd', null, mmss(x.dur)),
            h('dt', null, 'Nella live'), h('dd', null, hms(x.a) + ' – ' + hms(x.b)),
            x.hook ? h('dt', null, 'Scritta d\'apertura') : null, x.hook ? h('dd', { 'data-notr': '' }, x.hook) : null),
          h('div', { class: 'cg-mbtns' },
            h('button', { class: 'btn primary', onclick: () => { close(); openClip(x); } }, icon('scissors', 14, '#fff', 2), 'Modifica'),
            h('button', { class: 'btn', onclick: () => { close(); extendBox(x); }, 'data-tip': 'Aggiungi il contesto prima o il finale dopo, prendendolo dalla live' }, icon('expand', 14, 'currentColor', 2), 'Allunga'),
            h('button', { class: 'btn', onclick: () => { close(); exportClips([x.id]); } }, icon('download', 14, 'currentColor', 2), 'Esporta'))),
        list.length > 1 ? h('button', { class: 'iconbtn cg-mnav r', 'aria-label': 'Clip successiva', onclick: () => go(1) }, icon('right', 20, 'currentColor', 2.2)) : null].filter(Boolean));
    }
    bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
    bg.append(box); document.body.append(bg); addEventListener('keydown', key); draw();
  }

  // ---------------------------------------------------------------- ricerca con l'AI e anteprime
  function showStatus(j, label) {
    status.style.display = '';
    const pct = Math.round((j.progress || 0) * 100);
    status.replaceChildren(...[h('span', { class: 'spinner sm' }),
      h('div', { class: 'cg-st-tx' }, h('b', null, label), h('span', null, j.message || '…')),
      h('div', { class: 'cg-st-bar' }, h('div', { style: { width: pct + '%' } })),
      h('span', { class: 'cg-st-pct' }, pct + '%'),
      j.kind === 'clips' ? h('button', { class: 'btn sm', onclick: () => post(`/api/jobs/${j.id}/cancel`).catch(() => {}) }, 'Annulla') : null].filter(Boolean));
  }
  async function start() {
    if (job) return;
    if (data.clips.some((c) => c.ai && c.edited) || data.clips.length) {
      if (!await confirmBox('Cerco di nuovo le clip?', 'Le clip dell\'AI che non hai modificato vengono sostituite. Quelle che hai modificato restano.', 'Cerca di nuovo')) return;
    }
    if (!await lookBox({ search: true })) return;   // i passaggi iniziali: come escono le clip
    if (job || !alive) return;
    const body = { prompt: qIn.value.trim() };
    if (!data.clips.length) body.lang = findLang.value;   // con le clip gia' fatte la lingua si cambia dal menu della galleria
    try { job = await post(`/api/p/${pid}/clips`, body); } catch (e) { return toast(e.message, true); }
    // le anteprime in corso sono delle clip che stanno per essere sostituite: si fermano, cosi' si vede solo la ricerca
    if (pjob) post(`/api/jobs/${pjob.id}/cancel`).catch(() => {});
    queued.clear();
    findBtn.disabled = true;
    await follow();
  }
  async function follow() {
    if (!job) return;
    findBtn.disabled = true;
    drawGrid();
    showStatus(job, 'L\'AI cerca le clip');
    let r;
    try { r = await pollJob(job.id, (j) => { if (alive) showStatus(j, 'L\'AI cerca le clip'); }); } catch (e) { r = { status: 'error', error: e.message }; }
    job = null; findBtn.disabled = false;
    if (!alive) return;
    status.style.display = 'none';
    if (r.status !== 'done') { if (r.error && !/annullat/i.test(r.error)) toast(r.error, true); await reload(); return; }
    toast(`${(r.result.clips || []).length} clip pronte da guardare`);
    await reload();
    await previews();
  }
  async function reload() {
    try { data = await post(`/api/p/${pid}/cliplist`); } catch (e) { return; }
    if (alive) { drawTools(); drawGrid(); drawSel(); }
  }
  async function refresh(ids) {
    for (const id of ids) {
      try { await bakeHooks(id); } catch (e) { /* */ }
    }
    await previews(ids);
  }
  // anteprime: prima le scritte d'apertura (le disegna l'app), poi i video leggeri, che compaiono uno alla volta
  const tried = new Set();   // anteprime gia' provate in questa visita (se una non riesce non si riprova all'infinito)
  async function previews(only) {
    if (job) return;   // mentre l'AI cerca le clip non si preparano anteprime (le fa alla fine)
    const need = (only || data.clips.filter((c) => (!c.preview || c.stale || c.needsBake) && !tried.has(c.id + ':' + (c.updated || 0))).map((c) => c.id))
      .filter((id) => data.clips.some((c) => c.id === id));
    if (!need.length) return;
    if (pjob) { need.forEach((id) => queued.add(id)); drawGrid(); return; }   // dopo quelle in corso
    for (const id of need) {
      const c = data.clips.find((x) => x.id === id);
      if (c && c.needsBake) { try { await bakeHooks(id); } catch (e) { console.warn(e); } }
    }
    if (pjob) return;
    need.forEach((id) => { working.add(id); const c = data.clips.find((x) => x.id === id); if (c) tried.add(c.id + ':' + (c.updated || 0)); });
    drawGrid();
    try { pjob = await post(`/api/p/${pid}/clippreview`, { ids: need }); } catch (e) { working.clear(); return toast(e.message, true); }
    await followPrev();
  }
  async function followPrev() {
    if (!pjob) return;
    let lastDone = -1;
    if (!job) showStatus(pjob, 'Preparo le anteprime');
    const timer = setInterval(async () => {
      try {
        const d = await post(`/api/p/${pid}/cliplist`);
        if (!alive || job) return;
        const ready = d.clips.filter((c) => c.preview && !c.stale && working.has(c.id)).map((c) => c.id);   // un'anteprima vecchia da rifare non e' pronta
        if (ready.length !== lastDone) { lastDone = ready.length; ready.forEach((id) => working.delete(id)); data = d; drawGrid(); }
      } catch (e) { /* */ }
    }, 4000);
    try { await pollJob(pjob.id, (j) => { if (alive && !job) showStatus(j, 'Preparo le anteprime'); }); } catch (e) { /* */ }
    clearInterval(timer);
    pjob = null; working.clear();
    if (!alive || job) return;   // c'e' una ricerca in corso: lo stato lo mostra lei
    status.style.display = 'none';
    await reload();
    const next = [...queued].filter((id) => data.clips.some((c) => c.id === id && (!c.preview || c.stale || c.needsBake)));
    queued.clear();
    if (next.length) await previews(next);
  }

  let menuClose = null;
  setCleanup(() => { alive = false; if (menuClose) menuClose(); document.querySelectorAll('.cg-menu').forEach((x) => x.remove()); });
  drawTools(); drawGrid(); drawSel();
  if (job && pjob) { post(`/api/jobs/${pjob.id}/cancel`).catch(() => {}); pjob = null; }   // una cosa alla volta: prima la ricerca
  if (job) follow();
  else if (pjob) followPrev();
  else if (data.clips.some((c) => !c.preview || c.stale || c.needsBake)) previews();
}
