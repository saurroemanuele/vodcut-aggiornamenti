// Crediti NoonFrame: saldo, piani mensili, ricariche e offerte lampo.
// Il listino arriva sempre dal server (lo decide il pannello admin): qui niente prezzi scritti a mano.
import { get, post, h, icon, toast } from './lib.js';
import { LANG } from './i18n.js';

const nf = (n) => Math.round(+n || 0).toLocaleString('it-IT');
const eur = (n) => (+n || 0).toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
const day = (iso) => { try { return new Date(iso).toLocaleDateString('it-IT', { day: 'numeric', month: 'short' }); } catch (e) { return ''; } };

// quanto "vale" una quantita' di crediti, in cose concrete (costi medi dei servizi)
function worth(credits, perUsd) {
  const p = perUsd || 280;
  const video = Math.floor(credits / Math.ceil(0.42 * p));      // video AI da 5 s (Kling standard)
  const img = Math.floor(credits / Math.ceil(0.08 * p));         // immagine AI
  return { video, img };
}

// tempo che manca, che si aggiorna da solo
function countdown(iso) {
  const el = h('span', { class: 'cr-cd', 'data-notr': '' });
  const end = new Date(iso).getTime();
  const tick = () => {
    if (!el.isConnected && el._started) { clearInterval(el._iv); return; }
    el._started = true;
    let s = Math.max(0, Math.floor((end - Date.now()) / 1000));
    const d = Math.floor(s / 86400); s -= d * 86400;
    const hh = Math.floor(s / 3600); s -= hh * 3600;
    const mm = Math.floor(s / 60); s -= mm * 60;
    el.textContent = d > 0 ? `${d}${LANG === 'en' ? 'd' : 'g'} ${hh}h ${String(mm).padStart(2, '0')}m` : `${hh}h ${String(mm).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
  };
  tick(); el._iv = setInterval(tick, 1000);
  return el;
}

let CAT = null, CAT_AT = 0;
export async function loadCatalog(force) {
  if (!force && CAT && Date.now() - CAT_AT < 5 * 60 * 1000) return CAT;
  CAT = await get('/api/ai/catalog'); CAT_AT = Date.now();
  return CAT;
}

async function buy(kind, id, btn) {
  btn.disabled = true;
  try { await post('/api/ai/buy', { item: { kind, id } }); toast('Fatto'); }
  catch (e) {
    // "pagamenti in arrivo" non e' un errore dell'app: avviso normale, niente finestra "Segnala il problema"
    if (/pagamenti arrivano|payments are coming/i.test(e.message)) toast(e.message); else toast(e.message, true);
  }
  finally { btn.disabled = false; }
}

export async function creditsDialog() {
  const bg = h('div', { class: 'modal-bg' });
  const body = h('div', { class: 'cr-body' }, h('div', { class: 'cr-load' }, h('div', { class: 'spinner' })));
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.append(h('div', { class: 'modal cr-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Crediti e piani' },
    h('div', { class: 'cr-head' }, h('h2', null, 'Crediti e piani'), h('button', { class: 'iconbtn', 'aria-label': 'Chiudi', onclick: close }, icon('x', 16))),
    body));
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  let c;
  try { c = await loadCatalog(true); } catch (e) { body.replaceChildren(h('p', { class: 'cr-err' }, e.message)); return; }
  if (!c.signedIn) {
    body.replaceChildren(h('div', { class: 'cr-empty' }, icon('sparkle', 28, 'var(--accent-hi)'),
      h('b', null, 'Accedi per usare i crediti'), h('p', null, 'I crediti sono legati al tuo account NoonFrame: accedi in alto a destra.')));
    return;
  }
  const cat = c.catalog || {}, per = c.creditsPerUsd || 280;
  const plan = c.plan || 'free';
  // saldo
  const bal = h('div', { class: 'cr-bal' },
    h('div', { class: 'cr-bal-n' }, icon('sparkle', 18, 'var(--accent-hi)', 2), h('b', { 'data-notr': '' }, nf(c.balance)), h('span', null, 'crediti')),
    h('div', { class: 'cr-bal-sub' },
      plan !== 'free'
        ? [h('span', { class: 'cr-pill' }, h('span', { 'data-notr': '' }, c.planName || plan)),
          h('span', null, h('b', { 'data-notr': '' }, nf(c.monthly)), ' ', h('span', null, 'del piano'), c.nextGrant ? [' · ', h('span', null, 'si rinnovano il'), ' ', h('span', { 'data-notr': '' }, day(c.nextGrant))] : null),
          h('span', null, h('b', { 'data-notr': '' }, nf(c.extra)), ' ', h('span', null, 'extra, non scadono'))]
        : [h('span', { class: 'cr-pill free' }, 'Gratis'), h('span', null, 'I crediti che hai non scadono. Con un piano ne ricevi di nuovi ogni mese.')]));
  const parts = [bal];
  // offerte lampo
  const offers = cat.offers || [];
  if (offers.length) {
    parts.push(h('div', { class: 'cr-sec' }, icon('bolt', 14, 'currentColor', 2.2), h('span', null, 'Offerte lampo')),
      h('div', { class: 'cr-offers' }, ...offers.map((o) => {
        const isPlan = o.kind === 'plan';
        const w = worth(o.credits || 0, per);
        return h('div', { class: 'cr-offer' },
          o.badge ? h('span', { class: 'cr-badge', 'data-notr': '' }, o.badge) : null,
          h('b', { class: 'cr-o-t', 'data-notr': '' }, o.title),
          o.subtitle ? h('p', { 'data-notr': '' }, o.subtitle) : null,
          h('div', { class: 'cr-o-price' },
            h('b', { 'data-notr': '' }, eur(o.price)), isPlan ? h('span', null, 'al mese') : null,
            isPlan && o.fullPrice ? h('s', { 'data-notr': '' }, eur(o.fullPrice)) : null),
          h('small', null, isPlan
            ? (o.months === 1 ? 'Il primo mese, poi ' + eur(o.fullPrice) + ' al mese' : 'Per ' + o.months + ' mesi, poi ' + eur(o.fullPrice) + ' al mese')
            : [h('span', { 'data-notr': '' }, nf(o.credits)), ' ', h('span', null, 'crediti che non scadono'), w.video ? [' · ≈ ', h('span', { 'data-notr': '' }, String(w.video)), ' ', h('span', null, 'video AI')] : null]),
          h('div', { class: 'cr-o-foot' }, h('span', { class: 'cr-o-end' }, icon('clock', 12, 'currentColor', 2), h('span', null, 'Scade tra'), ' ', countdown(o.endsAt)),
            h('button', { class: 'btn primary sm', onclick: (e) => buy('offer', o.id, e.currentTarget) }, 'Approfitta')));
      })));
  }
  // piani mensili
  const plans = cat.plans || [];
  if (plans.length) {
    parts.push(h('div', { class: 'cr-sec' }, icon('calendar', 14, 'currentColor', 2), h('span', null, 'Piani mensili')),
      h('div', { class: 'cr-plans' }, ...plans.map((p, i) => {
        const cur = p.id === plan, w = worth(p.monthly, per);
        const pick = plans.length >= 3 && i === Math.floor(plans.length / 2) && plan === 'free';
        return h('div', { class: 'cr-plan' + (cur ? ' cur' : '') + (pick ? ' pick' : '') + (p.premium ? ' prem' : '') },
          pick ? h('span', { class: 'cr-ribbon' }, 'Il più scelto') : null,
          h('div', { class: 'cr-p-name', 'data-notr': '' }, p.name),
          p.tagline ? h('div', { class: 'cr-p-tag', 'data-notr': '' }, p.tagline) : null,
          h('div', { class: 'cr-p-price' }, h('b', { 'data-notr': '' }, eur(p.price)), h('span', null, 'al mese')),
          h('div', { class: 'cr-p-cred' }, h('b', { 'data-notr': '' }, nf(p.monthly)), ' ', h('span', null, 'crediti al mese')),
          h('ul', null,
            h('li', null, '≈ ', h('span', { 'data-notr': '' }, String(w.video)), ' ', h('span', null, 'video AI da 5 secondi')),
            h('li', null, '≈ ', h('span', { 'data-notr': '' }, String(w.img)), ' ', h('span', null, 'immagini AI')),
            ...(p.perks || []).map((k) => h('li', { 'data-notr': '' }, k))),
          cur ? h('button', { class: 'btn sm', disabled: true }, 'Il tuo piano')
            : h('button', { class: 'btn sm' + (pick || p.premium ? ' primary' : ''), onclick: (e) => buy('plan', p.id, e.currentTarget) }, 'Scegli ' + p.name));
      })));
  }
  // ricariche
  const packs = cat.packs || [];
  if (packs.length) {
    parts.push(h('div', { class: 'cr-sec' }, icon('plus', 14, 'currentColor', 2.2), h('span', null, 'Ricariche'), h('small', null, 'i crediti non scadono')),
      h('div', { class: 'cr-packs' }, ...packs.map((k) => h('button', { class: 'cr-pack', onclick: (e) => buy('pack', k.id, e.currentTarget) },
        h('b', { 'data-notr': '' }, nf(k.credits)), h('span', null, 'crediti'), h('em', { 'data-notr': '' }, eur(k.price))))));
  }
  parts.push(h('p', { class: 'cr-foot' }, 'Prezzi IVA inclusa. Puoi disdire quando vuoi. Se una generazione non riesce, i crediti tornano da soli.'));
  body.replaceChildren(...parts);
}

// --------------------------------------------------------------- barra in alto: saldo (solo con i crediti attivi)
export function creditsChip() {
  const b = h('button', { class: 'cr-chip', style: { display: 'none' }, 'data-tip': 'Crediti e piani', onclick: () => creditsDialog() });
  get('/api/ai/wallet').then((c) => {
    c = c || {};
    if (!c.on || !c.loggedIn || c.balance == null) return;
    b.replaceChildren(icon('sparkle', 13, 'var(--accent-hi)', 2.2), h('span', { 'data-notr': '' }, nf(c.balance)));
    b.style.display = '';
    loadCatalog().then((cat) => { if (((cat.catalog || {}).offers || []).length) b.classList.add('deal'); }).catch(() => {});
  }).catch(() => {});
  return b;
}

// --------------------------------------------------------------- home: banner dell'offerta lampo piu' vicina alla scadenza
export function offerBanner() {
  const box = h('div', { class: 'cr-banner', style: { display: 'none' } });
  loadCatalog().then((c) => {
    const o = ((c.catalog || {}).offers || [])[0];
    if (!o) return;
    box.replaceChildren(h('span', { class: 'cr-bn-ic' }, icon('bolt', 15, '#fff', 2.2)),
      h('div', { class: 'cr-bn-t' }, h('b', { 'data-notr': '' }, o.title), o.subtitle ? h('span', { 'data-notr': '' }, o.subtitle) : null),
      h('span', { class: 'cr-bn-cd' }, icon('clock', 12, 'currentColor', 2), countdown(o.endsAt)),
      h('button', { class: 'btn primary sm', onclick: () => creditsDialog() }, 'Vedi offerta'));
    box.style.display = '';
  }).catch(() => {});
  return box;
}
