// Grafica: disegno del documento. Ogni livello si disegna una volta nel suo riquadro (contenuto + filtri + maschera
// + effetti) e si tiene in memoria; spostarlo, ruotarlo o cambiarne l'opacita' non lo ridisegna.
import { hex2rgba } from './doc.js';
import { ensureFont, fontReady } from '../fonts.js';

// ---------------------------------------------------------------- immagini della grafica (file e tele in memoria)
export class Assets {
  constructor(urlOf, onReady) { this.urlOf = urlOf; this.onReady = onReady; this.map = new Map(); }
  get(name) {
    if (!name) return null;
    let a = this.map.get(name);
    if (!a) {
      a = { el: null, w: 0, h: 0, ready: false, ver: 0 };
      this.map.set(name, a);
      const im = new Image();
      im.decoding = 'async';
      im.onload = () => { a.el = im; a.w = im.naturalWidth; a.h = im.naturalHeight; a.ready = true; a.ver++; this.onReady && this.onReady(name); };
      im.onerror = () => { a.failed = true; };
      im.src = this.urlOf(name);
    }
    return a.ready ? a : null;
  }
  // tela in memoria (pittura in corso, maschere, immagini appena caricate): si usa subito, il file arriva dopo
  put(name, canvas) { const a = this.map.get(name) || {}; Object.assign(a, { el: canvas, w: canvas.width, h: canvas.height, ready: true, ver: (a.ver || 0) + 1 }); this.map.set(name, a); return a; }
  alias(from, to) { const a = this.map.get(from); if (a) this.map.set(to, a); }
  touch(name) { const a = this.map.get(name); if (a) a.ver++; }
  ver(name) { const a = this.map.get(name); return a ? a.ver : 0; }
}

// ---------------------------------------------------------------- colori e riempimenti (tinta unita o sfumatura)
export function fillStyle(g, fill, w, h) {
  if (!fill) return null;
  if (typeof fill === 'string') return fill;
  if (fill.type === 'linear' || fill.type === 'radial') {
    let gr;
    if (fill.type === 'radial') gr = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) / 2);
    else {
      const a = ((fill.angle || 0) - 90) * Math.PI / 180, r = (Math.abs(w * Math.cos(a)) + Math.abs(h * Math.sin(a))) / 2;
      gr = g.createLinearGradient(w / 2 - Math.cos(a) * r, h / 2 - Math.sin(a) * r, w / 2 + Math.cos(a) * r, h / 2 + Math.sin(a) * r);
    }
    for (const [o, c] of fill.stops || []) { try { gr.addColorStop(Math.max(0, Math.min(1, o)), c); } catch (e) { /* colore non valido */ } }
    return gr;
  }
  return '#000';
}
export const fillColor = (fill) => (typeof fill === 'string' ? fill : fill && fill.stops && fill.stops[0] ? fill.stops[0][1] : '#000000');

// ---------------------------------------------------------------- testo
const measure = document.createElement('canvas').getContext('2d');
export const fontOf = (l, k = 1) => `${l.italic ? 'italic ' : ''}${l.weight || 400} ${Math.max(1, l.size * k)}px "${l.font || 'Inter'}", -apple-system, "Segoe UI", Arial, sans-serif`;
function widthOf(g, s, letter) { return g.measureText(s).width + Math.max(0, s.length - 1) * (letter || 0); }
// righe del testo dentro la larghezza del livello (a capo sulle parole)
export function textLines(l) {
  if (l.font) ensureFont(l.font);
  measure.font = fontOf(l);
  const txt = l.upper ? String(l.text || '').toUpperCase() : String(l.text || '');
  const maxW = l.w;
  const out = [];
  for (const para of txt.split('\n')) {
    const words = para.split(/(\s+)/);
    let line = '';
    for (const w of words) {
      const test = line + w;
      if (line && widthOf(measure, test.trimEnd(), l.letter) > maxW && w.trim()) { out.push(line.trimEnd()); line = w.trimStart(); }
      else line = test;
      // parola piu' lunga della riga: si spezza
      while (widthOf(measure, line, l.letter) > maxW && line.length > 1) {
        let n = line.length - 1;
        while (n > 1 && widthOf(measure, line.slice(0, n), l.letter) > maxW) n--;
        out.push(line.slice(0, n)); line = line.slice(n);
      }
    }
    out.push(line);
  }
  return out;
}
export function textHeight(l) {
  if (l.onPath) return l.h;
  if (l.curve) return Math.max(1, Math.round(curveGeom(l).h));
  return Math.max(1, Math.round(textLines(l).length * l.size * (l.lineH || 1.2)));
}
// testo curvo: una riga sola lungo un arco. curve -100..100 (100 = cerchio intero, negativo = verso il basso)
export function curveGeom(l, k = 1) {
  measure.font = fontOf(l);
  const txt = (l.upper ? String(l.text || '').toUpperCase() : String(l.text || '')).replace(/\n/g, ' ');
  const tw = Math.max(1, widthOf(measure, txt, l.letter));
  const th = Math.max(0.01, Math.abs(l.curve) / 100 * Math.PI * 2);
  const R = tw / th, fs = l.size;
  // altezza: freccia dell'arco + una riga di testo
  const sag = th >= Math.PI ? R + Math.min(R, R * (1 - Math.cos(th / 2))) : R * (1 - Math.cos(th / 2));
  const chord = th >= Math.PI ? 2 * R : 2 * R * Math.sin(th / 2);
  return { txt, tw: tw * k, th, R: R * k, h: (sag + fs * 1.25) * k, w: (chord + fs) * k, fs: fs * k };
}
// larghezza naturale (per il testo appena creato con un clic)
export function textNaturalWidth(l) {
  if (l.onPath) return l.w;
  if (l.curve) return Math.ceil(curveGeom(l).w) + 2;
  measure.font = fontOf(l);
  const txt = l.upper ? String(l.text || '').toUpperCase() : String(l.text || '');
  return Math.ceil(Math.max(1, ...txt.split('\n').map((s) => widthOf(measure, s, l.letter)))) + 2;
}
function drawText(g, l, k, cw) {
  g.font = fontOf(l, k);
  g.textBaseline = 'middle';
  if (l.onPath && l.pts && l.pts.length > 1) { drawTextOnPath(g, l, k, cw); return; }
  if (l.curve) {
    const c = curveGeom(l, k), up = l.curve > 0, sp = (l.letter || 0) * k;
    g.fillStyle = fillStyle(g, l.fill || l.color, cw, c.h) || '#000';
    // centro del cerchio: sotto il testo (arco verso l'alto) o sopra (arco verso il basso)
    const cx = cw / 2, cy = up ? c.fs * 0.62 + c.R : c.h - c.fs * 0.62 - c.R;
    let a = -c.th / 2;
    for (const ch of c.txt) {
      const w = g.measureText(ch).width + sp, mid = a + (w / 2) / c.R;
      g.save();
      if (up) { g.translate(cx + Math.sin(mid) * c.R, cy - Math.cos(mid) * c.R); g.rotate(mid); }
      else { g.translate(cx + Math.sin(mid) * c.R, cy + Math.cos(mid) * c.R); g.rotate(-mid); }
      g.textAlign = 'center'; g.fillText(ch, 0, 0); g.restore();
      a += w / c.R;
    }
    g.textAlign = 'start';
    return;
  }
  const lines = textLines(l), lh = l.size * (l.lineH || 1.2) * k, sp = (l.letter || 0) * k;
  g.fillStyle = fillStyle(g, l.fill || l.color, cw, lines.length * lh) || '#000';
  lines.forEach((s, i) => {
    const y = (i + 0.5) * lh, w = widthOf(g, s, sp);
    let x = l.align === 'left' ? 0 : l.align === 'right' ? cw - w : (cw - w) / 2;
    if (!sp) { g.fillText(s, x, y); return; }
    for (const ch of s) { g.fillText(ch, x, y); x += g.measureText(ch).width + sp; }
  });
}

// testo che segue un tracciato (punti in l.pts come i livelli della penna, margine = mezza riga)
export const pathPad = (l) => (l.type === 'path' ? ((l.stroke && l.strokeW) || 0) / 2 : l.onPath ? l.size * 0.75 : 0);
function samplePath(l, ox, oy, w, h) {
  const P = l.pts, out = [];
  const segs = [];
  for (let i = 1; i < P.length; i++) segs.push([P[i - 1], P[i]]);
  if (l.closed && P.length > 2) segs.push([P[P.length - 1], P[0]]);
  for (const [a, b] of segs) {
    const p0 = [a.x, a.y], p1 = [a.x + (a.ox || 0), a.y + (a.oy || 0)], p2 = [b.x + (b.ix || 0), b.y + (b.iy || 0)], p3 = [b.x, b.y];
    for (let t = out.length ? 1 : 0; t <= 60; t++) {
      const u = t / 60, v = 1 - u;
      const x = v * v * v * p0[0] + 3 * v * v * u * p1[0] + 3 * v * u * u * p2[0] + u * u * u * p3[0];
      const y = v * v * v * p0[1] + 3 * v * v * u * p1[1] + 3 * v * u * u * p2[1] + u * u * u * p3[1];
      out.push([ox + x * w, oy + y * h]);
    }
  }
  return out;
}
function drawTextOnPath(g, l, k, cw) {
  const m = pathPad(l) * k, ch = l.h * k;
  const pts = samplePath(l, m, m, cw - 2 * m, ch - 2 * m);
  const cum = [0];
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const total = cum[cum.length - 1];
  const txt = (l.upper ? String(l.text || '').toUpperCase() : String(l.text || '')).replace(/\n/g, ' ');
  const sp = (l.letter || 0) * k;
  const tw = widthOf(g, txt, sp);
  let s = l.align === 'left' ? 0 : l.align === 'right' ? total - tw : (total - tw) / 2;
  s += (l.pathStart || 0) * total;
  g.fillStyle = fillStyle(g, l.fill || l.color, cw, ch) || '#000';
  g.textAlign = 'center';
  let j = 0;
  const at = (d) => {   // punto e direzione a distanza d lungo il tracciato
    if (l.closed) d = ((d % total) + total) % total;
    while (j > 0 && cum[j] > d) j--;
    while (j < cum.length - 2 && cum[j + 1] < d) j++;
    const a = pts[j], b = pts[Math.min(j + 1, pts.length - 1)], seg = Math.max(1e-6, cum[j + 1] - cum[j]);
    const f = Math.max(0, Math.min(1, (d - cum[j]) / seg));
    return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, Math.atan2(b[1] - a[1], b[0] - a[0])];
  };
  for (const c of txt) {
    const w = g.measureText(c).width;
    const mid = s + w / 2;
    if (l.closed || (mid >= 0 && mid <= total)) {
      const [x, y, ang] = at(mid);
      g.save(); g.translate(x, y); g.rotate(ang); g.fillText(c, 0, -(l.size * k) * 0.18); g.restore();
    }
    s += w + sp;
  }
  g.textAlign = 'start';
}

// ---------------------------------------------------------------- tracciati (penna): punti 0..1 nel riquadro, maniglie relative
export function pathTrace(g, l, ox, oy, w, h) {
  const P = l.pts || [];
  g.beginPath();
  if (!P.length) return;
  const X = (v) => ox + v * w, Y = (v) => oy + v * h;
  g.moveTo(X(P[0].x), Y(P[0].y));
  const seg = (a, b) => {
    const c1x = a.x + (a.ox || 0), c1y = a.y + (a.oy || 0), c2x = b.x + (b.ix || 0), c2y = b.y + (b.iy || 0);
    if (!a.ox && !a.oy && !b.ix && !b.iy) g.lineTo(X(b.x), Y(b.y));
    else g.bezierCurveTo(X(c1x), Y(c1y), X(c2x), Y(c2y), X(b.x), Y(b.y));
  };
  for (let i = 1; i < P.length; i++) seg(P[i - 1], P[i]);
  if (l.closed && P.length > 2) { seg(P[P.length - 1], P[0]); g.closePath(); }
}

// ---------------------------------------------------------------- forme
export function shapePath(g, l, w, h) {
  g.beginPath();
  const k = l.kind;
  if (k === 'ellipse') g.ellipse(w / 2, h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
  else if (k === 'line') { g.moveTo(0, h / 2); g.lineTo(w, h / 2); }
  else if (k === 'triangle') { g.moveTo(w / 2, 0); g.lineTo(w, h); g.lineTo(0, h); g.closePath(); }
  else if (k === 'star' || k === 'poly') {
    const n = k === 'star' ? Math.max(3, l.sides || 5) : Math.max(3, l.sides || 6);
    const pts = k === 'star' ? n * 2 : n;
    for (let i = 0; i < pts; i++) {
      const a = -Math.PI / 2 + i * Math.PI * 2 / pts, r = k === 'star' && i % 2 ? (l.inner || 0.45) : 1;
      const x = w / 2 + Math.cos(a) * w / 2 * r, y = h / 2 + Math.sin(a) * h / 2 * r;
      if (i) g.lineTo(x, y); else g.moveTo(x, y);
    }
    g.closePath();
  } else {
    const r = Math.max(0, Math.min((l.radius || 0) * (w / Math.max(1, l.w)), w / 2, h / 2));
    if (g.roundRect && r) g.roundRect(0, 0, w, h, r); else g.rect(0, 0, w, h);
  }
}

// ---------------------------------------------------------------- filtri del livello e regolazioni
export function filterCss(f, k = 1) {
  if (!f) return 'none';
  const out = [];
  if (f.brightness) out.push(`brightness(${1 + f.brightness / 100})`);
  if (f.contrast) out.push(`contrast(${1 + f.contrast / 100})`);
  if (f.saturation) out.push(`saturate(${1 + f.saturation / 100})`);
  if (f.hue) out.push(`hue-rotate(${f.hue}deg)`);
  if (f.grayscale) out.push(`grayscale(${f.grayscale}%)`);
  if (f.sepia) out.push(`sepia(${f.sepia}%)`);
  if (f.invert) out.push(`invert(${f.invert}%)`);
  if (f.blur) out.push(`blur(${(f.blur * k).toFixed(2)}px)`);
  return out.length ? out.join(' ') : 'none';
}
export function adjustCss(l, k = 1) {
  const p = l.p || {};
  switch (l.kind) {
    case 'bc': return filterCss({ brightness: p.brightness, contrast: p.contrast });
    case 'hsl': return filterCss({ hue: p.hue, saturation: p.saturation, brightness: p.lightness });
    case 'bw': return `grayscale(${p.amount == null ? 100 : p.amount}%)`;
    case 'warm': { const a = p.amount || 0; return a >= 0 ? `sepia(${a * 0.6}%) saturate(${1 + a / 200})` : `hue-rotate(${a * 0.4}deg) saturate(${1 + a / 300})`; }
    case 'invert': return 'invert(100%)';
    case 'blur': return `blur(${((p.amount || 0) * k).toFixed(2)}px)`;
    default: return 'none';
  }
}

// ---------------------------------------------------------------- regolazioni "pro" (pixel per pixel)
export const PIXEL_ADJ = new Set(['curves', 'levels', 'exposure', 'vibrance', 'colorbal', 'gradmap', 'photo', 'shadhigh', 'lut']);
// curva monotona (punti 0..255) -> tabella di 256 valori
export function curveLut(pts) {
  const P = (pts && pts.length >= 2 ? pts : [[0, 0], [255, 255]]).slice().sort((a, b) => a[0] - b[0]);
  const n = P.length, xs = P.map((p) => p[0]), ys = P.map((p) => p[1]);
  const d = [], m = new Array(n).fill(0);
  for (let i = 0; i < n - 1; i++) d.push((ys[i + 1] - ys[i]) / Math.max(1e-6, xs[i + 1] - xs[i]));
  m[0] = d[0]; m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i++) m[i] = d[i - 1] * d[i] <= 0 ? 0 : (d[i - 1] + d[i]) / 2;
  const out = new Uint8ClampedArray(256);
  for (let x = 0; x < 256; x++) {
    let k = 0; while (k < n - 2 && x > xs[k + 1]) k++;
    if (x <= xs[0]) { out[x] = ys[0]; continue; }
    if (x >= xs[n - 1]) { out[x] = ys[n - 1]; continue; }
    const hh = xs[k + 1] - xs[k], t = (x - xs[k]) / hh, t2 = t * t, t3 = t2 * t;
    out[x] = (2 * t3 - 3 * t2 + 1) * ys[k] + (t3 - 2 * t2 + t) * hh * m[k] + (-2 * t3 + 3 * t2) * ys[k + 1] + (t3 - t2) * hh * m[k + 1];
  }
  return out;
}
const hexRgb = (h0) => { let s = String(h0 || '#000').replace('#', ''); if (s.length === 3) s = s.split('').map((c) => c + c).join(''); const n = parseInt(s, 16) || 0; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const lutCache = new Map();
export function pixelAdjust(g, l, clip) {
  const W = g.canvas.width, H = g.canvas.height;
  let [x, y, w, h] = clip ? clip.map(Math.round) : [0, 0, W, H];
  x = Math.max(0, x); y = Math.max(0, y); w = Math.min(W - x, w); h = Math.min(H - y, h);
  if (w <= 0 || h <= 0) return;
  const im = g.getImageData(x, y, w, h), d = im.data, p = l.p || {};
  const n = d.length;
  if (l.kind === 'curves' || l.kind === 'levels' || l.kind === 'exposure' || l.kind === 'colorbal') {
    // tre tabelle (R, G, B)
    let R, G, B;
    if (l.kind === 'curves') { const M = curveLut(p.rgb); const cr = curveLut(p.r), cg = curveLut(p.g), cb = curveLut(p.b); R = cr.map((v, i) => cr[M[i]]); G = cg.map((v, i) => cg[M[i]]); B = cb.map((v, i) => cb[M[i]]); }
    else if (l.kind === 'levels') {
      const ib = p.inBlack || 0, iw = p.inWhite == null ? 255 : p.inWhite, ga = p.gamma || 1, ob = p.outBlack || 0, ow = p.outWhite == null ? 255 : p.outWhite;
      R = new Uint8ClampedArray(256); for (let i = 0; i < 256; i++) { const t = Math.max(0, Math.min(1, (i - ib) / Math.max(1, iw - ib))); R[i] = ob + Math.pow(t, 1 / ga) * (ow - ob); }
      G = R; B = R;
    } else if (l.kind === 'exposure') {
      const e = Math.pow(2, p.exposure || 0), off = (p.offset || 0) / 100, ga = p.gamma || 1;
      R = new Uint8ClampedArray(256); for (let i = 0; i < 256; i++) { const lin = Math.pow(i / 255, 2.2) * e + off; R[i] = 255 * Math.pow(Math.max(0, Math.min(1, lin)), 1 / 2.2 / ga); }
      G = R; B = R;
    } else {
      // bilanciamento colore sui toni medi (e un po' su ombre e luci)
      const cr = (p.cr || 0) / 100, mg = (p.mg || 0) / 100, yb = (p.yb || 0) / 100;
      const f = (i, a) => { const t = i / 255, w0 = 1 - Math.abs(t - 0.5) * 1.4; return i + a * 60 * Math.max(0.2, w0); };
      R = new Uint8ClampedArray(256); G = new Uint8ClampedArray(256); B = new Uint8ClampedArray(256);
      for (let i = 0; i < 256; i++) { R[i] = f(i, cr); G[i] = f(i, mg); B[i] = f(i, yb); }
    }
    for (let i = 0; i < n; i += 4) { d[i] = R[d[i]]; d[i + 1] = G[d[i + 1]]; d[i + 2] = B[d[i + 2]]; }
  } else if (l.kind === 'vibrance') {
    const v = (p.vibrance || 0) / 100, s = (p.saturation || 0) / 100;
    for (let i = 0; i < n; i += 4) {
      const r = d[i], gg = d[i + 1], b = d[i + 2], mx = Math.max(r, gg, b), mn = Math.min(r, gg, b), avg = (r + gg + b) / 3;
      const sat = (mx - mn) / 255;
      const k = 1 + s + v * (1 - sat) * 1.5;   // la vividezza spinge di piu' i colori spenti
      d[i] = avg + (r - avg) * k; d[i + 1] = avg + (gg - avg) * k; d[i + 2] = avg + (b - avg) * k;
    }
  } else if (l.kind === 'gradmap') {
    const stops = (p.stops || [[0, '#000000'], [1, '#FFFFFF']]).map(([o, c]) => [o, hexRgb(c)]).sort((a, b) => a[0] - b[0]);
    const T = new Uint8ClampedArray(256 * 3);
    for (let i = 0; i < 256; i++) {
      const t = i / 255; let k = 0; while (k < stops.length - 2 && t > stops[k + 1][0]) k++;
      const a = stops[k], b = stops[Math.min(k + 1, stops.length - 1)], f = b[0] > a[0] ? Math.max(0, Math.min(1, (t - a[0]) / (b[0] - a[0]))) : 0;
      for (let c = 0; c < 3; c++) T[i * 3 + c] = a[1][c] + (b[1][c] - a[1][c]) * f;
    }
    for (let i = 0; i < n; i += 4) { const L = Math.round(0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]); d[i] = T[L * 3]; d[i + 1] = T[L * 3 + 1]; d[i + 2] = T[L * 3 + 2]; }
  } else if (l.kind === 'photo') {
    const [cr, cg, cb] = hexRgb(p.color || '#EC8A00'), dn = (p.density == null ? 25 : p.density) / 100;
    for (let i = 0; i < n; i += 4) {
      const L0 = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2];
      let r = d[i] * (1 - dn) + (d[i] * cr / 255) * dn * 1.6, gg = d[i + 1] * (1 - dn) + (d[i + 1] * cg / 255) * dn * 1.6, b = d[i + 2] * (1 - dn) + (d[i + 2] * cb / 255) * dn * 1.6;
      if (p.keepLum !== false) { const L1 = 0.2126 * r + 0.7152 * gg + 0.0722 * b || 1, k = L0 / L1; r *= k; gg *= k; b *= k; }
      d[i] = r; d[i + 1] = gg; d[i + 2] = b;
    }
  } else if (l.kind === 'shadhigh') {
    const sa = (p.shadows || 0) / 100, ha = (p.highlights || 0) / 100;
    for (let i = 0; i < n; i += 4) {
      const L = (0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]) / 255;
      const ws = Math.pow(1 - L, 2), wh = Math.pow(L, 2);
      const k = 1 + sa * ws * 1.2 - ha * wh * 0.6;
      const add = sa * ws * 40 - ha * wh * 40;
      d[i] = d[i] * k + add; d[i + 1] = d[i + 1] * k + add; d[i + 2] = d[i + 2] * k + add;
    }
  } else if (l.kind === 'lut' && p.lut) {
    let L3 = lutCache.get(p.lut);
    if (!L3) { L3 = parseCube(p.lut); lutCache.set(p.lut, L3); }
    if (L3) {
      const N = L3.size, T = L3.data, s = (N - 1) / 255, amt = p.amount == null ? 1 : p.amount / 100;
      const N2 = N * N, out = [0, 0, 0];
      for (let i = 0; i < n; i += 4) {
        // interpolazione trilineare
        const r = d[i] * s, gg = d[i + 1] * s, b = d[i + 2] * s;
        const r0 = Math.min(N - 2, r | 0), g0 = Math.min(N - 2, gg | 0), b0 = Math.min(N - 2, b | 0), fr = r - r0, fg = gg - g0, fb = b - b0;
        for (let c = 0; c < 3; c++) {
          const o = (b0 * N2 + g0 * N + r0) * 3 + c;
          const c00 = T[o] + (T[o + 3] - T[o]) * fr, c10 = T[o + N * 3] + (T[o + N * 3 + 3] - T[o + N * 3]) * fr;
          const c01 = T[o + N2 * 3] + (T[o + N2 * 3 + 3] - T[o + N2 * 3]) * fr, c11 = T[o + N2 * 3 + N * 3] + (T[o + N2 * 3 + N * 3 + 3] - T[o + N2 * 3 + N * 3]) * fr;
          const c0 = c00 + (c10 - c00) * fg, c1 = c01 + (c11 - c01) * fg;
          out[c] = (c0 + (c1 - c0) * fb) * 255;
        }
        d[i] += (out[0] - d[i]) * amt; d[i + 1] += (out[1] - d[i + 1]) * amt; d[i + 2] += (out[2] - d[i + 2]) * amt;
      }
    }
  }
  g.putImageData(im, x, y);
}
// LUT .cube (formato standard dei colori da film)
export function parseCube(txt) {
  // forma compatta salvata nella grafica: "nf:N:<base64 di N^3*3 byte>"
  if (String(txt).startsWith('nf:')) {
    const [, nn, b64] = String(txt).split(':'); const N = parseInt(nn, 10);
    try { const bin = atob(b64); if (!N || bin.length < N * N * N * 3) return null; const data = new Float32Array(N * N * N * 3); for (let i = 0; i < data.length; i++) data[i] = bin.charCodeAt(i) / 255; return { size: N, data }; } catch (e) { return null; }
  }
  const lines = String(txt).split(/\r?\n/);
  let size = 0; const vals = [];
  for (const ln of lines) {
    const t = ln.trim(); if (!t || t[0] === '#') continue;
    if (/^LUT_3D_SIZE/i.test(t)) { size = parseInt(t.split(/\s+/)[1], 10); continue; }
    if (/^[A-Z_]/i.test(t)) continue;
    const p = t.split(/\s+/).map(Number); if (p.length >= 3 && p.every((v) => isFinite(v))) vals.push(p[0], p[1], p[2]);
  }
  if (!size || vals.length < size * size * size * 3) return null;
  return { size, data: new Float32Array(vals.slice(0, size * size * size * 3)) };
}

// ---------------------------------------------------------------- deformazioni (trasformazione libera)
// quadrato unitario -> quadrilatero (angoli: in alto a sinistra, in alto a destra, in basso a destra, in basso a sinistra)
export function quadMap(p) {
  const [x0, y0] = p[0], [x1, y1] = p[1], [x2, y2] = p[2], [x3, y3] = p[3];
  const dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
  let G = 0, Hh = 0;
  if (Math.abs(dx3) > 1e-9 || Math.abs(dy3) > 1e-9) { const den = dx1 * dy2 - dx2 * dy1 || 1e-9; G = (dx3 * dy2 - dx2 * dy3) / den; Hh = (dx1 * dy3 - dx3 * dy1) / den; }
  const a = x1 - x0 + G * x1, b = x3 - x0 + Hh * x3, d = y1 - y0 + G * y1, e = y3 - y0 + Hh * y3;
  return (s, t) => { const w = G * s + Hh * t + 1 || 1e-9; return [(a * s + b * t + x0) / w, (d * s + e * t + y0) / w]; };
}
const bern = (t) => { const u = 1 - t; return [u * u * u, 3 * u * u * t, 3 * u * t * t, t * t * t]; };
// superficie di Bezier 4x4 (16 punti, per righe)
export function meshMap(p) {
  return (s, t) => {
    const bs = bern(s), bt = bern(t); let x = 0, y = 0;
    for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) { const w = bs[i] * bt[j], q = p[j * 4 + i]; x += q[0] * w; y += q[1] * w; }
    return [x, y];
  };
}
export const warpMap = (wp) => (wp.kind === 'mesh' && wp.pts.length === 16 ? meshMap(wp.pts) : quadMap(wp.pts));
// deformazione calcolata pixel per pixel: per ogni triangolo della griglia, ogni pixel di arrivo prende il colore
// dal punto giusto della sorgente (interpolato). Niente cuciture tra i triangoli.
export function warpCanvas(src, wp, dw, dh) {
  const O = mk(dw, dh), og = O.getContext('2d');
  const sw = src.width, sh = src.height;
  let sd;
  try { sd = src.getContext('2d').getImageData(0, 0, sw, sh).data; } catch (e) { return O; }
  const out = og.createImageData(dw, dh), od = out.data;
  const f = warpMap(wp), N = wp.kind === 'mesh' ? 24 : 16;
  const P = [];
  for (let j = 0; j <= N; j++) for (let i = 0; i <= N; i++) { const q = f(i / N, j / N); P.push([q[0] * dw, q[1] * dh]); }
  const sample = (x, y, o) => {
    // bilineare con alfa premoltiplicato (niente aloni scuri sui bordi)
    x -= 0.5; y -= 0.5;
    const x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0;
    let r = 0, g = 0, b = 0, a = 0;
    for (let k = 0; k < 4; k++) {
      const xx = Math.min(sw - 1, Math.max(0, x0 + (k & 1))), yy = Math.min(sh - 1, Math.max(0, y0 + (k >> 1)));
      const w = ((k & 1) ? fx : 1 - fx) * ((k >> 1) ? fy : 1 - fy);
      if (w <= 0) continue;
      const i = (yy * sw + xx) * 4, al = sd[i + 3] * w;
      r += sd[i] * al; g += sd[i + 1] * al; b += sd[i + 2] * al; a += al;
    }
    if (a > 0) { od[o] = r / a; od[o + 1] = g / a; od[o + 2] = b / a; od[o + 3] = a; }
  };
  const tri = (d0, d1, d2, s0, s1, s2) => {
    const minX = Math.max(0, Math.floor(Math.min(d0[0], d1[0], d2[0]))), maxX = Math.min(dw - 1, Math.ceil(Math.max(d0[0], d1[0], d2[0])));
    const minY = Math.max(0, Math.floor(Math.min(d0[1], d1[1], d2[1]))), maxY = Math.min(dh - 1, Math.ceil(Math.max(d0[1], d1[1], d2[1])));
    const den = (d1[1] - d2[1]) * (d0[0] - d2[0]) + (d2[0] - d1[0]) * (d0[1] - d2[1]);
    if (Math.abs(den) < 1e-9) return;
    const eps = -1e-6;
    for (let y = minY; y <= maxY; y++) {
      const py = y + 0.5;
      for (let x = minX; x <= maxX; x++) {
        const px = x + 0.5;
        const w0 = ((d1[1] - d2[1]) * (px - d2[0]) + (d2[0] - d1[0]) * (py - d2[1])) / den;
        const w1 = ((d2[1] - d0[1]) * (px - d2[0]) + (d0[0] - d2[0]) * (py - d2[1])) / den;
        const w2 = 1 - w0 - w1;
        if (w0 < eps || w1 < eps || w2 < eps) continue;
        const o = (y * dw + x) * 4;
        if (od[o + 3]) continue;   // gia' fatto da un triangolo davanti (pieghe)
        sample(w0 * s0[0] + w1 * s1[0] + w2 * s2[0], w0 * s0[1] + w1 * s1[1] + w2 * s2[1], o);
      }
    }
  };
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
    const a = j * (N + 1) + i, b = a + 1, c = a + N + 1, d = c + 1;
    const sa = [i / N * sw, j / N * sh], sb = [(i + 1) / N * sw, j / N * sh], sc = [i / N * sw, (j + 1) / N * sh], sdd = [(i + 1) / N * sw, (j + 1) / N * sh];
    tri(P[a], P[b], P[d], sa, sb, sdd);
    tri(P[a], P[d], P[c], sa, sdd, sc);
  }
  og.putImageData(out, 0, 0);
  return O;
}

// .cube -> forma compatta (griglia 17x17x17, ~20 KB) da salvare nella grafica
export function compactLut(txt, N = 17) {
  const L = parseCube(txt); if (!L || L.size < 2) return null;
  const M = L.size, T = L.data, M2 = M * M, k = (M - 1) / (N - 1), bytes = new Uint8Array(N * N * N * 3);
  const at = (r, g, b, c) => T[(b * M2 + g * M + r) * 3 + c];
  for (let b = 0; b < N; b++) for (let g = 0; g < N; g++) for (let r = 0; r < N; r++) {
    const R = r * k, G = g * k, B = b * k, r0 = Math.min(M - 2, R | 0), g0 = Math.min(M - 2, G | 0), b0 = Math.min(M - 2, B | 0), fr = R - r0, fg = G - g0, fb = B - b0;
    for (let c = 0; c < 3; c++) {
      const v = ((at(r0, g0, b0, c) * (1 - fr) + at(r0 + 1, g0, b0, c) * fr) * (1 - fg) + (at(r0, g0 + 1, b0, c) * (1 - fr) + at(r0 + 1, g0 + 1, b0, c) * fr) * fg) * (1 - fb)
        + ((at(r0, g0, b0 + 1, c) * (1 - fr) + at(r0 + 1, g0, b0 + 1, c) * fr) * (1 - fg) + (at(r0, g0 + 1, b0 + 1, c) * (1 - fr) + at(r0 + 1, g0 + 1, b0 + 1, c) * fr) * fg) * fb;
      bytes[((b * N + g) * N + r) * 3 + c] = Math.max(0, Math.min(255, Math.round(v * 255)));
    }
  }
  let bin = ''; for (let i = 0; i < bytes.length; i += 8192) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
  return 'nf:' + N + ':' + btoa(bin);
}

// ---------------------------------------------------------------- un livello: contenuto -> filtri -> maschera -> effetti
const cache = new Map();   // id -> { key, out }
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(h)); return c; };
const MAX_PX = 4096;
export function dropCache(id) { if (id) cache.delete(id); else cache.clear(); }

function contentKey(l, rs, assets) {
  const { x, y, rot, opacity, blend, visible, locked, name, flipX, flipY, ...rest } = l;
  return JSON.stringify(rest) + '|' + rs.toFixed(4) + '|' + (l.src ? assets.ver(l.src) : 0) + '|' + (l.mask && l.mask.src ? assets.ver(l.mask.src) : 0) + '|' + (l.font ? fontReady(l.font) : 1);
}

// scala del riquadro: quella della vista, ma mai oltre MAX_PX per lato (e mai oltre la risoluzione dell'immagine x2)
export function layerScale(l, k) {
  let rs = k;
  const big = Math.max(l.w, l.h) * rs;
  if (big > MAX_PX) rs *= MAX_PX / big;
  if ((l.type === 'image' || l.type === 'paint') && l.iw) rs = Math.min(rs, Math.max(1, 2 * l.iw / Math.max(1, l.w)));
  return Math.max(0.02, rs);
}

export function layerBitmap(l, k, assets, store = cache) {
  const rs = layerScale(l, k);
  const key = contentKey(l, rs, assets);
  const c0 = store.get(l.id);
  if (c0 && c0.key === key) return c0.out;
  // deformazione (prospettiva, distorsione, altera): il contenuto si disegna alla misura di prima e poi si deforma
  const wp = l.warp && l.warp.pts && l.warp.sw > 0 && l.warp.sh > 0 && l.type !== 'group' && l.type !== 'adjust' ? l.warp : null;
  let cw = Math.max(1, Math.round((wp ? wp.sw : l.w) * rs)), ch = Math.max(1, Math.round((wp ? wp.sh : l.h) * rs));
  if (wp && Math.max(cw, ch) > MAX_PX) { const kk = MAX_PX / Math.max(cw, ch); cw = Math.max(1, Math.round(cw * kk)); ch = Math.max(1, Math.round(ch * kk)); }
  let C = mk(cw, ch), g = C.getContext('2d');
  let ok = true;
  if (l.type === 'image' || l.type === 'paint') {
    const a = assets.get(l.src);
    if (a) g.drawImage(a.el, 0, 0, cw, ch); else if (l.src) ok = false;
  } else if (l.type === 'text') {
    drawText(g, l, rs, cw);
    if (l.font && !fontReady(l.font)) ok = false;
  } else if (l.type === 'path') {
    const m = ((l.stroke && l.strokeW) || 0) * rs / 2;
    pathTrace(g, l, m, m, cw - 2 * m, ch - 2 * m);
    if (l.fill && l.closed) { g.fillStyle = fillStyle(g, l.fill, cw, ch); g.fill(); }
    if (l.stroke && l.strokeW > 0) { g.strokeStyle = fillStyle(g, l.stroke, cw, ch); g.lineWidth = l.strokeW * rs; g.lineCap = 'round'; g.lineJoin = 'round'; g.stroke(); }
  } else if (l.type === 'shape') {
    shapePath(g, l, cw, ch);
    const lw = (l.strokeW || 0) * rs;
    if (l.kind !== 'line' && l.fill) { g.fillStyle = fillStyle(g, l.fill, cw, ch); g.fill(); }
    if (l.kind === 'line') {
      g.strokeStyle = fillStyle(g, l.fill || l.stroke || '#000', cw, ch); g.lineWidth = Math.max(1, ch * 0.9); g.lineCap = 'round'; g.stroke();
    } else if (lw > 0 && l.stroke) {
      g.save(); g.clip(); g.strokeStyle = fillStyle(g, l.stroke, cw, ch); g.lineWidth = lw * 2; shapePath(g, l, cw, ch); g.stroke(); g.restore();
    }
  }
  // filtri del livello
  const fc = filterCss(l.filters, rs);
  if (fc !== 'none') {
    const F = mk(cw, ch), fg = F.getContext('2d');
    fg.filter = fc; fg.drawImage(C, 0, 0); C = F; g = fg; g.filter = 'none';
  }
  // maschera: dove e' trasparente il livello sparisce (si dipinge con pennello e gomma)
  if (l.mask && l.mask.on !== false && l.mask.src) {
    const m = assets.get(l.mask.src);
    if (m) { g.globalCompositeOperation = 'destination-in'; g.drawImage(m.el, 0, 0, cw, ch); g.globalCompositeOperation = 'source-over'; } else ok = false;
  }
  if (wp) {
    C = warpCanvas(C, wp, Math.max(1, Math.round(l.w * rs)), Math.max(1, Math.round(l.h * rs)));
    g = C.getContext('2d'); cw = C.width; ch = C.height;
  }
  // effetti interni: sovrapposizione colore o sfumatura, ombra interna, smusso (dentro la forma)
  const fx = l.fx || {};
  const ov = fx.colorOverlay && fx.colorOverlay.on ? fx.colorOverlay : null, go = fx.gradOverlay && fx.gradOverlay.on ? fx.gradOverlay : null;
  const ins = fx.innerShadow && fx.innerShadow.on ? fx.innerShadow : null, bev = fx.bevel && fx.bevel.on ? fx.bevel : null;
  if (ov || go || ins || bev) {
    const I = mk(cw, ch), ig = I.getContext('2d');
    ig.drawImage(C, 0, 0);
    ig.globalCompositeOperation = 'source-atop';
    if (ov) { ig.globalAlpha = ov.opacity == null ? 1 : ov.opacity; ig.fillStyle = ov.color || '#000'; ig.fillRect(0, 0, cw, ch); ig.globalAlpha = 1; }
    if (go) { ig.globalAlpha = go.opacity == null ? 1 : go.opacity; ig.fillStyle = fillStyle(ig, go.fill || { type: 'linear', angle: 90, stops: [[0, '#FFFFFF'], [1, '#000000']] }, cw, ch); ig.fillRect(0, 0, cw, ch); ig.globalAlpha = 1; }
    // ombra "dentro": l'esterno della forma fa ombra verso l'interno
    const inner = (color, alpha, blur, dx, dy) => {
      // bordo extra intorno: anche le forme che toccano il bordo hanno l'ombra interna
      const m = Math.ceil(blur * 2 + Math.abs(dx) + Math.abs(dy) + 2), O = mk(cw + m * 2, ch + m * 2), og = O.getContext('2d');
      og.fillStyle = '#000'; og.fillRect(0, 0, cw + m * 2, ch + m * 2); og.globalCompositeOperation = 'destination-out'; og.drawImage(C, m, m);
      const S = mk(cw, ch), sg = S.getContext('2d'), far = 100000;
      sg.shadowColor = hex2rgba(color, alpha); sg.shadowBlur = blur; sg.shadowOffsetX = far + dx; sg.shadowOffsetY = dy;
      sg.drawImage(O, -far - m, -m);
      sg.shadowColor = 'transparent'; sg.shadowOffsetX = 0; sg.shadowOffsetY = 0; sg.shadowBlur = 0;
      sg.globalCompositeOperation = 'destination-in'; sg.drawImage(C, 0, 0);
      ig.drawImage(S, 0, 0);
    };
    if (ins) inner(ins.color || '#000000', ins.opacity == null ? 0.6 : ins.opacity, (ins.blur || 0) * rs, (ins.x || 0) * rs, (ins.y || 0) * rs);
    if (bev) {
      const a = (bev.angle == null ? 120 : bev.angle) * Math.PI / 180, d = (bev.size || 10) * rs, dx = Math.cos(a) * d * 0.5, dy = -Math.sin(a) * d * 0.5;
      inner('#FFFFFF', bev.highlight == null ? 0.75 : bev.highlight, d, -dx, -dy);   // luce sui bordi verso la luce
      inner('#000000', bev.shadow == null ? 0.6 : bev.shadow, d, dx, dy);
    }
    C = I; g = ig; g.globalCompositeOperation = 'source-over';
  }
  // effetti: ombra, bagliore, contorno (sotto il contenuto)
  const sh = fx.shadow && fx.shadow.on ? fx.shadow : null, gl = fx.glow && fx.glow.on ? fx.glow : null, st = fx.stroke && fx.stroke.on && fx.stroke.width > 0 ? fx.stroke : null;
  let pad = 0;
  if (sh) pad = Math.max(pad, (sh.blur * 1.5 + Math.max(Math.abs(sh.x), Math.abs(sh.y))) * rs);
  if (gl) pad = Math.max(pad, gl.blur * 1.5 * rs);
  if (st) pad = Math.max(pad, st.width * rs + 2);
  pad = Math.ceil(pad);
  let out = { cv: C, pad: 0, rs, ok };
  if (pad > 0) {
    const O = mk(cw + pad * 2, ch + pad * 2), og = O.getContext('2d');
    const sil = (color) => { const S = mk(cw, ch), sg = S.getContext('2d'); sg.drawImage(C, 0, 0); sg.globalCompositeOperation = 'source-in'; sg.fillStyle = color; sg.fillRect(0, 0, cw, ch); return S; };
    const far = 100000;
    if (sh) {
      og.save(); og.shadowColor = hex2rgba(sh.color, sh.opacity); og.shadowBlur = sh.blur * rs; og.shadowOffsetX = far + sh.x * rs; og.shadowOffsetY = sh.y * rs;
      og.drawImage(C, pad - far, pad); og.restore();
    }
    if (gl) {
      og.save(); og.shadowColor = hex2rgba(gl.color, gl.opacity); og.shadowBlur = gl.blur * rs; og.shadowOffsetX = far;
      const S = sil(gl.color); og.drawImage(S, pad - far, pad); og.shadowBlur = gl.blur * rs * 0.4; og.drawImage(S, pad - far, pad); og.restore();
    }
    if (st) {
      const S = sil(st.color), r = st.width * rs, n = Math.max(16, Math.min(64, Math.round(r * 2)));
      for (let rr = r; rr > 0; rr -= Math.max(1, r / 3)) for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; og.drawImage(S, pad + Math.cos(a) * rr, pad + Math.sin(a) * rr); }
    }
    og.drawImage(C, pad, pad);
    out = { cv: O, pad, rs, ok };
  }
  if (ok) store.set(l.id, { key, out });
  return out;
}

// ---------------------------------------------------------------- composizione
// view: { k: pixel della tela per pixel del documento, ox, oy: dove sta l'angolo (0,0) del documento }
function drawLayer(g, l, view, assets, store) {
  const bm = layerBitmap(l, view.k, assets, store);
  const s = view.k / bm.rs;
  g.save();
  g.globalAlpha = Math.max(0, Math.min(1, l.opacity == null ? 1 : l.opacity));
  g.globalCompositeOperation = l.blend && l.blend !== 'normal' ? l.blend : 'source-over';
  g.translate(view.ox + (l.x + l.w / 2) * view.k, view.oy + (l.y + l.h / 2) * view.k);
  if (l.rot) g.rotate(l.rot * Math.PI / 180);
  g.scale((l.flipX ? -1 : 1) * s, (l.flipY ? -1 : 1) * s);
  const cw = bm.cv.width - bm.pad * 2, ch = bm.cv.height - bm.pad * 2;
  g.imageSmoothingQuality = 'high';
  g.drawImage(bm.cv, -cw / 2 - bm.pad, -ch / 2 - bm.pad);
  g.restore();
  return bm.ok;
}

// disegna una lista di livelli (dal basso) su g; ritorna false se manca ancora qualcosa (immagini in arrivo)
export function renderLayers(g, layers, view, assets, opt = {}) {
  let ok = true;
  for (let i = 0; i < layers.length; i++) {
    const l = layers[i];
    if (l.clip && i > 0) continue;   // disegnato insieme al suo livello base
    if (!l.visible || (opt.hide && opt.hide.has(l.id))) { while (layers[i + 1] && layers[i + 1].clip) i++; continue; }
    // maschera di ritaglio: i livelli sopra con "clip" si vedono solo dove c'e' questo livello
    if (layers[i + 1] && layers[i + 1].clip && l.type !== 'adjust') {
      const W = g.canvas.width, H = g.canvas.height;
      const T = mk(W, H), tg = T.getContext('2d');
      ok = renderLayers(tg, [{ ...l, opacity: 1, blend: 'normal', clip: false }], view, assets, opt) && ok;
      let j = i + 1;
      for (; layers[j] && layers[j].clip; j++) {
        const c = layers[j];
        if (!c.visible || (opt.hide && opt.hide.has(c.id))) continue;
        const U = mk(W, H), ug = U.getContext('2d');
        if (c.type === 'adjust') { ug.drawImage(T, 0, 0); ok = renderLayers(ug, [{ ...c, clip: false }], view, assets, opt) && ok; tg.save(); tg.globalCompositeOperation = 'source-atop'; tg.drawImage(U, 0, 0); tg.restore(); continue; }
        ok = renderLayers(ug, [{ ...c, opacity: 1, blend: 'normal', clip: false }], view, assets, opt) && ok;
        tg.save(); tg.globalAlpha = c.opacity == null ? 1 : c.opacity;
        // fusione del livello ritagliato: si fonde con la base, poi resta solo dentro la base
        if (c.blend && c.blend !== 'normal') {
          const V = mk(W, H), vg = V.getContext('2d'); vg.drawImage(T, 0, 0); vg.globalCompositeOperation = c.blend; vg.globalAlpha = tg.globalAlpha; vg.drawImage(U, 0, 0);
          tg.globalAlpha = 1; tg.globalCompositeOperation = 'source-atop'; tg.drawImage(V, 0, 0);
        } else { tg.globalCompositeOperation = 'source-atop'; tg.drawImage(U, 0, 0); }
        tg.restore();
      }
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
      g.globalAlpha = l.opacity == null ? 1 : l.opacity;
      g.globalCompositeOperation = l.blend && l.blend !== 'normal' ? l.blend : 'source-over';
      g.drawImage(T, 0, 0); g.restore();
      i = j - 1;
      continue;
    }
    if (l.type === 'adjust') {
      // regolazione: cambia tutto quello che sta sotto (nello stesso gruppo), senza toccare i livelli
      const W = g.canvas.width, H = g.canvas.height;
      const T = mk(W, H), tg = T.getContext('2d');
      if (PIXEL_ADJ.has(l.kind)) { tg.drawImage(g.canvas, 0, 0); pixelAdjust(tg, l, opt.clip); }
      else { tg.filter = adjustCss(l, view.k); tg.drawImage(g.canvas, 0, 0); }
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
      g.globalAlpha = l.opacity == null ? 1 : l.opacity;
      g.globalCompositeOperation = l.blend && l.blend !== 'normal' ? l.blend : 'source-over';
      if (opt.clip) { g.beginPath(); g.rect(opt.clip[0], opt.clip[1], opt.clip[2], opt.clip[3]); g.clip(); }
      g.drawImage(T, 0, 0); g.restore();
      continue;
    }
    if (l.type === 'group') {
      // gruppo "passante" (come in Photoshop): a opacita' piena e fusione normale i livelli dentro si fondono con quelli sotto
      if ((!l.blend || l.blend === 'normal') && (l.opacity == null || l.opacity >= 1)) { ok = renderLayers(g, l.children || [], view, assets, opt) && ok; continue; }
      const W = g.canvas.width, H = g.canvas.height;
      const T = mk(W, H), tg = T.getContext('2d');
      ok = renderLayers(tg, l.children || [], view, assets, opt) && ok;
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
      g.globalAlpha = l.opacity == null ? 1 : l.opacity;
      g.globalCompositeOperation = l.blend && l.blend !== 'normal' ? l.blend : 'source-over';
      g.drawImage(T, 0, 0); g.restore();
      continue;
    }
    ok = drawLayer(g, l, view, assets, opt.store || cache) && ok;
  }
  return ok;
}

// una pagina intera: sfondo + livelli, tagliata ai bordi del documento
export function renderPage(g, doc, page, view, assets, opt = {}) {
  const x = view.ox, y = view.oy, w = doc.w * view.k, hh = doc.h * view.k;
  g.save();
  g.beginPath(); g.rect(x, y, w, hh); g.clip();
  if (page.bg) { g.fillStyle = fillStyle(g, page.bg, w, hh) || '#fff'; g.save(); g.translate(x, y); g.fillRect(0, 0, w, hh); g.restore(); }
  const ok = renderLayers(g, page.layers || [], view, assets, { ...opt, clip: [x, y, w, hh] });
  g.restore();
  return ok;
}

// immagine finale di una pagina (esportazione, anteprime): aspetta immagini e font
export async function pageCanvas(doc, page, scale, assets, opt = {}) {
  const fonts = new Set();
  const srcs = new Set();
  (function scan(list) { for (const l of list || []) { if (l.font) fonts.add(l.font); if (l.src) srcs.add(l.src); if (l.mask && l.mask.src) srcs.add(l.mask.src); if (l.children) scan(l.children); } })(page.layers);
  await Promise.all([...fonts].map((f) => ensureFont(f).catch(() => null)));
  for (let i = 0; i < 100; i++) {
    const miss = [...srcs].filter((s) => !assets.get(s) && !(assets.map.get(s) || {}).failed);
    if (!miss.length) break;
    await new Promise((r) => setTimeout(r, 60));
  }
  const W = Math.max(1, Math.round(doc.w * scale)), H = Math.max(1, Math.round(doc.h * scale));
  const C = mk(W, H), g = C.getContext('2d');
  if (opt.bg) { g.fillStyle = opt.bg; g.fillRect(0, 0, W, H); }
  // l'esportazione non usa i riquadri calcolati per lo schermo: memoria a parte
  renderPage(g, doc, page, { k: scale, ox: 0, oy: 0 }, assets, { store: new Map() });
  return C;
}

// punto sul livello? (per le immagini con trasparenza conta il pixel, non il riquadro)
export function hitLayer(l, px, py, toLocal, assets) {
  const [x, y] = toLocal(l, px, py);
  if (x < 0 || y < 0 || x > l.w || y > l.h) return false;
  if (l.type === 'image' || l.type === 'paint') {
    const c = cache.get(l.id);
    if (!c) return l.type === 'image';
    const bm = c.out, cw = bm.cv.width - bm.pad * 2, ch = bm.cv.height - bm.pad * 2;
    try {
      const d = bm.cv.getContext('2d').getImageData(Math.floor(bm.pad + x / l.w * cw), Math.floor(bm.pad + y / l.h * ch), 1, 1).data;
      return d[3] > 12;
    } catch (e) { return true; }
  }
  return true;
}
