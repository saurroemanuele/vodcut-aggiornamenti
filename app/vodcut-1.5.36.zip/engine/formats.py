"""Formati: si impara da video che funzionano (propri o di altri) per scrivere script dello stesso tipo.

Per ogni video di riferimento l'app, sul computer: trascrive il parlato (Whisper), trova i cambi di inquadratura
(le "visual", con ffmpeg), salva un fotogramma per ogni inquadratura e calcola ritmo e numeri. Poi l'AI (con la
chiave dell'utente) legge tutto e scrive il FORMATO: come aprire, struttura, ritmo, regole, chiusure.

Si impara la struttura, non si copiano le frasi: gli script nuovi sono sempre originali.
Tutto resta in ~/VODcut/formati/<id>: formato.json, LEGGIMI.md (riassunto leggibile) e i fotogrammi.
"""
import json
import os
import re
import secrets
import shutil
import subprocess
import threading
import time

from . import ai
from .util import APP_DIR, NO_WINDOW, ffmpeg_bin, probe

FORMATS_DIR = os.path.join(APP_DIR, "formati")
_LOCKS = {}
_GLOCK = threading.Lock()
KINDS = {"vendita": "Vendita di un'app o prodotto digitale", "ugc": "UGC / recensione", "storia": "Storia / racconto",
         "educativo": "Educativo / consigli", "altro": "Altro"}


def _lock(k):
    with _GLOCK:
        return _LOCKS.setdefault(k, threading.RLock())


def _fid(x):
    x = str(x or "")
    if not re.fullmatch(r"fm[0-9a-f]{8,16}", x):
        raise ValueError("Formato non valido")
    return x


def _dir(fid):
    return os.path.join(FORMATS_DIR, _fid(fid))


def _path(fid):
    return os.path.join(_dir(fid), "formato.json")


def get(fid):
    with open(_path(fid), encoding="utf-8") as f:
        return json.load(f)


def save(fm):
    fm["updated"] = time.time()
    os.makedirs(_dir(fm["id"]), exist_ok=True)
    tmp = _path(fm["id"]) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(fm, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _path(fm["id"]))
    try:
        write_readme(fm)
    except Exception as e:
        print(f"[formati] LEGGIMI non scritto: {e}", flush=True)
    return fm


def _s(v, n):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v or ""))[:n]


def list_all():
    out = []
    try:
        names = os.listdir(FORMATS_DIR)
    except OSError:
        return out
    for n in names:
        try:
            fm = get(n)
        except Exception:
            continue
        vids = fm.get("videos") or []
        out.append({"id": fm["id"], "name": fm.get("name"), "kind": fm.get("kind"), "videos": len(vids),
                    "ready": sum(1 for v in vids if v.get("status") == "pronto"), "hasPrompt": bool(fm.get("prompt")),
                    "thumb": next((v["thumbs"][0] for v in vids if v.get("thumbs")), None), "updated": fm.get("updated")})
    out.sort(key=lambda x: x.get("updated") or 0, reverse=True)
    return out


def create(name, kind):
    fid = "fm" + secrets.token_hex(5)
    fm = {"id": fid, "name": _s(name, 80).strip() or "Nuovo formato", "kind": kind if kind in KINDS else "altro", "goal": "",
          "created": time.time(), "videos": [], "analysis": None, "prompt": ""}
    return save(fm)


def update(fid, data):
    with _lock(fid):
        fm = get(fid)
        for k, n in (("name", 80), ("goal", 1500), ("prompt", 12000)):
            if k in data:
                fm[k] = _s(data[k], n)
        if data.get("kind") in KINDS:
            fm["kind"] = data["kind"]
        for vd in data.get("videos") or []:
            v = next((x for x in fm["videos"] if x["id"] == vd.get("id")), None)
            if not v:
                continue
            if "views" in vd:
                v["views"] = _s(vd["views"], 20)
            if vd.get("rating") in ("top", "ok", "flop", ""):
                v["rating"] = vd["rating"]
            if "note" in vd:
                v["note"] = _s(vd["note"], 500)
            if "shotsManual" in vd:
                try:
                    v["shotsManual"] = max(1, min(400, int(vd["shotsManual"]))) if str(vd["shotsManual"]).strip() else None
                except (TypeError, ValueError):
                    pass
            if "title" in vd:
                v["title"] = _s(vd["title"], 120)
        return save(fm)


def delete(fid):
    d = _dir(fid)
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    return True


def remove_video(fid, vid):
    with _lock(fid):
        fm = get(fid)
        v = next((x for x in fm["videos"] if x["id"] == vid), None)
        if v:
            fm["videos"].remove(v)
            d = os.path.join(_dir(fid), "video", vid)
            shutil.rmtree(d, ignore_errors=True)
        return save(fm)


def add_videos(fid, items):
    """items: [{path} o {url}] -> i video entrano in coda (stato 'in coda')."""
    with _lock(fid):
        fm = get(fid)
        added = []
        for it in items[:100]:
            vid = "v" + secrets.token_hex(4)
            src = str(it.get("path") or it.get("url") or "")
            if not src:
                continue
            v = {"id": vid, "title": _s(it.get("title") or os.path.basename(src) if it.get("path") else src, 120),
                 "path": it.get("path") or "", "url": it.get("url") or "", "status": "in coda", "error": None,
                 "views": "", "rating": "", "note": "", "shotsManual": None, "added": time.time()}
            fm["videos"].append(v)
            added.append(vid)
        save(fm)
    return added


# ------------------------------------------------------------------ analisi di un video (sul computer)
def detect_shots(path, dur, threshold=0.30):
    """Tempi dei cambi di inquadratura (ffmpeg, filtro 'scene')."""
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostats", "-i", path, "-an", "-vf",
           f"scale=320:-2,select='gt(scene,{threshold})',showinfo", "-f", "null", "-"]
    r = subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW, timeout=max(120, dur * 3))
    ts = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", r.stderr.decode(errors="ignore"))]
    out, last = [0.0], 0.0
    for t in sorted(ts):
        if t - last >= 0.25 and t < dur - 0.1:     # tagli troppo vicini: stessa inquadratura
            out.append(round(t, 2))
            last = t
    return out


def keyframes(path, shots, dur, outdir, limit=60):
    os.makedirs(outdir, exist_ok=True)
    files = []
    for k, a in enumerate(shots[:limit]):
        b = shots[k + 1] if k + 1 < len(shots) else dur
        t = min(a + 0.35, a + (b - a) / 2)
        dst = os.path.join(outdir, f"{k + 1:03d}.jpg")
        subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", path, "-frames:v", "1", "-vf", "scale=240:-2",
                        "-q:v", "4", dst], capture_output=True, creationflags=NO_WINDOW, timeout=60)
        if os.path.isfile(dst):
            files.append(dst)
    return files


def contact_sheet(files, shots, dst, cols=8):
    """Tutte le inquadrature in un'immagine sola, con il tempo di ognuna (comoda da leggere a colpo d'occhio)."""
    import cv2
    import numpy as np
    ims = []
    for f, t in zip(files, shots):
        im = cv2.imdecode(np.fromfile(f, dtype=np.uint8), cv2.IMREAD_COLOR)
        if im is None:
            continue
        im = cv2.resize(im, (180, int(180 * im.shape[0] / im.shape[1])))
        cv2.rectangle(im, (0, 0), (62, 20), (0, 0, 0), -1)
        cv2.putText(im, f"{t:.1f}s", (4, 15), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
        ims.append(im)
    if not ims:
        return None
    hmax = max(i.shape[0] for i in ims)
    ims = [cv2.copyMakeBorder(i, 0, hmax - i.shape[0], 0, 0, cv2.BORDER_CONSTANT, value=(20, 20, 20)) for i in ims]
    while len(ims) % cols:
        ims.append(np.full_like(ims[0], 20))
    rows = [np.hstack(ims[r * cols:(r + 1) * cols]) for r in range(len(ims) // cols)]
    ok, buf = cv2.imencode(".jpg", np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 85])
    if ok:
        buf.tofile(dst)
        return dst
    return None


def analyze_video(fid, vid, transcribe, download=None, progress=None, cancel=None):
    """Una sola analisi alla volta per video: trascrizione, inquadrature, fotogrammi, numeri."""
    fm = get(fid)
    v = next(x for x in fm["videos"] if x["id"] == vid)
    vd = os.path.join(_dir(fid), "video", vid)
    os.makedirs(vd, exist_ok=True)

    def st(**kw):
        with _lock(fid):
            cur = get(fid)
            x = next((y for y in cur["videos"] if y["id"] == vid), None)
            if x is not None:
                x.update(kw)
                save(cur)
    path = v.get("path")
    if not path and v.get("url"):
        st(status="scarico")
        path, title = download(v["url"], vd)
        st(path=path, title=_s(title, 120) or v["title"])
    if not path or not os.path.isfile(path):
        raise RuntimeError("File del video non trovato")
    dur = probe(path)["duration"]
    st(status="inquadrature", dur=round(dur, 2))
    if progress:
        progress(0.1, "Trovo i cambi di inquadratura")
    shots = detect_shots(path, dur)
    thumbs = keyframes(path, shots, dur, os.path.join(vd, "fotogrammi"))
    sheet = contact_sheet(thumbs, shots, os.path.join(vd, "inquadrature.jpg"))
    st(status="trascrivo", shots=shots, thumbs=thumbs, sheet=sheet)
    if progress:
        progress(0.35, "Trascrivo il parlato")
    segs, words = [], 0
    try:
        tr = transcribe(path, dur, lambda x: progress and progress(0.35 + 0.6 * x, "Trascrivo il parlato"), cancel)
        for sg in tr.get("segments", []):
            t = " ".join(w.get("w", "") for w in sg.get("words", [])).strip() or sg.get("text", "")
            if t:
                segs.append({"a": round(float(sg.get("a", 0)), 2), "b": round(float(sg.get("b", 0)), 2), "t": t})
                words += len(t.split())
        lang = tr.get("language")
    except Exception as e:
        if "annullato" in str(e).lower():
            raise
        st(status="errore", error="Trascrizione non riuscita: " + str(e)[:200])
        raise
    speech = sum(s["b"] - s["a"] for s in segs) or dur
    st(status="pronto", transcript=segs, lang=lang, words=words, wps=round(words / max(1.0, speech), 2),
       shotLen=round(dur / max(1, len(shots)), 2), hook=" ".join(s["t"] for s in segs if s["a"] < 3.0)[:300], error=None)
    return True


# ------------------------------------------------------------------ riassunto leggibile (anche da Claude)
def _fmt_t(t):
    return f"{int(t // 60)}:{t % 60:04.1f}"


def write_readme(fm):
    L = [f"# Formato: {fm.get('name')}", "", f"Tipo: {KINDS.get(fm.get('kind'), fm.get('kind'))}"]
    if fm.get("goal"):
        L += ["", f"Obiettivo: {fm['goal']}"]
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"]
    if vids:
        avg = lambda k: sum(float(v.get(k) or 0) for v in vids) / len(vids)
        L += ["", f"Video analizzati: {len(vids)} · durata media {avg('dur'):.1f}s · inquadratura media {avg('shotLen'):.2f}s · "
                  f"parole al secondo {avg('wps'):.2f}"]
    for n, v in enumerate(fm.get("videos") or [], 1):
        L += ["", f"## Video {n}: {v.get('title')}", ""]
        meta = [f"stato: {v.get('status')}"]
        if v.get("dur"):
            nsh = v.get("shotsManual") or len(v.get("shots") or [])
            meta += [f"durata {v['dur']}s", f"visual {nsh}" + (" (a mano)" if v.get("shotsManual") else ""), f"inquadratura media {v.get('shotLen')}s",
                     f"parole/s {v.get('wps')}"]
        for k, lbl in (("views", "views"), ("rating", "risultato"), ("url", "link"), ("note", "note")):
            if v.get(k):
                meta.append(f"{lbl}: {v[k]}")
        L.append(" · ".join(meta))
        if v.get("sheet"):
            L.append(f"Inquadrature (immagine): {os.path.relpath(v['sheet'], _dir(fm['id']))}")
        if v.get("transcript"):
            L += ["", "Trascrizione (con i cambi di inquadratura ▌):"]
            shots = v.get("shots") or []
            for sg in v["transcript"]:
                cuts = sum(1 for t in shots if sg["a"] <= t < sg["b"])
                L.append(f"- [{_fmt_t(sg['a'])}] {'▌' * cuts} {sg['t']}")
    if fm.get("prompt"):
        L += ["", "## Formato generato", "", fm["prompt"]]
    with open(os.path.join(_dir(fm["id"]), "LEGGIMI.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


# ------------------------------------------------------------------ l'AI scrive il formato
def dataset_text(fm, max_chars=60000):
    parts = []
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"]
    order = {"top": 0, "ok": 1, "": 2, "flop": 3}
    vids.sort(key=lambda v: order.get(v.get("rating") or "", 2))
    for n, v in enumerate(vids, 1):
        nsh = v.get("shotsManual") or len(v.get("shots") or [])
        head = (f"VIDEO {n} · risultato: {v.get('rating') or 'non indicato'} · views: {v.get('views') or '?'} · durata {v.get('dur')}s · "
                f"{nsh} visual (una ogni {round(float(v.get('dur') or 0) / max(1, nsh), 2)}s) · {v.get('wps')} parole/s" +
                (f" · note: {v['note']}" if v.get("note") else ""))
        tx = "\n".join(f"[{sg['a']:.1f}s] {sg['t']}" for sg in v.get("transcript") or [])
        parts.append(head + "\n" + tx)
    txt = "\n\n".join(parts)
    return txt[:max_chars]


def build_prompt(fm, cfg, cancel=None):
    data = dataset_text(fm)
    if not data.strip():
        raise ai.AIError("Nessun video pronto: aggiungi e analizza almeno 3 video")
    system = ("Sei un analista di contenuti short-form (TikTok, Reels, Shorts). Ricevi trascrizioni con tempi di video di riferimento, "
              "con numero di inquadrature e risultati. Estrai la STRUTTURA che li fa funzionare, senza copiare frasi: dai più peso ai "
              "video con risultato 'top' e views alte, e segnala cosa hanno di diverso i 'flop'. Scrivi in italiano. "
              "Rispondi SOLO con JSON:\n"
              '{"summary": "2-3 frasi: che tipo di video sono e perché funzionano",'
              ' "hooks": ["5-8 tipi di apertura dei primi 2 secondi, descritti come schema (es. \\"Problema diretto: ...\\")"],'
              ' "structure": [{"beat": "nome del passaggio", "share": 0.15, "what": "cosa succede e cosa si dice"}],'
              ' "pacing": {"length_sec": 30, "scene_sec": 2.0, "words_per_sec": 2.6, "notes": "ritmo, pause, cambi"},'
              ' "visuals": ["che tipo di immagini/inquadrature usano e quando cambiano"],'
              ' "cta": ["tipi di chiusura e invito all\'azione"],'
              ' "rules": ["regole di scrittura concrete: lunghezza frasi, tono, persona, parole"],'
              ' "avoid": ["cosa evitare (anche dai flop)"],'
              ' "examples": ["2 script ORIGINALI di esempio (argomento inventato), 60-120 parole, stessa struttura"]}')
    raw = ai.text(cfg, system, f"Tipo di video: {KINDS.get(fm.get('kind'))}. Obiettivo: {fm.get('goal') or '-'}\n\n{data}", max_tokens=8000, cancel=cancel)
    an = ai.parse_json(raw)
    return an, render_prompt(fm, an)


def render_prompt(fm, an):
    """Il formato in testo, pronto da mettere nelle istruzioni di chi scrive gli script (modificabile a mano)."""
    L = [f"FORMATO \"{fm.get('name')}\" — {KINDS.get(fm.get('kind'))}", an.get("summary") or ""]
    if an.get("hooks"):
        L += ["", "APERTURA (scegline una, varia sempre):"] + [f"- {x}" for x in an["hooks"]]
    if an.get("structure"):
        L += ["", "STRUTTURA:"] + [f"- {b.get('beat')} (~{round(float(b.get('share') or 0) * 100)}%): {b.get('what')}" for b in an["structure"] if isinstance(b, dict)]
    p = an.get("pacing") or {}
    if p:
        L += ["", f"RITMO: circa {p.get('length_sec')} secondi, una scena/visual ogni {p.get('scene_sec')} secondi, "
                  f"{p.get('words_per_sec')} parole al secondo. {p.get('notes') or ''}"]
    for key, lbl in (("visuals", "IMMAGINI"), ("cta", "CHIUSURA"), ("rules", "REGOLE"), ("avoid", "DA EVITARE")):
        if an.get(key):
            L += ["", lbl + ":"] + [f"- {x}" for x in an[key]]
    if an.get("examples"):
        L += ["", "ESEMPI DI STRUTTURA (non copiarli, sono solo modelli):"] + [f"---\n{x}" for x in an["examples"]]
    L += ["", "Scrivi sempre testi originali: prendi la struttura, mai le frasi. Non inventare risultati, numeri, recensioni o prezzi."]
    return "\n".join(L)


def scene_sec(fm):
    try:
        v = float(((fm.get("analysis") or {}).get("pacing") or {}).get("scene_sec") or 0)
    except (TypeError, ValueError):
        return None
    return max(1.0, min(6.0, v)) if v else None
