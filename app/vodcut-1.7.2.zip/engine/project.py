"""Progetto: tutto quello che l'utente decide, in un JSON.

Tutti i tempi sono nel tempo del VOD originale (secondi). I tagli vengono tolti solo
all'esportazione, cosi' l'editor puo' sempre rimettere tutto.
"""
import json
import re
import math
import os
import time
import uuid

from .util import PROJECTS_DIR, probe

DEFAULT_SETTINGS = {
    "norm": True,        # volume uguale su tutto il video (-14 LUFS)
    "duck": True,        # musica che si abbassa quando parli
    "denoise": False,    # riduzione rumore (per ora non mostrata)
    "bleep": False,      # bip sulle parolacce (per ora non mostrato)
    "burnSubs": False,   # sottotitoli impressi nel video
    "srt": False,        # file .srt accanto al video (per ora non mostrato)
    "chapters": False,   # capitoli per la descrizione (per ora non mostrati)
    "quality": "1080p",  # 1080p | 1440p | 4K
    "showSubs": True,    # traccia sottotitoli visibile = sottotitoli nel video
}


def new_id(prefix=""):
    return prefix + uuid.uuid4().hex[:8]


def path_for(pid):
    return os.path.join(PROJECTS_DIR, pid + ".json")


def create(source, name=None):
    info = probe(source)
    if not info["has_video"]:
        raise ValueError("Il file non contiene video.")
    pid = new_id("p")
    dur = info["duration"]
    proj = {
        "id": pid,
        "name": name or os.path.splitext(os.path.basename(source))[0],
        "source": os.path.abspath(source),
        "created": time.time(),
        "updated": time.time(),
        "duration": dur,
        "width": info["width"], "height": info["height"], "fps": info["fps"],
        "vcodec": info.get("vcodec"),
        "hasAudio": info["has_audio"],
        "stage": "webcam",          # webcam -> style -> editor
        "webcam": None,              # {"box":[x,y,w,h], "confidence":..}
        "style": {"cuts": 1, "zooms": 1},
        "analysis": None,
        "zooms": [], "cuts": [], "segs": [],
        "transcript": {"status": "none", "segments": []},
        "tracks": [{
            "id": "live", "name": "Audio live", "type": "live", "vol": 100, "mute": False,
            "clips": [{"id": new_id("a"), "a": 0.0, "b": dur, "vol": 100, "mute": False, "fin": False, "fout": False}],
        }],
        "settings": dict(DEFAULT_SETTINGS),
        "lastExport": None,
    }
    save(proj)
    return proj


def reset_edits(proj):
    """Lo stesso VOD come appena importato: via tagli, zoom, testi, effetti, video inseriti e montaggio AI.
    Restano il file, la webcam, la trascrizione (senza tagli, non si rifa': risparmi tempo) e le clip gia' create."""
    dur = float(proj.get("liveDuration") or proj["duration"])
    keep = {k: proj[k] for k in ("id", "name", "source", "created", "width", "height", "fps", "vcodec", "hasAudio", "webcam",
                                  "verticals", "timelines", "clipsRun", "subLang", "script") if k in proj}
    tr = proj.get("transcript") or {"status": "none", "segments": []}
    if proj.get("inserts"):   # con i video inseriti i tempi della trascrizione erano spostati: si rifa'
        tr = {"status": "none", "segments": []}
    if tr.get("status") == "done":
        for sg in tr.get("segments") or []:
            for w in sg.get("words") or []:
                w.pop("del", None)
                w.pop("nosub", None)
    out = {
        **keep,
        "duration": dur,
        "stage": "style" if (proj.get("webcam") is not None) else "webcam",
        "style": {"cuts": 1, "zooms": 1},
        "analysis": None,
        "zooms": [], "cuts": [], "segs": [],
        "transcript": tr if tr.get("status") == "done" else {"status": "none", "segments": []},
        "tracks": [{
            "id": "live", "name": "Audio live", "type": "live", "vol": 100, "mute": False,
            "clips": [{"id": new_id("a"), "a": 0.0, "b": dur, "vol": 100, "mute": False, "fin": False, "fout": False}],
        }],
        "settings": dict(DEFAULT_SETTINGS),
        "lastExport": None,
    }
    return out


def load(pid):
    for i in range(40):
        try:
            with open(path_for(pid), encoding="utf-8") as f:
                p = json.load(f)
            break
        except PermissionError:
            if i == 39:
                raise
            time.sleep(0.05)
    s = dict(DEFAULT_SETTINGS)
    s.update(p.get("settings") or {})
    p["settings"] = s
    return ensure_segs(p)


def save(proj):
    proj["updated"] = time.time()
    tmp = path_for(proj["id"]) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(proj, f, ensure_ascii=False)
    for i in range(60):  # su Windows il file puo' essere aperto da un'altra lettura: riprova
        try:
            os.replace(tmp, path_for(proj["id"]))
            break
        except PermissionError:
            if i == 59:
                raise
            time.sleep(0.05)


def delete(pid):
    try:
        os.remove(path_for(pid))
    except OSError:
        pass


# ------------------------------------------------------------------ cestino: i progetti eliminati restano 30 giorni
TRASH_DIR = os.path.join(PROJECTS_DIR, "cestino")
TRASH_DAYS = 30


def _trash_path(pid):
    return os.path.join(TRASH_DIR, pid + ".json")


def _valid_id(pid):
    return bool(re.fullmatch(r"p[A-Za-z0-9_]{1,60}", pid or ""))


def _kids(p):
    """Clip verticali e timeline del progetto (e quelle dentro le timeline)."""
    ids = [v.get("id", "") for v in p.get("verticals") or []] + list(p.get("timelines") or [])
    return [i for i in ids if _valid_id(i)]


def _kid_tree(pid, where):
    """Tutti i figli (a qualsiasi livello) di un progetto che sta in where(pid)."""
    out, todo = [], [pid]
    while todo:
        cur = todo.pop()
        try:
            with open(where(cur), encoding="utf-8") as f:
                p = json.load(f)
        except (OSError, ValueError):
            continue
        for k in _kids(p):
            if k not in out:
                out.append(k)
                todo.append(k)
    return out


def trash_child(pid):
    """Una timeline tolta dal progetto: nel cestino insieme alle sue clip, ma non compare da sola nell'elenco."""
    if not _valid_id(pid) or not os.path.exists(path_for(pid)):
        return False
    os.makedirs(TRASH_DIR, exist_ok=True)
    for k in _kid_tree(pid, path_for):
        if os.path.exists(path_for(k)):
            os.replace(path_for(k), _trash_path(k))
    p = load(pid)
    p["trashedAt"] = time.time()
    with open(_trash_path(pid), "w", encoding="utf-8") as f:
        json.dump(p, f, ensure_ascii=False)
    os.remove(path_for(pid))
    return True


def trash(pid):
    """Sposta il progetto (e le sue clip verticali) nel cestino. Si recupera per 30 giorni."""
    if not _valid_id(pid) or not os.path.exists(path_for(pid)):
        return False
    os.makedirs(TRASH_DIR, exist_ok=True)
    p = load(pid)
    now = time.time()
    for vid in _kid_tree(pid, path_for):
        if os.path.exists(path_for(vid)):
            os.replace(path_for(vid), _trash_path(vid))
    p["trashedAt"] = now
    tmp = _trash_path(pid) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(p, f, ensure_ascii=False)
    os.replace(tmp, _trash_path(pid))
    os.remove(path_for(pid))
    return True


def _swap_ids(v, ids):
    """Dentro un progetto copiato: ogni id del vecchio albero (progetto, clip verticali, timeline) diventa il suo nuovo."""
    if isinstance(v, str):
        return ids.get(v, v)
    if isinstance(v, list):
        return [_swap_ids(x, ids) for x in v]
    if isinstance(v, dict):
        return {k: _swap_ids(x, ids) for k, x in v.items()}
    return v


def duplicate(pid):
    """Copia del progetto con le sue clip verticali e le timeline, con id nuovi: la copia si modifica senza toccare
    l'originale. I video sul PC non si copiano. Restituisce {vecchio id: nuovo id} (il primo e' il progetto)."""
    if not _valid_id(pid) or not os.path.exists(path_for(pid)):
        return None
    new = new_id("p")
    ids = {pid: new}
    for k in _kid_tree(pid, path_for):
        ids[k] = new + k[len(pid):] if k.startswith(pid + "_") else new_id("p")
    now = time.time()
    name = None
    for old, nid in ids.items():
        try:
            with open(path_for(old), encoding="utf-8") as f:
                p = json.load(f)
        except (OSError, ValueError):
            continue
        p = _swap_ids(p, ids)
        p["id"] = nid
        p.pop("trashedAt", None)
        p["created"] = now
        if old == pid:
            p["name"] = ((p.get("name") or "Progetto")[:110] + " (copia)")
            p["lastExport"] = None
            name = p["name"]
        elif p.get("parent") == new and name:
            p["parentName"] = name
        save(p)
    return ids


def load_any(pid):
    """Un progetto, anche se sta nel cestino (per la copertina)."""
    if os.path.exists(path_for(pid)) or not _valid_id(pid) or not os.path.exists(_trash_path(pid)):
        return load(pid)
    with open(_trash_path(pid), encoding="utf-8") as f:
        return json.load(f)


def list_trash():
    purge_old()
    out = []
    try:
        names = os.listdir(TRASH_DIR)
    except OSError:
        return out
    for fn in names:
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(TRASH_DIR, fn), encoding="utf-8") as f:
                p = json.load(f)
        except (OSError, ValueError):
            continue
        if p.get("parent") or not p.get("trashedAt"):
            continue
        fmts = {"16:9": (16, 9), "9:16": (9, 16), "1:1": (1, 1), "4:5": (4, 5)}
        fw, fh = fmts.get(p.get("format") or "", (p.get("width") or 16, p.get("height") or 9))
        left = TRASH_DAYS - (time.time() - p["trashedAt"]) / 86400
        try:
            dur = sum(b - a for a, b in keep_segments(p))
        except Exception:
            dur = p.get("duration") or 0
        out.append({"id": p["id"], "name": p.get("name") or "Progetto", "kind": p.get("kind") or "vod", "aw": fw, "ah": fh,
                    "trashedAt": p["trashedAt"], "daysLeft": max(0, int(math.ceil(left))), "updated": p.get("updated", 0),
                    "duration": round(dur, 2), "folder": p.get("folder") or ""})
    out.sort(key=lambda x: -x["trashedAt"])
    return out


def restore(pid):
    if not _valid_id(pid) or not os.path.exists(_trash_path(pid)):
        return False
    with open(_trash_path(pid), encoding="utf-8") as f:
        p = json.load(f)
    p.pop("trashedAt", None)
    for vid in _kid_tree(pid, _trash_path):
        if os.path.exists(_trash_path(vid)):
            os.replace(_trash_path(vid), path_for(vid))
    save(p)
    os.remove(_trash_path(pid))
    return True


def purge(pid):
    """Elimina per sempre (solo il progetto: i video sul PC restano)."""
    if not _valid_id(pid):
        return False
    try:
        with open(_trash_path(pid), encoding="utf-8") as f:
            p = json.load(f)
    except (OSError, ValueError):
        return False
    for vid in _kid_tree(pid, _trash_path):
        try:
            os.remove(_trash_path(vid))
        except OSError:
            pass
    os.remove(_trash_path(pid))
    return True


def purge_old():
    try:
        names = os.listdir(TRASH_DIR)
    except OSError:
        return
    for fn in names:
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(TRASH_DIR, fn), encoding="utf-8") as f:
                p = json.load(f)
            if p.get("trashedAt") and time.time() - p["trashedAt"] > TRASH_DAYS * 86400:
                purge(p["id"])
        except Exception:
            continue


# elenco dei progetti: ogni file si legge una volta e poi solo quando cambia (data e dimensione). Prima ogni richiesta
# rileggeva tutti i file, anche le clip (con le trascrizioni intere): con 15 progetti e 100 clip ci voleva piu' di 1,5 s
_LIST_CACHE = {}   # nome del file -> (mtime_ns, dimensione, riassunto o None per le clip, video sorgente)


def list_projects():
    out, seen = [], set()
    for fn in os.listdir(PROJECTS_DIR):
        if not fn.endswith(".json"):
            continue
        path = os.path.join(PROJECTS_DIR, fn)
        try:
            st = os.stat(path)
        except OSError:
            continue
        seen.add(fn)
        c = _LIST_CACHE.get(fn)
        if not c or c[0] != st.st_mtime_ns or c[1] != st.st_size:
            try:
                with open(path, encoding="utf-8") as f:
                    p = json.load(f)
                # le clip verticali stanno dentro il loro VOD: nell'elenco non ci vanno
                c = (st.st_mtime_ns, st.st_size, None if p.get("parent") else _list_entry(p), p.get("source") or "")
            except Exception:
                continue
            _LIST_CACHE[fn] = c
        if c[2] is not None:
            out.append(dict(c[2], exists=bool(c[3]) and os.path.exists(c[3])))
    for fn in [k for k in _LIST_CACHE if k not in seen]:
        _LIST_CACHE.pop(fn, None)
    out.sort(key=lambda x: -x["updated"])
    return out


def _list_entry(p):
    """La riga di un progetto nell'elenco: tutto quello che dipende solo dal suo file ("exists" si guarda ogni volta)."""
    fmts = {"16:9": (16, 9), "9:16": (9, 16), "1:1": (1, 1), "4:5": (4, 5)}
    fw, fh = fmts.get(p.get("format") or "", (p.get("width") or 16, p.get("height") or 9))
    # durata vera: quello che esce (progetto vuoto: fin dove c'e' qualcosa)
    try:
        dur = sum(b - a for a, b in keep_segments(p))
    except Exception:
        dur = p["duration"]
    # progetto vuoto o storia: la copertina c'e' solo con un video o un'immagine dentro; senza niente, durata zero
    # (se un progetto vecchio ha una forma diversa, resta in elenco con la copertina normale: non deve sparire)
    cover, empty = True, False
    if (p.get("kind") or "vod") in ("blank", "story"):
        try:
            ins = any(not i.get("gap") and not i.get("live") for i in p.get("inserts") or [])
            clips = [c for t in p.get("tracks") or [] if t.get("type") != "live" for c in t.get("clips") or []]
            cover = ins or any(c.get("file") and not c.get("isText") for c in clips)
            empty = not ins and not clips
        except Exception:
            cover, empty = True, False
    return {"id": p["id"], "name": p["name"], "duration": 0 if empty else round(dur, 2), "updated": p.get("updated", 0),
            "stage": p.get("stage"), "exported": bool(p.get("lastExport")), "kind": p.get("kind") or "vod",
            "aw": fw, "ah": fh, "verticals": len(p.get("verticals") or []), "aiClips": sum(1 for v in p.get("verticals") or [] if v.get("clip")), "folder": p.get("folder") or "",
            "cover": cover}


# ---------------------------------------------------------------- tagli effettivi
def new_seg(a, b, **kw):
    s = {"id": new_id("s"), "a": round(a, 3), "b": round(b, 3), "removed": False, "auto": False,
         "vol": 100, "mute": False, "fin": False, "fout": False}
    s.update(kw)
    return s


def build_segs(proj):
    """Pezzi del video (video + audio insieme), dal vecchio formato tagli + clip audio."""
    dur = proj["duration"]
    cuts = [c for c in proj.get("cuts", []) if c["b"] > c["a"]]
    live = next((t for t in proj.get("tracks", []) if t.get("type") == "live"), None)
    lclips = live["clips"] if live else []
    pts = {0.0, dur}
    for c in cuts:
        pts.update([max(0.0, min(dur, c["a"])), max(0.0, min(dur, c["b"]))])
    for c in lclips:
        pts.update([max(0.0, min(dur, c["a"])), max(0.0, min(dur, c["b"]))])
    pts = sorted(pts)
    segs = []
    for a, b in zip(pts, pts[1:]):
        if b - a < 0.01:
            continue
        mid = (a + b) / 2
        cut = next((c for c in cuts if c["a"] <= mid <= c["b"]), None)
        lc = next((c for c in lclips if c["a"] <= mid <= c["b"]), None) or {}
        segs.append(new_seg(a, b, removed=bool(cut and cut.get("on", True)), auto=bool(cut and cut.get("kind") == "auto"),
                            vol=lc.get("vol", 100), mute=bool(lc.get("mute")), fin=bool(lc.get("fin")), fout=bool(lc.get("fout"))))
    return segs


def ensure_segs(proj):
    if not proj.get("segs"):
        proj["segs"] = build_segs(proj)
    proj.setdefault("assets", [])
    proj["layers"] = norm_layers(proj)
    return proj


def norm_layers(proj):
    """Ordine dei livelli video, dall'alto verso il basso. Il video e' sempre la base."""
    ov = ["ov:" + t["id"] for t in proj.get("tracks", []) if t.get("type") == "overlay"]
    fxk = [("fx" if t["id"] == "fx" else "fx:" + t["id"]) for t in (proj.get("fxTracks") or [{"id": "fx"}])]
    cur = [x for x in (proj.get("layers") or ["subs", "zoom", "fx"]) if x in ("subs", "zoom", "fx") or x in ov or x in fxk]
    for k in ("subs", "zoom", "fx"):
        if k not in cur:
            cur.append(k)
    for k in fxk:
        if k not in cur:
            cur.insert(max(0, cur.index("fx")), k)
    for k in ov:
        if k not in cur:
            cur.insert(0, k)
    return cur + ["video"]


def segs_from_auto_cuts(dur, cuts):
    segs, t = [], 0.0
    for a, b in sorted(cuts):
        if a > t + 0.01:
            segs.append(new_seg(t, a))
        segs.append(new_seg(a, b, removed=True, auto=True))
        t = b
    if dur > t + 0.01:
        segs.append(new_seg(t, dur))
    return segs


def removed_ranges(proj):
    """Intervalli tolti dal video: pezzi tolti + parole cancellate nel testo."""
    ensure_segs(proj)
    r = [(s["a"], s["b"]) for s in proj["segs"] if s.get("removed") and s["b"] > s["a"]]
    for seg in proj.get("transcript", {}).get("segments", []):
        for w in seg.get("words", []):
            if w.get("del"):
                r.append((w["a"], w["b"]))
    r.sort()
    merged = []
    for a, b in r:
        if merged and a <= merged[-1][1] + 0.05:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def content_end(proj):
    """Progetto vuoto: fin dove c'e' qualcosa (clip nella traccia principale, immagini, video, testi, suoni)."""
    e = 0.0
    for c in proj.get("segs") or []:
        if c.get("ins") and not c.get("gone") and not c.get("removed"):
            e = max(e, c["b"])
    for t in proj.get("tracks") or []:
        if t.get("hidden") or t.get("type") == "live":
            continue
        for c in t.get("clips") or []:
            e = max(e, c["a"] + (c["dur"] if c.get("dur") is not None else c.get("b", c["a"]) - c["a"]))
    return e


def keep_segments(proj):
    dur = proj["duration"]
    if proj.get("kind") == "blank":
        # il nero dopo l'ultima cosa messa non va nel video
        dur = min(dur, content_end(proj) or dur)
    keep, t = [], 0.0
    for a, b in removed_ranges(proj):
        a, b = max(0.0, min(dur, a)), min(dur, b)
        if a > t + 0.02:
            keep.append((t, a))
        t = max(t, b)
    if dur - t > 0.02:
        keep.append((t, dur))
    return keep


FX_ADJ = ("bri", "con", "sat", "temp", "tint", "shad", "high")


def _kf_lerp(ks, tr, get):
    xs = [k for k in ks if get(k) is not None]
    if not xs:
        return None
    if tr <= xs[0]["t"]:
        return get(xs[0])
    if tr >= xs[-1]["t"]:
        return get(xs[-1])
    i = 0
    while i < len(xs) - 2 and tr >= xs[i + 1]["t"]:
        i += 1
    k0, k1 = xs[i], xs[i + 1]
    u0 = (tr - k0["t"]) / max(1e-6, k1["t"] - k0["t"])
    from .easing import ease
    u = ease(u0, k0.get("ease", "smooth"))
    return get(k0) + (get(k1) - get(k0)) * u


def fx_at(f, t):
    """Filtro con intensita' e colori dell'istante t se ha i keyframe. Come fxAt in web/lib.js."""
    kf = f.get("kf") or []
    if not kf:
        return f
    ks = sorted(kf, key=lambda k: k.get("t", 0))
    tr = t - f["a"]
    k = _kf_lerp(ks, tr, lambda x: None if x.get("k") is None else float(x["k"]))
    adj = dict(f.get("adj") or {})
    for key in FX_ADJ:
        v = _kf_lerp(ks, tr, lambda x, key=key: float(x["adj"].get(key) or 0) if isinstance(x.get("adj"), dict) else None)
        if v is not None:
            adj[key] = v
    return dict(f, k=f.get("k", 100) if k is None else k, adj=adj)


def expand_kf(f):
    """Filtro con keyframe -> tanti pezzi corti con valori fissi (l'esportazione lavora a pezzi con filtri fissi)."""
    if not f.get("kf"):
        return [f]
    a, b = float(f["a"]), float(f["b"])
    L = max(0.0, b - a)
    step = max(0.2, L / 200.0)
    out, i, x = [], 0, a
    while x < b - 1e-4:
        y = min(b, x + step)
        g = fx_at(f, (x + y) / 2)
        g = {k: v for k, v in g.items() if k != "kf"}
        g.update(id=f"{f.get('id', 'f')}_k{i}", a=round(x, 4), b=round(y, 4))
        g["k"] = round(float(g.get("k", 100)), 1)
        g["adj"] = {k: round(float(v), 1) for k, v in (g.get("adj") or {}).items()}
        out.append(g)
        x, i = y, i + 1
    return out


def all_filters(proj):
    """Filtri delle tracce + quelli messi direttamente sulle clip video (filtro e colori della clip).
    Quelli delle clip vanno per primi: stanno subito sopra il video."""
    out = []
    for c in proj.get("segs") or []:
        if c.get("gone") or c.get("removed"):
            continue
        fx = c.get("fx")
        if fx and fx.get("type"):
            out += expand_kf({"id": "sf_" + c["id"], "type": fx["type"], "k": fx.get("k", 100), "a": c["a"], "b": c["b"],
                              "track": "fx", "mask": {"type": "all"}, "kf": c.get("fxKf")})
        adj = c.get("adj") or {}
        if any(adj.get(k) for k in FX_ADJ) or c.get("adjKf"):
            out += expand_kf({"id": "sa_" + c["id"], "type": "adjust", "adj": adj, "k": 100, "a": c["a"], "b": c["b"],
                              "track": "fx", "mask": {"type": "all"}, "kf": c.get("adjKf")})
    return out + [g for f in (proj.get("filters") or []) for g in expand_kf(f)]


SPEED_CHUNK = 0.25


def speed_parts(c):
    """Pezzettini a velocita' fissa di una clip: [(a, b, velocita')]. Con i keyframe della velocita'
    (c["pk"]["speed"], t dall'inizio della clip) la clip si divide in pezzettini lunghi circa SPEED_CHUNK,
    ognuno alla velocita' che c'e' a meta'. Uguale a web/lib.js speedParts."""
    from .easing import pk_list, pk_at
    try:
        base = max(0.25, min(4.0, float(c.get("speed") or 1)))
    except (TypeError, ValueError):
        base = 1.0
    if not pk_list(c, "speed") or c.get("gone"):
        return [(c["a"], c["b"], base)]
    L = c["b"] - c["a"]
    n = max(1, min(60, int(math.ceil(L / SPEED_CHUNK - 1e-9))))
    out = []
    for i in range(n):
        a = c["a"] + L * i / n
        b = c["b"] if i == n - 1 else c["a"] + L * (i + 1) / n
        out.append((a, b, max(0.25, min(4.0, pk_at(c, "speed", (a + b) / 2 - c["a"], base)))))
    return out


def has_ramp(c):
    from .easing import pk_list
    return bool(pk_list(c, "speed"))


def seg_speed(proj, t):
    """Velocita' della clip al tempo t (1 = normale)."""
    for c in proj.get("segs") or []:
        if c["a"] <= t < c["b"]:
            for a, b, sp in speed_parts(c):
                if a <= t < b:
                    return sp
            return speed_parts(c)[-1][2]
    return 1.0


def split_by_speed(proj, keep):
    """Divide i pezzi da tenere dove cambia la velocita': [(a, b, velocita')]."""
    bounds = sorted({x for c in proj.get("segs") or [] for p_ in speed_parts(c) for x in (p_[0], p_[1])})
    out = []
    for a, b in keep:
        pts = [a] + [x for x in bounds if a + 0.02 < x < b - 0.02] + [b]
        for x, y in zip(pts, pts[1:]):
            sp = seg_speed(proj, (x + y) / 2)
            if out and abs(out[-1][1] - x) < 1e-6 and out[-1][2] == sp:
                out[-1] = (out[-1][0], y, sp)
            else:
                out.append((x, y, sp))
    return out


def make_time_mapper(keep):
    """Tempo originale -> tempo nel video finale (None se tagliato). keep: (a, b) o (a, b, velocita')."""
    starts, acc = [], 0.0
    for k in keep:
        a, b = k[0], k[1]
        sp = k[2] if len(k) > 2 else 1.0
        starts.append((a, b, acc, sp))
        acc += (b - a) / sp

    def f(t):
        for a, b, off, sp in starts:
            if a <= t <= b:
                return off + (t - a) / sp
        return None
    return f, acc


def shift_after(proj, t0, dt):
    """Video inserito in mezzo (al tempo t0, lungo dt): quello che viene dopo si sposta avanti.
    La clip che contiene t0 si divide in due e in mezzo nasce la clip nuova."""
    def sh(x):
        return x + dt if x >= t0 - 1e-6 else x
    for z in proj.get("zooms", []) + proj.get("filters", []) + proj.get("cuts", []):
        z["a"], z["b"] = sh(z["a"]), sh(z["b"])
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            c["a"] = sh(c["a"])
            if "b" in c:
                c["b"] = sh(c["b"])
    for seg in (proj.get("transcript") or {}).get("segments", []):
        seg["a"], seg["b"] = sh(seg["a"]), sh(seg["b"])
        for w in seg.get("words", []):
            w["a"], w["b"] = sh(w["a"]), sh(w["b"])
    segs = []
    for c in proj.get("segs", []):
        if c["b"] <= t0 + 1e-6:
            segs.append(c)
        elif c["a"] >= t0 - 1e-6:
            c["a"] += dt
            c["b"] += dt
            segs.append(c)
        else:   # la clip viene divisa nel punto dove entra il video nuovo
            c2 = dict(c, id=new_id("s"), a=t0 + dt, b=c["b"] + dt)
            c["b"] = t0
            segs += [c, c2]
    segs.append(new_seg(t0, t0 + dt))
    segs.sort(key=lambda x: x["a"])
    proj["segs"] = segs


def shift_times(proj, dt):
    """Sposta avanti di dt secondi tutto quello che sta sulla timeline (video aggiunto all'inizio)."""
    if not dt:
        return
    for z in proj.get("zooms", []):
        z["a"] += dt
        z["b"] += dt
    for f in proj.get("filters", []):
        f["a"] += dt
        f["b"] += dt
    for c in proj.get("cuts", []):
        c["a"] += dt
        c["b"] += dt
    for s in proj.get("segs", []):
        s["a"] += dt
        s["b"] += dt
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            c["a"] += dt
            if "b" in c:
                c["b"] += dt
    for seg in (proj.get("transcript") or {}).get("segments", []):
        seg["a"] += dt
        seg["b"] += dt
        for w in seg.get("words", []):
            w["a"] += dt
            w["b"] += dt


# ---------------------------------------------------------------- video inseriti nella traccia principale
# Un video aggiunto all'inizio, alla fine o in mezzo NON viene unito alla live: resta un file a parte.
# La timeline continua a usare un solo tempo ("tempo della timeline"); qui si calcola quale file c'e'
# in ogni istante e in che punto di quel file.
def live_duration(proj):
    ins = proj.get("inserts") or []
    return proj.get("liveDuration") or (proj["duration"] - sum(i["dur"] for i in ins))


def pieces(proj):
    """[{t0, t1, file, off, live, ins}] in ordine: la live (a pezzi) e i video inseriti."""
    ins = sorted(proj.get("inserts") or [], key=lambda x: x["at"])
    out, T, L = [], 0.0, 0.0
    live_d = live_duration(proj)
    for i in ins:
        if i["at"] > T + 1e-6:
            out.append({"t0": T, "t1": i["at"], "file": proj["source"], "off": L, "live": True, "ins": None})
            L += i["at"] - T
            T = i["at"]
        if i.get("live"):   # un pezzo della live spostato in un altro punto: si legge dalla live
            out.append({"t0": T, "t1": T + i["dur"], "file": proj["source"], "off": i.get("offset", 0.0), "live": True, "ins": i})
        else:
            out.append({"t0": T, "t1": T + i["dur"], "file": i["file"], "off": i.get("offset", 0.0), "live": False, "ins": i})
        T += i["dur"]
    if live_d - L > 1e-3 or not out:
        out.append({"t0": T, "t1": T + (live_d - L), "file": proj["source"], "off": L, "live": True, "ins": None})
    return out


def piece_at(proj, t, pcs=None):
    pcs = pcs or pieces(proj)
    for p in pcs:
        if t < p["t1"] - 1e-6:
            return p
    return pcs[-1]


def live_to_timeline(proj, lt):
    """Istante della live -> istante sulla timeline (per la trascrizione della live)."""
    for p in pieces(proj):
        if p["live"] and p["off"] - 1e-6 <= lt < p["off"] + (p["t1"] - p["t0"]) + 1e-6:
            return p["t0"] + (lt - p["off"])
    return lt


def insert_video(proj, at, info):
    """Mette un video nella timeline al tempo 'at'. info: {file, dur, w, h, hasAudio, name, preview?}.
    Se 'at' cade dentro un altro video inserito, va prima o dopo quello (il piu' vicino)."""
    at = max(0.0, min(proj["duration"], float(at)))
    for i in proj.get("inserts") or []:
        if i["at"] < at < i["at"] + i["dur"]:
            at = i["at"] if at - i["at"] < i["at"] + i["dur"] - at else i["at"] + i["dur"]
    if at < 0.3:
        at = 0.0
    elif at > proj["duration"] - 0.3:
        at = proj["duration"]
    proj.setdefault("liveDuration", live_duration(proj))
    dt = info["dur"]
    shift_after(proj, at, dt)
    for i in proj.get("inserts") or []:
        if i["at"] >= at - 1e-6:
            i["at"] += dt
    rec = {"id": new_id("v"), "at": at, "dur": dt, "offset": 0.0, "file": info["file"], "name": info.get("name"),
           "w": info.get("w"), "h": info.get("h"), "hasAudio": bool(info.get("hasAudio")), "vcodec": info.get("vcodec")}
    if info.get("preview"):
        rec["preview"] = info["preview"]
    proj.setdefault("inserts", []).append(rec)
    proj["inserts"].sort(key=lambda x: x["at"])
    proj["duration"] = proj["duration"] + dt
    return rec


def remove_interval(proj, t0, dt):
    """Il contrario di shift_after: toglie dalla timeline il tratto [t0, t0+dt] e sposta indietro quello che segue."""
    t1 = t0 + dt

    def sh(x):
        return x - dt if x >= t1 - 1e-6 else min(x, t0)
    for z in proj.get("zooms", []) + proj.get("filters", []) + proj.get("cuts", []):
        z["a"], z["b"] = sh(z["a"]), sh(z["b"])
    for k in ("zooms", "filters", "cuts"):
        proj[k] = [z for z in proj.get(k, []) if z["b"] - z["a"] > 0.05]
    for t in proj.get("tracks", []):
        for c in t.get("clips", []):
            c["a"] = sh(c["a"])
            if "b" in c:
                c["b"] = sh(c["b"])
    tr = proj.get("transcript") or {}
    segs_t = []
    for seg in tr.get("segments", []):
        if seg["a"] >= t0 - 1e-6 and seg["b"] <= t1 + 1e-6:
            continue
        seg["a"], seg["b"] = sh(seg["a"]), sh(seg["b"])
        seg["words"] = [w for w in seg.get("words", []) if not (w["a"] >= t0 - 1e-6 and w["b"] <= t1 + 1e-6)]
        for w in seg["words"]:
            w["a"], w["b"] = sh(w["a"]), sh(w["b"])
        segs_t.append(seg)
    if tr:
        tr["segments"] = segs_t
    out = []
    for c in proj.get("segs", []):
        a, b = sh(c["a"]), sh(c["b"])
        if b - a > 0.02:
            c["a"], c["b"] = a, b
            out.append(c)
    proj["segs"] = out


def repair_merged(proj, orig_duration):
    """Progetti dove un video era stato UNITO alla live (versione vecchia): si torna alla live originale
    e si toglie il pezzo aggiunto (va rimesso trascinandolo, ora non si unisce piu'). Ritorna True se ha riparato."""
    src, orig = proj.get("source") or "", proj.get("origSource")
    if not orig or " (montato" not in os.path.basename(src) or not os.path.exists(orig) or proj.get("inserts"):
        return None
    dt = proj["duration"] - orig_duration
    if dt < 0.05:
        proj["source"] = orig
        proj["duration"] = orig_duration
        proj.pop("origSource", None)
        return (orig_duration, 0.0)
    # dove era finito il video aggiunto: una clip lunga esattamente come lui (di solito l'ultima o la prima)
    at = orig_duration
    cand = [c for c in proj.get("segs", []) if abs((c["b"] - c["a"]) - dt) < 0.15]
    if cand:
        last = [c for c in cand if abs(c["b"] - proj["duration"]) < 0.2]
        first = [c for c in cand if c["a"] < 0.05]
        at = (last or first or cand)[0]["a"]
    remove_interval(proj, at, dt)
    proj["source"] = orig
    proj["duration"] = orig_duration
    if proj.get("segs"):
        proj["segs"][-1]["b"] = min(proj["segs"][-1]["b"], orig_duration)
    proj.pop("origSource", None)
    return (at, dt)


def split_segs_at(segs, points):
    """Divide le clip nei punti dati (i bordi dei video inseriti: ogni video resta una clip a se')."""
    out = []
    for c in segs:
        cuts = [p for p in sorted(points) if c["a"] + 0.02 < p < c["b"] - 0.02]
        a = c["a"]
        for p in cuts:
            out.append(dict(c, id=new_id("s"), a=a, b=p))
            a = p
        out.append(dict(c, a=a) if cuts else c)
    return out
