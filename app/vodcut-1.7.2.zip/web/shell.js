// Rebrand: guscio delle schermate (tutte tranne l'editor). Barra laterale di vetro (248px) con Home, Progetti a tendina
// (cartelle vere, Nuova cartella, Cestino) e Preset; in alto a destra (layout B) pillola lavori, feedback, notifiche e
// profilo. Su Windows la finestra non ha cornice: in alto c'e' una fascia di 32px per trascinarla e per i suoi pulsanti.
import { h, get, post, icon, toast, promptBox, confirmBox } from './lib.js';

const st = { list: null, trash: null, at: 0 };
// tendina dei progetti: aperta in Progetti, nelle cartelle e nel cestino, chiusa da sola nelle altre schermate.
// La freccia la apre e la chiude a mano (vale finche' resti in quelle schermate)
let projOpen = null;

export function extraFolders() { try { return JSON.parse(localStorage.getItem('nf.folders') || '[]'); } catch (e) { return []; } }
export function saveExtraFolders(fs) { try { localStorage.setItem('nf.folders', JSON.stringify([...new Set(fs)])); } catch (e) { /* */ } }
// progetti e cestino, letti dal server (cache breve: la barra si ridisegna a ogni schermata)
export async function shellData(force) {
  if (force || !st.list || Date.now() - st.at > 4000) {
    const [l, t] = await Promise.all([get('/api/projects').catch(() => st.list || []), get('/api/trash').catch(() => st.trash || [])]);
    st.list = l; st.trash = t; st.at = Date.now();
  }
  return st;
}
export function shellDirty() { st.at = 0; }
export function allFolders(list) {
  return [...new Set([...(list || []).map((p) => p.folder).filter(Boolean), ...extraFolders()])].sort((a, b) => a.localeCompare(b));
}

// rinomina una cartella: e' il campo "folder" dei progetti che ci stanno dentro (piu' l'elenco delle cartelle vuote)
export async function renameFolder(oldName, newName, list) {
  newName = (newName || '').trim();
  if (!newName || newName === oldName) return false;
  for (const p of list.filter((x) => x.folder === oldName)) await post(`/api/p/${p.id}/meta`, { folder: newName });
  saveExtraFolders(extraFolders().map((f) => (f === oldName ? newName : f)));
  shellDirty();
  return true;
}
// elimina una cartella: i progetti restano, escono solo dalla cartella
export async function deleteFolder(name, list) {
  const inside = list.filter((x) => x.folder === name);
  const ok = await confirmBox('Eliminare la cartella?', inside.length === 1
    ? `Il progetto di "${name}" resta tra i tuoi progetti, fuori da ogni cartella.`
    : inside.length ? `I ${inside.length} progetti di "${name}" restano tra i tuoi progetti, fuori da ogni cartella.`
    : `La cartella "${name}" è vuota.`, 'Elimina la cartella', true);
  if (!ok) return false;
  for (const p of inside) await post(`/api/p/${p.id}/meta`, { folder: '' });
  saveExtraFolders(extraFolders().filter((f) => f !== name));
  shellDirty();
  return true;
}
export async function newFolder() {
  const nm = await promptBox('Nuova cartella', 'Metti qui i video di una serie o di una playlist: esportati, finiscono tutti nella stessa cartella.', '', 'Crea');
  if (!nm || !nm.trim()) return '';
  saveExtraFolders([...extraFolders(), nm.trim()]);
  shellDirty();
  return nm.trim();
}

// ctx: { nav, active: 'home'|'projects'|'trash'|'preset'|'folder', folder, cluster: [elementi in alto a destra],
//        winCtl: elemento con i pulsanti della finestra, onPreset }
const INSIDE = ['projects', 'folder', 'trash'];
export function shell(ctx, ...content) {
  if (!INSIDE.includes(ctx.active)) projOpen = null;   // uscendo da Progetti la tendina si chiude da sola
  const side = h('aside', { class: 'nf-side' });
  const main = h('section', { class: 'nfs-main' }, ...content);
  const tr = h('div', { class: 'nf-tr' }, ...(ctx.cluster || []));
  const root = h('div', { class: 'nf-shell' }, h('div', { class: 'nf-titlebar' }, ctx.winCtl || null), side, main, tr);
  const go = (s, a) => ctx.nav(s, a);
  const item = (key, ic, label, extra, onclick) => h('button', { class: 'nfs-it' + (ctx.active === key ? ' on' : ''), type: 'button', onclick },
    icon(ic, 17, 'currentColor', 1.6), h('span', { class: 'nfs-it-l' }, label), ...(extra || []));

  // la barra si disegna subito con i progetti che conosce gia' (niente barra vuota cambiando schermata), poi si aggiorna
  async function paint(force) {
    // subito, anche al primo avvio quando l'elenco non c'e' ancora (senza i numeri): mai una barra vuota
    if (!force) draw(st.list ? st : { list: null, trash: null });
    draw(await shellData(force));
  }
  function draw(d) {
    const list = d.list || [], trashN = (d.trash || []).length;
    const fs = allFolders(list);
    // dentro una cartella o nel cestino la tendina resta aperta, con la voce giusta accesa
    const inside = INSIDE.includes(ctx.active);
    const open = ctx.active === 'folder' || ctx.active === 'trash' || (projOpen != null ? projOpen : inside);
    const chev = icon('right', 13, 'currentColor', 1.8);
    chev.classList.add('nf-chev'); if (open) chev.classList.add('open');
    const sub = h('div', { class: 'nf-sub', hidden: !open },
      ...fs.map((f) => {
        const n = list.filter((p) => p.folder === f).length;
        return h('div', { class: 'nf-fd' + (ctx.active === 'folder' && ctx.folder === f ? ' on' : ''), role: 'button', tabindex: '0', onclick: () => go('projects', 'f:' + f) },
          icon('folder', 14, 'currentColor', 1.6), h('span', { class: 'nf-fd-n', 'data-notr': '' }, f),
          n ? h('span', { class: 'nf-n' }, String(n)) : null,
          h('span', { class: 'nf-fd-act' },
            h('button', { type: 'button', 'aria-label': 'Rinomina', 'data-tip': 'Rinomina', onclick: async (e) => {
              e.stopPropagation();
              const nm = await promptBox('Rinomina la cartella', null, f, 'Rinomina');
              try {
                if (!(await renameFolder(f, nm, list))) return;
                toast('Cartella rinominata');
                if (ctx.active === 'folder' && ctx.folder === f) go('projects', 'f:' + nm.trim()); else if (ctx.onFolders) ctx.onFolders(); else paint(true);
              } catch (er) { toast(er.message, true); }
            } }, icon('pen', 12, 'currentColor', 1.8)),
            h('button', { type: 'button', class: 'del', 'aria-label': 'Elimina', 'data-tip': 'Elimina', onclick: async (e) => {
              e.stopPropagation();
              try { if (await deleteFolder(f, list)) { toast('Cartella eliminata'); if (ctx.active === 'folder' && ctx.folder === f) go('projects'); else if (ctx.onFolders) ctx.onFolders(); else paint(true); } } catch (er) { toast(er.message, true); }
            } }, icon('trash', 12, 'currentColor', 1.8))));
      }),
      h('div', { class: 'nf-fd add', role: 'button', tabindex: '0', onclick: async () => { const nm = await newFolder(); if (nm) go('projects', 'f:' + nm); } },
        icon('plus', 14, 'currentColor', 1.8), h('span', null, 'Nuova cartella')),
      h('div', { class: 'nf-fd' + (ctx.active === 'trash' ? ' on' : ''), role: 'button', tabindex: '0', onclick: () => go('projects', 'trash') },
        icon('trash', 14, 'currentColor', 1.6), h('span', { class: 'nf-fd-n' }, 'Cestino'), trashN ? h('span', { class: 'nf-n' }, String(trashN)) : null));
    const setOpen = (v) => {
      projOpen = v;
      chev.classList.toggle('open', v); sub.hidden = !v;
    };
    // la freccia apre e chiude la tendina; la voce porta a tutti i progetti (se ci sei gia', apre e chiude)
    chev.addEventListener('click', (e) => { e.stopPropagation(); setOpen(sub.hidden); });
    const proj = item(inside ? 'projects' : '-', 'apps', 'Progetti', [h('span', { class: 'nf-n' }, d.list ? String(list.length) : ''), chev], () => {
      if (ctx.active === 'projects') { setOpen(sub.hidden); return; }
      setOpen(true);
      go('projects');
    });
    if (inside) proj.classList.add('on');
    proj.setAttribute('data-tour', 'nav');
    const preset = item('preset', 'presets', 'Preset', [], () => ctx.onPreset && ctx.onPreset());
    preset.setAttribute('data-tour', 'preset');
    side.replaceChildren(
      h('div', { class: 'nf-brand' }, h('img', { src: '/web/logo.png', alt: '', draggable: 'false' }), h('span', null, 'NoonFrame')),
      h('nav', { class: 'nf-nav' }, item('home', 'home', 'Home', null, () => go('home')), proj, sub),
      preset);
  }
  paint();
  root.repaintSide = paint;
  return root;
}
