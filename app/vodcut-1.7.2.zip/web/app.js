// NoonFrame - app principale: navigazione e schermate semplici. L'editor e' in editor.js
import { screenFast } from './fastclip.js';
import { api, get, post, put, h, icon, fmt, fmtDur, toast, confirmBox, promptBox, seg, pollJob, mediaUrl, thumbUrl, TOKEN, targetRect, IS_MAC, droppedPath, BIG_DROP, fixLink, isLocalPath, localPath, getTheme, setTheme, popOpened, onPopOpened, linkProblem } from './lib.js';
import { mountEditor } from './editor.js';
import { studioRoutes } from './studio.js';
import { screenClips } from './clips.js';
import { designHome } from './design/home.js';
import { mountDesign } from './design/editor.js';
import { feedbackButton, setContext, getContext, setFeedbackEmail } from './feedback.js';
import { offerBanner, walletCard, markOffer, planCard, loadCatalog, creditsDialog } from './credits.js';
import { jobsPill, setJobOpener } from './jobs.js';
import { shell, shellDirty } from './shell.js';
import { recentCard, projectsPage, quickActs } from './projects.js';
import { montaSheet, nuovoSheet, sheet } from './sheets.js';
import { shortcutsSheet, installGlobalKeys } from './shortcuts.js';
import { startTour, endTour } from './tour.js';
import { showBanner, hideBanner, inlineError, showSheet, explain } from './errors.js';
import { openStyleWizard, loadLook, lookCache } from './clipstyle.js';
import { presetsPage } from './presets.js';
import { plansView } from './plans.js';
import { liveImport } from './livesheet.js';
import { notifButton } from './messages.js';
import { LANG, loadLang, pickLang, startTranslating, locale } from './i18n.js';
// rotelline di caricamento: ogni rotellina nuova riparte dallo stesso punto delle altre (niente scatti quando la pagina si ridisegna)
try {
  new MutationObserver((ms) => {
    const ph = -(performance.now() % 800) + 'ms';
    for (const m of ms) for (const n of m.addedNodes) {
      if (n.nodeType !== 1) continue;
      if (n.classList.contains('spinner')) n.style.animationDelay = ph;
      if (n.firstElementChild) n.querySelectorAll('.spinner').forEach((x) => { x.style.animationDelay = ph; });
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
} catch (e) { /* */ }

const app = document.getElementById('app');
let ENV = { ffmpeg: true, whisper: false, gpu: false, ytdlp: false };
let cleanup = null;

// ----------------------------------------------------------------- barra in alto
const STEPS = ['Importa', 'Webcam', 'Stile', 'Modifica', 'Esporta'];
function topbar(stepIdx, right, allDone, crumb) {
  return h('header', { class: 'topbar' },
    h('button', { class: 'brand', onclick: () => nav('home'), 'aria-label': 'Torna alla home' },
      h('img', { class: 'logo', src: '/web/logo.png', alt: '', draggable: 'false' }), 'NoonFrame'),
    // clip verticale: al posto dei passaggi, la strada per tornare al video orizzontale
    crumb ? h('nav', { class: 'steps crumbs', 'aria-label': 'Dove sei' },
      crumb.parent ? h('button', { class: 'crumb-back', 'data-tip': crumb.parentTip || (crumb.toClips ? 'Torna a tutte le clip' : 'Torna al video orizzontale (non è stato toccato)'), onclick: () => nav(crumb.toClips ? 'clips' : 'editor', crumb.parent) },
        icon('left', 13, 'currentColor', 2.4), h('span', { 'data-notr': '' }, crumb.parentName || 'Video orizzontale'))
        : h('button', { class: 'crumb-back', 'data-tip': 'Tutti i progetti', onclick: () => nav('home') }, icon('left', 13, 'currentColor', 2.4), h('span', null, 'Progetti')),
      h('span', { class: 'crumb-sep' }, '/'),
      h('span', { class: 'crumb-cur' + (crumb.parent ? '' : ' h') + (crumb.onRename ? ' ren' : ''), 'data-tip': crumb.onRename ? 'Clic per rinominare' : null,
        onclick: crumb.onRename ? (e) => crumb.onRename(e.currentTarget) : null }, icon(crumb.icon || (crumb.parent ? 'phone' : 'film'), 13, 'currentColor', 2), h('span', { 'data-notr': '', class: 'crumb-name' }, crumb.name)))
    : stepIdx < 0 ? h('nav', { class: 'steps' }) : h('nav', { class: 'steps', 'aria-label': 'Passaggi' }, STEPS.map((s, i) => {
      const done = allDone || i < stepIdx, cur = !allDone && i === stepIdx;
      return h('div', { class: 'step' + (done ? ' done' : '') + (cur ? ' cur' : ''), 'aria-current': cur ? 'step' : null },
        h('span', { class: 'n' }, done ? icon('check', 11, '#fff', 3.5) : String(i + 1)), s);
    })),
    notifButton(),
    accountButton(),
    feedbackButton(),
    updSlot(),
    h('div', { class: 'topright' }, right || null),
    winCtl());
}

// rebrand 12: Webcam e Stile non sono piu' passi obbligati, si aprono dall'editor per correggere. In alto: indietro,
// nome del progetto e cosa stai sistemando; a destra lavori in corso, feedback, notifiche e profilo
function flowHeader(proj, what) {
  const toEd = proj.stage === 'editor';
  return h('header', { class: 'topbar eh fl-head' },
    h('button', { class: 'eh-back', type: 'button', 'aria-label': toEd ? 'Torna all\'editor' : 'Tutti i progetti', 'data-tip': toEd ? 'Torna all\'editor' : 'Tutti i progetti', onclick: () => nav(toEd ? 'editor' : 'projects', toEd ? proj.id : null) }, icon('left', 16, 'currentColor', 2)),
    h('img', { class: 'eh-logo', src: '/web/logo.png', alt: '', draggable: 'false' }),
    h('div', { class: 'eh-title' }, h('span', { class: 'crumb-cur h' }, h('span', { 'data-notr': '', class: 'crumb-name' }, proj.name || '')),
      h('span', { class: 'eh-sub' }, h('span', null, what))),
    h('div', { class: 'grow' }), jobsPill(),
    h('div', { class: 'eh-tr' }, updSlot(), feedbackButton(), notifButton(), h('div', { class: 'nf-sep' }), profileButton()), winCtl());
}

// ----------------------------------------------------------------- aggiornamenti automatici
// l'app scarica da sola le versioni nuove in background; qui solo l'avviso "pronto: riavvia" (come CapCut)
let UPD = null, updLater = false, updNewsShown = false;
function updSlot() { const s = h('div', { class: 'updslot' }); fillUpd(s); return s; }
function fillUpd(s) {
  s.innerHTML = '';
  if (!UPD || updLater) return;
  if (UPD.state === 'ready') {
    s.append(h('button', { class: 'updpill', 'data-tip': 'Novità e riavvio', onclick: updDialog },
      h('span', { class: 'updpill-dot' }), 'Aggiornamento pronto'));
  } else if (UPD.state === 'installer') {
    s.append(h('button', { class: 'updpill', 'data-tip': 'C\'è una nuova versione da installare', onclick: updDialog },
      icon('download', 13, 'currentColor', 2.2), 'Nuova versione'));
  }
}
function onUpd(u) {
  if (!u) return;
  const was = UPD && UPD.state + (UPD.version || '');
  UPD = u;
  if (was !== u.state + (u.version || '')) document.querySelectorAll('.updslot').forEach(fillUpd);
  if (u.justUpdated && !updNewsShown) { updNewsShown = true; newsDialog(u.justUpdated); }
}
function notesList(notes) {
  const items = String(notes || '').split(/\n+/).map((x) => x.replace(/^\s*[-•*]\s*/, '').trim()).filter(Boolean);
  return items.length ? h('ul', { class: 'upd-notes' }, ...items.map((x) => h('li', { 'data-notr': '' }, x))) : null;
}
// novita' divise per tipo; se le versioni sono piu' d'una, un riepilogo di tutto con la versione accanto
const CH_TYPES = [['feat', 'Novità', 'sparkle'], ['fix', 'Correzioni', 'check'], ['impr', 'Miglioramenti', 'wand']];
function changesView(hist, notes) {
  hist = (hist || []).filter((e) => e.items && e.items.length);
  if (!hist.length) return notesList(notes);
  const many = hist.length > 1;
  const box = h('div', { class: 'upd-changes' });
  if (many) box.append(h('div', { class: 'upd-recap' }, h('b', null, `${hist.length} aggiornamenti`), h('span', null, ' · ecco tutto quello che è cambiato')));
  CH_TYPES.forEach(([type, label, ic]) => {
    const rows = [];
    hist.forEach((e) => e.items.filter((i) => i.type === type).forEach((i) => rows.push([i.text, e.version])));
    if (!rows.length) return;
    box.append(h('div', { class: 'upd-sec upd-' + type },
      h('div', { class: 'upd-sec-h' }, h('span', { class: 'upd-sec-ic' }, icon(ic, 12, 'currentColor', 2.4)), h('span', null, label), h('span', { class: 'upd-sec-n' }, String(rows.length))),
      h('ul', null, ...rows.map(([t, v]) => h('li', null, h('span', { 'data-notr': '' }, t), many ? h('span', { class: 'upd-ver', 'data-notr': '' }, v) : null)))));
  });
  return box;
}
function updModal(kids) {
  const bg = h('div', { class: 'modal-bg' });
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.append(h('div', { class: 'modal updmodal', role: 'dialog', 'aria-modal': 'true' }, ...kids(close)));
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
}
function updDialog() {
  const u = UPD || {};
  const inst = u.state === 'installer';
  updModal((close) => [
    h('div', { class: 'upd-hero' }, h('img', { src: '/web/app-icon.png', alt: '' }),
      h('div', null, h('h2', null, inst ? 'Nuova versione di NoonFrame' : 'Aggiornamento pronto'),
        h('div', { class: 'muted small' }, h('span', null, 'Versione'), ' ', h('b', { 'data-notr': '' }, u.version || ''),
          ' · ', h('span', null, 'ora hai la'), ' ', h('span', { 'data-notr': '' }, u.current || ENV.version || '')))),
    changesView(u.history, u.notes) || h('p', { class: 'muted' }, 'Correzioni e miglioramenti.'),
    inst ? h('p', { class: 'xs', style: { margin: 0 } }, 'Questa versione cambia anche i componenti interni: va scaricata e installata sopra quella che hai. I progetti restano.')
      : h('p', { class: 'xs', style: { margin: 0 } }, 'È già scaricata. Si applica riavviando NoonFrame, anche più tardi: al prossimo avvio parte da sola.'),
    h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
      h('button', { class: 'btn ghost', onclick: () => { updLater = true; document.querySelectorAll('.updslot').forEach(fillUpd); close(); } }, 'Più tardi'),
      inst ? h('button', { class: 'btn primary', onclick: () => { if (u.installer) post('/api/openurl', { url: u.installer }).catch((e) => toast(e.message, true)); close(); } }, icon('download', 14), 'Scarica')
        : h('button', { class: 'btn primary', onclick: () => { close(); restartForUpdate(); } }, 'Riavvia ora')),
  ]);
}
// versioni beta (solo account autorizzati: il server ricontrolla)
async function betaDialog() {
  const on = ENV.channel === 'beta';
  const ok = await confirmBox(on ? 'Torna alle versioni stabili' : 'Versioni di prova (beta)',
    on ? 'Riceverai solo le versioni stabili. Quella che hai resta finché non esce una stabile più nuova.'
      : 'Ricevi le correzioni prima di tutti, appena sono pronte. Possono avere qualche problema in più delle versioni stabili.',
    on ? 'Passa a stabile' : 'Attiva beta');
  if (!ok) return;
  try {
    const j = await post('/api/update/channel', { channel: on ? 'stable' : 'beta' });
    ENV.channel = j.channel;
    const vs = document.querySelector('.homefoot span'); if (vs) vs.textContent = 'NoonFrame ' + (ENV.version || '') + (j.channel === 'beta' ? ' beta' : '') + ' · Emanuele Saurro';
    const b = document.getElementById('betabtn'); if (b) b.textContent = j.channel === 'beta' ? 'Beta attiva' : 'Versioni beta';
    toast(j.channel === 'beta' ? 'Versioni beta attive' : 'Versioni stabili attive');
  } catch (e) { toast(e.message, true); }
}
async function restartForUpdate(force) {
  try {
    const j = await post('/api/update/restart', { force: !!force });
    if (j.busy) {
      if (await confirmBox('C\'è un lavoro in corso', 'Un\'esportazione o un\'analisi non è ancora finita. Se riavvii adesso si interrompe. Meglio aspettare che finisca: l\'aggiornamento si applica anche al prossimo avvio.', 'Riavvia comunque', true)) restartForUpdate(true);
      return;
    }
    document.body.append(h('div', { class: 'modal-bg upd-restarting' }, h('div', { class: 'upd-rs' }, h('div', { class: 'spinner' }), h('div', null, 'Riavvio NoonFrame…'))));
    // di solito questa finestra si chiude e se ne apre una nuova; se resta aperta, si ricarica da sola
    const old = (await fetch('/api/ping').then((r) => r.json()).catch(() => ({}))).stamp;
    const t0 = Date.now();
    const iv = setInterval(async () => {
      const j = await fetch('/api/ping').then((r) => r.json()).catch(() => null);
      if ((j && j.stamp !== old) || Date.now() - t0 > 60000) { clearInterval(iv); location.reload(); }
    }, 1000);
  } catch (e) { toast(e.message, true); }
}
function newsDialog(j) {
  const notes = changesView(j.history, j.notes);
  if (!notes) { toast('NoonFrame aggiornato alla versione ' + j.version); return; }
  const n = (j.history || []).filter((e) => e.items && e.items.length).length;
  updModal((close) => [
    h('div', { class: 'upd-hero' }, h('img', { src: '/web/app-icon.png', alt: '' }),
      h('div', null, h('h2', null, n > 1 ? 'Cosa è cambiato' : 'Novità di questa versione'),
        h('div', { class: 'muted small', 'data-notr': '' }, (n > 1 && j.from ? 'NoonFrame ' + j.from + ' → ' : 'NoonFrame ') + j.version))),
    notes,
    h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn primary', onclick: close }, 'Ok')),
  ]);
}
async function checkUpdatesNow(btn) {
  const lab = btn.textContent;
  btn.disabled = true; btn.textContent = 'Controllo…';
  try {
    const u = await post('/api/update/check');
    updLater = false; onUpd(u);
    document.querySelectorAll('.updslot').forEach(fillUpd);
    if (u.state === 'ready' || u.state === 'installer') updDialog();
    else if (u.state === 'uptodate') toast('Hai già l\'ultima versione');
    else if (u.state === 'error') toast('Non riesco a controllare gli aggiornamenti adesso. Riprova più tardi.', true);
  } catch (e) { toast(e.message, true); }
  btn.disabled = false; btn.textContent = lab;
}

// ----------------------------------------------------------------- finestra nativa (barra del titolo disegnata dall'app)
// sul Mac la finestra ha la sua barra di macOS: niente pulsanti e bordi disegnati dall'app
const wapi = () => (!IS_MAC && window.pywebview && window.pywebview.api) || null;
const fsApi = () => (window.pywebview && window.pywebview.api) || null;
const WIN_ICONS = {
  min: '<svg width="10" height="10" viewBox="0 0 10 10"><path d="M0 5h10" stroke="currentColor" stroke-width="1"/></svg>',
  max: '<svg width="10" height="10" viewBox="0 0 10 10"><rect x=".5" y=".5" width="9" height="9" rx="1.5" fill="none" stroke="currentColor"/></svg>',
  restore: '<svg width="10" height="10" viewBox="0 0 10 10"><rect x=".5" y="2.5" width="7" height="7" rx="1.2" fill="none" stroke="currentColor"/><path d="M2.5 2.5V1.8A1.3 1.3 0 0 1 3.8.5h4.4A1.3 1.3 0 0 1 9.5 1.8v4.4A1.3 1.3 0 0 1 8.2 7.5H7.5" fill="none" stroke="currentColor"/></svg>',
  close: '<svg width="10" height="10" viewBox="0 0 10 10"><path d="M.5.5l9 9M9.5.5l-9 9" stroke="currentColor" stroke-width="1"/></svg>',
};
let winMax = false;
function winBtn(ic, label, fn, cls) {
  const b = h('button', { class: 'wc' + (cls ? ' ' + cls : ''), 'aria-label': label, 'data-wc': ic, onclick: fn });
  b.innerHTML = WIN_ICONS[ic];
  return b;
}
function syncMaxBtn() {
  document.documentElement.classList.toggle('maxed', winMax);
  document.querySelectorAll('.wc[data-wc="max"], .wc[data-wc="restore"]').forEach((b) => { b.innerHTML = WIN_ICONS[winMax ? 'restore' : 'max']; b.setAttribute('aria-label', winMax ? 'Ripristina' : 'Ingrandisci'); });
}
async function toggleMax() { const a = wapi(); if (!a) return; winMax = !!(await a.toggle_maximize()); syncMaxBtn(); }
function winCtl() {
  return h('div', { class: 'winctl' },
    winBtn('min', 'Riduci a icona', () => wapi() && wapi().minimize()),
    winBtn(winMax ? 'restore' : 'max', winMax ? 'Ripristina' : 'Ingrandisci', toggleMax),
    winBtn('close', 'Chiudi', () => wapi() && wapi().close(), 'close'));
}
// trascinare la barra in alto sposta la finestra; doppio clic la ingrandisce
const NO_DRAG = 'button, input, select, textarea, a, [role="button"], .winctl';
// la barra in alto e' la barra del titolo: trascinandola si sposta la finestra (lo fa Windows), doppio clic = ingrandisci
let lastDown = { t: 0, x: 0, y: 0 };
document.addEventListener('pointerdown', (e) => {
  const a = wapi();
  if (!a || e.button !== 0) return;
  if (!e.target.closest('.topbar, .nf-titlebar') || e.target.closest(NO_DRAG)) return;
  const now = Date.now();
  if (now - lastDown.t < 400 && Math.abs(e.screenX - lastDown.x) < 6 && Math.abs(e.screenY - lastDown.y) < 6) { lastDown.t = 0; toggleMax(); return; }
  lastDown = { t: now, x: e.screenX, y: e.screenY };
  // di riserva, se lo spostamento di Windows non parte: si sposta a mano seguendo il mouse
  const sx = e.screenX, sy = e.screenY, wx = window.screenX, wy = window.screenY, dpr = window.devicePixelRatio || 1;
  let busy = false, next = null, moved = false;
  const push = () => { if (busy || !next) return; busy = true; const n = next; next = null; a.set_bounds(n[0], n[1], 0, 0, dpr).finally(() => { busy = false; push(); }); };
  const mv = (ev) => { if (winMax) return; moved = true; next = [wx + ev.screenX - sx, wy + ev.screenY - sy]; push(); };
  const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); };
  window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  if (a.start_drag) a.start_drag().then(() => { up(); if (a.is_max) a.is_max().then((m) => { winMax = !!m; syncMaxBtn(); }).catch(() => {}); }).catch(() => {});
});
// bordi per ridimensionare la finestra
function mountEdges() {
  for (const ed of ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw']) {
    const el = h('div', { class: 'wedge ' + ed });
    el.addEventListener('pointerdown', (e) => {
      const a = wapi(); if (!a || winMax) return;
      e.preventDefault(); el.setPointerCapture(e.pointerId);
      const sx = e.screenX, sy = e.screenY, dpr = window.devicePixelRatio || 1;
      const r0 = { x: window.screenX, y: window.screenY, w: window.outerWidth, h: window.outerHeight };
      let busy = false, next = null;
      const push = () => { if (busy || !next) return; busy = true; const n = next; next = null; a.set_bounds(n.x, n.y, n.w, n.h, dpr).finally(() => { busy = false; push(); }); };
      const mv = (ev) => {
        const dx = ev.screenX - sx, dy = ev.screenY - sy, r = { ...r0 };
        if (ed.includes('e')) r.w = Math.max(1000, r0.w + dx);
        if (ed.includes('s')) r.h = Math.max(640, r0.h + dy);
        if (ed.includes('w')) { r.w = Math.max(1000, r0.w - dx); r.x = r0.x + r0.w - r.w; }
        if (ed.includes('n')) { r.h = Math.max(640, r0.h - dy); r.y = r0.y + r0.h - r.h; }
        next = r; push();
      };
      const up = () => { el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); };
      el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up);
    });
    document.body.append(el);
  }
}
window.addEventListener('pywebviewready', async () => {
  if (IS_MAC) return;
  document.documentElement.classList.add('native');
  mountEdges();
  try {
    const info = await wapi().setup();
    winMax = !!info.max; syncMaxBtn();
  } catch (e) { /* resta il trascinamento via script */ }
});
// ingrandita anche da Windows (doppio clic o trascinando in alto): aggiorna l'icona
window.addEventListener('resize', () => {
  if (!wapi() || document.fullscreenElement) return;
  const m = window.outerWidth >= screen.availWidth - 2 && window.outerHeight >= screen.availHeight - 2;
  if (m !== winMax) { winMax = m; syncMaxBtn(); }
});
// schermo intero dell'anteprima: la finestra copre tutto lo schermo, anche la barra delle app
document.addEventListener('fullscreenchange', () => {
  const on = !!document.fullscreenElement;
  if (IS_MAC) { post('/api/window/fullscreen', { on }).catch(() => {}); return; }   // sul Mac passa dal server (niente js_api)
  const a = fsApi(); if (a) a.fullscreen(on).catch(() => {});
});
// niente zoom dell'intera app (Ctrl + rotella, Ctrl +/-/0): e' un'app, non una pagina web
window.addEventListener('wheel', (e) => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
window.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && ['+', '=', '-', '_', '0'].includes(e.key)) e.preventDefault(); });
document.addEventListener('gesturestart', (e) => e.preventDefault());

// ----------------------------------------------------------------- navigazione
// una sola schermata alla volta: un doppio clic (o due aperture ravvicinate) non deve aprire l'editor due volte
let navSeq = 0, lastNav = { key: '', t: 0 };
const stale = (my) => my !== navSeq;
// cambio schermata senza lampo nero: la schermata di prima resta ferma sopra (senza clic) finche' la nuova non e' nella
// finestra, poi sparisce nello stesso fotogramma. Al massimo 1,5 secondi, se la nuova ci mette di piu'.
let ghost = null;
function holdOld() {
  if (!app.firstChild) return;
  if (!ghost) { ghost = h('div', { class: 'nav-ghost', 'aria-hidden': 'true' }); ghost.inert = true; document.body.append(ghost); }
  ghost.replaceChildren(...app.childNodes);
  clearTimeout(ghost.t);
  ghost.t = setTimeout(dropOld, 1500);
}
function dropOld() { if (!ghost) return; clearTimeout(ghost.t); ghost.remove(); ghost = null; }
new MutationObserver(() => { if (ghost && app.firstChild) dropOld(); }).observe(app, { childList: true });
export async function nav(screen, pid, extra) {
  const key = screen + '|' + (pid || '');
  if (key === lastNav.key && Date.now() - lastNav.t < 1500) return;
  lastNav = { key, t: Date.now() };
  const my = ++navSeq;
  endTour(true);
  app.classList.remove('live-only');
  setContext(screen, pid);
  if (cleanup) { const c = cleanup; cleanup = null; try { await c(); } catch (e) { /* ignora */ } }
  if (stale(my)) return;
  holdOld();
  const routes = { aiformats: (pid) => SR.formats(pid), studio: (pid) => SR.home(pid), aipage: (pid) => SR.page(pid), aistory: (pid) => SR.story(pid), profile: screenProfile, story: screenStory, home: screenHome, projects: screenProjects, preset: screenPreset, credits: screenCredits, design: screenDesign, webcam: screenWebcam, style: screenStyle, editor: screenEditor, export: screenExport, done: screenDone, clips: (pid) => screenClips(pid, { app, nav, setTitle, setCleanup: (fn) => { cleanup = fn; }, shell: (...c) => appShell('projects', null, ...c), openProject: (p) => openLong(p) }),
    fastclip: (pid, extra) => screenFast({ app, nav, setTitle, setCleanup: (fn) => { cleanup = fn; }, shell: (...c) => appShell('home', null, ...c) }, extra) };
  try { await routes[screen](pid, extra); } catch (e) { console.error(e); toast(e.message, true); if (screen !== 'home') nav('home'); }
}
window.addEventListener('nf-nav', (e) => { const [s, id, extra] = e.detail || []; if (s) nav(s, id, extra); });
// pagamento fatto (dal foglio di pagamento o dal browser): anello dei crediti e menu del profilo aggiornati ovunque
window.addEventListener('nf-credits-changed', async () => { await loadCredits(); paintAccount(); });
// errori (18a): dai fogli "Ricarica" e "Cerca il file"; striscia in alto quando manca internet; versione nei dettagli
window.addEventListener('nf-plans', () => creditsDialog());
window.addEventListener('nf-relink', async () => {
  const { screen, pid } = getContext();
  if (!pid) { nav('projects'); return; }
  try {
    const miss = await get('/api/p/' + pid + '/missing');
    if (!miss.length) { toast('Il video adesso si trova: riapro il progetto'); lastNav = { key: '', t: 0 }; nav(screen, pid); return; }
    if (await relinkDialog(pid, miss)) { lastNav = { key: '', t: 0 }; nav(screen, pid); }
  } catch (e) { toast(e.message, true); }
});
const offline = () => showBanner('Nessuna connessione a internet.', 'I download e l\'AI riprendono da soli quando torna. Puoi continuare a montare.',
  () => { if (navigator.onLine) hideBanner(); else toast('Ancora senza connessione: riprovo da solo quando torna'); });
window.addEventListener('offline', offline);
window.addEventListener('online', hideBanner);
if (navigator.onLine === false) setTimeout(offline, 1500);
get('/api/env').then((e) => { window.VODCUT.version = (e.version || '') + (e.channel === 'beta' ? ' beta' : ''); }).catch(() => {});
// scorciatoie di tutta l'app (elenco completo: Ctrl+/)
installGlobalKeys({ nav: (s, id) => nav(s, id), newProject: () => openNuovo(), monta: () => openMonta(), preset: () => nav('preset'),
  toggleTheme: () => setTheme(getTheme() === 'dark' ? 'light' : 'dark') });
const SR = studioRoutes({ app, topbar: (...a) => topbar(...a), nav: (...a) => nav(...a), setTitle: (t) => setTitle(t), setCleanup: (fn) => { cleanup = fn; } });
function setTitle(t) { document.title = t ? t + ' · NoonFrame' : 'NoonFrame'; }

// ----------------------------------------------------------------- PROGETTO DA UN ALTRO PC (.vodcut)
const KIND_ICON = { video: 'film', image: 'frame', audio: 'music', file: 'folder' };
const KIND_NAME = { video: 'Video della live', image: 'Immagine', audio: 'Suono', file: 'File' };
// finestra "ricollega i file" (come CapCut): un file alla volta o tutti insieme da una cartella
export function relinkDialog(pid, missing) {
  return new Promise((resolve) => {
    let miss = missing.slice();
    const bg = h('div', { class: 'modal-bg' });
    const list = h('div', { class: 'rl-list' });
    const note = h('p', { class: 'xs', style: { margin: 0 } });
    const openBtn = h('button', { class: 'btn primary' });
    const close = (v) => { bg.remove(); resolve(v); };
    const sourceMissing = () => miss.some((m) => m.source);
    function draw() {
      list.replaceChildren(...missing.map((m) => {
        const still = miss.some((x) => x.path === m.path);
        return h('div', { class: 'rl-row' + (still ? '' : ' ok') },
          h('span', { class: 'rl-ic' }, icon(still ? KIND_ICON[m.kind] || 'folder' : 'check', 16, still ? 'currentColor' : '#32D74B', 2)),
          h('div', { class: 'rl-tx' }, h('b', null, m.name), h('span', null, (KIND_NAME[m.kind] || 'File') + ' · ' + m.path)),
          still ? h('button', { class: 'btn sm', onclick: () => pickOne(m) }, 'Cerca…') : h('span', { class: 'rl-okt' }, 'Collegato'));
      }));
      note.textContent = miss.length ? `Mancano ${miss.length} file su ${missing.length}.` + (sourceMissing() ? ' Senza il video della live il progetto non si può aprire.' : '') : 'Tutti i file sono collegati.';
      openBtn.textContent = miss.length ? 'Apri comunque' : 'Apri il progetto';
      openBtn.disabled = sourceMissing() ? true : null;
    }
    async function pickOne(m) {
      try {
        const r = await post('/api/pick', { kind: m.kind === 'video' ? 'video' : m.kind === 'image' ? 'relink-image' : m.kind === 'audio' ? 'relink-audio' : 'relink-file' });
        let path = r.path;
        if (r.fallback) path = prompt('Percorso completo del file:', '') || '';
        if (!path) return;
        const j = await post(`/api/p/${pid}/relink`, { old: m.path, new: path });
        miss = j.missing;
        // se nella stessa cartella ci sono anche gli altri file, li collega da solo
        if (miss.length) {
          const dir = path.replace(/[\\/][^\\/]*$/, '');
          try { const k = await post(`/api/p/${pid}/relink-folder`, { folder: dir }); miss = k.missing; } catch (e) { /* */ }
        }
        draw();
      } catch (e) { toast(e.message, true); }
    }
    const folderBtn = h('button', { class: 'btn' });
    const folderIdle = () => folderBtn.replaceChildren(icon('folder', 14), 'Cerca in una cartella…');
    folderIdle();
    folderBtn.addEventListener('click', async () => {
      try {
        const r = await post('/api/pick', { kind: 'folder' });
        if (!r.path) return;
        folderBtn.disabled = true; folderBtn.textContent = 'Cerco…';
        const j = await post(`/api/p/${pid}/relink-folder`, { folder: r.path });
        miss = j.missing;
        toast(j.found ? `Collegati ${j.found} file` : 'In questa cartella non ho trovato i file mancanti', !j.found);
      } catch (e) { toast(e.message, true); }
      folderBtn.disabled = null; folderIdle();
      draw();
    });
    openBtn.addEventListener('click', () => close(true));
    bg.append(h('div', { class: 'modal rl-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'File da ricollegare' },
      h('h2', null, 'Ricollega i file'),
      h('p', null, 'Questo progetto usa file che non si trovano in questo PC. Indica dove sono: se sono nella stessa cartella basta sceglierne uno, oppure cerca in una cartella e NoonFrame li trova tutti.'),
      list, note,
      h('div', { class: 'row', style: { justifyContent: 'space-between' } }, folderBtn,
        h('div', { class: 'row' }, h('button', { class: 'btn ghost', onclick: () => close(false) }, 'Annulla'), openBtn))));
    document.body.append(bg);
    draw();
  });
}
// apre un .vodcut (da percorso o dal file trascinato) e poi, se serve, fa ricollegare i file
// salva il progetto in un file .vodcut (da editor, home e schermata finale)
export async function exportProjectFile(pid, name) {
  try {
    const safe = (name || 'progetto').replace(/[\\/:*?"<>|]+/g, '_');
    const r = await post('/api/pick', { kind: 'project-save:' + safe });
    let path = r.path;
    if (r.fallback) path = prompt('Dove salvo il file? (percorso completo, finisce con .vodcut)', '') || '';
    if (!path) return;
    const j = await post(`/api/p/${pid}/export-project`, { path });
    const nv = j.files.filter((f) => !f.source).length;
    const bg = h('div', { class: 'modal-bg' });
    const close = () => bg.remove();
    bg.append(h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
      h('h2', null, 'Progetto salvato'),
      h('p', null, 'Sull\'altro PC fai doppio clic sul file, oppure in NoonFrame scegli "Apri un progetto da un altro PC".'),
      h('p', { class: 'xs', style: { margin: 0 } }, 'Copia anche il video della live' + (nv ? ` e ${nv} file (immagini e suoni)` : '') + '. Se li metti nella stessa cartella, NoonFrame li trova tutti insieme.'),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
        h('button', { class: 'btn ghost', onclick: () => { post('/api/open', { path: j.path, reveal: true }).catch(() => {}); } }, icon('folder', 14), 'Mostra nella cartella'),
        h('button', { class: 'btn primary', onclick: close }, 'Ok'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  } catch (e) { toast(e.message, true); }
}
async function afterImport(res) {
  const proj = res.project;
  toast('Progetto importato: ' + (proj.name || ''));
  if (res.missing && res.missing.length) { const ok = await relinkDialog(proj.id, res.missing); if (!ok) return nav('home'); }
  openProject(proj, true);
}
export async function importProjectPath(path) {
  try { afterImport(await post('/api/import-project', { path })); } catch (e) { toast(e.message, true); }
}
function importProjectFile(file) {
  const xhr = new XMLHttpRequest();
  xhr.open('PUT', '/api/upload?kind=project&token=' + TOKEN + '&name=' + encodeURIComponent(file.name));
  xhr.onload = () => { let j = {}; try { j = JSON.parse(xhr.responseText); } catch (e) { /* */ } if (xhr.status === 200 && j.project) afterImport(j); else toast(j.error || 'Non riesco ad aprire il progetto', true); };
  xhr.onerror = () => toast('Non riesco ad aprire il progetto', true);
  xhr.send(file);
}
async function pickProjectFile() {
  try {
    const r = await post('/api/pick', { kind: 'project-open' });
    let path = r.path;
    if (r.fallback) path = prompt('Percorso completo del file .vodcut:', '') || '';
    if (path) importProjectPath(path);
  } catch (e) { toast(e.message, true); }
}

async function openProject(p, checked) {
  if (!checked) {
    // file spostati o progetto da un altro PC: prima si ricollegano
    try {
      const miss = await get('/api/p/' + p.id + '/missing');
      if (miss.length && !(await relinkDialog(p.id, miss))) return;
    } catch (e) { /* */ }
  }
  const proj = await get('/api/p/' + p.id);
  // si apre sempre con la funzione con cui l'hai creato: un video di Clip veloci va alle clip anche se poi hai aperto il
  // video lungo (dalla galleria c'e' "Apri il video lungo")
  if (proj.fastClips) return nav('clips', p.id);
  // niente piu' passaggi (webcam, stile): la webcam la trova l'AI da sola, anche quando si sposta
  if (proj.stage && proj.stage !== 'webcam' && proj.stage !== 'style') return nav(proj.stage, p.id);
  // le clip AI (anche quelle di Clip veloci): la galleria, da li' si rifanno o si apre il video lungo
  if (proj.fastClips || proj.clipsRun || (proj.verticals || []).some((v) => v.clip)) return nav('clips', p.id);
  openLong(proj);
}
// il video lungo: l'editor, o (mai preparato) lo stesso percorso automatico della Home fino all'editor
async function openLong(p) {
  const proj = p.stage !== undefined || p.name ? p : await get('/api/p/' + p.id);
  if (proj.stage === 'editor') return nav('editor', proj.id);
  liveImport({ pid: proj.id }, { nav, pickFile: pickLiveFile, whisper: !!ENV.whisper });
}

// ----------------------------------------------------------------- CREDITI E PIANI (21a): abbonamenti e ricariche, pagamento nel foglio
async function screenCredits(tab) {
  setTitle('Crediti e piani');
  app.innerHTML = '';
  app.classList.remove('live-only');
  app.append(appShell('credits', null, plansView({ tab: tab === 'packs' ? 'packs' : 'plans' })));
}

// ----------------------------------------------------------------- PRESET: tutti gli stili (uno per pagina social), "e:<id>" = uno aperto
async function screenPreset(arg) {
  setTitle('Preset');
  const id = String(arg || '').startsWith('e:') ? String(arg).slice(2) : '';
  let root = null;
  if (!id) {
    const page = presetsPage({ edit: (pid) => nav('preset', 'e:' + pid), onSide: () => { if (root && root.repaintSide) root.repaintSide(); } });
    root = appShell('preset', null, page);
    app.innerHTML = '';
    app.classList.remove('live-only');
    app.append(root);
    return;
  }
  const st = await loadLook(true);
  const p = (st.presets || []).find((x) => x.id === id);
  if (!p) return nav('preset');
  const isDef = st.look.preset === id;
  const wrap = h('div', { class: 'pp ps-page' },
    h('button', { type: 'button', class: 'ps-back', onclick: () => nav('preset') }, icon('left', 14, 'currentColor', 2), h('span', null, 'Tutti i preset')));
  app.innerHTML = '';
  app.classList.remove('live-only');
  app.append(appShell('preset', null, wrap));
  try {
    await openStyleWizard({ mount: wrap, preset: id, title: p.name, hideAuto: !isDef,
      lead: isDef ? 'Il preset delle clip nuove: titolo d\'apertura, sottotitoli e badge social.' : 'Titolo d\'apertura, sottotitoli e badge social di questo preset.',
      savedMsg: isDef ? 'Preset salvato: le prossime clip escono così' : 'Preset salvato',
      // un preset che non e' quello predefinito si salva tra i preset, senza cambiare lo stile delle clip nuove
      onFinish: async (look, presets) => {
        const active = isDef ? look : (lookCache() || st).look;
        await post('/api/cliplook', { look: active, presets });
        return { look: active };
      } });
  } catch (e) { toast(e.message, true); }
}

// ----------------------------------------------------------------- PROGETTI (16a): tutti, una cartella ("f:<nome>") o il cestino ("trash")
async function screenProjects(arg) {
  const where = arg === 'trash' ? { trash: true } : typeof arg === 'string' && arg.startsWith('f:') ? { folder: arg.slice(2) } : {};
  setTitle(where.trash ? 'Cestino' : where.folder || 'Progetti');
  let root = null;
  const page = projectsPage({ where, nav, open: (p) => openProject(p), share: exportProjectFile, onSide: () => { if (root && root.repaintSide) root.repaintSide(); } });
  root = shell({ nav, active: where.trash ? 'trash' : where.folder ? 'folder' : 'projects', folder: where.folder || null, cluster: clusterB(), winCtl: winCtl(),
    onPreset: () => nav('preset'), onFolders: () => page.reload() }, page);
  app.innerHTML = '';
  app.classList.remove('live-only');
  app.append(root);
}

// ----------------------------------------------------------------- HOME
// licenza, privacy e componenti di terze parti (la prima volta la licenza va accettata)
const LIC_FILES = [['Licenza', 'LICENZA.txt', 'en/LICENSE.txt'], ['Privacy', 'PRIVACY.txt', 'en/PRIVACY.txt'], ['Componenti di terze parti', 'COMPONENTI-DI-TERZE-PARTI.txt', 'en/THIRD-PARTY-NOTICES.txt']];
function licenseDialog(start, mustAccept) {
  return new Promise((resolve) => {
    let cur = start || 0;
    const body = h('pre', { class: 'lictext' }, 'Carico…');
    const load = async () => {
      body.textContent = 'Carico…';
      try { body.textContent = await (await fetch('/web/licenze/' + LIC_FILES[cur][LANG === 'it' ? 1 : 2])).text(); } catch (e) { body.textContent = 'Non riesco a leggere il file.'; }
      body.scrollTop = 0;
    };
    const tabs = seg(LIC_FILES.map((x) => x[0]), cur, (i) => { cur = i; [...tabs.children].forEach((b, k) => b.setAttribute('aria-pressed', k === i ? 'true' : 'false')); load(); });
    const bg = h('div', { class: 'modal-bg' });
    const close = (ok) => { bg.remove(); resolve(ok); };
    const acts = mustAccept
      ? [h('span', { class: 'xs muted', style: { marginRight: 'auto' } }, 'Per usare NoonFrame serve accettare la licenza.'),
        h('button', { class: 'btn primary', onclick: async () => { try { await post('/api/settings', { licenza: ENV.licenseVer || '1.0' }); } catch (e) { /* */ } close(true); } }, 'Accetto')]
      : [h('button', { class: 'btn primary', onclick: () => close(true) }, 'Chiudi')];
    bg.append(h('div', { class: 'modal licmodal' }, h('h2', null, mustAccept ? 'Benvenuto in NoonFrame' : 'Licenza e informazioni'), tabs, body,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', alignItems: 'center' } }, ...acts)));
    if (!mustAccept) bg.addEventListener('click', (e) => { if (e.target === bg) close(false); });
    document.body.append(bg);
    load();
  });
}

// lingua dell'app: menu a tendina (ogni lingua scritta nella sua lingua)
const LANG_NAMES = [['it', 'Italiano'], ['en', 'English'], ['fr', 'Français'], ['de', 'Deutsch'], ['pt', 'Português'], ['es', 'Español']];
function langPicker() {
  const sel = h('select', { class: 'langsel', 'aria-label': 'Lingua', 'data-notr': '1' },
    ...LANG_NAMES.map(([k, l]) => h('option', { value: k, selected: LANG === k ? true : null }, l)));
  sel.addEventListener('change', () => {
    const k = sel.value;
    try { localStorage.setItem('vodcut.lang', k); } catch (e) { /* */ }
    post('/api/settings', { lang: k }).catch(() => {}).finally(() => location.reload());
  });
  return h('label', { class: 'langpick', 'data-tip': 'Lingua' }, icon('globe', 13), sel);
}

async function screenHome() {
  const my = navSeq;
  setTitle('');
  try { ENV = await get('/api/env'); } catch (e) { /* */ }
  if (stale(my)) return;

  // ---- Clip veloci: link (o file) -> clip verticali pronte
  const link = h('input', { class: 'h8-in', type: 'text', placeholder: 'Incolla un link: le clip arrivano da sole', 'aria-label': 'Link del video o della live' });
  const goClips = () => {
    const raw = link.value.trim();
    if (!raw) { link.focus(); return; }
    if (isLocalPath(raw)) { nav('fastclip', null, { path: localPath(raw) }); return; }   // percorso di un video del computer
    const v = fixLink(raw);
    const bad = linkProblem(v);
    if (bad) {
      inlineError(errBox, bad, [['Incolla di nuovo', 'pri', async () => { try { const t = await navigator.clipboard.readText(); if (t) link.value = t.trim(); } catch (e) { /* */ } errBox.hidden = true; link.focus(); link.select(); }],
        ['Scegli un file', '', () => { errBox.hidden = true; pickForClips(); }]]);
      link.focus(); return;
    }
    nav('fastclip', null, { url: v });
  };
  const errBox = h('div', { class: 'h8-err', hidden: true });
  link.addEventListener('keydown', (e) => { if (e.key === 'Enter') goClips(); });
  link.addEventListener('input', () => { errBox.hidden = true; });
  const pickForClips = async () => {
    try {
      const r = await post('/api/pick', { kind: 'video' });
      const p = r.fallback ? (prompt('Percorso completo del video:', '') || '') : r.path;
      if (p) nav('fastclip', null, { path: p });
    } catch (e) { toast(e.message, true); }
  };
  const field = h('div', { class: 'h8-field', 'data-tour': 'link' },
    icon('link', 18, 'currentColor', 1.6), link,
    h('button', { class: 'h8-up', type: 'button', 'aria-label': 'Scegli un file', 'data-tip': 'Scegli un file dal computer', onclick: pickForClips }, icon('upload', 17, 'currentColor', 1.6)),
    h('button', { class: 'h8-go', type: 'button', onclick: goClips }, 'Crea le clip'));
  field.addEventListener('dragover', (e) => { e.preventDefault(); field.classList.add('over'); });
  field.addEventListener('dragleave', () => field.classList.remove('over'));
  field.addEventListener('drop', async (e) => {
    e.preventDefault(); field.classList.remove('over');
    const f = e.dataTransfer.files[0];
    if (!f) return;
    if (/\.vodcut$/i.test(f.name)) { const real = await droppedPath(f); if (real) importProjectPath(real); else importProjectFile(f); return; }
    const real = await droppedPath(f);
    if (real) { nav('fastclip', null, { path: real }); return; }
    toast(f.size > BIG_DROP ? 'File molto grande: sceglilo con il pulsante, così NoonFrame lo apre senza copiarlo' : 'Scegli il video con il pulsante accanto al campo', true);
  });

  // ---- Dalla live (12a-d): il file della live (o il link Twitch/Kick) -> foglio con l'avanzamento -> editor col suggerimento
  const liveCtx = { nav, pickFile: pickLiveFile, whisper: !!ENV.whisper };
  async function liveFromFile() {
    try { const p = await pickLiveFile(); if (p) liveImport({ file: p }, liveCtx); } catch (e) { toast(e.message, true); }
  }
  function liveFromLink(raw) {
    raw = (raw || '').trim();
    if (!raw) return;
    if (isLocalPath(raw)) { liveImport({ file: localPath(raw) }, liveCtx); return; }
    const url = fixLink(raw), bad = url ? linkProblem(url) : 'Questo non sembra un link: copialo dalla barra degli indirizzi del browser e incollalo qui.';
    if (bad) return toast(bad, true);
    if (!ENV.ytdlp) return toast('Per importare da link serve yt-dlp: riesegui INSTALLA.bat', true);
    liveImport({ url }, liveCtx);
  }
  function liveMenu(anchor) {
    document.querySelectorAll('.h8-pop').forEach((x) => x.remove());
    const inp = h('input', { class: 'input', type: 'text', placeholder: 'twitch.tv/videos/…  ·  kick.com/…', 'aria-label': 'Link della live' });
    const r = anchor.getBoundingClientRect();
    const m = h('div', { class: 'h8-pop', style: { left: Math.max(12, r.left + r.width / 2 - 160) + 'px', top: (r.bottom + 10) + 'px' } },
      h('button', { class: 'nf-pm-it', type: 'button', onclick: () => { m.remove(); liveFromFile(); } }, icon('folder', 16, 'currentColor', 1.6), h('span', { class: 'l' }, 'Scegli il file della live')),
      h('div', { class: 'h8-pop-or' }, 'oppure il link della live'),
      h('div', { class: 'h8-pop-row' }, inp, h('button', { class: 'btn primary sm', type: 'button', onclick: () => { m.remove(); liveFromLink(inp.value); } }, 'Importa')));
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { m.remove(); liveFromLink(inp.value); } });
    document.body.append(m);
    const off = (e) => { if (!m.contains(e.target) && !anchor.contains(e.target)) { m.remove(); document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  }
  // ---- Monta (17a) e Nuovo (17b): fogli in sheets.js
  // icone che si animano al passaggio del mouse (come nel prototipo): onde della live, ciak che batte, più con la scintilla
  const FN_SVG = {
    live: '<circle class="a3" cx="12" cy="12" r="2" fill="currentColor" stroke="none"/><path class="a1" d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 7.8a6 6 0 0 1 0 8.4"/><path class="a2" d="M4.9 4.9a10 10 0 0 0 0 14.2M19.1 4.9a10 10 0 0 1 0 14.2"/>',
    monta: '<g class="a3"><rect x="3" y="10" width="18" height="10" rx="2"/><path d="M3 14h18"/></g><g class="a1"><path d="M3.5 10l1.3-4.5h15.4L18.9 10zM8 5.5L6.8 10M12 5.5L10.8 10M16 5.5L14.8 10"/></g>',
    nuovo: '<path class="a1" d="M12 5v14M5 12h14"/><path class="a2" d="M18 3l.6 1.6L20.2 5.2l-1.6.6L18 7.4l-.6-1.6L15.8 5.2l1.6-.6z" fill="currentColor" stroke="none"/>',
  };
  const fn = (kind, label, onclick) => h('button', { class: 'h8-fn h8-' + kind, type: 'button', onclick: (e) => onclick(e.currentTarget) },
    h('span', { class: 'h8-fi', html: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + FN_SVG[kind] + '</svg>' }),
    h('span', null, label));
  const fns = h('div', { class: 'h8-fns', 'data-tour': 'more' }, fn('live', 'Dalla live', liveMenu), fn('monta', 'Monta', () => openMonta()), fn('nuovo', 'Nuovo', () => openNuovo()));

  // ---- Recenti
  const count = h('span', { class: 'h8-n' });
  // mentre arriva l'elenco: schede segnaposto che si muovono (mai una sezione vuota e ferma)
  const skel = () => h('div', { class: 'pj-rc sk', 'aria-hidden': 'true' }, h('div', { class: 'sk-shot' }), h('span', { class: 'sk-line' }), h('span', { class: 'sk-line short' }));
  const grid = h('div', { class: 'h8-grid', 'aria-busy': 'true' }, ...Array.from({ length: 4 }, skel));
  const recent = h('section', { class: 'h8-recent', 'data-tour': 'projects' }, h('div', { class: 'h8-rh' }, h('b', null, 'Recenti'), count), grid);
  const banner = h('div', { class: 'banner', style: { display: 'none' } });
  const col = h('div', { class: 'h8' }, offerBanner(), banner,
    h('div', { class: 'h8-head' }, h('h1', null, 'Clip veloci'), h('p', null, 'Da una live o da un video lungo alle clip verticali, pronte da pubblicare')),
    field, errBox, fns, recent);
  app.innerHTML = '';
  app.classList.remove('live-only');
  app.append(appShell('home', null, col));
  if (!ENV.ffmpeg) { banner.style.display = ''; banner.textContent = 'Manca ffmpeg: esegui INSTALLA.bat e riapri NoonFrame.'; }
  if (ENV.licenseOk === false && !stale(my)) { if (gating) await gating; if (!stale(my) && ENV.licenseOk === false) await firstRunLicense(); }
  // Recenti: si ridisegnano anche dopo un'azione rapida (sposta, rinomina, cestino) sulla miniatura
  let list = [];
  const emptyEl = h('div', { class: 'h8-empty' }, icon('film', 26, 'currentColor', 1.5), h('span', null, 'Ancora nessun progetto. Incolla un link qui sopra: in pochi minuti hai le prime clip.'));
  const allBtn = h('button', { class: 'h8-all', type: 'button', onclick: () => nav('projects') }, 'Tutti i progetti', icon('right', 14, 'currentColor', 1.8));
  const side = col.closest('.nf-shell');
  async function paintRecent() {
    try { list = await get('/api/projects'); } catch (e) { /* */ }
    if (stale(my)) return false;
    count.textContent = list.length ? String(list.length) : '';
    grid.removeAttribute('aria-busy');
    const acts = (p) => quickActs(p, { list: () => list, share: exportProjectFile, done: () => { paintRecent(); if (side && side.repaintSide) side.repaintSide(true); } });
    grid.replaceChildren(...list.slice(0, 8).map((p) => recentCard(p, (q) => openProject(q), acts(p))));
    grid.style.display = list.length ? '' : 'none';
    if (list.length) { emptyEl.remove(); if (!allBtn.isConnected) recent.append(allBtn); } else { allBtn.remove(); if (!emptyEl.isConnected) recent.append(emptyEl); }
    return true;
  }
  if (!(await paintRecent())) return;
  // tour del primo avvio (dopo la licenza): quando la pagina e il profilo sono al loro posto
  setTimeout(() => { if (!stale(my) && !document.querySelector('.modal-bg, .nfs-bg')) startTour('home'); }, 900);
}
// il file della live dal computer (finestra di Windows; se non si apre, il percorso a mano)
async function pickLiveFile() {
  const r = await post('/api/pick', { kind: 'video' });
  if (r.fallback) return ((await promptBox('Il file della live', 'Incolla il percorso completo del video.', '', 'Apri')) || '').trim();
  return r.path || '';
}
// fogli della Home (anche da tastiera: Ctrl+O e Ctrl+N)
const openMonta = () => montaSheet({ nav });
const openNuovo = () => nuovoSheet({ nav, more: [['image', 'Storia con le tue immagini', () => nav('story')], ['folder', 'Apri un progetto da un altro PC', () => pickProjectFile()]] });
// "Rivedi il tour" dal menu del profilo: si fa in Home
function replayTour() {
  if (!app.querySelector('.h8')) { nav('home'); setTimeout(() => startTour('home', true), 1200); return; }
  startTour('home', true);
}

// ----------------------------------------------------------------- cestino dei progetti (30 giorni)
async function trashDialog(onChange) {
  const bg = h('div', { class: 'modal-bg' });
  let changedAny = false;
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey, true); if (changedAny && onChange) onChange(); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  const body = h('div', { class: 'trash-list' }, h('div', { class: 'muted xs' }, 'Carico…'));
  const emptyBtn = h('button', { class: 'btn danger sm', onclick: async () => {
    if (!(await confirmBox('Svuotare il cestino?', 'I progetti nel cestino spariscono per sempre. I video sul PC restano.', 'Svuota', true))) return;
    try { await post('/api/trash/purge', { all: true }); changedAny = true; load(); } catch (e) { toast(e.message, true); }
  } }, 'Svuota il cestino');
  async function load() {
    let list = [];
    try { list = await get('/api/trash'); } catch (e) { toast(e.message, true); }
    emptyBtn.style.display = list.length ? '' : 'none';
    if (!list.length) { body.replaceChildren(h('div', { class: 'trash-empty' }, icon('trash', 22, 'currentColor', 1.5), h('b', null, 'Il cestino è vuoto'), h('span', null, 'I progetti che elimini restano qui per 30 giorni.'))); return; }
    body.replaceChildren(...list.map((p) => {
      const row = h('div', { class: 'trash-row' },
        h('div', { class: 'trash-shot' }, h('div', { class: 'trash-frame', style: { aspectRatio: (p.aw || 16) + ' / ' + (p.ah || 9) } },
          h('img', { src: `/api/p/${p.id}/cover?token=${TOKEN}`, alt: '', loading: 'lazy', onerror: (e) => e.target.remove() }))),
        h('div', { class: 'trash-info' }, h('b', { 'data-notr': '' }, p.name),
          h('span', { class: 'muted xs' }, p.daysLeft <= 1 ? 'Si elimina per sempre domani' : `Si elimina per sempre tra ${p.daysLeft} giorni`)),
        h('button', { class: 'btn primary sm', onclick: async () => {
          try { await post('/api/trash/restore', { id: p.id }); changedAny = true; toast('Progetto recuperato'); load(); } catch (e) { toast(e.message, true); }
        } }, 'Recupera'),
        h('button', { class: 'iconbtn', 'aria-label': 'Elimina per sempre', 'data-tip': 'Elimina per sempre', onclick: async () => {
          if (!(await confirmBox('Eliminare per sempre?', `"${p.name}" non si potrà più recuperare. I video sul PC restano.`, 'Elimina per sempre', true))) return;
          try { await post('/api/trash/purge', { id: p.id }); changedAny = true; load(); } catch (e) { toast(e.message, true); }
        } }, icon('trash', 15)));
      return row;
    }));
  }
  bg.append(h('div', { class: 'modal trash-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Cestino' },
    h('div', { class: 'trash-head' }, h('h3', null, 'Cestino'), h('span', { class: 'muted xs' }, 'I progetti eliminati restano qui 30 giorni, poi spariscono da soli.')),
    body,
    h('div', { class: 'trash-foot' }, emptyBtn, h('div', { class: 'grow' }), h('button', { class: 'btn', onclick: close }, 'Chiudi'))));
  bg.addEventListener('pointerdown', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  load();
}

// ----------------------------------------------------------------- STORIA CON IMMAGINI
// script a battute -> una immagine per battuta (animata) + la frase a schermo. Tempi dalla voce o dal testo.
const STORY_MOTIONS = [['zoomIn', 'Zoom avanti'], ['zoomOut', 'Zoom indietro'], ['panL', 'Verso sinistra'], ['panR', 'Verso destra'], ['panU', 'Verso l\'alto'], ['panD', 'Verso il basso']];
const STORY_AUTO = ['zoomIn', 'panL', 'zoomOut', 'panU', 'panR', 'zoomIn', 'panD', 'zoomOut'];
const STORY_COLORS = ['#FFFFFF', '#FFD166', '#8FD3FF', '#FFA8B8', '#B9F5A2'];
function toggleEl(on, onChange) {
  const b = h('button', { class: 'toggle', 'aria-pressed': on ? 'true' : 'false', onclick: (e) => { e.preventDefault(); onChange(b.getAttribute('aria-pressed') !== 'true'); } });
  return b;
}
async function screenStory() {
  const my = navSeq;
  setTitle('Storia con immagini');
  // stato del wizard: nome -> script -> immagini -> voce
  const st = { trim: true, captions: 'word', step: 0, name: 'La mia storia', text: '', lines: [], images: [], motions: [], colors: {}, voice: null, check: null, checking: false };
  const STEPS = [['Nome', 'Come si chiama il video'], ['Script', 'Una frase per riga'], ['Immagini', 'Una per ogni frase'], ['Voce', 'Facoltativa']];
  const head = h('div', { class: 'wz-steps' });
  const body = h('div', { class: 'wz-body' });
  const back = h('button', { class: 'btn ghost', onclick: () => go(st.step - 1) }, icon('left', 15), 'Indietro');
  const next = h('button', { class: 'btn primary', onclick: () => go(st.step + 1) }, 'Avanti', icon('chev', 13, 'currentColor', 2.4));
  const foot = h('div', { class: 'wz-foot' }, back, h('div', { class: 'grow' }), next);

  const canGo = (k) => k <= 0 || (k === 1 ? !!st.name.trim() : k === 2 ? st.lines.length > 0 : k === 3 ? st.lines.length > 0 : false);
  function go(k) {
    if (k < 0) return nav('home');
    if (k > 3) return create();
    if (!canGo(k)) return;
    st.step = k; draw();
  }
  function drawHead() {
    head.replaceChildren(...STEPS.map(([t, sub], k) => h('button', { class: 'wz-st' + (k === st.step ? ' on' : k < st.step ? ' done' : ''), disabled: canGo(k) ? null : true, onclick: () => go(k) },
      h('span', { class: 'n' }, k < st.step ? icon('check', 11, '#fff', 3.5) : String(k + 1)), h('span', { class: 't' }, h('b', null, t), h('small', null, sub)))));
  }
  function draw() {
    drawHead();
    back.replaceChildren(icon('left', 15), st.step ? 'Indietro' : 'Annulla');
    if (st.step === 3) next.replaceChildren(icon('sparkle', 15, '#fff'), st.voice ? 'Crea il video' : 'Crea senza voce');
    else next.replaceChildren('Avanti', icon('chev', 13, 'currentColor', 2.4));
    next.disabled = !(st.step === 3 ? st.lines.length && !st.checking : canGo(st.step + 1));
    body.replaceChildren(...[stepName, stepScript, stepImages, stepVoice][st.step]());
  }

  // ---- 1. nome
  function stepName() {
    const inp = h('input', { class: 'input big', value: st.name, placeholder: 'Es. Manifestazione — parte 1' });
    inp.addEventListener('input', () => { st.name = inp.value; next.disabled = !st.name.trim(); drawHead(); });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(1); });
    setTimeout(() => { inp.focus(); inp.select(); }, 30);
    return [h('h2', null, 'Come si chiama?'), h('p', { class: 'wz-p' }, 'È il nome del progetto e del video che esporti. Il video sarà verticale 9:16.'), inp];
  }

  // ---- 2. script
  let parseT = 0;
  async function parse(text) {
    const r = await post('/api/story/parse', { text });
    st.lines = r.lines;
    st.motions = st.lines.map((_, i) => st.motions[i] || STORY_AUTO[i % STORY_AUTO.length]);
    st.images = st.lines.map((_, i) => st.images[i] || null);
    st.lines.forEach((l) => { if (l.speaker && !st.colors[l.speaker]) st.colors[l.speaker] = STORY_COLORS[Object.keys(st.colors).length % STORY_COLORS.length]; });
    st.check = null;
  }
  function stepScript() {
    const ta = h('textarea', { class: 'input wz-script', spellcheck: 'false',
      placeholder: 'Perché quando mi innamoro…\nFinisco sempre per diventare un\'altra persona?\nPerché forse hai imparato che, per essere amata…\n…devi essere esattamente ciò che l\'altra persona vuole.' });
    ta.value = st.text;
    const prev = h('div', { class: 'wz-prev' });
    const paint = () => {
      next.disabled = !st.lines.length; drawHead();
      const sp = [...new Set(st.lines.map((l) => l.speaker).filter(Boolean))];
      prev.replaceChildren(
        h('div', { class: 'wz-prev-h' }, h('b', null, st.lines.length ? st.lines.length + ' frasi = ' + st.lines.length + ' immagini' : 'Anteprima'),
          ...sp.map((k) => h('button', { class: 'st-sp', 'data-tip': 'Colore del testo di ' + k + ' (clic per cambiarlo)', onclick: () => {
            st.colors[k] = STORY_COLORS[(STORY_COLORS.indexOf(st.colors[k]) + 1) % STORY_COLORS.length]; paint(); } }, h('i', { style: { background: st.colors[k] } }), k))),
        st.lines.length ? h('ol', { class: 'wz-lines' }, ...st.lines.map((l, i) => h('li', null, h('span', { class: 'img' }, 'IMG ' + (i + 1)),
          l.speaker ? h('b', { style: { color: st.colors[l.speaker] } }, l.speaker) : null, h('span', null, l.text))))
          : h('div', { class: 'wz-empty' }, 'Scrivi o incolla lo script: ogni riga diventa una frase a schermo con la sua immagine.'));
    };
    ta.addEventListener('input', () => { st.text = ta.value; clearTimeout(parseT); parseT = setTimeout(async () => { await parse(st.text); paint(); }, 200); });
    paint();
    setTimeout(() => ta.focus(), 30);
    return [h('h2', null, 'Scrivi lo script'),
      h('div', { class: 'wz-rules' },
        h('div', null, h('b', null, 'Una frase per riga.'), ' Ogni riga è una frase a schermo e avrà la sua immagine: riga 1 → immagine 1, riga 2 → immagine 2…'),
        h('div', null, h('b', null, 'Personaggi (facoltativo):'), ' scrivi il nome prima della frase, es. ', h('code', null, 'VOLPE: Forse.'), ' — ogni personaggio avrà il suo colore.'),
        h('div', null, 'Va bene anche il formato ', h('code', null, 'BATTUTA 1 — IMG 1'), ' con il nome e la frase sotto.')),
      h('div', { class: 'wz-2col' }, ta, prev)];
  }

  // ---- 3. immagini
  async function uploadImg(file) {
    const r = await fetch('/api/upload?kind=asset&token=' + TOKEN + '&name=' + encodeURIComponent(file.name), { method: 'PUT', body: file });
    const j = await r.json();
    if (!r.ok || j.kind !== 'image') throw new Error(j.error || 'Non è un\'immagine: ' + file.name);
    return j.path;
  }
  function stepImages() {
    const grid = h('div', { class: 'st-slots' });
    const count = h('span', { class: 'wz-count' });
    const paint = () => {
      const n = st.images.filter(Boolean).length;
      count.textContent = n + ' / ' + st.lines.length + ' immagini';
      grid.replaceChildren(...st.lines.map((l, i) => {
        const f = st.images[i];
        const mot = (STORY_MOTIONS.find(([k]) => k === st.motions[i]) || STORY_MOTIONS[0])[1];
        const pic = h('button', { class: 'st-pic', 'data-tip': f ? 'Clic o trascina qui un\'altra immagine' : 'Clic per sceglierla, o trascinala qui', onclick: () => pickOne(i) },
          f ? h('img', { src: mediaUrl(f), alt: '', loading: 'lazy' }) : h('span', { class: 'st-add' }, icon('plus', 20, 'currentColor', 2), h('small', null, 'Scegli o trascina')),
          h('span', { class: 'st-num' }, String(i + 1)),
          f ? h('span', { class: 'st-x', role: 'button', 'aria-label': 'Togli', onclick: (e) => { e.stopPropagation(); st.images[i] = null; paint(); } }, icon('x', 12, '#fff', 2.4)) : null);
        pic.addEventListener('dragover', (e) => { e.preventDefault(); pic.classList.add('over'); });
        pic.addEventListener('dragleave', () => pic.classList.remove('over'));
        pic.addEventListener('drop', async (e) => {
          e.preventDefault(); e.stopPropagation(); pic.classList.remove('over');
          const files = imgFiles(e.dataTransfer);
          if (files.length > 1) return dropMany(files);   // tante immagini: si ordinano da sole col numero nel nome
          if (files[0]) { try { st.images[i] = await uploadImg(files[0]); paint(); } catch (er) { toast(er.message, true); } }
        });
        return h('div', { class: 'st-slot' + (f ? '' : ' empty') }, pic,
          h('div', { class: 'st-line' }, l.speaker ? h('b', { style: { color: st.colors[l.speaker] } }, l.speaker) : null, h('span', null, l.text)),
          h('button', { class: 'st-mot', 'data-tip': 'Clic: cambia movimento', onclick: () => {
            const ids = STORY_MOTIONS.map(([k]) => k); st.motions[i] = ids[(ids.indexOf(st.motions[i]) + 1) % ids.length]; paint();
          } }, icon('sparkle', 11), mot));
      }));
    };
    // tutte le immagini trascinate insieme: caricate e messe al loro posto in base al numero nel nome (1, 2, 3…)
    const numOf = (name) => { const m = name.replace(/\.[^.]+$/, '').match(/\d+/g); return m ? parseInt(m[m.length - 1], 10) : null; };
    async function dropMany(files) {
      files = files.slice().sort((a, b) => (numOf(a.name) ?? 1e9) - (numOf(b.name) ?? 1e9) || a.name.localeCompare(b.name, undefined, { numeric: true }));
      const nums = files.map((f) => numOf(f.name));
      const byNum = nums.every((n) => n != null && n >= 1 && n <= st.lines.length) && new Set(nums).size === nums.length;
      let done = 0;
      dz.classList.add('busy'); dzTxt.textContent = 'Carico le immagini… 0 / ' + files.length;
      const q = files.map((f, k) => ({ f, slot: byNum ? nums[k] - 1 : k }));
      const worker = async () => {
        for (;;) {
          const it = q.shift(); if (!it) return;
          try { const path = await uploadImg(it.f); if (it.slot < st.lines.length) st.images[it.slot] = path; } catch (er) { toast(er.message, true); }
          done++; dzTxt.textContent = 'Carico le immagini… ' + done + ' / ' + files.length; paint();
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
      dz.classList.remove('busy'); dzTxt.textContent = DZ_TXT;
      if (files.length > st.lines.length) toast(`${files.length - st.lines.length} immagini in più rispetto alle frasi: le ho lasciate fuori`);
      paint();
    }
    const imgFiles = (dt) => [...(dt.files || [])].filter((x) => /^image\//.test(x.type) || /\.(png|jpe?g|webp|bmp|gif)$/i.test(x.name));
    const DZ_TXT = 'Trascina qui tutte le immagini insieme: le metto in ordine col numero nel nome (1, 2, 3…)';
    const dzTxt = h('span', null, DZ_TXT);
    const dz = h('div', { class: 'wz-imgdrop' }, icon('upload', 20, 'currentColor', 1.8), dzTxt);
    dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('over'));
    dz.addEventListener('drop', (e) => { e.preventDefault(); dz.classList.remove('over'); const f = imgFiles(e.dataTransfer); if (f.length) dropMany(f); });
    grid.addEventListener('dragover', (e) => e.preventDefault());
    grid.addEventListener('drop', (e) => { e.preventDefault(); const f = imgFiles(e.dataTransfer); if (f.length) dropMany(f); });
    async function useFiles(res) {
      if (!res.files.length) return toast('Nessuna immagine trovata', true);
      st.images = st.lines.map((_, i) => res.match[i] || st.images[i] || null); paint();
    }
    async function pickFolder() {
      try {
        const r = await post('/api/pick', { kind: 'folder' });
        let folder = r.path;
        if (r.fallback) folder = prompt('Percorso completo della cartella con le immagini:', '') || '';
        if (!folder) return;
        useFiles(await post('/api/story/images', { folder, lines: st.lines }));
      } catch (e) { toast(e.message, true); }
    }
    async function pickMany() {
      try {
        const r = await post('/api/pick', { kind: 'media' });
        const files = (r.files || []).filter((f) => f.kind === 'image').map((f) => f.path);
        if (files.length) useFiles(await post('/api/story/images', { files, lines: st.lines }));
      } catch (e) { toast(e.message, true); }
    }
    async function pickOne(i) {
      try {
        const r = await post('/api/pick', { kind: 'media' });
        const f = (r.files || []).find((x) => x.kind === 'image');
        if (!f) return;
        await post('/api/story/images', { files: [f.path] });
        st.images[i] = f.path; paint();
      } catch (e) { toast(e.message, true); }
    }
    paint();
    return [h('h2', null, 'Metti le immagini'),
      h('p', { class: 'wz-p' }, 'Ogni casella è una frase dello script. Trascina tutte le immagini insieme nel riquadro qui sotto (le ordino col numero nel nome), oppure clicca una casella per sceglierne una.'),
      h('div', { class: 'wz-bar' },
        h('button', { class: 'btn primary sm', onclick: pickFolder }, icon('folder', 14, '#fff'), 'Da una cartella numerata'),
        h('button', { class: 'btn sm', onclick: pickMany }, icon('plus', 14), 'Scegli più immagini'),
        h('div', { class: 'grow' }), count),
      dz, grid];
  }

  // ---- 4. voce
  function stepVoice() {
    const box = h('div', { class: 'wz-voice' });
    const paint = () => {
      next.disabled = st.checking;
      next.replaceChildren(icon('sparkle', 15, '#fff'), st.voice ? 'Crea il video' : 'Crea senza voce');
      if (!st.voice) {
        const drop = h('button', { class: 'wz-drop', onclick: pickVoice }, icon('music', 26, 'currentColor', 1.6),
          h('b', null, 'Carica la voce'), h('span', null, 'MP3, WAV, M4A… Clic o trascina qui il file'));
        drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
        drop.addEventListener('dragleave', () => drop.classList.remove('over'));
        drop.addEventListener('drop', async (e) => {
          e.preventDefault(); drop.classList.remove('over');
          const f = e.dataTransfer.files[0]; if (!f) return;
          try {
            const r = await fetch('/api/upload?kind=audio&token=' + TOKEN + '&name=' + encodeURIComponent(f.name), { method: 'PUT', body: f });
            const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Upload non riuscito');
            setVoice(j);
          } catch (er) { toast(er.message, true); }
        });
        box.replaceChildren(drop, h('p', { class: 'wz-p', style: { textAlign: 'center' } }, 'Senza voce i tempi si calcolano dalla lunghezza delle frasi (poi li cambi nell\'editor).'));
        return;
      }
      const vf = h('div', { class: 'st-vf' }, icon('music', 16, '#2DD4BF'), h('span', { 'data-notr': '' }, st.voice.name), h('span', { class: 'xs' }, fmt(st.voice.duration || 0)),
        h('button', { class: 'btn sm ghost', onclick: pickVoice }, 'Cambia'),
        h('button', { class: 'iconbtn', 'aria-label': 'Togli la voce', onclick: () => { st.voice = null; st.check = null; paint(); } }, icon('x', 14)));
      if (st.checking) {
        const bar = h('div', { class: 'progress' }, h('div', { style: { width: Math.round((st.checkProg || 0) * 100) + '%' } }));
        box.replaceChildren(vf, h('div', { class: 'wz-checking' }, h('div', { class: 'spinner' }), h('span', null, st.checkMsg || 'Ascolto la voce e la confronto con lo script…')), bar);
        return;
      }
      const c = st.check;
      if (!c) { box.replaceChildren(vf); return; }
      if (!c.report) { box.replaceChildren(vf, h('div', { class: 'wz-note' }, c.note || '')); return; }
      const bad = c.report.map((r, i) => ({ r, i })).filter(({ r }) => r.missing.length || r.extra.length);
      // durata: con i silenzi o senza
      const trimBox = c.trimDur && c.trimDur < c.dur - 0.5 ? h('div', { class: 'wz-trim' + (st.trim ? ' on' : '') },
        h('div', { class: 'wz-durs' },
          h('div', { class: 'd' + (st.trim ? '' : ' cur') }, h('small', null, 'Voce così com\'è'), h('b', null, fmt(c.dur))),
          icon('chev', 14, 'currentColor', 2.2),
          h('div', { class: 'd' + (st.trim ? ' cur' : '') }, h('small', null, 'Senza silenzi'), h('b', null, fmt(c.trimDur)))),
        h('label', { class: 'wz-tg' }, toggleEl(st.trim, (v) => { st.trim = v; paint(); }), h('span', null, h('b', null, 'Togli i silenzi tra le frasi'),
          h('small', null, `Resta una pausa breve e naturale tra una frase e l'altra · −${fmt(c.dur - c.trimDur)}`)))) : null;
      const summary = bad.length
        ? h('div', { class: 'wz-sum warn' }, icon('info', 16, 'currentColor', 2), h('span', null, h('b', null, bad.length + (bad.length === 1 ? ' frase un po\' diversa' : ' frasi un po\' diverse')), ' dallo script. Le immagini seguono la voce e il testo a schermo sarà quello che si sente davvero (i piccoli errori di ascolto restano come nello script). Qui sotto vedi cosa cambia.'))
        : h('div', { class: 'wz-sum ok' }, icon('check', 16, 'currentColor', 2.6), h('span', null, h('b', null, 'La voce corrisponde allo script.'), ' Ogni immagine durerà quanto la sua frase.'));
      const row = (r, i) => {
        const t = (st.trim && c.timesTrim ? c.timesTrim : c.times)[i];
        return h('div', { class: 'wz-vr' + (r.missing.length || r.extra.length ? ' bad' : '') },
          h('span', { class: 'n' }, String(i + 1)), h('span', { class: 'tm' }, fmt(t[0], 1)),
          h('div', { class: 'tx' }, h('div', null, st.lines[i].text),
            r.missing.length || r.extra.length ? h('div', { class: 'df' },
              r.missing.length ? h('span', { class: 'miss' }, 'Non si sente: ', r.missing.join(' ')) : null,
              r.extra.length ? h('span', { class: 'extra' }, 'Si sente in più: ', r.extra.join(' ')) : null,
              h('span', { class: 'heard' }, 'Nella voce: “' + (r.heard || '—') + '”')) : null));
      };
      const capBox = c.words ? h('div', { class: 'wz-cap' }, h('b', null, 'Testo a schermo'),
        seg(['Parola per parola', 'Frase intera'], st.captions === 'word' ? 0 : 1, (i) => { st.captions = i ? 'line' : 'word'; paint(); }),
        h('small', null, st.captions === 'word' ? 'Ogni parola compare quando viene detta, a tempo con la voce.' : 'La frase intera resta a schermo per tutta l\'immagine.')) : null;
      box.replaceChildren(vf, trimBox, capBox, summary, h('div', { class: 'wz-vlist' }, ...c.report.map(row)));
    };
    async function setVoice(f) {
      // una voce nuova mentre l'altra si sta ancora ascoltando: la vecchia si ferma
      if (st.voiceJob) { post(`/api/jobs/${st.voiceJob}/cancel`).catch(() => {}); st.voiceJob = null; }
      st.voice = f; st.check = null; st.checking = true; st.checkProg = 0; st.checkMsg = ''; paint();
      try {
        const job = await post('/api/story/voice', { voice: f.path, lines: st.lines });
        st.voiceJob = job.id;
        const res = await pollJob(job.id, (j) => { if (st.voiceJob !== job.id) return; st.checkProg = j.progress; st.checkMsg = j.message; if (st.step === 3) paint(); });
        if (st.voiceJob !== job.id) return;   // sostituita da un'altra voce
        st.voiceJob = null;
        if (res.status !== 'done') throw new Error(res.error || 'Non riuscito');
        st.check = res.result;
      } catch (e) { toast(e.message, true); }
      st.checking = false;
      if (st.step === 3) paint();
    }
    async function pickVoice() {
      try { const r = await post('/api/pick', { kind: 'audio' }); const f = (r.files || [])[0]; if (f) setVoice(f); } catch (e) { toast(e.message, true); }
    }
    paint();
    if (st.voice && !st.check && !st.checking) setTimeout(() => setVoice(st.voice), 0);   // lo script e' cambiato: si ricontrolla
    return [h('h2', null, 'Aggiungi la voce'), h('p', { class: 'wz-p' }, 'Con la voce ogni immagine resta a schermo quanto la sua frase. Te la confronto con lo script e ti segnalo le frasi diverse.'), box];
  }

  async function create() {
    const bg = h('div', { class: 'modal-bg' });
    const msg = h('div', { class: 'xs' }, 'Preparo il video…');
    const bar = h('div', { class: 'progress' }, h('div'));
    bg.append(h('div', { class: 'modal' }, h('h2', null, 'Creo la storia'), bar, msg));
    document.body.append(bg);
    try {
      const job = await post('/api/story/create', { name: st.name.trim() || 'Storia', lines: st.lines, images: st.images, motions: st.motions, colors: st.colors,
        voice: st.voice ? st.voice.path : '', times: st.check ? st.check.times : null, format: '9:16',
        trim: !!(st.trim && st.check && st.check.words), words: st.check ? st.check.words : null,
        captions: st.voice && st.check && st.check.words ? st.captions : 'line' });
      const res = await pollJob(job.id, (j) => { bar.firstChild.style.width = Math.round(j.progress * 100) + '%'; if (j.message) msg.textContent = j.message; });
      if (res.status !== 'done') throw new Error(res.error || 'Non riuscito');
      bg.remove(); nav('editor', res.result.project);
    } catch (e) { bg.remove(); toast(e.message, true); }
  }

  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(-1, null, false, { name: 'Storia con immagini', home: true }),
    h('main', { class: 'wizard' }, head, h('div', { class: 'wz-card' }, body, foot)));
  draw();
}

// ----------------------------------------------------------------- WEBCAM
async function findJob(pid, kind) {
  const jobs = await get('/api/jobs');
  return jobs.find((j) => j.pid === pid && j.kind === kind);
}

async function screenWebcam(pid) {
  const my = navSeq;
  let proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  const W = proj.width, H = proj.height;
  let box = proj.webcam && proj.webcam.box ? proj.webcam.box.slice() : null;
  let job = await findJob(pid, 'prepare');
  if (!job && !(proj.analysis && proj.analysis.ready)) job = await post(`/api/p/${pid}/prepare`);

  const stage = h('div', { class: 'stage' });
  const img = h('img', { src: `/api/p/${pid}/frame?token=${TOKEN}&t=${(proj.duration * 0.35).toFixed(1)}`, alt: 'Fotogramma del VOD' });
  stage.append(img);
  const rect = h('div', { class: 'camrect', style: { display: 'none' } },
    h('div', { class: 'h nw', 'data-h': 'nw' }), h('div', { class: 'h ne', 'data-h': 'ne' }),
    h('div', { class: 'h sw', 'data-h': 'sw' }), h('div', { class: 'h se', 'data-h': 'se' }),
    h('div', { class: 'tag' }, 'Webcam'));
  stage.append(rect);

  const title = h('h1', null, 'Cerco la tua webcam…');
  const text = h('p', null, 'Guardo dove compare la tua faccia durante la live.');
  const yes = h('button', { class: 'btn primary big', type: 'button' }, icon('check', 16, '#fff', 2.4), 'Sì, è questa');
  const fix = h('button', { class: 'btn big', type: 'button' }, icon('crop', 15, 'currentColor', 1.8), 'Correggi il riquadro');
  const none = h('button', { class: 'linkish fl-none', type: 'button' }, 'Non uso la webcam');
  const remember = h('input', { type: 'checkbox', checked: true });
  const waiting = h('div', { class: 'row muted small' }, h('div', { class: 'spinner' }), 'Un attimo…');
  const actions = h('div', { style: { display: 'none', flexDirection: 'column', gap: '10px' } }, yes, fix, none,
    h('label', { class: 'fl-remember' }, h('span', { class: 'tg' }, remember, h('i')), h('span', null, 'Ricorda per le prossime live')));
  const fromEd = proj.stage === 'editor';
  // dall'editor: rifaccio solo gli zoom con la webcam giusta (i tagli, anche quelli cambiati a mano, restano)
  const back = async (p) => {
    if (!fromEd) { nav('style', pid); return; }
    const st = p.style || {};
    try {
      await post(`/api/p/${pid}/propose`, { cuts: st.cuts != null ? st.cuts : 1, zooms: st.zooms >= 0 ? st.zooms : 1, zoomScale: p.webcam && p.webcam.box ? ((p.settings && p.settings.zoomLevel) || 2.8) : null, onlyZooms: true });
      toast(p.webcam && p.webcam.box ? 'Webcam salvata: ho rifatto gli zoom sulle reazioni' : 'Senza webcam: gli zoom seguono il viso');
    } catch (e) { toast(e.message, true); }
    nav('editor', pid);
  };

  if (stale(my)) return;
  app.innerHTML = '';
  app.append(flowHeader(proj, 'Webcam'), h('main', { class: 'split fl-main' }, h('div', { class: 'fl-stage' }, stage, h('span', { class: 'fl-at tnum' }, 'fotogramma a ' + fmt(proj.duration * 0.35))),
    h('aside', { class: 'side fl-card' }, h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } }, title, text), waiting, actions)));

  function place() {
    if (!box) return;
    const sw = stage.clientWidth, sh = stage.clientHeight;
    Object.assign(rect.style, { display: 'block', left: (box[0] / W * sw) + 'px', top: (box[1] / H * sh) + 'px', width: (box[2] / W * sw) + 'px', height: (box[3] / H * sh) + 'px' });
  }
  function ready(msgTitle, msgText) {
    waiting.style.display = 'none'; actions.style.display = 'flex';
    title.textContent = msgTitle; text.textContent = msgText;
    place();
  }
  const ro = new ResizeObserver(place); ro.observe(stage);

  // trascina / ridimensiona il riquadro
  let drag = null;
  rect.addEventListener('pointerdown', (e) => {
    e.preventDefault(); rect.setPointerCapture(e.pointerId);
    drag = { mode: e.target.dataset.h || 'move', x: e.clientX, y: e.clientY, box: box.slice() };
  });
  rect.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const sx = W / stage.clientWidth, sy = H / stage.clientHeight;
    const dx = (e.clientX - drag.x) * sx, dy = (e.clientY - drag.y) * sy;
    let [x, y, w, hh] = drag.box;
    if (drag.mode === 'move') { x += dx; y += dy; }
    if (drag.mode.includes('w')) { x += dx; w -= dx; }
    if (drag.mode.includes('e')) { w += dx; }
    if (drag.mode.includes('n')) { y += dy; hh -= dy; }
    if (drag.mode.includes('s')) { hh += dy; }
    w = Math.max(60, w); hh = Math.max(40, hh);
    x = Math.min(Math.max(0, x), W - w); y = Math.min(Math.max(0, y), H - hh);
    box = [Math.round(x), Math.round(y), Math.round(w), Math.round(hh)];
    place();
  });
  rect.addEventListener('pointerup', () => { drag = null; });
  fix.addEventListener('click', () => {
    title.textContent = 'Sistema il riquadro';
    text.textContent = 'Trascina il riquadro sulla webcam e tira gli angoli finché la copre tutta.';
    rect.animate([{ transform: 'scale(1.03)' }, { transform: 'scale(1)' }], { duration: 300 });
  });
  none.addEventListener('click', async () => {
    none.disabled = true;
    proj = await get('/api/p/' + pid);
    proj.webcam = { none: true }; if (!fromEd) proj.stage = 'style';
    await put('/api/p/' + pid, proj); back(proj);
  });
  yes.addEventListener('click', async (e) => {
    e.preventDefault();
    yes.disabled = true;
    proj = await get('/api/p/' + pid);
    proj.webcam = { box, confidence: 1 }; if (!fromEd) proj.stage = 'style';
    await put('/api/p/' + pid, proj);
    if (remember.checked) post('/api/settings', { webcam: { box, size: [W, H] } });
    back(proj);
  });

  let alive = true;
  cleanup = () => { alive = false; ro.disconnect(); };
  // aspetta la webcam
  for (let i = 0; alive; i++) {
    proj = await get('/api/p/' + pid);
    if (proj.webcam && proj.webcam.box) {
      box = proj.webcam.box.slice();
      const conf = proj.webcam.confidence;
      if (proj.webcam.remembered) ready('È questa la tua webcam?', 'È la stessa posizione dell\'ultima volta.');
      else if (conf >= 0.5) ready('È questa la tua webcam?', 'L\'abbiamo trovata da soli. Serve per sapere dove zoomare quando reagisci.');
      else ready('Aiutaci a trovare la webcam', 'Non siamo sicuri: sposta il riquadro sulla webcam e tira gli angoli.');
      break;
    }
    if (proj.webcam && proj.webcam.none) { box = (proj.webcam.guess || [W - W * 0.26, H * 0.01, W * 0.24, W * 0.24 * 9 / 16]).map(Math.round); ready(proj.webcam.guess ? 'Dov\'è la webcam?' : 'Webcam', proj.webcam.guess ? 'Non ero sicuro: sposta il riquadro sulla webcam e tira gli angoli.' : 'Avevi scelto di non usarla. Se c\'è, sistemala qui.'); break; }
    // nessun lavoro in corso (analisi gia' fatta, o il lavoro si e' perso chiudendo l'app): niente attesa infinita
    if (!job) { box = [W - W * 0.26, H * 0.01, W * 0.24, W * 0.24 * 9 / 16].map(Math.round); ready('Dov\'è la webcam?', 'Sposta il riquadro sulla webcam e tira gli angoli, oppure scegli «Non uso la webcam».'); break; }
    if (job) { const j = await get('/api/jobs/' + job.id).catch(() => ({ status: 'gone' })); if (j.status !== 'running') { if (j.error) toast(j.error, true); box = [W - W * 0.26, H * 0.01, W * 0.24, W * 0.24 * 9 / 16].map(Math.round); ready('Dov\'è la webcam?', 'Sposta il riquadro sulla webcam e tira gli angoli.'); break; } }
    await new Promise((r) => setTimeout(r, 500));
  }
}

// ----------------------------------------------------------------- STILE
const CUT_HELP = ['Nessun taglio automatico: il video resta intero, tagli tu nell\'editor.', 'Togliamo solo le pause molto lunghe (oltre 8 secondi).', 'Togliamo le pause oltre 4 secondi, lasciando sempre un po\' di contesto.', 'Ritmo veloce: togliamo quasi ogni pausa oltre 2 secondi.'];
const ZOOM_HELP = ['Nessuno zoom automatico: li aggiungi tu nell\'editor, se vuoi.', 'Solo le reazioni più forti, ben distanziate.', 'Le reazioni forti, con una pausa tra uno zoom e l\'altro.', 'Zoom frequenti su ogni reazione. Stile molto dinamico.'];

async function screenStyle(pid) {
  const my = navSeq;
  let proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  try { ENV = await get('/api/env'); } catch (e) { /* */ }
  let cuts = proj.style ? proj.style.cuts : 1, zooms = proj.style ? proj.style.zooms : 1;
  // quanto ingrandisce ogni zoom (vale per tutti; si ricorda per la prossima volta)
  const ZL = [2, 2.4, 2.8, 3.4, 4];
  let zl = 2.8;
  try { const v = parseFloat(localStorage.getItem('vodcut.zoomLevel')); if (ZL.includes(v)) zl = v; } catch (e) { /* */ }
  if (proj.settings && ZL.includes(proj.settings.zoomLevel)) zl = proj.settings.zoomLevel;
  const hasCam = proj.webcam && proj.webcam.box;
  const t = (proj.duration * 0.35).toFixed(1);
  const prev = h('div', { class: 'zprev' });
  const pimg = h('img', { src: `/api/p/${pid}/frame?token=${TOKEN}&t=${t}`, alt: 'Anteprima dello zoom sulla webcam' });
  prev.append(pimg, h('div', { class: 'chip' }, hasCam ? 'Anteprima zoom' : 'Senza webcam: niente zoom'));
  function layoutPrev() {
    const cw = prev.clientWidth, ch = prev.clientHeight;
    if (!hasCam) { Object.assign(pimg.style, { left: 0, top: 0, width: cw + 'px', height: ch + 'px' }); return; }
    const [rx, ry, rw] = targetRect(proj.width, proj.height, proj.webcam.box, zl);
    const k = cw / rw;
    Object.assign(pimg.style, { width: proj.width * k + 'px', height: proj.height * k + 'px', left: -rx * k + 'px', top: -ry * k + 'px' });
  }
  const ro = new ResizeObserver(layoutPrev); ro.observe(prev);

  const cutHelp = h('div', { class: 'help' }, CUT_HELP[cuts + 1]);
  const zoomHelp = h('div', { class: 'help' }, hasCam ? ZOOM_HELP[zooms + 1]
    : h('span', null, 'Hai scelto "Senza webcam": gli zoom automatici vanno sulla tua faccia, quindi senza il riquadro della webcam restano spenti. ',
      h('button', { class: 'linkish', onclick: () => nav('webcam', pid) }, 'Segna la webcam'), ' per attivarli (in qualsiasi angolo del video).'));
  const cutSeg = h('div');
  const zoomSeg = h('div');
  const zlSeg = h('div');
  // sottotitoli: si chiede prima di partire (la scelta viene ricordata per la prossima volta)
  const hasTr = !!(proj.transcript && proj.transcript.status && proj.transcript.status !== 'none' && proj.transcript.status !== 'error');
  let subs = 1;
  try { const v = localStorage.getItem('vodcut.autoSubs'); if (v !== null) subs = v === '1' ? 0 : 1; else subs = 0; } catch (e) { subs = 0; }
  const SUB_HELP = ['Li preparo mentre lavori: ci vogliono alcuni minuti e puoi già modificare il video.', 'Niente sottotitoli per ora: puoi crearli quando vuoi dalla traccia Testo dell\'editor.'];
  const subHelp = h('div', { class: 'help' }, SUB_HELP[subs]);
  const subSeg = h('div');
  // formato del video finale
  let fmtV = proj.format === '9:16' ? 1 : 0;
  const fmtLocked = !!(proj.analysis && proj.analysis.ready);
  const FMT_HELP = ['Per YouTube: il video resta orizzontale, come la tua live.',
    hasCam ? 'Per TikTok, Shorts e Reels: webcam sopra e gioco sotto. Nelle reazioni la webcam va a tutto schermo.' : 'Per TikTok, Shorts e Reels: tutto il video con lo sfondo sfocato (puoi cambiarlo nell\'editor).'];
  const fmtHelp = h('div', { class: 'help' }, FMT_HELP[fmtV]);
  const fmtSeg = h('div');
  // in verticale: cosa si vede in tutte le clip all'inizio (poi si cambia clip per clip nell'editor)
  const VL = [['split', 'Webcam e gioco'], ['fit', 'Tutto il video'], ['game', 'Solo il gioco'], ['cam', 'Solo webcam'], ['free', 'Libero']];
  let vl = (proj.vert && proj.vert.layout) || (hasCam ? 'split' : 'fit');
  const vlWrap = h('div', { class: 'ctl' });
  function renderSegs() {
    fmtSeg.replaceChildren(seg(['Orizzontale 16:9', 'Verticale 9:16'], fmtV, (i) => { if (fmtLocked) return; fmtV = i; fmtHelp.textContent = FMT_HELP[i]; renderSegs(); }, 'big'));
    // rifacendo l'analisi il formato non cambia: resta quello con cui e' nato il progetto
    if (fmtLocked) fmtSeg.querySelectorAll('button').forEach((b, i) => { if (i !== fmtV) b.disabled = true; });
    vlWrap.style.display = fmtV ? '' : 'none';
    const sg = seg(VL.map((x) => x[1]), VL.findIndex((x) => x[0] === vl), (i) => { vl = VL[i][0]; renderSegs(); }, 'vl4');
    sg.querySelectorAll('button').forEach((b, i) => { if (!hasCam && (VL[i][0] === 'split' || VL[i][0] === 'cam')) b.disabled = true; });
    vlWrap.replaceChildren(h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Cosa si vede'), sg,
      h('div', { class: 'help' }, 'Vale per tutte le clip. Nell\'editor puoi cambiarlo clip per clip.'));
    cutSeg.replaceChildren(seg(['Nessuno', 'Pochi', 'Normali', 'Tanti'], cuts + 1, (i) => { cuts = i - 1; cutHelp.textContent = CUT_HELP[i]; renderSegs(); }, 'big'));
    zoomSeg.replaceChildren(seg(['Nessuno', 'Pochi', 'Normali', 'Tanti'], zooms + 1, (i) => { zooms = i - 1; if (hasCam) zoomHelp.textContent = ZOOM_HELP[i]; renderSegs(); }, 'big'));
    if (!hasCam) zoomSeg.querySelectorAll('button').forEach((b) => { b.disabled = true; });
    zlSeg.replaceChildren(seg(ZL.map((v) => (v + '×').replace('.', ',')), ZL.indexOf(zl), (i) => { zl = ZL[i]; try { localStorage.setItem('vodcut.zoomLevel', String(zl)); } catch (e) { /* */ } layoutPrev(); renderSegs(); }, 'big'));
    if (!hasCam) zlSeg.querySelectorAll('button').forEach((b) => { b.disabled = true; });
    subSeg.replaceChildren(seg(['Sì, creali', 'No, per ora'], subs, (i) => { subs = i; subHelp.textContent = SUB_HELP[i]; try { localStorage.setItem('vodcut.autoSubs', i ? '0' : '1'); } catch (e) { /* */ } renderSegs(); }, 'big'));
  }
  renderSegs();
  const go = h('button', { class: 'btn primary big', disabled: true }, icon('check', 18, '#fff', 2.2), proj.stage === 'editor' ? 'Rifai tagli e zoom' : 'Analizza e apri l\'editor');
  const status = h('div', { class: 'row muted small' }, h('div', { class: 'spinner' }), h('span', null, 'Sto ascoltando l\'audio…'));

  if (stale(my)) return;
  app.innerHTML = '';
  app.append(flowHeader(proj, 'Tagli e zoom'), h('main', { class: 'split fl-main', style: { alignItems: 'flex-start' } },
    h('div', { style: { flexGrow: '1', maxWidth: '760px', display: 'flex', flexDirection: 'column', gap: '14px' } }, prev,
      h('div', { class: 'row muted small' }, icon('info', 18), `Durata del VOD: ${fmt(proj.duration)} · L'analisi richiede pochi secondi.`),
      h('button', { class: 'linkish fl-cam', type: 'button', onclick: () => nav('webcam', pid) }, icon('webcam', 13, 'currentColor', 1.8), h('span', null, hasCam ? 'Cambia il riquadro della webcam' : 'Segna la webcam'))),
    h('aside', { class: 'side fl-card', style: { width: '400px', gap: '22px' } },
      h('h1', null, 'Scegli lo stile'),
      h('div', { class: 'free-note' }, icon('check', 14, 'currentColor', 2.4), h('span', null, 'Tagli e zoom li calcola NoonFrame sul tuo computer: ', h('b', null, 'gratis'), ', senza AI e senza crediti.')),
      h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Formato'), fmtSeg, fmtHelp),
      vlWrap,
      h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Tagli'), cutSeg, cutHelp),
      h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Zoom sulla webcam'), zoomSeg, zoomHelp),
      hasCam ? h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Quanto ingrandire'), zlSeg,
        h('div', { class: 'help' }, 'Vale per tutti gli zoom: lo vedi subito nell\'anteprima. Nell\'editor puoi cambiarli anche tutti insieme.')) : null,
      ENV.whisper && !hasTr ? h('div', { class: 'ctl' }, h('div', { style: { fontSize: '15px', fontWeight: '600' } }, 'Sottotitoli automatici'), subSeg, subHelp) : null,
      status, go)));

  go.addEventListener('click', async () => {
    go.disabled = true;
    if (hasCam && zooms >= 0) { status.style.display = ''; status.lastChild.textContent = 'Controllo che negli zoom si veda la tua faccia…'; }
    try {
      proj = await post(`/api/p/${pid}/propose`, { cuts, zooms, zoomScale: hasCam ? zl : null, format: fmtV ? '9:16' : '16:9', vlayout: fmtV ? vl : null });
      try { localStorage.setItem('nf-live-style', JSON.stringify({ cuts, zooms })); } catch (e) { /* */ }
      if (ENV.whisper && subs === 0 && (!proj.transcript || proj.transcript.status === 'none' || proj.transcript.status === 'error')) {
        post(`/api/p/${pid}/transcribe`).catch(() => {});
      }
      nav('editor', pid);
    } catch (e) { toast(e.message, true); go.disabled = false; status.style.display = 'none'; }
  });

  let alive = true;
  cleanup = () => { alive = false; ro.disconnect(); };
  let job = await findJob(pid, 'prepare');
  if (!job && !(proj.analysis && proj.analysis.ready)) job = await post(`/api/p/${pid}/prepare`);
  while (alive) {
    proj = await get('/api/p/' + pid);
    if (proj.analysis && proj.analysis.ready) { status.style.display = 'none'; go.disabled = false; break; }
    if (job) {
      const j = await get('/api/jobs/' + job.id);
      status.lastChild.textContent = 'Sto ascoltando l\'audio… ' + Math.round(j.progress * 100) + '%';
      if (j.status === 'error') { toast(j.error, true); break; }
    }
    await new Promise((r) => setTimeout(r, 500));
  }
}

// ----------------------------------------------------------------- EDITOR
async function screenEditor(pid) {
  const my = navSeq;
  const proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  try { ENV = await get('/api/env'); } catch (e) { /* */ }
  if (stale(my)) return;
  app.innerHTML = '';
  const right = h('div', { class: 'row eh-right' });
  const undoSlot = h('div', { class: 'eh-undo' });
  const crumb = proj.parent && !proj.timeline ? { parent: proj.parent, parentName: proj.clip ? 'Clip pronte' : proj.parentName, name: proj.name, toClips: !!proj.clip } : { name: proj.timeline ? (proj.parentName || proj.name) : proj.name };
  let edApi = null;
  const tour = (force) => startTour('editor', force, { consented: () => !!(edApi && edApi.consented()), onConsent: () => edApi && edApi.giveConsent() });
  app.append(editorHeader(proj, crumb, right, undoSlot, () => tour(true)));
  const c = await mountEditor(app, proj, { env: ENV, nav, topRight: right, undoSlot, saveProject: exportProjectFile,
    credits: () => (ACCT && ACCT.enabled && ACCT.signedIn ? loadCredits() : Promise.resolve(null)), plans: () => creditsDialog(),
    // il piano gia' noto (letto all'avvio per la foto profilo): l'editor lo usa subito, senza aspettare
    creditsNow: () => (ACCT && ACCT.enabled && ACCT.signedIn ? CREDITS : undefined),
    onReady: (api) => { edApi = api; if (!stale(my) && !document.querySelector('.modal-bg, .nfs-bg')) tour(false); } });
  if (stale(my)) { try { await c(); } catch (e) { /* */ } return; }
  cleanup = c;
}
// intestazione dell'editor (rebrand 14a): indietro, titolo (clic per rinominare, Invio salva) e cosa c'e'; a destra
// scorciatoie, tour, annulla e rifai, lavori in corso, Esporta, feedback, notifiche e profilo
function editorHeader(proj, crumb, right, undoSlot, onTour) {
  const back = crumb.parent
    ? h('button', { class: 'eh-back', type: 'button', 'aria-label': crumb.toClips ? 'Torna alle clip' : 'Torna al video', 'data-tip': crumb.toClips ? 'Torna alle clip' : 'Torna al video orizzontale (non è stato toccato)', onclick: () => nav(crumb.toClips ? 'clips' : 'editor', crumb.parent) }, icon('left', 16, 'currentColor', 2))
    : h('button', { class: 'eh-back', type: 'button', 'aria-label': 'Tutti i progetti', 'data-tip': 'Tutti i progetti', onclick: () => nav('projects') }, icon('left', 16, 'currentColor', 2));
  // proporzione dalle misure vere (i progetti nuovi possono essere 1:1 o 4:5)
  const shape = (w, hh) => { const r = w / hh; return Math.abs(r - 1) < 0.03 ? '1:1' : Math.abs(r - 0.8) < 0.03 ? '4:5' : r >= 1 ? '16:9' : '9:16'; };
  const ratio = proj.format && proj.format !== 'native' ? proj.format : proj.width && proj.height ? shape(proj.width, proj.height) : '';
  const facts = [crumb.parent && proj.parentName ? 'da ' + proj.parentName : '', ratio, proj.duration > 0.5 && proj.kind !== 'blank' ? fmt(proj.duration) : ''].filter(Boolean);
  // il nome si cambia qui, come nel prototipo: clic, scrivi, Invio (o clic fuori) e si salva da solo; Esc lo rimette.
  // E' un campo: il doppio clic non ingrandisce la finestra (i campi non fanno parte della barra da trascinare)
  const target = proj.timeline && proj.parent ? proj.parent : proj.id;   // timeline: il nome e' quello del video
  let saved = crumb.name || '';
  const nameIn = h('input', { class: 'eh-name', type: 'text', value: saved, maxlength: '120', spellcheck: 'false', 'data-notr': '', 'aria-label': 'Nome del video',
    'data-tip': 'Clic per rinominare: si salva da solo ed è il nome del video esportato' });
  const fit = () => { nameIn.size = Math.max(6, Math.min(48, (nameIn.value || '').length + 1)); };
  let busy = null;   // Invio e uscita dal campo arrivano insieme: un solo salvataggio
  const commit = () => busy || (busy = (async () => {
    const nm = nameIn.value.trim();
    if (!nm) { nameIn.value = saved; fit(); return; }
    if (nm === saved) return;
    try {
      await post(`/api/p/${target}/meta`, { name: nm });
      saved = nm;
      if (target === proj.id) proj.name = nm; else proj.parentName = nm;   // il salvataggio automatico dell'editor lo tiene
      setTitle(nm);
      toast('Nome cambiato');
    } catch (e) { toast(e.message, true); nameIn.value = saved; fit(); }
  })().finally(() => { busy = null; }));
  nameIn.addEventListener('keydown', (e) => {
    e.stopPropagation();   // mentre scrivi le scorciatoie dell'editor (spazio, tagli…) non partono
    if (e.key === 'Enter') { e.preventDefault(); commit(); nameIn.blur(); }
    else if (e.key === 'Escape') { e.preventDefault(); nameIn.value = saved; fit(); nameIn.blur(); }
  });
  nameIn.addEventListener('input', fit);
  nameIn.addEventListener('blur', commit);
  fit();
  const title = h('div', { class: 'eh-title' },
    nameIn,
    h('span', { class: 'eh-sub' }, h('i', { class: 'dot' }), h('span', null, 'Salvato in automatico'), ...facts.map((f) => (f.startsWith('da ') ? h('span', null, ' · da ', h('span', { 'data-notr': '' }, f.slice(3))) : h('span', { 'data-notr': '' }, ' · ' + f)))));
  return h('header', { class: 'topbar eh' }, back,
    h('img', { class: 'eh-logo', src: '/web/logo.png', alt: '', draggable: 'false' }),
    title, h('div', { class: 'grow' }),
    h('button', { class: 'eh-ib', type: 'button', 'aria-label': 'Scorciatoie da tastiera', 'data-tip': 'Scorciatoie da tastiera', 'data-key': 'Ctrl+/', onclick: () => shortcutsSheet() }, icon('keyboard', 17, 'currentColor', 1.6)),
    h('button', { class: 'eh-ib', type: 'button', 'aria-label': 'Rivedi il tour dell\'editor', 'data-tip': 'Rivedi il tour dell\'editor', onclick: onTour }, icon('help', 17, 'currentColor', 1.6)),
    h('div', { class: 'eh-sep' }), undoSlot, jobsPill(), right,
    h('div', { class: 'eh-tr' }, updSlot(), feedbackButton(), notifButton(), h('div', { class: 'nf-sep' }), profileButton()),
    winCtl());
}

// ----------------------------------------------------------------- GRAFICA (editor a livelli)
async function screenDesign(gid, extra) {
  const my = navSeq;
  if (stale(my)) return;
  app.innerHTML = '';
  const right = h('div', { class: 'row dz-top' });
  let ed = null;
  const crumb = { name: '…', icon: 'image', onRename: async (el) => {
    if (!ed) return;
    const nm = await promptBox('Rinomina la grafica', 'È anche il nome del file quando la esporti.', ed.api.name, 'Rinomina');
    if (nm && nm.trim()) { await ed.api.rename(nm.trim()); }
    void el;
  } };
  const bar = topbar(-1, right, false, crumb);
  app.append(bar);
  const host = h('div', { class: 'dz-host' });
  app.append(host);
  ed = await mountDesign(host, gid, { topRight: right, onTitle: (t) => { setTitle(t); const n = bar.querySelector('.crumb-name'); if (n) n.textContent = t; }, autoCut: extra && extra.autoCut });
  if (stale(my)) { try { await ed.cleanup(); } catch (e) { /* */ } return; }
  cleanup = () => ed.cleanup();
}

// ----------------------------------------------------------------- ESPORTAZIONE
async function screenExport(pid, want) {
  const my = navSeq;
  const proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  let job = await findJob(pid, 'export');
  if (!job) job = await post(`/api/p/${pid}/export`, want || {});
  const many = !!(want && ((want.vod ? 1 : 0) + (want.verticals || []).length + (want.timelines || []).length > 1));
  const back = (want && want.back) || pid;   // si torna alla timeline da cui hai esportato
  const backTo = want && want.backTo === 'clips' ? 'clips' : 'editor';
  const msg = h('p', { class: 'xs muted', style: { margin: 0, minHeight: '16px' } }, '');
  const pct = h('div', { class: 'xs' }, '0%');
  const bar = h('div', { class: 'progress', role: 'progressbar', 'aria-label': 'Avanzamento', 'aria-valuemin': '0', 'aria-valuemax': '100' }, h('div', { style: { width: '0%' } }));
  const eta = h('p', { class: 'lead', style: { fontSize: '15px' } }, 'Preparo…');
  const steps = [['Audio sistemato', 'audio'], ['Zoom e tagli applicati', 'video'], ['Unisco i pezzi', 'join'], ['Esportazione finale', 'final']];
  const items = steps.map(([label]) => h('div', { class: 'it' }, h('div', { class: 'spinner', style: { visibility: 'hidden' } }), h('span', { style: { flexGrow: '1' } }, label)));
  const cancel = h('button', { class: 'btn ghost' }, 'Annulla');
  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(4), h('main', { class: 'center' }, h('div', { class: 'exportbox' },
    h('img', { src: thumbUrl(pid, Math.min(30, proj.duration / 3), 180), alt: '', style: { width: '320px', height: '180px', objectFit: 'cover', borderRadius: '16px' } }),
    h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px', alignItems: 'center' } }, h('h1', { style: { margin: 0, fontSize: '28px' } }, many ? 'Sto esportando i tuoi video' : 'Sto esportando il tuo video'), eta),
    h('div', { style: { width: '100%', display: 'flex', flexDirection: 'column', gap: '6px' } }, bar, h('div', { style: { display: 'flex', justifyContent: 'space-between', gap: '12px' } }, msg, pct)),
    many ? null : h('div', { class: 'steplist' }, items),
    h('div', { class: 'row' }, cancel, h('button', { class: 'btn', onclick: () => nav(backTo, back) }, 'Continua in secondo piano')),
    h('span', { class: 'muted small', style: { textAlign: 'center' } }, 'Puoi chiudere questa schermata: l\'esportazione continua in secondo piano.'))));

  function mark(i, state) {
    const sp = items[i].firstChild;
    if (state === 'done') sp.replaceWith(icon('check', 20, '#34C759', 2.4));
    else if (state === 'run') sp.style.visibility = 'visible';
  }
  const t0 = Date.now();
  let lastStage = -1;
  cancel.addEventListener('click', async () => {
    if (await confirmBox('Annullare l\'esportazione?', 'Le modifiche restano salvate, puoi esportare di nuovo quando vuoi.', 'Annulla esportazione', true)) {
      await post(`/api/jobs/${job.id}/cancel`); nav(backTo, back);
    }
  });
  let alive = true;
  cleanup = () => { alive = false; };
  const res = await pollJob(job.id, (j) => {
    if (!alive) return;
    const p = j.progress;
    bar.firstChild.style.width = (p * 100).toFixed(1) + '%'; bar.setAttribute('aria-valuenow', Math.round(p * 100));
    pct.textContent = Math.round(p * 100) + '%';
    if (many && j.message) msg.textContent = j.message;
    const el = (Date.now() - t0) / 1000;
    if (p > 0.03) { const left = el / p - el; eta.textContent = left > 90 ? 'Circa ' + Math.round(left / 60) + ' minuti rimanenti' : 'Meno di ' + Math.max(1, Math.ceil(left / 60)) + ' minuto rimanente'; }
    const stage = p < 0.02 ? 0 : p < 0.87 ? 1 : p < 0.93 ? 2 : 3;
    if (!many && stage !== lastStage) { for (let i = 0; i < stage; i++) mark(i, 'done'); mark(stage, 'run'); lastStage = stage; }
  });
  if (!alive) return;
  if (res.status === 'done') nav('done', pid, { back, backTo });
  else if (res.status === 'error') exportFailed(back, res.error || '', () => nav('export', pid, want));
}
// errore dell'export (rebrand 18a): foglio con Riprova e "Copia i dettagli per il supporto" (l'errore vero e'
// anche in NoonFrame/ultimo-errore-export.txt); disco pieno, file spostato o bloccato hanno il loro foglio
function exportFailed(pid, err, retry) {
  const ex = explain(err);
  const msg = ['disk', 'missing', 'locked', 'deleted'].includes(ex.key) ? err : 'Non riesco a esportare il video. Il progetto è salvato e non hai perso niente: riprova, oppure copia i dettagli per il supporto.';
  showSheet(msg, { where: 'Esportazione', details: err, onDismiss: () => nav('editor', pid),
    acts: [['Riprova', 'pri', retry], ['Torna all\'editor', '', null]] });   // senza azione: chiude e passa da onDismiss
}

// ----------------------------------------------------------------- FATTO
async function screenDone(pid, extra) {
  const back = (extra && extra.back) || pid;
  const backTo = extra && extra.backTo === 'clips' ? 'clips' : 'editor';
  const backLabel = backTo === 'clips' ? 'Torna alle clip' : 'Torna all\'editor';
  const my = navSeq;
  const proj = await get('/api/p/' + pid);
  setTitle(proj.name);
  const ex = proj.lastExport;
  if (!ex) return nav(backTo, back);
  const video = h('video', { src: mediaUrl(ex.path), controls: true, style: { width: '100%', height: '100%', background: '#000', borderRadius: '18px' } });
  const openBtn = (label, path, reveal, primary) => h('button', { class: 'btn' + (primary ? ' primary' : ''), onclick: async () => { const r = await post('/api/open', { path, reveal }); if (!r.ok) toast('File non trovato', true); } }, label);
  const extras = [];
  if (ex.srt) extras.push(h('div', { class: 'row small muted' }, icon('text', 16), 'Sottotitoli per YouTube (.srt) ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); post('/api/open', { path: ex.srt, reveal: true }); } }, 'mostra')));
  if (ex.chapters) extras.push(h('div', { class: 'row small muted' }, icon('text', 16), 'Capitoli per la descrizione ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); post('/api/open', { path: ex.chapters }); } }, 'apri')));
  const vert = ex.width && ex.height && ex.height > ex.width;
  const many = ex.files && ex.files.length > 1;
  const sz = (b) => (b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round((b || 0) / 1e6)) + ' MB');
  if (many) {
    // piu' video: la lista, ognuno si apre da solo; la cartella li contiene tutti
    const folder = ex.folder || ex.path;
    if (stale(my)) return;
    app.innerHTML = '';
    app.append(topbar(4, null, true), h('main', { class: 'page', style: { gap: '20px', paddingTop: '32px' } },
      h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' } },
        h('div', { class: 'okc' }, icon('check', 22, '#34C759', 2.6)),
        h('h1', null, `${ex.files.length} video pronti`),
        h('div', { class: 'muted' }, 'Tutti nella stessa cartella' + (ex.files.some((f) => f.vertical) && ex.files.some((f) => !f.vertical) ? ', le verticali in "Clip verticali"' : ''))),
      h('div', { class: 'donelist' }, ...ex.files.map((f) => h('div', { class: 'donerow' },
        h('span', { class: 'dr-ic' + (f.vertical ? ' v' : '') }, icon(f.vertical ? 'phone' : 'film', 16, 'currentColor', 2)),
        h('div', { class: 'dr-tx' }, h('b', { 'data-notr': '' }, f.name), h('span', null, `${fmt(f.duration)} · ${f.width}×${f.height} · ${sz(f.size)}`)),
        h('button', { class: 'btn sm', onclick: () => post('/api/open', { path: f.path, reveal: true }) }, 'Mostra'),
        h('button', { class: 'btn sm primary', onclick: async () => { const r = await post('/api/open', { path: f.path }); if (!r.ok) toast('File non trovato', true); } }, 'Apri')))),
      h('div', { class: 'row' },
        h('button', { class: 'btn', onclick: () => nav(backTo, back) }, backLabel),
        h('button', { class: 'btn primary', onclick: async () => { const r = await post('/api/open', { path: folder, reveal: !ex.folder }); if (!r.ok) toast('Cartella non trovata', true); } }, icon('folder', 14, '#fff'), 'Apri la cartella'))));
    return;
  }
  if (stale(my)) return;
  app.innerHTML = '';
  app.append(topbar(4, null, true), h('main', { class: 'page', style: { gap: '20px', paddingTop: '32px' } },
    h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' } },
      h('div', { class: 'okc' }, icon('check', 22, '#34C759', 2.6)),
      h('h1', null, 'Il tuo video è pronto'),
      h('div', { class: 'muted' }, `${proj.name} · ${fmt(ex.duration)} · ${Math.min(ex.width || ex.height, ex.height)}p` + (ex.fps ? ` · ${Math.round(ex.fps)} fps` : '') + (ex.size ? ` · ${ex.size >= 1e9 ? (ex.size / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.max(1, Math.round(ex.size / 1e6)) + ' MB'}` : '') + ' · pronto per YouTube')),
    h('div', { style: vert ? { height: 'min(62vh, 700px)', aspectRatio: '9/16' } : { width: 'min(860px, 100%)', aspectRatio: '16/9' } }, video),
    h('div', { class: 'row' },
      h('button', { class: 'btn', onclick: () => nav(backTo, back) }, backLabel),
      openBtn('Mostra nella cartella', ex.path, true),
      proj.parent ? null : h('button', { class: 'btn', onclick: () => exportProjectFile(pid, proj.name) }, icon('share', 14), 'Passa a un altro PC'),
      openBtn('Apri il video', ex.path, false, true)),
    extras.length ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px', alignItems: 'center' } }, extras) : null));
  cleanup = () => { video.pause(); video.removeAttribute('src'); video.load(); };
}


// ----------------------------------------------------------------- ACCOUNT
// Accesso con Google (obbligatorio), profilo con ID NoonFrame, nome utente e foto.
// L'accesso compare come finestra sopra l'app; il blocco dell'account resta anche senza internet.
let ACCT = null, PROF = null;
setFeedbackEmail(() => (ACCT && ACCT.signedIn && ACCT.user && ACCT.user.email) || '');   // "Ti rispondiamo su …" nel pannello del feedback
async function loadAccount() { try { ACCT = await get('/api/account'); } catch (e) { ACCT = null; } return ACCT; }
async function loadProfile(fresh = true) {
  try { const r = await get('/api/account/profile?fresh=' + (fresh ? 1 : 0)); PROF = r.profile; ACCT = r.account; } catch (e) { /* offline: resta quello di prima */ }
  paintAccount();
  return PROF;
}
function initial(s) { return (String(s || '?').trim().charAt(0) || '?').toUpperCase(); }
function displayName() { return (PROF && PROF.name) || (ACCT && ACCT.profile && ACCT.profile.name) || (ACCT && ACCT.user && (ACCT.user.name || ACCT.user.email)) || ''; }
function userHandle() { const u = (PROF && PROF.username) || (ACCT && ACCT.profile && ACCT.profile.username); return u ? '@' + u : ''; }
const GOOGLE_PIC = /^https:\/\/lh\d\.googleusercontent\.com\//;
function avatarSrc(size) {
  if (PROF && PROF.photo) return PROF.photo;
  const g = (PROF && PROF.google_avatar) || (ACCT && ACCT.user && ACCT.user.avatar) || '';
  return GOOGLE_PIC.test(g) ? g.replace(/=s\d+-c$/, '=s' + Math.min(512, Math.max(96, size * 2)) + '-c') : '';
}
function avatar(size, cls) {
  const el = h('span', { class: 'av' + (cls ? ' ' + cls : ''), style: { width: size + 'px', height: size + 'px', fontSize: Math.round(size * 0.4) + 'px' } });
  const src = avatarSrc(size);
  if (src) {
    const img = h('img', { src, alt: '', referrerpolicy: 'no-referrer', draggable: 'false' });
    img.addEventListener('error', () => img.replaceWith(h('span', { 'data-notr': '' }, initial(displayName()))));
    el.append(img);
  } else el.append(h('span', { 'data-notr': '' }, initial(displayName())));
  return el;
}
function fmtNoonFrameId(n) { const s = String(n || ''); return s.length === 8 ? s.slice(0, 4) + ' ' + s.slice(4) : s; }
function paintAccount() {
  document.querySelectorAll('.nf-mewrap').forEach((w) => w._paint && w._paint());
  document.querySelectorAll('.acct-btn').forEach((b) => {
    const inn = !!(ACCT && ACCT.signedIn);
    b.hidden = !(ACCT && ACCT.enabled);
    b.classList.toggle('in', inn);
    b.replaceChildren(inn ? avatar(28) : h('span', { class: 'acct-in' }, 'Accedi'));
  });
}

function accountButton() {
  const b = h('button', { class: 'acct-btn', 'aria-label': 'Account', 'data-tip': 'Il tuo profilo', hidden: true });
  b.addEventListener('click', () => (ACCT && ACCT.signedIn ? accountMenu(b) : gate()));
  markOffer(b);
  setTimeout(() => { if (ACCT) paintAccount(); else loadAccount().then(paintAccount); }, 0);
  return b;
}

function accountMenu(anchor) {
  document.querySelectorAll('.acct-menu').forEach((m) => m.remove());
  const r = anchor.getBoundingClientRect();
  const close = () => { m.remove(); document.removeEventListener('pointerdown', off, true); };
  const m = h('div', { class: 'acct-menu', style: { top: (r.bottom + 8) + 'px', right: Math.max(8, innerWidth - r.right) + 'px' } },
    h('button', { class: 'acct-who', onclick: () => { close(); nav('profile'); } }, avatar(42),
      h('div', null, h('b', { 'data-notr': '' }, displayName()), h('small', { 'data-notr': '' }, userHandle() || (ACCT.user && ACCT.user.email) || ''))),
    walletCard(() => close()),
    h('button', { class: 'acct-item', onclick: () => { close(); nav('profile'); } }, icon('user', 15), 'Il mio profilo'),
    h('button', { class: 'acct-item', onclick: () => { close(); nav('aiformats'); } }, icon('library', 15),
      h('span', { class: 'acct-it' }, h('span', null, 'Reference'), h('small', null, 'Video e immagini da cui l\'AI impara'))),
    h('button', { class: 'acct-item', onclick: async () => { close(); await signOut(); } }, icon('logout', 15), 'Esci'));
  document.body.append(m);
  const off = (e) => { if (!m.contains(e.target) && !anchor.contains(e.target)) close(); };
  setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
}

// ---- rebrand: profilo in alto a destra (avatar con l'anello dei crediti) e il suo menu
let CREDITS = null;   // { balance, frac, paid, offer }: dal catalogo dei crediti del server
async function loadCredits() {
  try {
    const c = await loadCatalog(true);
    if (!c || !c.signedIn) { CREDITS = null; return null; }
    const plans = (c.catalog || {}).plans || [];
    const pl = plans.find((p) => p.id === c.plan);
    const paid = !!(c.plan && c.plan !== 'free');
    // abbonati: crediti del mese rimasti; gratis: saldo rispetto ai 120 crediti di benvenuto (pieno se ne ha di piu')
    const frac = paid && pl && pl.monthly ? (c.monthly || 0) / pl.monthly : (c.balance || 0) / Math.max(c.balance || 0, 120);
    const offer = ((c.catalog || {}).offers || [])[0] || null;
    CREDITS = { balance: c.balance || 0, frac: Math.max(0, Math.min(1, frac || 0)), paid, offer, pct: offerPct(offer, (c.catalog || {}).packs) };
  } catch (e) { CREDITS = null; }
  return CREDITS;
}
// sconto dell'offerta in percentuale, come nel prototipo ("−30%"): sui piani rispetto al prezzo pieno, sulle ricariche
// rispetto al prezzo al credito della ricarica normale piu' vicina
function offerPct(o, packs) {
  if (!o || !(o.price > 0)) return 0;
  let full = 0;
  if (o.kind !== 'pack' && o.fullPrice) full = o.fullPrice;
  else if (o.credits) {
    const ps = (packs || []).filter((p) => p.credits > 0 && p.price > 0).sort((a, b) => a.credits - b.credits);
    const ref = [...ps].reverse().find((p) => p.credits <= o.credits) || ps[0];
    if (ref) full = ref.price / ref.credits * o.credits;
  }
  const pct = full > 0 ? Math.round((1 - o.price / full) * 100) : 0;
  return pct >= 5 && pct < 100 ? pct : 0;
}
function ringSvg(frac) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 40 40');
  s.innerHTML = '<circle cx="20" cy="20" r="18" fill="none" stroke="var(--glass2)" stroke-width="2.5"></circle>'
    + `<circle cx="20" cy="20" r="18" fill="none" stroke="var(--ac)" stroke-width="2.5" stroke-linecap="round" stroke-dasharray="113.1" stroke-dashoffset="${(113.1 * (1 - (frac || 0))).toFixed(1)}"></circle>`;
  return s;
}
function profileButton() {
  const wrap = h('div', { class: 'nf-mewrap' });
  let hov = null;
  wrap._paint = () => {
    if (!(ACCT && ACCT.enabled)) { wrap.replaceChildren(); return; }
    if (!ACCT.signedIn) { wrap.replaceChildren(h('button', { class: 'nf-login', type: 'button', onclick: () => gate() }, 'Accedi')); return; }
    const b = h('button', { class: 'nf-me', type: 'button', 'aria-label': 'Il tuo profilo', 'data-tour': 'me' },
      h('div', { class: 'nf-ring' }, ringSvg(CREDITS ? CREDITS.frac : 0), avatar(30)));
    b.addEventListener('click', () => (document.querySelector('.nf-pmenu') ? closeProfileMenu() : profileMenu(b)));
    b.addEventListener('pointerenter', () => { clearTimeout(hov); hov = setTimeout(() => { if (!document.querySelector('.nf-pmenu')) profileMenu(b); }, 120); });
    b.addEventListener('pointerleave', () => { clearTimeout(hov); hov = setTimeout(() => { const m = document.querySelector('.nf-pmenu'); if (m && !m.matches(':hover')) closeProfileMenu(); }, 220); });
    markOffer(b);
    wrap.replaceChildren(b);
  };
  setTimeout(async () => { if (!ACCT) await loadAccount(); wrap._paint(); if (ACCT && ACCT.signedIn) { await loadCredits(); wrap._paint(); } }, 0);
  return wrap;
}
function closeProfileMenu() {
  document.querySelectorAll('.nf-pmenu').forEach((m) => { if (m._off) m._off(); m.remove(); });
  document.querySelectorAll('.nf-me.on').forEach((b) => b.classList.remove('on'));
}
function profileMenu(anchor) {
  closeProfileMenu();
  popOpened('profile');
  anchor.classList.add('on');
  const r = anchor.getBoundingClientRect();
  const m = h('div', { class: 'nf-pmenu', role: 'menu', style: { top: (r.bottom + 10) + 'px', right: Math.max(8, innerWidth - r.right) + 'px' } });
  const close = closeProfileMenu;
  const it = (ic, label, right, fn, cls) => h('button', { class: 'nf-pm-it' + (cls ? ' ' + cls : ''), type: 'button', role: 'menuitem', onclick: () => { close(); fn(); } },
    icon(ic, 16, 'currentColor', 1.6), h('span', { class: 'l' }, label), right ? h('span', { class: 'r', 'data-notr': '' }, right) : null);
  const theme = getTheme();
  const seg = h('span', { class: 'nf-themeseg' },
    h('button', { type: 'button', class: theme === 'dark' ? 'on' : '', 'aria-label': 'Tema scuro', 'data-tip': 'Tema scuro', onclick: (e) => { e.stopPropagation(); setTheme('dark'); seg.children[0].classList.add('on'); seg.children[1].classList.remove('on'); } }, icon('moon', 14, 'currentColor', 1.7)),
    h('button', { type: 'button', class: theme === 'light' ? 'on' : '', 'aria-label': 'Tema chiaro', 'data-tip': 'Tema chiaro', onclick: (e) => { e.stopPropagation(); setTheme('light'); seg.children[1].classList.add('on'); seg.children[0].classList.remove('on'); } }, icon('sun', 14, 'currentColor', 1.7)));
  const list = h('div', { class: 'nf-pm-list' });
  const langName = (LANG_NAMES.find(([k]) => k === LANG) || [LANG, LANG])[0].toUpperCase();
  // come nel prototipo: Account, Lingua, Privacy, Aggiornamenti; poi, piu' tenui, Scorciatoie e Rivedi il tour; in fondo Esci
  const showMain = () => list.replaceChildren(...[
    it('user', 'Account', '', () => nav('profile')),
    h('button', { class: 'nf-pm-it', type: 'button', onclick: (e) => { e.stopPropagation(); showLangs(); } }, icon('globe', 16, 'currentColor', 1.6), h('span', { class: 'l' }, 'Lingua'), h('span', { class: 'r', 'data-notr': '' }, langName)),
    it('shield', 'Privacy', '', () => licenseDialog(1)),
    h('button', { class: 'nf-pm-it', type: 'button', onclick: (e) => { checkUpdatesNow(e.currentTarget); } }, icon('update', 16, 'currentColor', 1.6), h('span', { class: 'l' }, 'Aggiornamenti'), h('span', { class: 'r', 'data-notr': '' }, ENV.version || '')),
    // versioni beta: solo per gli account invitati dall'admin (prima era nel piè di pagina della Home)
    ENV.beta || ENV.channel === 'beta' ? it('bolt', ENV.channel === 'beta' ? 'Beta attiva' : 'Versioni beta', '', () => betaDialog()) : null,
    it('keyboard', 'Scorciatoie da tastiera', IS_MAC ? '⌘ /' : 'Ctrl /', () => shortcutsSheet(), 'dim'),
    it('tour', 'Rivedi il tour', '', () => replayTour(), 'dim'),
    h('div', { class: 'nf-pm-sep' }),
    it('logout', 'Esci', '', () => signOut(), 'dim')].filter(Boolean));
  const showLangs = () => list.replaceChildren(
    h('button', { class: 'nf-pm-it dim', type: 'button', onclick: (e) => { e.stopPropagation(); showMain(); } }, icon('left', 16, 'currentColor', 1.6), h('span', { class: 'l' }, 'Lingua')),
    ...LANG_NAMES.map(([k, l]) => h('button', { class: 'nf-pm-it', type: 'button', 'data-notr': '1', onclick: () => {
      try { localStorage.setItem('vodcut.lang', k); } catch (e) { /* */ }
      post('/api/settings', { lang: k }).catch(() => {}).finally(() => location.reload());
    } }, LANG === k ? icon('check', 16, 'var(--ac)', 2) : h('span', { style: { width: '16px' } }), h('span', { class: 'l' }, l))));
  showMain();
  const cr = CREDITS;
  m.append(
    h('div', { class: 'nf-pm-who' }, avatar(40),
      h('div', { class: 'nf-pm-nm' }, h('b', { 'data-notr': '' }, displayName()), cr && cr.paid ? h('span', { class: 'nf-pro' }, 'PRO') : null),
      seg),
    cr ? h('button', { class: 'nf-pm-cr', type: 'button', onclick: () => { close(); creditsDialog(); } },
      h('div', { class: 'nf-ring' }, ringSvg(cr.frac), h('b', { 'data-notr': '' }, String(cr.balance))),
      h('span', { class: 'lbl' }, 'Crediti'),
      cr.pct ? h('span', { class: 'nf-pm-off tnum' }, '−' + cr.pct + '%')
        : cr.offer && cr.offer.badge ? h('span', { class: 'nf-pm-off', 'data-notr': '' }, cr.offer.badge) : null,
      icon('right', 14, 'var(--t3)', 1.8)) : null,
    list);
  document.body.append(m);
  m.addEventListener('pointerleave', () => setTimeout(() => { if (!m.matches(':hover') && !anchor.matches(':hover')) close(); }, 220));
  const off = (e) => { if (!m.contains(e.target) && !anchor.contains(e.target)) close(); };
  const offPop = onPopOpened('profile', close);
  setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  m._off = () => { document.removeEventListener('pointerdown', off, true); offPop(); };
}
// "Apri" sulla pillola dei lavori finiti: la schermata giusta per ogni lavoro
setJobOpener(async (j) => {
  const res = j.result || {};
  if (j.kind === 'export' && (res.folder || res.path)) { post('/api/open', { path: res.folder || res.path, reveal: !res.folder }).catch(() => {}); return; }
  const pid = (j.kind === 'download' && res.project) || j.pid;
  if (!pid) return;
  if (/^clip/.test(j.kind)) { nav('clips', pid.split('_')[0]); return; }
  try { const p = (await get('/api/projects')).find((x) => x.id === pid); if (p) { openProject(p); return; } } catch (e) { /* */ }
  nav('editor', pid);
});
// gruppo in alto a destra delle schermate col guscio (layout B)
function clusterB() {
  const fb = feedbackButton();
  return [updSlot(), jobsPill(), fb, notifButton(), h('div', { class: 'nf-sep' }), profileButton()];
}
// guscio rebrand per le schermate (tutte tranne editor): barra laterale + contenuto
function appShell(active, folder, ...content) {
  return shell({ nav, active, folder, cluster: clusterB(), winCtl: winCtl(), onPreset: () => nav('preset') }, ...content);
}

// beta tester: l'AI puo' usare le proprie chiavi API invece dei crediti NoonFrame (le chiavi restano sul computer, cifrate)
function keysSwitch(closeMenu) {
  let own = null, busy = false;
  const sw = h('span', { class: 'aie-tsw', 'aria-hidden': 'true' }, h('i'));
  const sub = h('small', null, '…');
  const manage = h('button', { class: 'linkish acct-keys-go', hidden: true, onclick: (e) => { e.stopPropagation(); closeMenu(); SR.keysOpen(); } }, 'Gestisci le chiavi');
  const row = h('button', { class: 'acct-item acct-sw', role: 'switch', 'aria-checked': 'false', disabled: true, onclick: () => toggle() },
    icon('key', 15), h('span', { class: 'acct-it' }, h('span', null, 'Usa le mie chiavi API'), sub), sw);
  const paint = () => {
    sw.classList.toggle('on', !!own);
    row.setAttribute('aria-checked', own ? 'true' : 'false');
    row.disabled = own === null || busy;
    sub.textContent = own === null ? '…' : own ? 'L\'AI usa le tue chiavi, non i crediti' : 'L\'AI usa i crediti NoonFrame';
    manage.hidden = !own;
  };
  async function toggle() {
    if (busy || own === null) return;
    busy = true; paint();
    try {
      const r = await post('/api/ai/credits', { on: !!own });   // on = crediti accesi
      own = !r.credits.on;
      const anyKey = Object.values(r.keys || {}).some((k) => k && k.set);
      if (own && !anyKey) { toast('Collega almeno una chiave: testi, immagini e voce'); closeMenu(); SR.keysOpen(); }
      else toast(own ? 'L\'AI ora usa le tue chiavi API' : 'L\'AI ora usa i crediti NoonFrame');
    } catch (e) { toast(e.message, true); }
    busy = false; paint();
  }
  get('/api/ai/wallet').then((c) => { own = !(c && c.on); paint(); }).catch(() => { row.remove(); manage.remove(); });
  paint();
  return h('div', { class: 'acct-swbox' }, row, manage);
}

async function signOut() {
  try { await post('/api/account/logout', {}); } catch (e) { /* */ }
  ACCT = null; PROF = null;
  await loadAccount(); paintAccount();
  nav('home');
  gate();
}

async function deleteAccountDialog() {
  const ok = await confirmBox('Eliminare l\'account?', 'Cancelliamo il tuo account, la foto, i dispositivi e le segnalazioni che hai mandato. I progetti e i video sul computer restano. Non si può annullare.', 'Elimina account', true);
  if (!ok) return;
  try { await post('/api/account/delete', {}); ACCT = null; PROF = null; await loadAccount(); toast('Account eliminato'); nav('home'); gate(); }
  catch (e) { toast(e.message, true); }
}

const GOOGLE_G = () => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 48 48'); s.setAttribute('width', '18'); s.setAttribute('height', '18');
  s.innerHTML = '<path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 38.9 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/>';
  return s; };

// ---- finestra di accesso, sopra l'app (che resta visibile, sfocata, e non si tocca finche' non si entra)
let AUTH = null;   // finestra aperta
function authShell(dismissable) {
  if (AUTH) AUTH.close(false);
  const card = h('div', { class: 'auth', role: 'dialog', 'aria-modal': 'true' });
  const bg = h('div', { class: 'auth-bg' }, h('div', { class: 'auth-glow' }), card);
  app.inert = true;
  let resolve;
  const done = new Promise((r) => { resolve = r; });
  const onKey = (e) => { if (e.key === 'Escape' && dismissable) { e.stopPropagation(); shell.close(false); } };
  document.addEventListener('keydown', onKey, true);
  const shell = {
    card, done,
    close(v) {
      if (AUTH !== shell) return;
      AUTH = null; document.removeEventListener('keydown', onKey, true);
      bg.classList.add('out'); app.inert = false;
      setTimeout(() => bg.remove(), 220);
      resolve(v);
    },
    show(...kids) {
      card.classList.remove('in'); void card.offsetWidth;
      card.replaceChildren(...kids.filter(Boolean)); card.classList.add('in');
      const f = card.querySelector('[autofocus]'); if (f) setTimeout(() => f.focus(), 60);
    },
  };
  AUTH = shell;
  document.body.append(bg);
  requestAnimationFrame(() => bg.classList.add('on'));
  return shell;
}
function authMark(busy) {
  return h('div', { class: 'auth-mark' + (busy ? ' busy' : '') }, h('img', { src: '/web/app-icon.png', alt: '', draggable: 'false' }));
}
// in basso nelle schermate di accesso: versione e lingua (clic per cambiarla)
function authFoot() {
  const lang = (LANG_NAMES.find(([k]) => k === LANG) || ['', ''])[1];
  const sel = h('select', { class: 'auth-lang', 'aria-label': 'Lingua', 'data-notr': '1' }, ...LANG_NAMES.map(([k, l]) => h('option', { value: k, selected: LANG === k ? true : null }, l)));
  sel.addEventListener('change', () => { try { localStorage.setItem('vodcut.lang', sel.value); } catch (e) { /* */ } post('/api/settings', { lang: sel.value }).catch(() => {}).finally(() => location.reload()); });
  const ver = h('span', { 'data-notr': '' }, 'NoonFrame ' + (ENV.version || ''));
  if (!ENV.version) get('/api/env').then((e) => { ENV = { ...ENV, ...e }; ver.textContent = 'NoonFrame ' + (e.version || ''); }).catch(() => {});
  return h('div', { class: 'auth-foot' }, ver, h('span', null, '·'),
    h('label', { class: 'auth-langw', 'data-tip': lang }, icon('globe', 12, 'currentColor', 1.6), sel));
}
// rebrand 10c: al primo avvio licenza e privacy in quattro punti chiari, "Accetto e continua" (il pulsante e' il consenso)
function firstRunLicense() {
  return new Promise((resolve) => {
    const shell = authShell(false);
    const P = [
      ['laptop', 'I video restano sul tuo computer', 'Progetti ed esportazioni non passano dai nostri server.'],
      ['user', 'Salviamo solo l\'account', 'Email, nome, foto e i computer da cui accedi, per riconoscerti.'],
      ['card', 'Crediti e piani sono personali', 'Non si rivendono né si condividono. Le ricariche non scadono.'],
      ['trash', 'Puoi cancellare tutto quando vuoi', 'Da Account, "Elimina account" rimuove subito ogni dato.']];
    const go = h('button', { class: 'btn primary big auth-wide', autofocus: true, onclick: async () => {
      go.disabled = true;
      try { await post('/api/settings', { licenza: ENV.licenseVer || '1.0' }); } catch (e) { /* */ }
      ENV.licenseOk = true;
      shell.close(true); resolve(true);
    } }, 'Accetto e continua');
    const first = (displayName() || '').split(' ')[0];
    shell.card.classList.add('wide');
    shell.show(ACCT && ACCT.signedIn ? h('div', { class: 'auth-me' }, avatar(64), h('span', { class: 'ok' }, icon('check', 11, '#fff', 3))) : h('img', { class: 'auth-logo', src: '/web/logo.png', alt: '', draggable: 'false' }),
      h('h1', null, first ? 'Ciao ' + first + ', un\'ultima cosa' : 'Un\'ultima cosa'),
      h('p', { class: 'auth-sub' }, 'Prima di iniziare, come funziona NoonFrame in quattro punti.'),
      h('div', { class: 'auth-points' }, ...P.map(([ic, t, x]) => h('div', { class: 'pt' }, h('span', { class: 'ic' }, icon(ic, 16, 'currentColor', 1.6)), h('span', { class: 'tx' }, h('b', null, t), h('span', null, x))))),
      go,
      h('div', { class: 'auth-links sm' },
        h('button', { class: 'linkish', onclick: () => licenseDialog(0) }, icon('file', 12, 'currentColor', 1.8), h('span', null, 'Licenza completa')),
        h('span', { class: 'auth-dot' }, '·'),
        h('button', { class: 'linkish', onclick: () => licenseDialog(1) }, icon('shield', 12, 'currentColor', 1.8), h('span', null, 'Privacy')),
        h('span', { class: 'auth-dot' }, '·'),
        h('span', null, 'Versione ', h('span', { 'data-notr': '' }, ENV.licenseVer || '1.0'))));
  });
}
function legalLine() {
  return h('p', { class: 'auth-legal' }, 'Continuando accetti i ', h('button', { class: 'linkish', onclick: () => licenseDialog(0) }, 'Termini'),
    ' e la ', h('button', { class: 'linkish', onclick: () => licenseDialog(1) }, 'Privacy'), '.');
}

function signInFlow(shell, dismissable) {
  let poll = null;
  const stop = () => clearInterval(poll);
  const err = h('p', { class: 'auth-err', role: 'alert' });
  const start = async (btn) => {
    btn.disabled = true; err.textContent = '';
    try { await post('/api/account/google', {}); waiting(); }
    catch (e) { btn.disabled = false; err.textContent = e.message; }
  };
  // rebrand 10a: un pulsante solo; licenza e privacy si accettano dopo, in quattro punti (10c)
  const welcome = () => {
    stop();
    const g = h('button', { class: 'auth-google', autofocus: true, onclick: () => start(g) }, GOOGLE_G(), h('span', null, 'Continua con Google'));
    shell.show(h('img', { class: 'auth-logo', src: '/web/logo.png', alt: '', draggable: 'false' }),
      h('h1', null, 'Benvenuto in NoonFrame'),
      h('p', { class: 'auth-sub' }, 'Accedi per salvare progetti e crediti su tutti i tuoi computer.'),
      g, err,
      h('p', { class: 'auth-hint' }, icon('external', 12, 'currentColor', 1.8), h('span', null, 'Si apre il browser, poi torni qui da solo')),
      dismissable ? h('button', { class: 'linkish auth-skip', onclick: () => shell.close(false) }, 'Non ora') : null,
      authFoot());
  };
  // 10b: in attesa del browser
  const waiting = () => {
    shell.show(h('div', { class: 'auth-wait' }, h('i'), h('img', { src: '/web/logo.png', alt: '', draggable: 'false' })),
      h('h1', null, 'Completa l\'accesso nel browser'),
      h('p', { class: 'auth-sub' }, 'Quando hai finito, torni qui da solo.'),
      err,
      h('div', { class: 'auth-links' },
        h('button', { class: 'linkish', onclick: () => post('/api/account/google', {}).catch((e) => { err.textContent = e.message; }) }, icon('external', 13, 'currentColor', 1.8), h('span', null, 'Riapri il browser')),
        h('span', { class: 'auth-dot' }, '·'),
        h('button', { class: 'linkish', onclick: welcome }, 'Annulla')),
      authFoot());
    stop();
    poll = setInterval(async () => {
      if (AUTH !== shell) return stop();
      const a = await loadAccount();
      if (a && a.signedIn) { stop(); paintAccount(); afterSignIn(shell); }
    }, 1200);
  };
  welcome();
}

async function afterSignIn(shell) {
  shell.show(authMark(true), h('h1', null, 'Ci siamo quasi'), h('p', { class: 'auth-sub' }, 'Prepariamo il tuo profilo…'));
  try { ACCT = await post('/api/account/refresh', {}); } catch (e) { /* senza internet: si controlla dopo */ }
  const a = ACCT;
  if (a && a.blocked) { blockedView(shell, a.reason); return; }
  const p = await loadProfile(true);
  if (p && !p.username) { profileSetup(shell); return; }
  finishAuth(shell);
}

function finishAuth(shell) {
  shell.show(h('div', { class: 'auth-ok' }, icon('check', 30, '#fff', 3)),
    h('h1', null, 'Ciao, ' + (displayName().split(' ')[0] || '') + '!'),
    h('p', { class: 'auth-sub' }, 'Tutto pronto. Buon montaggio.'));
  setTimeout(() => { shell.close(true); nav('home'); }, 1100);
}

function blockedView(shell, reason) {
  shell.show(authMark(),
    h('h1', null, 'Account sospeso'),
    h('p', { class: 'auth-sub' }, 'Questo account non può usare NoonFrame.'),
    reason ? h('p', { class: 'auth-reason', 'data-notr': '' }, reason) : null,
    h('p', { class: 'auth-legal' }, 'Se pensi che sia un errore, scrivici dal sito di NoonFrame.'),
    h('button', { class: 'btn big auth-wide', onclick: async () => { await post('/api/account/logout', {}).catch(() => {}); ACCT = null; PROF = null; await loadAccount(); paintAccount(); signInFlow(shell, false); } }, 'Esci e usa un altro account'));
}

// nome utente proposto dal nome Google: "Mario Rossi" -> mario.rossi
function suggestUsername() {
  const base = String((PROF && (PROF.google_name || PROF.name)) || (ACCT && ACCT.user && ACCT.user.email || '').split('@')[0] || '')
    .normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.+|\.+$/g, '').slice(0, 20).replace(/\.+$/, '');
  return base.length >= 3 ? base : (base + 'creator').slice(0, 20);
}
const USERNAME_RE = /^[a-z0-9](?:[a-z0-9._]{1,18})[a-z0-9]$/;
const WHY = { format: 'Da 3 a 20 caratteri: lettere minuscole, numeri, punto e trattino basso', taken: 'Questo nome utente è già preso', reserved: 'Questo nome utente non si può usare' };

// campo "nome utente" con controllo mentre si scrive
function usernameField(initialValue, onState) {
  const input = h('input', { class: 'auth-input', maxlength: '20', spellcheck: 'false', autocomplete: 'off', value: initialValue || '', 'aria-label': 'Nome utente' });
  const hint = h('p', { class: 'field-hint' });
  const wrap = h('div', { class: 'field-at' }, h('span', { class: 'at' }, '@'), input, h('span', { class: 'field-state' }));
  const st = wrap.lastChild;
  let seq = 0, timer = null;
  const set = (state, msg) => { wrap.dataset.state = state; hint.textContent = msg || ''; st.replaceChildren(state === 'ok' ? icon('check', 14, 'currentColor', 2.6) : state === 'busy' ? h('span', { class: 'spinner' }) : state === 'bad' ? icon('x', 13, 'currentColor', 2.6) : ''); onState(state, input.value); };
  const check = () => {
    const v = input.value.trim().toLowerCase();
    clearTimeout(timer);
    if (v === ((PROF && PROF.username) || '')) { set(v ? 'same' : 'idle'); return; }
    if (!USERNAME_RE.test(v) || /[._]{2}/.test(v)) { set(v ? 'bad' : 'idle', v ? WHY.format : ''); return; }
    set('busy');
    const my = ++seq;
    timer = setTimeout(async () => {
      try { const r = await post('/api/account/username', { username: v }); if (my !== seq) return; r.ok ? set('ok', 'Disponibile') : set('bad', WHY[r.why] || WHY.format); }
      catch (e) { if (my === seq) set('bad', e.message); }
    }, 350);
  };
  input.addEventListener('input', () => { const c = input.selectionStart; const v = input.value.toLowerCase().replace(/[^a-z0-9._]/g, ''); if (v !== input.value) { input.value = v; input.setSelectionRange(c, c); } check(); });
  setTimeout(check, 0);
  return { el: h('div', { class: 'field' }, h('label', null, 'Nome utente'), wrap, hint), input };
}

function profileSetup(shell) {
  let unameOk = false;
  const err = h('p', { class: 'auth-err', role: 'alert' });
  const name = h('input', { class: 'auth-input', maxlength: '40', value: displayName(), 'aria-label': 'Nome' });
  const go = h('button', { class: 'btn primary big auth-wide', disabled: true }, 'Inizia a creare');
  const refresh = () => { go.disabled = !(unameOk && name.value.trim()); };
  const uf = usernameField(suggestUsername(), (st) => { unameOk = st === 'ok'; refresh(); });
  name.addEventListener('input', refresh);
  const pic = h('button', { class: 'auth-avatar', 'aria-label': 'Foto profilo', onclick: () => pickPhoto().then((ok) => { if (ok) pic.replaceChildren(avatar(96), h('span', { class: 'cam' }, icon('camera', 15))); }) },
    avatar(96), h('span', { class: 'cam' }, icon('camera', 15)));
  go.addEventListener('click', async () => {
    go.disabled = true; err.textContent = '';
    try { PROF = await post('/api/account/profile', { username: uf.input.value.trim(), name: name.value.trim() }); await loadAccount(); paintAccount(); finishAuth(shell); }
    catch (e) { err.textContent = e.message; refresh(); }
  });
  shell.show(h('h1', null, 'Crea il tuo profilo'),
    h('p', { class: 'auth-sub' }, 'Scegli come ti vedrà la community di NoonFrame.'),
    pic,
    h('div', { class: 'field' }, h('label', null, 'Nome'), name),
    uf.el, err, go,
    PROF && PROF.nuvora_id ? h('p', { class: 'auth-legal' }, 'Il tuo ID NoonFrame: ', h('b', { 'data-notr': '' }, fmtNoonFrameId(PROF.nuvora_id))) : null);
}

// ---- foto profilo: si sceglie, si inquadra nel cerchio, si salva piccola (256x256)
function pickPhoto() {
  return new Promise((resolve) => {
    const inp = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' });
    inp.addEventListener('change', async () => {
      const f = inp.files && inp.files[0];
      if (!f) return resolve(false);
      if (f.size > 25 * 1024 * 1024) { toast('L\'immagine è troppo grande', true); return resolve(false); }
      const data = await cropPhoto(f);
      if (!data) return resolve(false);
      try { PROF = await post('/api/account/photo', { data }); paintAccount(); toast('Foto aggiornata'); resolve(true); }
      catch (e) { toast(e.message, true); resolve(false); }
    });
    inp.click();
  });
}

function cropPhoto(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onerror = () => { URL.revokeObjectURL(url); toast('Non riesco ad aprire questa immagine', true); resolve(null); };
    img.onload = () => {
      const V = 260, W = img.naturalWidth, H = img.naturalHeight;
      const base = Math.max(V / W, V / H);
      let zoom = 1, x = (V - W * base) / 2, y = (V - H * base) / 2;
      const pic = h('img', { src: url, alt: '', draggable: 'false' });
      const view = h('div', { class: 'crop-view', style: { width: V + 'px', height: V + 'px' } }, pic, h('div', { class: 'crop-ring' }));
      const clamp = () => { const s = base * zoom; x = Math.min(0, Math.max(V - W * s, x)); y = Math.min(0, Math.max(V - H * s, y)); };
      const draw = () => { clamp(); const s = base * zoom; Object.assign(pic.style, { width: W * s + 'px', height: H * s + 'px', transform: `translate(${x}px, ${y}px)` }); };
      const setZoom = (z) => { const c = V / 2, s0 = base * zoom; zoom = Math.min(4, Math.max(1, z)); const s1 = base * zoom; x = c - (c - x) * s1 / s0; y = c - (c - y) * s1 / s0; slider.value = zoom; draw(); };
      const slider = h('input', { type: 'range', min: '1', max: '4', step: '0.01', value: '1', class: 'crop-zoom', 'aria-label': 'Zoom' });
      slider.addEventListener('input', () => setZoom(+slider.value));
      view.addEventListener('wheel', (e) => { e.preventDefault(); setZoom(zoom * (e.deltaY < 0 ? 1.08 : 1 / 1.08)); }, { passive: false });
      view.addEventListener('pointerdown', (e) => {
        view.setPointerCapture(e.pointerId); const sx = e.clientX - x, sy = e.clientY - y;
        const mv = (ev) => { x = ev.clientX - sx; y = ev.clientY - sy; draw(); };
        const up = () => { view.removeEventListener('pointermove', mv); view.removeEventListener('pointerup', up); };
        view.addEventListener('pointermove', mv); view.addEventListener('pointerup', up);
      });
      draw();
      const bg = h('div', { class: 'modal-bg crop-bg' });
      const close = (v) => { bg.remove(); URL.revokeObjectURL(url); resolve(v); };
      const save = () => {
        const S = 256, k = S / V, c = document.createElement('canvas'); c.width = S; c.height = S;
        const ctx = c.getContext('2d'); ctx.imageSmoothingQuality = 'high';
        ctx.fillStyle = '#151920'; ctx.fillRect(0, 0, S, S);
        const s = base * zoom; ctx.drawImage(img, x * k, y * k, W * s * k, H * s * k);
        close(c.toDataURL('image/jpeg', 0.9));
      };
      bg.append(h('div', { class: 'modal crop' },
        h('h3', null, 'Inquadra la foto'), view,
        h('div', { class: 'crop-row' }, icon('zoomout', 15), slider, icon('zoomin', 15)),
        h('p', { class: 'crop-tip' }, 'Trascina per spostare, rotella per zoomare'),
        h('div', { class: 'crop-btns' },
          h('button', { class: 'btn ghost', onclick: () => close(null) }, 'Annulla'),
          h('button', { class: 'btn primary', onclick: save }, 'Usa questa foto'))));
      document.body.append(bg);
    };
    img.src = url;
  });
}

// ---- all'avvio (e quando il server chiede l'accesso): accesso, account sospeso, profilo da completare
let gating = null;
function gate() {
  if (gating) return gating;
  gating = (async () => {
    const a = await loadAccount();
    paintAccount();
    if (!a || !a.enabled) return true;
    if (AUTH) return false;
    if (a.signedIn && a.blocked) { const s = authShell(false); blockedView(s, a.reason); await s.done; return false; }
    if (!a.signedIn) {
      if (!a.required) return true;
      const s = authShell(false); signInFlow(s, false); return s.done;
    }
    // dentro: profilo (salvato sul computer; se manca il nome utente si completa)
    const p = await loadProfile(!(a.profile && a.profile.loaded));
    if (p && !p.username) { const s = authShell(false); profileSetup(s); return s.done; }
    if (a.profile && a.profile.loaded) loadProfile(true);   // in background: numeri e dispositivi aggiornati
    return true;
  })().finally(() => { gating = null; });
  return gating;
}
window.addEventListener('nuvora:login', () => gate());
setInterval(async () => {
  const a = await loadAccount();
  if (a && a.signedIn && a.blocked && !AUTH) gate();
}, 5 * 60 * 1000);

// ----------------------------------------------------------------- PROFILO
const PLATFORM_NAME = { windows: 'Windows', mac: 'Mac', linux: 'Linux' };
function whenAgo(t) {
  if (!t) return '';
  const d = new Date(t), days = Math.floor((Date.now() - d.getTime()) / 86400000);
  if (Date.now() - d.getTime() < 10 * 60 * 1000) return 'adesso';
  if (days < 1) return 'oggi';
  if (days < 2) return 'ieri';
  if (days < 30) return days + ' giorni fa';
  return d.toLocaleDateString(locale(), { day: 'numeric', month: 'short', year: 'numeric' });
}
function monthYear(t) { return t ? new Date(t).toLocaleDateString(locale(), { month: 'long', year: 'numeric' }) : ''; }

async function screenProfile() {
  // rebrand 9a: come la Home, una colonna: foto con l'anello dei crediti, nome, numeri, e le righe che si toccano per
  // cambiare (nome, username, dispositivi, crediti e piano, lingua, privacy, aggiornamenti); in fondo Esci ed Elimina
  setTitle('Account');
  const my = navSeq;
  const col = h('div', { class: 'ac' });
  const page = h('div', { class: 'pp ac-page' },
    h('header', { class: 'pp-head' }, h('div', { class: 'pp-crumb' }, h('button', { type: 'button', class: 'ac-back', 'aria-label': 'Indietro', onclick: () => nav('home') }, icon('left', 16, 'currentColor', 2)), h('span', null, 'Account'))),
    h('div', { class: 'pp-body' }, col));
  app.innerHTML = '';
  app.classList.remove('live-only');
  app.append(appShell(null, null, page));
  if (!PROF) await loadProfile(false);
  if (ACCT && ACCT.signedIn && !CREDITS) await loadCredits();
  if (my !== navSeq) return;
  const sh = (title, sub, ...content) => {
    const { box, close } = sheet('nuovo ac-sheet', icon('user', 18, 'var(--tx)', 1.7), title, sub);
    box.append(...content.filter(Boolean));
    return close;
  };
  const render = () => {
    const p = PROF;
    if (!p) {
      col.replaceChildren(h('div', { class: 'pp-empty' }, h('span', { class: 'pp-eic' }, icon('globe', 22, 'var(--t2)', 1.6)), h('b', null, 'Profilo non disponibile'),
        h('span', null, 'Collegati a internet per vedere il tuo profilo.'), h('button', { class: 'pp-ebtn', type: 'button', onclick: () => loadProfile(true).then(render) }, 'Riprova')));
      return;
    }
    const cr = CREDITS;
    // --- testata: foto con l'anello dei crediti (clic per cambiarla), nome, @username, da quando, ID
    const photo = h('button', { class: 'ac-photo', type: 'button', 'aria-label': 'Cambia foto', 'data-tip': 'Cambia foto', onclick: () => photoMenu(photo) },
      h('div', { class: 'nf-ring ac-ring' }, ringSvg(cr ? cr.frac : 0), avatar(76)), h('span', { class: 'ac-cam' }, icon('camera', 13, 'currentColor', 1.8)));
    const idBtn = h('button', { class: 'ac-id', type: 'button', 'data-tip': 'Copia l\'ID', onclick: () => { navigator.clipboard.writeText(String(p.nuvora_id)).then(() => toast('ID copiato')).catch(() => {}); } },
      h('span', { 'data-notr': '' }, 'NF-' + fmtNoonFrameId(p.nuvora_id).replace(' ', '-')), icon('copy', 12, 'currentColor', 1.8));
    const head = h('section', { class: 'ac-head' }, photo,
      h('div', { class: 'ac-name' }, h('b', { 'data-notr': '' }, p.name || ''), cr && cr.paid ? h('span', { class: 'nf-pro' }, 'PRO') : null),
      h('div', { class: 'ac-meta' }, p.username ? h('span', { 'data-notr': '' }, '@' + p.username) : null,
        p.created_at ? h('span', { class: 'since' }, icon('calendar', 12, 'currentColor', 1.8), h('span', { 'data-notr': '' }, monthYear(p.created_at))) : null, idBtn));
    // --- numeri
    const st = p.stats || {};
    const stat = (n, label, ic) => h('div', { class: 'ac-stat' }, h('span', { class: 'ic' }, icon(ic, 17, 'currentColor', 1.6)), h('b', { class: 'tnum' }, String(n || 0)), h('span', null, label));
    const stats = h('section', { class: 'ac-stats' }, stat(st.exports, 'Video esportati', 'film'), stat(st.projects, 'Progetti', 'apps'),
      stat(st.reports, 'Segnalazioni', 'chat'), stat(st.reports_done, 'Realizzate', 'check'));
    // --- righe
    const row = (ic, label, value, fn, extra) => h(fn ? 'button' : 'div', { class: 'ac-row' + (fn ? '' : ' ro'), type: fn ? 'button' : null, onclick: fn || null },
      h('span', { class: 'ic' }, icon(ic, 16, 'currentColor', 1.6)), h('span', { class: 'k' }, label), h('span', { class: 'grow' }), extra || null,
      value != null && value !== '' ? h('span', { class: 'v', 'data-notr': '' }, value) : null, fn ? icon('right', 14, 'var(--t3)', 1.8) : null);
    const devs = p.devices || [];
    const card1 = h('section', { class: 'ac-card' },
      row('user', 'Nome', p.name || '', () => editName()),
      row('at', 'Username', p.username ? '@' + p.username : '', () => editUsername()),
      row('mail', 'Email', p.email || '', null, h('span', { class: 'ac-g', 'data-tip': 'Accedi con Google' }, GOOGLE_G())),
      row('laptop', 'Dispositivi', String(devs.length), () => devices()));
    const planVal = cr ? (cr.paid ? '' : 'Gratis · ') + cr.balance + ' crediti' : '';
    const langName = (LANG_NAMES.find(([k]) => k === LANG) || [LANG, LANG])[1];
    const card2 = h('section', { class: 'ac-card' },
      row('card', 'Crediti e piano', '', () => creditsDialog(), h('span', { class: 'ac-pv' }, cr && cr.paid ? h('span', { class: 'nf-pro' }, 'PRO') : null, planVal ? h('span', { class: 'v' }, planVal) : null)),
      row('globe', 'Lingua', langName, () => languages()),
      row('shield', 'Privacy e licenza', '', () => licenseDialog(1)),
      row('update', 'Aggiornamenti', ENV.version || '', () => checkUpdatesNow(card2.querySelector('.ac-row:nth-child(4)'))),
      ENV.beta || ENV.channel === 'beta' ? row('bolt', ENV.channel === 'beta' ? 'Beta attiva' : 'Versioni beta', '', () => betaDialog()) : null);
    const foot = h('section', { class: 'ac-foot' },
      h('button', { type: 'button', class: 'ac-out', onclick: signOut }, icon('logout', 15, 'currentColor', 1.8), h('span', null, 'Esci')),
      h('button', { type: 'button', class: 'ac-del', onclick: deleteAccountDialog }, 'Elimina account'));
    col.replaceChildren(head, stats, card1, card2, planCard(), foot);
  };
  async function save(body) {
    PROF = await post('/api/account/profile', body);
    await loadAccount(); paintAccount();
    toast('Profilo aggiornato');
    render();
  }
  async function editName() {
    const nm = await promptBox('Il tuo nome', 'È il nome del tuo account NoonFrame.', PROF.name || '', 'Salva');
    if (!nm || !nm.trim() || nm.trim() === PROF.name) return;
    try { await save({ name: nm.trim().slice(0, 40) }); } catch (e) { toast(e.message, true); }
  }
  function editUsername() {
    let state = 'same';
    const go = h('button', { class: 'nfs-go', type: 'button', disabled: true }, 'Salva');
    const uf = usernameField(PROF.username || '', (s) => { state = s; go.disabled = s !== 'ok'; });
    const next = PROF.username_next_change && new Date(PROF.username_next_change) > new Date() ? PROF.username_next_change : null;
    if (next) uf.input.disabled = true;
    const close = sh('Username', next ? '' : 'Puoi cambiarlo una volta ogni 7 giorni.', uf.el,
      next ? h('p', { class: 'field-hint' }, 'Potrai cambiarlo di nuovo il ', h('span', { 'data-notr': '' }, new Date(next).toLocaleDateString(locale(), { day: 'numeric', month: 'long' }))) : null,
      h('div', { class: 'nfs-nfoot' }, h('span', { class: 'grow' }), go));
    go.addEventListener('click', async () => {
      if (state !== 'ok') return;
      go.disabled = true;
      try { await save({ username: uf.input.value.trim() }); close(); } catch (e) { go.disabled = false; toast(e.message, true); }
    });
  }
  function devices() {
    const mine = ACCT && ACCT.device_id;
    const list = (PROF.devices || []).map((d) => h('div', { class: 'ac-dev' }, h('span', { class: 'ic' }, icon('laptop', 17, 'currentColor', 1.6)),
      h('div', { class: 'tx' }, h('b', { 'data-notr': '' }, (PLATFORM_NAME[d.platform] || d.platform || '') + (d.os ? ' · ' + d.os : '')),
        h('span', null, 'NoonFrame ', h('span', { 'data-notr': '' }, d.app_version || ''), ' · ultimo accesso ', h('span', null, whenAgo(d.last_seen_at)))),
      d.id === mine ? h('span', { class: 'nf-pro' }, 'Questo computer') : null));
    sh('Dispositivi', 'I computer da cui accedi con questo account', h('div', { class: 'ac-devs' }, ...(list.length ? list : [h('p', { class: 'field-note' }, 'Nessun dispositivo ancora.')])));
  }
  function languages() {
    const close = sh('Lingua', 'L\'app si riapre nella lingua che scegli', h('div', { class: 'ac-langs' }, ...LANG_NAMES.map(([k, l]) => h('button', { type: 'button', class: 'ac-lang' + (LANG === k ? ' on' : ''), 'data-notr': '1', onclick: () => {
      close();
      try { localStorage.setItem('vodcut.lang', k); } catch (e) { /* */ }
      post('/api/settings', { lang: k }).catch(() => {}).finally(() => location.reload());
    } }, h('span', null, l), LANG === k ? icon('check', 15, 'var(--ac)', 2.2) : null))));
  }
  const photoMenu = (anchor) => {
    document.querySelectorAll('.acct-menu').forEach((m) => m.remove());
    const r = anchor.getBoundingClientRect();
    const m = h('div', { class: 'acct-menu', style: { top: (r.bottom + 6) + 'px', left: r.left + 'px' } },
      h('button', { class: 'acct-item', onclick: () => { m.remove(); pickPhoto().then((ok) => ok && render()); } }, icon('upload', 15), 'Carica una foto'),
      PROF && PROF.photo ? h('button', { class: 'acct-item danger', onclick: async () => { m.remove(); try { PROF = await post('/api/account/photo', { data: '' }); paintAccount(); render(); } catch (e) { toast(e.message, true); } } }, icon('trash', 15), 'Rimuovi foto') : null);
    document.body.append(m);
    const off = (e) => { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('pointerdown', off, true); } };
    setTimeout(() => document.addEventListener('pointerdown', off, true), 0);
  };
  render();
  loadProfile(true).then(() => { if (my === navSeq && page.isConnected && !document.querySelector('.nfs-bg')) render(); });
}

// ----------------------------------------------------------------- avvio
window.addEventListener('error', (e) => /ResizeObserver loop/.test(e.message || '') ? null : post('/api/clientlog', { msg: 'ERRORE JS: ' + e.message + ' @ ' + (e.filename || '') + ':' + e.lineno }).catch(() => {}));
window.addEventListener('unhandledrejection', (e) => post('/api/clientlog', { msg: 'ERRORE promessa: ' + (e.reason && e.reason.message || e.reason) }).catch(() => {}));
post('/api/clientlog', { msg: 'app avviata ' + location.href.split('?')[0] }).catch(() => {});
// lingua: quella scelta, se no quella di Windows
{
  let saved = null;
  try { saved = localStorage.getItem('vodcut.lang'); } catch (e) { /* */ }
  const lang = pickLang(saved);
  await loadLang(lang);
  startTranslating();
  post('/api/settings', { lang }).catch(() => {});   // per le finestre di Windows (scegli file, salva)
}
const ping = () => fetch('/api/ping?ui=1').then((r) => r.json()).then((j) => onUpd(j.upd)).catch(() => {});
setInterval(ping, 5000);
ping();
nav('home');
gate();
// avvio con doppio clic su un file .vodcut
{
  const op = new URLSearchParams(location.search).get('open');
  if (op) { history.replaceState(null, '', '/'); setTimeout(() => importProjectPath(op), 400); }
}
// niente menu del browser col tasto destro (resta solo nei campi di testo); le tracce hanno il loro menu
document.addEventListener('contextmenu', (e) => { if (!e.target.closest('input, textarea, [contenteditable="true"]')) e.preventDefault(); });
