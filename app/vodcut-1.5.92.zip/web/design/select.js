// Grafica: la selezione (quale parte della tela e' scelta). E' una maschera in coordinate del documento:
// rettangolo, ellisse, lazo, bacchetta magica e "seleziona soggetto" la riempiono; tagli, riempimenti,
// maschere e pennello la usano.

const mk = (w, h) => { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; };

export class Selection {
  constructor(W, H) { this.resize(W, H); }
  resize(W, H) {
    this.W = W; this.H = H;
    this.k = Math.min(1, 2048 / Math.max(W, H));
    this.mask = mk(W * this.k, H * this.k);
    this.on = false; this._out = null; this._b = null;
  }
  get g() { return this.mask.getContext('2d'); }
  clear() { this.g.clearRect(0, 0, this.mask.width, this.mask.height); this.on = false; this._out = null; this._b = null; }
  // mode: 'new' | 'add' | 'sub' | 'int'
  _apply(mode, draw) {
    const g = this.g;
    if (mode === 'new' || !this.on) { g.clearRect(0, 0, this.mask.width, this.mask.height); mode = mode === 'sub' || mode === 'int' ? 'none' : 'add'; }
    if (mode === 'none') { this._done(); return; }
    const tmp = mk(this.mask.width, this.mask.height), tg = tmp.getContext('2d');
    tg.scale(this.k, this.k); tg.fillStyle = '#fff'; tg.strokeStyle = '#fff';
    draw(tg);
    g.save();
    g.globalCompositeOperation = mode === 'sub' ? 'destination-out' : mode === 'int' ? 'destination-in' : 'source-over';
    g.drawImage(tmp, 0, 0); g.restore();
    this._done();
  }
  _done() {
    this._out = null; this._b = null;
    const b = this.bounds();
    this.on = !!b;
  }
  rect(x, y, w, h, mode) { this._apply(mode, (g) => g.fillRect(x, y, w, h)); }
  ellipse(x, y, w, h, mode) { this._apply(mode, (g) => { g.beginPath(); g.ellipse(x + w / 2, y + h / 2, Math.abs(w / 2), Math.abs(h / 2), 0, 0, Math.PI * 2); g.fill(); }); }
  poly(pts, mode) {
    if (pts.length < 3) return;
    this._apply(mode, (g) => { g.beginPath(); pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath(); g.fill(); });
  }
  // maschera gia' pronta in coordinate del documento (alfa = scelto)
  fromCanvas(src, mode) { this._apply(mode, (g) => g.drawImage(src, 0, 0, this.W, this.H)); }
  all() { this.rect(0, 0, this.W, this.H, 'new'); }
  invert() {
    const g = this.g, c = mk(this.mask.width, this.mask.height), cg = c.getContext('2d');
    cg.fillStyle = '#fff'; cg.fillRect(0, 0, c.width, c.height);
    cg.globalCompositeOperation = 'destination-out'; cg.drawImage(this.mask, 0, 0);
    g.clearRect(0, 0, c.width, c.height); g.drawImage(c, 0, 0);
    this._done();
  }
  feather(px) {
    if (!this.on || px <= 0) return;
    const c = mk(this.mask.width, this.mask.height), cg = c.getContext('2d');
    cg.filter = `blur(${Math.max(0.5, px * this.k)}px)`; cg.drawImage(this.mask, 0, 0);
    this.g.clearRect(0, 0, c.width, c.height); this.g.drawImage(c, 0, 0);
    this._done();
  }
  // riquadro occupato (coordinate del documento), null se vuota
  bounds() {
    if (this._b !== null) return this._b;
    const w = this.mask.width, h = this.mask.height;
    const d = this.g.getImageData(0, 0, w, h).data;
    let x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (let y = 0; y < h; y++) {
      const row = y * w * 4;
      for (let x = 0; x < w; x++) if (d[row + x * 4 + 3] > 8) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; y1 = y; }
    }
    this._b = x1 < 0 ? false : { x: x0 / this.k, y: y0 / this.k, w: (x1 - x0 + 1) / this.k, h: (y1 - y0 + 1) / this.k };
    return this._b || null;
  }
  // bordo (per le "formiche"): pixel scelti che toccano un pixel non scelto
  outline() {
    if (this._out) return this._out;
    // bordo del "dentro" (alfa da meta' in su): vale anche per le selezioni morbide (sfumate o dell'AI)
    const w = this.mask.width, h = this.mask.height;
    const d = this.g.getImageData(0, 0, w, h).data;
    const O = mk(w, h), og = O.getContext('2d'), od = og.createImageData(w, h), o = od.data;
    const IN = (x, y) => x >= 0 && y >= 0 && x < w && y < h && d[(y * w + x) * 4 + 3] >= 128;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (!IN(x, y)) continue;
      if (!IN(x - 1, y) || !IN(x + 1, y) || !IN(x, y - 1) || !IN(x, y + 1)) { const i = (y * w + x) * 4; o[i] = o[i + 1] = o[i + 2] = 255; o[i + 3] = 255; }
    }
    og.putImageData(od, 0, 0);
    this._out = O;
    return O;
  }
  // la selezione disegnata nel riquadro di un livello (per maschere, pittura, tagli). cw x ch = tela del livello
  toLayer(l, cw, ch) { return mapToLayer(l, cw, ch, (g) => g.drawImage(this.mask, 0, 0, this.W, this.H)); }
}

// disegna qualcosa in coordinate del documento dentro la tela di un livello (cw x ch), con la sua posizione e rotazione
export function mapToLayer(l, cw, ch, draw) {
  const c = mk(cw, ch), g = c.getContext('2d');
  g.scale(cw / l.w, ch / l.h);
  g.translate(l.w / 2, l.h / 2);
  g.scale(l.flipX ? -1 : 1, l.flipY ? -1 : 1);
  g.rotate(-(l.rot || 0) * Math.PI / 180);
  g.translate(-(l.x + l.w / 2), -(l.y + l.h / 2));
  draw(g);
  return c;
}

// bacchetta magica: pixel di colore simile (tolleranza 0..255), vicini o in tutta l'immagine
export function magicWand(img, px, py, tol, contiguous) {
  const w = img.width, h = img.height, g = img.getContext('2d');
  const d = g.getImageData(0, 0, w, h).data;
  const out = mk(w, h), og = out.getContext('2d'), od = og.createImageData(w, h), o = od.data;
  px = Math.max(0, Math.min(w - 1, Math.floor(px))); py = Math.max(0, Math.min(h - 1, Math.floor(py)));
  const i0 = (py * w + px) * 4;
  const r0 = d[i0], g0 = d[i0 + 1], b0 = d[i0 + 2], a0 = d[i0 + 3];
  const near = (i) => Math.max(Math.abs(d[i] - r0), Math.abs(d[i + 1] - g0), Math.abs(d[i + 2] - b0), Math.abs(d[i + 3] - a0)) <= tol;
  if (!contiguous) {
    for (let i = 0; i < w * h; i++) if (near(i * 4)) o[i * 4 + 3] = 255;
  } else {
    const seen = new Uint8Array(w * h);
    const stack = [px, py];
    while (stack.length) {
      const y = stack.pop(); let x = stack.pop();
      let i = y * w + x;
      while (x >= 0 && !seen[i] && near(i * 4)) { x--; i--; }
      x++; i++;
      let up = false, dn = false;
      while (x < w && !seen[i] && near(i * 4)) {
        seen[i] = 1; o[i * 4 + 3] = 255;
        if (y > 0) { const j = i - w; if (!seen[j] && near(j * 4)) { if (!up) { stack.push(x, y - 1); up = true; } } else up = false; }
        if (y < h - 1) { const j = i + w; if (!seen[j] && near(j * 4)) { if (!dn) { stack.push(x, y + 1); dn = true; } } else dn = false; }
        x++; i++;
      }
    }
  }
  for (let i = 0; i < w * h; i++) { o[i * 4] = 255; o[i * 4 + 1] = 255; o[i * 4 + 2] = 255; }
  og.putImageData(od, 0, 0);
  return out;
}
