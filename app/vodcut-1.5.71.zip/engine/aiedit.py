"""Montaggio con l'AI: stili di montaggio (pronti o imparati dai video di riferimento) e il piano delle modifiche.

L'AI non tocca il progetto: legge la trascrizione (parole numerate con i tempi) e lo stile, e propone un piano
(tagli, zoom, sottotitoli, scritte, grafiche). L'editor lo mostra, l'utente sceglie e lo applica (si annulla in un colpo).
Le pause si trovano qui, senza AI (gratis): sono i buchi tra una parola e l'altra.
"""
import json
import os
import re
import subprocess

from . import ai
from .util import NO_WINDOW, ffmpeg_bin

FONTS = ["Montserrat", "Poppins", "Inter", "TikTok Sans", "Bebas Neue", "Anton", "Oswald", "Archivo Black", "Kanit", "Rubik",
         "Lilita One", "Luckiest Guy", "Bangers", "Titan One", "Outfit", "Sora", "Space Grotesk", "Unbounded", "Playfair Display",
         "Russo One", "Teko", "Orbitron", "Permanent Marker", "Arial", "Impact"]

# ------------------------------------------------------------------ stili pronti
PRESETS = {
    "business": {
        "name": "Finanza e business", "icon": "chart",
        "summary": "Ritmo serrato da YouTube business: niente pause, zoom sui numeri e sulle frasi forti, parole chiave colorate, grafiche pulite con cifre e icone.",
        "pace": {"pauses": "tutte", "max_pause_sec": 0.3, "cut_every_sec": 3, "notes": "togli esitazioni, ripetizioni e frasi ricominciate"},
        "zoom": {"per_min": 6, "level": 1.25, "style": "scatto", "when": "numeri, cifre, promesse, frasi forti e cambi di argomento"},
        "captions": {"on": True, "mode": "poche", "position": "basso", "font": "Montserrat", "upper": False, "color": "#FFFFFF",
                     "highlight": "#FFD60A", "effect": "highlight", "box": False, "stroke": True, "size": "medi"},
        "texts": {"per_min": 1.5, "when": "numeri importanti, titoli dei capitoli, concetti chiave in 2-4 parole", "color": "#FFFFFF", "box": True},
        "graphics": {"per_min": 1.5, "when": "quando si parla di soldi, crescita, strumenti, aziende, concetti astratti",
                     "types": ["icone 3D", "grafici", "banconote e monete", "loghi generici"],
                     "prompt_style": "glossy 3D icon, soft studio lighting, clean modern finance style, vibrant but professional colors"},
        "broll": {"per_min": 0.5, "when": "esempi concreti"},
        "hook": "prima frase subito, zoom sul volto nei primi 2 secondi, titolo grande con la promessa",
        "rules": ["mai più di 3 secondi senza un cambio (zoom, scritta o grafica)", "le cifre vanno sempre anche a schermo"],
    },
    "gaming": {
        "name": "Gaming", "icon": "play",
        "summary": "Montaggio energico da gaming: tagli rapidissimi, zoom a scatto sulle reazioni, sottotitoli grandi e colorati, scritte meme.",
        "pace": {"pauses": "tutte", "max_pause_sec": 0.25, "cut_every_sec": 2, "notes": "togli le parti morte senza azione o reazione"},
        "zoom": {"per_min": 10, "level": 1.4, "style": "scatto", "when": "reazioni, urla, momenti epici, battute"},
        "captions": {"on": True, "mode": "parola", "position": "centro", "font": "Luckiest Guy", "upper": True, "color": "#FFFFFF",
                     "highlight": "#3DDC84", "effect": "pop", "box": False, "stroke": True, "size": "grandi"},
        "texts": {"per_min": 2, "when": "reazioni e momenti comici, stile meme (es. \"NO WAY\", \"GG\")", "color": "#FFD60A", "box": False},
        "graphics": {"per_min": 1, "when": "momenti comici o epici",
                     "types": ["emoji 3D", "effetti cartoon"], "prompt_style": "bold cartoon sticker, thick outline, vibrant saturated colors"},
        "broll": {"per_min": 0, "when": ""},
        "hook": "parti dal momento più epico, poi il contesto",
        "rules": ["energia sempre alta", "ogni reazione forte ha zoom o scritta"],
    },
    "story": {
        "name": "Storytelling", "icon": "text",
        "summary": "Racconto coinvolgente: ritmo che respira nei momenti di tensione, zoom lenti sulle frasi emotive, sottotitoli puliti.",
        "pace": {"pauses": "lunghe", "max_pause_sec": 0.7, "cut_every_sec": 4, "notes": "tieni le pause drammatiche, togli solo quelle morte"},
        "zoom": {"per_min": 3, "level": 1.2, "style": "morbido", "when": "rivelazioni, frasi emotive, colpi di scena"},
        "captions": {"on": True, "mode": "poche", "position": "basso", "font": "Poppins", "upper": False, "color": "#FFFFFF",
                     "highlight": "#FF9F5A", "effect": "highlight", "box": False, "stroke": True, "size": "medi"},
        "texts": {"per_min": 0.5, "when": "luoghi, date, nomi importanti", "color": "#FFFFFF", "box": False},
        "graphics": {"per_min": 1, "when": "per illustrare luoghi, oggetti e momenti del racconto",
                     "types": ["illustrazioni"], "prompt_style": "cinematic illustration, moody lighting, rich colors"},
        "broll": {"per_min": 1, "when": "descrizioni di luoghi e scene"},
        "hook": "apri con la frase più misteriosa o il momento più forte",
        "rules": ["non spezzare le frasi emotive"],
    },
    "podcast": {
        "name": "Podcast e interviste", "icon": "speaker",
        "summary": "Pulito e leggibile: togli pause lunghe ed errori, zoom leggeri su chi dice la cosa importante, sottotitoli a frase.",
        "pace": {"pauses": "lunghe", "max_pause_sec": 0.8, "cut_every_sec": 6, "notes": "togli solo errori e pause lunghe, mai il ragionamento"},
        "zoom": {"per_min": 2, "level": 1.15, "style": "morbido", "when": "le frasi citabili"},
        "captions": {"on": True, "mode": "frase", "position": "basso", "font": "Inter", "upper": False, "color": "#FFFFFF",
                     "highlight": "#6CB2FF", "effect": "none", "box": True, "stroke": False, "size": "piccoli"},
        "texts": {"per_min": 0.3, "when": "nome dell'ospite e argomenti", "color": "#FFFFFF", "box": True},
        "graphics": {"per_min": 0, "when": "", "types": [], "prompt_style": ""},
        "broll": {"per_min": 0, "when": ""},
        "hook": "apri con la frase più forte dell'intervista",
        "rules": ["niente effetti invadenti"],
    },
}
LEVELS = {"scatto": ("snap", "cut"), "morbido": ("smooth", "smooth")}


def presets():
    return [{"id": "p:" + k, "name": v["name"], "icon": v.get("icon"), "summary": v["summary"], "builtin": True} for k, v in PRESETS.items()]


def style_by_id(sid):
    """"p:business" -> stile pronto; "f:<formato>" -> stile imparato dai video di un formato."""
    sid = str(sid or "p:business")
    if sid.startswith("f:"):
        from . import formats as FM
        fm = FM.get(sid[2:])
        st = fm.get("editStyle")
        if not st:
            raise ai.AIError("Questo formato non ha ancora uno stile di montaggio: aprilo in Formati e premi \"Analizza lo stile\"")
        return dict(st, name=fm.get("name"))
    return PRESETS.get(sid[2:] if sid.startswith("p:") else sid) or PRESETS["business"]


# ------------------------------------------------------------------ stile imparato dai video di riferimento
def style_grid(path, dur, shots, out, n=8):
    """8 fotogrammi del video (uno per inquadratura, sparsi) in una griglia 4x2: l'AI ci vede sottotitoli, zoom, grafiche."""
    import cv2
    import numpy as np
    if os.path.isfile(out):
        return out
    pts = sorted(set([min(dur - 0.1, (a + b) / 2) for a, b in zip([0.0] + list(shots), list(shots) + [dur]) if b - a > 0.15]))
    if len(pts) > n:
        pts = [pts[round(i * (len(pts) - 1) / (n - 1))] for i in range(n)]
    while len(pts) < n:
        pts.append(dur * (len(pts) + 0.5) / n)
    pts = sorted(pts)[:n]
    tiles = []
    for t in pts:
        r = subprocess.run([ffmpeg_bin(), "-v", "error", "-ss", f"{max(0.0, t):.2f}", "-i", path, "-frames:v", "1", "-vf", "scale=420:-2",
                            "-f", "image2pipe", "-c:v", "png", "-"], capture_output=True, creationflags=NO_WINDOW)
        im = cv2.imdecode(np.frombuffer(r.stdout, np.uint8), cv2.IMREAD_COLOR) if r.stdout else None
        if im is not None:
            tiles.append(im)
    if not tiles:
        return None
    h = max(t.shape[0] for t in tiles)
    tiles = [cv2.copyMakeBorder(t, 0, h - t.shape[0], 0, 0, cv2.BORDER_CONSTANT, value=(20, 20, 20)) for t in tiles]
    while len(tiles) % 4:
        tiles.append(np.full_like(tiles[0], 20))
    rows = [np.hstack(tiles[i:i + 4]) for i in range(0, len(tiles), 4)]
    grid = np.vstack(rows)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    cv2.imwrite(out, grid, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return out


def _pauses(segs):
    gaps = []
    for x, y in zip(segs, segs[1:]):
        g = float(y["a"]) - float(x["b"])
        if g > 0.25:
            gaps.append(g)
    return gaps


STYLE_SCHEMA = (
    '{"summary": "2-3 frasi: com\'è montato e perché funziona",'
    ' "pace": {"pauses": "tutte|lunghe|nessuna", "max_pause_sec": 0.3, "cut_every_sec": 2.5, "notes": "come tagliano"},'
    ' "zoom": {"per_min": 6, "level": 1.25, "style": "scatto|morbido", "when": "su cosa zoomano"},'
    ' "captions": {"on": true, "mode": "parola|poche|frase", "position": "centro|basso", "font": "uno tra: ' + ", ".join(FONTS) + '",'
    ' "upper": false, "color": "#FFFFFF", "highlight": "#FFD60A", "effect": "highlight|pop|none", "box": false, "stroke": true, "size": "piccoli|medi|grandi"},'
    ' "texts": {"per_min": 1.5, "when": "quando compaiono scritte oltre ai sottotitoli", "color": "#FFFFFF", "box": true},'
    ' "graphics": {"per_min": 1.5, "when": "quando compaiono grafiche/immagini", "types": ["tipi di grafiche"],'
    ' "prompt_style": "stile visivo delle grafiche in inglese, per un generatore di immagini"},'
    ' "broll": {"per_min": 0.5, "when": "quando usano spezzoni di altre scene"},'
    ' "hook": "come montano i primi 3 secondi", "rules": ["3-6 regole di montaggio concrete"]}')


def analyze_style(fm, cfg, cancel=None):
    """Lo stile di montaggio dei video pronti di un formato: numeri misurati + fotogrammi guardati dall'AI."""
    from . import formats as FM
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto" and v.get("path") and os.path.isfile(v["path"])]
    if not vids:
        raise ai.AIError("Nessun video pronto: aggiungi e analizza almeno un video di riferimento")
    order = {"top": 0, "ok": 1, "new": 2, "": 2, "flop": 3}
    vids.sort(key=lambda v: order.get(v.get("rating") or "", 2))
    vids = vids[:6]
    grids, lines = [], []
    for n, v in enumerate(vids, 1):
        dur = float(v.get("dur") or 0) or 1.0
        shots = v.get("shots") or []
        g = style_grid(v["path"], dur, shots, os.path.join(FM._dir(fm["id"]), "video", v["id"], "stile.jpg"))
        if g:
            grids.append(g)
        segs = v.get("transcript") or []
        gaps = _pauses(segs)
        lines.append(f"VIDEO {n} (immagine {len(grids)}): durata {dur:.0f}s · {len(shots)} cambi di inquadratura (uno ogni {dur / max(1, len(shots)):.1f}s, "
                     f"{len(shots) / dur * 60:.0f} al minuto) · {v.get('wps') or '?'} parole al secondo · pause oltre 0,25s: {len(gaps)} "
                     f"(media {sum(gaps) / len(gaps) if gaps else 0:.2f}s) · risultato: {v.get('rating') or 'non indicato'}\n"
                     f"Inizio: {' '.join(s['t'] for s in segs if s['a'] < 6)[:240]}")
    system = ("Sei un montatore video esperto di YouTube, TikTok e Reels. Ricevi i numeri misurati di alcuni video di riferimento e, per ognuno, "
              "una griglia di 8 fotogrammi presi in momenti diversi. Guarda i fotogrammi con attenzione: come sono fatti i sottotitoli (font, colori, "
              "maiuscole, parole evidenziate, posizione, quante parole per volta), se l'inquadratura cambia (zoom, punch-in), scritte e grafiche a "
              "schermo, b-roll, colori. Ricava lo STILE DI MONTAGGIO comune, da riusare su video nuovi. Scrivi in italiano (tranne prompt_style in inglese). "
              "Rispondi SOLO con JSON:\n" + STYLE_SCHEMA)
    user = f"Tipo di video: {FM.KINDS.get(fm.get('kind'), fm.get('kind'))}\n\n" + "\n\n".join(lines)
    raw = ai.text(cfg, system, user, max_tokens=3000, cancel=cancel, images=grids)
    st = ai.parse_json(raw)
    if not isinstance(st, dict):
        raise ai.AIError("L'AI non ha risposto con uno stile valido: riprova")
    st["from"] = {"videos": len(vids), "grids": len(grids)}
    return clean_style(st)


def estimate_style(fm):
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"][:6]
    return {"videos": len(vids), "tokensIn": 1500 + 1700 * len(vids), "tokensOut": 1200}


def _num(v, lo, hi, d):
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return d


def clean_style(st):
    """Valori sicuri (l'AI a volte sbaglia i tipi o esagera)."""
    b = PRESETS["business"]
    out = {"summary": str(st.get("summary") or "")[:600]}
    p = st.get("pace") or {}
    out["pace"] = {"pauses": p.get("pauses") if p.get("pauses") in ("tutte", "lunghe", "nessuna") else "tutte",
                   "max_pause_sec": _num(p.get("max_pause_sec"), 0.15, 2.0, 0.35), "cut_every_sec": _num(p.get("cut_every_sec"), 0.5, 30, 3),
                   "notes": str(p.get("notes") or "")[:300]}
    z = st.get("zoom") or {}
    out["zoom"] = {"per_min": _num(z.get("per_min"), 0, 30, 4), "level": _num(z.get("level"), 1.05, 2.0, 1.25),
                   "style": z.get("style") if z.get("style") in LEVELS else "scatto", "when": str(z.get("when") or "")[:300]}
    c = st.get("captions") or {}
    hexc = lambda x, d: x if isinstance(x, str) and re.match(r"^#[0-9a-fA-F]{6}$", x) else d
    out["captions"] = {"on": c.get("on") is not False, "mode": c.get("mode") if c.get("mode") in ("parola", "poche", "frase") else "poche",
                       "position": c.get("position") if c.get("position") in ("centro", "basso") else "basso",
                       "font": c.get("font") if c.get("font") in FONTS else "Montserrat", "upper": bool(c.get("upper")),
                       "color": hexc(c.get("color"), "#FFFFFF"), "highlight": hexc(c.get("highlight"), "#FFD60A"),
                       "effect": c.get("effect") if c.get("effect") in ("highlight", "pop", "none") else "highlight",
                       "box": bool(c.get("box")), "stroke": c.get("stroke") is not False,
                       "size": c.get("size") if c.get("size") in ("piccoli", "medi", "grandi") else "medi"}
    t = st.get("texts") or {}
    out["texts"] = {"per_min": _num(t.get("per_min"), 0, 10, 1), "when": str(t.get("when") or "")[:300], "color": hexc(t.get("color"), "#FFFFFF"),
                    "box": bool(t.get("box"))}
    g = st.get("graphics") or {}
    out["graphics"] = {"per_min": _num(g.get("per_min"), 0, 10, 1), "when": str(g.get("when") or "")[:300],
                       "types": [str(x)[:60] for x in (g.get("types") or [])][:6] if isinstance(g.get("types"), list) else [],
                       "prompt_style": str(g.get("prompt_style") or b["graphics"]["prompt_style"])[:300]}
    r = st.get("broll") or {}
    out["broll"] = {"per_min": _num(r.get("per_min"), 0, 10, 0), "when": str(r.get("when") or "")[:300]}
    out["hook"] = str(st.get("hook") or "")[:300]
    out["rules"] = [str(x)[:200] for x in (st.get("rules") or [])][:8] if isinstance(st.get("rules"), list) else []
    if st.get("from"):
        out["from"] = st["from"]
    return out


# ------------------------------------------------------------------ il piano delle modifiche
def words_of(proj):
    """Le parole ancora nel video (non tagliate), in ordine, con i tempi della timeline."""
    out = []
    for si, sg in enumerate(((proj.get("transcript") or {}).get("segments")) or []):
        for wi, w in enumerate(sg.get("words") or []):
            if w.get("del"):
                continue
            t = str(w.get("w") or "").strip()
            if t:
                out.append({"w": t, "a": float(w.get("a", 0)), "b": float(w.get("b", 0)), "k": f"{si}_{wi}"})
    return out


def removed_ranges(proj):
    rs = [(float(s["a"]), float(s["b"])) for s in proj.get("segs") or [] if s.get("removed")]
    return sorted(rs)


def _inside(t, rs):
    return any(a - 0.01 <= t <= b + 0.01 for a, b in rs)


def find_pauses(words, style, dur, rs):
    """Buchi tra le parole piu' lunghi di quanto vuole lo stile (+ silenzio all'inizio e alla fine)."""
    p = style.get("pace") or {}
    if p.get("pauses") == "nessuna":
        return []
    mx = float(p.get("max_pause_sec") or 0.35)
    if p.get("pauses") == "lunghe":
        mx = max(mx, 0.7)
    pad = 0.08
    out = []
    if words and words[0]["a"] > 0.6:
        out.append((0.0, max(0.0, words[0]["a"] - 0.15)))
    for x, y in zip(words, words[1:]):
        a, b = x["b"] + pad, y["a"] - pad
        if y["a"] - x["b"] > mx and b - a > 0.12:
            out.append((a, b))
    if words and dur - words[-1]["b"] > 0.8:
        out.append((words[-1]["b"] + 0.3, dur))
    return [(round(a, 3), round(b, 3)) for a, b in out if not (_inside(a, rs) and _inside(b, rs))]


PLAN_SCHEMA = (
    '{"summary": "2 frasi: cosa hai fatto e perché",'
    ' "cuts": [{"from": 12, "to": 19, "why": "ripetizione|errore|frase ricominciata|parte morta|fuori tema"}],'
    ' "zooms": [{"from": 40, "to": 52, "why": "breve motivo"}],'
    ' "texts": [{"from": 80, "to": 86, "text": "SCRITTA BREVE", "why": "breve motivo"}],'
    ' "graphics": [{"from": 120, "to": 131, "prompt": "english prompt of ONE object or scene", "place": "centro|alto|pieno", "why": "breve motivo"}]}')


def _chunks(words, size=2500):
    for i in range(0, len(words), size):
        yield i, words[i:i + size]


def plan(proj, style, prompt="", opts=None, cfg=None, cancel=None, progress=None):
    """-> {"summary", "items": [...], "usd"}; items: {id, type, a, b, ...} in tempi della timeline."""
    opts = opts or {}
    words = words_of(proj)
    if len(words) < 5:
        raise ai.AIError("Serve la trascrizione del video: premi \"Trascrivi il video\" e riprova")
    dur = float(proj.get("duration") or words[-1]["b"])
    rs = removed_ranges(proj)
    items = []
    if opts.get("pauses", True):
        for a, b in find_pauses(words, style, dur, rs):
            items.append({"type": "pause", "a": a, "b": b, "why": "pausa"})
    want_ai = any(opts.get(k, True) for k in ("cuts", "zooms", "texts", "graphics"))
    summary, usd = "", 0.0
    if want_ai:
        minutes = max(0.3, (words[-1]["b"] - words[0]["a"]) / 60)
        z, t, g = style.get("zoom") or {}, style.get("texts") or {}, style.get("graphics") or {}
        n_z = round(float(z.get("per_min") or 0) * minutes) if opts.get("zooms", True) else 0
        n_t = round(float(t.get("per_min") or 0) * minutes) if opts.get("texts", True) else 0
        n_g = round(float(g.get("per_min") or 0) * minutes) if opts.get("graphics", True) else 0
        system = ("Sei un montatore video professionista. Ricevi la trascrizione di un video: ogni parola ha un numero (indice) e il tempo in "
                  "secondi tra parentesi quadre all'inizio di ogni riga. Prepara il montaggio seguendo lo STILE indicato, usando SOLO gli indici "
                  "delle parole per dire dove. Regole:\n"
                  "- cuts: togli errori, frasi ricominciate, ripetizioni, balbettii e parti morte o fuori tema. Mai tagliare a metà di un concetto "
                  "utile. Il taglio va dalla prima all'ultima parola da togliere (comprese).\n"
                  "- zooms: sulle frasi forti, i numeri, le promesse, le battute. Ognuno da 1,5 a 6 secondi, mai sovrapposti.\n"
                  "- texts: scritte a schermo BREVISSIME (1-5 parole), nella lingua del video, che rinforzano il concetto (numeri, parole chiave).\n"
                  "- graphics: immagini da generare con l'AI per illustrare un concetto; prompt in inglese, descrivi UN soggetto concreto "
                  "(niente testo o scritte nell'immagine). place: \"centro\" = sticker sopra il video, \"alto\" = piccolo in alto, \"pieno\" = copre tutto (b-roll).\n"
                  "- Distribuisci tutto lungo il video, non solo all'inizio. Non mettere zoom, scritte o grafiche dentro parti che tagli.\n"
                  "Rispondi SOLO con JSON:\n" + PLAN_SCHEMA)
        sty = json.dumps({k: style.get(k) for k in ("summary", "pace", "zoom", "texts", "graphics", "broll", "hook", "rules")}, ensure_ascii=False)
        ask = (f"STILE:\n{sty}\n\nQuantità indicative per tutto il video ({minutes:.1f} minuti): circa {n_z} zoom, {n_t} scritte, {n_g} grafiche. "
               + ("Tagli: sì. " if opts.get("cuts", True) else "Tagli: NO, lista cuts vuota. ")
               + ("" if n_z else "Zoom: NO. ") + ("" if n_t else "Scritte: NO. ") + ("" if n_g else "Grafiche: NO. ")
               + (f"\nRICHIESTA DELL'UTENTE (ha la precedenza): {prompt.strip()[:800]}" if (prompt or "").strip() else ""))
        parts = list(_chunks(words))
        for ci, (off, ws) in enumerate(parts):
            if cancel and cancel():
                raise ai.AIError("Annullato")
            if progress:
                progress(0.1 + 0.8 * ci / len(parts), "L'AI prepara il montaggio" + (f" ({ci + 1}/{len(parts)})" if len(parts) > 1 else ""))
            lines, cur, last = [], [], None
            for i, w in enumerate(ws):
                gi = off + i
                if last is None or w["a"] - last > 0.9 or len(cur) >= 14:
                    if cur:
                        lines.append(" ".join(cur))
                    cur = [f"[{w['a']:.1f}]"]
                cur.append(f"{gi}:{w['w']}")
                last = w["b"]
            if cur:
                lines.append(" ".join(cur))
            frac = len(ws) / len(words)
            part = f"\nPARTE {ci + 1} di {len(parts)} del video: usa circa il {round(frac * 100)}% delle quantità." if len(parts) > 1 else ""
            user = ask + part + "\n\nTRASCRIZIONE:\n" + "\n".join(lines)
            raw = ai.text(cfg, system, user, max_tokens=6000, cancel=cancel)
            usd += ai.text_usd(cfg.get("model"), system, user, raw)
            try:
                obj = ai.parse_json(raw)
            except Exception:
                raise ai.AIError("L'AI ha risposto in modo non leggibile: riprova")
            summary = summary or str(obj.get("summary") or "")
            items += _items_from(obj, words, off, off + len(ws) - 1, opts, style, rs)
    items = _tidy(items, dur)
    for n, it in enumerate(items):
        it["id"] = f"i{n}"
    return {"summary": summary, "items": items, "usd": round(usd, 4), "words": len(words)}


def _items_from(obj, words, lo, hi, opts, style, rs):
    out = []

    def rng(x):
        try:
            i, j = int(x.get("from")), int(x.get("to", x.get("from")))
        except (TypeError, ValueError):
            return None
        i, j = max(lo, min(hi, i)), max(lo, min(hi, j))
        if j < i:
            i, j = j, i
        return words[i]["a"], words[j]["b"]
    if opts.get("cuts", True):
        for x in obj.get("cuts") or []:
            r = rng(x) if isinstance(x, dict) else None
            if r and 0.15 < r[1] - r[0] < 90:
                out.append({"type": "cut", "a": round(r[0] - 0.04, 3), "b": round(r[1] + 0.04, 3), "why": str(x.get("why") or "")[:60],
                            "text": " ".join(w["w"] for w in words if r[0] <= w["a"] and w["b"] <= r[1])[:160]})
    if opts.get("zooms", True):
        for x in obj.get("zooms") or []:
            r = rng(x) if isinstance(x, dict) else None
            if r:
                a, b = r[0], max(r[1], r[0] + 1.5)
                b = min(b, a + 6)
                out.append({"type": "zoom", "a": round(a, 3), "b": round(b, 3), "why": str(x.get("why") or "")[:80],
                            "level": (style.get("zoom") or {}).get("level", 1.25), "style": (style.get("zoom") or {}).get("style", "scatto")})
    if opts.get("texts", True):
        for x in obj.get("texts") or []:
            r = rng(x) if isinstance(x, dict) else None
            txt = str((x or {}).get("text") or "").strip()[:40]
            if r and txt:
                out.append({"type": "text", "a": round(r[0], 3), "b": round(max(r[1], r[0] + 1.2), 3), "text": txt, "why": str(x.get("why") or "")[:80]})
    if opts.get("graphics", True):
        ps = (style.get("graphics") or {}).get("prompt_style") or ""
        for x in obj.get("graphics") or []:
            r = rng(x) if isinstance(x, dict) else None
            pr = str((x or {}).get("prompt") or "").strip()[:400]
            if r and pr:
                place = x.get("place") if x.get("place") in ("centro", "alto", "pieno") else "centro"
                out.append({"type": "graphic", "a": round(r[0], 3), "b": round(min(max(r[1], r[0] + 1.5), r[0] + 5), 3), "prompt": pr,
                            "style": ps, "place": place, "why": str(x.get("why") or "")[:80]})
    return out


def _tidy(items, dur):
    """Niente sovrapposizioni dove non servono, niente effetti dentro le parti tagliate, ordine per tempo."""
    cuts = sorted([(i["a"], i["b"]) for i in items if i["type"] in ("cut", "pause")])
    merged = []
    for a, b in cuts:
        if merged and a <= merged[-1][1] + 0.02:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    cut_in = lambda t: any(a <= t <= b for a, b in merged)
    out, zooms = [], []
    for it in sorted(items, key=lambda x: (x["a"], x["type"])):
        it["a"], it["b"] = max(0.0, it["a"]), min(dur, it["b"])
        if it["b"] - it["a"] < 0.1:
            continue
        if it["type"] in ("zoom", "text", "graphic") and cut_in((it["a"] + it["b"]) / 2):
            continue
        if it["type"] == "zoom":
            if zooms and it["a"] < zooms[-1]["b"] + 0.3:
                continue
            zooms.append(it)
        out.append(it)
    return out


def subs_patch(style, vertical):
    """Lo stile dei sottotitoli per l'editor (subStyle)."""
    c = style.get("captions") or {}
    size = {"piccoli": (0.045, 0.030), "medi": (0.058, 0.040), "grandi": (0.075, 0.052)}[c.get("size") or "medi"][1 if vertical else 0]
    y = {"centro": (0.62, 0.62), "basso": (0.88, 0.74)}[c.get("position") or "basso"][1 if vertical else 0]
    mc = {"parola": 1, "poche": 18, "frase": 22 if vertical else 38}[c.get("mode") or "poche"]
    return {"font": c.get("font") or "Montserrat", "size": size, "y": y, "maxChars": mc, "upper": bool(c.get("upper")),
            "color": c.get("color") or "#FFFFFF", "hiColor": c.get("highlight") or "#FFD60A", "effect": c.get("effect") or "none",
            "box": bool(c.get("box")), "boxColor": "#000000", "boxOp": 65, "stroke": bool(c.get("stroke", True)), "strokeColor": "#000000",
            "strokeW": 0.12, "bold": True, "shadow": not c.get("box")}


# ------------------------------------------------------------------ grafiche generate (anche con lo sfondo trasparente)
GREEN = "on a solid pure bright green (#00FF00) background, isolated subject, no shadow on the background, nothing else"


def key_green(src, dst):
    """Toglie lo sfondo verde (chroma key) e salva un PNG trasparente, con i bordi puliti."""
    import cv2
    import numpy as np
    im = cv2.imread(src, cv2.IMREAD_COLOR)
    if im is None:
        raise ai.AIError("Immagine non leggibile")
    f = im.astype(np.float32)
    b, g, r = f[..., 0], f[..., 1], f[..., 2]
    gv = g - np.maximum(r, b)                      # quanto e' "verde" il pixel
    alpha = 1.0 - np.clip((gv - 40.0) / 70.0, 0.0, 1.0)
    alpha = cv2.GaussianBlur(alpha, (3, 3), 0)
    # niente alone verde sui bordi (despill)
    g2 = np.minimum(g, np.maximum(r, b) + 12)
    out = np.dstack([b, g2, r, alpha * 255.0]).clip(0, 255).astype(np.uint8)
    ys, xs = np.where(alpha > 0.05)
    if len(xs):
        pad = 6
        y0, y1 = max(0, ys.min() - pad), min(out.shape[0], ys.max() + pad)
        x0, x1 = max(0, xs.min() - pad), min(out.shape[1], xs.max() + pad)
        out = out[y0:y1, x0:x1]
    cv2.imwrite(dst, out)
    return dst


def graphic(cfg, it, outdir, vertical, cancel=None):
    """Crea la grafica di un elemento del piano -> percorso del file (PNG)."""
    os.makedirs(outdir, exist_ok=True)
    full = it.get("place") == "pieno"
    style = (it.get("style") or "").strip()
    prompt = it["prompt"].rstrip(".") + ". " + (style + ". " if style else "")
    if full:
        prompt += "Full frame cinematic shot. " + ai.NO_TEXT
        ratio = "9:16" if vertical else "16:9"
    else:
        prompt += GREEN + ". " + ai.NO_TEXT
        ratio = "1:1"
    b, ext = ai.image(cfg, prompt, None, ratio=ratio, cancel=cancel)
    import secrets
    base = os.path.join(outdir, "ai_" + secrets.token_hex(4))
    raw = base + ext
    with open(raw, "wb") as f:
        f.write(b)
    if full:
        return raw
    png = key_green(raw, base + "_trasparente.png")
    try:
        os.remove(raw)
    except OSError:
        pass
    return png


# ------------------------------------------------------------------ stile delle immagini (reference per le Storie AI)
def _small(path, out, side=640):
    import cv2
    im = cv2.imread(path, cv2.IMREAD_COLOR)
    if im is None:
        return None
    h, w = im.shape[:2]
    k = side / max(h, w)
    if k < 1:
        im = cv2.resize(im, (int(w * k), int(h * k)), interpolation=cv2.INTER_AREA)
    cv2.imwrite(out, im, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return out


def analyze_image_style(fm, cfg, cancel=None):
    """Le immagini di riferimento -> lo stile visivo in un prompt (inglese) da usare come stile di una pagina delle Storie AI."""
    from . import formats as FM
    imgs = [v["path"] for v in fm.get("videos") or [] if v.get("image") and v.get("path") and os.path.isfile(v["path"])][:10]
    if not imgs:
        raise ai.AIError("Carica almeno un'immagine di riferimento")
    d = os.path.join(FM._dir(fm["id"]), "stile-immagini")
    os.makedirs(d, exist_ok=True)
    small = [x for x in (_small(p, os.path.join(d, f"{i}.jpg")) for i, p in enumerate(imgs)) if x]
    system = ("Sei un art director. Guarda le immagini di riferimento e descrivi lo STILE VISIVO comune (non il contenuto), così che un generatore "
              "di immagini possa creare immagini nuove nello stesso stile: tecnica (foto, 3D, anime, illustrazione…), luce, colori, grana, "
              "inquadrature, atmosfera, dettagli ricorrenti. Rispondi SOLO con JSON:\n"
              '{"summary": "2 frasi in italiano sullo stile", "prompt": "style prompt in English, 40-80 words, only style (no subject)",'
              ' "palette": ["#RRGGBB", "... 3-6 colori"], "rules": ["3-5 regole in italiano, es. inquadrature strette sui volti"]}')
    raw = ai.text(cfg, system, f"{len(small)} immagini di riferimento. Categoria: {fm.get('niche') or '-'}", max_tokens=1500, cancel=cancel, images=small)
    st = ai.parse_json(raw)
    if not isinstance(st, dict) or not st.get("prompt"):
        raise ai.AIError("L'AI non ha risposto con uno stile valido: riprova")
    pal = [x for x in (st.get("palette") or []) if isinstance(x, str) and re.match(r"^#[0-9a-fA-F]{6}$", x)][:6]
    return {"summary": str(st.get("summary") or "")[:500], "prompt": str(st["prompt"])[:800], "palette": pal,
            "rules": [str(x)[:200] for x in (st.get("rules") or [])][:6], "images": len(small)}
