// Notifiche del team: campanella in alto (accanto alla foto profilo) con il pannello, e in home al massimo
// una pillola compatta per la cosa più importante non ancora letta. Li sceglie il server di NoonFrame (pannello admin).
// Qui si mostrano solo come testo: niente HTML dal server.
import { get, post, h, icon } from './lib.js';
import { LANG } from './i18n.js';

const KIND = {
  reply: ['reply', 'Risposta del team'],
  update: ['sparkle', 'Novità'],
  warning: ['alert', 'Avviso'],
  info: ['info', 'Dal team'],
};
const N = { list: [], at: 0, busy: null, signed: false, subs: new Set() };
const emit = () => N.subs.forEach((f) => { try { f(); } catch (e) { /* */ } });
const unread = () => N.list.filter((m) => !m.seen);

function load(force) {
  if (N.busy) return N.busy;
  if (!force && Date.now() - N.at < 120000) return Promise.resolve(N.list);
  N.busy = get('/api/messages').then((r) => { N.list = (r && r.list) || []; N.signed = !!(r && r.signedIn); N.at = Date.now(); emit(); return N.list; })
    .catch(() => N.list).finally(() => { N.busy = null; });
  return N.busy;
}
function markSeen(ids) {
  const todo = N.list.filter((m) => ids.includes(m.id) && !m.seen);
  if (!todo.length) return;
  todo.forEach((m) => { m.seen = true; post('/api/messages/seen', { id: m.id }).catch(() => {}); });
  emit();
}
function remove(id) {
  N.list = N.list.filter((m) => m.id !== id); emit();
  post('/api/messages/seen', { id, dismiss: true }).catch(() => {});
}
function ago(iso) {
  const s = (Date.now() - new Date(iso)) / 1000, en = LANG === 'en';
  if (!(s >= 0)) return '';
  if (s < 90) return en ? 'just now' : 'adesso';
  if (s < 3600) return Math.round(s / 60) + (en ? ' min ago' : ' min fa');
  if (s < 86400) return Math.round(s / 3600) + (en ? ' h ago' : ' h fa');
  const d = Math.round(s / 86400);
  if (d < 7) return d === 1 ? (en ? 'yesterday' : 'ieri') : d + (en ? ' days ago' : ' giorni fa');
  return new Date(iso).toLocaleDateString(en ? 'en-GB' : 'it-IT', { day: 'numeric', month: 'short' });
}
const openUrl = (url) => post('/api/openurl', { url }).catch(() => {});

// ----------------------------------------------------------------- campanella nella barra in alto
export function notifButton() {
  const dot = h('span', { class: 'nf-badge', hidden: true });
  const b = h('button', { class: 'nf-btn', 'aria-label': 'Notifiche', 'data-tip': 'Notifiche', hidden: true }, icon('bell', 16, 'currentColor', 2), dot);
  const paint = () => {
    if (!b.isConnected && b._painted) { N.subs.delete(paint); return; }
    b._painted = true;
    const n = unread().length;
    b.hidden = !N.signed;
    dot.hidden = !n; dot.textContent = n > 9 ? '9+' : String(n);
    b.setAttribute('aria-label', n ? 'Notifiche: ' + n + ' da leggere' : 'Notifiche');
  };
  N.subs.add(paint);
  b.addEventListener('click', () => openPanel(b));
  load().then(() => { paint(); if (b.isConnected && !b.hidden) setTimeout(() => maybeToast(b), 900); });
  return b;
}

export function openPanel(anchor) {
  const old = document.querySelector('.nf-panel');
  if (old) { old._close(); return; }
  anchor = anchor && anchor.isConnected ? anchor : document.querySelector('.nf-btn:not([hidden])') || document.querySelector('.acct-btn');
  const r = anchor ? anchor.getBoundingClientRect() : { bottom: 52, right: innerWidth - 16 };
  const listEl = h('div', { class: 'nf-items' });
  const allBtn = h('button', { class: 'nf-all', onclick: () => markSeen(N.list.map((m) => m.id)) }, 'Segna tutte come lette');
  const p = h('div', { class: 'nf-panel', role: 'dialog', 'aria-label': 'Notifiche', style: { top: (r.bottom + 8) + 'px', right: Math.max(8, innerWidth - r.right - 6) + 'px' } },
    h('div', { class: 'nf-head' }, h('b', null, 'Notifiche'), allBtn), listEl);
  const item = (m) => {
    const [ic, label] = KIND[m.kind] || KIND.info;
    const body = m.body ? h('p', { class: 'nf-body', 'data-notr': '' }, m.body) : null;
    const long = m.body && (m.body.length > 140 || m.body.split('\n').length > 2);
    return h('article', { class: 'nf-it k-' + (m.kind || 'info') + (m.seen ? '' : ' new'), onclick: (e) => { if (body && long && !e.target.closest('button')) body.classList.toggle('open'); } },
      h('span', { class: 'nf-ic' }, icon(ic, 15, 'currentColor', 2)),
      h('div', { class: 'nf-main' },
        h('b', { class: 'nf-title', 'data-notr': '' }, m.title),
        body,
        h('div', { class: 'nf-meta' }, h('span', null, label), h('span', null, '·'), h('span', { 'data-notr': '' }, ago(m.at)),
          long ? h('span', { class: 'nf-more' }, '· ', 'Mostra tutto') : null),
        m.url ? h('button', { class: 'nf-cta', 'data-notr': '', onclick: () => openUrl(m.url) }, m.cta || 'Apri', icon('right', 12, 'currentColor', 2.4)) : null),
      h('button', { class: 'nf-x', 'aria-label': 'Rimuovi', 'data-tip': 'Rimuovi', onclick: (e) => { e.stopPropagation(); remove(m.id); } }, icon('x', 12, 'currentColor', 2.2)),
      m.seen ? null : h('span', { class: 'nf-dot', 'aria-hidden': 'true' }));
  };
  const paint = () => {
    allBtn.hidden = !unread().length;
    listEl.replaceChildren(...(N.list.length ? N.list.map(item)
      : [h('div', { class: 'nf-empty' }, h('span', { class: 'nf-empty-ic' }, icon('bell', 20, 'currentColor', 1.8)), h('b', null, 'Nessuna notifica'),
        h('small', null, 'Qui arrivano le risposte del team alle tue segnalazioni e le novità di NoonFrame.'))]));
  };
  const close = () => { p.remove(); N.subs.delete(paint); document.removeEventListener('pointerdown', off, true); document.removeEventListener('keydown', esc); if (anchor) anchor.classList.remove('open'); clearTimeout(t); };
  const off = (e) => { if (!p.contains(e.target) && !(anchor && anchor.contains(e.target))) close(); };
  const esc = (e) => { if (e.key === 'Escape') close(); };
  p._close = close;
  N.subs.add(paint); paint();
  document.body.append(p);
  if (anchor) anchor.classList.add('open');
  setTimeout(() => { document.addEventListener('pointerdown', off, true); document.addEventListener('keydown', esc); }, 0);
  // aperto il pannello, quello che si vede conta come letto (il puntino resta un attimo, poi sparisce)
  const t = setTimeout(() => markSeen(N.list.map((m) => m.id)), 1500);
  load(true);
}

// ----------------------------------------------------------------- notifica nuova: una card discreta sotto la campanella, una volta sola
let toastDone = false;
function seenToasts() { try { return JSON.parse(sessionStorage.getItem('nf.toasted') || '[]'); } catch (e) { return []; } }
function maybeToast(anchor) {
  if (toastDone) return;
  const shown = seenToasts();
  const order = { reply: 0, warning: 1, update: 2, info: 3 };
  const m = unread().filter((x) => !shown.includes(x.id)).sort((a, b) => (order[a.kind] ?? 9) - (order[b.kind] ?? 9))[0];
  if (!m) return;
  toastDone = true;
  try { sessionStorage.setItem('nf.toasted', JSON.stringify(unread().map((x) => x.id))); } catch (e) { /* */ }
  const [ic, label] = KIND[m.kind] || KIND.info;
  const others = unread().length - 1;
  const r = anchor.getBoundingClientRect();
  const close = () => { t.classList.add('out'); setTimeout(() => t.remove(), 220); clearTimeout(timer); };
  const t = h('div', { class: 'nf-toast k-' + (m.kind || 'info'), role: 'status', style: { top: (r.bottom + 10) + 'px', right: Math.max(12, innerWidth - r.right - 8) + 'px' },
    onclick: (e) => { if (e.target.closest('.nf-x')) return; close(); openPanel(anchor); } },
    h('span', { class: 'nf-ic' }, icon(ic, 15, 'currentColor', 2)),
    h('div', { class: 'nf-main' },
      h('div', { class: 'nf-meta' }, h('span', null, m.kind === 'reply' ? 'Il team ti ha risposto' : label), h('span', null, '·'), h('span', { 'data-notr': '' }, ago(m.at))),
      h('b', { class: 'nf-title', 'data-notr': '' }, m.kind === 'reply' ? (m.body || '').replace(/\s+/g, ' ') : m.title),
      m.kind !== 'reply' && m.body ? h('p', { class: 'nf-body', 'data-notr': '' }, m.body) : null,
      others > 0 ? h('small', { class: 'nf-also' }, '+' + others + ' ', others === 1 ? 'altra notifica' : 'altre notifiche') : null),
    h('button', { class: 'nf-x', 'aria-label': 'Chiudi', onclick: close }, icon('x', 12, 'currentColor', 2.2)));
  document.body.append(t);
  const timer = setTimeout(close, 9000);
  t.addEventListener('mouseenter', () => clearTimeout(timer));
}
