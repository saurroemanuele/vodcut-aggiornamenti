"""Formati: si impara da video che funzionano (propri o di altri) per scrivere script dello stesso tipo.

Per ogni video di riferimento l'app, sul computer: trascrive il parlato (Whisper), trova i cambi di inquadratura
(le "visual", con ffmpeg), salva un fotogramma per ogni inquadratura e calcola ritmo e numeri. Poi l'AI (con la
chiave dell'utente) legge tutto e scrive il FORMATO: come aprire, struttura, ritmo, regole, chiusure.

Si impara la struttura, non si copiano le frasi: gli script nuovi sono sempre originali.
Tutto resta in ~/VODcut/formati/<id>: formato.json, LEGGIMI.md (riassunto leggibile) e i fotogrammi.
"""
import json
import os
import re
import secrets
import shutil
import subprocess
import threading
import time

from . import ai
from .util import APP_DIR, NO_WINDOW, ffmpeg_bin, probe

FORMATS_DIR = os.path.join(APP_DIR, "formati")
_LOCKS = {}
_GLOCK = threading.Lock()
KINDS = {"vendita": "Vendita di un'app o prodotto digitale", "ugc": "UGC / recensione", "storia": "Storia / racconto",
         "educativo": "Educativo / consigli", "altro": "Altro"}


def _lock(k):
    with _GLOCK:
        return _LOCKS.setdefault(k, threading.RLock())


def _fid(x):
    x = str(x or "")
    if not re.fullmatch(r"fm[0-9a-f]{8,16}", x):
        raise ValueError("Formato non valido")
    return x


def _dir(fid):
    return os.path.join(FORMATS_DIR, _fid(fid))


def _path(fid):
    return os.path.join(_dir(fid), "formato.json")


def get(fid):
    with open(_path(fid), encoding="utf-8") as f:
        return json.load(f)


def save(fm):
    fm["updated"] = time.time()
    os.makedirs(_dir(fm["id"]), exist_ok=True)
    tmp = _path(fm["id"]) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(fm, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _path(fm["id"]))
    try:
        write_readme(fm)
    except Exception as e:
        print(f"[formati] LEGGIMI non scritto: {e}", flush=True)
    return fm


def _s(v, n):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(v or ""))[:n]


def list_all():
    out = []
    try:
        names = os.listdir(FORMATS_DIR)
    except OSError:
        return out
    for n in names:
        try:
            fm = get(n)
        except Exception:
            continue
        vids = fm.get("videos") or []
        out.append({"id": fm["id"], "name": fm.get("name"), "kind": fm.get("kind"), "videos": len(vids),
                    "ready": sum(1 for v in vids if v.get("status") == "pronto"), "hasPrompt": bool(fm.get("prompt")),
                    "thumb": next((v["thumbs"][0] for v in vids if v.get("thumbs")), None), "updated": fm.get("updated")})
    out.sort(key=lambda x: x.get("updated") or 0, reverse=True)
    return out


def create(name, kind):
    fid = "fm" + secrets.token_hex(5)
    fm = {"id": fid, "name": _s(name, 80).strip() or "Nuovo formato", "kind": kind if kind in KINDS else "altro", "goal": "",
          "created": time.time(), "videos": [], "analysis": None, "prompt": ""}
    return save(fm)


def update(fid, data):
    with _lock(fid):
        fm = get(fid)
        for k, n in (("name", 80), ("goal", 1500), ("prompt", 12000)):
            if k in data:
                fm[k] = _s(data[k], n)
        if data.get("kind") in KINDS:
            fm["kind"] = data["kind"]
        for vd in data.get("videos") or []:
            v = next((x for x in fm["videos"] if x["id"] == vd.get("id")), None)
            if not v:
                continue
            if "views" in vd:
                v["views"] = _s(vd["views"], 20)
            if vd.get("rating") in ("top", "ok", "flop", ""):
                v["rating"] = vd["rating"]
            if "note" in vd:
                v["note"] = _s(vd["note"], 500)
            if "shotsManual" in vd:
                try:
                    v["shotsManual"] = max(1, min(400, int(vd["shotsManual"]))) if str(vd["shotsManual"]).strip() else None
                except (TypeError, ValueError):
                    pass
            if "title" in vd:
                v["title"] = _s(vd["title"], 120)
            if "recount" in vd:
                v["recount"] = bool(vd["recount"])
            if v.get("dur"):
                v["shotLen"] = round(float(v["dur"]) / max(1, v.get("shotsManual") or len(v.get("shots") or [])), 2)
        return save(fm)


def delete(fid):
    d = _dir(fid)
    if os.path.isdir(d):
        shutil.rmtree(d, ignore_errors=True)
    return True


def remove_video(fid, vid):
    with _lock(fid):
        fm = get(fid)
        v = next((x for x in fm["videos"] if x["id"] == vid), None)
        if v:
            fm["videos"].remove(v)
            d = os.path.join(_dir(fid), "video", vid)
            shutil.rmtree(d, ignore_errors=True)
        return save(fm)


SOURCES = {"tiktok": "TikTok", "instagram": "Instagram", "youtube": "YouTube", "file": "File dal computer", "web": "Altro sito"}


def source(v):
    """Da dove viene il video: TikTok, Instagram, YouTube, file dal computer."""
    u = (v.get("url") or "").lower()
    if not u:
        return "file"
    for k, keys in (("tiktok", ("tiktok.com",)), ("instagram", ("instagram.com",)), ("youtube", ("youtube.com", "youtu.be"))):
        if any(x in u for x in keys):
            return k
    return "web"


def _link_title(url):
    """https://www.tiktok.com/@nome/video/123?… -> 'TikTok · @nome'."""
    m = re.search(r"(tiktok|instagram|youtube|youtu)\.[a-z.]+/(@[\w.\-]+)?", url or "")
    if not m:
        return url
    site = {"tiktok": "TikTok", "instagram": "Instagram", "youtube": "YouTube", "youtu": "YouTube"}[m.group(1)]
    return site + (" · " + m.group(2) if m.group(2) else "")


def add_videos(fid, items):
    """items: [{path} o {url}] -> i video entrano in coda (stato 'in coda')."""
    with _lock(fid):
        fm = get(fid)
        added = []
        for it in items[:100]:
            vid = "v" + secrets.token_hex(4)
            src = str(it.get("path") or it.get("url") or "")
            if not src:
                continue
            v = {"id": vid, "title": _s(it.get("title") or (os.path.basename(src) if it.get("path") else _link_title(src)), 120),
                 "path": it.get("path") or "", "url": it.get("url") or "", "status": "in coda", "error": None,
                 "views": "", "rating": "", "note": "", "shotsManual": None, "added": time.time()}
            fm["videos"].append(v)
            added.append(vid)
        save(fm)
    return added


# ------------------------------------------------------------------ analisi di un video (sul computer)
SHOTS_ALGO = 2  # versione del conteggio visual (se cambia, i video vecchi si possono ricontare)


def content_box(path, dur):
    """Parte del fotogramma dove c'e' davvero il video. Nei TikTok spesso il video e' una fascia in mezzo,
    con bande nere, titolo fisso e sottotitoli: se contassimo tutto, i tagli veri sembrerebbero piccoli."""
    try:
        import cv2
        import numpy as np
        cap = cv2.VideoCapture(path)
        W, H = cap.get(cv2.CAP_PROP_FRAME_WIDTH), cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        if not W or not H:
            return None
        frames = []
        n = 48
        for k in range(n):
            cap.set(cv2.CAP_PROP_POS_MSEC, (k + 0.5) * dur / n * 1000)
            ok, fr = cap.read()
            if ok:
                frames.append(cv2.cvtColor(cv2.resize(fr, (90, int(90 * H / W))), cv2.COLOR_BGR2GRAY).astype(np.float32))
        cap.release()
        if len(frames) < 8:
            return None
        sd = np.stack(frames).std(axis=0)
        rows, cols = sd.mean(axis=1), sd.mean(axis=0)
        def span(prof):
            m = prof.max()
            if m < 4:
                return None
            idx = np.where(prof > 0.35 * m)[0]
            return (int(idx[0]), int(idx[-1]) + 1) if len(idx) else None
        r, c = span(rows), span(cols)
        if not r or not c:
            return None
        h, w = sd.shape
        y0, y1, x0, x1 = r[0] / h * H, r[1] / h * H, c[0] / w * W, c[1] / w * W
        if (y1 - y0) * (x1 - x0) < 0.12 * W * H or (y1 - y0) * (x1 - x0) > 0.92 * W * H:
            return None
        bw, bh = int(x1 - x0) // 2 * 2, int(y1 - y0) // 2 * 2
        return (bw, bh, int(x0) // 2 * 2, int(y0) // 2 * 2)
    except Exception:
        return None


def scene_scores(path, dur, box=None):
    """Quanto cambia l'immagine a ogni fotogramma (0-1), solo nella parte utile."""
    vf = (f"crop={box[0]}:{box[1]}:{box[2]}:{box[3]}," if box else "") + "scale=240:-2,select='gte(scene,0)',metadata=print"
    cmd = [ffmpeg_bin(), "-hide_banner", "-nostats", "-i", path, "-an", "-vf", vf, "-f", "null", "-"]
    r = subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW, timeout=max(180, dur * 4))
    txt = r.stderr.decode(errors="ignore")
    P = [float(x) for x in re.findall(r"pts_time:([0-9.]+)", txt)]
    S = [float(x) for x in re.findall(r"scene_score=([0-9.]+)", txt)]
    n = min(len(P), len(S))
    return P[:n], S[:n]


def pick_cuts(P, S, dur, floor=0.08, k=3.0, gap=0.4):
    """Un taglio e' un picco netto rispetto a quello che succede intorno (si adatta a ogni video:
    cartoni, UGC, schermate). Le dissolvenze lunghe contano una volta sola."""
    import numpy as np
    n = len(S)
    if not n:
        return [0.0]
    s = np.array(S)
    fps = n / max(0.5, dur)
    win, loc = max(4, int(fps)), max(3, int(fps * 0.4))
    cuts = [0.0]
    for i in range(n):
        if s[i] < floor:
            continue
        lo, hi = max(0, i - win), min(n, i + win + 1)
        base = float(np.median(np.concatenate([s[lo:i], s[i + 1:hi]]))) if hi - lo > 1 else 0.0
        if s[i] < k * base + 0.04:
            continue
        if s[max(0, i - loc):min(n, i + loc + 1)].max() > s[i]:
            continue
        t = P[i]
        if t - cuts[-1] < gap or t > dur - 0.2:
            continue
        cuts.append(round(t, 2))
    return cuts


def confirm_cuts(path, cuts, box=None):
    """Seconda passata: guarda l'immagine subito prima e subito dopo ogni taglio. Se e' la stessa scena
    (cambia solo il sottotitolo, o il personaggio si muove), non e' una visual nuova."""
    try:
        import cv2
        import numpy as np
        cap = cv2.VideoCapture(path)

        def frame(t):
            cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, t) * 1000)
            ok, f = cap.read()
            if not ok:
                return None
            if box:
                w, h, x, y = box
                f = f[y:y + h, x:x + w]
            f = f[:int(f.shape[0] * 0.78)]            # senza la fascia dei sottotitoli
            g = cv2.cvtColor(cv2.resize(f, (48, 36), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY).astype(np.float32)
            return cv2.GaussianBlur(g, (3, 3), 0)
        out = [cuts[0]]
        for t in cuts[1:]:
            a, b = frame(t - 0.12), frame(t + 0.12)
            if a is None or b is None:
                out.append(t)
                continue
            corr = float(np.corrcoef(a.ravel(), b.ravel())[0, 1]) if a.std() > 1 and b.std() > 1 else 0.0
            if corr > 0.85 and float(np.abs(a - b).mean()) < 20:
                continue
            out.append(t)
        cap.release()
        return out
    except Exception:
        return cuts


def detect_shots(path, dur):
    """Tempi dei cambi di inquadratura (visual). Si analizzano tutti i fotogrammi, solo nella parte utile."""
    box = content_box(path, dur)
    P, S = scene_scores(path, dur, box)
    return confirm_cuts(path, pick_cuts(P, S, dur), box), box


def keyframes(path, shots, dur, outdir, limit=120, box=None):
    os.makedirs(outdir, exist_ok=True)
    files = []
    for k, a in enumerate(shots[:limit]):
        b = shots[k + 1] if k + 1 < len(shots) else dur
        t = min(a + 0.35, a + (b - a) / 2)
        dst = os.path.join(outdir, f"{k + 1:03d}.jpg")
        subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", path, "-frames:v", "1", "-vf", (f"crop={box[0]}:{box[1]}:{box[2]}:{box[3]}," if box else "") + "scale=240:-2",
                        "-q:v", "4", dst], capture_output=True, creationflags=NO_WINDOW, timeout=60)
        if os.path.isfile(dst):
            files.append(dst)
    return files


def contact_sheet(files, shots, dst, cols=8):
    """Tutte le inquadrature in un'immagine sola, con il tempo di ognuna (comoda da leggere a colpo d'occhio)."""
    import cv2
    import numpy as np
    ims = []
    for f, t in zip(files, shots):
        im = cv2.imdecode(np.fromfile(f, dtype=np.uint8), cv2.IMREAD_COLOR)
        if im is None:
            continue
        im = cv2.resize(im, (180, int(180 * im.shape[0] / im.shape[1])))
        cv2.rectangle(im, (0, 0), (62, 20), (0, 0, 0), -1)
        cv2.putText(im, f"{t:.1f}s", (4, 15), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
        ims.append(im)
    if not ims:
        return None
    hmax = max(i.shape[0] for i in ims)
    ims = [cv2.copyMakeBorder(i, 0, hmax - i.shape[0], 0, 0, cv2.BORDER_CONSTANT, value=(20, 20, 20)) for i in ims]
    while len(ims) % cols:
        ims.append(np.full_like(ims[0], 20))
    rows = [np.hstack(ims[r * cols:(r + 1) * cols]) for r in range(len(ims) // cols)]
    ok, buf = cv2.imencode(".jpg", np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 85])
    if ok:
        buf.tofile(dst)
        return dst
    return None


def find_shots(path, dur, vd):
    shots, box = detect_shots(path, dur)
    fd = os.path.join(vd, "fotogrammi")
    shutil.rmtree(fd, ignore_errors=True)
    thumbs = keyframes(path, shots, dur, fd, box=box)
    sheet = contact_sheet(thumbs, shots, os.path.join(vd, "inquadrature.jpg"))
    return shots, thumbs, sheet


def recount(fid, vid):
    """Riconta le visual di un video gia' analizzato (non rifa' la trascrizione)."""
    v = next(x for x in get(fid)["videos"] if x["id"] == vid)
    path = v.get("path")
    if not path or not os.path.isfile(path):
        raise RuntimeError("File del video non trovato")
    dur = float(v.get("dur") or probe(path)["duration"])
    shots, thumbs, sheet = find_shots(path, dur, os.path.join(_dir(fid), "video", vid))
    with _lock(fid):
        cur = get(fid)
        x = next((y for y in cur["videos"] if y["id"] == vid), None)
        if x is not None:
            x.update(shots=shots, thumbs=thumbs, sheet=sheet, shotsAlgo=SHOTS_ALGO, shotsManual=None,
                     shotLen=round(dur / max(1, len(shots)), 2))
            save(cur)
    return len(shots)


def analyze_video(fid, vid, transcribe, download=None, progress=None, cancel=None):
    """Una sola analisi alla volta per video: trascrizione, inquadrature, fotogrammi, numeri."""
    fm = get(fid)
    v = next(x for x in fm["videos"] if x["id"] == vid)
    vd = os.path.join(_dir(fid), "video", vid)
    os.makedirs(vd, exist_ok=True)

    def st(**kw):
        with _lock(fid):
            cur = get(fid)
            x = next((y for y in cur["videos"] if y["id"] == vid), None)
            if x is not None:
                x.update(kw)
                save(cur)
    path = v.get("path")
    if not path and v.get("url"):
        st(status="scarico")
        path, title = download(v["url"], vd)
        st(path=path, title=_s(title, 120) or v["title"])
    if not path or not os.path.isfile(path):
        raise RuntimeError("File del video non trovato")
    dur = probe(path)["duration"]
    st(status="inquadrature", dur=round(dur, 2))
    if progress:
        progress(0.1, "Trovo i cambi di inquadratura")
    shots, thumbs, sheet = find_shots(path, dur, vd)
    st(status="trascrivo", shots=shots, thumbs=thumbs, sheet=sheet, shotsAlgo=SHOTS_ALGO)
    if progress:
        progress(0.35, "Trascrivo il parlato")
    segs, words = [], 0
    try:
        tr = transcribe(path, dur, lambda x: progress and progress(0.35 + 0.6 * x, "Trascrivo il parlato"), cancel)
        for sg in tr.get("segments", []):
            t = " ".join(w.get("w", "") for w in sg.get("words", [])).strip() or sg.get("text", "")
            if t:
                segs.append({"a": round(float(sg.get("a", 0)), 2), "b": round(float(sg.get("b", 0)), 2), "t": t})
                words += len(t.split())
        lang = tr.get("language")
    except Exception as e:
        if "annullato" in str(e).lower():
            raise
        st(status="errore", error="Trascrizione non riuscita: " + str(e)[:200])
        raise
    speech = sum(s["b"] - s["a"] for s in segs) or dur
    st(status="pronto", transcript=segs, lang=lang, words=words, wps=round(words / max(1.0, speech), 2),
       shotLen=round(dur / max(1, len(shots)), 2), hook=" ".join(s["t"] for s in segs if s["a"] < 3.0)[:300], error=None)
    return True


# ------------------------------------------------------------------ riassunto leggibile (anche da Claude)
def _fmt_t(t):
    return f"{int(t // 60)}:{t % 60:04.1f}"


def write_readme(fm):
    L = [f"# Formato: {fm.get('name')}", "", f"Tipo: {KINDS.get(fm.get('kind'), fm.get('kind'))}"]
    if fm.get("goal"):
        L += ["", f"Obiettivo: {fm['goal']}"]
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"]
    if vids:
        avg = lambda k: sum(float(v.get(k) or 0) for v in vids) / len(vids)
        L += ["", f"Video analizzati: {len(vids)} · durata media {avg('dur'):.1f}s · inquadratura media {avg('shotLen'):.2f}s · "
                  f"parole al secondo {avg('wps'):.2f}"]
        L += ["", "Per piattaforma:"]
        for k, name in SOURCES.items():
            g = [v for v in vids if source(v) == k]
            if g:
                a = lambda key: sum(float(v.get(key) or 0) for v in g) / len(g)
                L.append(f"- {name}: {len(g)} video · durata media {a('dur'):.1f}s · una visual ogni {a('shotLen'):.2f}s · parole/s {a('wps'):.2f}")
    for n, v in enumerate(fm.get("videos") or [], 1):
        L += ["", f"## Video {n}: {v.get('title')}", ""]
        meta = [f"stato: {v.get('status')}", f"piattaforma: {SOURCES[source(v)]}"]
        if v.get("dur"):
            nsh = v.get("shotsManual") or len(v.get("shots") or [])
            meta += [f"durata {v['dur']}s", f"visual {nsh}" + (" (a mano)" if v.get("shotsManual") else ""), f"inquadratura media {v.get('shotLen')}s",
                     f"parole/s {v.get('wps')}"]
        for k, lbl in (("views", "views"), ("rating", "risultato"), ("url", "link"), ("note", "note")):
            if v.get(k):
                meta.append(f"{lbl}: {v[k]}")
        L.append(" · ".join(meta))
        if v.get("sheet"):
            L.append(f"Inquadrature (immagine): {os.path.relpath(v['sheet'], _dir(fm['id']))}")
        if v.get("transcript"):
            L += ["", "Trascrizione (con i cambi di inquadratura ▌):"]
            shots = v.get("shots") or []
            segs = v["transcript"]
            for i, sg in enumerate(segs):
                a = sg["a"] if i else 0.0
                b = segs[i + 1]["a"] if i + 1 < len(segs) else 1e9
                cuts = sum(1 for t in shots if a <= t < b)
                L.append(f"- [{_fmt_t(sg['a'])}] {'▌' * cuts} {sg['t']}")
    if fm.get("prompt"):
        L += ["", "## Formato generato", "", fm["prompt"]]
    with open(os.path.join(_dir(fm["id"]), "LEGGIMI.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")


# ------------------------------------------------------------------ l'AI scrive il formato
def dataset_text(fm, max_chars=60000):
    parts = []
    vids = [v for v in fm.get("videos") or [] if v.get("status") == "pronto"]
    order = {"top": 0, "ok": 1, "": 2, "flop": 3}
    vids.sort(key=lambda v: order.get(v.get("rating") or "", 2))
    for n, v in enumerate(vids, 1):
        nsh = v.get("shotsManual") or len(v.get("shots") or [])
        head = (f"VIDEO {n} · {SOURCES[source(v)]} · risultato: {v.get('rating') or 'non indicato'} · views: {v.get('views') or '?'} · durata {v.get('dur')}s · "
                f"{nsh} visual (una ogni {round(float(v.get('dur') or 0) / max(1, nsh), 2)}s) · {v.get('wps')} parole/s" +
                (f" · note: {v['note']}" if v.get("note") else ""))
        tx = "\n".join(f"[{sg['a']:.1f}s] {sg['t']}" for sg in v.get("transcript") or [])
        parts.append(head + "\n" + tx)
    txt = "\n\n".join(parts)
    return txt[:max_chars]


def build_prompt(fm, cfg, cancel=None):
    data = dataset_text(fm)
    if not data.strip():
        raise ai.AIError("Nessun video pronto: aggiungi e analizza almeno 3 video")
    system = ("Sei un analista di contenuti short-form (TikTok, Reels, Shorts). Ricevi trascrizioni con tempi di video di riferimento, "
              "con numero di inquadrature e risultati. Estrai la STRUTTURA che li fa funzionare, senza copiare frasi: dai più peso ai "
              "video con risultato 'top' e views alte, e segnala cosa hanno di diverso i 'flop'. Scrivi in italiano. "
              "Rispondi SOLO con JSON:\n"
              '{"summary": "2-3 frasi: che tipo di video sono e perché funzionano",'
              ' "hooks": ["5-8 tipi di apertura dei primi 2 secondi, descritti come schema (es. \\"Problema diretto: ...\\")"],'
              ' "structure": [{"beat": "nome del passaggio", "share": 0.15, "what": "cosa succede e cosa si dice"}],'
              ' "pacing": {"length_sec": 30, "scene_sec": 2.0, "words_per_sec": 2.6, "notes": "ritmo, pause, cambi"},'
              ' "visuals": ["che tipo di immagini/inquadrature usano e quando cambiano"],'
              ' "cta": ["tipi di chiusura e invito all\'azione"],'
              ' "rules": ["regole di scrittura concrete: lunghezza frasi, tono, persona, parole"],'
              ' "avoid": ["cosa evitare (anche dai flop)"],'
              ' "examples": ["2 script ORIGINALI di esempio (argomento inventato), 60-120 parole, stessa struttura"]}')
    raw = ai.text(cfg, system, f"Tipo di video: {KINDS.get(fm.get('kind'))}. Obiettivo: {fm.get('goal') or '-'}\n\n{data}", max_tokens=8000, cancel=cancel)
    an = ai.parse_json(raw)
    return an, render_prompt(fm, an)


def render_prompt(fm, an):
    """Il formato in testo, pronto da mettere nelle istruzioni di chi scrive gli script (modificabile a mano)."""
    L = [f"FORMATO \"{fm.get('name')}\" — {KINDS.get(fm.get('kind'))}", an.get("summary") or ""]
    if an.get("hooks"):
        L += ["", "APERTURA (scegline una, varia sempre):"] + [f"- {x}" for x in an["hooks"]]
    if an.get("structure"):
        L += ["", "STRUTTURA:"] + [f"- {b.get('beat')} (~{round(float(b.get('share') or 0) * 100)}%): {b.get('what')}" for b in an["structure"] if isinstance(b, dict)]
    p = an.get("pacing") or {}
    if p:
        L += ["", f"RITMO: circa {p.get('length_sec')} secondi, una scena/visual ogni {p.get('scene_sec')} secondi, "
                  f"{p.get('words_per_sec')} parole al secondo. {p.get('notes') or ''}"]
    for key, lbl in (("visuals", "IMMAGINI"), ("cta", "CHIUSURA"), ("rules", "REGOLE"), ("avoid", "DA EVITARE")):
        if an.get(key):
            L += ["", lbl + ":"] + [f"- {x}" for x in an[key]]
    if an.get("examples"):
        L += ["", "ESEMPI DI STRUTTURA (non copiarli, sono solo modelli):"] + [f"---\n{x}" for x in an["examples"]]
    L += ["", "Scrivi sempre testi originali: prendi la struttura, mai le frasi. Non inventare risultati, numeri, recensioni o prezzi."]
    return "\n".join(L)


def scene_sec(fm):
    try:
        v = float(((fm.get("analysis") or {}).get("pacing") or {}).get("scene_sec") or 0)
    except (TypeError, ValueError):
        return None
    return max(1.0, min(6.0, v)) if v else None
