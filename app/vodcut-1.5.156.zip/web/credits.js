// Crediti NoonFrame: carta crediti (menu della foto profilo), store dei piani e delle ricariche, offerte lampo.
// Il listino arriva sempre dal server (lo decide il pannello admin): qui niente prezzi scritti a mano.
import { get, post, h, icon, toast } from './lib.js';
import { LANG } from './i18n.js';

// 1.000 / 12.500 sempre col punto (in italiano Intl non separa i numeri di 4 cifre)
const nf = (n) => String(Math.round(+n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, LANG === 'en' ? ',' : '.');
const eur = (n) => { const v = (+n || 0).toFixed(2); return (LANG === 'en' ? '€' + v : v.replace('.', ',') + ' €'); };
const day = (iso) => { try { return new Date(iso).toLocaleDateString(LANG === 'en' ? 'en-GB' : 'it-IT', { day: 'numeric', month: 'long' }); } catch (e) { return ''; } };

// la moneta dei crediti: un piccolo sole (NoonFrame = mezzogiorno)
const SUN = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="5.2" fill="currentColor"/><g stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/></g></svg>';
export const coin = (size = 14) => { const s = h('span', { class: 'cr-coin', style: { width: size + 'px', height: size + 'px' } }); s.innerHTML = SUN; return s; };

function worth(credits, perUsd) {
  const p = perUsd || 280;
  return { video: Math.floor(credits / Math.ceil(0.42 * p)), img: Math.floor(credits / Math.ceil(0.08 * p)) };
}

function countdown(iso) {
  const el = h('span', { class: 'cr-cd', 'data-notr': '' });
  const end = new Date(iso).getTime();
  const tick = () => {
    if (el._started && !el.isConnected) { clearInterval(el._iv); return; }
    el._started = true;
    let s = Math.max(0, Math.floor((end - Date.now()) / 1000));
    if (s > 3 * 86400) {
      el.textContent = (LANG === 'en' ? 'until ' : 'fino al ') + new Date(end).toLocaleDateString(LANG === 'en' ? 'en-GB' : 'it-IT', { day: 'numeric', month: 'short' });
      return;
    }
    const d = Math.floor(s / 86400); s -= d * 86400;
    const hh = Math.floor(s / 3600); s -= hh * 3600;
    const mm = Math.floor(s / 60); s -= mm * 60;
    const p2 = (x) => String(x).padStart(2, '0');
    el.textContent = d > 0 ? `${d}${LANG === 'en' ? 'd' : 'g'} ${hh}h ${p2(mm)}m` : `${p2(hh)}:${p2(mm)}:${p2(s)}`;
  };
  tick(); el._iv = setInterval(tick, 1000);
  return el;
}

let CAT = null, CAT_AT = 0;
export async function loadCatalog(force) {
  if (!force && CAT && Date.now() - CAT_AT < 3 * 60 * 1000) return CAT;
  CAT = await get('/api/ai/catalog'); CAT_AT = Date.now();
  return CAT;
}

// acquisto: si apre il pagamento sicuro di Lemon Squeezy nel browser; l'app aspetta la conferma e aggiorna i crediti.
// onWait(kind, r, before) mostra l'attesa nella finestra dei crediti
async function buy(kind, id, btn, period, onWait) {
  const was = btn.textContent;
  btn.disabled = true; btn.classList.add('busy');
  let before = null;
  try { const c0 = await loadCatalog(true); before = { balance: c0.balance, plan: c0.plan }; } catch (e) { /* */ }
  try {
    const r = await post('/api/ai/buy', { item: period === 'year' ? { kind, id, period } : { kind, id } });
    if (onWait && (r.opened || r.changed)) onWait(kind, r, before);
    else if (r.changed) toast('Piano cambiato');
  } catch (e) { toast(e.message, true); }
  finally { btn.disabled = false; btn.classList.remove('busy'); btn.textContent = was; }
}

// dopo il pagamento: si controlla il saldo finche' Lemon Squeezy non conferma (al massimo 15 minuti)
function waitPayment(before, onDone, alive) {
  const t0 = Date.now();
  const tick = async () => {
    if (!alive()) return;
    try {
      const c = await loadCatalog(true);
      if (before && (c.balance !== before.balance || c.plan !== before.plan)) { onDone(c); return; }
    } catch (e) { /* riprova */ }
    if (Date.now() - t0 < 15 * 60 * 1000) setTimeout(tick, 4000);
  };
  setTimeout(tick, 3000);
}

// ------------------------------------------------------------------ carta crediti (menu della foto profilo)
const kids = (...a) => a.flat().filter((x) => x != null && x !== false && x !== '');   // replaceChildren scrive "null"

// pagina di Lemon Squeezy dell'abbonamento (carta, fatture, disdetta), aperta nel browser
export async function openPortal(btn) {
  if (btn) btn.disabled = true;
  try { await post('/api/ai/portal', {}); toast('Pagina dell\'abbonamento aperta nel browser'); } catch (e) { toast(e.message, true); }
  if (btn) btn.disabled = false;
}

// profilo: piano attuale, rinnovo o scadenza, crediti e gestione dell'abbonamento
export function planCard() {
  const card = h('section', { class: 'prof-card prof-plan' }, h('h2', null, 'Piano e pagamenti'), h('div', { class: 'cw-skel' }));
  Promise.all([loadCatalog(true), get('/api/ai/substatus').catch(() => ({}))]).then(([c, st]) => {
    if (!c || !c.signedIn) { card.remove(); return; }
    const sub = (st && st.sub) || null;
    const paid = !!(c.plan && c.plan !== 'free');
    const name = c.planName || (((c.catalog || {}).plans || []).find((p) => p.id === c.plan) || {}).name || 'Gratis';
    const when = (iso) => { try { return new Date(iso).toLocaleDateString(LANG === 'en' ? 'en-GB' : 'it-IT', { day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return ''; } };
    const status = sub && sub.status === 'cancelled' && sub.endsAt
      ? h('span', { class: 'v warn' }, h('span', null, 'Disdetto: attivo fino al'), ' ', h('span', { 'data-notr': '' }, when(sub.endsAt)))
      : sub && sub.renewsAt ? h('span', { class: 'v' }, h('span', null, 'Si rinnova il'), ' ', h('span', { 'data-notr': '' }, when(sub.renewsAt)))
        : null;
    const row = (k, v) => h('div', { class: 'prof-row' }, h('span', { class: 'k' }, k), v);
    card.replaceChildren(...kids(h('h2', null, 'Piano e pagamenti'),
      row('Piano', h('span', { class: 'v', 'data-notr': '' }, paid ? name + (sub && sub.period === 'year' ? (LANG === 'en' ? ' · yearly' : ' · annuale') : '') : (LANG === 'en' ? 'Free' : 'Gratis'))),
      status ? row(sub.status === 'cancelled' ? 'Stato' : 'Rinnovo', status) : null,
      row('Crediti', h('span', { class: 'v' }, coin(13), ' ', h('b', { 'data-notr': '' }, nf(c.balance)))),
      h('div', { class: 'prof-plan-acts' },
        paid ? h('button', { class: 'btn', onclick: (e) => openPortal(e.currentTarget) }, icon('card', 14), 'Gestisci abbonamento') : null,
        h('button', { class: 'btn ' + (paid ? 'ghost' : 'primary'), onclick: () => creditsDialog(paid ? 'packs' : 'plans') }, paid ? 'Ricarica crediti' : 'Scegli un piano')),
      paid ? h('p', { class: 'field-note' }, 'Da "Gestisci abbonamento" cambi carta, scarichi le fatture o disdici: il piano resta attivo fino alla fine del periodo pagato.') : null));
  }).catch(() => card.remove());
  return card;
}

export function walletCard(onOpen) {
  const card = h('div', { class: 'cw' }, h('div', { class: 'cw-skel' }));
  const go = (tab) => { onOpen && onOpen(); creditsDialog(tab); };
  loadCatalog(true).then((c) => {
    if (!c || !c.signedIn) { card.remove(); return; }
    const plans = (c.catalog || {}).plans || [];
    const pl = plans.find((p) => p.id === c.plan);
    const paid = !!(c.plan && c.plan !== 'free');
    const offer = ((c.catalog || {}).offers || [])[0];
    const pop = plans.length >= 3 ? plans[Math.floor(plans.length / 2)] : plans[0];
    // crediti del mese: barra sottile (solo con un piano)
    const used = paid && pl && pl.monthly ? Math.max(0, Math.min(1, (c.monthly || 0) / pl.monthly)) : 0;
    card.replaceChildren(...kids(
      h('div', { class: 'cw-top' },
        h('div', { class: 'cw-num' }, coin(20), h('b', { 'data-notr': '' }, nf(c.balance))),
        h('span', { class: 'cw-plan' + (paid ? ' paid' : '') }, paid ? h('span', { 'data-notr': '' }, c.planName || (plans.find((p) => p.id === c.plan) || {}).name || (c.plan[0].toUpperCase() + c.plan.slice(1))) : 'Gratis')),
      h('div', { class: 'cw-lbl' }, 'crediti disponibili'),
      paid && pl ? h('div', { class: 'cw-meter' },
        h('div', { class: 'cw-bar' }, h('i', { style: { width: (used * 100).toFixed(1) + '%' } })),
        h('div', { class: 'cw-meta' }, h('span', null, h('span', { 'data-notr': '' }, nf(c.monthly) + ' / ' + nf(pl.monthly)), ' ', h('span', null, 'del mese')),
          c.nextGrant ? h('span', null, h('span', null, 'rinnovo'), ' ', h('span', { 'data-notr': '' }, day(c.nextGrant))) : null)) : null,
      paid && c.extra ? h('div', { class: 'cw-extra' }, h('span', { 'data-notr': '' }, '+' + nf(c.extra)), ' ', h('span', null, 'crediti extra che non scadono')) : null,
      offer ? h('button', { class: 'cw-offer', onclick: () => go() },
        h('span', { class: 'cw-o-ic' }, icon('bolt', 11, 'currentColor', 2.6)), h('span', { class: 'cw-o-t', 'data-notr': '' }, offer.title), countdown(offer.endsAt)) : null,
      c.on === false ? h('div', { class: 'cw-keys' }, h('span', null, 'L\'AI ora usa le tue chiavi'),
        h('button', { class: 'linkish', onclick: async (e) => { e.stopPropagation(); try { await post('/api/ai/credits', { on: true }); toast('Crediti attivi'); onOpen && onOpen(); } catch (er) { toast(er.message, true); } } }, 'Usa i crediti')) : null,
      paid
        ? h('div', { class: 'cw-act' }, h('button', { class: 'cw-btn main', onclick: () => go('packs') }, 'Ricarica'), h('button', { class: 'cw-btn', onclick: () => go('plans') }, 'Cambia piano'))
        : null,
      paid ? h('button', { class: 'cw-link', onclick: (e) => { onOpen && onOpen(); openPortal(e.currentTarget); } }, 'Gestisci abbonamento: carta, fatture, disdetta')
        : null,
      paid ? null
        : h('div', { class: 'cw-act one' },
          h('button', { class: 'cw-btn main', onclick: () => go('plans') }, pop ? 'Passa a ' + pop.name + ' · ' + eur(pop.price) + (LANG === 'en' ? '/mo' : '/mese') : 'Scegli un piano'),
          h('button', { class: 'cw-link', onclick: () => go('packs') }, 'oppure ricarica i crediti'))));
  }).catch(() => card.remove());
  return card;
}

// ------------------------------------------------------------------ store: piani e ricariche
export async function creditsDialog(tab) {
  const bg = h('div', { class: 'modal-bg cs-bg' });
  const sheet = h('div', { class: 'cs', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Crediti NoonFrame' }, h('div', { class: 'cs-load' }, h('div', { class: 'spinner' })));
  let open = true;
  const close = () => { open = false; bg.remove(); document.removeEventListener('keydown', onKey, true); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  document.addEventListener('keydown', onKey, true);
  bg.append(sheet);
  bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
  document.body.append(bg);
  let c;
  try { c = await loadCatalog(true); } catch (e) { sheet.replaceChildren(h('p', { class: 'cs-err' }, e.message)); return; }
  const x = h('button', { class: 'cs-x', 'aria-label': 'Chiudi', onclick: close }, icon('x', 15, 'currentColor', 2.2));
  if (!c.signedIn) {
    sheet.replaceChildren(x, h('div', { class: 'cs-empty' }, coin(34), h('h2', null, 'Accedi per usare i crediti'), h('p', null, 'I crediti sono legati al tuo account: accedi dalla foto profilo in alto a destra.')));
    return;
  }
  const cat = c.catalog || {}, per = c.creditsPerUsd || 280, cur = c.plan || 'free';
  const plans = cat.plans || [], packs = cat.packs || [], offers = cat.offers || [];
  let mode = tab === 'packs' && packs.length ? 'packs' : 'plans';
  const popular = plans.length >= 3 ? plans[Math.floor(plans.length / 2)].id : (plans[0] || {}).id;
  let selPlan = (plans.find((p) => cur === 'free' && p.id === popular) || plans.find((p) => p.id !== cur) || plans[0] || {}).id;
  let selPack = (packs[Math.min(1, packs.length - 1)] || {}).id;

  const list = h('div', { class: 'cs-list', role: 'radiogroup' });
  const cta = h('button', { class: 'cs-cta' });
  const fine = h('p', { class: 'cs-fine' });
  const tabs = h('div', { class: 'cs-tabs', role: 'tablist' });
  // mensile o annuale (solo se il pannello admin ha messo un prezzo annuale)
  const hasYear = plans.some((p) => p.priceYear);
  let period = 'month';
  const per2 = h('div', { class: 'cs-period', role: 'radiogroup', 'aria-label': 'Pagamento' });
  const saveOf = (p) => (p.priceYear && p.price ? Math.round((1 - p.priceYear / (p.price * 12)) * 100) : 0);
  const maxSave = Math.max(0, ...plans.map(saveOf));

  function paint() {
    tabs.replaceChildren(...[['plans', 'Abbonamenti'], ['packs', 'Ricariche']].filter(([k]) => (k === 'plans' ? plans : packs).length).map(([k, l]) =>
      h('button', { role: 'tab', 'aria-selected': String(mode === k), class: mode === k ? 'on' : '', onclick: () => { mode = k; paint(); } }, l)));
    per2.style.display = mode === 'plans' && hasYear ? '' : 'none';
    per2.replaceChildren(...[['month', 'Mensile'], ['year', 'Annuale']].map(([k, l]) => h('button', { role: 'radio', 'aria-checked': String(period === k), class: period === k ? 'on' : '',
      onclick: () => { period = k; paint(); } }, l, k === 'year' && maxSave > 0 ? h('em', null, '−' + maxSave + '%') : null)));
    const yearly = period === 'year';
    if (mode === 'plans') {
      list.replaceChildren(...plans.map((p) => {
        const on = p.id === selPlan, mine = p.id === cur, w = worth(p.monthly, per);
        return h('button', { class: 'cs-row' + (on ? ' on' : '') + (mine ? ' mine' : ''), role: 'radio', 'aria-checked': String(on), onclick: () => { selPlan = p.id; paint(); } },
          h('span', { class: 'cs-radio' }),
          h('span', { class: 'cs-main' },
            h('span', { class: 'cs-name' }, h('b', { 'data-notr': '' }, p.name),
              mine ? h('em', { class: 'tag mine' }, 'Il tuo piano') : p.id === popular && cur === 'free' ? h('em', { class: 'tag' }, 'Il più scelto') : null),
            h('span', { class: 'cs-amt' }, coin(12), h('span', { 'data-notr': '' }, nf(p.monthly)), ' ', h('span', null, 'crediti al mese')),
            on ? h('span', { class: 'cs-more' },
              h('span', null, '≈ ', h('span', { 'data-notr': '' }, String(w.video)), ' ', h('span', null, 'video AI da 5 secondi'), ' · ', h('span', { 'data-notr': '' }, String(w.img)), ' ', h('span', null, 'immagini')),
              ...(p.perks || []).map((k) => h('span', { 'data-notr': '' }, k))) : null),
          yearly && p.priceYear
            ? h('span', { class: 'cs-price' }, h('b', { 'data-notr': '' }, eur(p.priceYear / 12)), h('small', null, 'al mese'),
              h('small', { class: 'cs-yr' }, h('span', { 'data-notr': '' }, eur(p.priceYear)), ' ', h('span', null, 'all\'anno')))
            : h('span', { class: 'cs-price' }, h('b', { 'data-notr': '' }, eur(p.price)), h('small', null, 'al mese')));
      }));
      const p = plans.find((q) => q.id === selPlan) || {};
      const mine = p.id === cur;
      cta.disabled = mine;
      const y = yearly && p.priceYear;
      cta.textContent = mine ? 'È già il tuo piano' : 'Continua con ' + (p.name || '') + ' · ' + (y ? eur(p.priceYear) + (LANG === 'en' ? '/yr' : '/anno') : eur(p.price) + (LANG === 'en' ? '/mo' : '/mese'));
      cta.onclick = () => buy('plan', p.id, cta, y ? 'year' : 'month', waiting);
      fine.textContent = y
        ? 'Paghi una volta all\'anno e risparmi. I crediti arrivano ogni mese, come nel mensile. Prezzi IVA inclusa.'
        : 'Si rinnova ogni mese, disdici quando vuoi. I crediti del mese si azzerano al rinnovo. Prezzi IVA inclusa.';
    } else {
      list.replaceChildren(...packs.map((k) => {
        const on = k.id === selPack, w = worth(k.credits, per);
        return h('button', { class: 'cs-row' + (on ? ' on' : ''), role: 'radio', 'aria-checked': String(on), onclick: () => { selPack = k.id; paint(); } },
          h('span', { class: 'cs-radio' }),
          h('span', { class: 'cs-main' },
            h('span', { class: 'cs-name' }, coin(14), h('b', { 'data-notr': '' }, nf(k.credits)), h('span', { class: 'cs-unit' }, 'crediti')),
            h('span', { class: 'cs-amt dim' }, '≈ ', h('span', { 'data-notr': '' }, String(w.video)), ' ', h('span', null, 'video AI'), ' · ', h('span', { 'data-notr': '' }, String(w.img)), ' ', h('span', null, 'immagini'))),
          h('span', { class: 'cs-price' }, h('b', { 'data-notr': '' }, eur(k.price)), h('small', null, 'una volta')));
      }));
      const k = packs.find((q) => q.id === selPack) || {};
      cta.disabled = false;
      cta.textContent = 'Ricarica ' + nf(k.credits) + ' crediti · ' + eur(k.price);
      cta.onclick = () => buy('pack', k.id, cta, null, waiting);
      fine.textContent = 'I crediti delle ricariche non scadono mai. Prezzi IVA inclusa.';
    }
  }

  const o = offers[0];
  const offerBar = o ? h('div', { class: 'cs-offer' },
    h('span', { class: 'cs-o-ic' }, icon('bolt', 15, 'currentColor', 2.4)),
    h('span', { class: 'cs-o-txt' }, h('b', { 'data-notr': '' }, o.title),
      o.kind === 'plan'
        ? h('span', { 'data-notr': '' }, eur(o.price) + (LANG === 'en' ? '/mo ' : '/mese '), o.fullPrice ? h('s', null, eur(o.fullPrice)) : null)
        : h('span', null, h('span', { 'data-notr': '' }, nf(o.credits)), ' ', h('span', null, 'crediti che non scadono a'), ' ', h('span', { 'data-notr': '' }, eur(o.price)))),
    h('span', { class: 'cs-o-end' }, h('small', null, 'Offerta a tempo'), countdown(o.endsAt)),
    h('button', { class: 'cs-o-btn', onclick: (e) => buy('offer', o.id, e.currentTarget, null, waiting) }, 'Prendi l\'offerta')) : null;

  // attesa del pagamento (aperto nel browser) e conferma
  function waiting(kind, r, before) {
    const msg = h('p', null, r.changed
      ? 'Sto cambiando il tuo piano: Lemon Squeezy conferma in pochi secondi.'
      : 'Completa il pagamento nella pagina che si è aperta nel browser. Appena va a buon fine i crediti arrivano qui da soli.');
    const box = h('div', { class: 'cs-wait' },
      h('div', { class: 'spinner' }), h('h2', null, r.changed ? 'Cambio piano' : 'Pagamento in corso'), msg,
      h('div', { class: 'cs-wait-acts' },
        r.changed ? null : h('button', { class: 'btn ghost sm', onclick: () => { sheet.replaceChildren(...kids(x, head, offerBar, tabs, per2, list, cta, fine)); paint(); } }, 'Torna ai piani'),
        h('button', { class: 'btn ghost sm', onclick: close }, 'Chiudi')),
      h('p', { class: 'cs-fine' }, 'Pagamento sicuro con Lemon Squeezy. Puoi chiudere questa finestra: i crediti arrivano lo stesso.'));
    sheet.replaceChildren(x, box);
    waitPayment(before, (c) => {
      const got = before ? c.balance - before.balance : 0;
      const planNow = c.plan !== (before && before.plan);
      toast(planNow ? 'Piano ' + (c.planName || c.plan) + ' attivo' : got > 0 ? '+' + nf(got) + ' crediti arrivati' : 'Pagamento ricevuto');
      if (!open) return;
      sheet.replaceChildren(x, h('div', { class: 'cs-wait done' }, h('div', { class: 'cs-mark' }, coin(30)),
        h('h2', null, planNow ? 'Piano ' + (c.planName || c.plan) + ' attivo' : 'Pagamento ricevuto'),
        h('p', null, h('span', null, 'Ora hai'), ' ', h('b', { 'data-notr': '' }, nf(c.balance)), ' ', h('span', null, 'crediti')),
        h('button', { class: 'btn primary', onclick: close }, 'Fatto')));
    }, () => true);
  }

  const paid = cur !== 'free';
  const manage = paid ? h('button', { class: 'linkish cs-manage', onclick: (e) => openPortal(e.currentTarget) }, 'Gestisci abbonamento') : null;
  const head = h('div', { class: 'cs-head' },
    h('div', { class: 'cs-glow' }),
    h('div', { class: 'cs-mark' }, coin(26)),
    h('h2', null, 'Più AI, ogni mese'),
    h('p', null, 'Video, immagini e voci generate dentro NoonFrame, senza chiavi da collegare.'),
    h('div', { class: 'cs-bal' }, h('span', null, 'Hai'), coin(12), h('b', { 'data-notr': '' }, nf(c.balance)), h('span', null, 'crediti'),
      paid ? h('span', { class: 'cs-bal-pl' }, h('span', null, 'piano'), ' ', h('span', { 'data-notr': '' }, c.planName || cur)) : null), manage);
  sheet.replaceChildren(...kids(x, head, offerBar, tabs, per2, list, cta, fine));
  paint();
}

// ------------------------------------------------------------------ home: offerta lampo (sottile, si chiude)
export function offerBanner() {
  const box = h('div', { class: 'cr-banner', style: { display: 'none' } });
  loadCatalog().then((c) => {
    const o = ((c.catalog || {}).offers || [])[0];
    if (!o) return;
    try { if (sessionStorage.getItem('nf.offer.hide') === String(o.id)) return; } catch (e) { /* */ }
    box.replaceChildren(...kids(h('span', { class: 'cr-bn-ic' }, icon('bolt', 13, 'currentColor', 2.4)),
      h('b', { 'data-notr': '' }, o.title), o.subtitle ? h('span', { class: 'cr-bn-sub', 'data-notr': '' }, o.subtitle) : null,
      h('span', { class: 'cr-bn-cd' }, countdown(o.endsAt)),
      h('button', { class: 'cr-bn-go', onclick: () => creditsDialog() }, 'Vedi'),
      h('button', { class: 'cr-bn-x', 'aria-label': 'Nascondi', onclick: () => { box.remove(); try { sessionStorage.setItem('nf.offer.hide', String(o.id)); } catch (e) { /* */ } } }, icon('x', 12, 'currentColor', 2.2))));
    box.style.display = '';
  }).catch(() => {});
  return box;
}

// pallino sulla foto profilo quando c'e' un'offerta lampo
export function markOffer(el) {
  loadCatalog().then((c) => { if (((c.catalog || {}).offers || []).length) el.classList.add('has-offer'); }).catch(() => {});
}
