"""Filtri sul video (look di colore ed effetti) con maschera a pixel.

Stessi numeri dell'anteprima (web/fx.js): i look arrivano da web/fx_looks.json.
I filtri lavorano sul video di base, nelle coordinate del VOD: la maschera segue
l'inquadratura anche durante gli zoom.
"""
import json
import math
import os

import cv2
import numpy as np

LOOKS_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web", "fx_looks.json")
_LOOKS = None
LOOK_IDS = ("cine", "vintage", "bw", "warm", "cool", "vivid", "neon", "matte")
EFFECT_IDS = ("blur", "pixel", "glow", "vignette", "grain", "glitch", "vhs")


def looks():
    global _LOOKS
    if _LOOKS is None:
        with open(LOOKS_FILE, encoding="utf-8") as f:
            _LOOKS = {k: v for k, v in json.load(f).items() if not k.startswith("_")}
    return _LOOKS


def sat_matrix(s):
    return np.array([
        [0.213 + 0.787 * s, 0.715 - 0.715 * s, 0.072 - 0.072 * s],
        [0.213 - 0.213 * s, 0.715 + 0.285 * s, 0.072 - 0.072 * s],
        [0.213 - 0.213 * s, 0.715 - 0.715 * s, 0.072 + 0.928 * s]], np.float64)


def look_matrix(lk):
    m = sat_matrix(lk.get("sat", 1.0))
    if lk.get("mix"):
        m = np.array(lk["mix"], np.float64) @ m
    return m


def apply_look(rgb, lk, k):
    """rgb: array (...,3) in 0..1. Come l'anteprima: matrice -> curve -> miscela con l'originale."""
    m = look_matrix(lk)
    v = np.clip(rgb @ m.T, 0, 1)
    xs = np.linspace(0, 1, len(lk["r"]))
    out = np.stack([np.interp(v[..., i], xs, lk[c]) for i, c in enumerate("rgb")], -1)
    return k * out + (1 - k) * rgb


ADJ_KEYS = ("bri", "con", "sat", "temp", "tint", "shad", "high")


def adjust_look(adj):
    """Regola colori: stessi calcoli di web/fx.js adjustLook()."""
    adj = adj or {}

    def v(k):
        try:
            return max(-1.0, min(1.0, float(adj.get(k) or 0) / 100))
        except (TypeError, ValueError):
            return 0.0
    b, c, T, Ti, sh, hi = v("bri"), v("con"), v("temp"), v("tint"), v("shad"), v("high")
    g = 2 ** (-0.9 * b)
    cc = 1 + 0.7 * c if c >= 0 else 1 + 0.5 * c
    curve = []
    for i in range(17):
        y = (i / 16) ** g
        y = 0.5 + (y - 0.5) * cc
        ws = math.sin(math.pi * y / 0.6) if 0 < y < 0.6 else 0.0
        wh = math.sin(math.pi * (y - 0.4) / 0.6) if 0.4 < y < 1 else 0.0
        y += 0.18 * sh * ws + 0.18 * hi * wh
        curve.append(round(max(0.0, min(1.0, y)), 5))
    return {"sat": 1 + v("sat"),
            "mix": [[1 + 0.12 * T + 0.04 * Ti, 0, 0], [0, 1 - 0.08 * Ti, 0], [0, 0, 1 - 0.12 * T + 0.04 * Ti]],
            "r": curve, "g": curve, "b": curve}


def write_cube(path, look_id, k, n=33, adj=None):
    lk = adjust_look(adj) if look_id == "adjust" else looks()[look_id]
    g = np.linspace(0, 1, n)
    b, gg, r = np.meshgrid(g, g, g, indexing="ij")          # r varia piu' in fretta
    rgb = np.stack([r, gg, b], -1).reshape(-1, 3)
    out = apply_look(rgb, lk, k)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"LUT_3D_SIZE {n}\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n")
        f.write("\n".join(f"{x:.6f} {y:.6f} {z:.6f}" for x, y, z in out) + "\n")


def feather_sigma(mask, W, H):
    return float(mask.get("feather", 0.15)) * min(W, H) * 0.25


def mask_image(mask, W, H):
    """Maschera 0..255 alla risoluzione del VOD (bianco = filtro applicato)."""
    t = mask.get("type", "all")
    m = np.zeros((H, W), np.float32)
    if t == "rect":
        x, y, w, h = (mask.get(k, d) for k, d in (("x", .25), ("y", .25), ("w", .5), ("h", .5)))
        cv2.rectangle(m, (int(round(x * W)), int(round(y * H))), (int(round((x + w) * W)) - 1, int(round((y + h) * H)) - 1), 1.0, -1)
    elif t == "ellipse":
        x, y, w, h = (mask.get(k, d) for k, d in (("x", .25), ("y", .25), ("w", .5), ("h", .5)))
        cv2.ellipse(m, (((x + w / 2) * W, (y + h / 2) * H), (w * W, h * H), 0), 1.0, -1, cv2.LINE_AA)
    elif t == "brush":
        for st in mask.get("strokes", []):
            val = 0.0 if st.get("erase") else 1.0
            th = max(1, int(round(st.get("r", 0.03) * W * 2)))
            pts = [(int(round(px * W)), int(round(py * H))) for px, py in st.get("pts", [])]
            if len(pts) == 1:
                cv2.circle(m, pts[0], th // 2, val, -1, cv2.LINE_AA)
            for a, b in zip(pts, pts[1:]):
                cv2.line(m, a, b, val, th, cv2.LINE_AA)
    else:
        m[:] = 1.0
    sig = feather_sigma(mask, W, H) if t != "all" else 0
    if sig > 0.3:
        m = cv2.GaussianBlur(m, (0, 0), sig, borderType=cv2.BORDER_CONSTANT)
    if mask.get("invert") and t != "all":
        m = 1 - m
    return np.clip(m * 255 + 0.5, 0, 255).astype(np.uint8)


def vignette_image(k, W, H):
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    dx, dy = (xx + 0.5 - W / 2) / (W / 2), (yy + 0.5 - H / 2) / (H / 2)
    r = np.sqrt(dx * dx + dy * dy) / math.sqrt(2)
    u = np.clip((r - 0.35) / 0.6, 0, 1)
    f = 1 - k * 0.85 * u * u * (3 - 2 * u)
    return np.clip(f * 255 + 0.5, 0, 255).astype(np.uint8)


def params(typ, k, W):
    """Parametri degli effetti (uguali all'anteprima)."""
    return {
        "blur": {"sigma": max(0.5, k * 0.02 * W)},
        "pixel": {"block": max(2, int(round(k * 0.045 * W)))},
        "glow": {"sigma": 0.012 * W, "op": k * 0.8},
        "vignette": {},
        "grain": {"amt": int(round(k * 28))},
        "glitch": {"d": max(1, int(round(k * 0.008 * W)))},
        "vhs": {"d": max(1, int(round(k * 0.004 * W))), "sat": 1 - 0.25 * k, "sigma": 0.0006 * W, "amt": int(round(k * 14))},
    }.get(typ, {})


def _save_gray(path, img):
    ok, buf = cv2.imencode(".png", img, [cv2.IMWRITE_PNG_COMPRESSION, 1])
    buf.tofile(path)


def graph(filters, W, H, first_input, work, fps, cache, cur="0:v", pre="x"):
    """Filtri attivi su un pezzo, in ordine. Ritorna (argomenti input, righe, etichetta finale)."""
    inputs, lines = [], []
    d = os.path.join(work, "fx")
    os.makedirs(d, exist_ok=True)

    def still(path):
        idx = first_input + len(inputs)
        inputs.append(["-loop", "1", "-framerate", f"{fps:.6f}", "-i", path])
        return f"{idx}:v"

    for n, f in enumerate(filters):
        typ, k = f.get("type"), max(0.0, min(1.0, f.get("k", 100) / 100))
        p = params(typ, k, W)
        mask = f.get("mask") or {"type": "all"}
        masked = mask.get("type", "all") != "all"
        src, out = f"{pre}{n}s", f"{pre}{n}e"
        body = []
        if typ in LOOK_IDS or typ == "adjust":
            adj = f.get("adj") if typ == "adjust" else None
            key = ("cube", typ, round(k, 3), json.dumps(adj, sort_keys=True))
            if key not in cache:
                cache[key] = f"fx/{typ}_{int(k * 1000)}_{len(cache)}.cube"
                write_cube(os.path.join(work, cache[key]), typ, k, adj=adj)
            body.append(f"[{src}]lut3d=file={cache[key]}:interp=tetrahedral[{out}]")
        elif typ == "blur":
            body.append(f"[{src}]gblur=sigma={p['sigma']:.3f}:steps=3[{out}]")
        elif typ == "pixel":
            b = p["block"]
            body.append(f"[{src}]scale=trunc(iw/{b}):trunc(ih/{b}):flags=area,scale={W}:{H}:flags=neighbor[{out}]")
        elif typ == "glow":
            body.append(f"[{src}]format=gbrp,split[{pre}{n}g1][{pre}{n}g2]")
            body.append(f"[{pre}{n}g2]gblur=sigma={p['sigma']:.3f}:steps=3[{pre}{n}g3]")
            body.append(f"[{pre}{n}g1][{pre}{n}g3]blend=all_mode=screen:all_opacity={p['op']:.4f}[{out}]")
        elif typ == "vignette":
            key = ("vig", round(k, 3), W, H)
            if key not in cache:
                cache[key] = os.path.join(d, f"vig_{int(k * 1000)}_{H}.png")
                _save_gray(cache[key], vignette_image(k, W, H))
            vin = still(cache[key])
            body.append(f"[{vin}]format=gbrp[{pre}{n}v]")
            body.append(f"[{src}]format=gbrp[{pre}{n}i]")
            body.append(f"[{pre}{n}i][{pre}{n}v]blend=all_mode=multiply:shortest=1[{out}]")
        elif typ == "grain":
            body.append(f"[{src}]noise=alls={p['amt']}:allf=t+u[{out}]")
        elif typ == "glitch":
            body.append(f"[{src}]format=gbrp,rgbashift=rh=-{p['d']}:bh={p['d']}:edge=smear[{out}]")
        elif typ == "vhs":
            body.append(f"[{src}]format=gbrp,rgbashift=rh=-{p['d']}:bh={p['d']}:edge=smear,eq=saturation={p['sat']:.3f},"
                        f"gblur=sigma={max(0.3, p['sigma']):.3f},noise=alls={p['amt']}:allf=t+u[{out}]")
        else:
            continue
        if masked:
            key = ("mask", f["id"], json.dumps(mask, sort_keys=True), W, H)
            if key not in cache:
                cache[key] = os.path.join(d, f"mask_{f['id']}_{len(cache)}.png")
                _save_gray(cache[key], mask_image(mask, W, H))
            min_ = still(cache[key])
            lines.append(f"[{cur}]format=gbrp,split[{pre}{n}a][{src}]")
            lines += body
            lines.append(f"[{out}]format=gbrp[{pre}{n}c]")
            lines.append(f"[{min_}]format=gray,format=gbrp[{pre}{n}m]")
            lines.append(f"[{pre}{n}a][{pre}{n}c][{pre}{n}m]maskedmerge[{pre}{n}o]")
            cur = f"{pre}{n}o"
        else:
            lines.append(f"[{cur}]null[{src}]")
            lines += body
            cur = out
    return inputs, lines, cur
