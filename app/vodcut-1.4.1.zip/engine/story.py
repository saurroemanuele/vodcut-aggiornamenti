"""Storie con immagini (formato "faceless"): uno script a battute, un'immagine per battuta, testo a schermo.

- parse(): legge lo script ("BATTUTA 1 — IMG 1 / DONNA / Perché…", oppure una battuta per riga)
- durations(): quanto dura ogni battuta, dalla voce (allineando la trascrizione allo script) o dal testo
- make_base(): il video di base (nero, 9:16) lungo quanto la storia, con la voce come audio
- match_images(): abbina le immagini di una cartella numerata agli slot IMG 1, IMG 2…
"""
import difflib
import os
import re
import subprocess
import unicodedata

HEAD = re.compile(r"^\s*(?:BATTUTA|SCENA|LINE|SHOT)\s*(\d+)\s*(?:[—–\-:·|]+\s*(?:IMG|IMMAGINE|IMAGE|FOTO)\s*(\d+))?\s*$", re.I)
IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif")
# movimenti delle immagini (uno diverso per ogni battuta, a giro)
MOTIONS = ["zoomIn", "panL", "zoomOut", "panU", "panR", "zoomIn", "panD", "zoomOut"]


def _is_speaker(line):
    s = line.strip().rstrip(":")
    return 0 < len(s) <= 30 and s.upper() == s and any(ch.isalpha() for ch in s) and len(s.split()) <= 3


def parse(text):
    """-> [{n, img, speaker, text}]"""
    lines = [l.rstrip() for l in (text or "").replace("\r", "").split("\n")]
    out, cur = [], None
    has_heads = any(HEAD.match(l) for l in lines)
    if has_heads:
        for l in lines:
            m = HEAD.match(l)
            if m:
                cur = {"n": int(m.group(1)), "img": int(m.group(2) or m.group(1)), "speaker": "", "text": ""}
                out.append(cur)
                continue
            if cur is None or not l.strip():
                continue
            if not cur["speaker"] and not cur["text"] and _is_speaker(l):
                cur["speaker"] = l.strip().rstrip(":").upper()
            else:
                cur["text"] = (cur["text"] + " " + l.strip()).strip()
        out = [b for b in out if b["text"]]
    else:
        # una battuta per riga, eventualmente "NOME: frase"
        # una frase per riga; il personaggio (facoltativo) si scrive prima: "VOLPE: Forse."
        for l in lines:
            if not l.strip():
                continue
            m = re.match(r"^\s*([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ0-9 ]{0,24}):\s*(.+)$", l)
            sp, tx = (m.group(1).strip().upper(), m.group(2).strip()) if m else ("", l.strip())
            out.append({"n": len(out) + 1, "img": len(out) + 1, "speaker": sp, "text": tx})
    for i, b in enumerate(out):
        b["i"] = i
    return out


def _norm(w):
    w = unicodedata.normalize("NFKD", w.lower())
    w = "".join(ch for ch in w if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]", "", w)


def text_duration(text):
    """Durata di una battuta senza voce: ~2,6 parole al secondo, mai troppo corta."""
    n = len([w for w in re.split(r"\s+", text) if w])
    return round(max(1.4, min(8.0, 0.6 + n * 0.38)), 2)


def estimate(lines):
    t, out = 0.0, []
    for b in lines:
        d = text_duration(b["text"])
        out.append([round(t, 2), round(t + d, 2)])
        t += d
    return out


def align(lines, words, total):
    """Tempi di ogni battuta dalla trascrizione della voce: words = [{w, a, b}] in ordine.
    Le parole dello script si abbinano a quelle trascritte (anche con qualche errore di trascrizione)."""
    sw, owner = [], []
    for i, b in enumerate(lines):
        for w in re.split(r"\s+", b["text"]):
            n = _norm(w)
            if n:
                sw.append(n)
                owner.append(i)
    tw = [_norm(w["w"]) for w in words]
    sm = difflib.SequenceMatcher(None, sw, tw, autojunk=False)
    hit = {}
    for blk in sm.get_matching_blocks():
        for k in range(blk.size):
            hit[blk.a + k] = blk.b + k
    starts, ends = [None] * len(lines), [None] * len(lines)
    for si, ti in sorted(hit.items()):
        i = owner[si]
        if starts[i] is None:
            starts[i] = words[ti]["a"]
        ends[i] = words[ti]["b"]
    # battute senza parole riconosciute: in mezzo alle vicine, in proporzione al testo
    n = len(lines)
    for i in range(n):
        if starts[i] is None:
            prev_end = next((ends[j] for j in range(i - 1, -1, -1) if ends[j] is not None), 0.0)
            nxt = next((starts[j] for j in range(i + 1, n) if starts[j] is not None), None)
            if nxt is None:
                starts[i] = prev_end
                ends[i] = prev_end + text_duration(lines[i]["text"])
            else:
                gap = [j for j in range(i, n) if starts[j] is None and j < next(k for k in range(i + 1, n) if starts[k] is not None)]
                tot = sum(len(lines[j]["text"]) for j in gap) or 1
                t = prev_end
                for j in gap:
                    d = (nxt - prev_end) * len(lines[j]["text"]) / tot
                    starts[j], ends[j] = t, t + d
                    t += d
    # ogni immagine resta fino alla battuta dopo (niente buchi neri); la prima parte da 0
    out = []
    for i in range(n):
        a = 0.0 if i == 0 else out[-1][1]
        b = starts[i + 1] if i + 1 < n else max(ends[i] + 0.6, total)
        b = max(b, a + 0.4)
        out.append([round(a, 2), round(b, 2)])
    return out


def check_voice(lines, words):
    """Cosa si sente nella voce rispetto allo script, battuta per battuta:
    [{heard, missing:[parole dello script non dette], extra:[parole dette in piu'], score}]"""
    sw, owner, disp = [], [], []
    for i, b in enumerate(lines):
        for w in re.split(r"\s+", b["text"]):
            n = _norm(w)
            if n:
                sw.append(n)
                owner.append(i)
                disp.append(w.strip(".,;:!?…\"'«»()"))
    tw = [_norm(w["w"]) for w in words]
    sm = difflib.SequenceMatcher(None, sw, tw, autojunk=False)
    rep = [{"heard": [], "missing": [], "extra": [], "n": 0, "ok": 0} for _ in lines]
    for i in owner:
        rep[i]["n"] += 1
    last_line = 0
    for tag, a0, a1, b0, b1 in sm.get_opcodes():
        if tag == "equal":
            for k in range(a1 - a0):
                i = owner[a0 + k]
                rep[i]["ok"] += 1
                rep[i]["heard"].append(words[b0 + k]["w"])
                last_line = i
        else:
            for k in range(a0, a1):
                rep[owner[k]]["missing"].append(disp[k])
            # parole in piu' (o sbagliate): alla battuta dove siamo arrivati
            tgt = owner[a0] if a0 < len(owner) else last_line
            for k in range(b0, b1):
                rep[tgt]["extra"].append(words[k]["w"].strip())
                rep[tgt]["heard"].append(words[k]["w"])
    out = []
    for r in rep:
        out.append({"heard": " ".join(x.strip() for x in r["heard"]), "missing": r["missing"], "extra": r["extra"],
                    "score": round(r["ok"] / r["n"], 3) if r["n"] else 1.0})
    return out


def _num_key(path):
    name = os.path.splitext(os.path.basename(path))[0]
    nums = re.findall(r"\d+", name)
    return (int(nums[-1]) if nums else 10 ** 9, name.lower())


def list_images(folder):
    try:
        files = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith(IMG_EXT)]
    except OSError:
        return []
    return sorted(files, key=_num_key)


def match_images(files, lines):
    """Immagini numerate (IMG 1 -> il file col numero 1). Se i numeri non tornano, in ordine."""
    by_num = {}
    for f in files:
        k = _num_key(f)[0]
        if k < 10 ** 9 and k not in by_num:
            by_num[k] = f
    if lines and all(b["img"] in by_num for b in lines[: min(3, len(lines))]):
        return [by_num.get(b["img"]) for b in lines]
    return [files[i] if i < len(files) else None for i in range(len(lines))]


def script_words(lines, words):
    """Le parole dello script (scritte giuste) con i tempi della voce: per le didascalie parola per parola.
    -> per ogni battuta [[parola, inizio, fine], ...]"""
    disp, owner, sw = [], [], []
    for i, b in enumerate(lines):
        for w in re.split(r"\s+", b["text"]):
            if w.strip():
                disp.append(w.strip())
                owner.append(i)
                sw.append(_norm(w))
    tw = [_norm(w["w"]) for w in words]
    sm = difflib.SequenceMatcher(None, sw, tw, autojunk=False)
    tim = [None] * len(disp)
    for tag, a0, a1, b0, b1 in sm.get_opcodes():
        if tag == "equal" or (tag == "replace" and a1 - a0 == b1 - b0):
            for k in range(a1 - a0):
                tim[a0 + k] = (float(words[b0 + k]["a"]), float(words[b0 + k]["b"]))
        elif tag == "replace" and b1 > b0:
            # stesse parole dette in modo diverso: il tempo di quel pezzo diviso in parti uguali
            ta, tb = float(words[b0]["a"]), float(words[b1 - 1]["b"])
            n = a1 - a0
            for k in range(n):
                tim[a0 + k] = (ta + (tb - ta) * k / n, ta + (tb - ta) * (k + 1) / n)
    # parole senza tempo: tra la precedente e la successiva
    n = len(disp)
    for k in range(n):
        if tim[k] is None:
            prev = next((tim[j][1] for j in range(k - 1, -1, -1) if tim[j]), 0.0)
            nxt = next((tim[j][0] for j in range(k + 1, n) if tim[j]), prev + 0.4)
            gap = [j for j in range(k, n) if tim[j] is None]
            run = 1
            while k + run < n and tim[k + run] is None:
                run += 1
            step = max(0.08, (nxt - prev) / run)
            for r in range(run):
                tim[k + r] = (prev + step * r, prev + step * (r + 1))
    out = [[] for _ in lines]
    for k in range(n):
        out[owner[k]].append([disp[k], round(tim[k][0], 3), round(tim[k][1], 3)])
    return out


def speech_regions(words, total, pause=0.25, lead=0.08):
    """Parti con la voce (dalle parole trascritte): tra una frase e l'altra resta al massimo 'pause' secondi di silenzio."""
    half = pause / 2
    regs = []
    for w in words:
        a, b = max(0.0, float(w["a"]) - lead), min(total, float(w["b"]) + half)
        a = max(0.0, a - max(0.0, half - lead))
        if regs and a <= regs[-1][1]:
            regs[-1][1] = max(regs[-1][1], b)
        else:
            regs.append([a, b])
    return [[round(a, 3), round(b, 3)] for a, b in regs if b - a > 0.05]


def map_time(regs, t):
    """Tempo nella voce originale -> tempo nella voce senza silenzi."""
    off = 0.0
    for a, b in regs:
        if t < a:
            return round(off, 3)
        if t <= b:
            return round(off + t - a, 3)
        off += b - a
    return round(off, 3)


def trim_times(regs, times):
    total = sum(b - a for a, b in regs)
    out = []
    for i, (a, b) in enumerate(times):
        na = 0.0 if i == 0 else out[-1][1]
        nb = total if i == len(times) - 1 else map_time(regs, b)
        out.append([round(na, 2), round(max(nb, na + 0.3), 2)])
    return out


def trim_audio(src, dst, regs, ffmpeg="ffmpeg", nowin=0, work=None):
    """Voce senza i silenzi lunghi: solo le parti in regs, una dopo l'altra (con 10 ms di dissolvenza per non avere click)."""
    parts = []
    for k, (a, b) in enumerate(regs):
        parts.append(f"[0:a]atrim={a:.3f}:{b:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.01,afade=t=out:st={max(0.0, b - a - 0.01):.3f}:d=0.01[p{k}]")
    graph = ";\n".join(parts) + ";\n" + "".join(f"[p{k}]" for k in range(len(regs))) + f"concat=n={len(regs)}:v=0:a=1[out]"
    fp = os.path.join(work or os.path.dirname(dst), os.path.basename(dst) + ".filter.txt")
    with open(fp, "w", encoding="utf-8") as f:
        f.write(graph)
    from .util import filter_script_args
    r = subprocess.run([ffmpeg, "-nostdin", "-v", "error", "-y", "-i", src, *filter_script_args(fp), "-map", "[out]",
                        "-ac", "2", "-ar", "48000", "-c:a", "pcm_s16le", dst],
                       creationflags=nowin, capture_output=True, stdin=subprocess.DEVNULL, timeout=900)
    if r.returncode != 0:
        raise RuntimeError("Non riesco a togliere i silenzi dalla voce: " + r.stderr.decode(errors="ignore")[-300:])
    try:
        os.remove(fp)
    except OSError:
        pass
    return dst


def make_base(path, W, H, dur, audio=None, ffmpeg="ffmpeg", nowin=0, progress=None):
    """Video nero W x H lungo dur secondi, con la voce (o silenzio) come audio."""
    fps = 30
    cmd = [ffmpeg, "-nostdin", "-v", "error", "-y", "-f", "lavfi", "-i", f"color=c=black:s={W}x{H}:r={fps}:d={dur:.3f}"]
    if audio:
        cmd += ["-i", audio, "-map", "0:v", "-map", "1:a", "-af", f"apad,atrim=0:{dur:.3f}"]
    else:
        cmd += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-map", "0:v", "-map", "1:a"]
    cmd += ["-t", f"{dur:.3f}", "-c:v", "libx264", "-preset", "ultrafast", "-tune", "stillimage", "-crf", "30",
            "-g", "30", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart",
            "-progress", "pipe:1", "-nostats", path]
    p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=nowin)
    for line in p.stdout:
        m = re.match(rb"out_time_ms=(\d+)", line)
        if m and progress and dur:
            progress(min(1.0, int(m.group(1)) / 1e6 / dur))
    err = p.stderr.read().decode(errors="ignore")
    if p.wait() != 0:
        raise RuntimeError("Non riesco a preparare il video: " + err[-300:])
    return path
