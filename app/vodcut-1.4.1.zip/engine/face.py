"""Tracciamento del viso nella webcam (per il formato verticale).

Nel verticale la webcam si ritaglia (es. da 16:9 a quasi quadrata): se lo streamer si sposta di lato
esce dal ritaglio. Qui si cerca la faccia dentro il riquadro webcam ~4 volte al secondo, si riempiono i
buchi, si leviga il movimento (con una zona morta, come un operatore di camera calmo) e si salva il
centro della faccia nel tempo della live, in coordinate 0..1 del video.
Il ritaglio della webcam poi segue quel punto restando sempre dentro il riquadro webcam (shift()).
"""
import json
import os

import numpy as np

STEP = 0.25          # un punto ogni 0.25 s
FPS = 1 / STEP


MODELS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")


class Detector:
    """Trova le facce in un'immagine BGR. Prima YuNet (rete neurale piccola, inclusa nell'app: funziona anche
    con OpenCV 5 che non ha piu' i vecchi CascadeClassifier), se no i classici Haar."""

    def __init__(self):
        import cv2
        self.cv2 = cv2
        self.yn = None
        self.haar = None
        model = os.path.join(MODELS, "face_detection_yunet_2023mar.onnx")
        make = getattr(cv2, "FaceDetectorYN", None)
        make = getattr(make, "create", None) or getattr(cv2, "FaceDetectorYN_create", None)
        if make and os.path.exists(model):
            try:
                self.yn = make(model, "", (320, 320), 0.6, 0.3, 20)
            except Exception:
                self.yn = None
        if self.yn is None and hasattr(cv2, "CascadeClassifier"):
            xml = os.path.join(MODELS, "haarcascade_frontalface_default.xml")
            if not os.path.exists(xml):
                try:
                    xml = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
                except AttributeError:
                    xml = None
            if xml:
                c = cv2.CascadeClassifier(xml)
                if not c.empty():
                    self.haar = c
        if self.yn is None and self.haar is None:
            raise RuntimeError("OpenCV senza rilevamento dei visi")

    def faces(self, bgr):
        """[(x, y, w, h), ...] dalla piu' sicura."""
        cv2 = self.cv2
        h, w = bgr.shape[:2]
        if self.yn is not None:
            self.yn.setInputSize((w, h))
            _, f = self.yn.detect(bgr)
            if f is None:
                return []
            f = sorted(f.tolist(), key=lambda r: -r[-1])
            return [(r[0], r[1], r[2], r[3]) for r in f]
        g = cv2.equalizeHist(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY))
        m = max(18, int(min(w, h) * 0.1))
        return [tuple(r) for r in self.haar.detectMultiScale(g, 1.1, 4, minSize=(m, m))]


_DET = None


def detector():
    global _DET
    if _DET is None:
        _DET = Detector()
    return _DET


def _smooth(vals, win):
    if len(vals) < 3 or win < 2:
        return vals
    k = np.ones(win) / win
    pad = win // 2
    v = np.pad(vals, (pad, win - 1 - pad), mode="edge")
    return np.convolve(v, k, mode="valid")


def _median(vals, win):
    if len(vals) < win:
        return vals
    pad = win // 2
    v = np.pad(vals, (pad, pad), mode="edge")
    return np.array([np.median(v[i:i + win]) for i in range(len(vals))])


def _lazy(vals, dz):
    """Zona morta: la camera si muove solo quando la faccia si allontana davvero."""
    out = np.empty_like(vals)
    cur = vals[0]
    for i, x in enumerate(vals):
        d = x - cur
        if abs(d) > dz:
            cur += d - dz * np.sign(d)
        out[i] = cur
    return out


def clean(raw, cam_w_n, cam_h_n):
    """raw: lista di (x, y) o None -> punti levigati (o None se nella parte non c'e' mai una faccia)."""
    n = len(raw)
    idx = [i for i, p in enumerate(raw) if p is not None]
    if not idx:
        return [None] * n
    xs = np.interp(np.arange(n), idx, [raw[i][0] for i in idx])
    ys = np.interp(np.arange(n), idx, [raw[i][1] for i in idx])
    xs, ys = _median(xs, 5), _median(ys, 5)
    xs, ys = _smooth(xs, 7), _smooth(ys, 7)
    xs, ys = _lazy(xs, cam_w_n * 0.05), _lazy(ys, cam_h_n * 0.05)
    xs, ys = _smooth(xs, 9), _smooth(ys, 9)
    return [[round(float(x), 4), round(float(y), 4)] for x, y in zip(xs, ys)]


def track_range(src, cam, W, H, a, b, ffmpeg, popen, check=lambda: None, on_frame=None):
    """Centro della faccia (0..1 del video) ogni STEP secondi tra a e b (secondi della live)."""
    import subprocess
    det = detector()
    cx, cy, cw, ch = [int(round(v)) for v in cam]
    cx, cy = max(0, cx), max(0, cy)
    cw, ch = max(16, min(cw, W - cx)), max(16, min(ch, H - cy))
    ow = 480
    oh = max(2, int(round(ch * ow / cw / 2)) * 2)
    cmd = [ffmpeg, "-v", "error", "-ss", f"{a:.3f}", "-i", src, "-t", f"{max(0.1, b - a):.3f}", "-an",
           "-vf", f"crop={cw}:{ch}:{cx}:{cy},fps={FPS:g},scale={ow}:{oh}",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    p = popen(cmd, stdout=subprocess.PIPE)
    raw, prev = [], None
    size = ow * oh * 3
    try:
        while True:
            check()
            buf = p.stdout.read(size)
            if len(buf) < size:
                break
            img = np.frombuffer(buf, np.uint8).reshape(oh, ow, 3)
            faces = [f for f in det.faces(img) if f[2] >= ow * 0.06]
            pt = None
            if faces:
                # la faccia piu' vicina a quella di prima (o la piu' sicura)
                if prev is not None:
                    f = min(faces[:4], key=lambda q: (q[0] + q[2] / 2 - prev[0]) ** 2 + (q[1] + q[3] / 2 - prev[1]) ** 2)
                else:
                    f = faces[0]
                fx, fy = f[0] + f[2] / 2, f[1] + f[3] / 2
                prev = (fx, fy)
                pt = ((cx + fx / ow * cw) / W, (cy + fy / oh * ch) / H)
            raw.append(pt)
            if on_frame:
                on_frame(len(raw))
    finally:
        try:
            p.stdout.close()
        except OSError:
            pass
        p.kill()
        p.wait()
    return clean(raw, cw / W, ch / H)


def path_for(pid):
    from .util import CACHE_DIR
    return os.path.join(CACHE_DIR, pid.split("_v")[0] + "_face.json")


def live_ranges(proj, pieces):
    """Le parti della live da analizzare: quelle della clip verticale (o tutta la live), con 1 s di margine."""
    rng = proj.get("ranges") or ([proj["range"]] if proj.get("range") else None) or [[0, proj.get("duration") or 0]]
    out = []
    for a, b in rng:
        for pc in pieces:
            if not pc["live"]:
                continue
            lo, hi = max(a, pc["t0"]), min(b, pc["t1"])
            if hi > lo:
                out.append([max(0.0, pc["off"] + lo - pc["t0"] - 1), pc["off"] + hi - pc["t0"] + 1])
    out.sort()
    merged = []
    for a, b in out:
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return merged


def missing(data, ranges):
    """Le parti non ancora analizzate."""
    done = data.get("done") or []
    out = []
    for a, b in ranges:
        cur = a
        for da, db in sorted(done):
            if db <= cur or da >= b:
                continue
            if da > cur + 0.5:
                out.append([cur, da])
            cur = max(cur, db)
        if b > cur + 0.5:
            out.append([cur, b])
    return out


def load(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))
    os.replace(tmp, path)


def at(data, lt):
    """Centro della faccia (0..1) nel secondo lt della live, o None."""
    pts = (data or {}).get("pts") or {}
    if not pts:
        return None
    k = lt / STEP
    i0 = int(np.floor(k))
    p0, p1 = pts.get(str(i0)), pts.get(str(i0 + 1))
    if p0 and p1:
        f = k - i0
        return [p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f]
    return p0 or p1


def shift(regs, f, cam, W, H):
    """Il ritaglio della webcam segue la faccia f (0..1), senza uscire dal riquadro webcam."""
    if not f or not cam:
        return regs
    fx, fy = f[0] * W, f[1] * H
    x0, y0, cw, ch = cam
    out = []
    for r in regs:
        if r.get("role") == "cam" and not r.get("blur"):
            x, y, w, h = r["s"]
            nx = min(max(x0, fx - w / 2), x0 + cw - w) if w < cw - 0.5 else x
            # un filo di spazio sopra la testa: la faccia un po' sopra il centro
            ny = min(max(y0, fy - h * 0.45), y0 + ch - h) if h < ch - 0.5 else y
            r = dict(r, s=[nx, ny, w, h])
        out.append(r)
    return out
