"""Rilevamento automatico del riquadro webcam in un VOD.

Idea: la webcam e' il punto dove compare sempre una faccia, dentro un riquadro con
bordi che restano fermi per tutta la live (l'overlay). 1) Troviamo le facce su ~24
fotogrammi e prendiamo il gruppo piu' costante. 2) Attorno alla faccia cerchiamo le
linee (verticali/orizzontali) che restano nette in quasi tutti i fotogrammi.
Se qualcosa non torna, restituiamo una stima e l'utente corregge a mano nell'app.
"""
import cv2
import numpy as np


def _sample_frames(path, count=24):
    cap = cv2.VideoCapture(path)
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    frames = []
    for i in range(count):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(n * (i + 0.5) / count))
        ok, f = cap.read()
        if ok:
            frames.append(f)
    cap.release()
    return frames


def _face_cluster(frames):
    try:
        from .face import detector
        det = detector()
    except Exception:  # OpenCV senza rilevamento dei visi: si usano solo i bordi dell'overlay
        return None
    faces = []
    for f in frames:
        H, W = f.shape[:2]
        s = 960 / W
        small = cv2.resize(f, (960, int(H * s)))
        for (x, y, w, h) in det.faces(small):
            if w >= 16:
                faces.append((x / s, y / s, w / s, h / s))
    if not faces:
        return None
    F = np.array(faces)
    centers = F[:, :2] + F[:, 2:] / 2
    # il gruppo piu' popoloso: per ogni faccia conta le vicine
    best, best_n = None, 0
    for c, f in zip(centers, F):
        d = np.linalg.norm(centers - c, axis=1)
        near = d < f[2] * 0.8
        if near.sum() > best_n:
            best_n, best = near.sum(), near
    if best_n < max(3, len(frames) // 5):
        return None
    sel = F[best]
    cx, cy = np.median(centers[best], axis=0)
    size = np.median(sel[:, 2])
    return cx, cy, size, best_n


def detect_webcam(path):
    """Ritorna dict {box:[x,y,w,h], confidence:0-1, width, height}."""
    frames = _sample_frames(path)
    if not frames:
        return None
    H, W = frames[0].shape[:2]
    face = _face_cluster(frames)
    gx_all, gy_all = [], []
    for f in frames:
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32)
        gx_all.append(np.abs(cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)))
        gy_all.append(np.abs(cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)))
    # bordo "persistente": alto anche nei fotogrammi peggiori
    GX = np.percentile(np.stack(gx_all), 25, axis=0)
    GY = np.percentile(np.stack(gy_all), 25, axis=0)
    # i bordi del fotogramma non sono bordi della webcam
    GX[:, :3] = 0; GX[:, -3:] = 0; GY[:3, :] = 0; GY[-3:, :] = 0

    if face is None:
        # nessuna faccia: stima standard in alto a destra
        w = int(W * 0.24); h = int(w * 9 / 16)
        return {"box": [W - w - int(W * 0.01), int(H * 0.01), w, h], "confidence": 0.0, "width": W, "height": H}

    cx, cy, fs, nfaces = face
    conf = min(1.0, nfaces / len(frames))
    # finestra di ricerca attorno alla faccia
    x_lo, x_hi = int(max(0, cx - fs * 4)), int(min(W - 1, cx + fs * 4))
    y_lo, y_hi = int(max(0, cy - fs * 2.5)), int(min(H - 1, cy + fs * 2.5))

    def best_edge(profile, lo, hi, prefer_far):
        seg = profile[lo:hi]
        if len(seg) < 3:
            return None, 0
        thr = np.median(profile) * 3 + 4
        idx = np.where(seg > thr)[0]
        if len(idx) == 0:
            return None, 0
        # tra i candidati prendi il piu' forte, a parita' il piu' lontano dalla faccia
        k = idx[np.argmax(seg[idx] + (idx if prefer_far else -idx) * 0.001)]
        return lo + int(k), float(seg[k])

    # prima alto/basso (colonne attorno alla faccia), poi sinistra/destra misurati
    # su TUTTA l'altezza trovata: il vero bordo e' una linea lunga, oggetti fermi
    # dentro la webcam (microfono, mensole) no.
    cols = slice(int(max(0, cx - fs * 0.8)), int(min(W, cx + fs * 0.8)))
    hprof = GY[:, cols].mean(axis=1)
    top, _ = best_edge(hprof, y_lo, int(cy - fs * 0.55), True)
    bottom, _ = best_edge(hprof, int(cy + fs * 0.55), y_hi, False)
    r0 = (top if top is not None else int(max(0, cy - fs))) + 2
    r1 = (bottom if bottom is not None else int(min(H, cy + fs))) - 2
    # copertura: che frazione della colonna e' "bordo"? il vero bordo ~100%
    band = GX[r0:r1, :]
    cov = (band > 10).mean(axis=0) * (band.mean(axis=0) > 6)

    def cover_edge(lo, hi, outward_left):
        lo, hi = max(0, lo), min(W, hi)
        if hi - lo < 3:
            return None
        c = cov[lo:hi]
        idx = np.where(c > 0.85)[0]
        if len(idx) == 0:
            return None
        # il bordo piu' esterno rispetto alla faccia
        return lo + int(idx.min() if outward_left else idx.max())

    left = cover_edge(x_lo, int(cx - fs * 0.55), True)
    right = cover_edge(int(cx + fs * 0.55), x_hi, False)
    vprof = band.mean(axis=0)
    if left is None:
        left, _ = best_edge(vprof, x_lo, int(cx - fs * 0.55), True)
    if right is None:
        right, _ = best_edge(vprof, int(cx + fs * 0.55), x_hi, False)
    if left is not None and right is not None:
        # ricalcola alto/basso su tutta la larghezza trovata
        hprof2 = GY[:, left + 2:right - 2].mean(axis=1)
        t2, _ = best_edge(hprof2, y_lo, int(cy - fs * 0.55), True)
        b2, _ = best_edge(hprof2, int(cy + fs * 0.55), y_hi, False)
        top = t2 if t2 is not None else top
        bottom = b2 if b2 is not None else bottom

    # completa i lati mancanti con il formato 16:9 o i bordi del fotogramma
    if left is None and right is not None and top is not None and bottom is not None:
        left = right - int((bottom - top) * 16 / 9)
    if right is None and left is not None and top is not None and bottom is not None:
        right = left + int((bottom - top) * 16 / 9)
    if top is None:
        top = 0 if cy < H / 2 else None
    if bottom is None and top is not None and left is not None and right is not None:
        bottom = top + int((right - left) * 9 / 16)
    if None in (left, right, top, bottom):
        w = int(fs * 3.5); h = int(w * 9 / 16)
        return {"box": [int(cx - w / 2), int(cy - h / 2), w, h], "confidence": round(float(conf) * 0.4, 2), "width": W, "height": H}

    left, top = max(0, left + 1), max(0, top + 1)
    right, bottom = min(W, right), min(H, bottom)
    w, h = right - left, bottom - top
    ratio = w / max(1, h)
    if not (1.0 < ratio < 2.4) or w < fs * 1.5:
        conf *= 0.5
    return {"box": [int(left), int(top), int(w), int(h)], "confidence": round(float(conf), 2), "width": W, "height": H}


if __name__ == "__main__":
    import sys, time
    t = time.time()
    print(detect_webcam(sys.argv[1]), f"{time.time() - t:.1f}s")
