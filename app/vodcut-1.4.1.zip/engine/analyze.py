"""Analisi audio: dove parli, dove reagisci -> tagli e zoom proposti.

Legge l'audio a blocchi (va bene anche per VOD di molte ore) e calcola il volume
ogni 50 ms. Le regole sono quelle tarate sul primo test (vedi documento).
"""
import numpy as np

from .util import ffmpeg_bin, popen

HOP = 0.05  # secondi per campione di volume
SR = 16000

CUT_PRESETS = [  # Pochi, Normali, Tanti
    {"min_silence": 8.0, "pad_before": 1.5, "pad_after": 2.0},
    {"min_silence": 4.0, "pad_before": 1.0, "pad_after": 1.2},
    {"min_silence": 2.2, "pad_before": 0.5, "pad_after": 0.7},
]
ZOOM_PRESETS = [
    {"peak_margin_db": 17.0, "zoom_cooldown": 45.0},
    {"peak_margin_db": 14.0, "zoom_cooldown": 8.0},
    {"peak_margin_db": 11.0, "zoom_cooldown": 3.0},
]
BASE = {
    "speech_margin_db": 18.0,
    "peak_min_len": 0.25,
    "zoom_lead": 0.4,
    "zoom_hold_after": 0.5,
    "zoom_bridge_gap": 3.5,
    "zoom_min_len": 2.0,
    "zoom_max_len": 10.0,
    "zoom_merge_gap": 3.0,
}


def loudness_track(path, progress=None, duration=None, cancel=None):
    """Volume in dB ogni HOP secondi, letto in streaming."""
    hop = int(SR * HOP)
    p = popen([ffmpeg_bin(), "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(SR), "-f", "s16le", "-"],
              stdout=__import__("subprocess").PIPE)
    out = []
    buf = b""
    chunk = hop * 2 * 200  # 10 s
    done = 0
    while True:
        if cancel and cancel():
            p.kill()
            raise RuntimeError("annullato")
        data = p.stdout.read(chunk)
        if not data:
            break
        buf += data
        n = len(buf) // (hop * 2)
        if n:
            x = np.frombuffer(buf[: n * hop * 2], np.int16).astype(np.float32) / 32768.0
            r = np.sqrt((x.reshape(n, hop) ** 2).mean(1) + 1e-12)
            out.append(20 * np.log10(r + 1e-9))
            buf = buf[n * hop * 2:]
            done += n * HOP
            if progress and duration:
                progress(min(0.99, done / duration))
    p.wait()
    if not out:
        return np.full(1, -90.0, np.float32)
    return np.concatenate(out).astype(np.float32)


def _smooth(db, sec):
    k = max(1, int(sec / HOP))
    lin = 10 ** (db / 20)
    lin = np.convolve(lin, np.ones(k) / k, mode="same")
    return 20 * np.log10(lin + 1e-9)


def _runs(mask):
    m = np.concatenate([[False], mask, [False]]).astype(np.int8)
    d = np.diff(m)
    return list(zip(np.where(d == 1)[0], np.where(d == -1)[0]))


def _fill_gaps(mask, max_gap):
    mask = mask.copy()
    for a, b in _runs(~mask):
        if a > 0 and b < len(mask) and (b - a) <= max_gap:
            mask[a:b] = True
    return mask


def waveform(db, per_sec=5):
    """Picchi 0..1 per disegnare la forma d'onda (per_sec valori al secondo)."""
    step = max(1, int(1 / (HOP * per_sec)))
    n = len(db) // step
    if n == 0:
        return []
    peaks = db[: n * step].reshape(n, step).max(1)
    v = np.clip((peaks + 60) / 55, 0, 1)
    return [round(float(a), 2) for a in v]


def propose(db, duration, cut_level=1, zoom_level=1):
    C = dict(BASE)
    C.update(CUT_PRESETS[cut_level])
    C.update(ZOOM_PRESETS[zoom_level])
    dbs = _smooth(db, 0.15)
    floor = float(np.percentile(dbs, 10))
    speech_thr = floor + C["speech_margin_db"]
    speech = _fill_gaps(dbs > speech_thr, int(0.5 / HOP))
    voiced = dbs[speech]
    speech_med = float(np.median(voiced)) if len(voiced) else speech_thr
    peak_thr = speech_med + C["peak_margin_db"]

    # --- tagli: solo silenzi lunghi, con contesto ---
    bounds = [(a * HOP, b * HOP) for a, b in _runs(speech)]
    gaps, prev = [], 0.0
    for s, e in bounds:
        gaps.append((prev, s, prev == 0.0, False))
        prev = e
    gaps.append((prev, duration, False, True))
    cuts = []
    for gs, ge, is_start, is_end in gaps:
        if ge - gs < C["min_silence"]:
            continue
        cs = gs if is_start else gs + C["pad_after"]
        ce = ge if is_end else ge - C["pad_before"]
        if ce - cs > 0.5:
            cuts.append((round(float(cs), 2), round(float(min(ce, duration)), 2)))

    # --- zoom: reazioni forti, fino a fine frase ---
    loud = _fill_gaps(dbs > peak_thr, int(0.3 / HOP))
    sruns = _runs(speech)
    cands = []
    for a, b in _runs(loud):
        if (b - a) * HOP < C["peak_min_len"]:
            continue
        e = b
        while e < len(speech) and speech[e]:
            e += 1
        for rs, re_ in sruns:
            if rs >= e and (re_ - rs) * HOP >= 0.4:
                if (rs - e) * HOP < C["zoom_bridge_gap"]:
                    e = re_
                break
        s = a * HOP - C["zoom_lead"]
        en = e * HOP + C["zoom_hold_after"]
        cands.append([max(0.0, s), min(duration, en), float(dbs[a:b].max())])
    merged = []
    for c in sorted(cands):
        if (merged and c[0] - merged[-1][1] < C["zoom_merge_gap"]
                and max(merged[-1][1], c[1]) - merged[-1][0] <= C["zoom_max_len"]):
            merged[-1][1] = max(merged[-1][1], c[1])
            merged[-1][2] = max(merged[-1][2], c[2])
        else:
            merged.append(c)
    for m in merged:
        if m[1] - m[0] < C["zoom_min_len"]:
            m[1] = min(duration, m[0] + C["zoom_min_len"])
        if m[1] - m[0] > C["zoom_max_len"]:
            cap = m[0] + C["zoom_max_len"]
            i0, i1 = int((cap - 2.0) / HOP), int(cap / HOP)
            m[1] = (i0 + int(np.argmin(dbs[i0:i1]))) * HOP if i1 > i0 else cap
    chosen = []
    for m in sorted(merged, key=lambda m: -m[2]):
        if all(m[0] - c[1] >= C["zoom_cooldown"] or c[0] - m[1] >= C["zoom_cooldown"] for c in chosen):
            chosen.append(m)
    # niente zoom dentro le parti tagliate
    zooms = []
    for a, b, _ in sorted(chosen):
        inside = any(ca <= a and b <= cb for ca, cb in cuts)
        if not inside:
            zooms.append((round(float(a), 2), round(float(b), 2)))
    stats = {"floor_db": round(floor, 1), "speech_db": round(speech_med, 1), "peak_db": round(peak_thr, 1)}
    return cuts, zooms, stats
