"""Trascrizione in locale con faster-whisper (gratis, niente cloud).

GPU NVIDIA se disponibile, altrimenti CPU. Il modello viene scaricato la prima volta
(circa 0,5-1,5 GB) e poi resta sul PC.
"""


def available():
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def _add_cuda_dlls():
    """Su Windows le DLL CUDA installate con pip (nvidia-cublas/cudnn) non sono nel PATH."""
    import os
    import sys
    if sys.platform != "win32":
        return
    import site
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        base = os.path.join(sp, "nvidia")
        if not os.path.isdir(base):
            continue
        for sub in os.listdir(base):
            b = os.path.join(base, sub, "bin")
            if os.path.isdir(b):
                try:
                    os.add_dll_directory(b)
                except Exception:
                    pass
                os.environ["PATH"] = b + os.pathsep + os.environ.get("PATH", "")


def _load_model(log):
    _add_cuda_dlls()
    from faster_whisper import WhisperModel
    tries = [("large-v3-turbo", "cuda", "float16"), ("small", "cuda", "float16"), ("small", "cpu", "int8")]
    last = None
    for name, device, ctype in tries:
        try:
            m = WhisperModel(name, device=device, compute_type=ctype)
            log(f"Modello {name} su {'GPU' if device == 'cuda' else 'CPU'}")
            return m, device
        except Exception as e:  # driver/cuDNN mancanti -> prova il successivo
            last = e
    raise RuntimeError(f"Impossibile caricare il modello di trascrizione: {last}")


def _collect(model, path, duration, language, beam, progress, cancel):
    segments, info = model.transcribe(path, language=language, word_timestamps=True, vad_filter=True, beam_size=beam)
    out = []
    for seg in segments:  # la trascrizione vera avviene qui (generatore)
        if cancel and cancel():
            raise RuntimeError("annullato")
        words = []
        for w in (seg.words or []):
            txt = w.word.strip()
            if txt:
                words.append({"w": txt, "a": round(float(w.start), 2), "b": round(float(w.end), 2), "del": False})
        if words:
            out.append({"a": words[0]["a"], "b": words[-1]["b"], "words": words})
        if progress and duration:
            progress(min(0.99, float(seg.end) / duration))
    return out, getattr(info, "language", None)


def transcribe(path, duration, progress=None, cancel=None, language=None, log=print):
    model, device = _load_model(log)
    try:
        out, lang = _collect(model, path, duration, language, 5 if device == "cuda" else 1, progress, cancel)
    except Exception as e:
        if device != "cuda" or "annullato" in str(e):
            raise
        # errore CUDA durante la trascrizione (memoria, DLL): riprova su CPU
        log("GPU non disponibile per la trascrizione, uso la CPU")
        del model
        from faster_whisper import WhisperModel
        model = WhisperModel("small", device="cpu", compute_type="int8")
        out, lang = _collect(model, path, duration, language, 1, progress, cancel)
    return {"status": "done", "language": lang, "segments": out}
