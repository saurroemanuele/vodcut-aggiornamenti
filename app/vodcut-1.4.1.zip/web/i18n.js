// Lingua dell'interfaccia. Il testo dell'app e' scritto in italiano; in inglese viene tradotto al volo
// mentre compare sullo schermo (testi, suggerimenti, etichette), con il dizionario in web/i18n/en.json.
// Il testo dell'utente (trascrizione, sottotitoli, testi, nomi dei progetti) non viene mai toccato.

export let LANG = 'it';
const LANGS = ['it', 'en'];
const exact = new Map();
let pats = [];      // [regex, testo inglese]
let frags = [];     // [regex, testo inglese] pezzi di frasi (per i testi composti)
const cache = new Map();
const ATTRS = ['data-tip', 'aria-label', 'placeholder', 'title', 'alt', 'data-key'];
// testo scritto o detto dall'utente: mai tradotto
const NOTR = '[data-notr], .sub, .subblk, .tseg, .asset-nm, .rcard .t, input, textarea, [contenteditable="true"], .lictext, .timelbl';

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export function langFromSystem() {
  const n = (navigator.languages && navigator.languages[0]) || navigator.language || 'it';
  return n.toLowerCase().startsWith('it') ? 'it' : 'en';
}

export function pickLang(saved) {
  return LANGS.includes(saved) ? saved : langFromSystem();
}

export async function loadLang(lang) {
  LANG = LANGS.includes(lang) ? lang : 'it';
  document.documentElement.lang = LANG;
  if (LANG === 'it') return;
  let dict = {};
  try { dict = await (await fetch('/web/i18n/' + LANG + '.json')).json(); } catch (e) { LANG = 'it'; return; }
  const P = [], F = [];
  for (const [it, en] of Object.entries(dict)) {
    if (it.includes('{}') || it.includes('{n}')) {
      // {} = qualsiasi testo, {n} = solo un numero
      const parts = it.split(/(\{n?\})/);
      const re = new RegExp('^' + parts.map((x, i) => (i % 2 ? (x === '{n}' ? '(\\d+)' : '(.+?)') : esc(x))).join('') + '$');
      P.push([re, en]);
    } else {
      exact.set(it, en);
      // pezzi di frasi: solo quelli abbastanza lunghi da non confondersi con altre parole
      if (it.length >= 7 && /\s/.test(it)) F.push([new RegExp('(^|[^\\p{L}])' + esc(it) + '(?=$|[^\\p{L}])', 'gu'), en, it.length]);
    }
  }
  // prima i modelli piu' specifici (piu' testo fisso)
  pats = P.sort((a, b) => b[0].source.length - a[0].source.length);
  frags = F.sort((a, b) => b[2] - a[2]);
}

function fill(en, groups) {
  let k = 0;
  return en.replace(/\{(\d*)\}/g, (m, n) => {
    const g = n === '' ? groups[k++] : groups[+n];
    return g === undefined ? '' : tr(g, 1);
  });
}

function tr(core, depth) {
  const hit = exact.get(core);
  if (hit !== undefined) return hit;
  if (depth > 2) return core;
  // "3:00 · Esportato": ogni pezzo per conto suo (i modelli con " · " dentro vanno prima)
  if (core.includes(' · ')) {
    for (const [re, en] of pats) { if (re.source.includes('·')) { const m = re.exec(core); if (m) return fill(en, m.slice(1)); } }
    return core.split(/(\s+·\s+)/).map((x, i) => (i % 2 ? x : tr(x.trim(), depth + 1))).join('');
  }
  for (const [re, en] of pats) {
    const m = re.exec(core);
    if (m) return fill(en, m.slice(1));
  }
  // "Sfocatura 0:20 → 0:32": il nome davanti ai numeri
  const lead = /^([^\d]+?)\s+(\d[\s\S]*)$/.exec(core);
  if (lead && exact.has(lead[1])) return exact.get(lead[1]) + ' ' + lead[2];
  // testi composti: si traducono i pezzi conosciuti
  let out = core;
  if (depth === 0 && frags.length && /[a-zà-ù]{3}/i.test(core)) {
    for (const [re, en] of frags) out = out.replace(re, (m, pre) => pre + en);
  }
  return out;
}

// traduce una stringa (anche da codice: nomi predefiniti, messaggi)
export function t(s) {
  if (LANG === 'it' || typeof s !== 'string' || !s) return s;
  const c = cache.get(s);
  if (c !== undefined) return c;
  const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(s);
  let r = s;
  if (/\p{L}/u.test(m[2])) r = m[1] + tr(m[2], 0) + m[3];
  r = r.replace(/(\d),(\d)/g, '$1.$2');   // 0,5 s -> 0.5 s
  if (cache.size > 20000) cache.clear();
  cache.set(s, r);
  return r;
}

const done = new WeakMap();   // nodo -> ultimo testo tradotto (per non ritradurre)
function skip(el) { return !el || (el.closest && el.closest(NOTR)); }

function doText(node) {
  const v = node.data;
  if (done.get(node) === v) return;
  const p = node.parentElement;
  if (!p || p.tagName === 'SCRIPT' || p.tagName === 'STYLE' || skip(p)) return;
  const r = t(v);
  done.set(node, r);
  if (r !== v) node.data = r;
}

function doAttrs(el) {
  if (el.closest && el.closest('[data-notr]')) return;
  for (const a of ATTRS) {
    const v = el.getAttribute(a);
    if (!v) continue;
    const r = t(v);
    if (r !== v) el.setAttribute(a, r);
  }
}

function walk(root) {
  if (root.nodeType === 3) return doText(root);
  if (root.nodeType !== 1) return;
  if (skip(root) && !root.matches('input, textarea')) return;
  doAttrs(root);
  const it = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
  let n = it.nextNode();
  while (n) {
    if (n.nodeType === 3) doText(n);
    else doAttrs(n);
    n = it.nextNode();
  }
}

export function startTranslating() {
  if (LANG === 'it') return;
  walk(document.body);
  if (document.title) document.title = t(document.title);
  new MutationObserver((list) => {
    for (const m of list) {
      if (m.type === 'characterData') doText(m.target);
      else if (m.type === 'attributes') { if (ATTRS.includes(m.attributeName)) doAttrs(m.target); }
      else for (const n of m.addedNodes) walk(n);
    }
  }).observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  // titolo della finestra
  new MutationObserver(() => { const r = t(document.title); if (r !== document.title) document.title = r; })
    .observe(document.querySelector('title') || document.head, { childList: true, characterData: true, subtree: true });
}
