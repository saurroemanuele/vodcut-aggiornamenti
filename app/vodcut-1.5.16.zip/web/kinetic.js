// VODcut - testi animati "cinetici": ogni lettera o parola si muove da sola (come nei pack professionali).
// Il testo si ridisegna a ogni fotogramma su una tela di grandezza fissa. In anteprima si disegna dal vivo;
// per l'esportazione l'app prepara i fotogrammi (PNG) e il video li usa uguali, pixel per pixel.
import { TEXT_DEFAULT } from './text.js';
import { fontReady } from './fonts.js';

// [id, nome, descrizione, per lettere o parole, durata dell'entrata (s)]
export const KINETICS = [
  ['highlight', 'Evidenziatore', 'Il riquadro colorato si allarga dietro le parole *evidenziate*', 'word'],
  ['stomp', 'Colpi', 'Ogni parola arriva con un colpo, una dopo l\'altra', 'word'],
  ['words', 'Parole pop', 'Le parole saltano fuori una alla volta', 'word'],
  ['rise', 'Sale dal basso', 'Le parole salgono da una fessura, pulite', 'word'],
  ['karaoke', 'Karaoke', 'Le parole si accendono una dopo l\'altra', 'word'],
  ['letters', 'Lettere che saltano', 'Ogni lettera rimbalza al suo posto', 'char'],
  ['type', 'Macchina da scrivere', 'Lettera per lettera, con il cursore', 'char'],
  ['blur', 'Messa a fuoco', 'Le lettere arrivano sfocate e si stringono', 'char'],
  ['zoom', 'Zoom lettere', 'Le lettere arrivano da grandi', 'char'],
  ['flip', 'Ribalta 3D', 'Le lettere girano su se stesse', 'char'],
  ['slide', 'Scorre', 'Le lettere scivolano dentro da sinistra', 'char'],
  ['scramble', 'Decodifica', 'Lettere a caso che diventano il testo', 'char'],
  ['wave', 'Onda', 'Le lettere ondeggiano sempre', 'char'],
  ['rainbow', 'Arcobaleno', 'I colori scorrono sulle lettere', 'char'],
  ['shine', 'Riflesso', 'Un lampo di luce passa sul testo', 'char'],
  ['neon', 'Neon che si accende', 'Sfarfalla e poi resta acceso', 'char'],
  ['glitch', 'Glitch', 'Righe spostate e colori separati', 'char'],
  ['vhs', 'VHS', 'Come una vecchia cassetta', 'char'],
];
export const kineticName = (id) => (KINETICS.find((k) => k[0] === id) || [0, ''])[1];

const clamp = (x) => Math.max(0, Math.min(1, x));
const eOut = (p) => 1 - Math.pow(1 - clamp(p), 3);
const eBack = (p) => { p = clamp(p); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
const eElastic = (p) => { p = clamp(p); if (p === 0 || p === 1) return p; return Math.pow(2, -10 * p) * Math.sin((p * 10 - 0.75) * (2 * Math.PI) / 3) + 1; };
const rnd = (n) => { const x = Math.sin(n * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); };
function hexA(hex, a) {
  let x = (hex || '#000').replace('#', ''); if (x.length === 3) x = x.split('').map((c) => c + c).join('');
  return `rgba(${parseInt(x.slice(0, 2), 16)},${parseInt(x.slice(2, 4), 16)},${parseInt(x.slice(4, 6), 16)},${a})`;
}

// stato di ogni lettera al tempo tr: {dx, dy, sc, sx, sy, rot, op, blur, ch, color, px, py (perno)}
function states(kind, L, t, tr, dur) {
  const n = L.chars.length, nw = Math.max(1, L.words.length);
  const out = [];
  const inT = Math.min(dur * 0.7, kind === 'type' ? 0.055 * n : kind === 'karaoke' ? dur : 0.9);
  for (const u of L.chars) {
    const px = u.px;
    const w = u.word >= 0 ? L.words[u.word] : null;
    const s = { dx: 0, dy: 0, sc: 1, sx: 1, sy: 1, rot: 0, op: 1, blur: 0, ch: u.ch, color: null, pvx: u.cx, pvy: u.Y };
    const ci = u.idx, wi = w ? w.i : 0;
    if (w && KIND_MODE[kind] === 'word') { s.pvx = w.cx; s.pvy = w.Y; }
    const cStag = Math.min(0.045, inT / Math.max(1, n)), wStag = Math.min(0.2, (inT * 0.9) / nw);
    if (kind === 'letters') { const p = (tr - ci * cStag) / 0.45; s.sc = Math.max(0, eBack(p)); s.dy = (1 - eOut(p)) * px * 0.5; s.op = clamp(p * 3); }
    else if (kind === 'words') { const p = (tr - wi * wStag) / 0.38; s.sc = Math.max(0, 0.4 + 0.6 * eBack(p)); s.op = clamp(p * 3); }
    else if (kind === 'stomp') {
      const p = (tr - wi * Math.max(0.16, wStag)) / 0.2; s.sc = 1 + 1.6 * (1 - eOut(p)); s.op = clamp(p * 2.2);
      const k = tr - wi * Math.max(0.16, wStag) - 0.2;   // piccolo tremolio all'arrivo
      if (k > 0 && k < 0.18) { const a = (1 - k / 0.18) * px * 0.05; s.dx = (rnd(wi * 7 + Math.floor(tr * 60)) - 0.5) * a * 2; s.dy = (rnd(wi * 13 + Math.floor(tr * 60)) - 0.5) * a * 2; }
    } else if (kind === 'rise') { const p = (tr - wi * Math.min(0.09, wStag)) / 0.55; s.dy = (1 - eOut(p)) * u.lh * 1.05; s.clip = true; }
    else if (kind === 'karaoke') {
      const k = tr / Math.max(0.3, dur * 0.85) * nw;
      s.op = 1; s.color = wi < k ? (t.hlColor || '#FFD60A') : null; s.dim = wi >= k;
      if (wi < k && wi > k - 1) s.sc = 1 + 0.07 * Math.sin(Math.PI * (k - wi));
    } else if (kind === 'type') { const k = tr / Math.max(0.2, inT) * n; s.op = ci < k ? 1 : 0; }
    else if (kind === 'blur') { const p = (tr - ci * cStag) / 0.5; const e = eOut(p); s.op = clamp(p * 1.6); s.blur = (1 - e) * px * 0.22; s.dx = (u.cx - L.W / 2) * 0.35 * (1 - e); }
    else if (kind === 'zoom') { const p = (tr - ci * cStag) / 0.45; const e = eOut(p); s.sc = 1 + 1.6 * (1 - e); s.op = clamp(p * 2); s.blur = (1 - e) * px * 0.12; }
    else if (kind === 'flip') { const p = (tr - ci * cStag) / 0.5; const e = eBack(p); s.sx = Math.cos((1 - clamp(e)) * Math.PI / 2) * (e > 1 ? e : 1); s.op = clamp(p * 2.5); s.dy = -(1 - eOut(p)) * px * 0.15; }
    else if (kind === 'slide') { const p = (tr - ci * cStag) / 0.42; const e = eOut(p); s.dx = -(1 - e) * px * 1.4; s.op = clamp(p * 2); s.blur = (1 - e) * px * 0.08; }
    else if (kind === 'scramble') {
      const done = 0.25 + ci * cStag * 1.4;
      if (tr < done && u.ch.trim()) { const pool = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#%&@$'; s.ch = pool[Math.floor(rnd(ci * 31 + Math.floor(tr * 20)) * pool.length)]; s.op = tr < ci * cStag * 0.6 ? 0 : 0.85; s.color = t.hlColor || null; }
    } else if (kind === 'wave') { const p = (tr - ci * cStag * 0.5) / 0.4; s.op = clamp(p * 2); s.dy = Math.sin(tr * 4.2 - ci * 0.55) * px * 0.1 * clamp(tr / 0.6); }
    else if (kind === 'rainbow') { const p = (tr - ci * cStag * 0.5) / 0.35; s.op = clamp(p * 2); s.color = `hsl(${(ci * 24 + tr * 140) % 360},95%,62%)`; s.dy = Math.sin(tr * 3 - ci * 0.4) * px * 0.04; }
    else if (kind === 'highlight') { const p = (tr - wi * Math.min(0.07, wStag)) / 0.35; s.op = clamp(p * 2.5); s.dy = (1 - eOut(p)) * px * 0.25; }
    else if (kind === 'shine' || kind === 'neon' || kind === 'glitch' || kind === 'vhs') { const p = tr / 0.35; s.op = kind === 'neon' ? 1 : clamp(p); }
    out.push(s);
  }
  return out;
}
// ---------------------------------------------------------------- impaginazione
// Due livelli possibili: il testo principale e una seconda scritta (es. "Clean" + "Style" in corsivo) sovrapposta.
// Ogni lettera sa a che livello appartiene, con il suo font e la sua grandezza.
const layouts = new Map();
function fontOf(o, px) { return `${o.italic ? 'italic ' : ''}${o.weight || (o.bold ? '700' : '400')} ${px}px "${o.font}", Arial, sans-serif`; }
function blockLayout(o, px, content, useHl) {
  const m = document.createElement('canvas').getContext('2d');
  const font = fontOf(o, px);
  m.font = font;
  const ls = (o.spacing || 0) * px;
  if ('letterSpacing' in m) m.letterSpacing = ls + 'px';
  const lh = px * (o.lineH || 1.15);
  const lines = String(content || ' ').split('\n').map((l) => (o.upper ? l.toUpperCase() : l));
  const out = [];
  const widths = [];
  lines.forEach((raw, li) => {
    let s = '', hl = [];
    if (useHl) { let on = false; for (const ch of raw) { if (ch === '*') { on = !on; continue; } s += ch; hl.push(on); } }
    else { s = raw; hl = [...raw].map(() => false); }
    const arr = [...s];
    // con le lettere strette (spaziatura negativa) gli spazi tra le parole restano ben visibili
    const gap = ls < 0 ? -ls * 1.8 : 0;
    let pre = '', spaces = 0;
    arr.forEach((ch, i) => { const x = m.measureText(pre).width + spaces * gap; pre += ch; if (ch === ' ') spaces++; out.push({ ch, x, w: m.measureText(ch).width, line: li, hl: hl[i] }); });
    widths.push(Math.max(m.measureText(s).width + spaces * gap - (arr.length ? ls : 0), m.measureText(' ').width));
  });
  return { font, px, lh, ls, units: out, widths, nLines: lines.length, w: Math.max(...widths, 1), h: lh * lines.length };
}
function layout(t, H) {
  let ready = true;
  try { ready = fontReady(t.font) && (!t.sub || fontReady(t.sub.font || t.font)); } catch (e) { /* */ }
  const key = JSON.stringify([t, H, ready]);
  const hit = layouts.get(key);
  if (hit) return hit;
  const px = Math.max(8, Math.round(t.size * H));
  const useHl = !!(t.hlColor || t.hlBox);
  const A = blockLayout(t, px, t.content, useHl);
  let B = null;
  if (t.sub && String(t.sub.content || '').trim()) {
    const so = { ...t.sub, font: t.sub.font || t.font };
    B = blockLayout(so, Math.max(6, Math.round(px * (t.sub.scale || 0.6))), t.sub.content, false);
  }
  // posizione dei blocchi (origine: angolo in alto a sinistra del testo principale)
  const alignX = (bl, li, x0, wBox, al) => (al === 'left' ? x0 : al === 'right' ? x0 + wBox - bl.widths[li] : x0 + (wBox - bl.widths[li]) / 2);
  let bx = 0, by = 0;
  if (B) {
    const p = t.sub.pos || 'br', dx = (t.sub.dx || 0) * px, dy = (t.sub.dy || 0) * px;
    if (p === 'below') { bx = (A.w - B.w) / 2; by = A.h - px * 0.12; }
    else if (p === 'above') { bx = (A.w - B.w) / 2; by = -B.h + px * 0.1; }
    else if (p === 'br') { bx = A.w - B.w * 0.85; by = A.h - B.h * 0.55; }
    else if (p === 'bl') { bx = -B.w * 0.1; by = A.h - B.h * 0.55; }
    else if (p === 'tr') { bx = A.w - B.w * 0.8; by = -B.h * 0.45; }
    bx += dx; by += dy;
  }
  const minX = Math.min(0, B ? bx : 0), minY = Math.min(0, B ? by : 0);
  const maxX = Math.max(A.w, B ? bx + B.w : 0), maxY = Math.max(A.h, B ? by + B.h : 0);
  const sw = t.stroke ? t.strokeW * px : 0;
  const sw2 = t.stroke2 ? (t.stroke2W || 0.1) * px : 0;
  const hard = t.hard ? (t.hardD || 0.08) * px : 0;
  const bloom = t.bloom || (t.glow ? (t.glowColor || t.color) : '');
  const glowR = bloom ? (t.bloomK || t.glowR || 0.35) * px * 2.2 : 0;
  const pad = Math.ceil((t.box || t.lineBox ? 0.35 * px : 0) + sw + sw2 + hard + glowR + 0.25 * px + 2 + px * 0.55);
  const W = Math.ceil(maxX - minX + pad * 2), Hc = Math.ceil(maxY - minY + pad * 2);
  const ox = pad - minX, oy = pad - minY;
  const chars = [], words = [], hlRuns = [];
  const addBlock = (bl, x0, y0, layer, al) => {
    let word = null, run = null;
    bl.units.forEach((u0) => {
      const X = alignX(bl, u0.line, x0, bl.w, al) + u0.x, Y = y0 + bl.lh * u0.line + bl.lh / 2;
      const u = { ...u0, X, Y, cx: X + u0.w / 2, px: bl.px, lh: bl.lh, font: bl.font, layer, idx: chars.length, word: -1 };
      if (u.ch.trim()) {
        if (!word || word.line !== u.line || word.layer !== layer) { word = { i: words.length, line: u.line, layer, X0: X, X1: X + u.w, Y, chars: [] }; words.push(word); }
        word.X1 = X + u.w; word.cx = (word.X0 + word.X1) / 2; word.chars.push(u); u.word = word.i;
      } else word = null;
      if (u.hl) { if (!run || run.line !== u.line) { run = { line: u.line, X0: X, X1: X + u.w, Y }; hlRuns.push(run); } else run.X1 = X + u.w; } else run = null;
      chars.push(u);
    });
  };
  addBlock(A, ox, oy, 0, t.align || 'center');
  if (B) addBlock(B, ox + bx, oy + by, 1, 'center');
  const lineBoxes = A.widths.map((w, i) => ({ X: alignX(A, i, ox, A.w, t.align || 'center'), w, Y: oy + A.lh * i + A.lh / 2 }));
  const L = { px, lh: A.lh, chars, words, hlRuns, lineBoxes, W, H: Hc, pad, sw, sw2, hard, bloom, glowR, nLines: A.nLines, box: { x: ox, y: oy, w: A.w, h: A.h } };
  if (layouts.size > 80) layouts.clear();
  layouts.set(key, L);
  return L;
}

const KIND_MODE = Object.fromEntries(KINETICS.map((k) => [k[0], k[3]]));
// quando il testo usa gli effetti "pro" (o e' animato) si disegna con questo motore
export const isProText = (t) => !!(t && !t.badge && (t.bloom || t.gloss || t.sub || t.split || t.strike || t.softShadow));

// tele di lavoro riusate (niente tele nuove a ogni fotogramma)
const pool = new Map();
function work(name, W, H) {
  let c = pool.get(name);
  if (!c) { c = document.createElement('canvas'); pool.set(name, c); }
  if (c.width !== W || c.height !== H) { c.width = W; c.height = H; } else c.getContext('2d').clearRect(0, 0, W, H);
  return c;
}
const subStyle = (t) => ({ ...t, ...(t.sub || {}), font: (t.sub && t.sub.font) || t.font, stroke: t.sub && 'stroke' in t.sub ? t.sub.stroke : false, hard: false,
  grad: t.sub && t.sub.grad ? t.sub.grad : null, color: (t.sub && t.sub.color) || '#FFFFFF', bloom: t.sub && 'bloom' in t.sub ? t.sub.bloom : t.bloom, gloss: t.sub && 'gloss' in t.sub ? t.sub.gloss : false });

function eachUnit(g, L, st, layer, fn) {
  L.chars.forEach((u, i) => {
    if (u.layer !== layer) return;
    const s = st[i];
    if (s.op <= 0.004 || !s.ch.trim()) return;
    const copies = s.blur > 0.6 ? 6 : 1;
    for (let k = 0; k < copies; k++) {
      g.save();
      if (s.clip) { g.beginPath(); g.rect(0, u.Y - u.lh * 0.62, L.W, u.lh * 1.24); g.clip(); }
      const ox = copies > 1 ? Math.cos(k / copies * Math.PI * 2) * s.blur : 0, oy = copies > 1 ? Math.sin(k / copies * Math.PI * 2) * s.blur * 0.6 : 0;
      g.globalAlpha = Math.min(1, s.op * (s.dim ? 0.55 : 1)) / (copies > 1 ? copies * 0.55 : 1);
      g.translate(s.pvx + s.dx + ox, s.pvy + s.dy + oy);
      if (s.rot) g.rotate(s.rot);
      g.scale(s.sc * s.sx, s.sc * s.sy);
      g.translate(-s.pvx, -s.pvy);
      g.font = u.font;
      fn(u, s);
      g.restore();
    }
  });
}

// disegna un livello (principale o seconda scritta) nelle tele di lavoro: riempimento e contorni separati
function paintLayer(L, t, st, layer, tr) {
  const o = layer ? subStyle(t) : t;
  const F = work('fill' + layer, L.W, L.H), S = work('stroke' + layer, L.W, L.H);
  const f = F.getContext('2d'), sg = S.getContext('2d');
  for (const q of [f, sg]) { q.textBaseline = 'middle'; q.lineJoin = 'round'; q.miterLimit = 2; q.textAlign = 'left'; if ('letterSpacing' in q) q.letterSpacing = '0px'; }
  const sw = o.stroke ? (o.strokeW || 0.08) * (layer ? L.chars.find((u) => u.layer === 1).px : L.px) : 0;
  const sw2 = !layer && t.stroke2 ? L.sw2 : 0;
  if (sw2) eachUnit(sg, L, st, layer, (u, s) => { sg.strokeStyle = t.stroke2Color || '#000'; sg.lineWidth = (sw + sw2) * 2; sg.strokeText(s.ch, u.X, u.Y); });
  if (sw) eachUnit(sg, L, st, layer, (u, s) => { sg.strokeStyle = u.hl && t.hlStroke ? t.hlStroke : (o.strokeColor || '#000'); sg.lineWidth = sw * 2; sg.strokeText(s.ch, u.X, u.Y); });
  eachUnit(f, L, st, layer, (u, s) => {
    let fill = s.color || (u.hl && t.hlColor ? t.hlColor : o.color);
    if (!s.color && !(u.hl && t.hlColor) && o.grad && o.grad.length > 1) {
      const gr = f.createLinearGradient(0, u.Y - u.px * 0.45, 0, u.Y + u.px * 0.45);
      o.grad.forEach((col, j) => gr.addColorStop(j / (o.grad.length - 1), col));
      fill = gr;
    }
    f.fillStyle = fill; f.fillText(s.ch, u.X, u.Y);
  });
  // lucido: chiaro in alto, piu' scuro in basso, dentro le lettere
  if (o.gloss) {
    f.save(); f.globalCompositeOperation = 'source-atop';
    const rows = new Map();
    L.chars.forEach((u, i) => { if (u.layer === layer) rows.set(u.Y + st[i].dy, u); });
    for (const [y, u] of rows) {
      const gr = f.createLinearGradient(0, y - u.px * 0.5, 0, y + u.px * 0.5);
      gr.addColorStop(0, 'rgba(255,255,255,.55)'); gr.addColorStop(0.42, 'rgba(255,255,255,.1)'); gr.addColorStop(0.5, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(0,0,0,.3)');
      f.fillStyle = gr; f.fillRect(0, y - u.lh * 0.7, L.W, u.lh * 1.4);
    }
    f.restore();
  }
  void tr;
  return { F, S, o, sw };
}

function tintOf(src, col, tag = '') {
  const z = work('tint' + col + tag, src.width, src.height), q = z.getContext('2d');
  q.globalCompositeOperation = 'source-over'; q.drawImage(src, 0, 0);
  q.globalCompositeOperation = 'source-in'; q.fillStyle = col; q.fillRect(0, 0, z.width, z.height);
  q.globalCompositeOperation = 'source-over';
  return z;
}

export function kineticSize(t0, H) {
  const t = { ...TEXT_DEFAULT, ...(t0 || {}) };
  const L = layout(t, H);
  return { w: L.W, h: L.H };
}

// kind vuoto = testo fermo (con gli effetti pro)
export function drawKinetic(t0, H, tr, dur, kind, canvas) {
  const t = { ...TEXT_DEFAULT, ...(t0 || {}) };
  const L = layout(t, H);
  const c = canvas || document.createElement('canvas');
  if (c.width !== L.W || c.height !== L.H) { c.width = L.W; c.height = L.H; }
  const g = c.getContext('2d');
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.globalCompositeOperation = 'source-over'; g.globalAlpha = 1;
  g.clearRect(0, 0, c.width, c.height);
  g.textBaseline = 'middle'; g.lineJoin = 'round'; g.miterLimit = 2; g.textAlign = 'left';
  if ('letterSpacing' in g) g.letterSpacing = '0px';   // le lettere sono gia' messe al loro posto una per una
  const st = kind ? states(kind, L, t, Math.max(0, tr), Math.max(0.3, dur))
    : L.chars.map((u) => ({ dx: 0, dy: 0, sc: 1, sx: 1, sy: 1, rot: 0, op: 1, blur: 0, ch: u.ch, color: null, pvx: u.cx, pvy: u.Y }));
  const anyOp = st.reduce((a, s) => Math.max(a, s.op), 0);
  // neon: sfarfalla e poi resta acceso (con un respiro leggero)
  let bloomK = 1, globalA = 1;
  if (kind === 'neon') {
    const fl = [1, 0, 1, 0.2, 1, 1, 0, 1, 1, 1];
    globalA = tr < 0.9 ? fl[Math.floor(tr / 0.09) % fl.length] * (0.6 + 0.4 * rnd(Math.floor(tr * 30))) : 1;
    bloomK = 0.85 + 0.15 * Math.sin(tr * 5);
  }
  // ---- sfondi
  if (t.box) {
    const r = Math.min(L.H / 2, t.boxR * L.px), b = L.box;
    const x0 = b.x - 0.35 * L.px, x1 = b.x + b.w + 0.35 * L.px, y0 = b.y - 0.28 * L.px, y1 = b.y + b.h + 0.28 * L.px;
    const k = kind === 'highlight' || kind === 'words' || kind === 'stomp' ? eBack(tr / 0.35) : 1, cx = (x0 + x1) / 2;
    g.save(); g.globalAlpha = anyOp * globalA;
    if (t.boxGlow) { g.shadowColor = t.boxGlow; g.shadowBlur = L.px * 0.6; }
    g.fillStyle = hexA(t.boxColor, (t.boxOp ?? 80) / 100);
    g.beginPath(); g.roundRect(cx - (cx - x0) * k, y0, (x1 - x0) * k, y1 - y0, r); g.fill(); g.restore();
  }
  if (t.lineBox) {
    g.save(); g.fillStyle = hexA(t.boxColor, (t.boxOp ?? 100) / 100);
    const bp = 0.28 * L.px, r = (t.boxR ?? 0.25) * L.px;
    L.lineBoxes.forEach((lb, i) => {
      const lineOp = Math.max(0, ...L.chars.map((u, j) => (u.layer === 0 && u.line === i ? st[j].op : 0)));
      const k = kind ? eBack((tr - i * 0.12) / 0.35) : 1;
      g.globalAlpha = lineOp * globalA;
      const cx = lb.X + lb.w / 2, ww = (lb.w + bp * 2) * Math.max(0, k);
      g.beginPath(); g.roundRect(cx - ww / 2, lb.Y - L.lh / 2 + L.px * 0.04, ww, L.lh - L.px * 0.08, r); g.fill();
    });
    g.restore();
  }
  if (t.hlBox) {
    const hp = 0.14 * L.px;
    L.hlRuns.forEach((r, i) => {
      const first = L.chars.findIndex((u) => u.layer === 0 && u.hl && Math.abs(u.X - r.X0) < 1 && Math.abs(u.Y - r.Y) < 1);
      const op = first >= 0 ? st[first].op : 1;
      let k = 1;
      if (kind === 'highlight') k = eOut((tr - 0.25 - i * 0.18) / 0.35);
      else if (op < 1) k = op;
      if (k <= 0.001) return;
      g.save(); g.globalAlpha = globalA;
      g.translate(r.X0 - hp, r.Y);
      g.rotate(((t.hlTilt ?? -2) * Math.PI) / 180);
      if (t.hlGlow) { g.shadowColor = t.hlGlow; g.shadowBlur = L.px * 0.5; }
      const bw = (r.X1 - r.X0 + hp * 2) * k;
      const grd = g.createLinearGradient(0, -L.px * 0.52, 0, L.px * 0.52);
      grd.addColorStop(0, t.hlBoxColor2 || t.hlBoxColor || '#FFD60A'); grd.addColorStop(1, t.hlBoxColor || '#FFD60A');
      g.fillStyle = grd;
      g.beginPath(); g.roundRect(0, -L.px * 0.52, bw, L.px * 1.04, L.px * 0.14); g.fill();
      g.restore();
    });
  }
  // ---- livelli di testo (prima la seconda scritta sotto? no: il principale sotto, la seconda sopra)
  const layers = [0];
  if (L.chars.some((u) => u.layer === 1)) layers.push(1);
  for (const layer of layers) {
    const { F, S, o } = paintLayer(L, t, st, layer, tr);
    g.save(); g.globalAlpha = globalA;
    // ombra morbida sotto
    if (o.softShadow || (o.shadow && !o.hard)) {
      g.save(); g.shadowColor = 'rgba(0,0,0,.72)'; g.shadowBlur = L.px * 0.22; g.shadowOffsetY = L.px * 0.07;
      g.drawImage(S, 0, 0); g.drawImage(F, 0, 0); g.restore();
    }
    // 3D: ombra piena spostata
    if (!layer && L.hard) {
      const tint = tintOf(F, t.hardColor || '#000', 'f');
      const tintS = tintOf(S, t.hardColor || '#000', 's');
      const steps = Math.max(1, Math.round(L.hard / Math.max(1, L.px * 0.02)));
      for (let k = steps; k >= 1; k--) { const d = L.hard * k / steps; g.drawImage(tintS, d, d); g.drawImage(tint, d, d); }
    }
    // bagliore (bloom): tre passate, dalla piu' larga alla piu' stretta
    const bl = layer ? o.bloom : L.bloom;
    if (bl) {
      const R = L.glowR * bloomK;
      for (const [r, a] of [[R, 0.6], [R * 0.4, 0.8], [R * 0.13, 0.9]]) {
        g.save(); g.shadowColor = bl; g.shadowBlur = r; g.globalAlpha = a * globalA; g.drawImage(F, 0, 0); g.restore();
      }
    }
    // colori separati (effetto errore / VHS)
    if (!layer && t.split) {
      const d = t.split * L.px;
      g.save(); g.globalAlpha = 0.8 * globalA; g.globalCompositeOperation = 'lighter';
      g.drawImage(tintOf(F, '#FF1F4B', 'r'), -d, 0); g.drawImage(tintOf(F, '#00D9FF', 'c'), d, 0);
      g.restore();
    }
    g.drawImage(S, 0, 0);
    g.drawImage(F, 0, 0);
    g.restore();
  }
  // linea che barra il testo
  if (t.strike) {
    const b = L.box, k = kind ? eOut((tr - 0.35) / 0.3) : 1;
    if (k > 0) { g.save(); g.fillStyle = t.strike; g.shadowColor = t.strike; g.shadowBlur = L.px * 0.25; g.globalAlpha = globalA; g.fillRect(b.x - L.px * 0.05, b.y + b.h / 2 - L.px * 0.055, (b.w + L.px * 0.1) * k, L.px * 0.11); g.restore(); }
  }
  // cursore della macchina da scrivere
  if (kind === 'type') {
    const typed = Math.min(dur * 0.7, 0.055 * L.chars.length);
    const k = tr / Math.max(0.2, typed) * L.chars.length;
    const last = L.chars[Math.min(L.chars.length - 1, Math.max(0, Math.ceil(k) - 1))];
    if (last && tr < typed + 1.4 && (tr < typed + 0.1 || Math.floor(tr * 2.2) % 2 === 0)) {
      g.save(); g.fillStyle = t.hlColor || t.color;
      if (L.bloom) { g.shadowColor = L.bloom; g.shadowBlur = L.px * 0.4; }
      g.fillRect((k >= 1 ? last.X + last.w : last.X) + last.px * 0.04, last.Y - last.px * 0.42, Math.max(2, last.px * 0.07), last.px * 0.84);
      g.restore();
    }
  }
  // ---- effetti su tutto il testo
  if (kind === 'shine') {
    const per = 2.4, ph = ((tr - 0.3) % per) / per;
    if (tr > 0.3 && ph < 0.45) {
      const x = -L.W * 0.3 + (L.W * 1.6) * (ph / 0.45);
      g.save(); g.globalCompositeOperation = 'source-atop';
      const gr = g.createLinearGradient(x - L.px, 0, x + L.px, L.H * 0.3);
      gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,.8)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, L.W, L.H); g.restore();
    }
  } else if (kind === 'glitch' || kind === 'vhs') {
    const f = Math.floor(tr * 30);
    const burst = kind === 'glitch' ? (tr < 0.5 || (tr % 1.7) < 0.22) : true;
    const amp = kind === 'glitch' ? (burst ? 1 : 0.15) : 0.35;
    const snap = work('snap', L.W, L.H);
    snap.getContext('2d').drawImage(c, 0, 0);
    const d = L.px * 0.06 * amp * (0.6 + rnd(f));
    g.clearRect(0, 0, L.W, L.H);
    g.save(); g.globalAlpha = 0.75; g.globalCompositeOperation = 'lighter';
    g.drawImage(tintOf(snap, '#FF2A55', 'g1'), -d, 0); g.drawImage(tintOf(snap, '#00E5FF', 'g2'), d, 0); g.restore();
    const bands = kind === 'glitch' && burst ? 7 : 3;
    let y = 0;
    for (let b = 0; b < bands && y < L.H; b++) {
      const hh = L.H / bands * (0.5 + rnd(f * 3 + b));
      const sh = (rnd(f * 7 + b * 11) - 0.5) * L.px * (kind === 'glitch' ? 0.5 * amp : 0.06);
      g.drawImage(snap, 0, y, L.W, hh, sh, y, L.W, hh);
      y += hh;
    }
    if (y < L.H) g.drawImage(snap, 0, y, L.W, L.H - y, 0, y, L.W, L.H - y);
    if (kind === 'vhs') {
      g.save(); g.globalCompositeOperation = 'source-atop';
      g.fillStyle = 'rgba(0,0,0,.26)';
      for (let yy = (f % 3); yy < L.H; yy += Math.max(3, Math.round(L.px * 0.06))) g.fillRect(0, yy, L.W, Math.max(1, L.px * 0.02));
      g.fillStyle = `rgba(255,255,255,${0.04 + 0.07 * rnd(f)})`; g.fillRect(0, 0, L.W, L.H);
      g.restore();
    }
  }
  return c;
}

// quanti fotogrammi servono (tutta la clip: alcuni effetti continuano sempre)
export const KINETIC_FPS = (fps) => Math.max(24, Math.min(60, Math.round(fps || 30)));
