// Noonframe - Storie AI: pagine (identità di ogni profilo), chiavi dei servizi AI dell'utente, storie scena per scena.
// Le chiavi non arrivano mai qui: l'interfaccia vede solo se ci sono e le ultime 4 cifre.
import { get, post, h, icon, toast, confirmBox, seg, pollJob, mediaUrl, fmt } from './lib.js';

const MOTIONS = [['zoomIn', 'Zoom avanti'], ['zoomOut', 'Zoom indietro'], ['panL', 'Verso sinistra'], ['panR', 'Verso destra'], ['panU', 'Verso l\'alto'], ['panD', 'Verso il basso']];
const DOES = { text: 'Testi', image: 'Immagini', voice: 'Voce', video: 'Video AI' };
// clip video AI: si paga la durata della clip (la piu' corta che il modello accetta), non quella della frase
const clipFor = (info, sec) => {
  const i = info || { usd_s: 0.1, durs: [5, 10] }; const ok = i.durs.filter((d) => d >= Math.max(1, sec) - 0.15); const d = ok.length ? ok[0] : i.durs[i.durs.length - 1];
  const pv = i.per_video && i.per_video[d];
  return { sec: d, usd: pv != null ? pv : d * (i.usd_s || 0) + (i.usd_fix || 0) };
};
// prezzo "da listino" di un modello video, scritto per esteso
const priceLbl = (i) => i.per_video ? Object.entries(i.per_video).map(([d, u]) => '$' + (+u).toFixed(2) + ' / ' + d + ' s').join(' · ') : '$' + (+i.usd_s).toFixed(3).replace(/0$/, '') + ' al secondo';
const durLbl = (i) => i.durs.length === 1 ? 'clip fissa da ' + i.durs[0] + ' s' : (i.durs.length > 3 && i.durs[1] - i.durs[0] === i.durs[2] - i.durs[1] ? 'clip da ' + i.durs[0] + ' a ' + i.durs[i.durs.length - 1] + ' s' : 'clip da ' + i.durs.join(', ') + ' s');
// scelta del modello video (tutti quelli di fal.ai): costo calcolato sulle scene vere (durs = durate delle frasi)
function videoModelPicker({ info, current, durs, title, sub, pageModel, onPick }) {
  const bg = h('div', { class: 'modal-bg' });
  const cost = (i) => (durs || []).reduce((a, d) => a + clipFor(i, d).usd, 0);
  const brands = ['Tutti', ...new Set(Object.values(info).map((i) => i.brand || 'Altri'))];
  let brand = 'Tutti', sort = 0;
  const list = h('div', { class: 'vm-list' });
  const paint = () => {
    let rows = Object.entries(info).filter(([, i]) => brand === 'Tutti' || (i.brand || 'Altri') === brand);
    rows.sort((a, b) => sort === 0 ? cost(a[1]) - cost(b[1]) || a[1].tier - b[1].tier : b[1].tier - a[1].tier || cost(a[1]) - cost(b[1]));
    const mk = (m, i, extra) => h('button', { class: 'vm-row' + (m === current ? ' on' : ''), onclick: () => { bg.remove(); onPick(m); } },
      h('div', { class: 'vm-main' },
        h('div', { class: 'vm-name' }, h('b', { 'data-notr': '' }, extra || i.name), i.res_lbl ? h('span', { class: 'vm-tag' }, i.res_lbl) : null,
          h('span', { class: 'vm-q', 'data-tip': 'Qualità (secondo noi)' }, ...[1, 2, 3, 4, 5].map((k) => h('i', { class: k <= i.tier ? 'on' : '' })))),
        h('small', null, i.why),
        h('small', { class: 'vm-meta' }, priceLbl(i) + ' · ' + durLbl(i))),
      durs && durs.length ? h('div', { class: 'vm-cost' }, h('b', null, usd(cost(i))), h('small', null, durs.length === 1 ? 'clip da ' + clipFor(i, durs[0]).sec + ' s' : 'per ' + durs.length + ' clip')) : null,
      m === current ? icon('check', 16, 'currentColor', 2.6) : null);
    rc(list, ...(pageModel ? [h('button', { class: 'vm-row vm-def' + (!current ? ' on' : ''), onclick: () => { bg.remove(); onPick(''); } },
      h('div', { class: 'vm-main' }, h('b', null, 'Come la pagina'), h('small', null, 'Usa il modello scelto per tutte le scene: ' + ((info[pageModel] || {}).name || ''))),
      durs && durs.length && info[pageModel] ? h('div', { class: 'vm-cost' }, h('b', null, usd(cost(info[pageModel])))) : null, !current ? icon('check', 16, 'currentColor', 2.6) : null)] : []),
    ...rows.map(([m, i]) => mk(m, i)));
  };
  const bseg = h('div', { class: 'vm-brands' }, ...brands.map((b) => h('button', { class: 'ai-chip' + (b === brand ? ' on' : ''), onclick: (e) => { brand = b; bseg.querySelectorAll('.ai-chip').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); paint(); } }, b)));
  bg.append(h('div', { class: 'modal vm-modal' },
    h('div', { class: 'ai-mh' }, h('h2', null, title || 'Modello video'), h('button', { class: 'iconbtn', onclick: () => bg.remove() }, icon('x', 16))),
    h('p', { class: 'wz-p' }, sub || 'Tutti i modelli di fal.ai. Prezzi di fal.ai con l\'audio spento (la voce la mettiamo noi). Si paga la durata della clip: uso sempre la più corta che il modello accetta.'),
    h('div', { class: 'vm-bar' }, bseg, seg(['Più economici', 'Più belli'], sort, (k) => { sort = k; paint(); })), list));
  bg.addEventListener('click', (e) => { if (e.target === bg) bg.remove(); });
  document.body.append(bg); paint();
}
const USES = {
  openai: 'Fa tutto da solo: scrive la storia (GPT), crea le immagini (gpt-image-1) e la voce (TTS). Comodo per iniziare con una sola chiave.',
  anthropic: 'Scrive le storie e divide lo script in scene (Claude). Ottimo per testi naturali e ben scritti.',
  gemini: 'Scrive le storie e crea immagini (Nano Banana di Google) tenendo uguali i personaggi con le foto di riferimento.',
  elevenlabs: 'Le voci più realistiche, anche in italiano. Dà i tempi di ogni parola: sottotitoli perfetti.',
  fal: 'Immagini con personaggi coerenti (Nano Banana, Flux) e i video AI (Kling): trasforma un\'immagine in una clip che si muove.',
};
const PRESET_NAMES = { cinematic: 'Cinematico', anime: 'Anime', pixar: 'Animazione 3D', dark: 'Horror', comic: 'Fumetto', watercolor: 'Acquerello' };
const LANGS = [['it', 'Italiano'], ['en', 'English'], ['es', 'Español'], ['fr', 'Français'], ['de', 'Deutsch'], ['pt', 'Português']];
// come replaceChildren, ma salta le parti vuote (niente "null" a schermo)
const rc = (node, ...kids) => node.replaceChildren(...kids.flat().filter((k) => k != null && k !== false && k !== ''));
const usd = (x) => '$' + (x < 0.1 ? (+x || 0).toFixed(3) : (+x || 0).toFixed(2));
const secsOf = (t) => Math.max(1.2, (String(t || '').split(/\s+/).filter(Boolean).length) / 2.6);
const hueOf = (s) => { let x = 0; for (const c of String(s || '')) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };
const pageAv = (p, size = 36) => h('span', { class: 'ai-pav', style: { width: size + 'px', height: size + 'px', fontSize: Math.round(size * 0.42) + 'px', background: `hsl(${hueOf(p.name)} 70% 45%)` } },
  (p.name || '?').trim().charAt(0).toUpperCase());

export function studioRoutes(ctx) {
  const { app, topbar, nav, setTitle, setCleanup } = ctx;
  let S = null;   // stato: chiavi, pagine, storie
  const load = async () => { S = await get('/api/ai/state'); return S; };
  const keysReady = () => S && ['text', 'image', 'voice'].every((w) => Object.values(S.keys).some((k) => k.set && k.does.includes(w)));
  const missing = () => ['text', 'image', 'voice'].filter((w) => !Object.values(S.keys).some((k) => k.set && k.does.includes(w)));

  // ------------------------------------------------------------- guida: come funziona
  function guide() {
    const bg = h('div', { class: 'modal-bg' });
    const close = () => { bg.remove(); try { localStorage.setItem('nf.aiGuide', '1'); } catch (e) { /* */ } };
    const step = (n, ic, t, d) => h('div', { class: 'ai-gstep' }, h('span', { class: 'n' }, String(n)), h('span', { class: 'ic' }, icon(ic, 18)), h('div', null, h('b', null, t), h('span', null, d)));
    const row = (what, who, price) => h('tr', null, h('td', null, h('b', null, what)), h('td', null, who), h('td', null, price));
    bg.append(h('div', { class: 'modal ai-guide' },
      h('div', { class: 'ai-mh' }, h('h2', null, 'Come funziona Storie AI'), h('button', { class: 'iconbtn', 'aria-label': 'Chiudi', onclick: close }, icon('x', 16))),
      h('p', { class: 'wz-p' }, 'Da un argomento (o dal tuo script) a un video verticale pronto: storia, immagini, voce, animazioni e montaggio. Usi i tuoi account AI e paghi solo quello che generi, direttamente a loro.'),
      h('div', { class: 'ai-gsteps' },
        step(1, 'lock', 'Collega le chiavi', 'Una volta sola, in "Chiavi AI". Restano cifrate sul tuo computer.'),
        step(2, 'user', 'Crea una pagina', 'È il tuo profilo social: stile delle immagini, personaggi con foto di riferimento, voci, musica. Tutte le storie della pagina avranno lo stesso stile.'),
        step(3, 'text', 'Script', 'Scrivi un argomento, lascia scegliere l\'AI o incolla il tuo script. Lo divido io in scene da 3–5 secondi: il numero di scene dipende dalla lunghezza del testo.'),
        step(4, 'image', 'Immagini', 'Una per scena, con lo stile della pagina e la stessa faccia dei personaggi.'),
        step(5, 'speaker', 'Voce', 'Voce AI (narratore e personaggi) oppure la tua registrazione. Da qui ogni scena ha la sua durata vera.'),
        step(6, 'film', 'Animazioni', 'Ogni scena è un\'immagine che si muove (gratis) o un video AI (fal.ai). Io scelgo le scene importanti, tu decidi quante.'),
        step(7, 'sparkle', 'Crea il video', 'Monto tutto nell\'editor con sottotitoli e musica. Rifinisci ed esporti in 1080×1920.')),
      h('h3', null, 'Cosa collegare'),
      h('table', { class: 'ai-gtable' },
        h('tr', null, h('th', null, 'Per'), h('th', null, 'Servizi'), h('th', null, 'Costo indicativo')),
        row('Testi (storia e scene)', 'Anthropic, OpenAI o Gemini', 'pochi centesimi a storia'),
        row('Immagini', 'fal.ai, Gemini o OpenAI', 'circa $0.04–0.06 a immagine'),
        row('Voce', 'ElevenLabs o OpenAI', 'da pochi centesimi a circa $0.20 al minuto'),
        row('Video AI', 'fal.ai (Kling o LTX)', 'da $0.24 a $0.35 circa a clip, secondo la qualità')),
      h('p', { class: 'ai-tip' }, 'Esempio: una storia da 60 secondi con 15 immagini, voce ElevenLabs e 3 scene in video AI costa circa $2–3. Solo con immagini animate, meno di $1. I prezzi li decidono i servizi e cambiano: le cifre sono stime.'),
      h('div', { class: 'ai-tip2' }, icon('info', 15), h('span', null, h('b', null, 'Il minimo per iniziare: '), 'una chiave OpenAI (fa testi, immagini e voce). La combinazione migliore: Anthropic + fal.ai + ElevenLabs.')),
      h('div', { class: 'crop-btns' }, h('button', { class: 'btn primary', onclick: close }, 'Ho capito'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  // ------------------------------------------------------------- chiavi AI
  function keysDialog(onDone) {
    const bg = h('div', { class: 'modal-bg' });
    const list = h('div', { class: 'ai-keys' });
    const close = () => { bg.remove(); onDone && onDone(); };
    const paint = () => rc(list, ...Object.entries(S.keys).map(([id, k]) => {
      const inp = h('input', { class: 'input', type: 'password', autocomplete: 'off', spellcheck: 'false', placeholder: k.set ? 'Chiave salvata ' + k.hint : 'Incolla la chiave', 'aria-label': 'Chiave ' + k.name });
      const state = !k.set ? h('span', { class: 'ai-kst none' }, 'Non collegato')
        : k.ok === false ? h('span', { class: 'ai-kst bad' }, icon('x', 11, 'currentColor', 3), 'Non funziona')
          : k.ok ? h('span', { class: 'ai-kst ok' }, icon('check', 11, 'currentColor', 3), 'Collegato') : h('span', { class: 'ai-kst' }, 'Salvata ' + k.hint);
      const save = h('button', { class: 'btn primary sm', onclick: async () => {
        if (!inp.value.trim()) return inp.focus();
        save.disabled = true;
        try { S.keys = await post('/api/ai/key', { provider: id, key: inp.value.trim() }); inp.value = '';
          try { S.keys = await post('/api/ai/key/test', { provider: id }); toast(k.name + ' collegato'); } catch (e) { toast(e.message, true); await load().catch(() => {}); }
        } catch (e) { toast(e.message, true); }
        paint();
      } }, 'Salva');
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') save.click(); });
      // Anthropic: le chiavi di organizzazione vogliono anche l'ID del workspace
      let wsRow = null;
      if (id === 'anthropic' && (k.needWorkspace || k.workspace || wsOpen)) {
        const ws = h('input', { class: 'input', autocomplete: 'off', spellcheck: 'false', placeholder: 'ID workspace: wrkspc_…', value: k.workspace || '', 'aria-label': 'ID workspace Anthropic' });
        const wsSave = h('button', { class: 'btn sm', onclick: async () => {
          wsSave.disabled = true;
          try { S.keys = await post('/api/ai/key/workspace', { provider: id, workspace: ws.value.trim() });
            if (S.keys[id].set) { try { S.keys = await post('/api/ai/key/test', { provider: id }); toast(k.name + ' collegato'); } catch (e) { toast(e.message, true); await load().catch(() => {}); } }
          } catch (e) { toast(e.message, true); }
          paint();
        } }, 'Salva ID');
        ws.addEventListener('keydown', (e) => { if (e.key === 'Enter') wsSave.click(); });
        wsRow = h('div', { class: 'ai-kws' }, h('small', null, 'Chiave di organizzazione? Serve anche l\'ID del workspace: console.anthropic.com → Settings → Workspaces → copia l\'ID (inizia con wrkspc_).'),
          h('div', { class: 'ai-krow' }, ws, wsSave));
      }
      return h('div', { class: 'ai-key' + (k.set ? ' on' : '') },
        h('div', { class: 'ai-kh' }, h('b', null, k.name), h('div', { class: 'ai-does' }, ...k.does.map((d) => h('span', null, DOES[d]))), h('div', { class: 'grow' }), state),
        h('p', { class: 'ai-kuse' }, USES[id] || ''),
        h('div', { class: 'ai-krow' }, inp, save,
          k.set ? h('button', { class: 'btn sm ghost', 'data-tip': 'Prova la chiave', onclick: async () => { try { S.keys = await post('/api/ai/key/test', { provider: id }); toast('Funziona'); } catch (e) { toast(e.message, true); } await load(); paint(); } }, 'Prova') : null,
          k.set ? h('button', { class: 'iconbtn', 'aria-label': 'Togli la chiave', 'data-tip': 'Togli la chiave', onclick: async () => { S.keys = await post('/api/ai/key', { provider: id, key: '' }); paint(); } }, icon('trash', 14)) : null),
        wsRow,
        h('div', { class: 'ai-klinks' }, h('button', { class: 'linkish ai-where', onclick: () => post('/api/openurl', { url: k.site }).catch(() => {}) }, 'Dove trovo la chiave?'),
          id === 'anthropic' && !wsRow ? h('button', { class: 'linkish ai-where', onclick: () => { wsOpen = true; paint(); } }, 'Ho una chiave di organizzazione') : null));
    }));
    let wsOpen = false;
    paint();
    bg.append(h('div', { class: 'modal ai-kmodal' },
      h('div', { class: 'ai-mh' }, h('h2', null, 'Chiavi AI'), h('button', { class: 'iconbtn', 'aria-label': 'Chiudi', onclick: close }, icon('x', 16))),
      h('div', { class: 'ai-trust' }, icon('shield', 18), h('div', null, h('b', null, 'Usi i tuoi account, paghi solo quello che usi.'),
        h('span', null, 'Le chiavi restano solo su questo computer, cifrate. Noonframe non le vede e non prende commissioni: ogni immagine o voce la paghi direttamente al servizio.'))),
      h('p', { class: 'ai-tip' }, 'Per iniziare bastano: uno per i testi (Anthropic, OpenAI o Gemini), uno per le immagini (fal.ai, Gemini o OpenAI) e uno per la voce (ElevenLabs o OpenAI). Solo OpenAI fa tutte e tre le cose.'),
      list,
      h('div', { class: 'crop-btns' }, h('button', { class: 'btn primary', onclick: close }, 'Fatto'))));
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    document.body.append(bg);
  }

  // ------------------------------------------------------------- home: pagine e storie
  async function home(pid) {
    setTitle('Storie AI');
    await load();
    let sel = pid || (S.pages[0] && S.pages[0].id) || null;
    const wrap = h('div', { class: 'aih-wrap' });
    const STATUS = { script: 'Script', scene: 'Immagini', produzione: 'In lavorazione', montata: 'Montata' };
    const openKeys = () => keysDialog(() => load().then(paint));
    const paint = () => {
      const keysOk = keysReady();
      const anyKey = Object.values(S.keys).some((k) => k.set);
      const page = S.pages.find((p) => p.id === sel);
      // barra in alto: le pagine come schede, le chiavi a destra
      const bar = h('div', { class: 'aih-bar' },
        h('div', { class: 'aih-pages' }, ...S.pages.map((p) => h('button', { class: 'aih-ptab' + (p.id === sel ? ' on' : ''), onclick: () => { sel = p.id; paint(); } },
          pageAv(p, 24), h('span', { 'data-notr': '' }, p.name))),
          h('button', { class: 'aih-ptab add', onclick: () => nav('aipage', 'new') }, icon('plus', 14, 'currentColor', 2.2), 'Nuova pagina')),
        h('div', { class: 'grow' }),
        h('button', { class: 'aih-fmt', onclick: () => nav('aiformats') }, icon('library', 15), 'Formati'),
        h('button', { class: 'aih-keys' + (keysOk ? ' ok' : anyKey ? ' part' : ''), onclick: openKeys },
          h('span', { class: 'dot' }), h('span', null, keysOk ? 'Chiavi AI collegate' : anyKey ? 'Mancano: ' + missing().map((w) => DOES[w]).join(', ') : 'Collega le chiavi AI')));
      if (!anyKey || !page) {
        const first = !anyKey;
        rc(wrap, bar, h('section', { class: 'aih-hero empty' },
          h('div', { class: 'aih-glow' }),
          h('div', { class: 'aih-emptyart' }, h('i'), h('i'), h('i'), h('span', { class: 'art-orb' })),
          h('h1', null, first ? 'Storie AI, con i tuoi account' : 'Crea la tua prima pagina'),
          h('p', null, first ? 'Scrivi un argomento o incolla il tuo script: l\'AI crea le immagini, la voce e le clip, Noonframe monta il video 9:16 con sottotitoli e musica. Paghi solo quello che generi, direttamente ai servizi.'
            : 'Una pagina è l\'identità di un profilo social: stile delle immagini, personaggi, voci e musica. Tutte le storie della pagina avranno lo stesso stile.'),
          h('div', { class: 'aih-cta' },
            h('button', { class: 'btn primary big', onclick: first ? openKeys : () => nav('aipage', 'new') }, icon(first ? 'lock' : 'plus', 15, '#fff'), first ? 'Collega le chiavi AI' : 'Crea la pagina'),
            h('button', { class: 'btn big ghost', onclick: () => guide() }, icon('info', 15), 'Come funziona')),
          h('div', { class: 'aih-steps' }, ...[['lock', 'Chiavi', 'Una volta sola'], ['user', 'Pagina', 'Stile e personaggi'], ['text', 'Script', 'Argomento o testo tuo'], ['image', 'Immagini e voce', 'Scena per scena'], ['film', 'Video', 'Montato da solo']]
            .map(([ic, t, sub], i) => h('div', { class: 'aih-step' + ((first ? 0 : 1) === i ? ' cur' : (first ? 0 : 1) > i ? ' done' : '') }, h('span', { class: 'ic' }, icon(ic, 16)), h('b', null, t), h('small', null, sub))))));
        return;
      }
      const stories = S.stories.filter((x) => x.page === page.id);
      const hue = hueOf(page.name);
      const cast = page.characters || [];
      const hero = h('section', { class: 'aih-hero', style: { '--h': hue } },
        h('div', { class: 'aih-glow' }),
        h('div', { class: 'aih-top' }, pageAv(page, 64),
          h('div', { class: 'aih-who' }, h('h1', { 'data-notr': '' }, page.name),
            h('div', { class: 'aih-meta' }, page.handle ? h('span', { 'data-notr': '' }, '@' + page.handle) : null,
              h('span', null, icon('image', 12), PRESET_NAMES[(page.style || {}).preset] || 'Stile personale'),
              h('span', null, icon('speaker', 12), h('span', { 'data-notr': '' }, (page.narrator || {}).name || 'Voce da scegliere')),
              h('span', null, icon('film', 12), { none: 'Solo immagini animate', few: 'Poche scene in video AI', half: 'Metà in video AI', all: 'Tutto in video AI' }[(page.videoCfg || {}).share || 'few']))),
          h('div', { class: 'grow' }),
          h('button', { class: 'btn big ghost', onclick: () => nav('aipage', page.id) }, icon('sliders', 15), 'Modifica pagina'),
          h('button', { class: 'btn primary big aih-new', onclick: () => newStory(page) }, icon('sparkle', 16, '#fff'), 'Nuova storia')),
        cast.length ? h('div', { class: 'aih-cast' }, h('small', null, 'Personaggi'), ...cast.map((c) => h('div', { class: 'aih-castc' },
          c.refs && c.refs[0] ? h('img', { src: mediaUrl(c.refs[0]), alt: '' }) : h('span', { class: 'ai-pav', style: { background: `hsl(${hueOf(c.name)} 55% 40%)` } }, c.name.charAt(0)),
          h('b', { 'data-notr': '' }, c.name), (c.refs || []).length ? h('i', { 'data-tip': (c.refs || []).length + ' foto di riferimento' }, icon('check', 10, '#fff', 3)) : null)))
          : h('button', { class: 'aih-nocast', onclick: () => nav('aipage', page.id) }, icon('plus', 13), 'Aggiungi un personaggio con le sue foto: avrà sempre la stessa faccia'));
      const grid = stories.length ? h('div', { class: 'aih-grid' }, ...stories.map((x) => h('div', { class: 'aih-card', role: 'button', tabindex: '0', onclick: () => nav('aistory', x.id) },
        h('div', { class: 'aih-shot' }, x.thumb ? h('img', { src: mediaUrl(x.thumb), alt: '', loading: 'lazy' }) : h('span', { class: 'aih-ph' }, icon('sparkle', 22)),
          h('span', { class: 'aih-st s-' + x.status }, STATUS[x.status] || x.status),
          h('button', { class: 'aih-del', 'aria-label': 'Elimina', 'data-tip': 'Elimina la storia', onclick: async (e) => {
            e.stopPropagation();
            if (!await confirmBox('Eliminare la storia?', 'Si cancellano script, immagini, voci e video generati. Il video già montato (se c\'è) resta tra i progetti.', 'Elimina', true)) return;
            await post('/api/ai/story/delete', { id: x.id }); await load(); paint();
          } }, icon('trash', 13, '#fff')),
          h('div', { class: 'aih-over' }, h('b', { 'data-notr': '' }, x.title || 'Storia'),
            h('small', null, x.scenes + ' scene · ' + usd(x.cost))))))) 
        : h('div', { class: 'aih-emptyst' }, h('span', { class: 'ic' }, icon('sparkle', 20, '#fff')), h('div', null, h('b', null, 'Nessuna storia ancora'),
          h('span', null, 'Premi "Nuova storia": scrivi un argomento, lascia scegliere l\'AI o incolla il tuo script.')),
          h('button', { class: 'btn primary', onclick: () => newStory(page) }, 'Inizia'));
      rc(wrap, bar, hero,
        h('div', { class: 'phead' }, h('h2', null, 'Storie'), h('span', { class: 'pcount' }, String(stories.length)), h('div', { class: 'grow' }),
          h('button', { class: 'btn ghost sm', onclick: () => nav('story') }, icon('image', 14), 'Storia con immagini tue')),
        grid);
    };
    paint();
    app.append(topbar(-1, h('button', { class: 'btn ghost sm', onclick: () => guide() }, icon('info', 14), 'Come funziona'), false, { name: 'Storie AI', home: true }), h('main', { class: 'ai-home2' }, wrap));
    let seen = false;
    try { seen = localStorage.getItem('nf.aiGuide') === '1'; } catch (e) { seen = true; }
    if (!seen) setTimeout(guide, 300);
  }

  // ------------------------------------------------------------- nuova storia (finestra)
  function newStory(page) {
    if (!keysReady()) { toast('Collega prima le chiavi AI: mancano ' + missing().map((w) => DOES[w]).join(', '), true); return keysDialog(); }
    let mode = 0, dur = page.duration || 60, fmtId = page.lastFormat || '';
    let fmts = [];
    get('/api/ai/formats').then((r) => { fmts = r.formats.filter((f) => f.hasPrompt); paint(); }).catch(() => {});
    const MODES = ['Argomento', 'Scegli tu', 'Ho lo script'];
    const box = h('div', { class: 'ai-nsbody' });
    const topic = h('textarea', { class: 'input ai-ta', rows: 3, placeholder: 'Es. Una ragazza sente bussare alla porta, ma vive da sola…' });
    const script = h('textarea', { class: 'input ai-ta', rows: 9, placeholder: 'Incolla lo script: lo divido in scene senza cambiare le parole.' });
    const durs = h('div', { class: 'ai-durs' });
    const paintD = () => rc(durs, ...[30, 45, 60, 90].map((d) => h('button', { class: 'ai-chip' + (d === dur ? ' on' : ''), onclick: () => { dur = d; paintD(); } }, d + ' s')));
    const paint = () => {
      paintD();
      rc(box, seg(MODES, mode, (i) => { mode = i; paint(); }),
        mode === 0 ? h('div', { class: 'field' }, h('label', null, 'Di cosa parla?'), topic)
          : mode === 1 ? h('p', { class: 'wz-p' }, 'L\'AI sceglie un argomento nuovo adatto alla pagina (evitando le storie già fatte) e scrive tutto.')
            : h('div', { class: 'field' }, h('label', null, 'Script'), script,
              h('p', { class: 'field-note' }, 'Incolla il testo che verrà letto (anche lungo). Lo divido io in scene da 3–5 secondi senza cambiare le parole, e per ogni scena preparo la descrizione dell\'immagine. Se hai già la registrazione, la carichi nel passaggio Voce.')),
        mode !== 2 ? h('div', { class: 'field' }, h('label', null, 'Durata'), durs) : null,
        h('div', { class: 'field' }, h('label', null, 'Formato'), (() => {
          const sel = h('select', { class: 'input' }, h('option', { value: '' }, 'Storia libera (senza formato)'), ...fmts.map((f) => h('option', { value: f.id, selected: f.id === fmtId ? true : null }, f.name)));
          sel.addEventListener('change', () => { fmtId = sel.value; });
          return sel; })(),
          h('p', { class: 'field-note' }, fmts.length ? 'Il formato dà la struttura, il ritmo e le regole imparate dai video di riferimento.' : 'Nessun formato ancora: creane uno in "Formati" caricando i video che funzionano.')));
      setTimeout(() => (mode === 0 ? topic : mode === 2 ? script : go).focus(), 30);
    };
    const bg = h('div', { class: 'modal-bg' });
    const msg = h('div', { class: 'ai-busy', hidden: true }, h('div', { class: 'spinner' }), h('span', null, 'Scrivo la storia…'));
    const go = h('button', { class: 'btn primary', onclick: async () => {
      go.disabled = true; msg.hidden = false;
      try {
        const job = await post('/api/ai/story/write', { page: page.id, mode: ['topic', 'auto', 'script'][mode], topic: topic.value, script: script.value, duration: dur, format: fmtId || null });
        const r = await pollJob(job.id, (j) => { if (j.message) msg.lastChild.textContent = j.message + '…'; });
        if (r.status !== 'done') throw new Error(r.error || 'Non riuscito');
        bg.remove(); nav('aistory', r.result.story);
      } catch (e) { go.disabled = false; msg.hidden = true; toast(e.message, true); }
    } }, icon('sparkle', 14, '#fff'), 'Scrivi la storia');
    paint();
    bg.append(h('div', { class: 'modal ai-nsmodal' },
      h('div', { class: 'ai-mh' }, h('h2', null, 'Nuova storia'), h('span', { class: 'ai-pchip', 'data-notr': '' }, page.name), h('div', { class: 'grow' }),
        h('button', { class: 'iconbtn', 'aria-label': 'Chiudi', onclick: () => bg.remove() }, icon('x', 16))),
      box, msg, h('div', { class: 'crop-btns' }, h('button', { class: 'btn ghost', onclick: () => bg.remove() }, 'Annulla'), go)));
    document.body.append(bg);
  }

  // ------------------------------------------------------------- pagina (preset)
  async function pageEditor(pid) {
    await load();
    const isNew = !pid || pid === 'new';
    const P = isNew ? { name: 'Nuova pagina', handle: '', lang: 'it', niche: '', duration: 60, style: { preset: 'cinematic', prompt: S.presets.cinematic },
      narrative: {}, characters: [], narrator: {}, textCfg: {}, imageCfg: {}, voiceCfg: { stability: 0.5, similarity: 0.75, style: 0, speed: 1 }, edit: { captions: 'word', musicVol: 22 } }
      : JSON.parse(JSON.stringify(S.pages.find((p) => p.id === pid) || {}));
    if (!isNew && !P.id) { toast('Pagina non trovata', true); return nav('studio'); }
    setTitle(P.name || 'Pagina');
    let tab = 'id', dirty = false, voices = null;
    const TABS = [['id', 'Identità', 'user'], ['product', 'Prodotto', 'star'], ['style', 'Stile', 'image'], ['cast', 'Personaggi', 'user'], ['story', 'Narrazione', 'text'], ['voice', 'Voci', 'speaker'], ['edit', 'Montaggio', 'film'], ['models', 'Modelli AI', 'sparkle']];
    const nav2 = h('nav', { class: 'ai-tabs' });
    const body = h('div', { class: 'ai-pbody' });
    const saveBtn = h('button', { class: 'btn primary', onclick: () => save(true) }, isNew ? 'Crea pagina' : 'Salva');
    const mark = () => { dirty = true; saveBtn.disabled = false; };
    async function save(leave) {
      saveBtn.disabled = true;
      try {
        const r = await post('/api/ai/page', P); Object.assign(P, r); dirty = false;
        await load();
        if (leave) { toast(isNew ? 'Pagina creata' : 'Pagina salvata'); nav('studio', P.id); }
        return r;
      } catch (e) { saveBtn.disabled = false; toast(e.message, true); }
    }
    const field = (label, el, note) => h('div', { class: 'field' }, h('label', null, label), el, note ? h('p', { class: 'field-note' }, note) : null);
    const inp = (obj, key, ph, max) => { const e = h('input', { class: 'input', value: obj[key] || '', placeholder: ph || '', maxlength: max || 200 }); e.addEventListener('input', () => { obj[key] = e.value; mark(); }); return e; };
    const ta = (obj, key, ph, rows) => { const e = h('textarea', { class: 'input ai-ta', rows: rows || 3, placeholder: ph || '' }); e.value = obj[key] || ''; e.addEventListener('input', () => { obj[key] = e.value; mark(); }); return e; };
    const selectEl = (opts, cur, onPick) => { const s = h('select', { class: 'input' }, ...opts.map(([v, l]) => h('option', { value: v, selected: v === cur ? true : null }, l))); s.addEventListener('change', () => { onPick(s.value); mark(); }); return s; };
    async function loadVoices() {
      const pv = (P.voiceCfg || {}).provider || (S.keys.elevenlabs.set ? 'elevenlabs' : S.keys.openai.set ? 'openai' : '');
      if (!pv) { voices = []; return; }
      try { voices = (await post('/api/ai/voices', { provider: pv })).voices; } catch (e) { voices = []; toast(e.message, true); }
    }
    const voicePicker = (cur, onPick) => {
      if (voices === null) { loadVoices().then(draw); return h('div', { class: 'ai-busy' }, h('div', { class: 'spinner' }), h('span', null, 'Carico le voci…')); }
      if (!voices.length) return h('p', { class: 'field-note' }, 'Collega ElevenLabs o OpenAI in Chiavi AI per scegliere le voci.');
      let curId = cur && cur.id;
      const lg = P.lang || 'it';
      const sel = selectEl([['', '— Scegli una voce —'], ...voices.map((v) => [v.id, (v.langs && v.langs[lg] ? '★ ' : '') + v.name + ' · ' + voiceDesc(v.labels || {}, v.langs && v.langs[lg])])], curId, (id) => {
        const v = voices.find((x) => x.id === id); curId = id; onPick(v ? { id: v.id, name: v.name } : { id: '', name: '' }); stopVoice();
      });
      const pv = (P.voiceCfg || {}).provider || (S.keys.elevenlabs.set ? 'elevenlabs' : 'openai');
      const listen = (custom) => async (e) => {
        const b = e.currentTarget;
        if (!curId) return toast('Scegli prima una voce', true);
        if (playing && playing.btn === b) return stopVoice();
        stopVoice(); b.classList.add('busy');
        try {
          const r = await post('/api/ai/voice/sample', { provider: pv, voice: curId, custom, lang: P.lang || 'it', model: (P.voiceCfg || {}).model || '', settings: P.voiceCfg || {} });
          const a = new Audio(mediaUrl(r.path)); playing = { a, btn: b }; b.classList.add('on');
          a.addEventListener('ended', stopVoice); await a.play();
        } catch (err) { toast(err.message, true); stopVoice(); }
        b.classList.remove('busy');
      };
      return h('div', { class: 'ai-vpick' }, sel,
        pv === 'elevenlabs' ? h('button', { class: 'btn sm ai-vplay', 'data-tip': 'Voci madrelingua della libreria di ElevenLabs, con il campione nella lingua della pagina', onclick: () => voiceLibrary(onPick) }, icon('globe', 13), 'Voci ' + (LANG_ADJ[P.lang || 'it'] || '')) : null,
        h('button', { class: 'btn sm ai-vplay', 'data-tip': pv === 'elevenlabs' ? 'Ascolta la voce nella lingua della pagina: gratis se ElevenLabs ha il campione in quella lingua, altrimenti legge una frase di prova (meno di un centesimo)' : 'Ascolta la voce con una frase di prova (costa meno di un centesimo)', onclick: listen(false) }, icon('play', 12), 'Ascolta'),
        h('button', { class: 'btn sm ghost ai-vplay', 'data-tip': 'Frase di prova in italiano con velocità, stabilità ed espressività della pagina (costa meno di un centesimo)', onclick: listen(true) }, icon('speaker', 13), 'Prova con le impostazioni'));
    };
    const LANG_ADJ = { it: 'italiane', en: 'inglesi', es: 'spagnole', fr: 'francesi', de: 'tedesche', pt: 'portoghesi' };
    const TR = { male: 'uomo', female: 'donna', neutral: 'neutra', young: 'giovane', middle_aged: 'adulta', 'middle aged': 'adulta', old: 'anziana',
      american: 'accento americano', british: 'accento inglese', australian: 'accento australiano', italian: 'accento italiano', standard: 'italiano standard',
      northern: 'accento del nord', southern: 'accento del sud', roman: 'accento romano', neapolitan: 'accento napoletano', sicilian: 'accento siciliano', milanese: 'accento milanese' };
    const tr = (x) => TR[String(x || '').toLowerCase()] || x;
    const voiceDesc = (lab, inLang) => [tr(lab.gender), tr(lab.age), inLang ? (inLang.accent ? 'parla ' + (LANG_ADJ[P.lang || 'it'] || '').replace(/e$/, 'o') + ' (' + tr(inLang.accent) + ')' : 'parla ' + (LANG_ADJ[P.lang || 'it'] || '').replace(/e$/, 'o')) : tr(lab.accent)].filter(Boolean).join(', ');
    function voiceLibrary(onPick) {
      const lg = P.lang || 'it';
      const bg = h('div', { class: 'modal-bg' });
      const list = h('div', { class: 'ai-vlib' }, h('div', { class: 'ai-busy' }, h('div', { class: 'spinner' }), h('span', null, 'Cerco le voci…')));
      let gender = '', q = '';
      const search = h('input', { class: 'input', placeholder: 'Cerca (es. narratore, calda, giovane)…' });
      const load = async () => {
        rc(list, h('div', { class: 'ai-busy' }, h('div', { class: 'spinner' }), h('span', null, 'Cerco le voci…')));
        try {
          const r = await post('/api/ai/voice/shared', { lang: lg, gender, search: q });
          rc(list, ...(r.voices.length ? r.voices.map((v) => {
            const play = h('button', { class: 'btn sm ai-vplay', onclick: async (e) => {
              const b = e.currentTarget; if (playing && playing.btn === b) return stopVoice(); stopVoice(); b.classList.add('busy');
              try { const s = await post('/api/ai/voice/sample', { provider: 'elevenlabs', voice: v.id, lang: lg }); const a = new Audio(mediaUrl(s.path)); playing = { a, btn: b }; b.classList.add('on'); a.addEventListener('ended', stopVoice); await a.play(); }
              catch (err) { toast(err.message, true); stopVoice(); } b.classList.remove('busy'); } }, icon('play', 12), 'Ascolta');
            const use = h('button', { class: 'btn sm primary', onclick: async () => {
              use.disabled = true;
              try { const r2 = await post('/api/ai/voice/add', { owner: v.owner, voice: v.id, name: v.name }); stopVoice(); bg.remove(); voices = null; onPick({ id: r2.id, name: r2.name || v.name }); mark(); toast('Voce aggiunta: ' + v.name); draw(); }
              catch (err) { toast(err.message, true); use.disabled = false; } } }, 'Usa questa');
            return h('div', { class: 'ai-vrow' }, h('div', { class: 'ai-vinfo' }, h('b', { 'data-notr': '' }, v.name), h('small', null, [tr(v.gender), tr(v.age), v.accent ? tr(v.accent) : ''].filter(Boolean).join(' · ')),
              v.description ? h('small', { class: 'ai-vd', 'data-notr': '' }, v.description) : null), play, use);
          }) : [h('p', { class: 'field-note' }, 'Nessuna voce trovata con questi filtri.')]));
        } catch (e) { rc(list, h('p', { class: 'ai-err' }, e.message)); }
      };
      const gseg = seg(['Tutte', 'Donna', 'Uomo'], 0, (k) => { gender = ['', 'female', 'male'][k]; load(); });
      search.addEventListener('keydown', (e) => { if (e.key === 'Enter') { q = search.value.trim(); load(); } });
      bg.append(h('div', { class: 'modal ai-vlmodal' },
        h('div', { class: 'ai-mh' }, h('h2', null, 'Voci ' + (LANG_ADJ[lg] || '')), h('button', { class: 'iconbtn', onclick: () => { stopVoice(); bg.remove(); } }, icon('x', 16))),
        h('p', { class: 'wz-p' }, 'Voci madrelingua della libreria di ElevenLabs: il campione è nella lingua della pagina. "Usa questa" la aggiunge alle tue voci su ElevenLabs (gratis; il numero di voci dipende dal tuo piano).'),
        h('div', { class: 'ai-vlbar' }, gseg, search), list));
      bg.addEventListener('click', (e) => { if (e.target === bg) { stopVoice(); bg.remove(); } });
      document.body.append(bg); load();
    }
    let playing = null;
    const stopVoice = () => { if (playing) { try { playing.a.pause(); } catch (e) { /* */ } playing.btn.classList.remove('on'); playing = null; } };
    setCleanup && setCleanup(stopVoice);
    const T = {
      id: () => [h('h2', null, 'Identità'), h('p', { class: 'wz-p' }, 'Chi è questa pagina: il nome, il profilo social e di cosa parla.'),
        h('div', { class: 'prof-grid' }, field('Nome della pagina', inp(P, 'name', 'Es. Storie di paura', 60)), field('Username social', inp(P, 'handle', 'senza @', 40))),
        field('Nicchia e argomenti', ta(P, 'niche', 'Es. storie horror brevi ispirate a leggende urbane italiane, ambientate oggi', 3)),
        h('div', { class: 'prof-grid' }, field('Lingua dei video', selectEl(LANGS, P.lang || 'it', (v) => { P.lang = v; })),
          field('Durata media', selectEl([['30', '30 secondi'], ['45', '45 secondi'], ['60', '60 secondi'], ['90', '90 secondi'], ['120', '2 minuti']], String(P.duration || 60), (v) => { P.duration = +v; })))],
      product: () => { const pr = P.product = P.product || {}; return [h('h2', null, 'Prodotto'),
        h('p', { class: 'wz-p' }, 'Se la pagina vende qualcosa (un\'app, un corso, un prodotto digitale), scrivilo qui: gli script di vendita useranno solo queste informazioni, senza inventare niente. Lascia vuoto per le pagine di storie.'),
        h('div', { class: 'prof-grid' }, field('Nome del prodotto', inp(pr, 'name', 'Es. PandaCoco', 80)), field('Per chi è', inp(pr, 'audience', 'Es. chi vuole imparare il cinese da zero', 300))),
        field('Cos\'è e cosa fa', ta(pr, 'what', 'Es. app che insegna il cinese con lezioni da 5 minuti e un tutor AI', 3)),
        field('Benefici principali', ta(pr, 'benefits', 'Es. impari 10 parole al giorno, pronuncia corretta dall\'AI, funziona anche offline', 3)),
        h('div', { class: 'prof-grid' }, field('Prezzo / offerta', inp(pr, 'offer', 'Es. gratis 7 giorni, poi 4,99 €/mese', 200)), field('Invito all\'azione', inp(pr, 'cta', 'Es. link in bio, cerca PandaCoco sull\'App Store', 200)))]; },
      style: () => {
        const st = P.style = P.style || {};
        const pr = ta(st, 'prompt', 'Descrivi lo stile delle immagini (in inglese funziona meglio)', 5);
        return [h('h2', null, 'Stile delle immagini'), h('p', { class: 'wz-p' }, 'È il "master prompt": viene aggiunto a ogni immagine, così tutte le storie della pagina hanno lo stesso aspetto.'),
          h('div', { class: 'ai-presets' }, ...Object.entries(S.presets).map(([k, v]) => h('button', { class: 'ai-preset' + (st.preset === k ? ' on' : ''), onclick: () => { st.preset = k; st.prompt = v; pr.value = v; mark(); draw(); } },
            h('i', { class: 'pv-' + k }), h('b', null, PRESET_NAMES[k] || k)))),
          field('Prompt di stile', pr, 'Puoi partire da uno stile qui sopra e modificarlo: palette, luce, epoca, tipo di inquadrature.')];
      },
      cast: () => [h('h2', null, 'Personaggi ricorrenti'),
        h('p', { class: 'wz-p' }, 'Descrivi l\'aspetto e aggiungi 1–4 foto di riferimento: le immagini useranno sempre la stessa faccia e gli stessi vestiti (con fal.ai Nano Banana, Gemini o OpenAI).'),
        ...(P.characters || []).map((c, i) => h('div', { class: 'ai-char' },
          h('div', { class: 'ai-refs' }, ...(c.refs || []).map((r) => h('div', { class: 'ai-ref' }, h('img', { src: mediaUrl(r), alt: '' }),
            h('button', { class: 'st-x', 'aria-label': 'Togli', onclick: async () => { try { const pg = await post('/api/ai/page/ref/remove', { page: P.id, char: c.id, path: r }); P.characters = pg.characters; draw(); } catch (e) { toast(e.message, true); } } }, icon('x', 11, '#fff', 2.6)))),
            (c.refs || []).length < 4 ? h('button', { class: 'ai-ref add', 'data-tip': 'Aggiungi una foto di riferimento', onclick: () => addRef(c) }, icon('plus', 18), h('small', null, 'Foto')) : null),
          h('div', { class: 'ai-cf' },
            h('div', { class: 'prof-grid' }, field('Nome', inp(c, 'name', 'Es. Emma', 40)), field('Ruolo', inp(c, 'role', 'Es. protagonista', 60))),
            field('Aspetto (in inglese)', ta(c, 'look', 'Es. young woman, 25, short black hair, green eyes, grey oversized hoodie', 2)),
            field('Personalità', ta(c, 'personality', 'Es. coraggiosa ma diffidente, ironica', 2)),
            field('Voce', voicePicker(c.voice, (v) => { c.voice = v; })),
            h('button', { class: 'linkish danger', onclick: () => { P.characters.splice(i, 1); mark(); draw(); } }, 'Togli il personaggio')))),
        h('button', { class: 'btn', onclick: () => { P.characters = [...(P.characters || []), { id: '', name: 'Nuovo personaggio', look: '', personality: '', role: '', voice: {}, refs: [] }]; mark(); draw(); } }, icon('plus', 14), 'Aggiungi personaggio')],
      story: () => { const n = P.narrative = P.narrative || {}; return [h('h2', null, 'Narrazione'), h('p', { class: 'wz-p' }, 'Come scrive l\'AI per questa pagina. Ricorda anche le storie già fatte, per non ripeterle.'),
        h('div', { class: 'prof-grid' }, field('Tipo di storie', inp(n, 'kind', 'Es. horror psicologico, mistero', 200)), field('Tono', inp(n, 'tone', 'Es. teso, sussurrato, ironico', 200))),
        h('div', { class: 'prof-grid' }, field('Come apre (hook)', inp(n, 'hook', 'Es. una domanda inquietante nei primi 2 secondi', 300)), field('Finale', inp(n, 'ending', 'Es. colpo di scena, finale aperto', 200))),
        h('div', { class: 'prof-grid' }, field('Punto di vista', selectEl([['terza persona', 'Terza persona'], ['prima persona', 'Prima persona'], ['seconda persona', 'Seconda persona (tu)']], n.pov || 'terza persona', (v) => { n.pov = v; })),
          field('Argomenti da evitare', inp(n, 'avoid', 'Es. violenza esplicita, politica', 300))),
        field('Regole di scrittura', ta(n, 'rules', 'Es. frasi brevi, niente parolacce, sempre un dettaglio sensoriale per scena', 3))]; },
      voice: () => { const vc = P.voiceCfg = P.voiceCfg || {}; const slider = (k, lbl, min, max, step) => { const e = h('input', { type: 'range', min, max, step, value: vc[k] ?? (k === 'speed' ? 1 : 0.5), class: 'crop-zoom' }); const out = h('span', { class: 'ai-sv' }, String(vc[k] ?? e.value)); e.addEventListener('input', () => { vc[k] = +e.value; out.textContent = e.value; mark(); }); return field(lbl, h('div', { class: 'crop-row' }, e, out)); };
        const chars = P.characters || [];
        return [h('h2', null, 'Voci'), h('p', { class: 'wz-p' }, 'Scegli la voce del narratore e quella di ogni personaggio: nelle storie ogni battuta viene letta dalla voce di chi parla. Le impostazioni qui sotto valgono per tutte.'),
          field('Servizio', selectEl([['', 'Automatico'], ['elevenlabs', 'ElevenLabs'], ['openai', 'OpenAI']], vc.provider || '', (v) => { vc.provider = v; voices = null; draw(); })),
          field('Voce del narratore', voicePicker(P.narrator, (v) => { P.narrator = v; })),
          chars.length ? h('div', { class: 'ai-vchars' }, h('h3', null, 'Voci dei personaggi'),
            ...chars.map((c) => field(c.name || 'Personaggio', voicePicker(c.voice, (v) => { c.voice = v; }))))
            : h('p', { class: 'field-note' }, 'Aggiungi i personaggi nella scheda Personaggi: qui potrai dare a ognuno la sua voce.'),
          h('div', { class: 'prof-grid' }, slider('speed', 'Velocità', 0.7, 1.2, 0.05), slider('stability', 'Stabilità', 0, 1, 0.05)),
          h('div', { class: 'prof-grid' }, slider('similarity', 'Somiglianza alla voce', 0, 1, 0.05), slider('style', 'Espressività', 0, 1, 0.05))]; },
      edit: () => { const ed = P.edit = P.edit || {}; return [h('h2', null, 'Montaggio'), h('p', { class: 'wz-p' }, 'Come vengono montati i video: sottotitoli e musica di sottofondo (si abbassa da sola quando si parla).'),
        field('Sottotitoli', seg(['Parola per parola', 'Frase intera'], ed.captions === 'line' ? 1 : 0, (i) => { ed.captions = i ? 'line' : 'word'; mark(); draw(); })),
        field('Scene in video AI (con fal.ai)', (() => { const vc = P.videoCfg = P.videoCfg || {}; const cur = vc.share || 'few';
          return h('div', { class: 'ai-durs' }, ...[['none', 'Nessuna'], ['few', 'Poche'], ['half', 'Metà'], ['all', 'Tutte']].map(([k, l]) => h('button', { class: 'ai-chip' + (cur === k ? ' on' : ''), onclick: () => { vc.share = k; mark(); draw(); } }, l))); })(),
          'Quante scene di ogni nuova storia diventano video AI. Le altre sono immagini che si muovono (gratis). Puoi cambiarlo in ogni storia.'),
        field('Modello dei video AI', (() => { const vc = P.videoCfg = P.videoCfg || {}; const VI = S.videoInfo || {};
          const lbl = () => { const m = VI[vc.model] ? vc.model : (S.models.video.fal || [])[0], i = VI[m] || {}; return (i.name || '') + ' · ' + (i.durs ? priceLbl(i) : ''); };
          const b = h('button', { class: 'btn sm vm-pagebtn', type: 'button', onclick: () => videoModelPicker({ info: VI, current: VI[vc.model] ? vc.model : (S.models.video.fal || [])[0], durs: [2.5],
            sub: 'Il modello usato per le scene video di questa pagina (in ogni storia puoi cambiarlo, anche scena per scena). Il costo a destra è per una frase di 2,5 secondi.',
            onPick: (m) => { vc.provider = 'fal'; vc.model = m; b.replaceChildren(icon('film', 13), lbl()); mark(); } }) }, icon('film', 13), lbl());
          return b; })(),
          'Si paga la durata della clip, non quella della frase. Il costo esatto di ogni clip lo vedi nel passaggio Animazioni.'),
        field('Musica di sottofondo', h('div', { class: 'ai-music' }, icon('music', 16), h('span', { 'data-notr': '' }, ed.music ? ed.music.name : 'Nessuna'),
          h('div', { class: 'grow' }), h('button', { class: 'btn sm', onclick: pickMusic }, ed.music ? 'Cambia' : 'Scegli'),
          ed.music ? h('button', { class: 'iconbtn', 'aria-label': 'Togli', onclick: async () => { const pg = await post('/api/ai/page/music', { page: P.id, path: '' }); P.edit = pg.edit; draw(); } }, icon('x', 14)) : null),
        'Usa solo musica che hai il diritto di usare (tua, royalty free o con licenza).'),
        field('Volume della musica', (() => { const e = h('input', { type: 'range', min: 5, max: 60, step: 1, value: ed.musicVol || 22, class: 'crop-zoom' }); const o = h('span', { class: 'ai-sv' }, (ed.musicVol || 22) + '%'); e.addEventListener('input', () => { ed.musicVol = +e.value; o.textContent = e.value + '%'; mark(); }); return h('div', { class: 'crop-row' }, e, o); })())]; },
      models: () => { const mk = (what, cfgKey) => { const c = P[cfgKey] = P[cfgKey] || {}; const provs = Object.keys(S.models[what]).filter((p) => S.keys[p]); const list = h('datalist', { id: 'dl-' + what }, ...(S.models[what][c.provider] || []).map((m) => h('option', { value: m })));
        const mdl = h('input', { class: 'input', list: 'dl-' + what, value: c.model || '', placeholder: 'Modello consigliato' }); mdl.addEventListener('input', () => { c.model = mdl.value.trim(); mark(); });
        return h('div', { class: 'prof-grid' }, field(DOES[what], selectEl([['', 'Automatico (quello collegato)'], ...provs.map((p) => [p, S.keys[p].name + (S.keys[p].set ? '' : ' (chiave mancante)')])], c.provider || '', (v) => { c.provider = v; c.model = ''; draw(); })),
          field('Modello', h('div', null, mdl, list))); };
        return [h('h2', null, 'Modelli AI'), h('p', { class: 'wz-p' }, 'Quale servizio usa questa pagina per testi, immagini e voce. "Automatico" sceglie tra quelli che hai collegato. Puoi scrivere anche un modello nuovo appena esce.'),
          mk('text', 'textCfg'), mk('image', 'imageCfg'), mk('voice', 'voiceCfg'), mk('video', 'videoCfg'),
          h('p', { class: 'field-note' }, 'Per tenere uguali i personaggi con le foto di riferimento: fal.ai "nano-banana-2/edit", Gemini "flash-image" o OpenAI "gpt-image-1".')]; },
    };
    async function addRef(c) {
      if (!P.id || dirty) { const r = await save(false); if (!r) return; const cc = r.characters.find((x) => x.name === c.name) || r.characters[r.characters.length - 1]; c = cc; }
      try {
        const r = await post('/api/pick', { kind: 'media' });
        const f = (r.files || []).find((x) => x.kind === 'image'); if (!f) return;
        const pg = await post('/api/ai/page/ref', { page: P.id, char: c.id, path: f.path });
        P.characters = pg.characters; draw();
      } catch (e) { toast(e.message, true); }
    }
    async function pickMusic() {
      if (!P.id || dirty) { if (!await save(false)) return; }
      try {
        const r = await post('/api/pick', { kind: 'audio' }); const f = (r.files || [])[0]; if (!f) return;
        const pg = await post('/api/ai/page/music', { page: P.id, path: f.path }); P.edit = pg.edit; draw();
      } catch (e) { toast(e.message, true); }
    }
    function draw() {
      rc(nav2, ...TABS.map(([k, l, ic]) => h('button', { class: 'ai-tab' + (k === tab ? ' on' : ''), onclick: () => { tab = k; draw(); } }, icon(ic, 15), l)),
        h('div', { class: 'grow' }),
        !isNew ? h('button', { class: 'linkish danger ai-delpage', onclick: async () => {
          if (!await confirmBox('Eliminare la pagina?', 'Si cancellano il preset, i personaggi e le foto di riferimento. Le storie e i video restano.', 'Elimina', true)) return;
          await post('/api/ai/page/delete', { id: P.id }); nav('studio');
        } }, 'Elimina pagina') : null);
      rc(body, ...T[tab]().filter(Boolean));
      saveBtn.disabled = !dirty && !isNew;
    }
    app.append(topbar(-1, h('div', { class: 'ai-topact' }, h('button', { class: 'btn ghost', onclick: async () => {
      if (dirty && !await confirmBox('Uscire senza salvare?', 'Le modifiche alla pagina andranno perse.', 'Esci', true)) return; nav('studio', P.id);
    } }, 'Annulla'), saveBtn), false, { name: isNew ? 'Nuova pagina' : P.name, home: true }),
    h('main', { class: 'ai-page' }, nav2, h('div', { class: 'ai-pcard' }, body)));
    draw();
  }

  // ------------------------------------------------------------- storia: script → immagini → voce → animazioni → video
  // riquadro "come funziona" di ogni passaggio (si chiude e resta chiuso)
  function helpBox(key, title, items) {
    let closed = false;
    try { closed = localStorage.getItem('nf.help.' + key) === '0'; } catch (e) { /* */ }
    const box = h('details', { class: 'ai-help', open: closed ? null : true },
      h('summary', null, icon('info', 14, 'currentColor', 2.2), h('b', null, title)),
      h('ul', null, ...items.map((t) => h('li', null, t))));
    box.addEventListener('toggle', () => { try { localStorage.setItem('nf.help.' + key, box.open ? '1' : '0'); } catch (e) { /* */ } });
    return box;
  }
  async function storyEditor(sid) {
    let D;
    try { D = await get('/api/ai/story?id=' + encodeURIComponent(sid)); } catch (e) { toast(e.message, true); return nav('studio'); }
    await load();
    let st = D.story, est = D.estimate;
    const page = D.page || { characters: [], name: '' };
    setTitle(st.title || 'Storia AI');
    let step = st.status === 'montata' ? 4 : ({ script: 0, scene: 1, produzione: 2 }[st.status] ?? 0);
    let busy = null;   // {kind, msg, prog}
    let saveT = 0;
    const STEPS = [['Script', 'Le frasi, scena per scena'], ['Immagini', 'Una per scena'], ['Voce', 'AI o la tua registrazione'], ['Animazioni', 'Video AI o immagini in movimento'], ['Video', 'Montaggio automatico']];
    const head = h('nav', { class: 'ais-steps' });
    const body = h('div', { class: 'ais-body' });
    const cost = h('div', { class: 'ai-cost' });
    const foot = h('div', { class: 'ais-foot' });
    const speakers = [['', 'Narratore'], ...(page.characters || []).map((c) => [c.name, c.name])];
    const persist = (now) => {
      clearTimeout(saveT);
      const doit = async () => { try { const r = await post('/api/ai/story/save', { id: st.id, title: st.title, scenes: st.scenes }); st = r.story; est = r.estimate; paintCost(); } catch (e) { toast(e.message, true); } };
      if (now) return doit();
      saveT = setTimeout(doit, 600);
      return Promise.resolve();
    };
    const refresh = async () => { const r = await get('/api/ai/story?id=' + encodeURIComponent(st.id)); st = r.story; est = r.estimate; };
    const setFrom = (r) => { st = r.story; est = r.estimate; };
    function paintCost() {
      rc(cost, h('button', { class: 'btn ghost sm', onclick: () => guide() }, icon('info', 14), 'Come funziona'),
        h('span', { 'data-tip': 'Quanto hai speso finora con i tuoi servizi (stima)' }, 'Speso ', h('b', null, usd(est.spent))),
        est.todo > 0 ? h('span', { 'data-tip': 'Stima di quello che manca: immagini ' + usd(est.imageUsd) + ' · voce ' + usd(est.voiceUsd) + ' · video ' + usd(est.videoUsd || 0) }, 'Da fare ~', h('b', null, usd(est.todo))) : null);
    }
    async function runJob(kind, url, payload, msg, after) {
      if (busy) return;
      busy = { kind, msg, prog: 0 }; draw();
      let tick = null;
      try {
        const job = await post(url, { story: st.id, ...payload });
        tick = setInterval(async () => { try { await refresh(); if (!busy) return; paintBody(); paintCost(); } catch (e) { /* */ } }, 2500);
        const r = await pollJob(job.id, (j) => { if (busy) { busy.prog = j.progress; busy.msg = j.message || msg; paintBusy(); } });
        if (r.status === 'error') throw new Error(r.error || 'Non riuscito');
        if (r.result && r.result.errors) toast(r.result.errors + ' non riuscite: ' + (r.result.first || ''), true);
        await refresh();
        busy = null; draw();
        after && after(r.result);
      } catch (e) { busy = null; await refresh().catch(() => {}); draw(); toast(e.message, true); }
      finally { clearInterval(tick); }
    }
    setCleanup(() => { clearTimeout(saveT); });
    const busyEl = h('div', { class: 'ai-jobbar', hidden: true });
    function paintBusy() {
      busyEl.hidden = !busy;
      if (!busy) return;
      rc(busyEl, h('div', { class: 'spinner' }), h('span', null, busy.msg || 'Lavoro…'), h('div', { class: 'progress' }, h('div', { style: { width: Math.round((busy.prog || 0) * 100) + '%' } })));
    }
    function drawHead() {
      rc(head, ...STEPS.map(([t, sub], k) => h('button', { class: 'ais-st' + (k === step ? ' on' : k < step ? ' done' : ''), disabled: busy ? true : null, onclick: () => { step = k; draw(); } },
        h('span', { class: 'n' }, k < step ? icon('check', 12, '#fff', 3.2) : String(k + 1)), h('span', { class: 't' }, h('b', null, t), h('small', null, sub)))));
    }
    const durOf = (i) => (est.durations && est.durations[i]) || secsOf(st.scenes[i].text);
    // pausa dopo la battuta: automatica (respiro dopo domande, esclamazioni, cambio di chi parla) o scelta a mano
    const PAUSES = [null, 0, 0.3, 0.6, 1];
    function pauseChip(sc, i) {
      const man = typeof sc.pause === 'number', val = man ? sc.pause : ((est.pauses || [])[i] ?? 0.12);
      return h('button', { class: 'ai-pause' + (man ? ' man' : ''), disabled: busy || sc.locked ? true : null,
        'data-tip': 'Pausa dopo questa frase (clic per cambiare): automatica, nessuna, breve, media, lunga. Evita i tagli netti dove serve respiro.',
        onclick: async () => {
          const k = PAUSES.indexOf(man ? sc.pause : null), nx = PAUSES[(k + 1) % PAUSES.length];
          try { setFrom(await post('/api/ai/story/kinds', { story: st.id, i, pause: nx })); paintBody(); paintCost(); } catch (e) { toast(e.message, true); }
        } }, icon('pause', 10), (man ? '' : 'auto · ') + (val < 0.05 ? 'nessuna' : val.toFixed(1).replace('.', ',') + ' s'));
    }
    // --- 1. script
    function stepScript() {
      const total = st.scenes.reduce((s, x, i) => s + durOf(i), 0);
      const rows = st.scenes.map((sc, i) => {
        const txt = h('textarea', { class: 'ai-line', rows: 1, disabled: sc.locked ? true : null }); txt.value = sc.text;
        const fit = () => { txt.style.height = 'auto'; txt.style.height = txt.scrollHeight + 'px'; };
        txt.addEventListener('input', () => { sc.text = txt.value; fit(); persist(); });
        setTimeout(fit, 0);
        const sp = h('select', { class: 'ai-spk', disabled: sc.locked ? true : null }, ...speakers.map(([v, l]) => h('option', { value: v, selected: v === (sc.speaker || '') ? true : null }, l)));
        sp.addEventListener('change', () => { sc.speaker = sp.value; persist(); });
        return h('div', { class: 'ai-row' + (sc.locked ? ' locked' : '') },
          h('span', { class: 'ai-n' }, String(i + 1)),
          h('div', { class: 'ai-rmain' }, sp, txt, sc.error ? h('p', { class: 'ai-err' }, sc.error) : null),
          h('div', { class: 'ai-secw' }, h('span', { class: 'ai-sec' }, durOf(i).toFixed(1) + ' s'), i < st.scenes.length - 1 ? pauseChip(sc, i) : null),
          h('div', { class: 'ai-ract' },
            h('button', { class: 'iconbtn', 'data-tip': 'Riscrivi questa scena con l\'AI', disabled: sc.locked || busy ? true : null, onclick: () => rewrite(i) }, icon('wand', 14)),
            h('button', { class: 'iconbtn', 'data-tip': sc.locked ? 'Sblocca' : 'Blocca: non verrà più cambiata', onclick: () => { sc.locked = !sc.locked; persist(true); paintBody(); } }, icon(sc.locked ? 'lock' : 'unlock', 14)),
            h('button', { class: 'iconbtn', 'data-tip': 'Aggiungi una scena sotto', onclick: () => { st.scenes.splice(i + 1, 0, { id: '', speaker: '', text: '…', visual: '', motion: 'zoomIn', kind: 'image' }); persist(true).then(paintBody); } }, icon('plus', 14)),
            h('button', { class: 'iconbtn', 'data-tip': 'Togli la scena', disabled: sc.locked || st.scenes.length < 2 ? true : null, onclick: () => { st.scenes.splice(i, 1); persist(true).then(paintBody); } }, icon('trash', 14))));
      });
      return [h('div', { class: 'ai-shead' }, h('h2', null, 'Script'), h('span', { class: 'wz-count' }, st.scenes.length + ' scene · ~' + fmt(total))),
        helpBox('script', 'Come funziona lo script', [
          'Ogni riga è una scena: avrà la sua immagine (o il suo video) e dura quanto la frase detta a voce, di solito 3–5 secondi.',
          'Il numero di scene lo decido io dalla lunghezza del testo: più frasi = più immagini. Puoi aggiungere, togliere o unire le scene a mano.',
          'Scegli chi parla (narratore o personaggio): ogni personaggio avrà la sua voce e il suo colore nei sottotitoli.',
          'La bacchetta riscrive una sola scena con l\'AI, il lucchetto la blocca per non cambiarla più.']),
        h('div', { class: 'ai-rows' }, ...rows)];
    }
    function rewrite(i) {
      const bg = h('div', { class: 'modal-bg' });
      const inp = h('input', { class: 'input', placeholder: 'Es. più misteriosa, più corta, aggiungi un dettaglio sul rumore' });
      const go = () => { bg.remove(); runJob('scene', '/api/ai/story/scene', { i, instruction: inp.value }, 'Riscrivo la scena ' + (i + 1)); };
      inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
      bg.append(h('div', { class: 'modal' }, h('h2', null, 'Riscrivi la scena ' + (i + 1)), h('p', { class: 'wz-p', 'data-notr': '' }, st.scenes[i].text),
        h('div', { class: 'field' }, h('label', null, 'Come la vuoi? (facoltativo)'), inp),
        h('div', { class: 'crop-btns' }, h('button', { class: 'btn ghost', onclick: () => bg.remove() }, 'Annulla'), h('button', { class: 'btn primary', onclick: go }, icon('wand', 14, '#fff'), 'Riscrivi'))));
      bg.addEventListener('click', (e) => { if (e.target === bg) bg.remove(); });
      document.body.append(bg); setTimeout(() => inp.focus(), 30);
    }
    // --- 2. immagini
    function stepImages() {
      const missingN = st.scenes.filter((x) => !(x.image && x.image.file)).length;
      const refs = (page.characters || []).filter((c) => (c.refs || []).length).map((c) => c.name);
      const cards = st.scenes.map((sc, i) => {
        const f = sc.image && sc.image.file;
        const vis = h('textarea', { class: 'ai-vis', rows: 3, disabled: sc.locked ? true : null, placeholder: 'Cosa si vede (in inglese)' }); vis.value = sc.visual || '';
        vis.addEventListener('input', () => { sc.visual = vis.value; persist(); });
        return h('div', { class: 'ai-card' + (sc.locked ? ' locked' : '') + (sc.error ? ' err' : '') },
          h('div', { class: 'ai-pic' }, f ? h('img', { src: mediaUrl(f), alt: '', loading: 'lazy' }) : h('span', { class: 'ai-ph' }, busy && busy.kind === 'images' && !sc.locked ? h('div', { class: 'spinner' }) : icon('image', 22)),
            h('span', { class: 'st-num' }, String(i + 1)),
            sc.locked ? h('span', { class: 'ai-lk' }, icon('lock', 11, '#fff', 2.4)) : null),
          h('div', { class: 'ai-ctx', 'data-notr': '' }, sc.speaker ? h('b', null, sc.speaker + ': ') : null, sc.text),
          sc.error ? h('p', { class: 'ai-err' }, sc.error) : null,
          vis,
          h('div', { class: 'ai-cact' },
            h('div', { class: 'grow' }),
            h('button', { class: 'iconbtn', 'data-tip': sc.locked ? 'Sblocca' : 'Blocca questa immagine', onclick: () => { sc.locked = !sc.locked; persist(true); paintBody(); } }, icon(sc.locked ? 'lock' : 'unlock', 14)),
            h('button', { class: 'btn sm', disabled: sc.locked || busy ? true : null, onclick: async () => { await persist(true); runJob('images', '/api/ai/story/images', { only: [i] }, 'Creo l\'immagine ' + (i + 1)); } },
              icon(f ? 'undo' : 'sparkle', 13), f ? 'Rifai' : 'Crea')));
      });
      return [h('div', { class: 'ai-shead' }, h('h2', null, 'Immagini'), h('div', { class: 'grow' }),
        h('button', { class: 'btn sm', disabled: busy ? true : null, 'data-tip': 'Rifà le descrizioni dalle frasi attuali (dopo averle cambiate)', onclick: async () => { await persist(true); runJob('visuals', '/api/ai/story/visuals', {}, 'Aggiorno le descrizioni'); } }, icon('wand', 13), 'Aggiorna descrizioni'),
        h('button', { class: 'btn primary sm', disabled: busy || !missingN ? true : null, onclick: async () => { await persist(true); runJob('images', '/api/ai/story/images', {}, 'Creo le immagini'); } },
          icon('sparkle', 13, '#fff'), missingN ? `Crea ${missingN} immagini · ~${usd(est.imageUsd)}` : 'Tutte pronte')),
        helpBox('images', 'Come funzionano le immagini', [
          'Ogni immagine unisce lo stile della pagina, la descrizione della scena (qui sotto, puoi cambiarla) e l\'aspetto dei personaggi.',
          refs.length ? 'Foto di riferimento attive per: ' + refs.join(', ') + '. Le uso per tenere uguali faccia e vestiti in tutte le scene.'
            : 'Nessun personaggio ha foto di riferimento: aggiungile nella pagina (Personaggi) per avere sempre la stessa faccia.',
          'Se un\'immagine non ti piace, cambia la descrizione e premi Rifai: pagherai solo quella. Il lucchetto la blocca.',
          'Servizio: ' + (S.keys[est.imageProvider] ? S.keys[est.imageProvider].name : est.imageProvider) + ' · circa ' + usd((est.imageUsd || 0) / Math.max(1, est.images || 1)) + ' a immagine (stima).']),
        h('div', { class: 'ai-cards' }, ...cards)];
    }
    // --- 3. voce (AI o la tua registrazione)
    let playing = null;
    const playBtn = (file, key) => h('button', { class: 'ai-play', disabled: !file ? true : null, 'aria-label': 'Ascolta', onclick: () => {
      if (playing) { playing.pause(); if (playing._k === key) { playing = null; paintBody(); return; } }
      playing = new Audio(mediaUrl(file)); playing._k = key; playing.play().catch(() => {}); playing.onended = () => { playing = null; paintBody(); }; paintBody();
    } }, icon(playing && playing._k === key ? 'pause' : 'play', 14, 'currentColor'));
    let voiceMode = st.ownVoice ? 1 : 0;
    function stepVoice() {
      const modeSeg = seg(['Voce AI', 'La mia registrazione'], voiceMode, (k) => { voiceMode = k; paintBody(); });
      if (voiceMode === 1) return ownVoiceStep(modeSeg);
      const stale = (x) => !(x.audio && x.audio.file) || x.audio.text !== x.text || x.audio.stale;
      const todo = st.scenes.filter(stale).length;
      const rows = st.scenes.map((sc, i) => {
        const a = sc.audio;
        const ok = a && a.file && a.text === sc.text && !a.stale;
        return h('div', { class: 'ai-row ai-vrow' + (sc.locked ? ' locked' : '') },
          h('span', { class: 'ai-n' }, String(i + 1)), playBtn(a && a.file, 'v' + i),
          h('div', { class: 'ai-rmain' }, h('div', { class: 'ai-ctx', 'data-notr': '' }, h('b', null, (sc.speaker || 'Narratore') + ' '), sc.text),
            sc.error ? h('p', { class: 'ai-err' }, sc.error) : !ok ? h('small', { class: 'ai-warn' }, a && a.file ? (a.stale ? 'Voce cambiata: la battuta va rifatta' : 'La frase è cambiata: la voce va rifatta') : 'Voce da creare') : null),
          h('span', { class: 'ai-sec' }, ok ? (a.dur || 0).toFixed(1) + ' s' : '—'),
          h('button', { class: 'btn sm', disabled: sc.locked || busy ? true : null, onclick: () => runJob('voices', '/api/ai/story/voices', { only: [i] }, 'Creo la voce ' + (i + 1)) }, icon(a && a.file ? 'undo' : 'sparkle', 13), a && a.file ? 'Rifai' : 'Crea'));
      });
      return [h('div', { class: 'ai-shead' }, h('h2', null, 'Voce'), modeSeg, h('div', { class: 'grow' }),
        h('button', { class: 'btn primary sm', disabled: busy || !todo ? true : null, onclick: () => runJob('voices', '/api/ai/story/voices', {}, 'Creo le voci') },
          icon('sparkle', 13, '#fff'), todo ? `Crea ${todo} voci · ~${usd(est.voiceUsd)}` : 'Tutte pronte')),
        castBox(),
        helpBox('voice', 'Come funziona la voce', [
          'Voce AI: creo una battuta per scena con la voce del narratore della pagina, o quella del personaggio che parla. Le voci si scelgono nella pagina (Voci e Personaggi).',
          'La registrazione tua: se preferisci leggere tu lo script, scegli "La mia registrazione" e carica il file. Trovo da solo dove inizia ogni scena.',
          'Da qui in poi le durate sono quelle vere: ogni immagine o video resterà a schermo esattamente quanto la sua frase.',
          'Servizio: ' + (S.keys[est.voiceProvider] ? S.keys[est.voiceProvider].name : est.voiceProvider) + '. Con ElevenLabs i sottotitoli vanno parola per parola a tempo perfetto.']),
        h('div', { class: 'ai-rows' }, ...rows)];
    }
    // chi parla: ogni nome che compare nello script -> narratore, un personaggio o una voce qualsiasi
    let allVoices = null;
    const NARR = ['', 'narratore', 'narrator', 'voce narrante', 'voce fuori campo'];
    const autoCast = (k) => { if (NARR.includes(k)) return { narrator: true }; const c = (page.characters || []).find((x) => (x.name || '').trim().toLowerCase() === k); return c ? { char: c.id } : null; };
    function castBox() {
      const names = [...new Set(st.scenes.map((x) => (x.speaker || 'Narratore').trim()))];
      const cast = st.cast || {};
      if (allVoices === null) {
        allVoices = [];
        post('/api/ai/voices', { provider: (page.voiceCfg || {}).provider || (S.keys.elevenlabs.set ? 'elevenlabs' : 'openai') }).then((r) => { allVoices = r.voices || []; paintBody(); }).catch(() => {});
      }
      const nv = page.narrator && page.narrator.id ? page.narrator.name : 'da scegliere';
      const rows = names.map((name) => {
        const k = name.toLowerCase();
        const cur = cast[k] || autoCast(k) || {};
        const val = cur.narrator ? 'n:' : cur.char ? 'c:' + cur.char : cur.voice ? 'v:' + cur.voice.id : '';
        const opts = [['', '— Scegli chi è —'], ['n:', 'Narratore (voce: ' + nv + ')'],
          ...(page.characters || []).map((c) => ['c:' + c.id, c.name + ' (voce: ' + ((c.voice || {}).name || 'da scegliere nella pagina') + ')']),
          ...allVoices.map((v) => ['v:' + v.id, 'Voce: ' + v.name])];
        const sel = h('select', { class: 'input' }, ...opts.map(([v, l]) => h('option', { value: v, selected: v === val ? true : null }, l)));
        sel.addEventListener('change', async () => {
          const x = sel.value; const m = { ...cast };
          if (!x) delete m[k]; else if (x === 'n:') m[k] = { narrator: true }; else if (x.startsWith('c:')) m[k] = { char: x.slice(2) };
          else { const v = allVoices.find((y) => y.id === x.slice(2)); m[k] = { voice: { id: v.id, name: v.name } }; }
          try { const r = await post('/api/ai/story/cast', { id: st.id, cast: m }); st.cast = r.cast || m; toast('Voce di ' + name + ' aggiornata'); paintBody(); } catch (e) { toast(e.message, true); }
        });
        const missing = !val;
        return h('div', { class: 'ai-castrow' + (missing ? ' miss' : '') }, h('b', { 'data-notr': '' }, name), h('span', null, '→'), sel);
      });
      return h('div', { class: 'ai-cast' }, h('div', { class: 'ai-casth' }, h('b', null, 'Chi parla'), h('small', null, 'Per ogni nome dello script scegli chi è o che voce usa. Vale solo per questa storia.')), ...rows);
    }
    function ownVoiceStep(modeSeg) {
      const ov = st.ownVoice;
      const changed = ov && JSON.stringify(ov.texts || []) !== JSON.stringify(st.scenes.map((x) => x.text));
      const pick = async () => {
        try {
          const r = await post('/api/pick', { kind: 'audio' }); const f = (r.files || [])[0]; if (!f) return;
          runJob('ownvoice', '/api/ai/story/ownvoice', { path: f.path }, 'Ascolto la registrazione');
        } catch (e) { toast(e.message, true); }
      };
      const out = [h('div', { class: 'ai-shead' }, h('h2', null, 'Voce'), modeSeg),
        helpBox('ownvoice', 'Usare la tua registrazione', [
          'Registra lo script leggendo le frasi nell\'ordine (va bene anche con il telefono), poi carica il file: MP3, WAV o M4A.',
          'Ascolto la registrazione e la confronto con lo script: trovo dove inizia ogni scena e ti segnalo le frasi dette in modo diverso.',
          'Se cambi lo script dopo, ricarica la registrazione. Con la tua voce non spendi niente per il parlato.'])];
      if (!ov) {
        out.push(h('button', { class: 'wz-drop', onclick: pick, disabled: busy ? true : null }, icon('music', 26, 'currentColor', 1.6), h('b', null, 'Carica la registrazione'), h('span', null, 'MP3, WAV, M4A… Clic per scegliere il file')));
        return out;
      }
      const bad = (ov.report || []).map((r, i) => ({ r, i })).filter(({ r }) => r.missing.length || r.extra.length);
      out.push(h('div', { class: 'st-vf' }, playBtn(ov.file, 'own'), h('span', { 'data-notr': '' }, ov.name || 'Registrazione'), h('span', { class: 'xs' }, fmt(ov.dur || 0)),
        h('div', { class: 'grow' }), h('button', { class: 'btn sm', onclick: pick }, 'Cambia'),
        h('button', { class: 'iconbtn', 'aria-label': 'Togli', onclick: async () => { setFrom(await post('/api/ai/story/ownvoice/remove', { story: st.id })); voiceMode = 0; draw(); } }, icon('x', 14))));
      if (changed) out.push(h('div', { class: 'wz-sum warn' }, icon('info', 16, 'currentColor', 2), h('span', null, h('b', null, 'Hai cambiato lo script dopo la registrazione.'), ' Ricaricala per rifare i tempi delle scene.')));
      else if (!ov.report) { /* senza trascrizione: resta solo la nota qui sotto */ }
      else out.push(bad.length ? h('div', { class: 'wz-sum warn' }, icon('info', 16, 'currentColor', 2), h('span', null, h('b', null, bad.length + ' frasi un po\' diverse'), ' dallo script: le immagini seguono comunque la tua voce.'))
        : h('div', { class: 'wz-sum ok' }, icon('check', 16, 'currentColor', 2.6), h('span', null, h('b', null, 'La registrazione corrisponde allo script.'), ' Ogni scena dura quanto la sua frase.')));
      if (ov.note) out.push(h('div', { class: 'wz-sum warn' }, icon('info', 16, 'currentColor', 2), h('span', null, ov.note)));
      out.push(h('div', { class: 'ai-rows' }, ...st.scenes.map((sc, i) => { const t = (ov.times || [])[i]; return h('div', { class: 'ai-row ai-vrow' }, h('span', { class: 'ai-n' }, String(i + 1)),
        h('div', { class: 'ai-rmain' }, h('div', { class: 'ai-ctx', 'data-notr': '' }, sc.text)), h('span', { class: 'ai-sec' }, t ? (t[1] - t[0]).toFixed(1) + ' s' : '—')); })));
      return out;
    }
    // --- 4. animazioni: video AI o immagine in movimento
    function stepMotion() {
      const falOn = S.keys.fal && S.keys.fal.set;
      const share = st.videoShare || (st.scenes.some((x) => x.kind === 'video') ? 'few' : 'none');
      const shareSeg = h('div', { class: 'ai-durs' }, ...[['none', 'Nessuna'], ['few', 'Poche (consigliato)'], ['half', 'Metà'], ['all', 'Tutte']].map(([k, l]) =>
        h('button', { class: 'ai-chip' + (share === k ? ' on' : ''), disabled: !falOn && k !== 'none' ? true : null, onclick: async () => { setFrom(await post('/api/ai/story/kinds', { story: st.id, share: k })); paintBody(); paintCost(); } }, l)));
      const VI = S.videoInfo || {};
      const vmodel = VI[(page.videoCfg || {}).model] ? page.videoCfg.model : (S.models.video.fal || [])[0];
      const vinfo = VI[vmodel];
      const modelOf = (sc) => (sc.videoModel && VI[sc.videoModel] ? sc.videoModel : vmodel);
      const vidIdx = st.scenes.map((x, i) => i).filter((i) => st.scenes[i].kind === 'video');
      const pickPage = () => videoModelPicker({ info: VI, current: vmodel, durs: vidIdx.filter((i) => !st.scenes[i].videoModel).map(durOf),
        title: 'Modello video per la storia', onPick: async (m) => {
          try { const pg = await post('/api/ai/page', { id: page.id, videoCfg: { ...(page.videoCfg || {}), provider: 'fal', model: m } }); page.videoCfg = pg.videoCfg; await refresh(); paintBody(); paintCost(); toast('Modello video: ' + VI[m].name); }
          catch (e) { toast(e.message, true); } } });
      const pickScene = (i) => videoModelPicker({ info: VI, current: st.scenes[i].videoModel && VI[st.scenes[i].videoModel] ? st.scenes[i].videoModel : '', pageModel: vmodel, durs: [durOf(i)],
        title: 'Modello per la scena ' + (i + 1), sub: 'Vale solo per questa scena: puoi provare un modello diverso senza cambiare le altre. Il costo è per la clip di questa frase.',
        onPick: async (m) => { try { setFrom(await post('/api/ai/story/kinds', { story: st.id, i, model: m })); paintBody(); paintCost(); } catch (e) { toast(e.message, true); } } });
      const mixed = vidIdx.some((i) => st.scenes[i].videoModel && VI[st.scenes[i].videoModel]);
      const totV = vidIdx.reduce((a, i) => a + clipFor(VI[modelOf(st.scenes[i])], durOf(i)).usd, 0);
      const qual = vinfo ? h('div', { class: 'ai-vq' },
        h('div', { class: 'ai-vqhead' },
          h('div', { class: 'ai-vqcur' }, h('small', null, 'Modello video della storia'), h('b', { 'data-notr': '' }, vinfo.name),
            h('small', null, priceLbl(vinfo) + ' · ' + durLbl(vinfo) + (vinfo.res_lbl ? ' · ' + vinfo.res_lbl : ''))),
          h('div', { class: 'grow' }),
          vidIdx.length ? h('div', { class: 'ai-vqtot' }, h('small', null, vidIdx.length + ' video AI'), h('b', null, usd(totV))) : null,
          h('button', { class: 'btn sm', disabled: busy ? true : null, onclick: pickPage }, icon('film', 13), 'Cambia modello')),
        h('small', { class: 'field-note' }, (mixed ? 'Alcune scene usano un modello diverso (lo vedi sulla scena). ' : '') + 'Puoi anche cambiare modello a una sola scena: "Modello" sotto la scena.')) : null;
      const nVid = st.scenes.filter((x) => x.kind === 'video').length;
      const missV = st.scenes.filter((x) => x.kind === 'video' && !(x.video && x.video.file && x.video.image === (x.image || {}).file)).length;
      const cards = st.scenes.map((sc, i) => {
        const f = sc.image && sc.image.file, v = sc.video && sc.video.file && sc.video.image === f ? sc.video : null;
        const need = durOf(i), sm = modelOf(sc), cc = clipFor(VI[sm], need), clip = cc.sec, own = sm !== vmodel;
        const isV = sc.kind === 'video';
        const mot = (MOTIONS.find(([k]) => k === sc.motion) || MOTIONS[0])[1];
        return h('div', { class: 'ai-card' + (isV ? ' vid' : '') + (sc.error && isV ? ' err' : '') },
          h('div', { class: 'ai-pic' }, isV && v ? h('video', { src: mediaUrl(v.file), muted: true, loop: true, playsinline: true, autoplay: true, preload: 'metadata' })
            : f ? h('img', { src: mediaUrl(f), alt: '', loading: 'lazy', class: isV ? '' : 'kb-' + (sc.motion || 'zoomIn') }) : h('span', { class: 'ai-ph' }, icon('image', 22)),
            h('span', { class: 'st-num' }, String(i + 1)),
            h('span', { class: 'ai-kind' + (isV ? ' v' : '') }, isV ? 'Video AI' : 'Immagine animata')),
          h('div', { class: 'ai-ctx', 'data-notr': '' }, sc.text),
          sc.error && isV ? h('p', { class: 'ai-err' }, sc.error) : null,
          h('div', { class: 'ai-kindseg' }, seg(['Immagine', 'Video AI'], isV ? 1 : 0, async (k) => {
            if (k === 1 && !falOn) { toast('Per i video AI collega fal.ai in Chiavi AI', true); return; }
            setFrom(await post('/api/ai/story/kinds', { story: st.id, i, kind: k ? 'video' : 'image' })); paintBody(); paintCost();
          })),
          isV ? h('button', { class: 'ai-smodel' + (own ? ' own' : ''), disabled: busy ? true : null, 'data-tip': 'Cambia il modello solo per questa scena', onclick: () => pickScene(i) },
            icon('film', 11), h('span', { 'data-notr': '' }, (VI[sm] || {}).name || ''), h('small', null, usd(cc.usd))) : null,
          isV ? h('small', { class: 'ai-need' }, 'La frase dura ' + need.toFixed(1) + ' s → clip da ' + clip + ' s · ' + usd(cc.usd))
            : h('button', { class: 'st-mot', 'data-tip': 'Clic: cambia movimento', onclick: () => { const ids = MOTIONS.map(([k]) => k); sc.motion = ids[(ids.indexOf(sc.motion) + 1) % ids.length]; persist(); paintBody(); } }, icon('sparkle', 11), mot),
          isV ? h('button', { class: 'btn sm', disabled: busy || !f ? true : null, onclick: () => runJob('videos', '/api/ai/story/videos', { only: [i] }, 'Creo il video ' + (i + 1)) }, icon(v ? 'undo' : 'sparkle', 13), v ? 'Rifai il video' : 'Crea il video') : null);
      });
      return [h('div', { class: 'ai-shead' }, h('h2', null, 'Animazioni'), h('div', { class: 'grow' }),
        h('button', { class: 'btn primary sm', disabled: busy || !missV || !falOn ? true : null, onclick: () => runJob('videos', '/api/ai/story/videos', {}, 'Creo i video') },
          icon('sparkle', 13, '#fff'), missV ? `Crea ${missV} video · ~${usd(est.videoUsd || 0)}` : nVid ? 'Video pronti' : 'Nessun video AI')),
        falOn ? qual : null,
        helpBox('motion', 'Video AI o immagine animata?', [
          'Immagine animata: gratis. L\'immagine si muove con uno zoom o uno spostamento di camera, come nei video "faceless". Va benissimo per la maggior parte delle scene.',
          'Video AI: l\'immagine della scena diventa una clip vera (persone che si muovono, luci, fumo…) con fal.ai. Costa di più: da pochi centesimi a qualche dollaro a clip, secondo il modello che scegli. Il prezzo è quello di fal.ai, calcolato sulle tue frasi.',
          'Io scelgo le scene più importanti (l\'apertura, le azioni, il colpo di scena). Tu scegli quante: poche, metà o tutte, oppure cambi scena per scena.',
          'Si paga la durata della clip, non della frase: chiedo sempre la clip più corta che il modello accetta (per esempio 3 secondi con Kling 3, 1 secondo con PixVerse V6) e poi la taglio alla lunghezza esatta della frase. Per questo conviene fare prima la voce.']),
        !falOn ? h('div', { class: 'wz-sum warn' }, icon('lock', 16, 'currentColor', 2), h('span', null, h('b', null, 'Per i video AI serve fal.ai.'), ' Senza, tutte le scene sono immagini animate (gratis).'),
          h('button', { class: 'btn sm', onclick: () => keysDialog(() => load().then(draw)) }, 'Collega fal.ai')) : null,
        h('div', { class: 'field' }, h('label', null, 'Quante scene diventano video AI?'), shareSeg),
        h('div', { class: 'ai-cards' }, ...cards)];
    }
    // --- 5. video
    function stepVideo() {
      const imgs = st.scenes.filter((x) => x.image && x.image.file).length;
      const own = !!st.ownVoice;
      const vcs = own ? st.scenes.length : st.scenes.filter((x) => x.audio && x.audio.file && x.audio.text === x.text).length;
      const nV = st.scenes.filter((x) => x.kind === 'video').length;
      const okV = st.scenes.filter((x) => x.kind === 'video' && x.video && x.video.file && x.video.image === (x.image || {}).file).length;
      const dur = st.scenes.reduce((s, x, i) => s + durOf(i), 0);
      const ed = (page.edit || {});
      const chk = (ok, t, sub) => h('div', { class: 'ai-chk' + (ok ? ' ok' : '') }, icon(ok ? 'check' : 'info', 15, 'currentColor', 2.4), h('span', null, h('b', null, t), h('small', null, sub)));
      return [h('h2', null, 'Monta il video'),
        helpBox('build', 'Cosa succede quando premi "Crea il video"', [
          'Creo quello che manca (immagini, voci, video AI), poi metto tutto sulla timeline: una scena dopo l\'altra, ognuna lunga quanto la sua frase.',
          'Aggiungo i sottotitoli, la musica della pagina (che si abbassa quando si parla) e un movimento diverso su ogni immagine.',
          'Si apre l\'editor: puoi cambiare tutto (tagli, testi, musica) ed esportare in 1080×1920. La storia resta qui: se cambi una scena, rifai il video in un clic.']),
        h('div', { class: 'ai-sum' },
          chk(imgs === st.scenes.length, imgs + ' / ' + st.scenes.length + ' immagini', imgs === st.scenes.length ? 'Pronte' : 'Le mancanti le creo io'),
          chk(vcs === st.scenes.length, own ? 'La tua registrazione' : vcs + ' / ' + st.scenes.length + ' voci', vcs === st.scenes.length ? 'Pronte' : 'Le mancanti le creo io'),
          chk(okV === nV, nV ? okV + ' / ' + nV + ' video AI' : 'Solo immagini animate', nV ? (okV === nV ? 'Pronti' : 'I mancanti li creo io') : 'Nessun costo per i video'),
          chk(true, 'Durata ~' + fmt(dur), 'Formato 9:16, 1080×1920'),
          chk(true, ed.captions === 'line' ? 'Sottotitoli a frasi' : 'Sottotitoli parola per parola', ed.music ? 'Musica: ' + ed.music.name : 'Senza musica')),
        st.project ? h('div', { class: 'ai-done' }, icon('check', 16, 'currentColor', 2.6), h('span', null, 'Video già montato. Puoi aprirlo o rifarlo con le modifiche.'),
          h('div', { class: 'grow' }), h('button', { class: 'btn', onclick: () => nav('editor', st.project) }, icon('film', 14), 'Apri nell\'editor')) : null,
        h('button', { class: 'btn primary big ai-build', disabled: busy ? true : null, onclick: () => runJob('build', '/api/ai/story/build', {}, 'Monto il video', (r) => { if (r && r.project) nav('editor', r.project); }) },
          icon('sparkle', 16, '#fff'), st.project ? 'Rifai il video' : 'Crea il video' + (est.todo > 0 ? ' · ~' + usd(est.todo) : ''))];
    }
    function paintBody() { rc(body, ...[stepScript, stepImages, stepVoice, stepMotion, stepVideo][step]().filter(Boolean)); }
    function draw() {
      drawHead(); paintBusy(); paintCost(); paintBody();
      rc(foot, h('button', { class: 'btn ghost', onclick: () => (step ? (step--, draw()) : nav('studio', st.page)) }, icon('left', 15), step ? 'Indietro' : 'Storie'),
        h('div', { class: 'grow' }), busyEl,
        step < 4 ? h('button', { class: 'btn primary', disabled: busy ? true : null, onclick: async () => { await persist(true); step++; post('/api/ai/story/save', { id: st.id, status: ['script', 'scene', 'produzione', 'produzione', 'montata'][Math.min(step, 3)] }).catch(() => {}); draw(); } }, 'Avanti', icon('chev', 13, 'currentColor', 2.4)) : null);
    }
    const title = h('input', { class: 'ais-title', value: st.title || '', 'aria-label': 'Titolo della storia', maxlength: 120, spellcheck: 'false' });
    title.addEventListener('input', () => { st.title = title.value; persist(); });
    const hdr = h('header', { class: 'ais-head', style: { '--h': hueOf(page.name) } },
      h('button', { class: 'ais-back', 'aria-label': 'Storie', 'data-tip': 'Torna alle storie', onclick: () => nav('studio', st.page) }, icon('left', 16, 'currentColor', 2.2)),
      h('div', { class: 'ais-tt' }, h('span', { class: 'ais-page' }, pageAv(page, 18), h('span', { 'data-notr': '' }, page.name)), title),
      h('div', { class: 'grow' }), cost,
      h('button', { class: 'btn primary ais-all', 'data-tip': 'Crea in un colpo tutto quello che manca (immagini, voci, animazioni) e monta il video nell\'editor', onclick: () => { if (busy) return; step = 4; draw(); runJob('build', '/api/ai/story/build', {}, 'Creo tutto e monto il video', (r) => { if (r && r.project) nav('editor', r.project); }); } },
        icon('sparkle', 14, '#fff'), 'Crea tutto'));
    app.append(topbar(-1, null, false, { name: 'Storie AI', home: true }),
      h('main', { class: 'ais-main' }, h('div', { class: 'ais-glow', style: { '--h': hueOf(page.name) } }), hdr, head, h('section', { class: 'ais-card' }, body, foot)));
    draw();
  }

  // ------------------------------------------------------------- formati: imparare da video che funzionano
  const FSTATUS = { 'in coda': 'In coda', scarico: 'Scarico', inquadrature: 'Cerco le visual', trascrivo: 'Trascrivo', pronto: 'Pronto', errore: 'Errore' };
  async function formatsScreen(fid) {
    if (!fid) return formatsList();
    let D;
    try { D = await get('/api/ai/format?id=' + encodeURIComponent(fid)); } catch (e) { toast(e.message, true); return nav('aiformats'); }
    await load();
    if (D.format.builtin) return builtinFormat(D.format, D.kinds || {});
    let fm = D.format, running = D.running, poll = null, analyzing = false;
    let SOC = { sites: {}, login: {} };
    try { SOC = await get('/api/social'); } catch (e) { /* */ }
    let socPoll = null;
    async function tiktokConnect() {
      try { await post('/api/social/tiktok/connect', {}); } catch (e) { return toast(e.message, true); }
      toast('Accedi a TikTok nella finestra che si è aperta (anche con il QR dal telefono). La password la vede solo TikTok.');
      clearInterval(socPoll);
      socPoll = setInterval(async () => {
        try {
          SOC = await get('/api/social');
          if (SOC.login.state === 'open') return;
          clearInterval(socPoll); socPoll = null;
          if (SOC.sites.tiktok && SOC.sites.tiktok.connected) {
            toast('TikTok collegato');
            if ((fm.videos || []).some((v) => v.status === 'errore')) { await post('/api/ai/format/process', { id: fm.id }); running = true; startPoll(); }
          }
          paint();
        } catch (e) { /* */ }
      }, 1500);
    }
    async function tiktokDisconnect() {
      if (!await confirmBox('Scollegare TikTok?', 'Cancello la sessione di TikTok da questo computer. I video già scaricati restano.', 'Scollega')) return;
      try { SOC = { ...SOC, ...(await post('/api/social/tiktok/disconnect', {})) }; paint(); } catch (e) { toast(e.message, true); }
    }
    setTitle(fm.name || 'Formato');
    const body = h('div', { class: 'ais-body' });
    const refresh = async () => { const r = await get('/api/ai/format?id=' + encodeURIComponent(fm.id)); fm = r.format; running = r.running; paint(); };
    const startPoll = () => { clearInterval(poll); poll = setInterval(async () => { try { await refresh(); if (!running) { clearInterval(poll); poll = null; } } catch (e) { /* */ } }, 2000); };
    setCleanup(() => { clearInterval(poll); clearInterval(socPoll); });
    let saveT = 0;
    const saveVideo = (v, patch) => { Object.assign(v, patch); clearTimeout(saveT); saveT = setTimeout(() => post('/api/ai/format/save', { id: fm.id, videos: [{ id: v.id, ...patch }] }).catch((e) => toast(e.message, true)), 400); };
    async function addPaths(paths, urls) {
      try { const r = await post('/api/ai/format/video/add', { id: fm.id, paths: paths || [], urls: urls || [] }); fm = r.format; running = true; paint(); startPoll(); }
      catch (e) { toast(e.message, true); }
    }
    async function uploadFiles(files) {
      const paths = [];
      for (const f of files) {
        try {
          const r = await fetch('/api/upload?kind=asset&token=' + window.VODCUT.token + '&name=' + encodeURIComponent(f.name), { method: 'PUT', body: f });
          const j = await r.json(); if (!r.ok) throw new Error(j.error || 'Upload non riuscito'); paths.push(j.path);
        } catch (e) { toast(f.name + ': ' + e.message, true); }
      }
      if (paths.length) addPaths(paths);
    }
    const pickVideos = async () => { try { const r = await post('/api/pick', { kind: 'media' }); const ps = (r.files || []).filter((x) => x.kind === 'video' || x.kind === 'audio').map((x) => x.path); if (ps.length) addPaths(ps); } catch (e) { toast(e.message, true); } };
    let srcFilter = 'all';
    const SRC = { tiktok: 'TikTok', instagram: 'Instagram', youtube: 'YouTube', file: 'Dal computer', web: 'Altri siti' };
    const srcOf = (v) => { const u = (v.url || '').toLowerCase(); if (!u) return 'file'; if (u.includes('tiktok.com')) return 'tiktok'; if (u.includes('instagram.com')) return 'instagram'; if (u.includes('youtube.com') || u.includes('youtu.be')) return 'youtube'; return 'web'; };
    async function recount(vid) {
      try { const r = await post('/api/ai/format/video/recount', { id: fm.id, video: vid || '' }); fm = r.format; running = true; paint(); startPoll(); }
      catch (e) { toast(e.message, true); }
    }
    // campi che restano gli stessi tra un aggiornamento e l'altro (non perdono testo e cursore)
    const link = h('input', { class: 'input', placeholder: 'Incolla un link (TikTok, Reels, YouTube Shorts) e premi Invio' });
    link.addEventListener('keydown', (e) => { if (e.key === 'Enter' && link.value.trim()) { addPaths([], link.value.split(/\s+/).filter((x) => /^https:\/\//.test(x))); link.value = ''; } });
    link.addEventListener('paste', () => setTimeout(() => { const us = link.value.split(/\s+/).filter((x) => /^https:\/\/\S+\.\S+/.test(x)); if (us.length) { addPaths([], us); link.value = ''; } }, 0));
    const promptTa = h('textarea', { class: 'input ai-ta fm-prompt', rows: 16 });
    promptTa.addEventListener('input', () => { fm.prompt = promptTa.value; clearTimeout(saveT); saveT = setTimeout(() => post('/api/ai/format/save', { id: fm.id, prompt: promptTa.value }).catch(() => {}), 600); });
    function paint() {
      const act = document.activeElement, keep = act === link || act === promptTa ? [act, act.selectionStart, act.selectionEnd] : null;
      paint2();
      if (keep && document.contains(keep[0])) { keep[0].focus(); try { keep[0].setSelectionRange(keep[1], keep[2]); } catch (e) { /* */ } }
    }
    function paint2() {
      const all = fm.videos || [];
      const counts = {}; all.forEach((v) => { const k = srcOf(v); counts[k] = (counts[k] || 0) + 1; });
      if (srcFilter !== 'all' && !counts[srcFilter]) srcFilter = 'all';
      const vids = srcFilter === 'all' ? all : all.filter((v) => srcOf(v) === srcFilter);
      const ready = vids.filter((v) => v.status === 'pronto');
      const chips = Object.keys(counts).length > 1 || (Object.keys(counts).length === 1 && all.length > 0)
        ? h('div', { class: 'fm-src' }, h('button', { class: 'ai-chip' + (srcFilter === 'all' ? ' on' : ''), onclick: () => { srcFilter = 'all'; paint(); } }, 'Tutti · ' + all.length),
          ...Object.keys(SRC).filter((k) => counts[k]).map((k) => h('button', { class: 'ai-chip' + (srcFilter === k ? ' on' : ''), onclick: () => { srcFilter = k; paint(); } }, SRC[k] + ' · ' + counts[k])))
        : null;
      const avg = (k) => ready.length ? ready.reduce((s, v) => s + (+v[k] || 0), 0) / ready.length : 0;
      const nshots = (v) => (v.shots || []).length;
      const drop = h('div', { class: 'fm-drop' }, h('span', { class: 'ic' }, icon('upload', 22, '#fff', 2)),
        h('div', null, h('b', null, 'Trascina qui i video di riferimento'), h('span', null, 'Anche tanti insieme. Li trascrivo e conto le visual sul tuo computer, gratis.')),
        h('button', { class: 'btn', onclick: pickVideos }, icon('folder', 14), 'Scegli i video'));
      drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
      drop.addEventListener('dragleave', () => drop.classList.remove('over'));
      drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); uploadFiles([...e.dataTransfer.files].filter((f) => /^(video|audio)\//.test(f.type) || /\.(mp4|mov|mkv|webm|m4v|mp3|wav|m4a)$/i.test(f.name))); });
      const stat = (v, l) => h('div', { class: 'fm-stat' }, h('b', null, v), h('span', null, l));
      const rows = vids.map((v) => {
        const st = v.status || 'in coda';
        const busyRow = v.recount && running;
        const S = v.stats || {};
        const ready1 = st === 'pronto';
        const big = (n) => n == null || n === '' ? '–' : (+n >= 1e6 ? (+n / 1e6).toFixed(1).replace('.0', '') + 'M' : +n >= 1e3 ? Math.round(+n / 1e3) + 'K' : String(n));
        const box = (label, val, tip) => h('div', { class: 'fm-val', 'data-tip': tip || null }, h('small', null, label), h('b', null, val));
        let viewsEl;
        if (v.url) viewsEl = box('Views', big(S.views != null ? S.views : v.views), S.likes != null ? '♥ ' + big(S.likes) + ' · 💬 ' + big(S.comments) + ' · ↗ ' + big(S.shares) + (S.saves != null ? ' · 🔖 ' + big(S.saves) : '') : null);
        else {
          const views = h('input', { class: 'input fm-views', value: v.views || '', placeholder: 'es. 1,2M' });
          views.addEventListener('change', async () => { try { fm = await post('/api/ai/format/save', { id: fm.id, videos: [{ id: v.id, views: views.value }] }); paint(); } catch (e) { toast(e.message, true); } });
          viewsEl = h('label', { 'data-tip': 'Video dal computer: le views non si possono leggere da sole, scrivile tu' }, h('small', null, 'Views'), views);
        }
        const RL = { top: 'Top', ok: 'Ok', flop: 'Flop', new: 'Troppo nuovo' };
        return h('div', { class: 'fm-row s-' + st.replace(' ', '') },
          h('div', { class: 'fm-strip' }, ...(v.thumbs || []).slice(0, 6).map((t) => h('img', { src: mediaUrl(t), alt: '', loading: 'lazy' })),
            !(v.thumbs || []).length ? h('span', { class: 'fm-nost' }, st === 'pronto' ? '' : h('div', { class: 'spinner' })) : null),
          h('div', { class: 'fm-info' },
            h('div', { class: 'fm-t' }, h('b', { 'data-notr': '' }, v.title || 'Video'), h('span', { class: 'fm-badge s-' + st.replace(' ', '') }, FSTATUS[st] || st),
              h('span', { class: 'fm-srcb s-' + srcOf(v) }, SRC[srcOf(v)])),
            busyRow ? h('small', null, 'Riconto le visual…') : st === 'pronto' ? h('small', null, fmt(v.dur || 0) + ' · ' + nshots(v) + ' visual · una ogni ' + ((v.dur || 0) / Math.max(1, nshots(v))).toFixed(1) + ' s · ' + (v.wps || 0) + ' parole/s')
              : v.error ? h('small', { class: 'ai-err' }, v.error) : h('small', null, 'Aspetta: lo sto analizzando'),
            st === 'pronto' && v.hook ? h('small', { class: 'fm-hook', 'data-notr': '' }, '“' + v.hook + '”') : null),
          h('div', { class: 'fm-ctl' },
            box('Visual', ready1 && !busyRow ? String((v.shots || []).length) : '–', 'Contate in automatico guardando tutti i fotogrammi'),
            viewsEl,
            h('div', { class: 'fm-val', 'data-tip': v.ratingWhy ? 'In automatico: ' + v.ratingWhy : 'Serve sapere le views' }, h('small', null, 'Risultato'),
              v.rating ? h('span', { class: 'fm-rt r-' + v.rating }, RL[v.rating]) : h('b', null, '–'))),
          h('div', { class: 'fm-act' },
            st === 'pronto' ? h('button', { class: 'iconbtn', disabled: busyRow, 'data-tip': 'Rianalizza visual e numeri', onclick: () => recount(v.id) }, busyRow ? h('div', { class: 'spinner sm' }) : icon('refresh', 15)) : null,
            v.transcript ? h('button', { class: 'iconbtn', 'data-tip': 'Leggi la trascrizione', onclick: () => showTranscript(v) }, icon('text', 15)) : null,
            h('button', { class: 'iconbtn', 'data-tip': 'Togli il video', onclick: async () => { fm = await post('/api/ai/format/video/remove', { id: fm.id, video: v.id }); paint(); } }, icon('trash', 15))));
      });
      const canAnalyze = ready.length >= 3 && !running && !analyzing;
      const errN = vids.filter((v) => v.status === 'errore').length;
      rc(body,
        helpBox('formats', 'Come funziona un formato', [
          'Carica video che funzionano (tuoi o di altri) dello stesso tipo: per esempio 20–50 video di vendita di app. Più sono diversi tra loro, meglio è.',
          'Sul tuo computer li trascrivo e conto le visual (i cambi di inquadratura). Views e interazioni le leggo dal link, e ogni video diventa Top / Ok / Flop da solo: i Top contano di più.',
          'Poi l\'AI (con la tua chiave, pochi centesimi) studia struttura, apertura, ritmo e chiusura, e scrive il formato. Lo scegli quando crei una storia.',
          'Si impara la struttura, non si copiano le frasi: gli script nuovi sono sempre originali.']),
        drop, h('div', { class: 'fm-link' }, icon('globe', 15), link,
          (SOC.sites.tiktok || {}).connected
            ? h('div', { class: 'fm-soc on', 'data-tip': 'I link TikTok si scaricano con il tuo account. La sessione resta solo su questo computer, cifrata.' },
              icon('check', 13, 'currentColor', 2.4), h('span', null, 'TikTok collegato'), h('button', { class: 'linkish', onclick: tiktokDisconnect }, 'Scollega'))
            : h('button', { class: 'btn fm-soc', onclick: tiktokConnect, 'data-tip': 'Serve se TikTok chiede l\'accesso per scaricare. Accedi nella pagina ufficiale di TikTok: la sessione resta solo su questo computer, cifrata, e non arriva a nessuno.' },
              icon('user', 14), SOC.login.state === 'open' ? 'Accesso in corso…' : 'Collega TikTok')),
        chips,
        ready.length ? h('div', { class: 'fm-stats' }, stat(ready.length + ' / ' + vids.length, srcFilter === 'all' ? 'video pronti' : SRC[srcFilter] + ' · pronti'), stat(fmt(avg('dur')), 'durata media'),
          stat((ready.reduce((a, v) => a + (+v.dur || 0) / Math.max(1, nshots(v)), 0) / ready.length).toFixed(1) + ' s', 'una visual ogni'), stat(avg('wps').toFixed(1), 'parole al secondo')) : null,
        running ? h('div', { class: 'ai-busy' }, h('div', { class: 'spinner' }), h('span', null, 'Sto analizzando i video: puoi continuare a lavorare, si aggiorna da solo.')) : null,
        errN && !running ? h('div', { class: 'wz-sum warn' }, icon('info', 16, 'currentColor', 2), h('span', null, errN + ' video non analizzati.'), h('button', { class: 'btn sm', onclick: async () => { await post('/api/ai/format/process', { id: fm.id }); running = true; paint(); startPoll(); } }, 'Riprova')) : null,
        vids.length ? h('div', { class: 'fm-rows' }, ...rows) : null,
        h('div', { class: 'fm-make' + (fm.prompt ? ' done' : '') },
          h('div', null, h('b', null, fm.prompt ? 'Formato pronto' : 'Crea il formato'), h('span', null, fm.prompt ? 'Puoi modificarlo qui sotto. Si usa scegliendolo in "Nuova storia".'
            : ready.length >= 3 ? 'L\'AI legge i ' + ready.length + ' video e scrive struttura, aperture, ritmo e regole.' : 'Servono almeno 3 video pronti (meglio 20 o più).')),
          h('button', { class: 'btn primary', disabled: canAnalyze ? null : true, onclick: analyze }, analyzing ? h('div', { class: 'spinner' }) : icon('sparkle', 14, '#fff'), fm.prompt ? 'Rifai il formato' : 'Crea il formato con l\'AI')),
        fm.prompt ? (() => { if (document.activeElement !== promptTa && promptTa.value !== fm.prompt) promptTa.value = fm.prompt; return promptTa; })() : null);
    }
    async function runAnalyze(choice) {
      analyzing = true; paint();
      try { const j = await post('/api/ai/format/analyze', { id: fm.id, ...choice }); const r = await pollJob(j.id); if (r.status !== 'done') throw new Error(r.error || 'Non riuscito'); toast('Formato pronto'); }
      catch (e) { toast(e.message, true); }
      analyzing = false; await refresh();
    }
    async function analyze() {
      let E;
      try { E = await post('/api/ai/format/estimate', { id: fm.id }); } catch (e) { return toast(e.message, true); }
      const ready = E.options.filter((o) => o.ready);
      if (!ready.length) { toast('Collega prima una chiave di Anthropic, OpenAI o Gemini in Chiavi AI', true); return keysDialog && keysDialog(); }
      let sel = E.recommended || { provider: ready[0].provider, model: ready[0].model };
      const TAG = { rec: ['Consigliato', 'rec'], cheap: ['Più economico', 'cheap'], best: ['Qualità migliore', 'best'] };
      const bg = h('div', { class: 'modal-bg' });
      const list = h('div', { class: 'fm-models' });
      const paintM = () => rc(list, ...E.options.map((o) => h('button', {
        class: 'fm-model' + (o.ready ? '' : ' off') + (o.provider === sel.provider && o.model === sel.model ? ' on' : ''),
        disabled: o.ready ? null : true, onclick: () => { sel = { provider: o.provider, model: o.model }; paintM(); } },
        h('div', { class: 'fm-mh' }, h('b', null, o.name), h('small', null, o.providerName), ...(o.tags || []).map((t) => h('span', { class: 'fm-tag t-' + TAG[t][1] }, TAG[t][0])),
          h('span', { class: 'grow' }), h('b', { class: 'fm-cost' }, '≈ ' + usd(o.cost))),
        h('small', null, o.ready ? o.why : 'Per usarlo collega la chiave di ' + o.providerName + ' in Chiavi AI'))));
      paintM();
      const go = h('button', { class: 'btn primary', onclick: () => { bg.remove(); runAnalyze(sel); } }, icon('sparkle', 14, '#fff'), 'Analizza i video');
      bg.append(h('div', { class: 'modal fm-mmodal' },
        h('div', { class: 'ai-mh' }, h('h2', null, 'Chi analizza i video?'), h('button', { class: 'iconbtn', onclick: () => bg.remove() }, icon('x', 16))),
        h('p', { class: 'fm-mlead' }, 'L\'AI legge le trascrizioni e i numeri di ' + E.videos + ' video (circa ' + Math.round(E.tokensIn / 1000) + ' mila token) e scrive il formato. Paghi direttamente il servizio che scegli, con la tua chiave: il costo è una stima.'),
        list,
        h('div', { class: 'fm-mfoot' }, h('small', null, 'Consigliato = la qualità più alta al prezzo più basso tra le chiavi che hai. Il formato si fa una volta: la differenza è di pochi centesimi.'), go)));
      bg.addEventListener('click', (e) => { if (e.target === bg) bg.remove(); });
      document.body.append(bg);
    }
    function showTranscript(v) {
      const bg = h('div', { class: 'modal-bg' });
      bg.append(h('div', { class: 'modal ai-guide' }, h('div', { class: 'ai-mh' }, h('h2', { 'data-notr': '' }, v.title || 'Trascrizione'), h('button', { class: 'iconbtn', onclick: () => bg.remove() }, icon('x', 16))),
        v.sheet ? h('img', { class: 'fm-sheet', src: mediaUrl(v.sheet), alt: 'Tutte le visual del video' }) : null,
        h('div', { class: 'fm-tx' }, ...(v.transcript || []).map((sg) => h('div', null, h('span', { class: 't' }, fmt(sg.a, 1)), h('span', { 'data-notr': '' }, sg.t))))));
      bg.addEventListener('click', (e) => { if (e.target === bg) bg.remove(); });
      document.body.append(bg);
    }
    const name = h('input', { class: 'ais-title', value: fm.name || '', maxlength: 80, 'aria-label': 'Nome del formato' });
    name.addEventListener('input', () => { clearTimeout(saveT); saveT = setTimeout(() => post('/api/ai/format/save', { id: fm.id, name: name.value }).catch(() => {}), 500); });
    const kind = h('select', { class: 'ai-spk' }, ...Object.entries(D.kinds).map(([k, l]) => h('option', { value: k, selected: k === fm.kind ? true : null }, l)));
    kind.addEventListener('change', () => post('/api/ai/format/save', { id: fm.id, kind: kind.value }).catch(() => {}));
    const hdr = h('header', { class: 'ais-head' },
      h('button', { class: 'ais-back', 'aria-label': 'Formati', onclick: () => nav('aiformats') }, icon('left', 16, 'currentColor', 2.2)),
      h('div', { class: 'ais-tt' }, h('span', { class: 'ais-page' }, icon('library', 13), 'Formato', kind), name),
      h('div', { class: 'grow' }),
      h('button', { class: 'btn ghost sm', 'data-tip': D.folder, onclick: () => post('/api/ai/format/reveal', { id: fm.id }).catch(() => {}) }, icon('folder', 14), 'Apri la cartella'),
      h('button', { class: 'btn ghost sm', onclick: async () => { if (!await confirmBox('Eliminare il formato?', 'Si cancellano trascrizioni, fotogrammi e il formato. I tuoi video originali restano dove sono.', 'Elimina', true)) return; await post('/api/ai/format/delete', { id: fm.id }); nav('aiformats'); } }, icon('trash', 14)));
    app.append(topbar(-1, null, false, { name: 'Storie AI', home: true }),
      h('main', { class: 'ais-main' }, h('div', { class: 'ais-glow' }), hdr, h('section', { class: 'ais-card' }, body)));
    paint();
    if (running) startPoll();
    else if ((fm.videos || []).some((v) => v.status === 'pronto' && ((v.shotsAlgo || 1) < 3 || (v.url && !v.stats)))) recount('');   // analisi migliorata: aggiorno da solo i video vecchi
  }
  function builtinFormat(fm, kinds) {
    setTitle(fm.name);
    const an = fm.analysis || {}, pc = an.pacing || {};
    const stat = (v, l) => h('div', { class: 'fm-stat' }, h('b', null, v), h('span', null, l));
    const ta = h('textarea', { class: 'input ai-ta fm-prompt', rows: 18, readonly: true }); ta.value = fm.prompt || '';
    const dup = async () => { try { const f = await post('/api/ai/format/duplicate', { id: fm.id }); toast('Copia creata: ora puoi modificarla e aggiungere i tuoi video'); nav('aiformats', f.id); } catch (e) { toast(e.message, true); } };
    const hdr = h('header', { class: 'ais-head' },
      h('button', { class: 'ais-back', 'aria-label': 'Formati', onclick: () => nav('aiformats') }, icon('left', 16, 'currentColor', 2.2)),
      h('div', { class: 'ais-tt' }, h('span', { class: 'ais-page' }, icon('library', 13), 'Formato pronto di Noonframe'), h('b', { class: 'fm-bname' }, fm.name)),
      h('div', { class: 'grow' }),
      h('button', { class: 'btn ghost sm', onclick: dup }, icon('copy', 14), 'Duplica per modificarlo'));
    const body = h('div', { class: 'ais-body' },
      h('div', { class: 'wz-sum' }, icon('sparkle', 16, 'currentColor', 2), h('span', null, (fm.basedOn || '') + '. Si usa scegliendolo in "Nuova storia": lo script prende struttura, ritmo e regole di questi video, con il tuo prodotto e il tuo personaggio.')),
      h('div', { class: 'fm-stats' }, stat((pc.length_sec || '–') + ' s', 'durata ideale'), stat((pc.scene_sec || '–') + ' s', 'una visual ogni'),
        stat(pc.words_per_sec || '–', 'parole al secondo'), stat((an.structure || []).length, 'passaggi')),
      an.summary ? h('p', { class: 'fm-bsum' }, an.summary) : null,
      h('div', { class: 'fm-make done' }, h('div', null, h('b', null, 'Il formato'), h('span', null, 'Solo da leggere. Per cambiarlo, duplicalo.')),
        h('button', { class: 'btn primary', onclick: () => nav('studio') }, icon('plus', 14, '#fff'), 'Crea una storia')),
      ta);
    app.append(topbar(-1, null, false, { name: 'Storie AI', home: true }),
      h('main', { class: 'ais-main' }, h('div', { class: 'ais-glow' }), hdr, h('section', { class: 'ais-card' }, body)));
  }
  async function formatsList() {
    setTitle('Formati');
    let L = await get('/api/ai/formats');
    const wrap = h('div', { class: 'aih-wrap' });
    const create = async () => {
      const bg = h('div', { class: 'modal-bg' });
      const name = h('input', { class: 'input', value: 'Vendita app', maxlength: 80 });
      let kind = 'vendita';
      const kinds = h('div', { class: 'ai-durs' });
      const pk = () => rc(kinds, ...Object.entries(L.kinds).map(([k, l]) => h('button', { class: 'ai-chip' + (k === kind ? ' on' : ''), onclick: () => { kind = k; pk(); } }, l)));
      pk();
      bg.append(h('div', { class: 'modal ai-nsmodal' }, h('div', { class: 'ai-mh' }, h('h2', null, 'Nuovo formato'), h('button', { class: 'iconbtn', onclick: () => bg.remove() }, icon('x', 16))),
        h('div', { class: 'field' }, h('label', null, 'Nome'), name), h('div', { class: 'field' }, h('label', null, 'Tipo di video'), kinds),
        h('div', { class: 'crop-btns' }, h('button', { class: 'btn ghost', onclick: () => bg.remove() }, 'Annulla'),
          h('button', { class: 'btn primary', onclick: async () => { const f = await post('/api/ai/format/create', { name: name.value, kind }); bg.remove(); nav('aiformats', f.id); } }, 'Crea'))));
      document.body.append(bg); setTimeout(() => name.select(), 30);
    };
    rc(wrap,
      h('section', { class: 'aih-hero', style: { '--h': 265 } }, h('div', { class: 'aih-glow' }),
        h('div', { class: 'aih-top' }, h('span', { class: 'fm-ico' }, icon('library', 26, '#fff', 1.8)),
          h('div', { class: 'aih-who' }, h('h1', null, 'Formati'), h('div', { class: 'aih-meta' }, h('span', null, 'Impara da video che funzionano e scrivi script dello stesso tipo'))),
          h('div', { class: 'grow' }), h('button', { class: 'btn primary big aih-new', onclick: create }, icon('plus', 16, '#fff'), 'Nuovo formato'))),
      L.formats.length ? h('div', { class: 'fm-grid' }, ...L.formats.map((f) => h('div', { class: 'fm-card', role: 'button', tabindex: '0', onclick: () => nav('aiformats', f.id) },
        h('div', { class: 'fm-cthumb' + (f.builtin ? ' nf' : '') }, f.thumb ? h('img', { src: mediaUrl(f.thumb), alt: '' }) : icon(f.builtin ? 'sparkle' : 'library', 22, f.builtin ? '#fff' : undefined)),
        h('div', null, h('b', { 'data-notr': '' }, f.name), h('small', null, (L.kinds[f.kind] || '') + ' · ' + (f.builtin ? 'di Noonframe' : f.ready + ' / ' + f.videos + ' video')),
          h('span', { class: 'fm-badge ' + (f.builtin ? 's-nf' : f.hasPrompt ? 's-pronto' : 's-incoda') }, f.builtin ? 'Pronto da usare' : f.hasPrompt ? 'Formato pronto' : 'Da creare')))))
        : h('div', { class: 'aih-emptyst' }, h('span', { class: 'ic' }, icon('library', 20, '#fff')), h('div', null, h('b', null, 'Nessun formato ancora'),
          h('span', null, 'Crea un formato, carica i video che funzionano e l\'AI impara come sono fatti.')), h('button', { class: 'btn primary', onclick: create }, 'Nuovo formato')));
    app.append(topbar(-1, null, false, { name: 'Storie AI', home: true }), h('main', { class: 'ai-home2' }, wrap));
  }

  return { home, page: pageEditor, story: storyEditor, formats: formatsScreen, keysDialog };
}
