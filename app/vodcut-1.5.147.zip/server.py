"""NoonFrame (ex VODcut) - server locale. Avvia l'app: python server.py

Gira solo su questo PC (127.0.0.1). L'interfaccia e' in web/ e si apre in una
finestra di Edge/Chrome in modalita' app.
"""
import json
import math
import mimetypes
import os
import re
import secrets
import struct
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


# con pythonw (senza finestra nera) stdout/stderr non esistono: scriviamo su un file di log
if sys.stdout is None or sys.stderr is None:
    # il log sta nella cartella dell'app, cosi' si trova subito
    # (anche quando gira un aggiornamento: il log resta nella cartella dell'app installata)
    _lp = os.environ.get("VODCUT_LOG") or os.path.join(os.environ.get("VODCUT_BASE") or os.path.dirname(os.path.abspath(__file__)), "vodcut.log")
    try:   # il log non cresce all'infinito: oltre 5 MB si tiene solo l'ultima parte
        if os.path.getsize(_lp) > 5_000_000:
            os.replace(_lp, _lp[:-4] + "-vecchio.log")
    except OSError:
        pass
    _log = open(_lp, "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _log
    sys.stderr = sys.stderr or _log


def _fatal(msg):
    print(msg)
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, msg, "NoonFrame", 0x10)
        except Exception:
            pass
    elif sys.platform == "darwin":
        try:
            subprocess.run(["osascript", "-e", 'display alert "NoonFrame" message ' + json.dumps(msg) + ' as critical'], timeout=120)
        except Exception:
            pass
    sys.exit(1)


def _boot_update():
    """Aggiornamenti automatici: se e' gia' stata scaricata una versione piu' nuova, parte quella."""
    if os.environ.get("VODCUT_BOOTED") or "--no-update" in sys.argv:
        return
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        sys.path.insert(0, here)
        from engine import updater
        updater.boot(here)
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()


_boot_update()


def _repair_opencv():
    """OpenCV a volte si rompe (due versioni installate insieme): lo sistemiamo prima di caricarlo.
    Si prova una volta sola: se non basta, l'app parte lo stesso (senza bloccare ogni avvio)."""
    nw = 0x08000000 if sys.platform == "win32" else 0
    mark = os.path.join(os.path.expanduser("~"), "VODcut", "opencv-controllato-2.txt")
    if os.path.exists(mark):
        return
    chk = [sys.executable, "-c", "import cv2, sys; print(cv2.__version__, cv2.__file__); "
           "sys.exit(0 if hasattr(cv2, 'FaceDetectorYN') or hasattr(cv2, 'CascadeClassifier') else 3)"]
    try:
        c = subprocess.run(chk, capture_output=True, creationflags=nw, timeout=60)
    except Exception:
        return
    if c.returncode == 0:
        return
    why = ((c.stderr.decode(errors="ignore").strip().splitlines() or [""])[-1] or c.stdout.decode(errors="ignore").strip())[:200]
    print(f"[app] OpenCV incompleto ({why}): lo reinstallo (una volta sola, circa un minuto)", flush=True)
    pip = [sys.executable, "-m", "pip"]
    subprocess.run(pip + ["uninstall", "-y", "opencv-python-headless", "opencv-contrib-python", "opencv-contrib-python-headless"],
                   capture_output=True, creationflags=nw)
    r = subprocess.run(pip + ["install", "--force-reinstall", "--no-deps", "opencv-python<5"], capture_output=True, creationflags=nw)
    c = subprocess.run(chk, capture_output=True, creationflags=nw)
    ok = c.returncode == 0
    print("[app] OpenCV " + ("sistemato " + c.stdout.decode(errors="ignore").strip() if ok else "ancora rotto: " + (c.stdout.decode(errors="ignore") + c.stderr.decode(errors="ignore") + r.stderr.decode(errors="ignore"))[-600:]), flush=True)
    try:
        os.makedirs(os.path.dirname(mark), exist_ok=True)
        with open(mark, "w") as f:
            f.write("ok" if ok else "tentato")
    except OSError:
        pass


_repair_opencv()

try:
    import numpy as np
    import cv2  # noqa: F401
except ImportError as _e:
    _fatal(f"Manca una libreria ({_e.name}). Fai doppio clic su INSTALLA.bat e poi riapri NoonFrame.")

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)


from engine import analyze as A  # noqa: E402
from engine import package as PK  # noqa: E402
from engine import project as P  # noqa: E402
from engine import render as R  # noqa: E402
from engine import transcribe as T  # noqa: E402
from engine import vertical as VT
from engine import face as FACE  # noqa: E402
from engine import story as ST  # noqa: E402
from engine import ai as AI  # noqa: E402
from engine import studio as SD  # noqa: E402
from engine import extras as EX  # noqa: E402
from engine import social as SOC  # noqa: E402
EX.load()
from engine import formats as FMT  # noqa: E402
from engine import aiedit as AE  # noqa: E402
from engine import design as DZ  # noqa: E402
from engine import webcam as W  # noqa: E402
from engine.util import (replace_retry, APP_DIR, CACHE_DIR, EXPORTS_DIR, IMPORTS_DIR, NO_WINDOW, ffmpeg_bin, ffprobe_bin, load_settings,  # noqa: E402
                         nvenc_ok, popen, probe, proxy_gpu_args, save_settings, tempdir)

from engine import feedback as FB  # noqa: E402
from engine import account as ACC  # noqa: E402
from engine import updater as UPD  # noqa: E402
from engine import fonts as FONTS  # noqa: E402
from engine.version import VERSION  # noqa: E402


def _code_stamp():
    """Data dell'ultima modifica del codice: serve a riavviare il server dopo un aggiornamento."""
    root = os.path.dirname(os.path.abspath(__file__))
    m = 0.0
    for d, _, files in os.walk(root):
        if "__pycache__" in d:
            continue
        for f in files:
            if f.endswith((".py", ".js", ".css", ".html")):
                m = max(m, os.path.getmtime(os.path.join(d, f)))
    return m


CODE_STAMP = _code_stamp()
WEB = os.path.join(ROOT, "web")
TOKEN = secrets.token_hex(16)


def _launch_key():
    """Chiave d'avvio: solo la finestra di NoonFrame (e chi puo' leggere la cartella dell'app) la conosce.
    Senza, la pagina dell'app non si apre e non consegna il codice di sessione: un altro programma o un altro
    utente dello stesso computer non puo' chiedere http://127.0.0.1:8765/ e prendersi l'accesso ai file e alle chiavi."""
    import hmac as _h  # noqa: F401
    fp = os.path.join(APP_DIR, ".avvio")
    try:
        with open(fp, encoding="utf-8") as f:
            k = f.read().strip()
        if re.fullmatch(r"[A-Za-z0-9_-]{32,}", k):
            return k
    except OSError:
        pass
    k = secrets.token_urlsafe(32)
    try:
        os.makedirs(APP_DIR, exist_ok=True)
        fd = os.open(fp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(k)
    except OSError:
        pass
    return k


LAUNCH = _launch_key()


def _proof(challenge):
    import hmac
    import hashlib
    return hmac.new(LAUNCH.encode(), ("noonframe:" + str(challenge)[:64]).encode(), hashlib.sha256).hexdigest()


def app_url(port, extra=""):
    return f"http://127.0.0.1:{port}/?k={LAUNCH}" + extra
PORT = int(os.environ.get("VODCUT_PORT", "8765"))
LAST_PING = [time.time()]
LOCK = threading.Lock()

# ------------------------------------------------------------------ job in background
JOBS = {}


class Job:
    def __init__(self, kind, pid=None):
        self.id = "j" + secrets.token_hex(5)
        self.kind, self.pid = kind, pid
        self.status, self.progress, self.message = "running", 0.0, ""
        self.result, self.error = None, None
        self.cancelled = False
        self.log = []
        self.t0 = time.time()
        JOBS[self.id] = self

    def eta(self):
        """Secondi che mancano, stimati da quanto e' andato finora (None finche' non si sa dire)."""
        el, p = time.time() - self.t0, float(self.progress or 0)
        if self.status != "running" or p < 0.03 or el < 4:
            return None
        return max(1, int(el * (1 - p) / p))

    def to_json(self):
        return {"id": self.id, "kind": self.kind, "pid": self.pid, "status": self.status,
                "progress": round(self.progress, 4), "message": self.message, "result": self.result,
                "error": self.error, "eta": self.eta()}


def start_job(kind, pid, fn):
    # un solo job per tipo per progetto
    for j in JOBS.values():
        if j.kind == kind and j.pid == pid and j.status == "running":
            return j
    job = Job(kind, pid)

    def runner():
        t0 = time.time()
        try:
            job.result = fn(job)
            job.status = "done" if not job.cancelled else "cancelled"
            job.progress = 1.0
        except R.Cancelled:
            job.status = "cancelled"
        except Exception as e:  # errore leggibile per l'interfaccia
            job.status = "cancelled" if job.cancelled else "error"
            job.error = str(e) or e.__class__.__name__
            traceback.print_exc()
        # uso delle funzioni per l'account: solo tipo di lavoro, esito e durata
        try:
            ACC.track("job." + re.sub(r"[^a-z0-9_]", "_", re.split(r"[:/\\ ]", str(kind))[0].lower())[:24], {"status": job.status, "sec": round(time.time() - t0, 1)})
        except Exception:
            pass
    threading.Thread(target=runner, daemon=True).start()
    return job


# lavori che si possono buttare: si rifanno da soli quando servono
DISPOSABLE_JOBS = ("proxy", "thumbs", "montage", "prepinsert")


def running_jobs():
    return [j for j in JOBS.values() if j.status == "running"]


# ------------------------------------------------------------------ cache analisi
def ckey(pid):
    """Le clip verticali (id "<vod>_v...") usano le cache del VOD da cui vengono: stessa live, niente lavoro doppio."""
    return pid.split("_v")[0]


def wave_path(pid):
    return os.path.join(CACHE_DIR, ckey(pid) + "_wave.json")


def db_path(pid):
    return os.path.join(CACHE_DIR, ckey(pid) + "_db.npy")


PREVIEW_OK = ("h264", "vp8", "vp9")


def job_prepare(job, pid):
    """Webcam + volume dell'audio (appena importato il VOD)."""
    proj = P.load(pid)
    src = proj["source"]
    if proj.get("kind") in ("blank", "story"):   # video di base nero: niente copia leggera, niente webcam
        return _prepare_audio(job, pid, proj)
    # anteprima fluida: per video piu' grandi di 720p (o in formati che l'anteprima non legge)
    # si prepara subito, in parallelo, una copia leggera a 720p
    if int(proj["height"]) > 720 or (proj.get("vcodec") and proj["vcodec"] not in PREVIEW_OK):
        hq = min(720, int(proj["height"]))
        start_job(f"proxy{hq}", pid, lambda j: job_proxy(j, pid, hq))
    if proj.get("kind") in ("video", "blank", "story"):
        return _prepare_audio(job, pid, proj)
    job.message = "Cerco la tua webcam"
    remembered = load_settings().get("webcam")
    try:
        cam = W.detect_webcam(src)
    except Exception:
        traceback.print_exc()
        cam = None
    if not cam:  # nessuna stima: riquadro standard in alto a destra, l'utente lo sistema
        w = int(proj["width"] * 0.24)
        cam = {"box": [proj["width"] - w - int(proj["width"] * 0.01), int(proj["height"] * 0.01), w, int(w * 9 / 16)],
               "confidence": 0.0}
    if remembered and remembered.get("size") == [proj["width"], proj["height"]] and (not cam or cam["confidence"] < 0.6):
        cam = {"box": remembered["box"], "confidence": 1.0, "remembered": True}
    with LOCK:  # la webcam si vede subito, l'audio continua in background
        cur = P.load(pid)
        if not cur.get("webcam"):
            cur["webcam"] = cam
            P.save(cur)
    job.progress = 0.3
    return _prepare_audio(job, pid, proj)


def _prepare_audio(job, pid, proj):
    src = proj["source"]
    if proj.get("hasAudio", True):
        job.message = "Ascolto l'audio"
        db = A.loudness_track(src, progress=lambda x: setattr(job, "progress", 0.3 + 0.7 * x),
                              duration=proj["duration"], cancel=lambda: job.cancelled)
    else:
        db = np.full(int(proj["duration"] / A.HOP) + 1, -90.0, np.float32)
    np.save(db_path(pid), db)
    with open(wave_path(pid), "w") as f:
        json.dump({"perSec": 5, "peaks": A.waveform(db, 5)}, f)
    with LOCK:
        proj = P.load(pid)
        proj["analysis"] = dict(proj.get("analysis") or {}, ready=True)
        P.save(proj)
    return {"webcam": proj.get("webcam")}


# ------------------------------------------------------------------ progetti senza VOD: video normale, vuoto, storia
FORMATS = {"16:9": (1920, 1080), "9:16": (1080, 1920), "1:1": (1080, 1080), "4:5": (1080, 1350)}


def base_path(name):
    d = os.path.join(IMPORTS_DIR, "basi")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, name + ".mp4")


def finish_plain(proj, kind):
    """Progetto che va dritto all'editor: niente webcam, niente tagli e zoom automatici."""
    proj["kind"] = kind
    proj["stage"] = "editor"
    proj["webcam"] = None
    proj["analysis"] = {"ready": True}
    proj["format"] = "native"
    P.save(proj)
    return proj


BLANK_SPACE = 1800.0   # nero di base del progetto vuoto: e' solo "spazio" (la durata vera la fanno le clip che metti)


def make_black_space(src, W_, H_, fps=30):
    """Mezz'ora di nero (con audio muto): 10 s ripetuti senza ricodificare, pronta in un attimo."""
    chunk = src[:-4] + "_pezzo.mp4"
    ST.make_base(chunk, W_, H_, 10.0, None, ffmpeg_bin(), NO_WINDOW)
    n = int(BLANK_SPACE // 10)
    r = subprocess.run([ffmpeg_bin(), "-nostdin", "-v", "error", "-y", "-stream_loop", str(n - 1), "-i", chunk, "-c", "copy",
                        "-movflags", "+faststart", src], stdin=subprocess.DEVNULL, capture_output=True, creationflags=NO_WINDOW)
    try:
        os.remove(chunk)
    except OSError:
        pass
    if r.returncode != 0:
        raise RuntimeError(r.stderr.decode(errors="ignore")[-300:])
    return src


def gap_file(proj):
    """Il nero per gli spazi vuoti nella traccia principale (uno per dimensione, riusato da tutti i progetti)."""
    W_, H_ = int(proj.get("width") or 1920), int(proj.get("height") or 1080)
    path = base_path(f"spazio_{W_}x{H_}")
    if not os.path.exists(path):
        tmp = path[:-4] + "_tmp.mp4"
        make_black_space(tmp, W_, H_)
        os.replace(tmp, path)
    return {"file": path, "w": W_, "h": H_, "dur": BLANK_SPACE}


def create_blank(fmt, dur, name):
    ACC.track("project.blank")
    W_, H_ = FORMATS.get(fmt, FORMATS["16:9"])
    # il nero di base e' uguale per tutti i progetti dello stesso formato: si crea una volta sola (poi e' immediato)
    src = base_path(f"spazio_{W_}x{H_}")
    if not os.path.exists(src):
        tmp = src[:-4] + "_" + secrets.token_hex(3) + "_tmp.mp4"
        make_black_space(tmp, W_, H_)
        os.replace(tmp, src)
    proj = P.create(src, name=name or "Progetto vuoto")
    proj["hasAudio"] = False
    return finish_plain(proj, "blank")


def job_story_voice(job, data):
    """Voce della storia: trascrizione, tempi di ogni battuta e differenze rispetto allo script."""
    lines = [dict(b) for b in data.get("lines") or [] if (b.get("text") or "").strip()]
    voice = (data.get("voice") or "").strip()
    if not os.path.isfile(voice):
        raise RuntimeError("File della voce non trovato")
    vdur = probe(voice)["duration"]
    if not T.available():
        est = ST.estimate(lines)
        k = vdur / (est[-1][1] or 1)
        return {"dur": vdur, "times": [[round(a * k, 2), round(b * k, 2)] for a, b in est], "report": None,
                "note": "Trascrizione non installata: tempi divisi in proporzione al testo"}
    while GPU["state"] == "installing" and not job.cancelled:
        job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
        time.sleep(1)
    job.message = "Ascolto la voce"
    tr = T.transcribe(voice, vdur, progress=lambda x: setattr(job, "progress", 0.05 + 0.9 * x), cancel=lambda: job.cancelled,
                      log=lambda m: setattr(job, "message", m), prompt=" ".join(b["text"] for b in lines))
    words = [w for sg in tr.get("segments", []) for w in sg.get("words", [])]
    if not words:
        raise RuntimeError("Nella voce non ho sentito parole")
    times = ST.align(lines, words, vdur)
    regs = ST.speech_regions(words, vdur)
    return {"dur": vdur, "times": times, "report": ST.check_voice(lines, words),
            "words": [[w["w"], round(float(w["a"]), 3), round(float(w["b"]), 3)] for w in words],
            "regions": regs, "trimDur": round(sum(b - a for a, b in regs), 2), "timesTrim": ST.trim_times(regs, times)}


def job_story(job, data):
    """Storia con immagini: tempi (dalla voce o dal testo), video di base 9:16 con la voce, poi l'editor fa il resto."""
    lines = [dict(b) for b in data.get("lines") or [] if (b.get("text") or "").strip()]
    if not lines:
        raise RuntimeError("Lo script e' vuoto")
    voice = (data.get("voice") or "").strip() or None
    if voice and not os.path.isfile(voice):
        raise RuntimeError("File della voce non trovato")
    words = None      # parole della voce [{w, a, b}] (dal controllo della voce, o si trascrive qui)
    times = None
    if voice:
        vdur = probe(voice)["duration"]
        words = [{"w": w[0], "a": w[1], "b": w[2]} for w in data.get("words") or []] or None
        if not words and T.available():
            while GPU["state"] == "installing" and not job.cancelled:
                job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
                time.sleep(1)
            job.message = "Ascolto la voce"
            try:
                tr = T.transcribe(voice, vdur, progress=lambda x: setattr(job, "progress", 0.05 + 0.25 * x), cancel=lambda: job.cancelled,
                                  log=lambda m: setattr(job, "message", m), prompt=" ".join(b["text"] for b in lines))
                words = [w for sg in tr.get("segments", []) for w in sg.get("words", [])] or None
            except R.Cancelled:
                raise
            except Exception as e:
                if not data.get("exact"):
                    raise
                print(f"[storia] trascrizione non riuscita, sottotitoli a frasi: {e}", flush=True)   # i tempi li sappiamo gia'
                words = None
        exact = data.get("times") if data.get("exact") else None
        if exact and len(exact) == len(lines):   # tempi gia' noti (voci generate una per scena): si usano cosi'
            times = [[round(float(a), 3), round(float(b), 3)] for a, b in exact]
        elif words:
            times = ST.align(lines, words, vdur)
        else:   # voce senza trascrizione: le battute si dividono la durata in proporzione al testo
            est = ST.estimate(lines)
            k = vdur / (est[-1][1] or 1)
            times = [[round(a * k, 2), round(b * k, 2)] for a, b in est]
    else:
        times = ST.estimate(lines)
    swords, changed = ST.caption_words(lines, words) if words else (None, None)
    # voce senza i silenzi lunghi tra una frase e l'altra
    if voice and words and data.get("trim"):
        regs = ST.speech_regions(words, vdur)
        job.message = "Tolgo i silenzi dalla voce"
        job.progress = 0.3
        tv = base_path("voce_" + secrets.token_hex(4))[:-4] + ".wav"
        ST.trim_audio(voice, tv, regs, ffmpeg_bin(), NO_WINDOW)
        voice = tv
        times = ST.trim_times(regs, times)
        swords = [[[w, ST.map_time(regs, a), max(ST.map_time(regs, b), ST.map_time(regs, a) + 0.05)] for w, a, b in ln] for ln in swords]
    total = round(max(times[-1][1], 1.0), 2)
    job.message = "Preparo il video"
    job.progress = 0.4
    src = base_path("storia_" + secrets.token_hex(4))
    W_, H_ = FORMATS.get(data.get("format") or "9:16", FORMATS["9:16"])
    ST.make_base(src, W_, H_, total, voice, ffmpeg_bin(), NO_WINDOW, progress=lambda x: setattr(job, "progress", 0.4 + 0.55 * x))
    proj = P.create(src, name=(data.get("name") or "Storia").strip()[:120])
    proj["hasAudio"] = bool(voice)
    imgs = data.get("images") or []
    mots = data.get("motions") or []
    out = []
    ars = {}
    for f in set(x for x in imgs if x):
        try:
            mi = media_info(f)
            ars[f] = (mi["h"] / mi["w"]) if mi.get("w") else 16 / 9
        except Exception:
            pass
    for i, (b, (a, e)) in enumerate(zip(lines, times)):
        f = imgs[i] if i < len(imgs) and imgs[i] and imgs[i] in ars else ""
        out.append({"speaker": b.get("speaker") or "", "text": b["text"].strip(), "a": a, "b": e, "file": f, "ar": ars.get(f),
                    "motion": mots[i] if i < len(mots) and mots[i] else ST.MOTIONS[i % len(ST.MOTIONS)]})
        if b.get("join") and i > 0:
            out[-1]["join"] = True   # continua la clip della battuta prima (stessa immagine o video)
        vids = data.get("videos") or []
        vf = vids[i] if i < len(vids) and vids[i] and os.path.isfile(vids[i]) else None
        if vf:     # scena con un video AI: sopra l'immagine, lungo quanto la scena (o quanto il video, se e' piu' corto)
            try:
                mi = media_info(vf)
                out[-1]["video"] = {"file": vf, "dur": round(float(mi.get("duration") or 5), 3), "ar": (mi["h"] / mi["w"]) if mi.get("w") else ars.get(f)}
            except Exception:
                pass
    if swords:
        for ln, ws, ch in zip(out, swords, changed):
            ln["words"] = ws
            if ch and ws:   # a schermo quello che si sente davvero nella voce
                ln["script"] = ln["text"]
                ln["text"] = " ".join(w[0] for w in ws)
    proj["story"] = {"lines": out, "colors": data.get("colors") or {}, "pending": True, "voice": voice or "",
                     "captions": data.get("captions") if data.get("captions") in ("line", "word") and swords else "line"}
    mu = data.get("music") or {}
    if mu.get("file") and os.path.isfile(mu["file"]):
        try:
            mdur = probe(mu["file"])["duration"]
            proj["story"]["music"] = {"file": mu["file"], "dur": round(mdur, 3), "name": str(mu.get("name") or "Musica")[:80],
                                      "vol": max(5, min(100, int(mu.get("vol") or 22)))}
        except Exception:
            pass
    if data.get("aiStory"):
        proj["story"]["ai"] = str(data["aiStory"])[:40]
    finish_plain(proj, "story")
    start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
    return {"project": proj["id"]}


# ---------------------------------------------------------------- Storie AI (con le chiavi dell'utente)
def job_ai_write(job, data):
    page = SD.get_page(data.get("page"))
    mode = data.get("mode") if data.get("mode") in ("auto", "topic", "script") else "topic"
    topic = str(data.get("topic") or "")[:2000]
    script = str(data.get("script") or "")[:20000]
    if mode == "topic" and not topic.strip():
        raise RuntimeError("Scrivi l'argomento della storia")
    if mode == "script" and not script.strip():
        raise RuntimeError("Incolla lo script")
    dur = max(15, min(180, int(data.get("duration") or page.get("duration") or 60)))
    lang = str(data.get("lang") or page.get("lang") or "it")[:5]
    job.message = "Scrivo la storia"
    job.progress = 0.1
    fmt = None
    if data.get("format"):
        try:
            fmt = FMT.get(data["format"])
        except Exception:
            fmt = None
    r = SD.write_story(page, mode, topic, script, dur, lang, cancel=lambda: job.cancelled, fmt=fmt)
    sid = data.get("story") or ("sa" + secrets.token_hex(6))
    st = {"id": sid, "page": page["id"], "title": r["title"], "topic": topic, "mode": mode, "duration": dur, "lang": lang,
          "status": "script", "created": time.time(), "scenes": r["scenes"], "versions": [], "costs": [],
          "format": fmt["id"] if fmt else None}
    SD._cost(st, "text", r["cfg"]["provider"], r["cfg"]["model"], r.get("usd", AI.PRICE["text"]))
    share = (page.get("videoCfg") or {}).get("share") or "few"
    fal_on = AI.keys_status()["fal"]["set"]
    vc_ = page.get("videoCfg") or {}
    look = "images" if data.get("look") == "images" else "video"
    st["look"] = look
    SD.set_lipsync(st, bool(vc_.get("lipsync")))
    if look == "images":   # storia con immagini: solo immagini animate, nessun video AI
        SD.choose_videos(st, "none", "off")
    else:
        SD.choose_videos(st, share if fal_on else "none", (vc_.get("dialog") or "talk") if fal_on else "off")
    SD.save_story(st)
    ACC.track("ai.write", {"text": r["cfg"]["provider"], "mode": mode, "scenes": len(st["scenes"])})
    return {"story": sid}


def job_ai_scene(job, data):
    sid = data.get("story")
    with SD._lock(sid):
        st = SD.get_story(sid)
    page = SD.get_page(st["page"])
    i = int(data.get("i"))
    job.message = "Riscrivo la scena"
    sc, cfg = SD.rewrite_scene(page, st, i, str(data.get("instruction") or "")[:600], cancel=lambda: job.cancelled)
    with SD._lock(sid):
        st = SD.get_story(sid)
        old = st["scenes"][i]
        if old.get("locked"):
            raise RuntimeError("La scena è bloccata")
        st.setdefault("versions", []).append({"at": time.time(), "scenes": [{"speaker": x.get("speaker"), "text": x["text"]} for x in st["scenes"]]})
        del st["versions"][:-30]
        sc["id"] = old["id"]
        sc["image"], sc["audio"] = old.get("image"), old.get("audio")
        st["scenes"][i] = sc
        SD._cost(st, "text", cfg["provider"], cfg["model"], AI.PRICE["text"] / 4)
        SD.save_story(st)
    return {"story": sid}


def job_ai_visuals(job, data):
    sid = data.get("story")
    st = SD.get_story(sid)
    page = SD.get_page(st["page"])
    job.message = "Aggiorno le descrizioni delle immagini"
    vis, cfg = SD.refresh_visuals(page, st, cancel=lambda: job.cancelled)
    names = {c["name"].lower(): c["name"] for c in page.get("characters") or []}
    with SD._lock(sid):
        st = SD.get_story(sid)
        for k, sc in enumerate(st["scenes"]):
            if sc.get("locked") or k >= len(vis):
                continue
            v = vis[k]
            sc["visual"] = SD._clean_str(v.get("visual"), 1200) or sc.get("visual")
            sc["shot"] = SD._clean_str(v.get("shot"), 120) or sc.get("shot")
            sc["characters"] = [names[c.lower()] for c in (v.get("characters") or []) if isinstance(c, str) and c.lower() in names]
            if v.get("motion") in SD.MOTIONS:
                sc["motion"] = v["motion"]
        SD._cost(st, "text", cfg["provider"], cfg["model"], AI.PRICE["text"] / 2)
        SD.save_story(st)
    return {"story": sid}


def _prog(job, a, b):
    def f(x, msg):
        job.progress = a + (b - a) * x
        job.message = msg
    return f


def job_ai_images(job, data):
    sid = data.get("story")
    only = [int(x) for x in data.get("only")] if isinstance(data.get("only"), list) else None
    job.message = "Creo le immagini"
    r = SD.gen_images(sid, only, progress=_prog(job, 0.02, 1.0), cancel=lambda: job.cancelled)
    ACC.track("ai.images", {"n": r["done"], "err": r["errors"]})
    return r


def job_ai_voices(job, data):
    sid = data.get("story")
    only = [int(x) for x in data.get("only")] if isinstance(data.get("only"), list) else None
    job.message = "Creo le voci"
    r = SD.gen_voices(sid, only, progress=_prog(job, 0.02, 1.0), cancel=lambda: job.cancelled)
    ACC.track("ai.voices", {"n": r["done"], "err": r["errors"]})
    return r


def job_ai_videos(job, data):
    sid = data.get("story")
    only = [int(x) for x in data.get("only")] if isinstance(data.get("only"), list) else None
    job.message = "Creo i video"
    r = SD.gen_videos(sid, only, progress=_prog(job, 0.02, 1.0), cancel=lambda: job.cancelled)
    ACC.track("ai.videos", {"n": r["done"], "err": r["errors"]})
    try:   # copie leggere per l'anteprima nell'editor: pronte prima di aprirlo
        for sc in SD.get_story(sid).get("scenes") or []:
            f = (sc.get("video") or {}).get("file")
            if f and os.path.isfile(f):
                light_copy(f)
    except Exception:
        traceback.print_exc()
    return r


def job_ai_ownvoice(job, data):
    """La tua registrazione al posto della voce AI: la ascolto e trovo dove inizia ogni scena."""
    sid = data.get("story")
    src = str(data.get("path") or "")
    st = SD.get_story(sid)
    lines = [{"speaker": x.get("speaker") or "", "text": x["text"]} for x in st["scenes"]]
    d = os.path.join(SD._story_dir(sid), "voce")
    os.makedirs(d, exist_ok=True)
    dst = os.path.join(d, "registrazione" + os.path.splitext(src)[1].lower())
    shutil.copyfile(src, dst)
    try:
        r = job_story_voice(job, {"voice": dst, "lines": lines})
    except R.Cancelled:
        raise
    except Exception as e:     # trascrizione non disponibile: tempi divisi in proporzione al testo
        print(f"[storie ai] registrazione senza trascrizione: {e}", flush=True)
        vdur = probe(dst)["duration"]
        est = ST.estimate(lines)
        k = vdur / (est[-1][1] or 1)
        r = {"dur": vdur, "times": [[round(a * k, 2), round(b * k, 2)] for a, b in est], "report": None, "words": None,
             "note": "Non sono riuscito ad ascoltare la registrazione: ho diviso i tempi in proporzione al testo. Controllali nell'editor."}
    with SD._lock(sid):
        st = SD.get_story(sid)
        st["ownVoice"] = {"file": dst, "name": os.path.basename(src)[:120], "dur": r.get("dur"), "times": r.get("times"),
                          "words": r.get("words"), "report": r.get("report"), "note": r.get("note"),
                          "texts": [x["text"] for x in st["scenes"]]}
        SD.save_story(st)
    return {"story": sid}



# ------------------------------------------------------------------ accesso a TikTok (solo sul computer)
SOCIAL_LOGIN = {"state": "idle", "site": "", "win": None}
SOCIAL_URLS = {"tiktok": "https://www.tiktok.com/login"}


def social_login(site):
    """Apre la pagina ufficiale di accesso del sito in una finestra di NoonFrame. Appena l'accesso c'e',
    salva la sessione (cifrata, sul computer) e chiude la finestra. La password la vede solo il sito."""
    if NATIVE["win"] is None:
        raise RuntimeError("Apri NoonFrame dall'icona sul desktop per collegare TikTok")
    import webview
    old = SOCIAL_LOGIN.get("win")
    if SOCIAL_LOGIN["state"] == "open" and old is not None:
        try:
            old.show()
            return
        except Exception:
            pass
    w = webview.create_window("Accedi a TikTok", SOCIAL_URLS[site], width=520, height=780, min_size=(420, 600),
                              background_color="#ffffff", text_select=True)
    SOCIAL_LOGIN.update(state="open", site=site, win=w)

    def closed():
        if SOCIAL_LOGIN.get("win") is w and SOCIAL_LOGIN["state"] == "open":
            SOCIAL_LOGIN.update(state="closed", win=None)
    try:
        w.events.closed += closed
    except Exception:
        pass

    def watch():
        end = time.time() + 15 * 60
        while time.time() < end and SOCIAL_LOGIN.get("win") is w and SOCIAL_LOGIN["state"] == "open":
            time.sleep(2)
            try:
                if SOC.connect(site, SOC.from_webview(w.get_cookies())):
                    SOCIAL_LOGIN.update(state="done", win=None)
                    time.sleep(0.8)
                    try:
                        w.destroy()
                    except Exception:
                        pass
                    return
            except Exception:
                continue
        if SOCIAL_LOGIN.get("win") is w and SOCIAL_LOGIN["state"] == "open":
            SOCIAL_LOGIN.update(state="closed", win=None)
            try:
                w.destroy()
            except Exception:
                pass
    threading.Thread(target=watch, daemon=True, name="social-login").start()


def social_logout(site):
    SOC.disconnect(site)
    try:   # toglie la sessione anche dalla finestra di NoonFrame
        win = NATIVE["win"]
        if win is not None:
            win.clear_cookies()
    except Exception:
        pass


NEEDS_BROWSER = ("tiktok.com", "instagram.com")
# TikTok blocca alcune versioni di Chrome (140-149): provo prima browser che passano, poi gli altri
BROWSER_TARGETS = ["chrome-136", "safari-26.0", "firefox-147", "chrome-131", "safari-18.4", "edge-101", "chrome"]


def _clean_url(url):
    """Toglie i parametri di tracciamento (?is_from_webapp=…) dai link social."""
    u = str(url or "").strip()
    try:
        from urllib.parse import urlsplit, urlunsplit
        x = urlsplit(u)
        if any(d in x.netloc for d in NEEDS_BROWSER):
            return urlunsplit((x.scheme, x.netloc, x.path, "", ""))
    except Exception:
        pass
    return u


def _ytdl(url, opts):
    """Scarica con yt-dlp. Per TikTok/Instagram si finge un browser vero (curl_cffi, scaricato la prima volta)."""
    import yt_dlp
    url = _clean_url(url)
    browser = any(d in url for d in NEEDS_BROWSER)

    site = "tiktok" if "tiktok.com" in url else ""

    def run(o):
        if site and SOC.connected(site):
            with SOC.cookie_file(site) as cf:
                return run2(dict(o, cookiefile=cf) if cf else o)
        return run2(o)

    def run2(o):
        with yt_dlp.YoutubeDL(o) as ydl:
            info = ydl.extract_info(url, download=True)
            path = ydl.prepare_filename(info)
            if not os.path.exists(path):
                path = os.path.splitext(path)[0] + ".mp4"
        return path, info

    def browser_ready():
        if not EX.ensure_impersonation():
            return False
        try:
            import curl_cffi
            import yt_dlp.dependencies as ydeps
            if getattr(ydeps, "curl_cffi", None) is None:   # yt-dlp caricato prima di curl_cffi: glielo presento ora
                ydeps.curl_cffi = curl_cffi
            import yt_dlp.networking._curlcffi  # noqa: F401  registra il gestore
            return True
        except Exception as e:
            print(f"impersonate non disponibile: {e}", file=sys.stderr)
            return False

    def blocked(m):
        m = m.lower()
        return "login" in m or "unexpected response" in m or "challenge" in m or "403" in m

    msg = ""
    if not browser:
        try:
            return run(opts)
        except Exception as e:
            msg = str(e)
            if not blocked(msg) or not browser_ready():
                raise
            targets = ["chrome"]
    else:
        targets = BROWSER_TARGETS if browser_ready() else []
        if not targets:
            try:
                return run(opts)
            except Exception as e:
                msg = str(e)
    from yt_dlp.networking.impersonate import ImpersonateTarget
    for t in targets:
        try:
            r = run(dict(opts, impersonate=ImpersonateTarget.from_str(t)))
            print(f"[link] scaricato come {t}", file=sys.stderr)
            return r
        except Exception as e:
            msg = str(e)
            print(f"[link] {t}: {msg[:160]}", file=sys.stderr)
            if not blocked(msg):
                break
    if "tiktok" in url:
        if "private" in msg.lower() or "privat" in msg.lower():
            raise RuntimeError("Questo TikTok è privato: scaricalo e trascinalo qui.")
        if not SOC.connected("tiktok"):
            raise RuntimeError("TikTok chiede l'accesso: premi «Collega TikTok» qui sopra, poi Riprova.")
        raise RuntimeError("TikTok non ha lasciato scaricare questo video. Riprova tra poco, oppure scaricalo e trascinalo qui.")
    raise RuntimeError(msg or "Download non riuscito")


def _fmt_download(url, outdir):
    opts = {"outtmpl": os.path.join(outdir, "video.%(ext)s"), "format": "bv*[height<=720]+ba/b[height<=720]/best", "merge_output_format": "mp4",
            "quiet": True, "noprogress": True, "ffmpeg_location": shutil.which("ffmpeg")}
    if re.search(r"(youtube\.com|youtu\.be)/(?!shorts/)", url or ""):
        # video YouTube lunghi: per imparare lo stile bastano i primi minuti (scarica molto meno)
        try:
            from yt_dlp.utils import download_range_func
            opts["download_ranges"] = download_range_func(None, [(0, FMT.SAMPLE_SEC)])
        except Exception:
            pass
    path, info = _ytdl(url, opts)
    return path, info.get("title") or info.get("description") or "", FMT.stats_from_info(info)


def _fmt_stats(url):
    """Solo i numeri pubblici del video (views, like…), senza riscaricarlo."""
    import yt_dlp
    url = _clean_url(url)
    o = {"quiet": True, "noprogress": True, "skip_download": True}
    try:
        if "tiktok.com" in url and EX.ensure_impersonation():
            import curl_cffi
            import yt_dlp.dependencies as ydeps
            if getattr(ydeps, "curl_cffi", None) is None:
                ydeps.curl_cffi = curl_cffi
            import yt_dlp.networking._curlcffi  # noqa: F401
            from yt_dlp.networking.impersonate import ImpersonateTarget
            o["impersonate"] = ImpersonateTarget.from_str(BROWSER_TARGETS[0])
        if "tiktok.com" in url and SOC.connected("tiktok"):
            with SOC.cookie_file("tiktok") as cf:
                with yt_dlp.YoutubeDL(dict(o, cookiefile=cf)) as y:
                    return FMT.stats_from_info(y.extract_info(url, download=False))
        with yt_dlp.YoutubeDL(o) as y:
            return FMT.stats_from_info(y.extract_info(url, download=False))
    except Exception as e:
        print(f"[formati] numeri non letti: {str(e)[:160]}", file=sys.stderr)
        return None


def job_format_videos(job, fid):
    """Analizza i video del formato ancora da fare, uno alla volta (trascrizione + inquadrature + fotogrammi)."""
    if not T.available():
        raise RuntimeError("Per analizzare i video serve la trascrizione: riesegui l'installazione di NoonFrame")
    done = 0
    while not job.cancelled:
        fm = FMT.get(fid)
        todo = [v for v in fm["videos"] if v.get("status") in ("in coda",)]
        if not todo:
            again = [v for v in fm["videos"] if v.get("recount") and v.get("status") == "pronto"]
            if not again:
                break
            v = again[0]
            job.message = f"Riconto le visual: {v.get('title') or ''}"[:120]
            try:
                FMT.recount(fid, v["id"], stats=_fmt_stats(v["url"]) if v.get("url") else None)
            except Exception as e:
                print(f"[formati] riconto: {e}", file=sys.stderr)
            FMT.update(fid, {"videos": [{"id": v["id"], "recount": False}]})
            done += 1
            continue
        v = todo[0]
        total = done + len(todo)
        job.message = f"Video {done + 1} / {total}: {v.get('title') or ''}"[:120]

        def prog(x, msg, d=done, t=total):
            job.progress = (d + x) / max(1, t)
            job.message = f"Video {d + 1} / {t} · {msg}"

        def tr(path, dur, p, cancel):
            while GPU["state"] == "installing" and not job.cancelled:
                time.sleep(1)
            return T.transcribe(path, dur, progress=p, cancel=cancel, log=lambda m: None)
        try:
            FMT.analyze_video(fid, v["id"], tr, download=_fmt_download, progress=prog, cancel=lambda: job.cancelled)
        except Exception as e:
            with FMT._lock(fid):
                cur = FMT.get(fid)
                x = next((y for y in cur["videos"] if y["id"] == v["id"]), None)
                if x is not None and x.get("status") != "pronto":
                    x["status"], x["error"] = "errore", str(e)[:300]
                    FMT.save(cur)
        done += 1
    ACC.track("fmt.videos", {"n": done})
    return {"done": done}


def job_format_analyze(job, fid, choice=None):
    fm = FMT.get(fid)
    try:
        page = SD.page_defaults()
        if choice and choice.get("provider") in AI.MODELS["text"] and choice.get("model") in AI.MODELS["text"][choice["provider"]]:
            page["textCfg"] = {"provider": choice["provider"], "model": choice["model"]}
        cfg = SD.pick(page, "text")
    except AI.AIError as e:
        raise RuntimeError(str(e))
    job.message = "L'AI studia i video"
    job.progress = 0.2
    an, prompt = FMT.build_prompt(fm, cfg, cancel=lambda: job.cancelled)
    with FMT._lock(fid):
        cur = FMT.get(fid)
        cur["analysis"], cur["prompt"] = an, prompt
        FMT.save(cur)
    ACC.track("fmt.analyze", {"text": cfg["provider"], "model": cfg.get("model")})
    return {"format": fid}


def _text_cfg(choice=None):
    page = SD.page_defaults()
    if choice and choice.get("provider") in AI.MODELS["text"] and choice.get("model") in AI.MODELS["text"][choice["provider"]]:
        page["textCfg"] = {"provider": choice["provider"], "model": choice["model"]}
    try:
        return SD.pick(page, "text")
    except AI.AIError as e:
        raise RuntimeError(str(e))


def _b64_images(lst, mx):
    """Immagini mandate dall'editor (data URL jpg/png) -> file temporanei da far guardare all'AI. Solo immagini, piccole."""
    import base64
    out = []
    for x in (lst or [])[:mx]:
        m = re.match(r"^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$", str(x or ""))
        if not m:
            continue
        b = base64.b64decode(m.group(2))
        if len(b) > 6_000_000:
            continue
        d = tempdir("fxref_")
        pth = os.path.join(d, "f%d.%s" % (len(out), "jpg" if m.group(1) == "jpeg" else m.group(1)))
        with open(pth, "wb") as f:
            f.write(b)
        out.append(pth)
    return out


def job_fxreview(job, d):
    from engine import fxcode as FXC
    cfg = _text_cfg()
    job.message = "L'AI controlla l'animazione"
    job.progress = 0.3
    try:
        return FXC.review(cfg, d["code"], d["frames"], d.get("prompt") or "", d.get("text") or "", cancel=lambda: job.cancelled)
    except AI.AIError as e:
        raise RuntimeError(str(e))


def job_fxcode(job, d):
    """Effetto su misura: il codice dell'animazione scritto dall'AI (poi gira nella sandbox dell'editor)."""
    from engine import fxcode as FXC
    cfg = _text_cfg()
    job.message = "L'AI disegna l'effetto"
    job.progress = 0.2
    try:
        out = FXC.generate(cfg, str(d.get("prompt") or ""), float(d.get("dur") or 3), str(d.get("style") or "premium"), str(d.get("text") or ""),
                           float(d.get("aspect") or 16 / 9), prev=d.get("prev") or None, error=d.get("error") or None, hand=bool(d.get("hand")),
                           cancel=lambda: job.cancelled, refs=d.get("refs") or None)
    except AI.AIError as e:
        raise RuntimeError(str(e))
    ACC.track("ai.fxcode", {"text": cfg["provider"], "style": str(d.get("style") or "")[:12]})
    return out


def job_format_style(job, fid, choice=None):
    """Stile di montaggio imparato dai video di riferimento di un formato (numeri + fotogrammi guardati dall'AI)."""
    cfg = _text_cfg(choice)
    job.message = "L'AI guarda i video di riferimento"
    job.progress = 0.2
    st = AE.analyze_style(FMT.get(fid), cfg, cancel=lambda: job.cancelled)
    with FMT._lock(fid):
        cur = FMT.get(fid)
        cur["editStyle"] = st
        FMT.save(cur)
    ACC.track("fmt.style", {"text": cfg["provider"], "model": cfg.get("model")})
    return {"format": fid, "style": st}


def job_format_imgstyle(job, fid, choice=None):
    """Lo stile delle immagini di riferimento (per le Storie AI): l'AI le guarda e scrive il prompt dello stile."""
    cfg = _text_cfg(choice)
    job.message = "L'AI guarda le immagini"
    job.progress = 0.2
    st = AE.analyze_image_style(FMT.get(fid), cfg, cancel=lambda: job.cancelled)
    with FMT._lock(fid):
        cur = FMT.get(fid)
        cur["imageStyle"] = st
        FMT.save(cur)
    return {"format": fid, "style": st}


def snap_cuts_words(items, words, quiet=None, min_keep=1.6):
    """Tagli dell'AI sistemati sulle parole: MAI un taglio a meta' parola.
    - un bordo che cade dentro una parola: la parola resta intera (fuori dal taglio) o va via intera (se e' quasi tutta dentro)
    - un po' di respiro prima e dopo le parole (i tempi delle parole non sono precisi al centesimo)
    - niente pezzi cortissimi tra un taglio e l'altro: il video non salta di continuo da un pezzo all'altro"""
    W = sorted((w for w in words if w["b"] > w["a"]), key=lambda w: w["a"])
    starts = [w["a"] for w in W]
    import bisect
    PRE, POST = 0.12, 0.10   # respiro: prima della parola che riparte, dopo quella che finisce

    def inside(t):
        i = bisect.bisect_right(starts, t) - 1
        return W[i] if 0 <= i < len(W) and W[i]["a"] < t < W[i]["b"] else None

    def prev_end(t):
        i = bisect.bisect_right(starts, t) - 1
        while i >= 0 and W[i]["b"] > t:
            i -= 1
        return W[i]["b"] if i >= 0 else None

    def next_start(t):
        i = bisect.bisect_left(starts, t)
        return W[i]["a"] if i < len(W) else None
    cuts = [it for it in items if it.get("type") in ("cut", "pause")]
    for it in cuts:
        a, b = float(it["a"]), float(it["b"])
        w = inside(a)
        if w:   # inizio dentro una parola: via tutta se e' quasi tutta nel taglio, altrimenti resta intera
            a = w["a"] if (w["b"] - a) > 0.6 * (w["b"] - w["a"]) else w["b"]
        w = inside(b)
        if w:
            b = w["b"] if (b - w["a"]) > 0.6 * (w["b"] - w["a"]) else w["a"]
        # respiro attorno alle parole che restano
        pe, ns = prev_end(a + 1e-3), next_start(b - 1e-3)
        lo = (pe + POST) if pe is not None else 0.0
        hi = (ns - PRE) if ns is not None else b
        a, b = max(a, lo), min(b, hi)
        if quiet and b - a > 0.3:   # il punto piu' silenzioso vicino, ma sempre fuori dalle parole
            qa, qb = quiet(a, 0.0, 0.12), quiet(b, -0.12, 0.0)
            if lo <= qa < qb <= hi:
                a, b = qa, qb
        it["a"], it["b"] = round(a, 3), round(b, 3)
        if b - a < 0.15:
            it["drop"] = True
    # pezzi troppo corti tra due tagli: se c'e' parlato si tiene (si toglie il taglio piu' corto), se e' silenzio si unisce
    live = sorted((it for it in cuts if not it.get("drop")), key=lambda x: x["a"])
    i = 0
    while i < len(live) - 1:
        x, y = live[i], live[i + 1]
        gap = y["a"] - x["b"]
        if gap < min_keep:
            spoken = any(w["a"] < y["a"] and w["b"] > x["b"] for w in W)
            if not spoken and gap < 0.6:
                x["b"] = max(x["b"], y["b"])
                y["drop"] = True
                live.pop(i + 1)
                continue
            if spoken:
                (x if (x["b"] - x["a"]) < (y["b"] - y["a"]) else y)["drop"] = True
                live = [c for c in live if not c.get("drop")]
                continue
        i += 1
    items[:] = [it for it in items if not it.get("drop")]
    for it in items:
        it.pop("drop", None)


def _snap_cuts(pid, proj, items):
    """Bordi dei tagli sulle parole (mai a meta' parola) e sul punto piu' silenzioso vicino.
    Solo senza video inseriti (tempo = tempo della live)."""
    if proj.get("inserts"):
        return
    try:
        db = np.load(db_path(pid))
    except Exception:
        db = None
    hop = 0.05

    def quiet(t, lo, hi):
        if db is None:
            return t
        i0, i1 = max(0, int((t + lo) / hop)), min(len(db) - 1, int((t + hi) / hop))
        if i1 <= i0:
            return t
        k = i0 + int(np.argmin(db[i0:i1 + 1]))
        return round((k + 0.5) * hop, 3)
    snap_cuts_words(items, AE.words_of(proj), quiet)


def _face_places(proj, items):
    """Dove sta il viso nei momenti delle scritte e delle grafiche: l'editor le mette di lato, mai sopra la faccia.
    Gli zoom sulla webcam quando nel riquadro non c'e' nessuno (scena solo cam, webcam vuota) si tolgono."""
    zs = [it for it in items if it.get("type") == "zoom" and not it.get("rect") and not it.get("custom")]
    if zs:
        keep = cam_face_ok(proj, [(it["a"], it["b"]) for it in zs])
        bad = {id(it) for it, k in zip(zs, keep) if not k}
        if bad:
            items[:] = [it for it in items if id(it) not in bad]
            print(f"[zoom] {len(bad)} zoom dell'AI tolti: nessuno nel riquadro della webcam", flush=True)
    if proj.get("inserts"):
        return
    want = [it for it in items if it["type"] in ("text", "graphic", "motion", "fx", "zoom")][:60]
    if not want:
        return
    try:
        import cv2
        from engine import face as FACE
        det = FACE.detector()
        cap = cv2.VideoCapture(proj["source"])
        for it in want:
            cap.set(cv2.CAP_PROP_POS_MSEC, (it["a"] + min(1.0, (it["b"] - it["a"]) / 2)) * 1000)
            ok, fr = cap.read()
            if not ok or fr is None:
                continue
            H, W = fr.shape[:2]
            k = 640 / max(W, H)
            sm = cv2.resize(fr, (int(W * k), int(H * k)))
            fs = det.faces(sm)
            if fs:
                x, y, w, h = fs[0]
                sw, sh = sm.shape[1], sm.shape[0]
                it["face"] = [round((x + w / 2) / sw, 3), round((y + h / 2) / sh, 3), round(w / sw, 3), round(h / sh, 3)]
        cap.release()
    except Exception as e:
        print("[aiedit] viso non trovato:", e, flush=True)


def job_ai_edit(job, pid, sty, prompt, opts, prev=None):
    """Il piano di montaggio dell'AI per un progetto (non cambia niente: lo applica l'editor)."""
    style = AE.style_by_id(sty)
    proj = P.load(pid)
    cfg = _text_cfg()
    job.message = "L'AI legge il video"
    job.progress = 0.05
    if sty == "p:live" and not prev:
        # live: l'AI giudica pezzi di live (parole + volume) invece delle singole parole
        from engine import live as LIVE
        try:
            db = np.load(db_path(pid))
        except Exception:
            db = None
        pl = LIVE.edit_plan(proj, db, cfg, opts.get("liveLen") or "normale", opts, prompt,
                            cancel=lambda: job.cancelled, progress=_prog(job, 0.05, 0.95))
    else:
        pl = AE.plan(proj, style, prompt, opts, cfg, cancel=lambda: job.cancelled, progress=_prog(job, 0.05, 0.95), prev=prev)
    _snap_cuts(pid, proj, pl["items"])
    job.message = "Guardo dove sei nell'inquadratura"
    _face_places(proj, pl["items"])
    vertical = (proj.get("format") == "9:16") or (proj.get("format") == "native" and proj.get("width", 16) < proj.get("height", 9))
    pl["subs"] = AE.subs_patch(style, vertical) if opts.get("subs", True) else None   # se li chiedi ci sono sempre, anche se lo stile non li aveva
    pl["style"] = {"id": sty, "name": style.get("name"), "summary": style.get("summary")}
    try:
        im = SD.pick(SD.page_defaults(), "image")
        pl["imageUsd"] = AI.image_price(im["provider"], im.get("model"))
    except AI.AIError:
        pl["imageUsd"] = None
    from engine import fxcode as FXC
    pl["fxUsd"] = FXC.estimate_usd(cfg.get("model"))   # ogni animazione su misura: una scrittura di codice dell'AI
    pl["credits"] = AI.credits_on()
    ACC.track("ai.edit", {"text": cfg["provider"], "items": len(pl["items"]), "style": sty[:2]})
    return pl


def job_ai_graphics(job, pid, items, gmodel=None):
    """Le grafiche del piano: immagini generate (sticker con sfondo trasparente o b-roll a tutto schermo)."""
    cfg = AE.graphic_cfg(gmodel) if gmodel else None
    if cfg and not AI.keys_status().get(cfg["provider"], {}).get("set") and not AI.credits_on():
        raise RuntimeError(f"Per il modello scelto serve la chiave di {AI.PROVIDERS.get(cfg['provider'], {}).get('name', cfg['provider'])} (Storie AI → Chiavi AI)")
    if not cfg:
        try:
            cfg = SD.pick(SD.page_defaults(), "image")
        except AI.AIError as e:
            raise RuntimeError(str(e))
    proj = P.load(pid)
    vertical = (proj.get("format") == "9:16") or (proj.get("format") == "native" and proj.get("width", 16) < proj.get("height", 9))
    outdir = os.path.join(IMPORTS_DIR, "grafiche-ai")
    out, errors = [], []
    lock = threading.Lock()
    done = [0]

    halt = [False]   # crediti o saldo finiti: inutile continuare

    # gia' create con le stesse scelte: si riusano (niente attesa e niente costi di nuovo)
    os.makedirs(outdir, exist_ok=True)
    cpath = os.path.join(outdir, "cache.json")
    try:
        cache = json.load(open(cpath, encoding="utf-8"))
    except Exception:
        cache = {}

    def ckey(it):
        import hashlib
        k = {"m": [cfg.get("provider"), cfg.get("model"), cfg.get("name")], "v": bool(vertical),
             **{f: it.get(f) for f in ("prompt", "style", "kind", "label", "gstyle", "place")}}
        return hashlib.sha1(json.dumps(k, sort_keys=True, default=str).encode()).hexdigest()[:20]

    def one(it):
        if job.cancelled or halt[0]:
            return
        try:
            key = ckey(it)
            path = cache.get(key)
            if not (path and os.path.isfile(path) and os.path.getsize(path) > 0):
                path = AE.graphic(cfg, it, outdir, vertical, cancel=lambda: job.cancelled)
                with lock:
                    cache[key] = path
            info = media_info(path)
            with lock:
                out.append({"id": it.get("id"), "info": info})
        except Exception as e:
            with lock:
                errors.append(str(e))
                if "credit" in str(e).lower() or "saldo" in str(e).lower():
                    halt[0] = True
        with lock:
            done[0] += 1
            job.progress = done[0] / max(1, len(items))
            job.message = f"Grafiche {done[0]} / {len(items)}"
    job.message = f"Grafiche 0 / {len(items)}"
    ths = []
    for i in range(0, len(items), 3):
        ths = [threading.Thread(target=one, args=(it,), daemon=True) for it in items[i:i + 3]]
        for t in ths:
            t.start()
        for t in ths:
            t.join()
    try:
        with open(cpath, "w", encoding="utf-8") as f:
            json.dump(cache, f)
    except OSError:
        pass
    allow_picked([x["info"]["path"] for x in out])
    if not out and errors:
        raise RuntimeError(errors[0])
    return {"items": out, "errors": len(errors), "first": errors[0] if errors else None}


def job_ai_build(job, data):
    """Tutto quello che manca (immagini, voci) e poi il progetto montato nell'editor."""
    sid = data.get("story")
    st = SD.get_story(sid)
    page = SD.get_page(st["page"])
    if any(not (s.get("image") or {}).get("file") and not SD.joined(st["scenes"], k) for k, s in enumerate(st["scenes"])):
        job.message = "Creo le immagini che mancano"
        r = SD.gen_images(sid, None, progress=_prog(job, 0.02, 0.4), cancel=lambda: job.cancelled)
        if r.get("errors"):
            raise RuntimeError(f"{r['errors']} immagini non riuscite: {r.get('first')}")
    st = SD.get_story(sid)
    own = st.get("ownVoice") or {}
    if own.get("file") and own.get("texts") != [x["text"] for x in st["scenes"]]:
        raise RuntimeError("Hai cambiato lo script dopo aver caricato la registrazione: caricala di nuovo nel passaggio Voce")
    if not own.get("file") and any(not (s.get("audio") or {}).get("file") or s["audio"].get("text") != s["text"] for s in st["scenes"]):
        job.message = "Creo le voci che mancano"
        r = SD.gen_voices(sid, None, progress=_prog(job, 0.4, 0.55), cancel=lambda: job.cancelled)
        if r.get("errors"):
            raise RuntimeError(f"{r['errors']} voci non riuscite: {r.get('first')}")
    st = SD.get_story(sid)
    if any(x.get("kind") in SD.AI_KINDS and not SD.joined(st["scenes"], k) and not SD._video_ok(x, st) for k, x in enumerate(st["scenes"])) and AI.keys_status()["fal"]["set"]:
        job.message = "Creo i video che mancano"
        r = SD.gen_videos(sid, None, progress=_prog(job, 0.55, 0.66), cancel=lambda: job.cancelled)
        if r.get("errors"):
            raise RuntimeError(f"{r['errors']} video non riusciti: {r.get('first')}")
    if job.cancelled:
        raise R.Cancelled()
    st = SD.get_story(sid)
    job.message = "Unisco le voci"
    job.progress = 0.68
    if own.get("file") and os.path.isfile(own["file"]):
        jv = {"voice": own["file"], "times": own.get("times"), "words": own.get("words")}
    else:
        jv = SD.join_voices(st)
    if not jv:
        raise RuntimeError("Mancano delle voci")
    ed = page.get("edit") or {}
    names = [c["name"] for c in page.get("characters") or []]
    colors = {}
    palette = ["#FFFFFF", "#FFD60A", "#6CB2FF", "#FF7AB6", "#7CF29A", "#FFA94D"]
    for k, n in enumerate(["", *names]):
        colors[n.upper() if n else ""] = palette[k % len(palette)]
    scs_ = st["scenes"]
    lead_ = [SD.group_of(scs_, k)[0] for k in range(len(scs_))]
    lines = [{"speaker": (s.get("speaker") or "").upper(), "text": s["text"], **({"join": True} if SD.joined(scs_, k) else {})} for k, s in enumerate(scs_)]
    payload = {"name": st.get("title") or "Storia AI", "lines": lines, "images": [(scs_[lead_[k]].get("image") or {}).get("file") for k in range(len(scs_))],
               "motions": [scs_[lead_[k]].get("motion") or "zoomIn" for k in range(len(scs_))], "colors": colors, "voice": jv["voice"],
               "videos": [(x.get("video") or {}).get("file") if x.get("kind") in SD.AI_KINDS and not SD.joined(scs_, k) and SD._video_ok(x, st) else None for k, x in enumerate(scs_)],
               "words": jv["words"], "times": jv["times"], "exact": True, "format": "9:16",
               "captions": ed.get("captions") if ed.get("captions") in ("word", "line") else "word",
               "music": {**(ed.get("music") or {}), "vol": ed.get("musicVol") or 22} if ed.get("music") else None, "aiStory": sid}
    job.progress = 0.72
    res = job_story(job, payload)
    with SD._lock(sid):
        st = SD.get_story(sid)
        st["project"] = res["project"]
        st["status"] = "montata"
        SD.save_story(st)
    # la pagina ricorda le storie fatte (per non ripeterle)
    try:
        pg = SD.get_page(st["page"])
        hist = (pg.get("history") or []) + [{"title": st.get("title"), "at": time.time(), "story": sid}]
        pg["history"] = hist[-200:]
        SD._write(SD._page_path(pg["id"]), pg)
    except Exception:
        pass
    ACC.track("ai.build", {"scenes": len(st["scenes"])})
    return res


SUB_VERT = {"size": 0.034, "y": 0.74, "maxChars": 22}


def set_format(proj, fmt):
    """Orizzontale <-> verticale: i sottotitoli si adattano (ognuno dei due formati ricorda il suo stile)."""
    old = proj.get("format") or "16:9"
    if old == fmt:
        return
    st = proj.get("subStyle") or {}
    proj["subStyle_" + old.replace(":", "x")] = {k: st.get(k) for k in ("size", "y", "maxChars") if st.get(k) is not None}
    saved = proj.get("subStyle_" + fmt.replace(":", "x"))
    base = saved if saved else (SUB_VERT if fmt == "9:16" else {"size": 0.055, "y": 0.92, "maxChars": 38})
    proj["subStyle"] = dict(st, **base)
    proj["format"] = fmt


def create_vertical(pid, ranges, name):
    """Clip verticale dal VOD: una copia del progetto che mostra solo i pezzi scelti (anche lontani tra loro,
    uno dopo l'altro); il resto e' tolto dalla timeline. Da qui in poi e' indipendente dal VOD."""
    ACC.track("project.vertical")
    import copy
    src = P.load(pid)
    if src.get("parent") and not src.get("timeline"):
        raise ValueError("Questa e' gia' una clip verticale")
    D = float(src["duration"])
    rs = sorted([max(0.0, float(a)), min(D, float(b))] for a, b in ranges if float(b) - float(a) > 0.05)
    merged = []
    for a, b in rs:
        if merged and a <= merged[-1][1] + 1e-6:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    if not merged or sum(b - a for a, b in merged) < 0.5:
        raise ValueError("La clip e' troppo corta")
    ch = copy.deepcopy(src)
    ch["id"] = pid + "_v" + secrets.token_hex(3)
    ch["name"] = (name or "Clip verticale").strip()[:120] or "Clip verticale"
    ch["parent"] = pid
    ch["parentName"] = src.get("name")
    ch["ranges"] = merged
    ch["range"] = [merged[0][0], merged[-1][1]]
    ch["created"] = time.time()
    ch["lastExport"] = None
    ch["stage"] = "editor"
    for k in ("verticals", "timelines", "timeline", "startWith", "tlName"):
        ch.pop(k, None)
    set_format(ch, "9:16")
    ch["vert"] = dict(VT.DEFAULT, **(src.get("vert") or {}))
    eps = 1e-6
    segs = P.split_segs_at(ch.get("segs") or [], [x for r in merged for x in r])
    inr = lambda x0, x1: any(x0 >= a - eps and x1 <= b + eps for a, b in merged)
    for c in segs:
        if not inr(c["a"], c["b"]):
            c["removed"] = True
            c["gone"] = True
    ch["segs"] = segs
    inside = lambda x0, x1: any(x1 > a + eps and x0 < b - eps for a, b in merged)
    ch["zooms"] = [z for z in ch.get("zooms") or [] if inside(z["a"], z["b"])]
    ch["filters"] = [f for f in ch.get("filters") or [] if inside(f["a"], f["b"])]
    for t in ch.get("tracks") or []:
        if t.get("type") in ("overlay", "sound"):
            t["clips"] = [c for c in t.get("clips") or [] if inside(c["a"], c["a"] + float(c.get("dur") or 0))]
    P.save(ch)
    return {"id": ch["id"], "name": ch["name"], "a": merged[0][0], "b": merged[-1][1], "ranges": merged,
            "dur": round(sum(b - a for a, b in merged), 2)}


CLIP_PREV_DIR = os.path.join(IMPORTS_DIR, "anteprime-clip")
# sottotitoli delle clip: grandi, poche parole alla volta, parola evidenziata (come Opus)
CLIP_SUBS = {"captions": {"on": True, "mode": "poche", "position": "centro", "font": "Montserrat", "upper": True, "color": "#FFFFFF",
                          "highlight": "#FFD60A", "effect": "pop", "box": False, "stroke": True, "size": "grandi"}}


CLIP_SUB_POS = {"cam": "Sotto la cam", "centro": "Al centro", "basso": "In basso"}


def talk_scores(proj, spans):
    """Per ogni pezzo (a, b): quanto si muove la bocca dello streamer nella webcam rispetto al resto della faccia.
    Serve a capire chi parla: se a parlare e' lo streamer la bocca si muove; se e' il gioco o un video in reaction no.
    Ritorna [punteggio o None] (None = faccia non trovata)."""
    cam = (proj.get("webcam") or {}).get("box")
    out = [None] * len(spans)
    if not cam or not spans:
        return out
    try:
        import cv2
        det = FACE.detector()
    except Exception:
        return out
    PW, PH = float(proj.get("width") or 1920), float(proj.get("height") or 1080)
    pcs = P.pieces(proj)
    caps = {}
    x, y, w, h = cam
    try:
        for i, (a, b) in enumerate(spans):
            pc = P.piece_at(proj, (a + b) / 2, pcs)
            if not pc["live"]:
                continue
            cap = caps.get(pc["file"])
            if cap is None:
                cap = caps[pc["file"]] = cv2.VideoCapture(pc["file"])
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            step = max(1, int(round(fps / 6)))
            cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, pc["off"] + a - pc["t0"]) * 1000)
            box, prev, dm, de = None, None, [], []
            n = int(min(b - a, 3.0) * 6)
            for k in range(n):
                for _ in range(step - 1):
                    cap.grab()
                ok, fr = cap.read()
                if not ok or fr is None:
                    break
                fh, fw = fr.shape[:2]
                kx, ky = fw / PW, fh / PH
                x0, y0 = int(max(0, (x - w * 0.15) * kx)), int(max(0, (y - h * 0.15) * ky))
                x1, y1 = int(min(fw, (x + w * 1.15) * kx)), int(min(fh, (y + h * 1.15) * ky))
                crop = fr[y0:y1, x0:x1]
                if crop.size == 0:
                    break
                if crop.shape[1] < 320:
                    kk = 320 / crop.shape[1]
                    crop = cv2.resize(crop, (320, max(8, int(crop.shape[0] * kk))), interpolation=cv2.INTER_CUBIC)
                if box is None:
                    fs = [f for f in det.faces(crop) if f[2] >= crop.shape[1] * 0.07]
                    if not fs:
                        if k >= 3:
                            break
                        continue
                    box = [int(v) for v in fs[0]]
                bx, by, bw, bh = box
                face = crop[max(0, by):by + bh, max(0, bx):bx + bw]
                if face.size == 0:
                    break
                g = cv2.cvtColor(cv2.resize(face, (64, 64), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY).astype(np.float32)
                g = cv2.GaussianBlur(g, (3, 3), 0)
                if prev is not None:
                    d = np.abs(g - prev)
                    dm.append(float(d[42:60, 16:48].mean()))   # bocca
                    de.append(float(d[14:30, 8:56].mean()))    # occhi e fronte: muovere la testa non e' parlare
                prev = g
            if len(dm) >= 4:
                m, e = float(np.mean(dm)), float(np.mean(de))
                out[i] = round(m / (e + 1.5) if m >= 2.0 else 0.0, 3)
    except Exception as e:
        print("[zoom] controllo di chi parla non riuscito:", e, flush=True)
    finally:
        for c in caps.values():
            c.release()
    return out


TALK_MIN = 1.3   # bocca che si muove almeno il 30% piu' del resto della faccia: sta parlando lo streamer


def _clip_zooms(proj, ch, ca, cb, rgs, lev, words, dur, has_hook):
    """Zoom sulla webcam della clip, con lo swoosh: sui picchi (urla, risate) e nei momenti in cui parla lo streamer,
    mai quando la webcam e' vuota o quando a parlare e' il gioco / il video della reaction."""
    from engine import live as LIVE
    ch["zooms"] = [z for z in ch.get("zooms") or [] if not z.get("ai")]
    zt = ((ch.get("zoomTracks") or [{"id": "zoom"}])[0]).get("id") or "zoom"
    start = rgs[0][0] if rgs else ca
    he = start + 0.05 + (3.25 if has_hook else 0)
    clip_len = sum(y - x for x, y in rgs) or (cb - ca)
    want = max(1, min(3, int(clip_len // 12)))
    med_, _ = LIVE.level_stats(lev, LIVE.speech_mask(words, dur))
    seg = lev[int(ca):int(cb) + 1]
    pk = [int(ca) + p_ + 0.5 for p_ in LIVE.peaks(seg, med_, 5)]
    pk = sorted(pk, key=lambda t: -float(lev[min(len(lev) - 1, int(t))]))[:3]
    grid = [t for t in np.arange(he + 1.2, cb - 2.5, 6.0)]
    cands = []
    for kind, t in [("peak", t) for t in pk] + [("talk", float(t)) for t in grid]:
        za, zb = round(max(ca + 0.5, t - 0.9), 2), round(min(cb, t + 2.6), 2)
        if zb - za < 1.8 or za < he or not any(x <= za and zb <= y for x, y in rgs):
            continue
        if not any(w["a"] < zb and za < w["b"] for w in words):   # nessuno parla: niente zoom
            continue
        cands.append((kind, za, zb))
    if not cands:
        return
    faces = cam_face_ok(proj, [(a, b) for _, a, b in cands])
    talk = talk_scores(proj, [(a, b) for _, a, b in cands])
    scored = []
    for (kind, za, zb), fok, ts in zip(cands, faces, talk):
        if not fok or ts is None:
            continue
        # sui picchi basta che la bocca si muova un po' (urlo, risata); altrimenti deve proprio parlare lo streamer
        if ts < (TALK_MIN * 0.8 if kind == "peak" else TALK_MIN):
            continue
        scored.append(((1 if kind == "peak" else 0), ts, za, zb))
    print("[zoom] clip %.0f-%.0f: %d candidati, %d con lo streamer che parla" % (ca, cb, len(cands), len(scored)), flush=True)
    picked = []
    for _, ts, za, zb in sorted(scored, key=lambda x: (-x[0], -x[1])):
        if len(picked) >= want:
            break
        if all(zb + 3.0 <= a or b + 3.0 <= za for a, b in picked):
            picked.append((za, zb))
    for za, zb in picked:
        if not any(z.get("a", 0) < zb and za < z.get("b", 0) for z in ch["zooms"]):
            ch["zooms"].append({"id": "z" + secrets.token_hex(4), "track": zt, "a": za, "b": zb, "on": True,
                                "level": 2.0, "in": "punch", "out": "cut", "ai": True})
    ch["zooms"] = _hook_zooms(sorted(ch["zooms"], key=lambda z: z["a"]), start, 3.25 if has_hook else 0)
    # swoosh profondo e leggero all'inizio di ogni zoom
    st_ = next((t_ for t_ in ch.get("tracks") or [] if t_.get("type") == "sound" and t_.get("name") == "Effetti"), None)
    if st_ is not None:
        st_["clips"] = [x for x in st_["clips"] if not x.get("ai")]
    snd = _sfx_file("zoom")
    if snd and any(z.get("ai") for z in ch["zooms"]):
        if st_ is None:
            st_ = {"id": "t" + secrets.token_hex(4), "name": "Effetti", "type": "sound", "vol": 70, "mute": False, "color": "#F2A65A", "clips": []}
            ch.setdefault("tracks", []).append(st_)
        for z in ch["zooms"]:
            if z.get("ai"):
                a_ = round(max(0.0, z["a"] - 0.16), 2)
                st_["clips"].append({"id": "s" + secrets.token_hex(4), "file": snd["path"], "name": "zoom", "a": a_,
                                     "dur": round(snd["duration"], 2), "offset": 0, "fileDur": snd["duration"], "vol": 60, "mute": False, "ai": True})


def _clip_rezoom(cid):
    """Clip fatte prima: rifa' gli zoom con le regole nuove (prima dell'anteprima)."""
    ch = P.load(cid)
    meta = ch.get("clip") or {}
    src_id = ch.get("parent")
    if not src_id or ch.get("clipEdited"):
        return
    src = P.load(src_id)
    cam = (ch.get("webcam") or {}).get("box")
    if cam and (ch.get("vert") or {}).get("layout") == "split":
        from engine import live as LIVE
        try:
            db = np.load(db_path(src_id))
        except Exception:
            db = np.full(int(float(src["duration"]) / A.HOP) + 1, -40.0, np.float32)
        dur = float(src["duration"])
        rs = ch.get("ranges") or [[0, 0]]
        has_hook = any(c.get("hook") for t in ch.get("tracks") or [] for c in t.get("clips") or [])
        _clip_zooms(src, ch, float(rs[0][0]), float(rs[-1][1]), [list(r) for r in rs], LIVE.sec_levels(db, dur), _clip_words(src), dur, has_hook)
        for t_ in ch.get("tracks") or []:
            for c_ in t_.get("clips") or []:
                if c_.get("hook") and (c_.get("pos") or {}).get("auto"):
                    c_["pos"]["y"] = _hook_y(ch, float(c_.get("a", 0)), float(c_.get("dur") or 3.2))
    meta["zv"] = 3
    meta.pop("zneed", None)
    with LOCK:
        cur = P.load(cid)
        for k_ in ("zooms", "tracks"):
            if k_ in ch:
                cur[k_] = ch[k_]
        cur["clip"] = meta
        P.save(cur)


def _clips_lang(job, src, made):
    """Lingua dei sottotitoli scelta per le clip diversa da quella della trascrizione della live
    (es. la live e' stata trascritta in inglese per sbaglio): ogni clip nuova si ritrascrive nella lingua giusta."""
    lang = src.get("subLang")
    tl = ((src.get("transcript") or {}).get("language") or "").lower()
    if not lang or lang not in SUB_LANGS or not tl or tl == lang or not made or not T.available():
        return
    n = len(made)
    for i, r in enumerate(made):
        if job.cancelled:
            return
        job.message = f"Sottotitoli in {SUB_LANGS[lang]} ({i + 1} di {n})"
        try:
            with LOCK:
                c2 = P.load(r["id"])
                c2["subLang"] = lang
                P.save(c2)
            rs = c2.get("ranges") or [[0, 0]]

            class _Sub:
                cancelled = False

                def __setattr__(self, k, v):
                    if k == "progress":
                        job.progress = min(0.995, 0.97 + (i + float(v)) / n * 0.025)
                    elif k == "cancelled":
                        object.__setattr__(self, k, v)
            job_transcribe_range(_Sub(), r["id"], float(rs[0][0]), float(rs[-1][1]))
        except Exception as e:
            print("[clip] sottotitoli nella lingua scelta non riusciti:", str(e)[:200], flush=True)


def _hook_zooms(zooms, start, hook_dur):
    """Niente zoom che parte a meta' della scritta d'apertura (il titolo cambierebbe posto mentre lo leggi):
    se lo zoom e' nei primi secondi parte subito dal primo fotogramma, con taglio netto, e copre tutta la scritta;
    se parte piu' tardi aspetta che la scritta sia finita (o si toglie se poi resterebbe troppo corto)."""
    if hook_dur <= 0:
        return zooms
    he = start + 0.05 + hook_dur
    out = []
    for z in zooms:
        if not z.get("ai") or z.get("b", 0) <= start or z.get("a", 0) >= he:
            out.append(z)
            continue
        z = dict(z)
        if z["a"] <= start + 1.6:
            z["a"], z["in"] = round(start, 2), "cut"
            z["b"] = round(max(z["b"], he + 0.4), 2)
        elif z["b"] - he >= 1.4:
            z["a"] = round(he, 2)
        else:
            continue
        if not any(o.get("a", 0) < z["b"] and z["a"] < o.get("b", 0) for o in out):
            out.append(z)
    return sorted(out, key=lambda z: z["a"])


def _hook_y(ch, a, dur):
    """Scritta d'apertura: in alto quando si vede solo la webcam (zoom sulla cam o impaginazione solo cam),
    sulla linea tra cam e gioco quando sono uno sopra l'altro."""
    b = a + dur
    lay = (ch.get("vert") or {}).get("layout") or "split"
    zoomed = any(z.get("on", True) and z.get("a", 0) < b and a < z.get("b", 0) for z in ch.get("zooms") or [])
    return 0.33 if lay == "split" and not zoomed else 0.07


def clip_sub_style(cam_h=0.4, has_cam=True, cs=None, fullcam=False):
    """Sottotitoli delle clip con le scelte della galleria (posizione, font, colori): pop, poche parole per volta."""
    cs = cs if cs is not None else (load_settings().get("clipSubs") or {})
    st = AE.subs_patch(CLIP_SUBS, True)
    st["maxChars"] = 14 if (cs.get("words") or "poche") == "poche" else 9 if cs.get("words") == "parola" else 22   # 2-3 parole alla volta
    st["effect"] = cs.get("effect") or "pop"
    pos = cs.get("pos") or "cam"
    if pos == "cam" and not has_cam:
        pos = "centro"
    st["y"] = round(min(0.86, float(cam_h) + 0.12), 3) if pos == "cam" else 0.62 if pos == "centro" else 0.8
    for k in ("font", "color", "hiColor"):
        if cs.get(k):
            st[k] = str(cs[k])[:40]
    if str(st.get("hiColor") or "").upper() == "#3DDC84":
        st["hiColor"] = "#FFD60A"     # il verde era il vecchio colore di base: ora parte giallo
    for k in ("upper", "box", "stroke"):
        if k in cs:
            st[k] = bool(cs[k])
    if cs.get("size") in ("medi", "grandi"):
        st["size"] = 0.04 if cs["size"] == "medi" else 0.052
    st["shadow"] = not st.get("box")
    st["hookHide"] = True   # mentre c'e' il titolo d'apertura niente sottotitoli
    st["popHi"] = True      # la parola che si sta dicendo prende il colore scelto (come nell'anteprima della galleria)
    st.pop("auto", None)
    if pos == "cam":
        # attaccati sotto la webcam (pochi px), sotto il titolo finche' c'e', in basso durante gli zoom sulla faccia
        base = round(min(0.86, float(cam_h) + float(st.get("size", 0.052)) * 1.25 + 0.012), 4)
        st["auto"] = {"base": base, "zoom": 0.8}
        st["y"] = base
    elif fullcam and (cs.get("pos") or "cam") == "cam":
        st["y"] = 0.8   # scena solo cam: la faccia riempie lo schermo, i sottotitoli vanno sotto
    return st


def _clip_words(proj):
    return [w for w in AE.words_of(proj)]


def _ensure_transcript(job, pid, a=0.0, b=0.2):
    """La ricerca delle clip legge le parole: se la live non e' ancora trascritta si trascrive prima (in locale se si puo')."""
    proj = P.load(pid)
    tr = proj.get("transcript") or {}
    if tr.get("status") == "done" and tr.get("segments"):
        return
    use_ai = not T.available()
    if use_ai and not AI.cloud_transcriber():
        raise RuntimeError("Per trovare le clip serve la trascrizione: installala (INSTALLA.bat) o aggiungi una chiave OpenAI/ElevenLabs")
    with LOCK:
        proj = P.load(pid)
        proj["transcript"] = {"status": "running", "segments": []}
        P.save(proj)
    try:
        job_transcribe(_SubJob(job, a, b), pid, use_ai)
    except Exception:
        if job.cancelled:
            raise RuntimeError("Annullato")
        raise


class _SubJob:
    """Un lavoro dentro un altro: avanzamento e messaggi finiscono nella barra di quello grande."""
    def __init__(self, parent, a, b):
        object.__setattr__(self, "_p", parent)
        object.__setattr__(self, "_ab", (a, b))
        object.__setattr__(self, "log", parent.log)

    @property
    def cancelled(self):
        return self._p.cancelled

    def __getattr__(self, k):
        return getattr(self._p, k)

    def __setattr__(self, k, v):
        if k == "progress":
            a, b = self._ab
            self._p.progress = a + (b - a) * float(v or 0)
        elif k == "message":
            self._p.message = v
        elif k != "cancelled":
            object.__setattr__(self, k, v)


def _sfx_file(name):
    """Un effetto sonoro incluso in NoonFrame (web/sfx), copiato tra gli importati: {path, duration} o None."""
    import shutil
    src = os.path.join(WEB, "sfx", name + ".wav")
    if not os.path.isfile(src):
        return None
    dst = os.path.join(IMPORTS_DIR, "effetti-sonori")
    os.makedirs(dst, exist_ok=True)
    to = os.path.join(dst, name + ".wav")
    try:
        if not os.path.isfile(to) or os.path.getsize(to) != os.path.getsize(src):
            shutil.copyfile(src, to)
        mi = media_info(to)
        allow_picked([to])
        return {"path": to, "duration": float(mi.get("duration") or 0.55)}
    except Exception as e:
        print("[clip] effetto sonoro non disponibile:", e, flush=True)
        return None


def job_clips(job, pid, prompt="", replace=True):
    """Clip verticali virali dalla live (stile Opus): l'AI trova i momenti, ognuno diventa una clip verticale gia' montata
    (webcam sopra e gioco sotto, sottotitoli grandi, silenzi tolti, scritta d'apertura) con punteggio, titolo e motivo."""
    from engine import live as LIVE
    src = P.load(pid)
    if src.get("parent") and not src.get("timeline"):
        raise RuntimeError("Questa e' gia' una clip: apri il video della live per cercare le clip")
    ACC.track("ai.clips")
    job.message = "Leggo la live"
    job.progress = 0.02
    _ensure_transcript(job, pid, 0.02, 0.35)
    proj = P.load(pid)
    cfg = _text_cfg()
    try:
        db = np.load(db_path(pid))
    except Exception:
        db = np.full(int(float(proj["duration"]) / A.HOP) + 1, -40.0, np.float32)
    words = _clip_words(proj)
    res = LIVE.find_clips(proj, db, cfg, cancel=lambda: job.cancelled, progress=_prog(job, 0.36, 0.85), words=words, prompt=prompt)
    if not res["clips"]:
        raise RuntimeError("Non ho trovato momenti abbastanza forti per una clip. Prova con una live piu' lunga o scrivi cosa cercare")
    job.message = "Monto le clip"
    dur = float(proj["duration"])
    lev = LIVE.sec_levels(db, dur)
    # le clip dell'AI di prima che non hai toccato vengono sostituite; quelle che hai modificato restano
    old = [v for v in (proj.get("verticals") or []) if v.get("clip")]
    gone = []
    if replace:
        for v in old:
            try:
                ch = P.load(v["id"])
            except Exception:
                gone.append(v["id"])
                continue
            pv_ = ch.get("clipPreview") or {}
            if not ch.get("clipEdited") and not (pv_.get("at") and ch.get("updated", 0) > pv_["at"] + 3):
                gone.append(v["id"])
    made = []
    # le clip che restano (modificate da te) non si ripetono: niente doppioni dello stesso momento
    kept_old = [(float((v.get("ranges") or [[v.get("a", 0), v.get("b", 0)]])[0][0]), float((v.get("ranges") or [[0, v.get("b", 0)]])[-1][1]))
                for v in old if v["id"] not in gone]
    res["clips"] = [c for c in res["clips"] if not any(min(c["b"], y) - max(c["a"], x) > 0.5 * min(c["b"] - c["a"], y - x) for x, y in kept_old)]
    for n, c in enumerate(res["clips"]):
        if job.cancelled:
            raise RuntimeError("Annullato")
        job.progress = 0.86 + 0.12 * n / len(res["clips"])
        # i silenzi senza azione dentro la clip vanno via: le clip devono correre
        rgs = []
        for gap in (1.5, 3.0, None):
            rgs, t = [], c["a"]
            for x, y in (LIVE.dead_air(words, lev, c["a"], c["b"], gap) if gap else []):
                if x - t > 0.4:
                    rgs.append([t, x])
                t = y
            if c["b"] - t > 0.4:
                rgs.append([t, c["b"]])
            if sum(y - x for x, y in rgs) >= 12:   # mai clip troppo corte per colpa dei silenzi tolti
                break
        try:
            r = create_vertical(pid, rgs, c["title"])
        except ValueError:
            continue
        fullx = clip_fullcam(proj, c["a"], c["b"]) if (proj.get("webcam") or {}).get("box") else None
        with LOCK:
            ch = P.load(r["id"])
            ch["clip"] = {"score": c["score"], "title": c["title"], "why": c["why"], "hook": c["hook"], "k": c.get("k"),
                          "src": [c["a"], c["b"]], "at": time.time(), "rank": n}
            cam = (ch.get("webcam") or {}).get("box")
            ch["vert"] = dict(VT.DEFAULT, **(src.get("vert") or {}), layout="split" if cam else "fit")
            if fullx is not None:
                # scena "solo cam" (la webcam a tutto schermo nella live): niente riquadro cam + gioco,
                # si inquadra la persona a tutto schermo e niente zoom sul riquadro della webcam (sarebbe vuoto)
                ch["vert"].update(layout="game", gameX=round(fullx, 3))
                ch["clip"]["fullcam"] = True
                ch["clip"]["fcv"] = 2
                cam = None
            ns_ = clip_sub_style(ch["vert"].get("camH", 0.4), bool(cam), None, fullx is not None)
            ch["subStyle"] = {k_: v_ for k_, v_ in dict(ch.get("subStyle") or {}, **ns_).items() if k_ != "auto" or "auto" in ns_}
            ch.setdefault("settings", {})["showSubs"] = True
            # gli zoom automatici della live non passano nella clip: restano solo quelli scelti qui (e quelli messi a mano)
            ch["zooms"] = [z for z in ch.get("zooms") or [] if not z.get("auto") and not z.get("ai")]
            # e nemmeno scritte, grafiche ed effetti del montaggio AI del video lungo (la clip ha i suoi)
            for t_ in ch.get("tracks") or []:
                if t_.get("type") in ("overlay", "sound"):
                    t_["clips"] = [x for x in t_.get("clips") or [] if not x.get("ai")]
            # zoom sulla webcam (con swoosh) quando e' lo streamer a parlare o a reagire forte
            if cam:
                _clip_zooms(proj, ch, c["a"], c["b"], rgs, lev, words, dur, bool(c.get("hook")))
            ch["clip"]["zv"] = 3
            # scritta d'apertura: il testo lo disegna l'app (stesso look dei titoli dell'editor) quando apri le clip
            if c.get("hook"):
                tr_ = next((t_ for t_ in ch.get("tracks") or [] if t_.get("type") == "overlay"), None)
                if tr_ is None:
                    tr_ = {"id": "t" + secrets.token_hex(4), "name": "Testi", "type": "overlay", "clips": []}
                    ch.setdefault("tracks", []).append(tr_)
                    ch["layers"] = ["ov:" + tr_["id"]] + [x for x in (ch.get("layers") or []) if x != "ov:" + tr_["id"]]
                tr_["clips"].append({"id": "c" + secrets.token_hex(4), "kind": "image", "isText": True, "hook": True,
                                     "text": {"content": c["hook"]}, "name": c["hook"][:40], "a": round(rgs[0][0] + 0.05, 2),
                                     "dur": 3.2, "opacity": 100, "pos": {"x": 0.07, "y": _hook_y(ch, rgs[0][0] + 0.05, 3.2), "w": 0.86, "auto": True}})
            P.save(ch)
        r["clip"] = ch["clip"]
        made.append(r)
    with LOCK:
        cur = P.load(pid)
        keep_ = [v for v in (cur.get("verticals") or []) if v.get("id") not in gone]
        cur["verticals"] = keep_ + made
        cur["clipsRun"] = {"at": time.time(), "usd": res["usd"], "found": len(made), "target": res["target"]}
        P.save(cur)
    _clips_lang(job, src, made)
    for g in gone:
        try:
            pv = (P.load(g).get("clipPreview") or {})
            for f_ in (pv.get("file"), pv.get("poster")):
                if f_ and os.path.dirname(os.path.abspath(f_)) == os.path.abspath(CLIP_PREV_DIR):
                    os.remove(f_)
            P.delete(g)
        except Exception:
            pass
    ACC.track("ai.clips.done", {"n": len(made), "text": cfg["provider"]})
    return {"clips": made, "usd": res["usd"], "target": res["target"]}


def _clip_migrate(src, ch):
    """Clip fatte con le versioni di prima: niente sottotitoli sotto il titolo d'apertura, e il controllo
    "solo cam" rifatto (la 1.5.145 scambiava per solo cam scene normali con facce nel gioco)."""
    meta = ch.get("clip") or {}
    st = ch.get("subStyle") or {}
    changed = False
    if meta.get("fullcam") and meta.get("fcv") != 2 and not ch.get("clipEdited"):
        rs = ch.get("ranges") or [[0, 0]]
        fx = clip_fullcam(src, float(rs[0][0]), float(rs[-1][1]))
        meta["fcv"] = 2
        if fx is None:
            cam = (ch.get("webcam") or {}).get("box")
            ch["vert"] = dict(ch.get("vert") or {}, layout="split" if cam else "fit")
            ch["vert"].pop("gameX", None)
            meta["fullcam"] = False
            ns_ = clip_sub_style((ch["vert"] or {}).get("camH", 0.4), bool(cam))
            st = {k_: v_ for k_, v_ in dict(st, **ns_).items() if k_ != "auto" or "auto" in ns_}
            for t_ in ch.get("tracks") or []:   # la scritta d'apertura torna sulla linea tra cam e gioco
                for c_ in t_.get("clips") or []:
                    if c_.get("hook") and (c_.get("pos") or {}).get("auto"):
                        c_["pos"]["y"] = _hook_y(ch, float(c_.get("a", 0)), float(c_.get("dur") or 3.2))
        else:
            ch["vert"] = dict(ch.get("vert") or {}, layout="game", gameX=round(fx, 3))
        ch["clip"] = meta
        changed = True
    if "hookHide" not in st or "popHi" not in st:
        st["hookHide"] = True
        st["popHi"] = True
        changed = True
    if meta.get("zv") != 3 and not meta.get("zneed") and not ch.get("clipEdited"):
        meta["zneed"] = True      # gli zoom si rifanno prima della prossima anteprima
        ch["clip"] = meta
        changed = True
    if changed:
        ch["subStyle"] = st
        ch.pop("clipPreview", None)   # anteprima da rifare
        with LOCK:
            cur = P.load(ch["id"])
            for k_ in ("clip", "vert", "subStyle", "tracks"):
                if k_ in ch:
                    cur[k_] = ch[k_]
            cur.pop("clipPreview", None)
            P.save(cur)
            ch = cur
    return ch


def clip_list(pid):
    """Le clip verticali della live con punteggio, motivo e stato dell'anteprima (per la galleria)."""
    proj = P.load(pid)
    out = []
    langs_ = {}   # lingua vera dei sottotitoli delle clip (per il menu della lingua)
    for v in proj.get("verticals") or []:
        try:
            ch = P.load(v["id"])
            if ch.get("clip"):
                ch = _clip_migrate(proj, ch)
            lg_ = ch.get("subLang") or (ch.get("transcript") or {}).get("language")
            if lg_:
                langs_[lg_] = langs_.get(lg_, 0) + 1
        except Exception:
            continue
        rs = ch.get("ranges") or [[v.get("a", 0), v.get("b", 0)]]
        keep = [(a, b) for a, b in P.keep_segments(ch)]
        dur = sum(max(0.0, min(b, B) - max(a, A_)) for a, b in keep for A_, B in rs)
        pv = ch.get("clipPreview") or {}
        ok = bool(pv.get("file") and os.path.exists(pv["file"]))
        meta = ch.get("clip") or {}
        out.append({"id": ch["id"], "name": ch.get("name"), "a": rs[0][0], "b": rs[-1][1], "dur": round(dur, 2),
                    "score": meta.get("score"), "why": meta.get("why"), "hook": meta.get("hook"), "k": meta.get("k"), "ai": bool(meta),
                    "edited": bool(ch.get("clipEdited")) or (ok and ch.get("updated", 0) > pv.get("at", 0) + 3),
                    "preview": pv.get("file") if ok else None, "poster": pv.get("poster") if ok and pv.get("poster") and os.path.exists(pv["poster"]) else None,
                    "previewAt": pv.get("at"), "updated": ch.get("updated"), "exported": bool(ch.get("lastExport")),
                    "needsBake": any((c.get("isText") and not (c.get("file") and os.path.exists(c["file"])))
                                     or (c.get("hook") and (c.get("text") or {}).get("font") and (c.get("text") or {}).get("v") != 2)
                                     for t in ch.get("tracks") or [] for c in t.get("clips") or [])})
    out.sort(key=lambda x: (x["score"] is None, -(x["score"] or 0), x["a"]))
    return {"clips": out, "run": proj.get("clipsRun"), "name": proj.get("name"), "duration": proj.get("duration"),
            "hasTranscript": (proj.get("transcript") or {}).get("status") == "done", "webcam": bool((proj.get("webcam") or {}).get("box")),
            "lang": (max(langs_, key=langs_.get) if langs_ else None) or proj.get("subLang") or (proj.get("transcript") or {}).get("language") or "it", "langs": SUB_LANGS,
            "clipSubs": load_settings().get("clipSubs") or {"pos": "cam"}}


def job_clip_previews(job, pid, ids):
    """Anteprime leggere (540p) delle clip per la galleria: lo stesso video dell'esportazione, piu' piccolo.
    Due alla volta (il montaggio verticale con lo zoom lavora un fotogramma alla volta su un solo core)."""
    import copy
    from concurrent.futures import ThreadPoolExecutor
    os.makedirs(CLIP_PREV_DIR, exist_ok=True)
    done, prog = [], {}
    ids = [c for c in ids if os.path.exists(P.path_for(c))]
    job.message = f"Preparo le anteprime (0/{len(ids)})"

    def one(cid):
        if job.cancelled:
            return
        ch = P.load(cid)
        if ch.get("parent") != pid:
            return
        if (ch.get("clip") or {}).get("zneed"):   # clip fatta prima: zoom rifatti con le regole nuove
            try:
                _clip_rezoom(cid)
            except Exception as e:
                print("[zoom] zoom non rifatti:", e, flush=True)
            ch = P.load(cid)
        pr = copy.deepcopy(ch)
        st = dict(pr.get("settings") or {})
        st.update(quality="540p", srt=False, chapters=False)
        st["export"] = dict(st.get("export") or {}, dir=CLIP_PREV_DIR, format="mp4", codec="h264", bitrate="low", fps="30", audio=True, abr=128)
        pr["settings"] = st
        pr["name"] = cid + "_" + secrets.token_hex(2)
        pr.pop("folder", None)

        def pg(x, m):
            prog[cid] = x
            job.progress = sum(prog.values()) / max(1, len(ids))
        try:
            r = R.render(pr, progress=pg, cancel=lambda: job.cancelled, log=lambda m: None)
        except R.Cancelled:
            return
        except Exception as e:
            print("[clip preview]", cid, e, flush=True)
            return
        poster = os.path.splitext(r["path"])[0] + ".jpg"
        subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", "0.6", "-i", r["path"], "-frames:v", "1", "-vf", "scale=360:-2", "-q:v", "4", poster],
                       capture_output=True, creationflags=NO_WINDOW)
        with LOCK:
            cur = P.load(cid)
            oldp = cur.get("clipPreview") or {}
            cur["clipPreview"] = {"file": r["path"], "poster": poster if os.path.exists(poster) else None, "at": time.time() + 1.0,
                                  "dur": r.get("duration")}
            P.save(cur)
            done.append(cid)
            job.message = f"Preparo le anteprime ({len(done)}/{len(ids)})"
        for f_ in (oldp.get("file"), oldp.get("poster")):
            if f_ and f_ not in (r["path"], poster) and os.path.dirname(os.path.abspath(f_)) == os.path.abspath(CLIP_PREV_DIR):
                try:
                    os.remove(f_)
                except OSError:
                    pass
    with ThreadPoolExecutor(max_workers=2) as ex:
        list(ex.map(one, ids))
    if job.cancelled:
        raise RuntimeError("Annullato")
    return {"done": done}


def fmt_of(proj):
    """Formato piu' vicino al video del progetto (per una timeline nuova uguale)."""
    f = proj.get("format")
    if f in FORMATS:
        return f
    w, h = float(proj.get("width") or 16), float(proj.get("height") or 9)
    r = w / max(1.0, h)
    return min(FORMATS, key=lambda k: abs(FORMATS[k][0] / FORMATS[k][1] - r))


def timeline_root(pid):
    p = P.load(pid)
    return p["parent"] if p.get("timeline") and p.get("parent") else pid


def list_timelines(pid):
    """Tutte le timeline del progetto: la principale e quelle aggiunte, in ordine."""
    rid = timeline_root(pid)
    root = P.load(rid)
    out = [{"id": rid, "name": root.get("tlName") or "Timeline 01", "main": True}]
    for tid in root.get("timelines") or []:
        try:
            t = P.load(tid)
        except Exception:
            continue
        out.append({"id": tid, "name": t.get("name") or "Timeline"})
    return out


def create_timeline(pid, name, asset=None):
    """Nuova timeline nello stesso progetto (come CapCut): stesso formato, stessi Media; se arriva un elemento
    (video o immagine), l'editor lo mette subito nella traccia principale."""
    ACC.track("project.timeline")
    rid = timeline_root(pid)
    with LOCK:
        root = P.load(rid)
        cur = P.load(pid)
    n = len(root.get("timelines") or []) + 2
    name = (name or "").strip()[:120] or f"Timeline {n:02d}"
    ch = create_blank(fmt_of(root), None, name)
    ch["parent"] = rid
    ch["parentName"] = root.get("name")
    ch["timeline"] = True
    ch["assets"] = [dict(a) for a in (cur.get("assets") or [])]
    if isinstance(asset, dict) and asset.get("path") and asset.get("kind") in ("video", "image"):
        ch["startWith"] = asset
    with LOCK:
        # il file del progetto nuovo ha un id libero: lo rinominiamo "<radice>_t..." per tenerlo vicino
        old = ch["id"]
        ch["id"] = rid + "_t" + secrets.token_hex(3)
        P.save(ch)
        try:
            os.remove(P.path_for(old))
        except OSError:
            pass
        root = P.load(rid)
        root["timelines"] = (root.get("timelines") or []) + [ch["id"]]
        P.save(root)
    return ch


def export_items(pid, want):
    """Cosa esportare: il progetto e/o le sue clip verticali e le altre timeline. -> [(progetto, cartella)] e la cartella che le contiene."""
    proj = P.load(pid)
    E = R.export_opts(proj)
    if isinstance(want.get("export"), dict):   # scelte fatte nella finestra di un'altra timeline
        E.update({k: v for k, v in want["export"].items() if k in R.EXPORT_DEFAULT or k == "dir"})
    base = E.get("dir") if E.get("dir") and os.path.isdir(E.get("dir")) else EXPORTS_DIR
    if proj.get("folder"):   # progetti nella stessa cartella della home: i video finiscono tutti nella stessa cartella
        base = os.path.join(base, PK.safe_name(proj["folder"]) or "Cartella")
        os.makedirs(base, exist_ok=True)
    tl_ids = set(proj.get("timelines") or [])
    ok_parents = {pid} | tl_ids
    subs = []
    seen = set()
    for vid in list(want.get("timelines") or []) + list(want.get("verticals") or []):
        if vid in seen or vid == pid:
            continue
        seen.add(vid)
        try:
            c = P.load(vid)
        except Exception:
            continue
        if c.get("parent") in ok_parents:
            subs.append(c)
    with_vod = bool(want.get("vod", True))
    safe = lambda n: re.sub(r'[\\/:*?"<>|]+', "_", n).strip(" .") or "video"
    only_vert = all(not c.get("timeline") for c in subs)
    folder = None
    if with_vod and subs:
        folder = R.unique_dir(base, safe(proj["name"]))
        items = [(proj, folder)] + [(c, folder if c.get("timeline") else os.path.join(folder, "Clip verticali")) for c in subs]
    elif not with_vod and len(subs) > 1:
        folder = R.unique_dir(base, safe(proj["name"]) + (" - Clip verticali" if only_vert else ""))
        items = [(c, folder if (only_vert or c.get("timeline")) else os.path.join(folder, "Clip verticali")) for c in subs]
    else:
        items = [(proj, base)] if with_vod else [(c, base) for c in subs]
    # tutto si esporta con le stesse impostazioni scelte qui (qualita', codec…); le timeline tengono il loro formato
    out = []
    for p_, d in items:
        q = dict(p_)
        q["settings"] = dict(p_.get("settings") or {})
        q["settings"]["export"] = dict(E, dir=d)
        q["settings"]["quality"] = want.get("quality") or (proj.get("settings") or {}).get("quality") or q["settings"].get("quality")
        out.append(q)
    return out, folder


def scene_kind(fr, cam, PW, PH, det):
    """Che scena e' questo fotogramma: ("full", x) = la webcam a tutto schermo (una faccia grande fuori dal riquadro
    della webcam; x = centro della faccia 0..1), ("normal", None) altrimenti."""
    import cv2
    fh, fw = fr.shape[:2]
    k = 640.0 / fw if fw > 640 else 1.0
    small = cv2.resize(fr, (int(fw * k), int(fh * k)), interpolation=cv2.INTER_AREA) if k < 1 else fr
    sw = small.shape[1]
    kx, ky = small.shape[1] / PW, small.shape[0] / PH
    x, y, w, h = cam
    bx0, by0, bx1, by1 = (x - w * 0.1) * kx, (y - h * 0.1) * ky, (x + w * 1.1) * kx, (y + h * 1.1) * ky
    faces = det.faces(small)[:4]
    cw = w * kx
    big = None
    for (fx, fy, fw_, fh_) in faces:
        cx, cy = fx + fw_ / 2, fy + fh_ / 2
        inside = bx0 <= cx <= bx1 and by0 <= cy <= by1
        if inside and fw_ <= cw * 0.75:
            # lo streamer e' nel suo riquadro: scena normale (anche se nel gioco ci sono altre facce grandi)
            return "normal", None
        if big is None and fw_ >= sw * 0.12:
            big = cx
    if big is None:
        return "normal", None
    # faccia grande e il riquadro della webcam non ha lo streamer: la cam e' a tutto schermo.
    # Doppio controllo sul riquadro ingrandito (una webcam piccola sfugge al primo giro)
    x0, y0 = int(max(0, (x - w * 0.15) * fw / PW)), int(max(0, (y - h * 0.15) * fh / PH))
    x1, y1 = int(min(fw, (x + w * 1.15) * fw / PW)), int(min(fh, (y + h * 1.15) * fh / PH))
    crop = fr[y0:y1, x0:x1]
    if crop.size:
        if crop.shape[1] < 320:
            kk = 320 / crop.shape[1]
            crop = cv2.resize(crop, (320, max(8, int(crop.shape[0] * kk))), interpolation=cv2.INTER_CUBIC)
        if any(cw_ >= crop.shape[1] * 0.07 and cw_ <= crop.shape[1] * 0.8 for _, _, cw_, _ in det.faces(crop)):
            return "normal", None
    return "full", max(0.0, min(1.0, big / sw))


def clip_fullcam(proj, a, b):
    """La clip e' (quasi tutta) una scena "solo cam"? Ritorna il centro della faccia (0..1) o None."""
    cam = (proj.get("webcam") or {}).get("box")
    if not cam:
        return None
    try:
        import cv2
        det = FACE.detector()
    except Exception:
        return None
    PW, PH = float(proj.get("width") or 1920), float(proj.get("height") or 1080)
    pcs = P.pieces(proj)
    caps, xs, n = {}, [], 0
    try:
        for f in (0.12, 0.3, 0.5, 0.7, 0.88):
            tt = a + (b - a) * f
            pc = P.piece_at(proj, tt, pcs)
            if not pc["live"]:
                continue
            cap = caps.get(pc["file"])
            if cap is None:
                cap = caps[pc["file"]] = cv2.VideoCapture(pc["file"])
            cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, pc["off"] + tt - pc["t0"]) * 1000)
            ok, fr = cap.read()
            if not ok or fr is None:
                continue
            n += 1
            kind, x = scene_kind(fr, cam, PW, PH, det)
            if kind == "full":
                xs.append(x)
    except Exception as e:
        print("[clip] controllo solo cam non riuscito:", e, flush=True)
        return None
    finally:
        for c in caps.values():
            c.release()
    if n and len(xs) >= max(3, n * 0.6):
        xs.sort()
        return xs[len(xs) // 2]
    return None


def cam_face_ok(proj, spans, cancel=None):
    """Per ogni pezzo (a, b) della timeline: c'e' una faccia dentro il riquadro della webcam?
    Gli zoom automatici vanno sulla webcam: se in quel momento la scena e' "solo cam" (la webcam a tutto schermo),
    un'altra scena o la webcam e' vuota, dentro il riquadro non c'e' nessuno e lo zoom inquadrerebbe il vuoto."""
    cam = (proj.get("webcam") or {}).get("box")
    out = [True] * len(spans)
    if not cam or not spans:
        return out
    try:
        import cv2
        det = FACE.detector()
    except Exception as e:
        print("[zoom] controllo del viso non disponibile:", e, flush=True)
        return out
    PW, PH = float(proj.get("width") or 1920), float(proj.get("height") or 1080)
    pcs = P.pieces(proj)
    caps = {}
    try:
        for i, (a, b) in enumerate(spans):
            if cancel and cancel():
                break
            pc = P.piece_at(proj, (a + b) / 2, pcs)
            if not pc["live"]:
                continue
            cap = caps.get(pc["file"])
            if cap is None:
                cap = caps[pc["file"]] = cv2.VideoCapture(pc["file"])
            found = False
            for f in (0.5, 0.2, 0.8):   # di solito basta il primo fotogramma; gli altri solo se li' non si vede la faccia
                t = pc["off"] + a + (b - a) * f - pc["t0"]
                cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, t) * 1000)
                ok, fr = cap.read()
                if not ok or fr is None:
                    continue
                if scene_kind(fr, cam, PW, PH, det)[0] == "full":   # webcam a tutto schermo: lo zoom sul riquadro inquadrerebbe altro
                    found = False
                    break
                fh, fw = fr.shape[:2]
                kx, ky = fw / PW, fh / PH
                x, y, w, h = cam
                px, py = w * 0.15, h * 0.15   # un po' di margine: la faccia puo' stare sul bordo del riquadro
                x0, y0 = int(max(0, (x - px) * kx)), int(max(0, (y - py) * ky))
                x1, y1 = int(min(fw, (x + w + px) * kx)), int(min(fh, (y + h + py) * ky))
                crop = fr[y0:y1, x0:x1]
                if crop.size == 0:
                    continue
                if crop.shape[1] < 320:   # webcam piccola: si ingrandisce, il rilevatore vede meglio
                    k = 320 / crop.shape[1]
                    crop = cv2.resize(crop, (320, max(8, int(crop.shape[0] * k))), interpolation=cv2.INTER_CUBIC)
                fs = det.faces(crop)
                if any(fw_ >= crop.shape[1] * 0.07 for _, _, fw_, _ in fs):
                    found = True
                    break
            out[i] = found
    except Exception as e:
        print("[zoom] controllo del viso non riuscito:", e, flush=True)
        return [True] * len(spans)
    finally:
        for c in caps.values():
            c.release()
    return out


def propose_into(proj, cut_level, zoom_level, zoom_scale=None):
    db = timeline_db(proj)
    # -1 = nessun taglio / nessuno zoom automatico (si monta tutto a mano)
    cut_level, zoom_level = max(-1, min(2, int(cut_level))), max(-1, min(2, int(zoom_level)))
    cuts, zooms, stats = A.propose(db, proj["duration"], max(0, cut_level), max(0, zoom_level))
    if cut_level < 0:
        cuts = []
    if zoom_level < 0:
        zooms = []
    elif zooms:
        keep = cam_face_ok(proj, zooms)
        dropped = sum(1 for k in keep if not k)
        zooms = [z for z, k in zip(zooms, keep) if k]
        stats["zoomsNoFace"] = dropped
        if dropped:
            print(f"[zoom] {dropped} zoom tolti: nel riquadro della webcam non c'era nessuno", flush=True)
    proj["style"] = {"cuts": cut_level, "zooms": zoom_level}
    proj["cuts"] = []
    proj["segs"] = P.split_segs_at(P.segs_from_auto_cuts(proj["duration"], cuts), [m["t0"] for m in P.pieces(proj)[1:]])
    zs = max(1.1, min(4.0, float(zoom_scale))) if zoom_scale else 2.8
    if zoom_scale:
        proj.setdefault("settings", {})["zoomLevel"] = zs   # anche gli zoom che aggiungi dopo partono da qui
    # gli zoom messi a mano restano: si rifanno solo quelli automatici (e non si sovrappongono ai tuoi)
    mine = [z for z in proj.get("zooms") or [] if not z.get("auto")]
    proj["zooms"] = mine + [{"id": P.new_id("z"), "a": a, "b": b, "on": True, "level": zs, "in": "snap", "out": "cut", "auto": True}
                            for a, b in zooms if not any(a < m["b"] and b > m["a"] for m in mine)]
    proj["analysis"] = {"ready": True, **stats}
    proj["stage"] = "editor"
    return proj


# ------------------------------------------------------------------ accelerazione NVIDIA per i sottotitoli
# L'installer non la mette (sarebbe 1 GB in piu' per tutti): se c'e' una scheda NVIDIA, l'app la scarica
# da sola in sottofondo la prima volta. La trascrizione, se sta arrivando, la aspetta.
GPU = {"state": "idle", "msg": ""}   # idle | installing | ready | none | failed


def _gpu_libs_ok():
    import site
    for sp in site.getsitepackages():
        base = os.path.join(sp, "nvidia")
        if os.path.isdir(os.path.join(base, "cublas")) and os.path.isdir(os.path.join(base, "cudnn")):
            return True
    return False


def ensure_gpu_bg():
    if sys.platform != "win32":
        GPU["state"] = "none"
        return
    if _gpu_libs_ok():
        GPU["state"] = "ready"
        return
    if not shutil.which("nvidia-smi"):
        GPU["state"] = "none"
        return
    mark = os.path.join(os.path.expanduser("~"), "VODcut", "nvidia-tentativo.txt")
    try:
        if os.path.exists(mark) and time.time() - os.path.getmtime(mark) < 86400:
            GPU["state"] = "failed"   # riprova domani, non a ogni avvio
            return
    except OSError:
        pass

    def run():
        GPU["state"] = "installing"
        print("[app] Scheda NVIDIA: scarico l'accelerazione per i sottotitoli (una volta sola, circa 1 GB)", flush=True)
        py = os.path.join(os.path.dirname(sys.executable), "python.exe")
        if not os.path.exists(py):
            py = sys.executable
        try:
            r = subprocess.run([py, "-m", "pip", "install", "--disable-pip-version-check", "--no-warn-script-location",
                                "nvidia-cublas-cu12", "nvidia-cudnn-cu12==9.*"], capture_output=True, creationflags=NO_WINDOW, timeout=3600)
            ok = r.returncode == 0 and _gpu_libs_ok()
        except Exception as e:
            ok, r = False, None
            print("[app] accelerazione NVIDIA: " + str(e), flush=True)
        GPU["state"] = "ready" if ok else "failed"
        print("[app] Accelerazione NVIDIA " + ("pronta" if ok else "non installata: i sottotitoli useranno il processore"), flush=True)
        if not ok:
            try:
                os.makedirs(os.path.dirname(mark), exist_ok=True)
                with open(mark, "w", encoding="utf-8") as f:
                    f.write((r.stderr.decode(errors="ignore")[-2000:] if r else "errore"))
            except OSError:
                pass
    threading.Thread(target=run, daemon=True).start()


def job_face(job, pid):
    """Tracciamento del viso nella webcam (verticale): la webcam ritagliata segue la faccia."""
    proj = P.load(pid)
    cam = (proj.get("webcam") or {}).get("box")
    if not cam:
        raise RuntimeError("Imposta prima il riquadro della webcam")
    path = FACE.path_for(pid)
    data = FACE.load(path)
    if data.get("cam") != cam or data.get("step") != FACE.STEP:
        data = {"cam": cam, "step": FACE.STEP, "pts": {}, "done": []}
    todo = FACE.missing(data, FACE.live_ranges(proj, P.pieces(proj)))
    total = sum(b - a for a, b in todo) or 1
    W, H = int(proj["width"]), int(proj["height"])
    done_s = 0.0
    job.message = "Cerco il viso nella webcam"

    def check():
        if job.cancelled:
            raise RuntimeError("Annullato")
    for a, b in todo:
        def on_frame(k, a=a):
            job.progress = min(0.99, (done_s + k * FACE.STEP) / total)
        pts = FACE.track_range(proj["source"], cam, W, H, a, b, ffmpeg_bin(), popen, check, on_frame)
        i0 = int(round(a / FACE.STEP))
        for k, pt in enumerate(pts):
            if pt:
                data["pts"][str(i0 + k)] = pt
        data["done"].append([a, b])
        done_s += b - a
        FACE.save(path, data)
    FACE.save(path, data)
    job.progress = 1.0
    return {"points": len(data["pts"])}


def job_transcribe(job, pid, use_ai=False):
    # l'accelerazione NVIDIA sta arrivando: meglio aspettarla (poi va molte volte piu' veloce)
    while GPU["state"] == "installing" and not job.cancelled:
        job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
        time.sleep(1)
    try:
        return _job_transcribe(job, pid, use_ai)
    except Exception as e:
        with LOCK:
            proj = P.load(pid)
            proj["transcript"] = {"status": "error", "error": str(e), "segments": []}
            P.save(proj)
        raise


def _job_transcribe(job, pid, use_ai=False):
    proj = P.load(pid)
    job.message = "Preparo la trascrizione AI" if use_ai else "Preparo la trascrizione (la prima volta scarica il modello)"
    script = (proj.get("script") or "").strip()
    if use_ai:
        TR = (lambda *a, **k: AI.transcribe_cloud(*a, prompt=script, **k)) if script else AI.transcribe_cloud
    else:
        TR = (lambda *a, **k: T.transcribe(*a, prompt=script, **k)) if script else T.transcribe

    def prog(x):
        job.progress = x
        job.message = "Trascrivo"
    # lingua scelta a mano (Sottotitoli -> Lingua): vale per la trascrizione sul computer
    if not use_ai and proj.get("subLang"):
        TR0, sl = TR, proj["subLang"]
        TR = lambda *a, **k: TR0(*a, **dict(k, language=sl))
    ins = proj.get("inserts") or []
    live_d = P.live_duration(proj)
    tot = live_d + sum(i["dur"] for i in ins)
    res = TR(proj["source"], live_d, progress=lambda x: prog(x * live_d / tot), cancel=lambda: job.cancelled,
             log=lambda m: setattr(job, "message", m))
    if ins:
        # la live e' a pezzi sulla timeline: i tempi si spostano; poi si trascrivono i video inseriti
        _shift_tr(res, lambda x: P.live_to_timeline(proj, x))
        done = live_d
        for i in ins:
            try:
                tr = TR(i["file"], i["dur"] + i.get("offset", 0), progress=lambda x, d0=done, d1=i["dur"]: prog((d0 + x * d1) / tot),
                        cancel=lambda: job.cancelled, log=lambda m: None)
                off = i.get("offset", 0)
                tr["segments"] = [sg for sg in tr.get("segments", []) if sg["b"] > off and sg["a"] < off + i["dur"]]
                _shift_tr(tr, lambda x, a=i["at"], o=off, d=i["dur"]: a + max(0.0, min(d, x - o)))
                res["segments"] += tr["segments"]
            except Exception:
                traceback.print_exc()
            done += i["dur"]
        res["segments"].sort(key=lambda x: x["a"])
    if script:   # nomi e termini scritti come nello script
        try:
            print("[trascrizione] parole corrette con lo script:", T.fix_with_script(res, script), flush=True)
        except Exception:
            traceback.print_exc()
    with LOCK:  # l'utente puo' aver modificato altro nel frattempo
        proj = P.load(pid)
        proj["transcript"] = res
        P.save(proj)
    return {"segments": len(res["segments"])}


def _stream_info(path):
    out = subprocess.check_output([ffprobe_bin(), "-v", "error", "-show_entries",
                                   "stream=codec_type,codec_name,time_base,sample_rate,channels", "-of", "json", path],
                                  creationflags=NO_WINDOW)
    v = a = None
    for st in json.loads(out).get("streams", []):
        if st.get("codec_type") == "video" and not v:
            v = st
        elif st.get("codec_type") == "audio" and not a:
            a = st
    return v or {}, a or {}


def keyframe_near(path, t, window=6.0):
    """Fotogramma chiave del video vicino al tempo t: li' si puo' tagliare senza ricodificare."""
    try:
        out = subprocess.run([ffprobe_bin(), "-v", "error", "-select_streams", "v:0", "-read_intervals", f"{max(0, t - window):.2f}%{t + window:.2f}",
                              "-show_entries", "packet=pts_time,flags", "-of", "csv=p=0", path], capture_output=True, text=True,
                             creationflags=NO_WINDOW).stdout
        ks = [float(l.split(",")[0]) for l in out.splitlines() if "K" in l.split(",")[-1] and l.split(",")[0] not in ("", "N/A")]
    except Exception:
        ks = []
    return min(ks, key=lambda k: abs(k - t)) if ks else t


SUB_LANGS = {"it": "italiano", "en": "inglese", "es": "spagnolo", "fr": "francese", "de": "tedesco", "pt": "portoghese"}


def job_cliplang(job, pid, lang):
    """Clip della galleria in un'altra lingua: sottotitoli riscritti (solo i pezzi delle clip) e titoli/scritte tradotti."""
    src = P.load(pid)
    kids = []
    for v in src.get("verticals") or []:
        try:
            ch = P.load(v["id"])
        except Exception:
            continue
        if ch.get("clip"):
            kids.append(ch)
    if not kids:
        raise RuntimeError("Nessuna clip da cambiare")
    with LOCK:
        src = P.load(pid)
        src["subLang"] = lang
        P.save(src)
    n = len(kids)
    redone, last_err = 0, ""
    for i, ch in enumerate(kids):
        if job.cancelled:
            raise RuntimeError("Annullato")
        job.message = f"Riscrivo i sottotitoli in {SUB_LANGS[lang]} ({i + 1} di {n})"
        with LOCK:
            c2 = P.load(ch["id"])
            c2["subLang"] = lang
            P.save(c2)
        rs = ch.get("ranges") or [[0, 0]]

        class _Sub:   # la sotto-attivita' scrive l'avanzamento nella barra di questa
            cancelled = False

            def __setattr__(self, k, v):
                if k == "progress":
                    job.progress = min(0.85, (i + float(v)) / n * 0.85)
                elif k == "cancelled":
                    object.__setattr__(self, k, v)
        sub = _Sub()
        if T.available():
            try:
                job_transcribe_range(sub, ch["id"], float(rs[0][0]), float(rs[-1][1]))
                redone += 1
            except Exception as e:
                print("[clip] sottotitoli non riscritti:", str(e)[:200], flush=True)
                last_err = str(e)
    # titoli, scritte d'apertura e motivi: tradotti con l'AI (se c'e' una chiave), altrimenti restano come sono
    job.message = "Traduco titoli e scritte"
    job.progress = 0.88
    items = []
    for ch in kids:
        meta = ch.get("clip") or {}
        items.append({"id": ch["id"], "title": meta.get("title") or ch.get("name") or "", "hook": meta.get("hook") or ""})
    translated = {}
    try:
        cfg = _text_cfg()
        raw = AI.text(cfg, ("Traduci titoli e scritte d'apertura di clip verticali (Shorts/TikTok) di uno streamer nella lingua richiesta. "
                            "Tieni lo stesso tono, brevi e d'impatto come scriverebbe un creator madrelingua, niente virgolette. "
                            "Rispondi SOLO con JSON: {\"items\": [{\"id\": \"...\", \"title\": \"...\", \"hook\": \"...\"}]}"),
                      json.dumps({"lingua": SUB_LANGS[lang], "items": items}, ensure_ascii=False), max_tokens=3000, cancel=lambda: job.cancelled)
        for x in (AI.parse_json(raw) or {}).get("items") or []:
            if isinstance(x, dict) and x.get("id"):
                translated[str(x["id"])] = x
    except Exception as e:
        print("[clip] titoli non tradotti:", str(e)[:200], flush=True)
    for ch in kids:
        t_ = translated.get(ch["id"])
        with LOCK:
            c2 = P.load(ch["id"])
            if t_:
                meta = c2.get("clip") or {}
                if str(t_.get("title") or "").strip():
                    meta["title"] = str(t_["title"]).strip()[:80]
                    c2["name"] = meta["title"]
                if str(t_.get("hook") or "").strip():
                    meta["hook"] = str(t_["hook"]).strip()[:60]
                    for tr_ in c2.get("tracks") or []:
                        for cl in tr_.get("clips") or []:
                            if cl.get("hook") and cl.get("isText"):
                                cl["text"] = dict(cl.get("text") or {}, content=meta["hook"])
                                cl["name"] = meta["hook"][:40]
                                cl.pop("file", None)   # la galleria la ridisegna
                c2["clip"] = meta
            c2.pop("clipPreview", None)   # anteprima da rifare con i sottotitoli nuovi
            P.save(c2)
    with LOCK:
        cur = P.load(pid)
        for v in cur.get("verticals") or []:
            t_ = translated.get(v.get("id"))
            if t_ and str(t_.get("title") or "").strip():
                v["name"] = str(t_["title"]).strip()[:80]
                if isinstance(v.get("clip"), dict):
                    v["clip"]["title"] = v["name"]
                    if str(t_.get("hook") or "").strip():
                        v["clip"]["hook"] = str(t_["hook"]).strip()[:60]
        P.save(cur)
    job.progress = 1.0
    if not redone and not translated:
        raise RuntimeError("Non sono riuscito a cambiare la lingua: " + (last_err or "riprova"))
    return {"clips": n, "translated": len(translated), "subs": redone}


def job_transcribe_range(job, pid, A, B):
    """Sottotitoli solo di un pezzo della timeline (A..B): si trascrive quel pezzo e si sostituisce quello che c'era."""
    while GPU["state"] == "installing" and not job.cancelled:
        job.message = "Preparo l'accelerazione NVIDIA (una volta sola)"
        time.sleep(1)
    proj = P.load(pid)
    lang = proj.get("subLang") or (proj.get("transcript") or {}).get("language")
    parts = []
    for pc in P.pieces(proj):
        lo, hi = max(A, pc["t0"]), min(B, pc["t1"])
        if hi - lo > 0.2:
            parts.append((pc, lo, hi))
    tot = sum(hi - lo for _, lo, hi in parts) or 1
    new, done = [], 0.0
    job.message = "Preparo la trascrizione"
    work = tempdir()
    try:
        for k, (pc, lo, hi) in enumerate(parts):
            ss = pc["off"] + (lo - pc["t0"])
            wav = os.path.join(work, f"r{k}.wav")
            subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{ss:.3f}", "-i", pc["file"], "-t", f"{hi - lo:.3f}",
                            "-vn", "-ac", "1", "-ar", "16000", wav], creationflags=NO_WINDOW, check=True)

            def prog(x, d0=done, d1=hi - lo):
                job.progress = min(0.99, (d0 + x * d1) / tot)
                job.message = "Trascrivo"
            tr = T.transcribe(wav, hi - lo, progress=prog, cancel=lambda: job.cancelled, language=lang,
                              log=lambda m: setattr(job, "message", m))
            _shift_tr(tr, lambda x, o=lo, d=hi - lo: round(o + max(0.0, min(d, x)), 2))
            new += tr.get("segments", [])
            lang = lang or tr.get("language")
            done += hi - lo
    finally:
        shutil.rmtree(work, ignore_errors=True)
    with LOCK:
        proj = P.load(pid)
        cur = proj.get("transcript") or {}
        keep = []
        for sg in (cur.get("segments") or []) if cur.get("status") == "done" else []:
            ws = [w for w in sg.get("words", []) if not (w["a"] >= A - 0.05 and w["b"] <= B + 0.05)]
            if ws:
                keep.append(dict(sg, a=ws[0]["a"], b=ws[-1]["b"], words=ws))
        segs = sorted(keep + new, key=lambda x: x["a"])
        proj["transcript"] = {**(cur if cur.get("status") == "done" else {}), "status": "done", "language": lang,
                              "segments": segs, "rev": int(cur.get("rev") or 0) + 1}
        P.save(proj)
    return {"segments": len(new), "words": sum(len(sg["words"]) for sg in new)}


def _shift_tr(tr, f):
    for sg in tr.get("segments", []):
        sg["a"], sg["b"] = f(sg["a"]), f(sg["b"])
        for w in sg.get("words", []):
            w["a"], w["b"] = f(w["a"]), f(w["b"])
    return tr


_INSUP_BUSY = set()


def _upgrade_ins_proxies(pid, proj):
    """Copie per l'anteprima dei video inseriti fatte da versioni vecchie (keyframe radi: play e salti lenti):
    si rifanno in background, una alla volta; al prossimo caricamento del progetto si usa quella nuova."""
    todo = [i for i in proj.get("inserts") or [] if i.get("preview") and not str(i["preview"]).endswith("_k6.mp4")
            and i.get("file") and os.path.exists(i["file"])]
    if not todo or pid in _INSUP_BUSY:
        return
    _INSUP_BUSY.add(pid)

    def work():
        try:
            for rec in todo:
                clip, out = rec["file"], ins_proxy_path(pid, rec["file"])
                if not os.path.exists(out):
                    ci = probe(clip)
                    fps = float(proj.get("fps") or 30)
                    vf = f"fps={min(30.0, fps):g},scale=-2:{min(720, int(ci.get('height') or 720))}"
                    part = out + ".part.mp4"
                    encs = ([proxy_gpu_args("6")] if proxy_gpu_args("6") else []) + \
                        [["-c:v", "libx264", "-preset", "ultrafast", "-crf", "27", "-g", "6", "-tune", "fastdecode", "-pix_fmt", "yuv420p"]]
                    for enc in encs:
                        r = subprocess.run([ffmpeg_bin(), "-nostdin", "-v", "error", "-y", "-i", clip, "-map", "0:v:0", "-map", "0:a:0?", "-vf", vf, *enc,
                                            "-af", PROXY_AF, "-c:a", "aac", "-b:a", "128k", "-ac", "2", "-movflags", "+faststart", part],
                                           stdin=subprocess.DEVNULL, capture_output=True, creationflags=NO_WINDOW)
                        if r.returncode == 0:
                            replace_retry(part, out)
                            break
                if os.path.exists(out):
                    with LOCK:
                        cur = P.load(pid)
                        for i in cur.get("inserts") or []:
                            if i.get("file") == clip and i.get("preview") and not str(i["preview"]).endswith("_k6.mp4"):
                                i["preview"] = out
                        P.save(cur)
        except Exception:
            traceback.print_exc()
        finally:
            _INSUP_BUSY.discard(pid)
    threading.Thread(target=work, daemon=True).start()


def ins_proxy_path(pid, clip):
    import hashlib
    k = hashlib.md5(os.path.normcase(os.path.abspath(clip)).encode("utf-8")).hexdigest()[:10]
    return os.path.join(CACHE_DIR, "proxy", f"{ckey(pid)}_ins_{k}_k6.mp4")


def clip_key(clip):
    import hashlib
    st = os.stat(clip)
    return hashlib.md5(f"{os.path.normcase(os.path.abspath(clip))}|{st.st_size}|{int(st.st_mtime)}".encode("utf-8")).hexdigest()[:12]


def clip_db_path(clip):
    return os.path.join(CACHE_DIR, "clips", clip_key(clip) + "_db.npy")


def clip_db(clip, dur, has_audio):
    """Volume dell'audio di un video inserito (tenuto in cache: si calcola una volta sola)."""
    p = clip_db_path(clip)
    if os.path.exists(p):
        try:
            return np.load(p)
        except Exception:
            pass
    db = None
    if has_audio:
        try:
            db = np.asarray(A.loudness_track(clip, duration=dur), np.float32)
        except Exception:
            traceback.print_exc()
    if db is None:
        db = np.full(int(round(dur / A.HOP)) + 1, -90.0, np.float32)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    np.save(p, db)
    return db


def timeline_db(proj):
    """Volume dell'audio lungo tutta la timeline: la live a pezzi + i video inseriti."""
    live = np.load(db_path(proj["id"]))
    if not proj.get("inserts"):
        return live
    out = []
    for m in P.pieces(proj):
        a, n = int(round(m["off"] / A.HOP)), int(round((m["t1"] - m["t0"]) / A.HOP))
        if m["live"]:
            part = live[a:a + n]
        else:
            try:
                part = clip_db(m["file"], m["ins"]["dur"] + m["off"], m["ins"].get("hasAudio"))[a:a + n]
            except Exception:
                part = np.zeros(0, np.float32)
        if len(part) < n:
            part = np.concatenate([part, np.full(n - len(part), -90.0, np.float32)])
        out.append(part)
    return np.concatenate(out) if out else live


IMAGE_CLIP_LEN = 300.0   # un'immagine nella traccia principale diventa un video fermo di 5 minuti (se ne usa quanto vuoi)
IMAGE_CLIP_START = 5.0


def image_clip(proj, img):
    """Immagine -> video fermo grande quanto il progetto (immagine intera al centro, sfondo nero), con audio muto.
    Si fanno 10 s e si ripetono senza ricodificare: pronto in un attimo. Uno per immagine e formato, riusato."""
    import hashlib
    W_, H_ = int(proj.get("width") or 1920), int(proj.get("height") or 1080)
    st = os.stat(img)
    key = hashlib.sha1(f"{os.path.abspath(img)}|{st.st_size}|{int(st.st_mtime)}".encode()).hexdigest()[:16]
    d = os.path.join(IMPORTS_DIR, "immagini-video")
    os.makedirs(d, exist_ok=True)
    out = os.path.join(d, f"{key}_{W_}x{H_}.mp4")
    if os.path.exists(out):
        return out
    chunk, tmp = out[:-4] + "_pezzo.mp4", out[:-4] + "_tmp.mp4"
    fc = (f"color=c=black:s={W_}x{H_}:r=30:d=10[bg];"
          f"[0:v]scale={W_}:{H_}:force_original_aspect_ratio=decrease:flags=lanczos,format=rgba[fg];"
          f"[bg][fg]overlay=(W-w)/2:(H-h)/2:shortest=1,format=yuv420p,setsar=1[v]")
    r = subprocess.run([ffmpeg_bin(), "-nostdin", "-v", "error", "-y", "-loop", "1", "-framerate", "30", "-t", "10", "-i", img,
                        "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-filter_complex", fc, "-map", "[v]", "-map", "1:a",
                        "-t", "10", "-r", "30", "-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage", "-crf", "16", "-g", "30",
                        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", chunk],
                       stdin=subprocess.DEVNULL, capture_output=True, creationflags=NO_WINDOW)
    if r.returncode != 0:
        raise RuntimeError("Non riesco a usare questa immagine: " + r.stderr.decode(errors="ignore")[-300:])
    r = subprocess.run([ffmpeg_bin(), "-nostdin", "-v", "error", "-y", "-stream_loop", str(int(IMAGE_CLIP_LEN // 10) - 1), "-i", chunk,
                        "-c", "copy", "-movflags", "+faststart", tmp], stdin=subprocess.DEVNULL, capture_output=True, creationflags=NO_WINDOW)
    try:
        os.remove(chunk)
    except OSError:
        pass
    if r.returncode != 0:
        raise RuntimeError("Non riesco a usare questa immagine: " + r.stderr.decode(errors="ignore")[-300:])
    replace_retry(tmp, out)
    return out


def freeze_frame(proj, t):
    """Fotogramma della timeline al tempo t (live o video inserito), a piena risoluzione, in PNG."""
    pcs = P.pieces(proj)
    pc = next((x for x in pcs if x["t0"] - 1e-6 <= t < x["t1"]), pcs[-1] if pcs else None)
    if not pc or not os.path.isfile(pc["file"]):
        raise RuntimeError("Non trovo il video in questo punto")
    st = max(0.0, pc["off"] + (t - pc["t0"]))
    out_dir = os.path.join(IMPORTS_DIR, "fermi")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, f"fermo-{ckey(proj['id'])}-{int(st * 1000)}.png")
    if not os.path.exists(out):
        tmp = out + ".part.png"
        r = subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{st:.3f}", "-i", pc["file"], "-frames:v", "1", tmp],
                           capture_output=True, creationflags=NO_WINDOW, timeout=60)
        if r.returncode != 0 or not os.path.exists(tmp):
            raise RuntimeError("Non riesco a prendere il fotogramma: " + r.stderr.decode(errors="ignore")[-200:])
        replace_retry(tmp, out)
    allow_picked([out])
    return out


def job_prepinsert(job, pid, clip):
    """Prepara un video da mettere nella traccia principale. Il progetto NON viene toccato:
    lo mette in timeline l'editor, subito (cosi' e' fluido e si puo' annullare)."""
    proj = P.load(pid)
    if clip.lower().endswith(IMG_EXT):
        job.message = "Preparo l'immagine"
        still = image_clip(proj, clip)
        ii = probe(clip)
        ci = probe(still)
        job.progress = 1.0
        return {"file": still, "dur": IMAGE_CLIP_START, "fileDur": float(ci.get("duration") or IMAGE_CLIP_LEN), "image": True,
                "src": os.path.abspath(clip), "iar": round(float(ii.get("width") or 1) / float(ii.get("height") or 1), 5), "w": ci.get("width"), "h": ci.get("height"), "hasAudio": False, "vcodec": "h264",
                "name": os.path.basename(clip), "peaks": []}
    ci = probe(clip)
    if not ci["has_video"]:
        raise RuntimeError("Il file scelto non contiene video")
    fps = float(proj.get("fps") or 30)
    clip_d = math.floor(float(ci["duration"] or 0) * fps) / fps   # durata a fotogrammi interi
    if clip_d < 0.1:
        raise RuntimeError("Il video scelto e' troppo corto")
    info = {"file": os.path.abspath(clip), "dur": clip_d, "w": ci.get("width"), "h": ci.get("height"),
            "hasAudio": bool(ci.get("has_audio")), "vcodec": ci.get("vcodec"), "name": os.path.basename(clip)}
    # copia leggera per l'anteprima solo se serve (video grande o formato che l'anteprima non legge)
    if int(ci.get("height") or 0) > 760 or (ci.get("vcodec") and ci["vcodec"] not in PREVIEW_OK):
        out = ins_proxy_path(pid, clip)
        if not os.path.exists(out):
            os.makedirs(os.path.dirname(out), exist_ok=True)
            part = out + ".part.mp4"
            job.message = "Preparo l'anteprima del video"
            vf = f"fps={min(30.0, fps):g},scale=-2:{min(720, int(ci.get('height') or 720))}"
            # un keyframe ogni 6 fotogrammi (come la copia della live): pausa, play e salti partono subito
            encs = []
            if proxy_gpu_args("6"):
                encs.append(proxy_gpu_args("6"))
            encs.append(["-c:v", "libx264", "-preset", "ultrafast", "-crf", "27", "-g", "6", "-tune", "fastdecode", "-pix_fmt", "yuv420p"])
            ok, err = False, ""
            for enc in encs:
                pr = subprocess.Popen([ffmpeg_bin(), "-v", "error", "-y", "-i", clip, "-map", "0:v:0", "-map", "0:a:0?", "-vf", vf, *enc,
                                       "-af", PROXY_AF, "-c:a", "aac", "-b:a", "128k",
                                       "-ac", "2", "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", part],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=NO_WINDOW)
                for line in pr.stdout:
                    if job.cancelled:
                        pr.kill()
                        raise R.Cancelled()
                    m = re.match(rb"out_time_(?:us|ms)=(\d+)", line)
                    if m:
                        job.progress = min(0.8, 0.8 * int(m.group(1)) / 1e6 / max(0.1, clip_d))
                pr.wait()
                if pr.returncode == 0:
                    replace_retry(part, out)
                    ok = True
                    break
                err = pr.stderr.read().decode(errors="ignore")[-300:]
            if not ok:
                raise RuntimeError(media_problem(err) or ("Non riesco a leggere questo video: " + err))
        info["preview"] = out
    job.message = "Ascolto l'audio del video"
    job.progress = max(job.progress, 0.85)
    db = clip_db(clip, clip_d, ci.get("has_audio"))[:int(round(clip_d / A.HOP)) + 1]
    info["peaks"] = A.waveform(db, 5)
    job.progress = 1.0
    return info


def job_insert_transcript(job, pid, clip, dur, offset=0.0):
    """Trascrizione di un video inserito (tempi dal suo inizio): l'editor la mette al posto giusto."""
    job.message = "Trascrivo il video aggiunto"
    tr = T.transcribe(clip, dur + offset, progress=lambda x: setattr(job, "progress", x), cancel=lambda: job.cancelled, log=lambda m: None)
    segs = [sg for sg in tr.get("segments", []) if sg["b"] > offset and sg["a"] < offset + dur]
    return {"segments": _shift_tr({"segments": segs}, lambda x: max(0.0, min(dur, x - offset)))["segments"]}


def media_problem(err):
    """Errori di ffmpeg tradotti in qualcosa che si capisce."""
    e = str(err or "") + " " + str(getattr(err, "stderr", "") or "")
    if "moov atom not found" in e or "Invalid data found when processing input" in e:
        return ("Il video non e' completo: forse la registrazione e' ancora in corso (OBS) o il file si e' rovinato. "
                "Aspetta che finisca di registrare, oppure usa un'altra copia del video.")
    if "No such file" in e:
        return "Il file del video non si trova piu': e' stato spostato o eliminato?"
    return None


def job_export(job, pid, want=None):
    if not os.path.exists(P.path_for(pid)):
        raise RuntimeError("Questo progetto non c'e' piu' (e' stato eliminato o messo nel cestino)")
    if want and (want.get("verticals") or want.get("timelines") or want.get("vod") is False):
        return job_export_many(job, pid, want)
    proj = P.load(pid)

    def lg(m):
        job.log.append(m)
        print(f"[export] {time.strftime('%H:%M:%S')} {m}", flush=True)
    t0 = time.time()
    lg(f"inizio: {proj.get('name')} · {proj.get('duration', 0):.0f} s · video inseriti: {len(proj.get('inserts') or [])}")
    try:
        res = R.render(proj, progress=lambda x, m: (setattr(job, "progress", x), setattr(job, "message", m)),
                       cancel=lambda: job.cancelled, log=lg)
    except R.Cancelled:
        raise
    except Exception as e:
        # l'errore resta scritto: si puo' mandare a chi ti aiuta
        det = traceback.format_exc()
        print("[export] ERRORE\n" + det, flush=True)
        try:
            with open(os.path.join(APP_DIR, "ultimo-errore-export.txt"), "w", encoding="utf-8") as f:
                f.write(f"NoonFrame {VERSION} · {time.strftime('%Y-%m-%d %H:%M:%S')}\nProgetto: {proj.get('name')}\n\n"
                        + "\n".join(job.log[-30:]) + "\n\n" + det)
        except OSError:
            pass
        raise RuntimeError(str(e) or e.__class__.__name__)
    lg(f"fatto in {time.time() - t0:.0f} s")
    with LOCK:
        proj = P.load(pid)
        proj["lastExport"] = {**res, "at": time.time()}
        P.save(proj)
    return res


def job_export_many(job, pid, want):
    """VOD e clip verticali in un colpo solo, uno dopo l'altro (in una cartella se sono piu' di uno)."""
    items, folder = export_items(pid, want)
    if not items:
        raise RuntimeError("Niente da esportare")

    def lg(m):
        job.log.append(m)
        print(f"[export] {time.strftime('%H:%M:%S')} {m}", flush=True)
    n = len(items)
    files = []
    for i, q in enumerate(items):
        os.makedirs(q["settings"]["export"]["dir"], exist_ok=True)
        tag = f"{i + 1} di {n} · {q['name']}" if n > 1 else q["name"]
        lg(f"inizio: {tag}")
        try:
            res = R.render(q, progress=lambda x, m, i=i: (setattr(job, "progress", (i + x) / n), setattr(job, "message", (f"Video {i + 1} di {n} · " if n > 1 else "") + m)),
                           cancel=lambda: job.cancelled, log=lg)
        except R.Cancelled:
            raise
        except Exception as e:
            det = traceback.format_exc()
            print("[export] ERRORE\n" + det, flush=True)
            try:
                with open(os.path.join(APP_DIR, "ultimo-errore-export.txt"), "w", encoding="utf-8") as f:
                    f.write(f"NoonFrame {VERSION} · {time.strftime('%Y-%m-%d %H:%M:%S')}\nProgetto: {q.get('name')}\n\n"
                            + "\n".join(job.log[-30:]) + "\n\n" + det)
            except OSError:
                pass
            raise RuntimeError(f"{q['name']}: {e}" if n > 1 else (str(e) or e.__class__.__name__))
        files.append({"name": q["name"], "vertical": bool(q.get("parent")) and not q.get("timeline"), **res})
        with LOCK:
            try:
                cur = P.load(q["id"])
                cur["lastExport"] = {**res, "at": time.time()}
                P.save(cur)
            except Exception:
                pass
    res = {**files[0], "files": files, "folder": folder}
    with LOCK:
        proj = P.load(pid)
        proj["lastExport"] = {**res, "at": time.time()}
        P.save(proj)
    return res


def job_download(job, url):
    try:
        import yt_dlp
    except ImportError:
        raise RuntimeError("Per importare da link serve yt-dlp. Riesegui INSTALLA.bat.")
    job.message = "Scarico il VOD"

    def hook(d):
        if job.cancelled:
            raise RuntimeError("annullato")
        if d.get("status") == "downloading":
            tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if tot:
                job.progress = min(0.98, d.get("downloaded_bytes", 0) / tot)
    opts = {"outtmpl": os.path.join(IMPORTS_DIR, "%(title).80s [%(id)s].%(ext)s"), "progress_hooks": [hook],
            "format": "bv*[height<=1080]+ba/b[height<=1080]/best", "merge_output_format": "mp4", "quiet": True,
            "noprogress": True, "ffmpeg_location": shutil.which("ffmpeg")}
    kick = _kick_vod_ref(url)
    try:
        path, info = _ytdl(url, opts)
    except Exception as e:
        if not kick or job.cancelled:
            raise
        print(f"[kick] yt-dlp non riuscito ({str(e)[:120]}), provo l'API dei canali", file=sys.stderr)
        job.message = "Cerco il VOD su Kick"
        v = _kick_find_vod(*kick)
        if not v:
            raise RuntimeError("Kick non trova questo VOD: controlla il link, oppure scaricalo e trascinalo qui.")
        job.message = "Scarico il VOD"
        safe = re.sub(r"\s+", " ", re.sub(r'[\\/:*?"<>|\r\n]+', " ", v["title"]))[:80].strip() or "VOD Kick"
        o2 = dict(opts, outtmpl=os.path.join(IMPORTS_DIR, f"{safe} [{v['id']}].%(ext)s"))
        path, info = _ytdl(v["source"], o2)
        info = dict(info or {}, title=v["title"])
    proj = P.create(path, name=info.get("title"))
    return {"project": proj["id"]}


_KICK_VOD = re.compile(r"kick\.com/([A-Za-z0-9_\-]+)/videos/([0-9a-fA-F\-]{8,})")


def _kick_vod_ref(url):
    """(canale, id) se il link è un VOD di Kick, altrimenti None."""
    m = _KICK_VOD.search(str(url or ""))
    return (m.group(1).lower(), m.group(2).lower()) if m else None


def _kick_json(u):
    """GET JSON da kick.com fingendo un browser (Kick sta dietro Cloudflare)."""
    try:
        if EX.ensure_impersonation():
            from curl_cffi import requests as creq
            r = creq.get(u, impersonate="chrome", timeout=25, headers={"Accept": "application/json"})
            if r.status_code == 200:
                return r.json()
            print(f"[kick] {u}: HTTP {r.status_code}", file=sys.stderr)
            if r.status_code in (403, 429, 503):
                raise RuntimeError(f"HTTP {r.status_code}")
            return None
    except Exception as e:
        print(f"[kick] {u}: {str(e)[:120]}", file=sys.stderr)
    try:
        import urllib.request
        rq = urllib.request.Request(u, headers={"Accept": "application/json", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0 Safari/537.36"})
        with urllib.request.urlopen(rq, timeout=25) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except Exception as e:
        print(f"[kick] {u}: {str(e)[:120]}", file=sys.stderr)
        return None


def _kick_pick(entries, vid):
    """Trova il VOD con questo id nella lista dei video del canale."""
    for e in entries or []:
        if not isinstance(e, dict):
            continue
        v = e.get("video") if isinstance(e.get("video"), dict) else {}
        ids = {str(x).lower() for x in (v.get("uuid"), v.get("id"), e.get("uuid"), e.get("id"), e.get("slug")) if x}
        if vid in ids and e.get("source"):
            return {"source": e["source"], "id": vid,
                    "title": str(e.get("session_title") or v.get("title") or "VOD Kick").strip()}
    return None


def _kick_find_vod(slug, vid):
    """Il link m3u8 del VOD tramite l'API dei video del canale (quella che usa il sito di Kick)."""
    d = _kick_json(f"https://kick.com/api/v1/video/{vid}")
    if isinstance(d, dict) and d.get("source"):
        ls = d.get("livestream") or {}
        return {"source": d["source"], "id": vid, "title": str(ls.get("session_title") or "VOD Kick").strip()}
    d = _kick_json(f"https://kick.com/api/v2/channels/{slug}/videos")
    if isinstance(d, dict):
        d = d.get("data") or d.get("videos") or []
    old = d if isinstance(d, list) else []
    v = _kick_pick(old, vid)
    if v:
        return v
    # VOD nuovi (id tipo 01a1…): stanno nella lista di web.kick.com; il file m3u8 è quello della lista vecchia
    # con lo stesso orario di inizio
    cid = next((e.get("channel_id") for e in old if isinstance(e, dict) and e.get("channel_id")), None)
    if not cid:
        ch = _kick_json(f"https://kick.com/api/v2/channels/{slug}")
        cid = ch.get("id") if isinstance(ch, dict) else None
    if not cid:
        print(f"[kick] canale {slug} non trovato", file=sys.stderr)
        return None
    w = _kick_json(f"https://web.kick.com/api/v1/channels/{cid}/videos")
    items = (w.get("data") if isinstance(w, dict) else w) or []
    nv = next((e for e in items if isinstance(e, dict) and str(e.get("id", "")).lower() == vid), None)
    if not nv:
        print(f"[kick] {vid} non è tra i {len(items)} video recenti di {slug}", file=sys.stderr)
        return None
    if nv.get("recording_url"):
        return {"source": nv["recording_url"], "id": vid, "title": str(nv.get("title") or "VOD Kick").strip()}
    return _kick_match_time(old, nv, vid)


def _kick_ts(s):
    """'2026-10-03T13:48:18Z' o '2026-10-03 13:48:22' -> secondi UTC."""
    import calendar
    m = re.match(r"(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)", str(s or ""))
    return calendar.timegm(tuple(int(x) for x in m.groups()) + (0, 0, 0)) if m else None


def _kick_match_time(old, nv, vid):
    """Il VOD della lista vecchia che è iniziato alla stessa ora (entro 10 minuti) di quello nuovo."""
    t0 = _kick_ts(nv.get("start_time"))
    if t0 is None:
        return None
    best, bd = None, 601
    for e in old:
        if not isinstance(e, dict) or not e.get("source"):
            continue
        for k in ("start_time", "created_at"):
            t = _kick_ts(e.get(k))
            if t is not None and abs(t - t0) < bd:
                best, bd = e, abs(t - t0)
    if not best:
        print(f"[kick] nessun file per {vid} (inizio {nv.get('start_time')})", file=sys.stderr)
        return None
    return {"source": best["source"], "id": vid, "title": str(nv.get("title") or best.get("session_title") or "VOD Kick").strip()}


# ------------------------------------------------------------------ utilita'
NATIVE = {"win": None}   # finestra nativa (pywebview), se c'e'


_DIALOG_EN = {"Video, immagini e suoni": "Videos, images and sounds", "Video immagini e suoni": "Videos images and sounds", "Immagini": "Images", "Suoni": "Sounds",
              "Tutti i file": "All files", "Progetto NoonFrame": "NoonFrame project", "Dove salvo il video?": "Where should I save the video?",
              "Importa video, immagini e suoni": "Import videos, images and sounds", "Scegli uno o piu' suoni": "Choose one or more sounds",
              "Apri un progetto NoonFrame": "Open a NoonFrame project", "Salva il progetto": "Save the project",
              "Dov'è questo file?": "Where is this file?", "Scegli il VOD": "Choose the VOD",
              "Selettore file non disponibile": "File picker not available", "Video": "Videos", "Audio": "Audio"}


def _L(s):
    """Testi delle finestre di Windows (scegli file, salva) nella lingua dell'app."""
    if load_settings().get("lang") != "en":
        return s
    head, sep, rest = s.partition(" (")
    return _DIALOG_EN.get(head, head) + sep + rest


_FT_OK = re.compile(r"^[\w ]+\([\w\s\*\.;]*\)$")


def _ft(*labels):
    """Filtri per il selettore di pywebview: accetta solo 'Nome (*.a;*.b)' con lettere e spazi nel nome
    (una virgola nel nome, anche solo nella traduzione, faceva fallire il selettore e chiudere l'app sul Mac)."""
    out = []
    for lb in labels:
        if not _FT_OK.match(lb):
            name, _, rest = lb.partition("(")
            lb = re.sub(r"[^\w ]+", " ", name).strip() + " (" + rest
            lb = re.sub(r"\s+\(", " (", re.sub(r" {2,}", " ", lb))
        if _FT_OK.match(lb):
            out.append(lb)
    return tuple(out)


def pick_file_native(kind):
    """Selettore file dalla finestra dell'app (non serve tkinter). Se i filtri non vanno, riprova senza."""
    import webview
    win0 = NATIVE["win"]

    class _W:
        def create_file_dialog(self, *a, **k):
            if "file_types" in k:
                k["file_types"] = _ft(*k["file_types"])
            try:
                return win0.create_file_dialog(*a, **k)
            except ValueError:
                traceback.print_exc()
                k.pop("file_types", None)
                return win0.create_file_dialog(*a, **k)
    win = _W()
    FD = getattr(webview, "FileDialog", None)
    OPEN = FD.OPEN if FD else 10
    FOLDER = FD.FOLDER if FD else 20
    if kind == "folder":
        r = win.create_file_dialog(FOLDER)
        print(f"[pick] cartella: {r!r}", flush=True)
        if isinstance(r, str):   # alcune versioni di pywebview danno il percorso e non una lista
            return (r or None), None
        return (r[0] if r else None), None
    if kind == "media":
        r = win.create_file_dialog(OPEN, allow_multiple=True, file_types=(
            _L("Video immagini e suoni (*.mp4;*.mkv;*.mov;*.webm;*.m4v;*.avi;*.flv;*.ts;*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp;*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac)"),
            _L("Video (*.mp4;*.mkv;*.mov;*.webm;*.m4v;*.avi;*.flv;*.ts)"), _L("Immagini (*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp)"),
            _L("Suoni (*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac)"), _L("Tutti i file (*.*)")))
        return list(r or []), None
    if kind == "audio":
        r = win.create_file_dialog(OPEN, allow_multiple=True, file_types=(_L("Audio (*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac)"), _L("Tutti i file (*.*)")))
        return list(r or []), None
    if kind == "project-open":
        r = win.create_file_dialog(OPEN, file_types=(_L("Progetto NoonFrame (*.vodcut)"), _L("Tutti i file (*.*)")))
        return (r[0] if r else None), None
    if kind.startswith("project-save:"):
        SAVE = FD.SAVE if FD else 30
        r = win.create_file_dialog(SAVE, save_filename=kind.split(":", 1)[1] + ".vodcut", file_types=(_L("Progetto NoonFrame (*.vodcut)"),))
        r = r[0] if isinstance(r, (list, tuple)) else r
        return (r or None), None
    if kind == "images":
        r = win.create_file_dialog(OPEN, allow_multiple=True, file_types=(_L("Immagini SVG e PSD (*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp;*.svg;*.psd)"), _L("Tutti i file (*.*)")))
        return list(r or []), None
    if kind in ("relink-image", "relink-audio", "relink-file"):
        ft = {"relink-image": (_L("Immagini (*.png;*.jpg;*.jpeg;*.webp;*.gif;*.bmp)"), _L("Tutti i file (*.*)")),
              "relink-audio": (_L("Audio (*.mp3;*.wav;*.m4a;*.aac;*.ogg;*.flac;*.opus)"), _L("Tutti i file (*.*)"))}.get(kind, (_L("Tutti i file (*.*)"),))
        r = win.create_file_dialog(OPEN, file_types=ft)
        return (r[0] if r else None), None
    r = win.create_file_dialog(OPEN, file_types=(_L("Video (*.mp4;*.mkv;*.mov;*.flv;*.ts;*.webm)"), _L("Tutti i file (*.*)")))
    return (r[0] if r else None), None


def pick_file(kind):
    """Finestra nativa per scegliere un file (quella dell'app, se no tkinter)."""
    if NATIVE["win"] is not None:
        try:
            return pick_file_native(kind)
        except Exception:
            traceback.print_exc()
            # sul Mac tkinter fuori dal thread principale chiude tutta l'app: meglio dirlo e basta
            if sys.platform == "darwin":
                return None, _L("Non riesco ad aprire la finestra per scegliere il file. Trascina il file nella finestra di NoonFrame.")
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception:
        return None, _L("Selettore file non disponibile")
    try:
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
    except Exception:
        return None, _L("Selettore file non disponibile")
    if kind == "folder":
        path = filedialog.askdirectory(title=_L("Dove salvo il video?"), mustexist=True)
        root.destroy()
        return path or None, None
    if kind == "media":
        types = [(_L("Video, immagini e suoni"), "*.mp4 *.mkv *.mov *.webm *.m4v *.avi *.flv *.ts *.png *.jpg *.jpeg *.webp *.gif *.bmp *.mp3 *.wav *.m4a *.aac *.ogg *.flac"),
                 (_L("Video"), "*.mp4 *.mkv *.mov *.webm *.m4v *.avi *.flv *.ts"),
                 (_L("Immagini"), "*.png *.jpg *.jpeg *.webp *.gif *.bmp"), (_L("Suoni"), "*.mp3 *.wav *.m4a *.aac *.ogg *.flac"),
                 (_L("Tutti i file"), "*.*")]
        paths = filedialog.askopenfilenames(title=_L("Importa video, immagini e suoni"), filetypes=types)
        root.destroy()
        return list(paths), None
    if kind == "audio":
        types = [(_L("Audio"), "*.mp3 *.wav *.m4a *.aac *.ogg *.flac"), (_L("Tutti i file"), "*.*")]
        paths = filedialog.askopenfilenames(title=_L("Scegli uno o piu' suoni"), filetypes=types)
        root.destroy()
        return list(paths), None
    if kind == "project-open":
        path = filedialog.askopenfilename(title=_L("Apri un progetto NoonFrame"), filetypes=[(_L("Progetto NoonFrame"), "*.vodcut"), (_L("Tutti i file"), "*.*")])
        root.destroy()
        return path or None, None
    if kind.startswith("project-save:"):
        path = filedialog.asksaveasfilename(title=_L("Salva il progetto"), initialfile=kind.split(":", 1)[1] + ".vodcut",
                                            defaultextension=".vodcut", filetypes=[(_L("Progetto NoonFrame"), "*.vodcut")])
        root.destroy()
        return path or None, None
    if kind == "images":
        paths = filedialog.askopenfilenames(title=_L("Scegli le immagini"), filetypes=[(_L("Immagini, SVG e PSD"), "*.png *.jpg *.jpeg *.webp *.gif *.bmp *.svg *.psd"), (_L("Tutti i file"), "*.*")])
        root.destroy()
        return list(paths), None
    if kind in ("relink-image", "relink-audio", "relink-file"):
        path = filedialog.askopenfilename(title=_L("Dov'è questo file?"))
        root.destroy()
        return path or None, None
    types = [(_L("Video"), "*.mp4 *.mkv *.mov *.flv *.ts *.webm"), (_L("Tutti i file"), "*.*")]
    path = filedialog.askopenfilename(title=_L("Scegli il VOD"), filetypes=types)
    root.destroy()
    return path or None, None


IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")
AUD_EXT = (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".opus")
VID_EXT = (".mp4", ".mkv", ".mov", ".webm", ".m4v", ".avi", ".flv", ".ts")


def media_info(path):
    """Video, immagine o suono da usare nel progetto (Media)."""
    ext = os.path.splitext(path)[1].lower()
    name = os.path.basename(path)
    if ext in IMG_EXT:
        info = probe(path)
        return {"path": path, "name": name, "kind": "image", "w": info.get("width", 0), "h": info.get("height", 0)}
    info = probe(path)
    if ext in AUD_EXT or (info.get("has_audio") and not info.get("has_video")):
        return {"path": path, "name": name, "kind": "audio", "duration": info["duration"]}
    if info.get("has_video") and info.get("duration", 0) > 0:
        return {"path": path, "name": name, "kind": "video", "duration": info["duration"], "w": info.get("width", 0),
                "h": info.get("height", 0), "hasAudio": bool(info.get("has_audio")), "vcodec": info.get("vcodec")}
    raise ValueError("Formato non supportato: usa video (mp4, mov…), immagini (png, jpg…) o suoni (mp3, wav…)")


def media_thumb(path, t=1.0, h=180):
    """Anteprima di un video importato (per i Media e la timeline)."""
    d = os.path.join(CACHE_DIR, "mthumbs")
    os.makedirs(d, exist_ok=True)
    key = re.sub(r"\W", "_", os.path.abspath(path))[-120:]
    fn = os.path.join(d, f"{key}_{int(t * 10)}_{h}.jpg")
    if not os.path.exists(fn):
        subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{max(0, t):.2f}", "-i", path, "-frames:v", "1",
                        "-vf", f"scale=-2:{h}", "-q:v", "5", fn], creationflags=NO_WINDOW)
        if not os.path.exists(fn):   # video piu' corto del secondo scelto
            subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-i", path, "-frames:v", "1", "-vf", f"scale=-2:{h}", "-q:v", "5", fn],
                           creationflags=NO_WINDOW)
    return fn


_REMBG = {}


def _ensure_rembg(job):
    nw = 0x08000000 if sys.platform == "win32" else 0
    try:
        import rembg  # noqa: F401
    except ImportError:
        job.message = "Installo lo strumento per ritagliare la persona (solo la prima volta, qualche minuto)"
        r = subprocess.run([sys.executable, "-m", "pip", "install", "rembg[cpu]"], capture_output=True, creationflags=nw)
        if r.returncode != 0:
            raise RuntimeError("Installazione non riuscita: " + r.stderr.decode(errors="ignore")[-300:])
        import importlib
        importlib.invalidate_caches()


def job_behind(job, pid, items):
    """Titoli dietro la persona: un video per ogni titolo (il pezzo di live con il testo dietro chi parla)."""
    from engine import behind as BH
    job.message = "Preparo il ritaglio della persona"
    try:
        BH.ensure_model(log=lambda m: setattr(job, "message", m), cancel=lambda: job.cancelled)
    except RuntimeError as e:
        if "annullato" in str(e):
            raise R.Cancelled()
        raise
    proj = P.load(pid)
    if proj.get("inserts"):
        raise RuntimeError("Con video inseriti nella timeline i titoli dietro la persona non si possono fare")
    W, H = int(proj.get("width") or 1920), int(proj.get("height") or 1080)
    k = min(1.0, 1080 / max(1, min(W, H)))
    W, H = int(W * k) // 2 * 2, int(H * k) // 2 * 2
    fps = min(30.0, float(proj.get("fps") or 30.0))
    outdir = os.path.join(IMPORTS_DIR, "persona-ai")
    os.makedirs(outdir, exist_ok=True)
    out, errs = [], []
    for n, it in enumerate(items):
        if job.cancelled:
            raise R.Cancelled()
        job.message = f"Ritaglio la persona per il titolo {n + 1} di {len(items)}"
        # lo stesso pezzo gia' ritagliato prima (anche dopo aver chiuso l'app): si riusa
        import hashlib
        key = hashlib.sha1(json.dumps([proj["source"], round(float(it["a"]), 3), round(float(it["b"]), 3), W, H, fps, 4]).encode()).hexdigest()[:16]
        d = os.path.join(outdir, "persona_" + key)
        try:
            meta = json.load(open(os.path.join(d, "fatto.json"), encoding="utf-8"))
            if meta.get("n") and os.path.isfile(meta.get("mask") or "") and os.path.isfile(meta.get("first") or ""):
                print("[titoli dietro] riuso il ritaglio gia' fatto", d, flush=True)
                out.append({"id": it.get("id"), **meta})
                job.progress = (n + 1) / len(items)
                continue
        except Exception:
            pass
        try:
            m = BH.matte(proj["source"], float(it["a"]), float(it["b"]), d, W, H, fps, mseq=True, mask_w=min(W, 960),
                         progress=lambda x, n=n: setattr(job, "progress", (n + x) / len(items)), cancel=lambda: job.cancelled)
            try:
                with open(os.path.join(d, "fatto.json"), "w", encoding="utf-8") as f:
                    json.dump(m, f)
            except OSError:
                pass
            out.append({"id": it.get("id"), **m})
        except Exception as e:
            if "annullato" in str(e):
                raise R.Cancelled()
            traceback.print_exc()
            errs.append(str(e)[:160])
    allow_picked([p for x in out for p in (x["mask"], x["first"])])
    return {"items": out, "errors": len(errs), "first": errs[0] if errs else ""}


def job_hands(job, pid, pieces, fps=10.0):
    """La mano (palmo, apertura, punta dell'indice, gesto) nei pezzi di video sotto un effetto, tutto sul computer."""
    from engine import hands as HN
    import hashlib
    proj = P.load(pid)
    known = {x.get("path") for x in proj.get("assets") or []} | {c.get("file") for t in proj.get("tracks") or [] for c in t.get("clips") or []} \
        | {proj.get("source")} | {x.get("file") for x in proj.get("inserts") or []}
    for p in pieces:
        if p["file"] not in known or not os.path.isfile(p["file"]):
            raise RuntimeError("Video non trovato nel progetto")
    job.message = "Preparo il tracciamento della mano"
    try:
        HN.ensure_models(log=lambda m: setattr(job, "message", m), cancel=lambda: job.cancelled)
    except RuntimeError as e:
        if "annullato" in str(e):
            raise R.Cancelled()
        raise
    tot = sum(p["b"] - p["a"] for p in pieces) or 1.0
    done, out = 0.0, []
    d = os.path.join(IMPORTS_DIR, "mani")
    os.makedirs(d, exist_ok=True)
    job.message = "Seguo la mano"
    for p in pieces:
        key = hashlib.sha1(json.dumps([p["file"], os.path.getmtime(p["file"]), round(p["a"], 2), round(p["b"], 2), fps, 1]).encode()).hexdigest()[:16]
        cf = os.path.join(d, key + ".json")
        try:
            rows = json.load(open(cf, encoding="utf-8"))
        except Exception:
            try:
                rows = HN.track(p["file"], p["a"], p["b"], fps=fps, cancel=lambda: job.cancelled,
                                progress=lambda x, d0=done, ln=p["b"] - p["a"]: setattr(job, "progress", min(1.0, (d0 + x * ln) / tot)))
            except RuntimeError as e:
                if "annullato" in str(e):
                    raise R.Cancelled()
                raise
            try:
                with open(cf, "w", encoding="utf-8") as f:
                    json.dump(rows, f)
            except OSError:
                pass
        out += [[round(r[0] + p["t0"], 3)] + r[1:] for r in rows]
        done += p["b"] - p["a"]
    out.sort(key=lambda r: r[0])
    seen = sum(1 for r in out if r[4])
    return {"fps": fps, "pts": out, "seen": round(seen / max(1, len(out)), 3)}


def job_cutout(job, pid, path, a, b):
    """Rimuovi sfondo con l'AI su un video sopra la live: la maschera della persona (sul tuo computer, gratis)."""
    from engine import behind as BH
    proj = P.load(pid)
    known = {x.get("path") for x in proj.get("assets") or []} | {c.get("file") for t in proj.get("tracks") or [] for c in t.get("clips") or []} \
        | {proj.get("source")} | {x.get("file") for x in proj.get("inserts") or []}
    if path not in known or not os.path.isfile(path):
        raise RuntimeError("Video non trovato nel progetto")
    job.message = "Preparo il ritaglio"
    try:
        BH.ensure_model(log=lambda m: setattr(job, "message", m), cancel=lambda: job.cancelled)
    except RuntimeError as e:
        if "annullato" in str(e):
            raise R.Cancelled()
        raise
    info = probe(path)
    w0, h0 = int(info.get("width") or 1280), int(info.get("height") or 720)
    k = min(1.0, 1280 / max(w0, h0))
    W, H = max(64, int(w0 * k) // 2 * 2), max(64, int(h0 * k) // 2 * 2)
    fps = min(30.0, float(info.get("fps") or 30.0))
    a, b = max(0.0, float(a)), float(b)
    import hashlib
    key = hashlib.sha1(json.dumps([path, os.path.getmtime(path), round(a, 3), round(b, 3), W, H, fps, 3]).encode()).hexdigest()[:16]
    d = os.path.join(IMPORTS_DIR, "ritagli-ai", "cut_" + key)
    try:
        meta = json.load(open(os.path.join(d, "fatto.json"), encoding="utf-8"))
        if os.path.isfile(meta.get("mask") or ""):
            allow_picked([meta["mask"]])
            return meta
    except Exception:
        pass
    job.message = "Ritaglio la persona"
    try:
        m = BH.matte(path, a, b, d, W, H, fps, progress=lambda x: setattr(job, "progress", x), cancel=lambda: job.cancelled,
                     pngs=False, mask_w=min(W, 1280))
    except RuntimeError as e:
        if "annullato" in str(e):
            raise R.Cancelled()
        raise
    meta = {"mask": m["mask"], "fps": m["fps"], "n": m["n"], "off": round(a, 3), "dur": round(m["n"] / m["fps"], 3)}
    try:
        with open(os.path.join(d, "fatto.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f)
    except OSError:
        pass
    allow_picked([meta["mask"]])
    return meta


def job_cutout_img(job, pid, path):
    """Rimuovi sfondo con l'AI su un'immagine: una copia PNG con la persona e il resto trasparente."""
    from engine import behind as BH
    import cv2
    import numpy as np
    proj = P.load(pid)
    known = {x.get("path") for x in proj.get("assets") or []} | {c.get("file") for t in proj.get("tracks") or [] for c in t.get("clips") or []}
    if path not in known or not os.path.isfile(path):
        raise RuntimeError("Immagine non trovata nel progetto")
    job.message = "Preparo il ritaglio"
    try:
        BH.ensure_model(log=lambda m: setattr(job, "message", m), cancel=lambda: job.cancelled)
    except RuntimeError as e:
        if "annullato" in str(e):
            raise R.Cancelled()
        raise
    import hashlib
    key = hashlib.sha1(json.dumps([path, os.path.getmtime(path), 3]).encode()).hexdigest()[:16]
    d = os.path.join(IMPORTS_DIR, "ritagli-ai")
    os.makedirs(d, exist_ok=True)
    out = os.path.join(d, "img_" + key + ".png")
    if not os.path.isfile(out):
        job.message = "Ritaglio la persona"
        img = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_UNCHANGED)
        if img is None:
            raise RuntimeError("Immagine non leggibile")
        if img.ndim == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
        elif img.shape[2] == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
        al = BH.alpha_image(np.ascontiguousarray(img[..., :3]))
        if float((al > 0.5).mean()) < 0.005:
            raise RuntimeError("Non trovo una persona in questa immagine: prova con la tinta unita")
        img[..., 3] = (img[..., 3].astype(np.float32) * al).astype(np.uint8)
        ok, buf = cv2.imencode(".png", img)
        if not ok:
            raise RuntimeError("Ritaglio non riuscito")
        buf.tofile(out)
    allow_picked([out])
    return {"file": out}


def removebg_bytes(job, data):
    """Sfondo tolto (rembg, modello isnet-general-use, tutto in locale) -> PNG con trasparenza."""
    nw = 0x08000000 if sys.platform == "win32" else 0
    try:
        import rembg  # noqa: F401
    except ImportError:
        job.message = "Installo lo strumento (solo la prima volta, qualche minuto)"
        job.progress = 0.05
        r = subprocess.run([sys.executable, "-m", "pip", "install", "rembg[cpu]"], capture_output=True, creationflags=nw)
        if r.returncode != 0:
            raise RuntimeError("Installazione non riuscita: " + r.stderr.decode(errors="ignore")[-300:])
        import importlib
        importlib.invalidate_caches()
    import rembg
    if "s" not in _REMBG:
        job.message = "Preparo il modello (la prima volta lo scarico, circa 170 MB)"
        job.progress = 0.3
        _REMBG["s"] = rembg.new_session("isnet-general-use")
    job.message = "Rimuovo lo sfondo"
    job.progress = 0.7
    return rembg.remove(data, session=_REMBG["s"])


def job_design_removebg(job, gid, name, mode):
    """Grafica: sfondo tolto da un livello immagine -> nuova immagine nella grafica (l'originale resta per Annulla)."""
    src = DZ.file_path(gid, name)
    if not os.path.isfile(src):
        raise RuntimeError("Immagine non trovata nella grafica")
    with open(src, "rb") as f:
        data = f.read()
    if mode == "persona":
        # la persona (stesso modello del video): piu' preciso su chi parla in camera
        from engine import behind as BH
        import cv2
        import numpy as np
        job.message = "Preparo il ritaglio"
        BH.ensure_model(log=lambda m: setattr(job, "message", m), cancel=lambda: job.cancelled)
        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_UNCHANGED)
        if img is None:
            raise RuntimeError("Immagine non leggibile")
        if img.ndim == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
        elif img.shape[2] == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
        job.message = "Ritaglio la persona"
        al = BH.alpha_image(np.ascontiguousarray(img[..., :3]))
        if float((al > 0.5).mean()) < 0.005:
            raise RuntimeError("Non trovo una persona in questa immagine: prova con \"Oggetto\"")
        img[..., 3] = (img[..., 3].astype(np.float32) * al).astype(np.uint8)
        ok, buf = cv2.imencode(".png", img)
        out = buf.tobytes()
    else:
        out = removebg_bytes(job, data)
    nm = DZ.put_file(gid, out, "cut")
    return {"file": nm}


def job_design_ai(job, gid, prompt, kind, ratio):
    """Grafica: un'immagine creata dall'AI (sfondo a tutta tela o elemento scontornato) -> file della grafica."""
    DZ.load(gid)
    try:
        cfg = SD.pick(SD.page_defaults(), "image")
    except AI.AIError as e:
        raise RuntimeError(str(e))
    job.message = "L'AI crea l'immagine"
    job.progress = 0.15
    tmp = os.path.join(CACHE_DIR, "grafica-ai")
    os.makedirs(tmp, exist_ok=True)
    try:
        if kind == "sticker":
            path = AE.graphic(cfg, {"prompt": prompt, "place": "", "kind": ""}, tmp, False, cancel=lambda: job.cancelled)
            with open(path, "rb") as f:
                data = f.read()
            try:
                os.remove(path)
            except OSError:
                pass
        else:
            data, ext = AI.image(cfg, prompt, None, ratio=ratio if ratio in ("1:1", "16:9", "9:16") else "1:1", cancel=lambda: job.cancelled)
            if DZ._sniff(data) is None:
                import cv2
                import numpy as np
                img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_UNCHANGED)
                if img is None:
                    raise RuntimeError("Immagine non valida")
                data = cv2.imencode(".png", img)[1].tobytes()
    except AI.AIError as e:
        raise RuntimeError(str(e))
    nm = DZ.put_file(gid, data, "ai")
    w, h = DZ.image_size(DZ.file_path(gid, nm))
    ACC.track("ai.design", {"image": cfg.get("provider"), "kind": kind})
    return {"file": nm, "w": w, "h": h, "usd": AI.image_price(cfg.get("provider"), cfg.get("model"))}


def job_design_genfill(job, gid, img_name, mask_name, prompt):
    """Grafica, riempimento generativo: la zona selezionata la rifa' l'AI (o, senza AI e senza descrizione,
    la ricostruisce il computer da quello che c'e' intorno). -> pezzo di immagine con trasparenza + dove va."""
    import cv2
    import numpy as np
    img = _dz_read(gid, img_name, cv2.IMREAD_COLOR)
    m = _dz_read(gid, mask_name, cv2.IMREAD_UNCHANGED)
    a = m[..., 3] if (m.ndim == 3 and m.shape[2] == 4) else (m if m.ndim == 2 else m[..., 0])
    if a.shape[:2] != img.shape[:2]:
        a = cv2.resize(a, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_LINEAR)
    H, W = img.shape[:2]
    ys, xs = np.nonzero(a > 16)
    if not len(xs):
        raise RuntimeError("Prima seleziona la zona da riempire")
    bx0, by0, bx1, by1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    # un po' di contesto intorno (l'AI deve vedere cosa c'e' vicino), con le proporzioni di una misura che l'AI accetta
    bw, bh = bx1 - bx0, by1 - by0
    cw, ch = max(96, int(bw * 1.6)), max(96, int(bh * 1.6))
    ar = cw / ch
    size = "1536x1024" if ar > 1.25 else "1024x1536" if ar < 0.8 else "1024x1024"
    tw, th = map(int, size.split("x"))
    if cw / ch < tw / th:
        cw = int(round(ch * tw / th))
    else:
        ch = int(round(cw * th / tw))
    cw, ch = min(cw, W), min(ch, H)
    cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
    x0 = int(max(0, min(W - cw, round(cx - cw / 2))))
    y0 = int(max(0, min(H - ch, round(cy - ch / 2))))
    crop = img[y0:y0 + ch, x0:x0 + cw]
    ma = a[y0:y0 + ch, x0:x0 + cw]
    hard = (ma > 16).astype(np.uint8) * 255
    grow = max(3, int(min(cw, ch) * 0.012))
    hard_d = cv2.dilate(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (grow * 2 + 1, grow * 2 + 1)))
    usd = 0
    try:
        cfg = SD.pick(SD.page_defaults(), "image")
    except AI.AIError as e:
        cfg = None
        if prompt.strip():
            raise RuntimeError(str(e))
    if cfg is None:
        # niente AI: ricostruzione dal contorno (come il pennello correttivo)
        job.message = "Riempio con quello che c'e' intorno"
        job.progress = 0.3
        filled = cv2.inpaint(crop, hard_d, max(5, grow * 2), cv2.INPAINT_TELEA)
    else:
        job.message = "L'AI riempie la zona"
        job.progress = 0.15
        im_png = cv2.imencode(".png", cv2.resize(crop, (tw, th), interpolation=cv2.INTER_AREA))[1].tobytes()
        mk_png = cv2.imencode(".png", cv2.resize(hard_d, (tw, th), interpolation=cv2.INTER_NEAREST))[1].tobytes()
        try:
            data = AI.inpaint(cfg, im_png, mk_png, prompt, size, cancel=lambda: job.cancelled)
        except AI.AIError as e:
            raise RuntimeError(str(e))
        res = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if res is None:
            raise RuntimeError("L'AI non ha restituito un'immagine valida")
        filled = cv2.resize(res, (cw, ch), interpolation=cv2.INTER_LANCZOS4 if res.shape[1] < cw else cv2.INTER_AREA)
        usd = AI.image_price(cfg.get("provider"), cfg.get("model"))
        ACC.track("ai.design", {"image": cfg.get("provider"), "kind": "fill"})
    # solo la zona scelta (bordo morbido), il resto trasparente
    soft = cv2.GaussianBlur(hard_d.astype(np.float32), (0, 0), max(1.0, grow / 1.5))
    alpha = np.clip(np.maximum(soft, ma.astype(np.float32)), 0, 255).astype(np.uint8)
    out = np.dstack([filled, alpha])
    nm = DZ.put_file(gid, cv2.imencode(".png", out)[1].tobytes(), "fill")
    _dz_drop(gid, img_name, mask_name)
    return {"file": nm, "x": x0, "y": y0, "w": cw, "h": ch, "usd": usd, "ai": cfg is not None}


def job_design_heal(job, gid, img_name, mask_name, radius):
    """Grafica, pennello correttivo: la zona dipinta si ricostruisce da quello che c'e' intorno (OpenCV inpaint)."""
    import cv2
    import numpy as np
    ip, mp = DZ.file_path(gid, img_name), DZ.file_path(gid, mask_name)
    img = cv2.imdecode(np.fromfile(ip, np.uint8), cv2.IMREAD_UNCHANGED)
    m = cv2.imdecode(np.fromfile(mp, np.uint8), cv2.IMREAD_UNCHANGED)
    if img is None or m is None:
        raise RuntimeError("Immagine non valida")
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
    elif img.shape[2] == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
    a = m[..., 3] if m.ndim == 3 and m.shape[2] == 4 else (m if m.ndim == 2 else m[..., 0])
    if a.shape[:2] != img.shape[:2]:
        a = cv2.resize(a, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_LINEAR)
    hole = (a > 40).astype(np.uint8) * 255
    ys, xs = np.nonzero(hole)
    if not len(xs):
        raise RuntimeError("Dipingi sulla zona da correggere")
    r = max(3, int(radius))
    pad = r * 4 + 8
    x0, y0 = max(0, xs.min() - pad), max(0, ys.min() - pad)
    x1, y1 = min(img.shape[1], xs.max() + pad + 1), min(img.shape[0], ys.max() + pad + 1)
    job.message = "Correggo"
    crop = img[y0:y1, x0:x1]
    hm = cv2.dilate(hole[y0:y1, x0:x1], np.ones((3, 3), np.uint8), iterations=2)
    bgr = crop[..., :3].copy()
    fixed = cv2.inpaint(bgr, hm, r, cv2.INPAINT_TELEA)
    # un po' di grana dell'immagine intorno: la zona corretta non sembra "di plastica"
    out = np.zeros((img.shape[0], img.shape[1], 4), np.uint8)
    out[y0:y1, x0:x1, :3] = fixed
    soft = cv2.GaussianBlur(hm.astype(np.float32), (0, 0), max(1.0, r / 3))
    out[y0:y1, x0:x1, 3] = np.clip(np.maximum(soft, hm.astype(np.float32) * (crop[..., 3] / 255.0)), 0, 255).astype(np.uint8)
    ok, buf = cv2.imencode(".png", out)
    nm = DZ.put_file(gid, buf.tobytes(), "heal")
    for f in (img_name, mask_name):
        try:
            os.remove(DZ.file_path(gid, f))
        except OSError:
            pass
    return {"file": nm}


def job_design_denoise(job, gid, img_name, strength):
    """Grafica, filtro Riduci disturbo: toglie la grana (OpenCV, non locale ma veloce), la trasparenza resta."""
    import cv2
    import numpy as np
    ip = DZ.file_path(gid, img_name)
    img = cv2.imdecode(np.fromfile(ip, np.uint8), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise RuntimeError("Immagine non valida")
    if img.ndim == 2:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
    elif img.shape[2] == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)
    job.message = "Tolgo la grana"
    job.progress = 0.2
    hs = float(max(1, min(30, strength)))
    bgr = cv2.fastNlMeansDenoisingColored(np.ascontiguousarray(img[..., :3]), None, hs, hs, 7, 21)
    out = np.dstack([bgr, img[..., 3]])
    ok, buf = cv2.imencode(".png", out)
    nm = DZ.put_file(gid, buf.tobytes(), "dn")
    try:
        os.remove(ip)
    except OSError:
        pass
    return {"file": nm}


def _dz_read(gid, name, flags):
    import cv2
    import numpy as np
    img = cv2.imdecode(np.fromfile(DZ.file_path(gid, name), np.uint8), flags)
    if img is None:
        raise RuntimeError("Immagine non valida")
    return img


def _dz_drop(gid, *names):
    for f in names:
        try:
            os.remove(DZ.file_path(gid, f))
        except (OSError, ValueError):
            pass


def job_design_quicksel(job, gid, img_name, m_name):
    """Grafica, selezione rapida: si dipinge sull'oggetto e la selezione si allarga fino ai bordi (OpenCV GrabCut).
    Maschera in ingresso: rosso = da aggiungere, verde = da togliere, blu = selezione di adesso."""
    import cv2
    import numpy as np
    img = _dz_read(gid, img_name, cv2.IMREAD_COLOR)
    m = _dz_read(gid, m_name, cv2.IMREAD_UNCHANGED)
    if m.ndim != 3 or m.shape[2] < 3:
        raise RuntimeError("Maschera non valida")
    if m.shape[:2] != img.shape[:2]:
        m = cv2.resize(m, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_NEAREST)
    alpha = m[..., 3] if m.shape[2] == 4 else np.full(m.shape[:2], 255, np.uint8)
    fg = (m[..., 2] > 127) & (alpha > 127)      # BGR: il rosso e' il canale 2
    bg = (m[..., 1] > 127) & (alpha > 127)
    cur = (m[..., 0] > 127) & (alpha > 127)
    h, w = img.shape[:2]
    if not fg.any() and not bg.any():
        raise RuntimeError("Dipingi sulla parte da selezionare")
    job.message = "Trovo i bordi"
    job.progress = 0.2
    seed = (fg | cur).astype(np.uint8)
    grow = max(15, int(0.15 * (h * h + w * w) ** 0.5))
    roi = cv2.dilate(seed, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (grow * 2 + 1, grow * 2 + 1))) > 0
    mask = np.full((h, w), cv2.GC_BGD, np.uint8)
    mask[roi] = cv2.GC_PR_BGD
    mask[cur] = cv2.GC_PR_FGD
    mask[fg] = cv2.GC_FGD
    mask[bg] = cv2.GC_BGD
    if not (mask == cv2.GC_FGD).any() and not (mask == cv2.GC_PR_FGD).any():
        out = np.zeros((h, w), np.uint8)
    else:
        bgm, fgm = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
        try:
            cv2.grabCut(img, mask, None, bgm, fgm, 4, cv2.GC_INIT_WITH_MASK)
        except cv2.error:
            pass
        out = ((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD)).astype(np.uint8)
        # solo i pezzi collegati a dove si e' dipinto (o alla selezione di prima)
        n, lab = cv2.connectedComponents(out)
        keep = np.zeros(n, bool)
        keep[np.unique(lab[(fg | (cur & ~bg)) & (out > 0)])] = True
        keep[0] = False
        out = keep[lab].astype(np.uint8) * 255
        out = cv2.morphologyEx(out, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    rgba = np.zeros((h, w, 4), np.uint8)
    rgba[..., :3] = 255
    rgba[..., 3] = out
    ok, buf = cv2.imencode(".png", rgba)
    nm = DZ.put_file(gid, buf.tobytes(), "qsel")
    _dz_drop(gid, img_name, m_name)
    return {"file": nm}


def _guided(I, p, r, eps):
    import cv2
    k = (2 * r + 1, 2 * r + 1)
    mI = cv2.boxFilter(I, -1, k)
    mp = cv2.boxFilter(p, -1, k)
    cov = cv2.boxFilter(I * p, -1, k) - mI * mp
    var = cv2.boxFilter(I * I, -1, k) - mI * mI
    a = cov / (var + eps)
    b = mp - a * mI
    return cv2.boxFilter(a, -1, k) * I + cv2.boxFilter(b, -1, k)


def job_design_refine(job, gid, img_name, m_name, radius, smooth, contrast):
    """Grafica, Migliora bordo: capelli e pelo. Vicino al bordo la selezione segue i dettagli dell'immagine (filtro guidato)."""
    import cv2
    import numpy as np
    img = _dz_read(gid, img_name, cv2.IMREAD_COLOR)
    m = _dz_read(gid, m_name, cv2.IMREAD_UNCHANGED)
    a = m[..., 3] if (m.ndim == 3 and m.shape[2] == 4) else (m if m.ndim == 2 else m[..., 0])
    if a.shape[:2] != img.shape[:2]:
        a = cv2.resize(a, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_LINEAR)
    job.message = "Miglioro il bordo"
    job.progress = 0.2
    p = a.astype(np.float32) / 255.0
    hard = (p > 0.5).astype(np.uint8)
    r = max(1, int(radius))
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
    band = (cv2.dilate(hard, ker) > 0) & ~(cv2.erode(hard, ker) > 0)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32) / 255.0
    eps = 10 ** (-4 + 2.5 * max(0.0, min(1.0, smooth)))
    gr = max(2, r // 2)
    # guida a colori semplice: media dei canali Lab filtrati (L pesa di piu')
    q = 0.6 * _guided(lab[..., 0], p, gr, eps) + 0.2 * _guided(lab[..., 1], p, gr, eps) + 0.2 * _guided(lab[..., 2], p, gr, eps)
    q = np.clip(q, 0, 1)
    if contrast:
        c = 1 + 4 * max(0.0, min(1.0, contrast))
        q = np.clip((q - 0.5) * c + 0.5, 0, 1)
    out = p.copy()
    out[band] = q[band]
    rgba = np.zeros(img.shape[:2] + (4,), np.uint8)
    rgba[..., :3] = 255
    rgba[..., 3] = np.clip(out * 255 + 0.5, 0, 255).astype(np.uint8)
    ok, buf = cv2.imencode(".png", rgba)
    nm = DZ.put_file(gid, buf.tobytes(), "refine")
    _dz_drop(gid, img_name, m_name)
    return {"file": nm}


def job_removebg(job, path):
    """Toglie lo sfondo da un'immagine (rembg, tutto in locale). La prima volta installa lo strumento e scarica il modello."""
    nw = 0x08000000 if sys.platform == "win32" else 0
    try:
        import rembg  # noqa: F401
    except ImportError:
        job.message = "Installo lo strumento (solo la prima volta, qualche minuto)"
        job.progress = 0.05
        r = subprocess.run([sys.executable, "-m", "pip", "install", "rembg[cpu]"], capture_output=True, creationflags=nw)
        if r.returncode != 0:
            raise RuntimeError("Installazione non riuscita: " + r.stderr.decode(errors="ignore")[-300:])
        import importlib
        importlib.invalidate_caches()
    import rembg
    if "s" not in _REMBG:
        job.message = "Preparo il modello (la prima volta lo scarico, circa 170 MB)"
        job.progress = 0.3
        _REMBG["s"] = rembg.new_session("isnet-general-use")
    job.message = "Rimuovo lo sfondo"
    job.progress = 0.7
    with open(path, "rb") as f:
        data = rembg.remove(f.read(), session=_REMBG["s"])
    base = os.path.splitext(os.path.basename(path))[0]
    os.makedirs(IMPORTS_DIR, exist_ok=True)
    out = os.path.join(IMPORTS_DIR, f"{base} (senza sfondo).png")
    i = 2
    while os.path.exists(out):
        out = os.path.join(IMPORTS_DIR, f"{base} (senza sfondo {i}).png")
        i += 1
    with open(out, "wb") as f:
        f.write(data)
    return media_info(out)


def fix_rotated(proj):
    """Progetti creati prima: i video del telefono (girati nei metadati) avevano le misure in orizzontale.
    Si correggono una volta sola: video inseriti, media e video sopra (cosi' il riquadro e' della forma giusta)."""
    seen = {}

    def dims(path):
        if path not in seen:
            try:
                pi = probe(path) if path and os.path.isfile(path) else {}
            except Exception:
                pi = {}
            seen[path] = (pi.get("width"), pi.get("height"), pi.get("rotation") or 0)
        return seen[path]
    for i in proj.get("inserts") or []:
        if i.get("gap") or i.get("live") or i.get("image"):
            continue
        w_, h_, rot = dims(i.get("file"))
        if rot and w_ and h_:
            i["w"], i["h"] = w_, h_
    for a in proj.get("assets") or []:
        if a.get("kind") == "video":
            w_, h_, rot = dims(a.get("path"))
            if rot and w_ and h_:
                a["w"], a["h"] = w_, h_
    for t in proj.get("tracks") or []:
        for c in t.get("clips") or []:
            if c.get("kind") == "video" and c.get("file"):
                w_, h_, rot = dims(c["file"])
                if rot and w_ and h_:
                    c["ar"] = round(h_ / w_, 6)
    if (proj.get("kind") or "vod") in ("vod", "video") and proj.get("source"):
        w_, h_, rot = dims(proj["source"])
        if rot and w_ and h_ and (proj.get("width"), proj.get("height")) == (h_, w_):
            proj["width"], proj["height"] = w_, h_
    proj["rotChecked"] = True
    return proj


LIBRARY_DIR = os.path.join(IMPORTS_DIR, "libreria")   # la mia libreria: media da usare in tutti i progetti


def library_list():
    out = []
    try:
        names = sorted(os.listdir(LIBRARY_DIR), key=lambda n: -os.path.getmtime(os.path.join(LIBRARY_DIR, n)))
    except OSError:
        return out
    for fn in names:
        fp = os.path.join(LIBRARY_DIR, fn)
        if not os.path.isfile(fp) or fn.startswith("."):
            continue
        try:
            out.append(media_info(fp))
        except Exception:
            continue
    return out


def library_add(path):
    """Copia un file dei Media nella libreria (se c'e' gia' lo stesso file, non lo duplica)."""
    if not os.path.isfile(path) or not allowed_media(path):
        raise ValueError("File non trovato")
    os.makedirs(LIBRARY_DIR, exist_ok=True)
    name = re.sub(r'[\\/:*?"<>|]+', "_", os.path.basename(path))
    dest = os.path.join(LIBRARY_DIR, name)
    size = os.path.getsize(path)
    stem, ext = os.path.splitext(dest)
    i = 2
    while os.path.exists(dest):
        if os.path.getsize(dest) == size:
            return media_info(dest)   # gia' in libreria
        dest = f"{stem} ({i}){ext}"
        i += 1
    shutil.copy2(path, dest)
    return media_info(dest)


def source_replaced(pid, pp):
    """Il file del VOD e' stato sostituito sul PC (stesso nome, video diverso) dopo che abbiamo fatto l'anteprima?
    Allora l'anteprima mostrerebbe il video vecchio e l'esportazione quello nuovo: si butta la cache e si avvisa."""
    try:
        if not os.path.exists(pp):
            return None
        proj = P.load(pid)
        src = proj.get("source") or ""
        if not os.path.isfile(src) or os.path.getmtime(src) <= os.path.getmtime(pp) + 2:
            return None
        dur = float(probe(src).get("duration") or 0)
        old = float(proj.get("duration") or 0)
        print(f"[app] il VOD del progetto {pid} e' cambiato sul PC (durata {dur:.1f}s, progetto {old:.1f}s): rifaccio l'anteprima", flush=True)
        for f in os.listdir(os.path.dirname(pp)):
            if f.startswith(ckey(pid) + "_") and "_ins_" not in f:
                try:
                    os.remove(os.path.join(os.path.dirname(pp), f))
                except OSError:
                    pass
        shutil.rmtree(os.path.join(CACHE_DIR, "thumbs", ckey(pid)), ignore_errors=True)
        return {"name": os.path.basename(src), "dur": dur, "projDur": old, "different": abs(dur - old) > 1.5}
    except Exception:
        traceback.print_exc()
        return None


# copie leggere dei video in sovrimpressione (video AI, clip aggiunte): 720p, un keyframe ogni 1/3 di secondo.
# Il file originale (1080p, bitrate alto) a scatti nell'anteprima: si vede il primo fotogramma fermo o un nero al cambio.
_LIGHT = {}
_LIGHT_LOCK = threading.Lock()
_LIGHT_SEM = threading.Semaphore(2)


def light_path(src):
    return os.path.join(CACHE_DIR, "proxy", f"ov_{clip_key(src)}.mp4")


def light_copy(src, start=True):
    """Percorso della copia leggera se pronta, altrimenti None (e la prepara in sottofondo)."""
    if os.environ.get("NOONFRAME_TEST_WEBM"):   # solo test automatici: il browser dei test non legge H.264
        return None
    out = light_path(src)
    if os.path.exists(out):
        return out
    if not start:
        return None
    with _LIGHT_LOCK:
        if _LIGHT.get(out) in ("busy", "err"):
            return None
        _LIGHT[out] = "busy"
    threading.Thread(target=_make_light, args=(src, out), daemon=True).start()
    return None


def _make_light(src, out):
    with _LIGHT_SEM:
        part = out + ".part.mp4"
        try:
            os.makedirs(os.path.dirname(out), exist_ok=True)
            info = probe(src)
            fps = min(30.0, info.get("fps") or 30.0)
            hh = min(720, int(info.get("height") or 720))
            hh -= hh % 2
            g = str(max(2, int(round(fps / 3))))
            cmd = [ffmpeg_bin(), "-v", "error", "-y", "-i", src, "-map", "0:v:0", "-vf", f"fps={fps:g},scale=-2:{hh}",
                   "-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-g", g, "-keyint_min", g, "-sc_threshold", "0",
                   "-tune", "fastdecode", "-pix_fmt", "yuv420p"]
            if info.get("has_audio"):
                cmd += ["-map", "0:a:0", "-c:a", "aac", "-b:a", "128k", "-ac", "2"]
            cmd += ["-movflags", "+faststart", part]
            r = subprocess.run(cmd, capture_output=True, stdin=subprocess.DEVNULL, creationflags=NO_WINDOW | (0x4000 if sys.platform == "win32" else 0))
            if r.returncode != 0 or not os.path.exists(part):
                raise RuntimeError(r.stderr.decode(errors="ignore")[-300:])
            replace_retry(part, out)
            with _LIGHT_LOCK:
                _LIGHT.pop(out, None)
        except Exception as e:
            print("[anteprima leggera] non riuscita:", os.path.basename(src), str(e)[:200], flush=True)
            with _LIGHT_LOCK:
                _LIGHT[out] = "err"
            try:
                os.remove(part)
            except OSError:
                pass


PROXY_AF = "aresample=async=1:first_pts=0"


def proxy_path(pid, h):
    return os.path.join(CACHE_DIR, "proxy", f"{ckey(pid)}_{int(h)}_k.mp4")   # _k: keyframe fitti (salti sui tagli istantanei)


def job_proxy(job, pid, h):
    """Copia leggera del VOD per l'anteprima (qualita' scelta, max 30 fps, un keyframe ogni 6 fotogrammi: cosi' saltare
    le parti tagliate durante la riproduzione e' istantaneo)."""
    proj = P.load(pid)
    out = proxy_path(pid, h)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    part = out + ".part.mp4"
    fps = min(30.0, proj.get("fps") or 30.0)
    g = "6"
    vf = f"fps={fps:g},scale=-2:{int(h)}"
    base = [ffmpeg_bin(), "-v", "error", "-y", "-i", proj["source"], "-map", "0:v:0", "-map", "0:a:0?", "-vf", vf]
    tail = ["-t", f"{P.live_duration(proj) + 0.5:.3f}",   # mai piu' lunga della live (file con tempi rovinati)
            # audio che parte qualche ms dopo il video (OBS, .mkv): senza riallinearlo a zero il primo pacchetto
            # ha un tempo negativo "storto" e l'anteprima dell'app si blocca (PIPELINE_ERROR_DECODE)
            "-af", PROXY_AF, "-c:a", "aac", "-b:a", "128k", "-ac", "2", "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", part]
    encs = []
    if proxy_gpu_args(g):
        encs.append(proxy_gpu_args(g))
    encs.append(["-c:v", "libx264", "-preset", "ultrafast", "-crf", "27", "-g", g, "-tune", "fastdecode", "-pix_fmt", "yuv420p"])
    dur = max(0.1, P.live_duration(proj))
    err = ""
    for enc in encs:
        job.message = "Preparo l'anteprima leggera"
        # priorita' bassa: la copia per l'anteprima non deve rallentare il resto del PC
        pr = subprocess.Popen(base + enc + tail, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              creationflags=NO_WINDOW | (0x4000 if sys.platform == "win32" else 0))
        for line in pr.stdout:
            if job.cancelled:
                pr.kill()
                raise R.Cancelled()
            m = re.match(rb"out_time_(?:us|ms)=(\d+)", line)
            if m:
                job.progress = min(0.99, int(m.group(1)) / 1e6 / dur)
        pr.wait()
        if pr.returncode == 0:
            replace_retry(part, out)
            return {"path": out}
        err = pr.stderr.read().decode(errors="ignore")[-300:]
    raise RuntimeError(media_problem(err) or ("Anteprima leggera non riuscita: " + err))


def job_montage(job, pid, keep):
    """Anteprima fluida: un video con solo le parti tenute, una dopo l'altra (niente salti durante la riproduzione).
    keep = [[a, b], ...] in tempi della live. Le parti si allineano ai fotogrammi (fps fisso), cosi' la mappa
    tempo della timeline <-> tempo di questo video e' esatta: la calcola l'editor con i fotogrammi restituiti."""
    import hashlib
    proj = P.load(pid)
    fps = min(30.0, float(proj.get("fps") or 30.0))
    fps = 30.0 if fps > 29 else (25.0 if fps > 24.5 else 24.0)
    live_d = P.live_duration(proj)
    fr = []
    for a, b in keep:
        A, B = int(math.ceil(max(0.0, a) * fps - 1e-6)), int(math.ceil(min(live_d, b) * fps - 1e-6))
        if B - A >= 1:
            if fr and A <= fr[-1][1]:
                fr[-1][1] = max(fr[-1][1], B)
            else:
                fr.append([A, B])
    if not fr:
        raise RuntimeError("Non c'e' niente da mostrare: tutto il video e' tagliato")
    key = hashlib.sha1(json.dumps([proj["source"], fps, fr]).encode()).hexdigest()[:16]
    webm = bool(os.environ.get("NOONFRAME_TEST_WEBM"))   # solo per i test automatici (browser senza H.264)
    out = os.path.join(CACHE_DIR, "proxy", f"{ckey(pid)}_mont_{key}." + ("webm" if webm else "mp4"))
    res = {"path": out, "fps": fps, "frames": fr, "key": key}
    allow_picked([out])   # l'editor la puo' aprire
    if os.path.exists(out):
        return res
    os.makedirs(os.path.dirname(out), exist_ok=True)
    h = int(proj.get("height") or 720)
    h = min(720, h) - (min(720, h) % 2)
    sel = "+".join(f"between(n,{A},{B - 1})" for A, B in fr)
    asel = "+".join(f"between(t,{A / fps:.6f},{B / fps - 1e-6:.6f})" for A, B in fr)
    flt = (f"[0:v]fps={fps:g},select='{sel}',setpts=N/({fps:g}*TB),scale=-2:{h}[v]"
           + (f";[0:a]aselect='{asel}',asetpts=N/SR/TB[a]" if proj.get("hasAudio", True) else ""))
    script = out + ".filtro.txt"
    with open(script, "w", encoding="utf-8") as f:
        f.write(flt)
    part = out + (".part.webm" if webm else ".part.mp4")
    total = sum(B - A for A, B in fr) / fps
    has_a = proj.get("hasAudio", True)
    cmd = [ffmpeg_bin(), "-v", "error", "-y", "-i", proj["source"], "-filter_complex_script", script, "-map", "[v]"] + \
          (["-map", "[a]", "-c:a", "libvorbis" if webm else "aac", "-b:a", "128k", "-ac", "2"] if has_a else []) + \
          (["-c:v", "libvpx", "-deadline", "realtime", "-b:v", "2M"] if webm else
           ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "26", "-g", "30", "-tune", "fastdecode", "-pix_fmt", "yuv420p", "-movflags", "+faststart"]) + \
          ["-progress", "pipe:1", "-nostats", part]
    job.message = "Preparo l'anteprima fluida"
    for attempt in (0, 1):
        pr = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              creationflags=NO_WINDOW | (0x4000 if sys.platform == "win32" else 0))
        for line in pr.stdout:
            if job.cancelled:
                pr.kill()
                raise R.Cancelled()
            m = re.match(rb"out_time_(?:us|ms)=(\d+)", line)
            if m:
                job.progress = min(0.99, int(m.group(1)) / 1e6 / max(0.1, total))
        pr.wait()
        if pr.returncode == 0 or attempt:
            break
        # ffmpeg recenti: l'opzione per leggere il filtro da file si scrive diversamente
        i = cmd.index("-filter_complex_script")
        cmd[i:i + 2] = ["-/filter_complex", script]
    try:
        os.remove(script)
    except OSError:
        pass
    if pr.returncode != 0:
        err = pr.stderr.read().decode(errors="ignore")[-300:]
        raise RuntimeError(media_problem(err) or ("Anteprima fluida non riuscita: " + err))
    replace_retry(part, out)
    # le anteprime fluide vecchie di questo progetto non servono piu'
    for f in os.listdir(os.path.dirname(out)):
        if f.startswith(f"{ckey(pid)}_mont_") and f.endswith((".mp4", ".webm")) and os.path.join(os.path.dirname(out), f) != out:
            try:
                os.remove(os.path.join(os.path.dirname(out), f))
            except OSError:
                pass
    return res


# file che si possono aprire con il programma predefinito (tutto il resto si mostra solo nella cartella)
OPEN_OK = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi", ".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg",
           ".png", ".jpg", ".jpeg", ".webp", ".gif", ".srt", ".vtt", ".txt", ".pdf"}


def open_path(path, reveal=False):
    if not path or not os.path.exists(path):
        return False
    # mai eseguire programmi o collegamenti (.exe, .bat, .lnk, .app, .command...): al massimo si mostra il file
    if not reveal and not os.path.isdir(path) and os.path.splitext(path)[1].lower() not in OPEN_OK:
        reveal = True
    if not reveal and os.path.isdir(path) and sys.platform == "darwin" and path.rstrip("/").lower().endswith(".app"):
        reveal = True
    if sys.platform == "win32":
        if reveal:
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        else:
            os.startfile(path)  # noqa
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", path] if reveal else ["open", path])
    else:
        subprocess.Popen(["xdg-open", os.path.dirname(path) if reveal else path])
    return True


_MEDIA_CACHE = {}  # file progetto -> (mtime, set di file consentiti)


PICKED = set()   # file scelti dall'utente in questa sessione (anteprime prima di creare il progetto)


def allow_picked(paths):
    for x in paths or []:
        if x:
            PICKED.add(os.path.normcase(os.path.abspath(x)))


def allowed_media(path):
    """Solo file che fanno parte di un progetto (niente accesso libero al disco)."""
    key = os.path.normcase(os.path.abspath(path))
    if key in PICKED:
        return True
    if key.startswith(os.path.normcase(os.path.abspath(IMPORTS_DIR)) + os.sep):
        return True
    # immagini e voci delle Storie AI e foto dei personaggi (solo file media)
    for d in (SD.PAGES_DIR, SD.STORIES_DIR, FMT.FORMATS_DIR):
        if key.startswith(os.path.normcase(os.path.abspath(d)) + os.sep) and key.endswith((".png", ".jpg", ".jpeg", ".webp", ".mp3", ".wav", ".mp4", ".m4a")):
            return True
    if key.startswith(os.path.normcase(os.path.abspath(os.path.join(CACHE_DIR, "proxy"))) + os.sep) and key.endswith(".mp4"):
        return True
    for fn in os.listdir(P.PROJECTS_DIR):
        if not fn.endswith(".json"):
            continue
        fp = os.path.join(P.PROJECTS_DIR, fn)
        try:
            mt = os.path.getmtime(fp)
            cached = _MEDIA_CACHE.get(fp)
            if not cached or cached[0] != mt:
                with open(fp, encoding="utf-8") as f:
                    pj = json.load(f)
                files = [pj.get("source")] + [c.get("file") for t in pj.get("tracks", []) for c in t.get("clips", [])]
                files += [a.get("path") for a in pj.get("assets", [])]
                files += [ln.get("file") for ln in (pj.get("story") or {}).get("lines", [])]
                files += [(ln.get("video") or {}).get("file") for ln in (pj.get("story") or {}).get("lines", [])]
                files.append(((pj.get("story") or {}).get("music") or {}).get("file"))
                files += [i.get(k) for i in pj.get("inserts") or [] for k in ("file", "preview")]
                if pj.get("lastExport"):
                    files.append(pj["lastExport"].get("path"))
                cached = (mt, {os.path.normcase(os.path.abspath(x)) for x in files if x})
                _MEDIA_CACHE[fp] = cached
        except Exception:
            continue
        if key in cached[1]:
            return True
    return False


def cover(pid):
    """Copertina del progetto per la home: un fotogramma che rappresenta davvero il video (non il nero di base
    dei progetti vuoti e delle storie)."""
    proj = P.load_any(pid)
    d = os.path.join(CACHE_DIR, "covers")
    os.makedirs(d, exist_ok=True)
    fn = os.path.join(d, f"{pid}_{int(proj.get('updated') or 0)}.jpg")
    if os.path.exists(fn):
        return fn
    for old in os.listdir(d):   # copertine vecchie dello stesso progetto
        if old.startswith(pid + "_"):
            try:
                os.remove(os.path.join(d, old))
            except OSError:
                pass
    kind = proj.get("kind") or "vod"
    src, t = None, 0.0
    if kind in ("blank", "story"):
        ins = [i for i in proj.get("inserts") or [] if not i.get("gap") and not i.get("live")]
        segs = [c for c in proj.get("segs") or [] if not c.get("gone") and c.get("ins")]
        first = None
        for c in sorted(segs, key=lambda x: x["a"]):
            first = next((i for i in ins if i["id"] == c["ins"]), None)
            if first:
                break
        if first and os.path.exists(first.get("file", "")):
            src, t = first["file"], (first.get("offset") or 0) + min(1.0, first["dur"] / 2)
        else:
            clips = [c for tr in proj.get("tracks") or [] if tr.get("type") == "overlay" for c in tr.get("clips") or []
                     if not c.get("isText") and c.get("file") and os.path.exists(c["file"])]
            clips.sort(key=lambda c: c["a"])
            if clips:
                src, t = clips[0]["file"], (clips[0].get("offset") or 0) + 0.5
    if src:
        is_img = src.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"))
        cmd = [ffmpeg_bin(), "-v", "error", "-y"] + ([] if is_img else ["-ss", f"{t:.2f}"]) + ["-i", src, "-frames:v", "1",
               "-vf", "scale=-2:360", "-q:v", "4", fn]
        subprocess.run(cmd, creationflags=NO_WINDOW)
        return fn if os.path.exists(fn) else None
    if kind in ("blank", "story"):
        return None
    try:
        tp = thumb(pid, min(30.0, max(0.0, proj["duration"] / 3)), 360)
        shutil.copyfile(tp, fn)
        return fn
    except Exception:
        return None


def thumb(pid, t, h):
    proj = P.load(pid)
    d = os.path.join(CACHE_DIR, "thumbs", ckey(pid))
    os.makedirs(d, exist_ok=True)
    m = P.piece_at(proj, t)
    st = max(0.0, m["off"] + t - m["t0"])   # istante dentro al file (la live o un video inserito)
    key = "live" if m["live"] else m["ins"]["id"]
    fn = os.path.join(d, f"{key}_{int(st * 10)}_{h}.jpg")
    if not os.path.exists(fn):
        subprocess.run([ffmpeg_bin(), "-v", "error", "-y", "-ss", f"{st:.2f}", "-i", m["file"],
                        "-frames:v", "1", "-vf", f"scale=-2:{h}", "-q:v", "5", fn], creationflags=NO_WINDOW)
    return fn


def strip_dir(pid):
    """Miniature della live (i video inseriti usano le loro, al volo)."""
    return os.path.join(CACHE_DIR, "thumbs", ckey(pid), "src_live")


def _live_strip(pid, proj=None):
    """(cartella, intervallo, file) delle miniature della live, o None se non sono pronte."""
    d = strip_dir(pid)
    old = os.path.join(CACHE_DIR, "thumbs", ckey(pid), "strip")
    if not os.path.exists(os.path.join(d, "done.txt")) and os.path.exists(os.path.join(old, "done.txt")):
        # versioni prima: la striscia vecchia era della live (senza video inseriti): si tiene
        proj = proj or P.load(pid)
        if not proj.get("inserts"):
            try:
                with open(os.path.join(old, "done.txt")) as f:
                    v = f.read().strip()
                iv = float(v) if v not in ("", "ok") else max(1.0, round(P.live_duration(proj) / 300.0, 2))
                os.replace(old, d)
                with open(os.path.join(d, "done.txt"), "w") as f:
                    f.write(str(iv))
            except (OSError, ValueError):
                pass
    if not os.path.exists(os.path.join(d, "done.txt")):
        return None
    ent = _STRIP_CACHE.get(d)
    mt = os.path.getmtime(os.path.join(d, "done.txt"))
    if not ent or ent[0] != mt:
        with open(os.path.join(d, "done.txt")) as f:
            try:
                iv = float(f.read().strip())
            except ValueError:
                iv = 1.0
        ent = (mt, iv, sorted(x for x in os.listdir(d) if x.endswith(".jpg")))
        _STRIP_CACHE[d] = ent
    return d, ent[1], ent[2]


_STRIP_CACHE = {}


def strip_info(pid, dur):
    interval = max(1.0, round(dur / 300.0, 2))  # al massimo ~300 miniature sulla timeline
    ls = _live_strip(pid)
    return {"ready": bool(ls), "interval": interval, "count": int(dur // interval) + 1, "liveIv": ls[1] if ls else 1.0}


_FSTRIP_BUSY = set()


def file_strip(path):
    """Miniature di un video a intervalli fissi, fatte una volta sola in un colpo (poi le clip si spostano e le
    miniature sono gia' pronte). Ritorna (cartella, intervallo, file) o None se non ancora pronte (e le prepara)."""
    d = os.path.join(CACHE_DIR, "fstrip", re.sub(r"\W", "_", os.path.abspath(path))[-100:])
    done = os.path.join(d, "done.txt")
    if os.path.exists(done):
        ent = _STRIP_CACHE.get(d)
        mt = os.path.getmtime(done)
        if not ent or ent[0] != mt:
            with open(done) as f:
                iv = float(f.read().strip() or 1)
            ent = (mt, iv, sorted(x for x in os.listdir(d) if x.endswith(".jpg")))
            _STRIP_CACHE[d] = ent
        return d, ent[1], ent[2]
    if d in _FSTRIP_BUSY:
        return None
    _FSTRIP_BUSY.add(d)

    def work():
        try:
            dur = float(probe(path).get("duration") or 0)
            iv = max(1.0, round(dur / 300.0, 2))
            os.makedirs(d, exist_ok=True)
            # solo i keyframe (come le miniature della live): molte volte piu' veloce sui video del telefono in 4K
            cmd = [ffmpeg_bin(), "-nostdin", "-v", "error", "-y", "-skip_frame", "nokey", "-i", path, "-an", "-vf", f"fps=1/{iv:g},scale=-2:120",
                   "-q:v", "6", os.path.join(d, "t%05d.jpg")]
            subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, creationflags=NO_WINDOW)
            if len([x for x in os.listdir(d) if x.endswith(".jpg")]) < max(1, int(dur / iv) // 2):   # keyframe troppo radi: tutti i fotogrammi
                cmd.remove("-skip_frame"); cmd.remove("nokey")
                subprocess.run(cmd, stdin=subprocess.DEVNULL, capture_output=True, creationflags=NO_WINDOW)
            with open(done, "w") as f:
                f.write(str(iv))
        except Exception as e:
            print(f"[miniature] {e}", flush=True)
        finally:
            _FSTRIP_BUSY.discard(d)
    threading.Thread(target=work, daemon=True).start()
    return None


def file_tile(path, st):
    fs = file_strip(path)
    if fs and fs[2]:
        d, iv, files = fs
        return os.path.join(d, files[max(0, min(len(files) - 1, int(st / iv)))])
    return media_thumb(path, round(max(0.0, st)), 120)   # intanto una sola, al volo


def source_tile(pid, src, st):
    """Miniatura di un punto di un file (la live o un video inserito): non dipende da dove sta la clip sulla
    timeline, cosi' spostando le clip le miniature restano quelle (niente da ricaricare)."""
    if src == "live":
        ls = _live_strip(pid)
        if not ls or not ls[2]:
            return None
        d, siv, files = ls
        return os.path.join(d, files[max(0, min(len(files) - 1, int(round(st / siv))))])
    rec = next((i for i in P.load(pid).get("inserts") or [] if i.get("id") == src), None)
    if not rec or rec.get("gap") or not os.path.exists(rec.get("file", "")):
        return None
    return media_thumb(rec["file"], round(max(0.0, st), 1), 120)


def strip_tile(pid, i):
    """Miniatura numero i della timeline: dalla live o dal video inserito che c'e' in quel punto."""
    proj = P.load(pid)
    iv = max(1.0, round(proj["duration"] / 300.0, 2))
    t = i * iv
    m = P.piece_at(proj, t)
    st = max(0.0, m["off"] + t - m["t0"])
    if m["live"]:
        ls = _live_strip(pid, proj)
        if not ls or not ls[2]:
            return None
        d, siv, files = ls
        return os.path.join(d, files[max(0, min(len(files) - 1, int(round(st / siv))))])
    f = m["ins"].get("file")
    return media_thumb(f, round(st, 1), 120) if f and os.path.exists(f) else None


def job_thumbs(job, pid):
    """Tutte le miniature della live in una sola passata (solo keyframe: velocissimo)."""
    proj = P.load(pid)
    d = strip_dir(pid)
    iv = max(1.0, round(P.live_duration(proj) / 300.0, 2))
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d, exist_ok=True)
    cmd = [ffmpeg_bin(), "-v", "error", "-y", "-skip_frame", "nokey", "-i", proj["source"], "-an",
           "-vf", f"fps=1/{iv},scale=-2:120", "-fps_mode", "vfr", "-q:v", "6", os.path.join(d, "%05d.jpg")]
    r = subprocess.run(cmd, creationflags=NO_WINDOW, capture_output=True)
    if r.returncode != 0:  # ffmpeg vecchi: -vsync al posto di -fps_mode
        cmd[cmd.index("-fps_mode")] = "-vsync"
        subprocess.run(cmd, creationflags=NO_WINDOW, capture_output=True)
    with open(os.path.join(d, "done.txt"), "w") as f:
        f.write(str(iv))
    return strip_info(pid, proj["duration"])


LICENSE_VER = "1.0"


def license_ok():
    """Licenza accettata: nell'installer (file segnaposto) o nell'app, la prima volta."""
    return load_settings().get("licenza") == LICENSE_VER or os.path.exists(os.path.join(APP_DIR, "licenza-accettata.txt"))


def env_info():
    return {"version": VERSION, "ffmpeg": bool(shutil.which("ffmpeg")), "gpu": nvenc_ok(),
            "whisper": T.available(), "ytdlp": _has("yt_dlp"), "exportsDir": EXPORTS_DIR, "appDir": APP_DIR,
            "licenseOk": license_ok(), "licenseVer": LICENSE_VER, "badges": load_settings().get("badges") or {},
            "autoUpdate": load_settings().get("autoUpdate") is not False, "platform": UPD.PLATFORM,
            "channel": "beta" if load_settings().get("updateChannel") == "beta" else "stable", "beta": ACC.beta_access() is True, "account": ACC.status()}


def _has(mod):
    try:
        __import__(mod)
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ HTTP
MIME = {".js": "text/javascript", ".css": "text/css", ".html": "text/html", ".json": "application/json",
        ".mp4": "video/mp4", ".m4v": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm", ".mkv": "video/x-matroska",
        ".m4a": "audio/mp4", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".ogg": "audio/ogg", ".flac": "audio/flac",
        ".aac": "audio/aac", ".jpg": "image/jpeg", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon"}


class H(BaseHTTPRequestHandler):
    server_version = "NoonFrame"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *a):
        # diagnostica leggera: registra le richieste (tranne quelle continue)
        try:
            line = re.sub(r"token=[0-9a-fA-F]+", "token=***", fmt % a)
            if "/api/ping" not in line and "/api/jobs/" not in line and "/tile" not in line and "/stile" not in line:
                print(f"[http] {time.strftime('%H:%M:%S')} {self.server.server_address[1]} {line[:160]}", flush=True)
        except Exception:
            pass

    # --- risposte
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
            pass  # la finestra ha cambiato pagina prima della risposta

    def err(self, msg, code=400):
        self.send_json({"error": msg}, code)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not n:
            return {}
        return json.loads(self.rfile.read(n).decode("utf-8"))

    def send_file(self, path, ctype=None, cache=False, nostore=False, headers=None):
        if not os.path.isfile(path):
            return self.err("non trovato", 404)
        size = os.path.getsize(path)
        # tabella fissa: su Windows il registro puo' dire .js = text/plain (pagina bianca)
        ctype = ctype or MIME.get(os.path.splitext(path)[1].lower()) or mimetypes.guess_type(path)[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    if m.group(2):
                        end = min(size - 1, int(m.group(2)))
                elif m.group(2):
                    start = max(0, size - int(m.group(2)))
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        else:
            self.send_response(200)
        length = end - start + 1
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store" if nostore else ("max-age=3600" if cache else "no-cache"))
        for hk, hv in (headers or {}).items():
            self.send_header(hk, hv)
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(path, "rb") as f:
            f.seek(start)
            left = length
            try:
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except OSError:
                # il lettore video ha chiuso la richiesta (salto in un altro punto): normale, anche su Mac (errore 55)
                pass

    def account_post(self, what, data):
        try:
            if what == "email":
                ACC.start_email(data.get("email"))
                return self.send_json({"ok": True})
            if what == "verify":
                return self.send_json(ACC.verify_email(data.get("email"), data.get("code")))
            if what in ("google", "apple"):
                url = ACC.oauth_start(self.server.server_address[1], what)
                import webbrowser
                webbrowser.open(url)
                return self.send_json({"ok": True})
            if what == "refresh":
                return self.send_json(ACC.heartbeat())
            if what == "profile":
                return self.send_json(ACC.set_profile(data))
            if what == "photo":
                return self.send_json(ACC.set_photo(data.get("data")))
            if what == "username":
                return self.send_json(ACC.username_free(data.get("username")))
            if what == "logout":
                ACC.logout()
                return self.send_json(ACC.status())
            if what == "delete":
                ACC.delete_account()
                return self.send_json(ACC.status())
        except ACC.AuthError as e:
            return self.err(str(e), 400)
        return self.err("azione sconosciuta", 404)

    def ai_post(self, what, data):
        """Storie AI: chiavi, pagine, storie. Le chiavi non tornano mai indietro all'interfaccia."""
        try:
            if what == "credits":
                return self.send_json({"credits": AI.set_credits(bool(data.get("on"))), "keys": AI.keys_status()})
            if what == "buy":
                it = data.get("item") or {}
                item = {"kind": str(it.get("kind") or "")[:10], "id": str(it.get("id") or "")[:64]}
                try:
                    return self.send_json(AI.credits_buy(item))
                except AI.AIError as e:
                    return self.err(str(e))
            if what == "key":
                return self.send_json(AI.set_key(str(data.get("provider") or ""), data.get("key")))
            if what == "key/workspace":
                return self.send_json(AI.set_workspace(str(data.get("provider") or ""), data.get("workspace")))
            if what == "key/test":
                return self.send_json(AI.test_key(str(data.get("provider") or "")))
            if what == "voice/shared":
                return self.send_json({"voices": AI.shared_voices(str(data.get("lang") or "it")[:5], str(data.get("gender") or ""), str(data.get("search") or ""))})
            if what == "voice/add":
                return self.send_json(AI.add_shared(str(data.get("owner") or ""), str(data.get("voice") or ""), str(data.get("name") or "")))
            if what == "voice/design":
                r = AI.design_voice(str(data.get("description") or "")[:900], str(data.get("lang") or "it")[:5], str(data.get("text") or "")[:1000])
                allow_picked([x["path"] for x in r["previews"]])
                return self.send_json(r)
            if what == "voice/design/save":
                others = data.get("others") if isinstance(data.get("others"), list) else []
                return self.send_json(AI.save_designed(str(data.get("id") or ""), str(data.get("name") or ""), str(data.get("description") or ""),
                                                       str(data.get("lang") or "it")[:5], others))
            if what == "voice/sample":
                vc = data.get("settings") or {}
                path = AI.voice_sample(str(data.get("provider") or ""), str(data.get("voice") or ""), vc if isinstance(vc, dict) else {},
                                       str(data.get("lang") or "it")[:5], bool(data.get("custom")), str(data.get("model") or "")[:80])
                allow_picked([path])
                return self.send_json({"path": path})
            if what == "voices":
                return self.send_json({"voices": AI.voices(str(data.get("provider") or ""))})
            if what == "page":
                pg = SD.save_page(data)
                return self.send_json(pg)
            if what == "page/delete":
                return self.send_json({"ok": SD.delete_page(data.get("id"))})
            if what == "page/ref":
                src = str(data.get("path") or "")
                if not allowed_media(src):
                    return self.err("File non consentito", 403)
                pg = SD.add_ref(data.get("page"), str(data.get("char") or ""), src)
                allow_picked([r for c in pg.get("characters") or [] for r in c.get("refs") or []])
                return self.send_json(pg)
            if what == "page/screen":
                src = str(data.get("path") or "")
                if not allowed_media(src):
                    return self.err("File non consentito", 403)
                pg = SD.add_screen(SD._sid(str(data.get("page") or "")), src)
                allow_picked(pg.get("screens") or [])
                return self.send_json(pg)
            if what == "page/screen/remove":
                return self.send_json(SD.remove_screen(SD._sid(str(data.get("page") or "")), str(data.get("path") or "")))
            if what == "page/ref/remove":
                return self.send_json(SD.remove_ref(data.get("page"), str(data.get("char") or ""), str(data.get("path") or "")))
            if what == "page/music":
                pg = SD.get_page(data.get("page"))
                src = str(data.get("path") or "")
                ed = dict(pg.get("edit") or {})
                if not src:
                    ed["music"] = None
                else:
                    if not allowed_media(src) or not src.lower().endswith((".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac")):
                        return self.err("Scegli un file audio", 400)
                    d = os.path.join(SD.PAGES_DIR, pg["id"], "musica")
                    os.makedirs(d, exist_ok=True)
                    dst = os.path.join(d, re.sub(r"[^\w.\- ]", "_", os.path.basename(src))[:80])
                    shutil.copyfile(src, dst)
                    ed["music"] = {"file": dst, "name": os.path.basename(src)}
                return self.send_json(SD.save_page({"id": pg["id"], "edit": ed}))
            if what == "story/write":
                SD.get_page(data.get("page"))
                return self.send_json(start_job("aiwrite", str(data.get("page")), lambda j: job_ai_write(j, data)).to_json())
            if what == "story/cast":
                return self.send_json(SD.set_cast(data.get("id"), data.get("cast")))
            if what == "story/save":
                sid = data.get("id")
                with SD._lock(sid):
                    st = SD.get_story(sid)
                    if "title" in data:
                        st["title"] = SD._clean_str(data.get("title"), 120)
                    if isinstance(data.get("scenes"), list):
                        old = {x["id"]: x for x in st["scenes"]}
                        if [x.get("speaker") for x in st["scenes"]] != [x.get("speaker") for x in data["scenes"]] or \
                                [x["text"] for x in st["scenes"]] != [x.get("text") for x in data["scenes"]]:
                            st.setdefault("versions", []).append({"at": time.time(), "scenes": [{"speaker": x.get("speaker"), "text": x["text"]} for x in st["scenes"]]})
                            del st["versions"][:-30]
                        new = []
                        for x in data["scenes"][:60]:
                            o = old.get(x.get("id")) or {"id": "sc" + secrets.token_hex(4), "image": None, "audio": None, "error": None}
                            o = dict(o)
                            o["speaker"] = SD._clean_str(x.get("speaker"), 40)
                            o["text"] = SD._clean_str(x.get("text"), 400).strip()
                            for k, n in (("visual", 1200), ("shot", 120)):
                                if k in x:
                                    o[k] = SD._clean_str(x.get(k), n)
                            if "app" in x:
                                o["app"] = bool(x.get("app"))
                            o["motion"] = x.get("motion") if x.get("motion") in SD.MOTIONS else o.get("motion") or "zoomIn"
                            o["locked"] = bool(x.get("locked"))
                            o["lip"] = bool(st.get("lipsync"))
                            if x.get("kind") in ("image", "video", "talk"):
                                o["kind"] = x["kind"]
                            if isinstance(x.get("characters"), list):
                                o["characters"] = [SD._clean_str(c, 40) for c in x["characters"][:6]]
                            if o["text"]:
                                new.append(o)
                        st["scenes"] = new
                    if data.get("status") in ("script", "scene", "produzione", "montata"):
                        st["status"] = data["status"]
                    SD.save_story(st)
                allow_picked(SD.story_files(st))
                try:
                    page = SD.get_page(st["page"])
                except Exception:
                    page = SD.page_defaults()
                return self.send_json({"story": st, "estimate": SD.estimate(st, page)})
            if what == "story/delete":
                return self.send_json({"ok": SD.delete_story(data.get("id"))})
            if what == "format/create":
                return self.send_json(FMT.create(data.get("name"), data.get("kind"), data.get("use") or "story", data.get("niche") or ""))
            if what == "format/save":
                return self.send_json(FMT.update(data.get("id"), data))
            if what == "format/duplicate":
                return self.send_json(FMT.duplicate(FMT._fid(data.get("id"))))
            if what == "format/delete":
                return self.send_json({"ok": FMT.delete(data.get("id"))})
            if what == "format/video/remove":
                return self.send_json(FMT.remove_video(data.get("id"), str(data.get("video") or "")))
            if what == "format/video/add":
                fid = FMT._fid(data.get("id"))
                items = []
                for pth in data.get("paths") or []:
                    if isinstance(pth, str) and allowed_media(pth) and pth.lower().endswith((".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi", ".mp3", ".wav", ".m4a") + FMT.IMG_EXT):
                        items.append({"path": pth})
                for u in data.get("urls") or []:
                    if isinstance(u, str) and re.match(r"^https://", u.strip()):
                        items.append({"url": u.strip()})
                if not items:
                    return self.err("Nessun video valido", 400)
                FMT.add_videos(fid, items)
                allow_picked([x["path"] for x in items if x.get("path")])
                if not any(v.get("status") == "in coda" for v in FMT.get(fid)["videos"]):   # solo immagini: niente da analizzare
                    return self.send_json({"job": None, "format": FMT.get(fid)})
                j = start_job("fmtvideos", fid, lambda jb: job_format_videos(jb, fid))
                return self.send_json({"job": j.to_json(), "format": FMT.get(fid)})
            if what == "format/process":
                fid = FMT._fid(data.get("id"))
                with FMT._lock(fid):
                    fm = FMT.get(fid)
                    for v in fm["videos"]:
                        if v.get("status") == "errore" or (data.get("all") and v.get("status") != "pronto"):
                            v["status"], v["error"] = "in coda", None
                    FMT.save(fm)
                return self.send_json(start_job("fmtvideos", fid, lambda jb: job_format_videos(jb, fid)).to_json())
            if what == "format/video/recount":
                fid = FMT._fid(data.get("id"))
                one = str(data.get("video") or "")
                with FMT._lock(fid):
                    fm = FMT.get(fid)
                    for v in fm["videos"]:
                        if v.get("status") == "pronto" and (not one or v["id"] == one):
                            v["recount"] = True
                    FMT.save(fm)
                j = start_job("fmtvideos", fid, lambda jb: job_format_videos(jb, fid))
                return self.send_json({"job": j.to_json(), "format": FMT.get(fid)})
            if what == "format/estimate":
                return self.send_json(FMT.estimate_analysis(FMT.get(data.get("id"))))
            if what == "format/analyze":
                fid = FMT._fid(data.get("id"))
                choice = {"provider": str(data.get("provider") or ""), "model": str(data.get("model") or "")}
                return self.send_json(start_job("fmtanalyze", fid, lambda jb: job_format_analyze(jb, fid, choice)).to_json())
            if what == "format/style":
                fid = FMT._fid(data.get("id"))
                choice = {"provider": str(data.get("provider") or ""), "model": str(data.get("model") or "")}
                return self.send_json(start_job("fmtstyle", fid, lambda jb: job_format_style(jb, fid, choice)).to_json())
            if what == "format/imgstyle":
                fid = FMT._fid(data.get("id"))
                choice = {"provider": str(data.get("provider") or ""), "model": str(data.get("model") or "")}
                return self.send_json(start_job("fmtimgstyle", fid, lambda jb: job_format_imgstyle(jb, fid, choice)).to_json())
            if what == "format/imgstyle/apply":
                fm = FMT.get(FMT._fid(data.get("id")))
                ist = fm.get("imageStyle") or {}
                if not ist.get("prompt"):
                    return self.err("Prima analizza lo stile delle immagini")
                pg = SD.get_page(str(data.get("page") or ""))
                style = dict(pg.get("style") or {}, prompt=ist["prompt"])
                return self.send_json(SD.save_page({"id": pg["id"], "style": style}))
            if what == "format/share":
                fm = FMT.get(FMT._fid(data.get("id")))
                kind = "images" if fm.get("use") == "images" else "edit"
                st = fm.get("imageStyle") if kind == "images" else fm.get("editStyle")
                if not st:
                    return self.err("Prima analizza lo stile")
                try:
                    ACC.share_style(fm.get("name") or "Stile", fm.get("niche") or "", kind, st)
                except Exception as e:
                    return self.err("Non riesco a pubblicarlo: " + str(e)[:160])
                with FMT._lock(fm["id"]):
                    cur = FMT.get(fm["id"])
                    cur["shared"] = {"at": time.time(), "status": "pending"}
                    FMT.save(cur)
                return self.send_json({"format": FMT.get(fm["id"])})
            if what == "format/style/save":
                fid = FMT._fid(data.get("id"))
                with FMT._lock(fid):
                    fm = FMT.get(fid)
                    fm["editStyle"] = AE.clean_style(data.get("style") or {}) if data.get("style") else None
                    FMT.save(fm)
                return self.send_json({"format": FMT.get(fid)})
            if what == "format/reveal":
                open_path(FMT._dir(data.get("id")))
                return self.send_json({"ok": True})
            if what == "story/kinds":
                sid = data.get("story")
                with SD._lock(sid):
                    st = SD.get_story(sid)
                    if data.get("look") in ("video", "images"):
                        st["look"] = data["look"]
                        if data["look"] == "images":
                            SD.choose_videos(st, "none", "off")
                        else:
                            SD.choose_videos(st, st.get("videoShare") if st.get("videoShare") not in (None, "none") else "few", "talk")
                    if data.get("dialog") in ("talk", "off", "mouth", "lipsync"):
                        # le battute dei personaggi: parlano (bocca che si muove o lip sync) oppure seguono le altre scene
                        dl_ = "off" if data["dialog"] == "off" else "talk"
                        if data["dialog"] in ("mouth", "lipsync"):
                            SD.set_lipsync(st, data["dialog"] == "lipsync")
                        st["dialog"] = dl_
                        SD.choose_videos(st, st.get("videoShare") or "few", dl_)
                    elif data.get("share") in SD.SHARES:
                        SD.choose_videos(st, data["share"])
                    elif data.get("i") is not None and data.get("kind") in ("image", "video", "talk"):
                        for k_ in SD.group_of(st["scenes"], int(data["i"])):   # tutta la clip (battute unite)
                            st["scenes"][k_]["kind"] = data["kind"]
                            st["scenes"][k_]["lip"] = bool(st.get("lipsync"))
                    if data.get("i") is not None and "join" in data:
                        # piu' battute nella stessa clip: questa scena continua la clip di quella prima
                        i_ = int(data["i"])
                        if 0 < i_ < len(st["scenes"]):
                            if data.get("join"):
                                st["scenes"][i_]["join"] = True
                            else:
                                st["scenes"][i_].pop("join", None)
                            SD.sync_groups(st)
                    if data.get("talkAll"):
                        # dialoghi: le battute dei personaggi (non del narratore) diventano scene che parlano
                        for sc_ in st["scenes"]:
                            if SD.speaker_key(sc_.get("speaker")) not in SD.NARRATOR_NAMES:
                                sc_["kind"] = "talk"
                    if data.get("i") is not None and "talkModel" in data:
                        sc_ = st["scenes"][int(data["i"])]
                        if str(data.get("talkModel") or "") in AI.TALK_INFO:
                            sc_["talkModel"] = str(data["talkModel"])
                        else:
                            sc_.pop("talkModel", None)
                    if data.get("i") is not None and "model" in data:
                        # modello video solo per questa scena ("" = quello della pagina)
                        sc_ = st["scenes"][int(data["i"])]
                        m_ = str(data.get("model") or "")
                        if m_ in AI.VIDEO_INFO:
                            sc_["videoModel"] = m_
                        else:
                            sc_.pop("videoModel", None)
                    if data.get("i") is not None and "pause" in data:
                        sc_ = st["scenes"][int(data["i"])]
                        try:
                            sc_["pause"] = max(0.0, min(SD.PAUSE_MAX, float(data["pause"])))
                        except (TypeError, ValueError):
                            sc_.pop("pause", None)   # automatica
                    SD.save_story(st)
                allow_picked(SD.story_files(st))
                return self.send_json({"story": st, "estimate": SD.estimate(st, SD.get_page(st["page"]))})
            if what == "story/ownvoice/remove":
                sid = data.get("story")
                with SD._lock(sid):
                    st = SD.get_story(sid)
                    st.pop("ownVoice", None)
                    SD.save_story(st)
                return self.send_json({"story": st, "estimate": SD.estimate(st, SD.get_page(st["page"]))})
            if what == "story/ownvoice":
                src = str(data.get("path") or "")
                if not allowed_media(src) or not src.lower().endswith((".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac")):
                    return self.err("Scegli un file audio (MP3, WAV, M4A…)", 400)
            jobs = {"story/scene": ("aiscene", job_ai_scene), "story/visuals": ("aivisual", job_ai_visuals),
                    "story/images": ("aiimages", job_ai_images), "story/voices": ("aivoices", job_ai_voices),
                    "story/videos": ("aivideos", job_ai_videos), "story/ownvoice": ("aiownvoice", job_ai_ownvoice),
                    "story/build": ("aibuild", job_ai_build)}
            if what in jobs:
                kind, fn = jobs[what]
                sid = SD._sid(data.get("story"))
                SD.get_story(sid)
                return self.send_json(start_job(kind, sid, lambda j: fn(j, data)).to_json())
        except AI.AIError as e:
            return self.err(str(e), 400)
        except (FileNotFoundError, ValueError) as e:
            return self.err(str(e) if isinstance(e, ValueError) else "Non trovato", 404 if isinstance(e, FileNotFoundError) else 400)
        return self.err("azione sconosciuta", 404)

    def auth_callback(self, qs):
        """Il browser torna qui dopo l'accesso con Google o Apple: scambia il codice (PKCE) e mostra una pagina semplice."""
        port = self.server.server_address[1]
        if (self.headers.get("Host") or "").lower() not in {f"127.0.0.1:{port}", f"localhost:{port}"}:
            return self.err("non autorizzato", 403)
        ok, msg = True, "Accesso fatto. Puoi chiudere questa scheda e tornare a NoonFrame."
        try:
            if qs.get("error"):
                raise ACC.AuthError("Accesso annullato")
            ACC.oauth_finish(qs.get("s", [""])[0], qs.get("code", [""])[0])
        except ACC.AuthError as e:
            ok, msg = False, str(e)
        page = ("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>NoonFrame</title>"
                "<body style=\"margin:0;height:100vh;display:grid;place-items:center;background:#0E1117;color:#E8EDF6;"
                "font:16px -apple-system,Segoe UI,sans-serif;text-align:center\"><div><div style=\"font-size:40px\">"
                + ("&#10003;" if ok else "&#9888;") + "</div><p>" + __import__("html").escape(msg) + "</p></div></body>").encode("utf-8")
        self.send_response(200 if ok else 400)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(page)

    def blocked(self):
        """Solo l'app stessa puo' parlare con il server. Blocca i siti web aperti nel browser che provano a
        chiamare 127.0.0.1 (anche con il trucco del "DNS rebinding"): controlla Host, Origin e Sec-Fetch-Site."""
        port = self.server.server_address[1]
        ok_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        host = (self.headers.get("Host") or "").lower()
        bad = host not in ok_hosts
        origin = self.headers.get("Origin")
        if origin and origin.lower() not in {"http://" + h for h in ok_hosts}:
            bad = True
        if (self.headers.get("Sec-Fetch-Site") or "").lower() in ("cross-site", "same-site"):
            bad = True
        if bad:
            print(f"[sicurezza] richiesta bloccata: host={host!r} origin={origin!r} {self.command} {self.path[:80]}", flush=True)
            self.err("non autorizzato", 403)
        return bad

    # senza accesso l'app si guarda ma non si usa: tutto quello che crea o cambia qualcosa aspetta il login
    GATE_FREE = ("/api/account/", "/api/settings", "/api/clientlog", "/api/track", "/api/update/check", "/api/openurl", "/api/window/")

    def gated(self, path):
        if ACC.can_use() or path.startswith(self.GATE_FREE):
            return False
        n = int(self.headers.get("Content-Length") or 0)
        if 0 < n <= 20_000_000:
            self.rfile.read(n)          # il corpo non letto rovinerebbe la richiesta dopo sulla stessa connessione
        elif n:
            self.close_connection = True
        self.send_json({"error": "Accedi per usare NoonFrame", "login": True}, 401)
        return True

    def authed(self, qs=None):
        tok = self.headers.get("X-Token") or (qs or {}).get("token", [None])[0]
        return tok == TOKEN

    # --- routing
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        u0 = urllib.parse.urlparse(self.path)
        if u0.path == "/auth/callback":
            return self.auth_callback(urllib.parse.parse_qs(u0.query))
        if self.blocked():
            return
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        path = u.path
        if path in ("/", "/index.html"):
            import hmac
            ck = ""
            for part in (self.headers.get("Cookie") or "").split(";"):
                kv = part.strip().split("=", 1)
                if len(kv) == 2 and kv[0] == "nfk":
                    ck = kv[1]
            via_q = hmac.compare_digest(str(qs.get("k", [""])[0]), LAUNCH)
            if not via_q and not hmac.compare_digest(ck, LAUNCH):
                body = ("<!doctype html><meta charset=utf-8><title>NoonFrame</title><body style='background:#0E1117;color:#A0AABB;"
                        "font:15px system-ui;display:grid;place-items:center;height:100vh;margin:0'>Apri NoonFrame dalla sua icona.</body>").encode()
                self.send_response(403)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
                return
            with open(os.path.join(WEB, "index.html"), encoding="utf-8") as f:
                html = f.read().replace("__TOKEN__", TOKEN).replace("__VERSION__", VERSION)
            nonce = secrets.token_urlsafe(16)
            html = html.replace("<script>", f'<script nonce="{nonce}">', 1)
            body = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            # difesa in piu': la finestra puo' caricare ed eseguire solo i file dell'app (niente script da fuori)
            self.send_header("Content-Security-Policy", (
                f"default-src 'self'; script-src 'self' 'nonce-{nonce}'; style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: blob: https://*.googleusercontent.com; media-src 'self' data: blob:; font-src 'self' data: blob:; "
                "connect-src 'self' data: blob:; worker-src 'self' blob:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            if via_q:
                self.send_header("Set-Cookie", f"nfk={LAUNCH}; Path=/; HttpOnly; SameSite=Strict")
            self.end_headers()
            self.wfile.write(body)
            return
        if path.startswith("/web/"):
            fp = os.path.normpath(os.path.join(WEB, path[5:]))
            if not fp.startswith(WEB + os.sep):
                return self.err("no", 403)
            if path.startswith("/web/fonts/"):
                return self.send_file(fp, cache=True)   # i font non cambiano: si tengono
            if path == "/web/fxbox.html":
                # sandbox degli effetti scritti dall'AI: senza origine, senza rete, senza accesso all'app
                return self.send_file(fp, nostore=True, headers={
                    "Content-Security-Policy": "sandbox allow-scripts; default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval' blob:; "
                                               "worker-src blob:; connect-src 'none'; img-src 'none'; frame-ancestors 'self'",
                    "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer"})
            return self.send_file(fp, nostore=True)
        if path == "/api/ping":
            LAST_PING[0] = time.time()
            if qs.get("ui"):
                UPD.mark_ok()   # la finestra ha caricato l'app: questa versione funziona
            r = {"ok": True, "app": "vodcut", "stamp": CODE_STAMP, "upd": UPD.status(), "headless": bool(NATIVE.get("headless"))}
            if qs.get("c"):
                r["proof"] = _proof(qs["c"][0])   # dimostra di essere davvero NoonFrame di questo utente
            return self.send_json(r)
        if path == "/api/restart-if-stale":
            # un avvio con codice piu' nuovo chiede al vecchio server di chiudersi (solo chi ha la chiave d'avvio)
            import hmac
            if not hmac.compare_digest(str(qs.get("k", [""])[0]), LAUNCH):
                return self.err("non autorizzato", 403)
            newer = float(qs.get("stamp", ["0"])[0])
            if newer > CODE_STAMP + 1 and not running_jobs():
                self.send_json({"ok": True, "restarting": True})
                threading.Thread(target=lambda: (time.sleep(0.3), os._exit(0)), daemon=True).start()
                return
            return self.send_json({"ok": True, "restarting": False})
        if not self.authed(qs):
            return self.err("non autorizzato", 403)
        try:
            return self.route_get(path, qs)
        except FileNotFoundError:
            return self.err("Progetto non trovato", 404)
        except Exception as e:
            traceback.print_exc()
            return self.err(str(e), 500)

    def route_get(self, path, qs):
        if path == "/api/env":
            return self.send_json(env_info())
        if path == "/api/account":
            return self.send_json(ACC.status())
        if path == "/api/social":
            return self.send_json({"sites": SOC.status(), "login": {"state": SOCIAL_LOGIN["state"], "site": SOCIAL_LOGIN["site"]},
                                   "native": NATIVE["win"] is not None})
        if path == "/api/ai/state":
            pages = SD.list_pages()
            for pg in pages:
                allow_picked([r for c in pg.get("characters") or [] for r in c.get("refs") or []])
            stories = SD.list_stories()
            allow_picked([x["thumb"] for x in stories if x.get("thumb")])
            return self.send_json({"keys": AI.keys_status(), "models": AI.MODELS, "videoInfo": AI.VIDEO_INFO, "talkInfo": AI.TALK_INFO, "talkDefault": AI.TALK_DEFAULT, "presets": SD.STYLE_PRESETS, "pages": pages,
                                   "stories": stories, "voicesOpenai": AI.OPENAI_VOICES, "credits": AI.credits_status()})
        if path == "/api/ai/credits":
            return self.send_json(AI.credits_status(refresh=True))
        if path == "/api/dropped":
            # il percorso vero di un file appena trascinato nella finestra (lo da' la finestra nativa)
            name = qs.get("name", [""])[0]
            now = time.time()
            for i in range(len(DROPS) - 1, -1, -1):
                n, p, t = DROPS[i]
                if now - t < 15 and n == name:
                    del DROPS[i]
                    PICKED.add(os.path.normcase(os.path.abspath(p)))   # scelto dall'utente: si puo' mostrare l'anteprima
                    return self.send_json({"path": p, "native": True})
            return self.send_json({"path": None, "native": NATIVE.get("win") is not None})
        if path == "/api/messages":
            # avvisi del team e risposte alle segnalazioni: solo testo, li sceglie il server di NoonFrame
            signed = bool(ACC.status().get("signedIn"))
            return self.send_json({"list": ACC.messages(load_settings().get("lang") or "it") if signed else [], "signedIn": signed})
        if path == "/api/ai/wallet":
            return self.send_json(AI.credits_status())   # saldo dalla memoria (si aggiorna da solo in background)
        if path == "/api/ai/catalog":
            # piani, ricariche e offerte lampo: decide tutto il server di NoonFrame (pannello admin)
            if not ACC.status().get("signedIn"):
                return self.send_json({"signedIn": False})
            try:
                r = AI.credits_catalog(load_settings().get("lang") or "it")
            except AI.AIError as e:
                return self.err(str(e))
            r["signedIn"] = True
            r["on"] = AI.credits_wanted()
            return self.send_json(r)
        if path == "/api/ai/sfx":
            # effetti sonori inclusi (creati da noi, tools/make_sfx.py): copiati tra gli importati per usarli nel progetto
            import shutil
            dst = os.path.join(IMPORTS_DIR, "effetti-sonori")
            os.makedirs(dst, exist_ok=True)
            out = {}
            for f in sorted(os.listdir(os.path.join(WEB, "sfx"))):
                if not f.endswith(".wav"):
                    continue
                src, to = os.path.join(WEB, "sfx", f), os.path.join(dst, f)
                if not os.path.isfile(to) or os.path.getsize(to) != os.path.getsize(src):
                    shutil.copyfile(src, to)
                out[f[:-4]] = media_info(to)
            allow_picked([x["path"] for x in out.values()])
            return self.send_json({"sfx": out})
        if path == "/api/ai/graphicmodels":
            return self.send_json({"models": AE.graphic_models()})
        if path == "/api/ai/editstyles":
            out = AE.presets()
            for f in FMT.list_all():
                if not f.get("builtin"):
                    try:
                        fm = FMT.get(f["id"])
                    except Exception:
                        continue
                    if fm.get("editStyle"):
                        out.append({"id": "f:" + fm["id"], "name": fm.get("name"), "summary": fm["editStyle"].get("summary"), "builtin": False,
                                    "niche": fm.get("niche") or ""})
            # stili della community (approvati) + i miei in attesa di approvazione
            for x in ACC.shared_styles():
                if x.get("kind") == "edit" and isinstance(x.get("style"), dict) and (x.get("status") == "approved" or x.get("mine")):
                    out.append({"id": "s:" + str(x["id"]), "name": x.get("name"), "summary": (x["style"].get("summary") or "")[:300], "builtin": False,
                                "niche": x.get("niche") or "", "community": True, "pending": x.get("status") != "approved"})
            return self.send_json({"styles": out})
        if path == "/api/ai/formats":
            lst = FMT.list_all()
            allow_picked([x["thumb"] for x in lst if x.get("thumb")])
            return self.send_json({"formats": lst, "kinds": FMT.KINDS})
        if path == "/api/ai/format":
            fm = FMT.get(qs.get("id", [""])[0])
            allow_picked([f for v in fm["videos"] for f in (v.get("thumbs") or []) + [v.get("sheet")] if f])
            running = any(j.kind == "fmtvideos" and j.pid == fm["id"] and j.status == "running" for j in JOBS.values())
            return self.send_json({"format": fm, "kinds": FMT.KINDS, "running": running, "folder": FMT._dir(fm["id"])})
        if path == "/api/ai/story":
            st = SD.get_story(qs.get("id", [""])[0])
            allow_picked(SD.story_files(st))
            try:
                page = SD.get_page(st["page"])
            except Exception:
                page = None
            return self.send_json({"story": st, "estimate": SD.estimate(st, page or SD.page_defaults()), "page": page,
                                   "working": SD.working(st["id"]), "now": time.time(), "credits": AI.credits_status()})
        if path == "/api/account/profile":
            return self.send_json({"profile": ACC.profile(refresh=qs.get("fresh", ["1"])[0] == "1"), "account": ACC.status()})
        if path == "/api/projects":
            return self.send_json(P.list_projects())
        if path == "/api/trash":
            return self.send_json(P.list_trash())
        if path == "/api/fonts":
            return self.send_json({"user": FONTS.user_fonts()})
        if path == "/api/library":
            return self.send_json(library_list())
        if path == "/api/userfont":
            fn = os.path.basename(qs.get("file", [""])[0])
            fp = os.path.join(FONTS.USER_FONTS, fn)
            if not fn.lower().endswith(FONTS.FONT_EXT) or not os.path.isfile(fp):
                return self.err("font non trovato", 404)
            return self.send_file(fp, "font/otf" if fn.lower().endswith(".otf") else "font/ttf", cache=True)
        if path == "/api/jobs":
            return self.send_json([j.to_json() for j in JOBS.values() if j.status == "running"])
        m = re.match(r"^/api/jobs/(\w+)$", path)
        if m:
            j = JOBS.get(m.group(1))
            return self.send_json(j.to_json()) if j else self.err("job non trovato", 404)
        if path == "/api/mthumb":
            p_ = qs.get("path", [""])[0]
            if not allowed_media(p_) or not os.path.isfile(p_):
                return self.err("file non consentito", 403)
            fn = media_thumb(p_, float(qs.get("t", ["1"])[0]))
            if not os.path.exists(fn):
                return self.err("anteprima non disponibile", 404)
            return self.send_file(fn, "image/jpeg", cache=True)
        if path == "/api/media/light":
            # copie leggere per l'anteprima dei video in sovrimpressione: {path: pronta | null}
            out = {}
            for p_ in qs.get("path", [])[:80]:
                if allowed_media(p_) and os.path.isfile(p_) and p_.lower().endswith((".mp4", ".mov", ".m4v", ".webm", ".mkv")):
                    try:
                        out[p_] = light_copy(p_)
                    except OSError:
                        out[p_] = None
            return self.send_json(out)
        if path == "/api/designs":
            return self.send_json(DZ.list_all())
        if path == "/api/designs/trash":
            return self.send_json(DZ.trashed())
        if path == "/api/brands":
            return self.send_json(DZ.brands())
        bm = re.match(r"^/api/brands/logo/([a-z0-9_.]{1,40})$", path)
        if bm:
            return self.send_file(DZ.logo_path(bm.group(1)), cache=True)
        if path == "/api/designs/ai-info":
            try:
                cfg = SD.pick(SD.page_defaults(), "image")
                return self.send_json({"ready": True, "provider": cfg.get("provider"), "usd": AI.image_price(cfg.get("provider"), cfg.get("model"))})
            except AI.AIError as e:
                return self.send_json({"ready": False, "error": str(e)})
        m = re.match(r"^/api/d/(g[0-9a-f]{10})(/.*)?$", path)
        if m:
            gid, sub = m.group(1), m.group(2) or ""
            if sub == "":
                return self.send_json(DZ.load(gid))
            fm = re.match(r"^/file/([a-z0-9_.]{1,48})$", sub)
            if fm:
                fp = DZ.file_path(gid, fm.group(1))
                if fm.group(1) == "cover.png":
                    return self.send_file(fp, nostore=True)
                return self.send_file(fp, cache=True)   # i nomi non cambiano mai: si tengono in cache
            return self.err("non trovato", 404)
        if path == "/media":
            p = qs.get("path", [""])[0]
            t0 = time.time()
            if not allowed_media(p):
                return self.err("file non consentito", 403)
            t1 = time.time()
            # un SVG puo' contenere script: arriva come testo (l'editor lo disegna come immagine)
            self.send_file(p, "text/plain; charset=utf-8" if p.lower().endswith(".svg") else None, headers={"X-Content-Type-Options": "nosniff"} if p.lower().endswith(".svg") else None)
            print(f"[media] {time.strftime('%H:%M:%S')} range={self.headers.get('Range')} check={t1 - t0:.2f}s "
                  f"tot={time.time() - t0:.2f}s {os.path.basename(p)}", flush=True)
            return
        m = re.match(r"^/api/p/(\w+)(/.*)?$", path)
        if m:
            pid, sub = m.group(1), m.group(2) or ""
            if sub == "/timelines":
                try:
                    return self.send_json(list_timelines(pid))
                except Exception as e:
                    return self.err(str(e), 404)
            if sub == "":
                proj = P.load(pid)
                if proj.get("origSource") and " (montato" in os.path.basename(proj.get("source") or ""):
                    # versione vecchia: il video aggiunto era stato unito alla live (lento e a volte si bloccava)
                    try:
                        with LOCK:
                            cur = P.load(pid)
                            rep = P.repair_merged(cur, float(probe(cur["origSource"])["duration"]))
                            if rep:
                                cur["repairNote"] = True
                                P.save(cur)
                                for j in JOBS.values():
                                    if j.pid == pid and j.status == "running" and j.kind.startswith("proxy"):
                                        j.cancelled = True
                                shutil.rmtree(strip_dir(pid), ignore_errors=True)
                                try:
                                    wf = wave_path(pid)
                                    db = np.load(db_path(pid))
                                    k0, k1 = int(round(rep[0] / A.HOP)), int(round((rep[0] + rep[1]) / A.HOP))
                                    db = np.concatenate([db[:k0], db[k1:]])
                                    np.save(db_path(pid), db)
                                    with open(wf, "w") as f:
                                        json.dump({"perSec": 5, "peaks": A.waveform(db, 5)}, f)
                                except Exception:
                                    traceback.print_exc()
                        proj = P.load(pid)
                    except Exception:
                        traceback.print_exc()
                for i in proj.get("inserts") or []:   # copia per l'anteprima sparita (altro PC, cache pulita)
                    if i.get("preview") and not os.path.exists(i["preview"]):
                        i.pop("preview")
                _upgrade_ins_proxies(pid, proj)
                if "vcodec" not in proj:   # progetti creati prima: il formato si legge una volta sola
                    try:
                        proj["vcodec"] = probe(proj["source"]).get("vcodec")
                        with LOCK:
                            cur = P.load(pid)
                            cur["vcodec"] = proj["vcodec"]
                            P.save(cur)
                    except Exception:
                        pass
                if not proj.get("rotChecked"):
                    try:
                        with LOCK:
                            cur = P.load(pid)
                            fix_rotated(cur)
                            P.save(cur)
                        proj = cur
                    except Exception:
                        traceback.print_exc()
                return self.send_json(proj)
            if sub == "/face":
                d = FACE.load(FACE.path_for(pid))
                return self.send_json({"step": d.get("step", FACE.STEP), "cam": d.get("cam"), "pts": d.get("pts") or {}, "done": d.get("done") or []})
            if sub == "/missing":
                return self.send_json(PK.missing_files(P.load(pid)))
            if sub == "/wave":
                try:
                    with open(wave_path(pid)) as f:
                        return self.send_json(json.load(f))
                except FileNotFoundError:
                    return self.send_json({"perSec": 5, "peaks": []})
            if sub == "/clipwave" and qs.get("path"):
                # forma d'onda di un file intero (le clip spostate o divise la riusano senza ricalcolarla)
                fpath = qs.get("path", [""])[0]
                if not (os.path.isfile(fpath) and allowed_media(fpath)):
                    return self.send_json({"perSec": 5, "peaks": []})
                pi = probe(fpath)
                db = clip_db(fpath, float(pi.get("duration") or 0), pi.get("has_audio"))
                return self.send_json({"perSec": 5, "peaks": A.waveform(db, 5)})
            if sub == "/clipwave":
                proj = P.load(pid)
                ins = next((i for i in proj.get("inserts") or [] if i.get("id") == qs.get("id", [""])[0]), None)
                if not ins or not os.path.exists(ins.get("file", "")):
                    return self.send_json({"perSec": 5, "peaks": []})
                db = clip_db(ins["file"], ins["dur"] + ins.get("offset", 0), ins.get("hasAudio"))
                return self.send_json({"perSec": 5, "peaks": A.waveform(db, 5)})
            if sub == "/cover":
                fp = cover(pid)
                if not fp:
                    return self.err("nessuna copertina", 404)
                return self.send_file(fp, "image/jpeg", cache=True)
            if sub == "/thumb":
                t = float(qs.get("t", ["0"])[0])
                h = int(qs.get("h", ["90"])[0])
                return self.send_file(thumb(pid, t, min(720, h)), "image/jpeg", cache=True)
            if sub == "/strip":
                info = strip_info(pid, P.load(pid)["duration"])
                if not info["ready"]:
                    start_job("thumbs", pid, lambda j: job_thumbs(j, pid))
                return self.send_json(info)
            if sub == "/proxy":
                hq = int(qs.get("h", ["720"])[0])
                pp = proxy_path(pid, hq)
                if qs.get("rebuild") and os.path.exists(pp) and not any(j.kind == f"proxy{hq}" and j.pid == pid and j.status == "running" for j in JOBS.values()):
                    # l'anteprima c'e' ma il lettore non la legge (es. fatta da una versione vecchia): la rifaccio
                    try:
                        os.remove(pp)
                    except OSError:
                        pass
                changed = source_replaced(pid, pp)
                if os.path.exists(pp):
                    return self.send_json({"ready": True, "path": pp})
                last = [j for j in JOBS.values() if j.kind == f"proxy{hq}" and j.pid == pid]
                if last and last[-1].status == "error" and not qs.get("retry"):
                    return self.send_json({"ready": False, "error": last[-1].error})
                j = start_job(f"proxy{hq}", pid, lambda j: job_proxy(j, pid, hq))
                return self.send_json({"ready": False, "job": j.to_json(), "changed": changed})
            if sub == "/stile":
                src = re.sub(r"\W", "", qs.get("src", ["live"])[0])
                st = float(qs.get("st", ["0"])[0])
                if src == "f":   # un video messo nella timeline: per file (vale anche prima che il progetto sia salvato)
                    fpath = qs.get("path", [""])[0]
                    fp = file_tile(fpath, st) if fpath and os.path.isfile(fpath) and allowed_media(fpath) else None
                else:
                    fp = source_tile(pid, src, st)
                if not fp or not os.path.exists(fp):
                    return self.err("anteprima non disponibile", 404)
                return self.send_file(fp, "image/jpeg", cache=True)
            if sub == "/tile":
                fp = strip_tile(pid, int(qs.get("i", ["0"])[0]))
                if not fp or not os.path.exists(fp):
                    return self.err("anteprima non disponibile", 404)
                return self.send_file(fp, "image/jpeg", cache=True)
            if sub == "/frame":
                t = float(qs.get("t", ["0"])[0])
                return self.send_file(thumb(pid, t, 720), "image/jpeg", cache=True)
        return self.err("non trovato", 404)

    def do_PUT(self):
        if self.blocked():
            return
        u = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(u.query)
        if not self.authed(qs):
            return self.err("non autorizzato", 403)
        if self.gated(u.path):
            return
        if u.path == "/api/fonts":
            n = int(self.headers.get("Content-Length") or 0)
            if n > FONTS.MAX_FONT:
                return self.err("Il font e' troppo grande")
            try:
                return self.send_json(FONTS.save_user_font(qs.get("name", ["font.ttf"])[0], self.rfile.read(n)))
            except ValueError as e:
                return self.err(str(e))
        if u.path == "/api/upload":
            # trascina e rilascia: il browser manda il file, lo salviamo in VODcut/importati
            name = os.path.basename(qs.get("name", ["video.mp4"])[0]) or "video.mp4"
            name = re.sub(r'[\\/:*?"<>|]+', "_", name)
            dest = os.path.join(IMPORTS_DIR, name)
            base, ext = os.path.splitext(dest)
            i = 2
            while os.path.exists(dest):
                dest = f"{base} ({i}){ext}"
                i += 1
            n = int(self.headers.get("Content-Length") or 0)
            with open(dest, "wb") as f:
                left = n
                while left > 0:
                    chunk = self.rfile.read(min(4 << 20, left))
                    if not chunk:
                        break
                    f.write(chunk)
                    left -= len(chunk)
            kind = qs.get("kind", ["video"])[0]
            if kind == "project":
                try:
                    proj = PK.import_package(dest, wave_path, db_path)
                except Exception as e:
                    return self.err(str(e))
                finally:
                    try:
                        os.remove(dest)
                    except OSError:
                        pass
                return self.send_json({"project": proj, "missing": PK.missing_files(proj)})
            if kind == "asset":
                try:
                    return self.send_json(media_info(dest))
                except Exception as e:
                    return self.err(str(e))
            if kind == "audio":
                return self.send_json({"path": dest, "duration": probe(dest)["duration"], "name": name})
            try:
                proj = P.create(dest)
            except Exception as e:
                return self.err(media_problem(e) or f"Non riesco ad aprire il file: {e}")
            start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
            return self.send_json(proj)
        if u.path in ("/api/brands", "/api/brands/logo"):
            n = int(self.headers.get("Content-Length") or 0)
            if n > 40 * 1024 * 1024:
                self.close_connection = True
                return self.err("Troppo grande")
            data = self.rfile.read(n) if n else b""
            try:
                if u.path == "/api/brands":
                    return self.send_json(DZ.save_brands(json.loads(data.decode("utf-8"))))
                return self.send_json({"logo": DZ.put_logo(data)})
            except (ValueError, UnicodeDecodeError) as e:
                return self.err(str(e) or "Non valido")
        m = re.match(r"^/api/d/(g[0-9a-f]{10})(/[a-z]+)?$", u.path)
        if m:
            gid, sub = m.group(1), m.group(2) or ""
            n = int(self.headers.get("Content-Length") or 0)
            if n > (DZ.MAX_DOC if sub == "" else 400 * 1024 * 1024):
                self.close_connection = True
                return self.err("Troppo grande")
            data = self.rfile.read(n) if n else b""
            try:
                if sub == "":
                    with LOCK:
                        return self.send_json(DZ.save(gid, json.loads(data.decode("utf-8"))))
                if sub == "/file":
                    return self.send_json({"file": DZ.put_file(gid, data, qs.get("kind", ["img"])[0])})
                if sub == "/cover":
                    return self.send_json({"ok": DZ.put_cover(gid, data)})
                if sub == "/tomedia":
                    # la grafica nei Media di un progetto video (come un'immagine importata)
                    pid = re.sub(r"\W", "", qs.get("pid", [""])[0])[:40]
                    if DZ._sniff(data) != "png":
                        return self.err("Immagine non valida")
                    P.load(pid)   # il progetto esiste
                    d_ = os.path.join(IMPORTS_DIR, "grafiche")
                    os.makedirs(d_, exist_ok=True)
                    dest = os.path.join(d_, DZ._safe_name(qs.get("name", ["Grafica"])[0]) + "_" + secrets.token_hex(3) + ".png")
                    with open(dest, "wb") as f:
                        f.write(data)
                    info = media_info(dest)
                    with LOCK:
                        proj = P.load(pid)
                        proj.setdefault("assets", []).append({"id": "m" + secrets.token_hex(4), **info})
                        P.save(proj)
                    return self.send_json({"ok": True, "path": dest, "project": proj.get("name")})
                if sub == "/export":
                    # pagine gia' disegnate: numero, poi per ognuna lunghezza + immagine
                    cnt = struct.unpack(">I", data[:4])[0]
                    if not 1 <= cnt <= 200:
                        return self.err("Pagine non valide")
                    files, off = [], 4
                    for _ in range(cnt):
                        ln = struct.unpack(">I", data[off:off + 4])[0]
                        files.append(data[off + 4:off + 4 + ln])
                        off += 4 + ln
                    folder = load_settings().get("designExportDir") or None
                    if folder and not os.path.isdir(folder):
                        folder = None
                    try:
                        dpi = int(qs.get("dpi", ["150"])[0])
                    except ValueError:
                        dpi = 150
                    try:
                        anim = {"dur": float(qs.get("dur", ["2"])[0]), "fade": qs.get("fade", ["1"])[0] == "1"}
                    except ValueError:
                        anim = {"dur": 2, "fade": True}
                    paths = DZ.export(gid, files, qs.get("fmt", ["png"])[0], qs.get("name", ["Grafica"])[0], folder, dpi, anim)
                    return self.send_json({"paths": paths, "folder": os.path.dirname(paths[0])})
            except (ValueError, struct.error, UnicodeDecodeError) as e:
                return self.err(str(e) or "Non valido")
            except FileNotFoundError:
                return self.err("Grafica non trovata", 404)
            return self.err("non trovato", 404)
        m = re.match(r"^/api/p/(\w+)/textseq$", u.path)
        if m:
            # testo animato: tutti i fotogrammi in un colpo (numero, poi per ognuno lunghezza + PNG)
            pid = m.group(1)
            clip = re.sub(r"\W", "", qs.get("clip", ["t"])[0])[:24] or "t"
            n = int(self.headers.get("Content-Length") or 0)
            if n > 400 * 1024 * 1024:
                return self.err("troppo grande")
            data = self.rfile.read(n)
            try:
                cnt = struct.unpack(">I", data[:4])[0]
                d = os.path.join(IMPORTS_DIR, "testi", f"seq_{pid}_{clip}_{secrets.token_hex(3)}")
                os.makedirs(d, exist_ok=True)
                off = 4
                for k in range(cnt):
                    ln = struct.unpack(">I", data[off:off + 4])[0]
                    png = data[off + 4:off + 4 + ln]
                    if not png.startswith(b"\x89PNG"):
                        raise ValueError("fotogramma non valido")
                    with open(os.path.join(d, "f%05d.png" % k), "wb") as f:
                        f.write(png)
                    off += 4 + ln
            except (ValueError, struct.error) as e:
                return self.err(f"fotogrammi non validi: {e}")
            return self.send_json({"dir": d, "n": cnt})
        m = re.match(r"^/api/p/(\w+)/textimg$", u.path)
        if m:
            # testo disegnato dall'app: un PNG per ogni versione (i vecchi servono ad Annulla)
            pid = m.group(1)
            clip = re.sub(r"\W", "", qs.get("clip", ["t"])[0])[:24] or "t"
            d = os.path.join(IMPORTS_DIR, "testi")
            os.makedirs(d, exist_ok=True)
            n = int(self.headers.get("Content-Length") or 0)
            data = self.rfile.read(n)
            if not data.startswith(b"\x89PNG"):
                return self.err("immagine non valida")
            name = f"{pid}_{clip}_{secrets.token_hex(3)}.png"
            dest = os.path.join(d, name)
            with open(dest, "wb") as f:
                f.write(data)
            return self.send_json({"path": dest})
        m = re.match(r"^/api/p/(\w+)$", u.path)
        if m:
            data = self.body_json()
            if data.get("id") != m.group(1):
                return self.err("id diverso")
            with LOCK:
                cur = P.load(m.group(1))
                # campi che decide solo il server
                for k in ("source", "duration", "width", "height", "fps", "hasAudio", "created"):
                    data[k] = cur[k]
                # timeline del progetto: le gestisce il server (si creano anche da un'altra timeline)
                for k in ("timelines", "timeline", "parent"):
                    if k in cur:
                        data[k] = cur[k]
                    else:
                        data.pop(k, None)
                # video inseriti nella traccia principale (li mette l'editor): la durata segue
                ins = [i for i in (data.get("inserts") or []) if isinstance(i, dict) and i.get("file") and float(i.get("dur") or 0) > 0]
                live_d = cur.get("liveDuration") or P.live_duration(cur)
                if ins or cur.get("inserts"):
                    data["inserts"] = ins
                    data["liveDuration"] = live_d
                    data["duration"] = live_d + sum(float(i["dur"]) for i in ins)
                # la trascrizione in corso non va sovrascritta da un salvataggio vecchio
                if cur.get("transcript", {}).get("status") == "done" and data.get("transcript", {}).get("status") != "done":
                    data["transcript"] = cur["transcript"]
                # sottotitoli rifatti su un pezzo mentre l'editor salvava: vince la versione piu' nuova
                elif int((cur.get("transcript") or {}).get("rev") or 0) > int((data.get("transcript") or {}).get("rev") or 0):
                    data["transcript"] = cur["transcript"]
                P.save(data)
            return self.send_json({"ok": True, "updated": data["updated"]})
        return self.err("non trovato", 404)

    def do_DELETE(self):
        if self.blocked():
            return
        u = urllib.parse.urlparse(self.path)
        if not self.authed():
            return self.err("non autorizzato", 403)
        if self.gated(u.path):
            return
        m = re.match(r"^/api/d/(g[0-9a-f]{10})$", u.path)
        if m:
            return self.send_json({"ok": DZ.trash(m.group(1)), "days": DZ.TRASH_DAYS})
        m = re.match(r"^/api/p/(\w+)$", u.path)
        if m:
            pid = m.group(1)
            # nel cestino (con le sue clip verticali): si recupera per 30 giorni
            return self.send_json({"ok": P.trash(pid), "days": P.TRASH_DAYS})
        return self.err("non trovato", 404)

    def do_POST(self):
        if self.blocked():
            return
        u = urllib.parse.urlparse(self.path)
        if not self.authed():
            return self.err("non autorizzato", 403)
        if self.gated(u.path):
            return
        try:
            data = self.body_json()
            return self.route_post(u.path, data)
        except FileNotFoundError:
            return self.err("Progetto non trovato", 404)
        except Exception as e:
            traceback.print_exc()
            return self.err(str(e), 500)

    def route_post(self, path, data):
        if path == "/api/track":
            # azioni dell'interfaccia (solo nomi conosciuti, senza contenuti)
            name = str(data.get("name") or "")
            if re.match(r"^(title|text|zoom|marker|library|subs|filter|sound|image|shortcut|layout|guide)\.[a-z_]{2,20}$", name):
                ACC.track(name)
            return self.send_json({"ok": True})
        if path.startswith("/api/account/"):
            return self.account_post(path[13:], data)
        if path.startswith("/api/ai/"):
            return self.ai_post(path[8:], data)
        m = re.match(r"^/api/social/(tiktok)/(connect|disconnect)$", path)
        if m:
            try:
                (social_login if m.group(2) == "connect" else social_logout)(m.group(1))
            except Exception as e:
                return self.err(str(e))
            return self.send_json({"ok": True, "sites": SOC.status()})
        if path == "/api/update/check":
            return self.send_json(UPD.check(force=True))
        if path == "/api/update/channel":
            # solo stabile o beta: l'indirizzo degli aggiornamenti resta fisso e ogni versione e' firmata
            ch = "beta" if data.get("channel") == "beta" else "stable"
            if ch == "beta" and ACC.beta_access(max_age=0) is not True:
                return self.err("Le versioni beta sono solo per chi è stato invitato")
            s = load_settings()
            s["updateChannel"] = ch
            save_settings(s)
            return self.send_json({"ok": True, "channel": ch, "update": UPD.check(force=True)})
        if path == "/api/feedback":
            proj = None
            pid = str(data.get("pid") or "")
            if data.get("project") and re.match(r"^p\w+$", pid):
                try:
                    proj = P.load(pid)
                except Exception:
                    proj = None
            rep = FB.build(data, proj, {"gpu": nvenc_ok(), "lang": load_settings().get("lang")})
            FB.save(rep)
            left = FB.send_pending()
            return self.send_json({"ok": True, "id": rep["id"], "sent": left == 0, "queued": left})
        if path == "/api/window/fullscreen":
            api = NATIVE.get("api")
            if api is not None:
                try:
                    return self.send_json({"on": api.fullscreen(bool(data.get("on")))})
                except Exception as e:
                    return self.err(str(e))
            return self.send_json({"on": False})
        if path == "/api/messages/seen":
            return self.send_json({"ok": ACC.message_seen(data.get("id"), bool(data.get("dismiss")))})
        if path == "/api/openurl":
            url = str(data.get("url") or "")
            if not url.startswith("https://"):
                return self.err("indirizzo non valido")
            import webbrowser
            webbrowser.open(url)
            return self.send_json({"ok": True})
        if path == "/api/update/restart":
            if running_jobs() and not data.get("force"):
                return self.send_json({"ok": False, "busy": True})
            self.send_json({"ok": True})
            UPD.restart(PORT)
            return
        if path == "/api/pick":
            res, err = pick_file(data.get("kind", "video"))
            if err:
                return self.send_json({"error": err, "fallback": True})
            if data.get("kind") in ("media", "audio", "image-many", "images"):
                allow_picked(res if isinstance(res, list) else [res])
            if data.get("kind") == "media":
                out, bad = [], []
                for p_ in res or []:
                    try:
                        out.append(media_info(p_))
                    except Exception:
                        bad.append(os.path.basename(p_))
                return self.send_json({"files": out, "skipped": bad})
            if data.get("kind") == "audio":
                out = []
                for p_ in res or []:
                    try:
                        out.append({"path": p_, "name": os.path.basename(p_), "duration": probe(p_)["duration"]})
                    except Exception:
                        pass
                return self.send_json({"files": out})
            return self.send_json({"path": res})
        # ---- progetto in un file .vodcut (per passarlo da un PC all'altro)
        if path == "/api/import-project":
            p_ = (data.get("path") or "").strip().strip('"')
            if not os.path.isfile(p_):
                return self.err("File non trovato")
            try:
                proj = PK.import_package(p_, wave_path, db_path)
            except Exception as e:
                return self.err(str(e))
            return self.send_json({"project": proj, "missing": PK.missing_files(proj)})
        m_ = re.match(r"^/api/p/(\w+)/(export-project|relink|relink-folder)$", path)
        if m_:
            pid, act = m_.group(1), m_.group(2)
            with LOCK:
                proj = P.load(pid)
                try:
                    if act == "export-project":
                        dest = (data.get("path") or "").strip()
                        if not dest:
                            return self.err("Scegli dove salvare")
                        if not dest.lower().endswith(".vodcut"):
                            dest += ".vodcut"
                        PK.export_package(proj, dest, [(wave_path(pid), "cache/wave.json"), (db_path(pid), "cache/db.npy")])
                        return self.send_json({"path": dest, "files": PK.media_refs(proj)})
                    if act == "relink":
                        PK.relink(proj, data.get("old") or "", (data.get("new") or "").strip().strip('"'))
                        found = 1
                    else:
                        folder = (data.get("folder") or "").strip()
                        if not os.path.isdir(folder):
                            return self.err("Cartella non trovata")
                        found = PK.relink_folder(proj, folder)
                except ValueError as e:
                    return self.err(str(e))
                P.save(proj)
            return self.send_json({"found": found, "missing": PK.missing_files(proj), "project": proj})
        if path == "/api/designs":
            try:
                return self.send_json(DZ.create(data.get("name"), data.get("w") or 1080, data.get("h") or 1080,
                                                data.get("bg", "#FFFFFF"), data.get("preset") or "", data.get("pages") or 1))
            except (TypeError, ValueError) as e:
                return self.err(str(e) or "Misure non valide")
        m = re.match(r"^/api/d/(g[0-9a-f]{10})/(\w+)$", path)
        if m:
            gid, act = m.group(1), m.group(2)
            if act == "meta":
                return self.send_json(DZ.meta(gid, data))
            if act == "duplicate":
                return self.send_json(DZ.duplicate(gid, data.get("name")))
            if act == "restore":
                return self.send_json({"ok": DZ.restore(gid)})
            if act == "import":
                # solo immagini scelte dall'utente con la finestra del computer
                out, bad = [], []
                for p_ in (data.get("paths") or [])[:50]:
                    p_ = str(p_ or "")
                    if os.path.normcase(os.path.abspath(p_)) not in PICKED:
                        bad.append(os.path.basename(p_))
                        continue
                    try:
                        out.append(DZ.import_path(gid, p_))
                    except ValueError:
                        bad.append(os.path.basename(p_))
                return self.send_json({"files": out, "skipped": bad})
            if act == "removebg":
                nm = str(data.get("file") or "")
                DZ.file_path(gid, nm)   # nome valido
                mode = "persona" if data.get("mode") == "persona" else "oggetto"
                return self.send_json(start_job("removebg", gid, lambda j: job_design_removebg(j, gid, nm, mode)).to_json())
            if act == "ai":
                pr = str(data.get("prompt") or "").strip()[:1500]
                if not pr:
                    return self.err("Descrivi l'immagine che vuoi")
                kind = "sticker" if data.get("kind") == "sticker" else "image"
                ratio = str(data.get("ratio") or "1:1")
                return self.send_json(start_job("designai", gid, lambda j: job_design_ai(j, gid, pr, kind, ratio)).to_json())
            if act == "heal":
                im, mk_ = str(data.get("img") or ""), str(data.get("mask") or "")
                DZ.file_path(gid, im); DZ.file_path(gid, mk_)
                rad = max(2, min(60, int(float(data.get("radius") or 6))))
                return self.send_json(start_job("heal", gid, lambda j: job_design_heal(j, gid, im, mk_, rad)).to_json())
            if act == "genfill":
                im, mk_ = str(data.get("img") or ""), str(data.get("mask") or "")
                DZ.file_path(gid, im); DZ.file_path(gid, mk_)
                pr = str(data.get("prompt") or "").strip()[:1500]
                return self.send_json(start_job("genfill", gid, lambda j: job_design_genfill(j, gid, im, mk_, pr)).to_json())
            if act == "quicksel":
                im, mk_ = str(data.get("img") or ""), str(data.get("mask") or "")
                DZ.file_path(gid, im); DZ.file_path(gid, mk_)
                return self.send_json(start_job("quicksel", gid, lambda j: job_design_quicksel(j, gid, im, mk_)).to_json())
            if act == "refine":
                im, mk_ = str(data.get("img") or ""), str(data.get("mask") or "")
                DZ.file_path(gid, im); DZ.file_path(gid, mk_)
                rad = max(1, min(80, int(float(data.get("radius") or 8))))
                sm = max(0.0, min(1.0, float(data.get("smooth") or 0)))
                ct = max(0.0, min(1.0, float(data.get("contrast") or 0)))
                return self.send_json(start_job("refine", gid, lambda j: job_design_refine(j, gid, im, mk_, rad, sm, ct)).to_json())
            if act == "denoise":
                im = str(data.get("file") or "")
                DZ.file_path(gid, im)
                st = max(1, min(30, int(float(data.get("strength") or 8))))
                return self.send_json(start_job("denoise", gid, lambda j: job_design_denoise(j, gid, im, st)).to_json())
            if act == "reveal":
                folder = load_settings().get("designExportDir") or DZ.EXPORT_DIR
                p_ = str(data.get("path") or "")
                if p_ and os.path.isfile(p_) and os.path.abspath(p_).startswith(os.path.abspath(folder) + os.sep):
                    return self.send_json({"ok": open_path(p_, True)})
                os.makedirs(folder, exist_ok=True)
                return self.send_json({"ok": open_path(folder, False)})
            return self.err("non trovato", 404)
        if path == "/api/removebg":
            p_ = (data.get("path") or "").strip()
            if not os.path.isfile(p_) or os.path.splitext(p_)[1].lower() not in IMG_EXT:
                return self.err("Serve un'immagine")
            return self.send_json(start_job("removebg", None, lambda j: job_removebg(j, p_)).to_json())
        if path == "/api/probe-media":
            p_ = (data.get("path") or "").strip().strip('"')
            if not os.path.isfile(p_):
                return self.err("File non trovato")
            try:
                return self.send_json(media_info(p_))
            except Exception as e:
                return self.err(str(e))
        if path == "/api/probe-audio":
            p_ = data.get("path", "")
            if not os.path.isfile(p_):
                return self.err("File non trovato")
            return self.send_json({"path": p_, "name": os.path.basename(p_), "duration": probe(p_)["duration"]})
        if path == "/api/library/add":
            try:
                return self.send_json(library_add(str(data.get("path") or "")))
            except ValueError as e:
                return self.err(str(e))
        if path == "/api/library/remove":
            fp = os.path.abspath(str(data.get("path") or ""))
            if os.path.dirname(fp) == os.path.abspath(LIBRARY_DIR) and os.path.isfile(fp):
                os.remove(fp)
            return self.send_json({"ok": True})
        if path == "/api/fonts/delete":
            return self.send_json({"ok": FONTS.delete_user_font(str(data.get("file") or ""))})
        if path == "/api/trash/restore":
            return self.send_json({"ok": P.restore(str(data.get("id") or ""))})
        if path == "/api/trash/purge":
            ids = [x["id"] for x in P.list_trash()] if data.get("all") else [str(data.get("id") or "")]
            return self.send_json({"ok": all([P.purge(i) for i in ids])})
        if path == "/api/projects":
            src = (data.get("source") or "").strip().strip('"')
            if not os.path.isfile(src):
                return self.err("File non trovato: " + src)
            try:
                proj = P.create(src)
            except Exception as e:
                return self.err(media_problem(e) or f"Non riesco ad aprire il file: {e}")
            if data.get("kind") == "video":
                finish_plain(proj, "video")
            start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
            return self.send_json(proj)
        if path == "/api/projects/blank":
            try:
                proj = create_blank(data.get("format"), data.get("dur"), (data.get("name") or "").strip())
            except Exception as e:
                return self.err(f"Non riesco a creare il progetto: {e}")
            start_job("prepare", proj["id"], lambda j: job_prepare(j, proj["id"]))
            return self.send_json(proj)
        if path == "/api/story/parse":
            return self.send_json({"lines": ST.parse(data.get("text") or "")})
        if path == "/api/story/images":
            files = data.get("files") or ST.list_images((data.get("folder") or "").strip())
            if data.get("folder"):
                print(f"[story] cartella {data.get('folder')!r}: {len(files)} immagini", flush=True)
            files = [f for f in files if isinstance(f, str) and f.lower().endswith(ST.IMG_EXT) and os.path.isfile(f)]   # solo immagini
            allow_picked(files)
            out = []
            for f in files:
                try:
                    out.append(media_info(f))
                except Exception:
                    pass
            lines = data.get("lines") or []
            match = ST.match_images([o["path"] for o in out], lines) if lines else []
            return self.send_json({"files": out, "match": match})
        if path == "/api/story/voice":
            if data.get("voice"):
                allow_picked([data["voice"]])
            return self.send_json(start_job("storyvoice", None, lambda j: job_story_voice(j, data)).to_json())
        if path == "/api/story/create":
            if data.get("voice"):
                allow_picked([data["voice"]])
            return self.send_json(start_job("story", None, lambda j: job_story(j, data)).to_json())
        if path == "/api/import-url":
            url = (data.get("url") or "").strip()
            if not re.match(r"^https?://", url):
                url = "https://" + url
            j = start_job("download", None, lambda j: job_download(j, url))
            return self.send_json(j.to_json())
        if path == "/api/clientlog":
            print(f"[app] {time.strftime('%H:%M:%S')} {str(data.get('msg'))[:300]}", flush=True)
            return self.send_json({"ok": True})
        if path == "/api/open":
            ok = open_path(data.get("path", ""), bool(data.get("reveal")))
            return self.send_json({"ok": ok})
        if path == "/api/settings":
            s = load_settings()
            # le impostazioni che decidono da dove arrivano gli aggiornamenti non si cambiano dall'interfaccia
            s.update({k: v for k, v in data.items() if k not in ("updateUrl", "updateChannel", "feedbackToken") and len(str(k)) < 40})
            save_settings(s)
            return self.send_json(s)
        m = re.match(r"^/api/jobs/(\w+)/cancel$", path)
        if m:
            j = JOBS.get(m.group(1))
            if j:
                j.cancelled = True
            return self.send_json({"ok": True})
        m = re.match(r"^/api/p/(\w+)/(\w[\w-]*)$", path)
        if m:
            pid, act = m.group(1), m.group(2)
            if act == "prepare":
                return self.send_json(start_job("prepare", pid, lambda j: job_prepare(j, pid)).to_json())
            if act == "meta":   # nome e cartella dalla home (senza aprire l'editor)
                proj = P.load(pid)
                if "name" in data:
                    nm = str(data.get("name") or "").strip()[:120]
                    if nm:
                        proj["name"] = nm
                if "folder" in data:
                    proj["folder"] = str(data.get("folder") or "").strip()[:60]
                P.save(proj)
                return self.send_json({"ok": True, "name": proj["name"], "folder": proj.get("folder") or ""})
            if act == "face":
                return self.send_json(start_job("face", pid, lambda j: job_face(j, pid)).to_json())
            if act == "redetect":
                def jd(j):
                    return W.detect_webcam(P.load(pid)["source"])
                return self.send_json(start_job("webcam", pid, jd).to_json())
            if act == "propose":
                with LOCK:
                    proj = P.load(pid)
                    if not os.path.exists(db_path(pid)):
                        return self.err("Analisi dell'audio non ancora pronta")
                    locked = bool((proj.get("analysis") or {}).get("ready"))  # il formato si sceglie una volta sola
                    propose_into(proj, int(data.get("cuts", 1)), int(data.get("zooms", 1)), data.get("zoomScale"))
                    if not locked and data.get("format") in ("16:9", "9:16") and data.get("format") != (proj.get("format") or "16:9"):
                        set_format(proj, data["format"])
                    if data.get("vlayout") in VT.LAYOUTS:
                        proj["vert"] = dict(proj.get("vert") or {}, layout=data["vlayout"])
                    P.save(proj)
                return self.send_json(proj)
            if act == "fxreview":   # controllo visivo dell'effetto: l'AI guarda i fotogrammi e lo corregge
                frames = _b64_images(data.get("frames"), 4)
                if not frames or not str(data.get("code") or "").strip():
                    return self.err("Mancano i fotogrammi")
                d_ = {"code": str(data.get("code"))[:40000], "prompt": str(data.get("prompt") or "")[:1500], "text": str(data.get("text") or "")[:120], "frames": frames}
                return self.send_json(start_job("fxreview", pid, lambda j: job_fxreview(j, d_)).to_json())
            if act == "fxcode":   # effetto su misura: l'AI scrive il codice dell'animazione
                d_ = {k: data.get(k) for k in ("prompt", "dur", "style", "text", "aspect", "prev", "error", "hand")}
                d_["refs"] = _b64_images(data.get("refs"), 3)   # screenshot di esempio da replicare
                if not str(d_.get("prompt") or "").strip() and not d_.get("error") and not d_["refs"]:
                    return self.err("Descrivi l'effetto che vuoi")
                return self.send_json(start_job("fxcode", pid, lambda j: job_fxcode(j, d_)).to_json())
            if act == "scriptfix":   # lo script incollato corregge le parole della trascrizione che c'e' gia'
                with LOCK:
                    proj = P.load(pid)
                    if "script" in data:
                        proj["script"] = str(data.get("script") or "")[:60000]
                    tr = proj.get("transcript") or {}
                    n = T.fix_with_script(tr, proj.get("script")) if tr.get("segments") else 0
                    P.save(proj)
                return self.send_json({"fixed": n, "transcript": proj.get("transcript")})
            if act == "transcribe":
                use_ai = bool(data.get("ai"))
                if "script" in data:
                    with LOCK:
                        proj = P.load(pid)
                        proj["script"] = str(data.get("script") or "")[:60000]
                        P.save(proj)
                if use_ai and not AI.cloud_transcriber():
                    return self.err("Per la trascrizione AI serve una chiave OpenAI o ElevenLabs in Storie AI → Chiavi AI")
                if not use_ai and not T.available():
                    return self.err("Trascrizione non installata: riesegui INSTALLA.bat")
                lang_ = data.get("lang")
                with LOCK:
                    proj = P.load(pid)
                    if lang_ is not None:   # lingua scelta a mano ("" = la riconosce da sola)
                        proj["subLang"] = lang_ if lang_ in SUB_LANGS else None
                    clip_ = proj.get("parent") and not proj.get("timeline") and proj.get("ranges")
                    if lang_ is not None and clip_ and not use_ai and (proj.get("transcript") or {}).get("status") == "done":
                        # clip: si riscrive solo il suo pezzo di live (pochi secondi, non tutta la live)
                        P.save(proj)
                        A_, B_ = float(proj["ranges"][0][0]), float(proj["ranges"][-1][1])
                        return self.send_json(start_job("transcribe", pid, lambda j: job_transcribe_range(j, pid, A_, B_)).to_json())
                    proj["transcript"] = {"status": "running", "segments": []}
                    P.save(proj)
                return self.send_json(start_job("transcribe", pid, lambda j: job_transcribe(j, pid, use_ai)).to_json())
            if act == "transcribeinfo":   # trascrizione AI: con che servizio e quanto costa
                pr_ = AI.cloud_transcriber()
                proj = P.load(pid)
                d = P.live_duration(proj) + sum(i["dur"] for i in proj.get("inserts") or [])
                return self.send_json({"provider": pr_, "name": AI.PROVIDERS.get(pr_, {}).get("name") if pr_ else None,
                                       "usd": AI.transcribe_cloud_usd(pr_, d) if pr_ else None})
            if act == "aiedit":
                sty = str(data.get("style") or "p:business")
                opts = {k: bool(v) for k, v in (data.get("opts") or {}).items() if k in ("pauses", "cuts", "zooms", "texts", "graphics", "motions", "subs")}
                opts["lv"] = AE.clean_levels(data.get("levels"))
                if data.get("liveLen") in ("highlights", "normale", "leggero"):
                    opts["liveLen"] = data["liveLen"]
                prompt = str(data.get("prompt") or "")[:1000]
                prev = [x for x in (data.get("prev") or []) if isinstance(x, dict)][:400]
                return self.send_json(start_job("aiedit", pid, lambda j: job_ai_edit(j, pid, sty, prompt, opts, prev)).to_json())
            if act == "aiestimate":
                try:
                    cfg = _text_cfg()
                except RuntimeError as e:
                    return self.send_json({"error": str(e), "planUsd": None})
                est = AE.estimate(P.load(pid), cfg)
                try:
                    im = SD.pick(SD.page_defaults(), "image")
                    est["imageUsd"] = AI.image_price(im["provider"], im.get("model"))
                except AI.AIError:
                    est["imageUsd"] = None
                from engine import fxcode as FXC
                est["fxUsd"] = FXC.estimate_usd(cfg.get("model"))
                est["credits"] = AI.credits_on()
                est["perUsd"] = AI.credits_status().get("perUsd")
                est["model"] = (AI.TEXT_INFO.get(cfg.get("model")) or {}).get("name") or cfg.get("model")
                return self.send_json(est)
            if act == "montage":
                keep = [[float(x[0]), float(x[1])] for x in (data.get("keep") or []) if isinstance(x, list) and len(x) == 2][:5000]
                for j in list(JOBS.values()):   # una sola alla volta: quella nuova sostituisce la vecchia
                    if j.kind == "montage" and j.pid == pid and j.status == "running":
                        j.cancelled = True
                return self.send_json(start_job("montage", pid, lambda j: job_montage(j, pid, keep)).to_json())
            if act == "behind":
                items = [x for x in (data.get("items") or []) if isinstance(x, dict) and x.get("text")][:30]
                return self.send_json(start_job("behind", pid, lambda j: job_behind(j, pid, items)).to_json())
            if act == "hands":   # effetti che seguono la mano: dove e' la mano nei pezzi di video sotto l'effetto
                pieces = []
                for x in (data.get("pieces") or [])[:40]:
                    try:
                        a_, b_, t0_ = float(x.get("a") or 0), float(x.get("b") or 0), float(x.get("t0") or 0)
                    except (TypeError, ValueError, AttributeError):
                        continue
                    if 0.05 <= b_ - a_ <= 120 and a_ >= 0 and 0 <= t0_ <= 120:
                        pieces.append({"file": str(x.get("file") or ""), "a": a_, "b": b_, "t0": t0_})
                if not pieces or sum(p["b"] - p["a"] for p in pieces) > 120:
                    return self.send_json({"error": "Pezzo non valido"}, 400)
                return self.send_json(start_job("hands", pid, lambda j: job_hands(j, pid, pieces)).to_json())
            if act == "cutout":
                path = str(data.get("file") or "")
                if data.get("image"):
                    return self.send_json(start_job("cutout", pid, lambda j: job_cutout_img(j, pid, path)).to_json())
                a, b = float(data.get("a") or 0), float(data.get("b") or 0)
                if b - a < 0.1 or b - a > 1800:
                    return self.send_json({"error": "Pezzo non valido"}, 400)
                return self.send_json(start_job("cutout", pid, lambda j: job_cutout(j, pid, path, a, b)).to_json())
            if act == "aigraphics":
                items = [x for x in (data.get("items") or []) if isinstance(x, dict) and x.get("prompt")][:40]
                gm = str(data.get("model") or "")[:20] or None
                return self.send_json(start_job("aigraphics", pid, lambda j: job_ai_graphics(j, pid, items, gm)).to_json())
            if act == "transcriberange":
                if not T.available():
                    return self.err("Trascrizione non installata: riesegui INSTALLA.bat")
                a, b = float(data.get("a", 0)), float(data.get("b", 0))
                if b - a < 0.3:
                    return self.err("Pezzo troppo corto")
                return self.send_json(start_job("trrange", pid, lambda j: job_transcribe_range(j, pid, a, b)).to_json())
            if act == "freezeframe":
                # fermo immagine: il fotogramma sotto la testina diventa un'immagine da mettere in timeline
                try:
                    return self.send_json({"path": freeze_frame(P.load(pid), float(data.get("t", 0)))})
                except Exception as e:
                    return self.err(str(e))
            if act == "gapfile":
                with LOCK:
                    return self.send_json(gap_file(P.load(pid)))
            if act == "prepinsert":
                clip = (data.get("path") or "").strip().strip('"')
                if not os.path.isfile(clip):
                    return self.err("File non trovato: " + clip)
                return self.send_json(start_job("prepinsert:" + clip, pid, lambda j: job_prepinsert(j, pid, clip)).to_json())
            if act == "inserttranscript":
                clip = (data.get("path") or "").strip()
                if not os.path.isfile(clip) or not T.available():
                    return self.err("File non trovato: " + clip)
                d_, o_ = float(data.get("dur") or 0), float(data.get("offset") or 0)
                return self.send_json(start_job("instr:" + clip, pid, lambda j: job_insert_transcript(j, pid, clip, d_, o_)).to_json())
            if act == "export":
                want = data if (data.get("verticals") or data.get("timelines") or data.get("vod") is False) else None
                return self.send_json(start_job("export", pid, lambda j: job_export(j, pid, want)).to_json())
            if act == "rename":
                with LOCK:
                    cur = P.load(pid)
                    cur["name"] = (data.get("name") or cur["name"]).strip()[:120] or cur["name"]
                    P.save(cur)
                return self.send_json({"ok": True, "name": cur["name"]})
            if act == "timeline":
                try:
                    ch = create_timeline(pid, data.get("name"), data.get("asset"))
                except Exception as e:
                    return self.err(f"Non riesco a creare la timeline: {e}")
                start_job("prepare", ch["id"], lambda j: job_prepare(j, ch["id"]))
                return self.send_json({"id": ch["id"], "name": ch["name"]})
            if act == "timeline-rename":
                tid = str(data.get("id") or "")
                nm = (data.get("name") or "").strip()[:120]
                if not nm:
                    return self.err("Scrivi un nome")
                with LOCK:
                    rid = timeline_root(pid)
                    if tid == rid:
                        root = P.load(rid)
                        root["tlName"] = nm
                        P.save(root)
                    else:
                        t = P.load(tid)
                        if t.get("parent") != rid:
                            return self.err("timeline non trovata", 404)
                        t["name"] = nm
                        P.save(t)
                return self.send_json({"ok": True})
            if act == "timeline-remove":
                tid = str(data.get("id") or "")
                with LOCK:
                    root = P.load(timeline_root(pid))
                    if tid not in (root.get("timelines") or []):
                        return self.err("timeline non trovata", 404)
                    root["timelines"] = [x for x in root["timelines"] if x != tid]
                    P.save(root)
                P.trash_child(tid)
                return self.send_json({"ok": True})
            if act == "clips":   # clip virali dalla live (stile Opus)
                prompt_ = str(data.get("prompt") or "")[:600]
                return self.send_json(start_job("clips", pid, lambda j: job_clips(j, pid, prompt_, data.get("replace", True) is not False)).to_json())
            if act == "resetedit":   # ricomincia da zero con lo stesso VOD (non editato)
                with LOCK:
                    cur = P.load(pid)
                    if cur.get("parent") and not cur.get("timeline"):
                        return self.err("Questa e' una clip: ricominciala dal video della live")
                    fresh = P.reset_edits(cur)
                    P.save(fresh)
                return self.send_json({"ok": True, "stage": fresh["stage"]})
            if act == "cliplist":
                return self.send_json(clip_list(pid))
            if act == "clipsubs":   # stile e posizione dei sottotitoli delle clip: per le prossime e (se chiesto) per quelle fatte
                cs = {k: data[k] for k in ("pos", "font", "color", "hiColor", "upper", "box", "stroke", "size", "words", "effect") if k in data}
                if cs.get("pos") not in CLIP_SUB_POS:
                    cs["pos"] = "cam"
                s_ = load_settings()
                s_["clipSubs"] = cs
                save_settings(s_)
                n_ = 0
                if data.get("apply", True):
                    for v in P.load(pid).get("verticals") or []:
                        with LOCK:
                            try:
                                ch = P.load(v["id"])
                            except Exception:
                                continue
                            if not ch.get("clip"):
                                continue
                            vt = ch.get("vert") or {}
                            ns_ = clip_sub_style(vt.get("camH", 0.4), bool((ch.get("webcam") or {}).get("box")) and vt.get("layout") == "split", cs,
                                                 bool((ch.get("clip") or {}).get("fullcam")))
                            ch["subStyle"] = {k_: v_ for k_, v_ in dict(ch.get("subStyle") or {}, **ns_).items() if k_ != "auto" or "auto" in ns_}
                            ch.pop("clipPreview", None)   # anteprima da rifare
                            P.save(ch)
                            n_ += 1
                return self.send_json({"ok": True, "clips": n_, "style": cs})
            if act == "cliplang":   # clip in un'altra lingua: sottotitoli riscritti e titoli tradotti
                lang_ = str(data.get("lang") or "")
                if lang_ not in SUB_LANGS:
                    return self.err("Lingua non valida")
                return self.send_json(start_job("cliplang", pid, lambda j: job_cliplang(j, pid, lang_)).to_json())
            if act == "clipestimate":
                from engine import live as LIVE
                proj = P.load(pid)
                try:
                    cfg = _text_cfg()
                except RuntimeError as e:
                    return self.send_json({"error": str(e)})
                est = LIVE.estimate(proj, cfg)
                est["credits"] = AI.credits_on()
                est["perUsd"] = AI.credits_status().get("perUsd")
                est["hasTranscript"] = (proj.get("transcript") or {}).get("status") == "done"
                return self.send_json(est)
            if act == "clippreview":
                ids = [str(x) for x in (data.get("ids") or []) if re.fullmatch(r"\w+", str(x))][:60]
                return self.send_json(start_job("clipprev", pid, lambda j: job_clip_previews(j, pid, ids)).to_json())
            if act == "clipremove":   # clip tolta dalla galleria: via anche dalla lista della live
                cid = str(data.get("id") or "")
                with LOCK:
                    proj = P.load(pid)
                    proj["verticals"] = [v for v in proj.get("verticals") or [] if v.get("id") != cid]
                    P.save(proj)
                return self.send_json({"ok": True})
            if act == "cliprename":
                cid, nm = str(data.get("id") or ""), str(data.get("name") or "").strip()[:120]
                if nm:
                    with LOCK:
                        proj = P.load(pid)
                        for v in proj.get("verticals") or []:
                            if v.get("id") == cid:
                                v["name"] = nm
                        P.save(proj)
                return self.send_json({"ok": True})
            if act == "vertical":
                try:
                    rg = data.get("ranges") or [[data.get("a", 0), data.get("b", 0)]]
                    return self.send_json(create_vertical(pid, rg, data.get("name")))
                except ValueError as e:
                    return self.err(str(e))
        return self.err("non trovato", 404)


def port_in_use_by_us(port):
    """True se VODcut gia' gira su questa porta con lo stesso codice.
    Se gira una versione vecchia (dopo un aggiornamento), la chiude e ritorna False."""
    import urllib.request
    import hmac
    ch = secrets.token_hex(12)
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping?c={ch}", timeout=1) as r:
            j = json.loads(r.read())
    except Exception:
        return False
    if j.get("app") != "vodcut" or not hmac.compare_digest(str(j.get("proof") or ""), _proof(ch)):
        return False   # non e' il nostro NoonFrame (o e' una versione vecchia senza prova): se ne apre uno nuovo
    if j.get("headless"):
        # la finestra di quel server e' stata chiusa e sta solo finendo un lavoro: non ci si attacca
        # (non potrebbe aprire "Scegli file" ne' confermare che l'aggiornamento parte): server nuovo su un'altra porta
        return False
    if j.get("stamp", 0) + 1 < CODE_STAMP:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/restart-if-stale?stamp={CODE_STAMP}&k={LAUNCH}", timeout=2) as r:
                if json.loads(r.read()).get("restarting"):
                    time.sleep(1.0)
                    return False
        except Exception:
            time.sleep(1.0)
            return False
    return True


def free_port(start):
    # prima riprova la porta solita per qualche secondo (il vecchio server si sta chiudendo)
    for _ in range(15):
        with socket.socket() as s:
            if sys.platform != "win32":
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", start))
                return start
            except OSError:
                time.sleep(0.2)
    for p in range(start, start + 50):
        with socket.socket() as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return start


def open_window(url):
    """Apre l'app in una finestra pulita di Edge o Chrome (modalita' app)."""
    cands = []
    if sys.platform == "win32":
        pf = [os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.environ.get("ProgramFiles", r"C:\Program Files"),
              os.environ.get("LocalAppData", "")]
        for base in pf:
            cands += [os.path.join(base, r"Microsoft\Edge\Application\msedge.exe"),
                      os.path.join(base, r"Google\Chrome\Application\chrome.exe")]
    else:
        cands += [shutil.which(x) or "" for x in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge")]
    prof = os.path.join(APP_DIR, "finestra")
    for c in cands:
        if c and os.path.exists(c):
            subprocess.Popen([c, f"--app={url}", f"--user-data-dir={prof}", "--window-size=1440,920",
                              "--no-first-run", "--no-default-browser-check", "--autoplay-policy=no-user-gesture-required"])
            return
    import webbrowser
    webbrowser.open(url)


# ------------------------------------------------------------------ finestra nativa (senza barra di Windows)
def have_webview():
    if sys.platform not in ("win32", "darwin"):
        return False
    try:
        import webview  # noqa: F401
        return True
    except Exception:
        return False


def install_webview_bg():
    """La finestra nativa usa pywebview: se manca si installa in silenzio (vale dal prossimo avvio)."""
    if sys.platform != "win32":
        return
    nw = 0x08000000

    def run():
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "pywebview"], capture_output=True, creationflags=nw, timeout=900)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


class WinApi:
    """Comandi della finestra chiamati dalla barra in alto (riduci, ingrandisci, chiudi, sposta, ridimensiona)."""

    def __init__(self):
        self._win = None
        self._max = None
        self._fs = False

    def _form(self):
        return self._win.native

    def _hwnd(self):
        return self._form().Handle.ToInt32()

    def _ui(self, fn):
        from System import Func, Type  # noqa: F401  (pythonnet, gia' caricato da pywebview)
        f = self._form()
        if f.InvokeRequired:
            f.Invoke(Func[Type](fn))
        else:
            fn()

    def setup(self):
        """Attiva le zone di trascinamento native (Aero Snap) se WebView2 le supporta."""
        res = {"nc": False}

        def go():
            f = self._form()
            try:
                # doppio clic sulla barra (gestito da Windows): ingrandisce senza coprire la barra delle app
                from System.Windows.Forms import Screen
                f.MaximizedBounds = Screen.FromControl(f).WorkingArea
            except Exception:
                pass
        try:
            self._ui(go)
        except Exception:
            pass
        self.set_icon()
        try:
            res["max"] = self.is_max()
        except Exception:
            res["max"] = False
        return res

    def set_icon(self):
        """Icona di VODcut sulla finestra e nella barra delle app (invece di quella di Python)."""
        ico = os.path.join(ROOT, "vodcut.ico")
        if not os.path.exists(ico):
            return

        def go():
            from System.Drawing import Icon
            self._form().Icon = Icon(ico)
        try:
            self._ui(go)
        except Exception:
            pass

    def minimize(self):
        self._win.minimize()

    def close(self):
        self._win.destroy()

    def toggle_maximize(self):
        """Ingrandisce / ripristina come fa Windows (cosi' trascinando la barra torna piccola da sola)."""
        from System.Windows.Forms import FormWindowState, Screen
        f = self._form()
        out = {}

        def go():
            try:
                f.MaximizedBounds = Screen.FromControl(f).WorkingArea   # la barra delle app resta visibile
            except Exception:
                pass
            if f.WindowState == FormWindowState.Maximized:
                f.WindowState = FormWindowState.Normal
                out["max"] = False
            else:
                f.WindowState = FormWindowState.Maximized
                out["max"] = True
        self._ui(go)
        self._max = None
        return out.get("max", False)

    def start_drag(self):
        """Spostamento della finestra fatto da Windows (come trascinare una barra del titolo vera):
        funziona anche l'aggancio ai bordi e, se e' ingrandita, torna piccola seguendo il mouse."""
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.SendMessageW.restype = wintypes.LPARAM
        h = self._form().Handle.ToInt64()

        def go():
            u.ReleaseCapture()
            u.SendMessageW(h, 0x00A1, 2, 0)   # WM_NCLBUTTONDOWN sulla "barra del titolo"
        self._ui(go)
        return True

    def is_max(self):
        from System.Windows.Forms import FormWindowState
        return self._form().WindowState == FormWindowState.Maximized

    def set_bounds(self, x, y, w, h, dpr):
        """Sposta/ridimensiona (coordinate CSS dello schermo, convertite in pixel veri)."""
        import ctypes
        try:
            if self.is_max():
                return
        except Exception:
            pass
        k = float(dpr or 1)
        flags = 0x0044 if w else 0x0045   # senza w/h: solo spostamento
        ctypes.windll.user32.SetWindowPos(self._hwnd(), 0, int(round(x * k)), int(round(y * k)),
                                          int(round((w or 0) * k)), int(round((h or 0) * k)), flags)

    def fullscreen(self, on):
        on = bool(on)
        if on != self._fs:
            self._fs = on
            self._win.toggle_fullscreen()
        return self._fs


class MacApi:
    """Sul Mac la finestra e' quella normale di macOS (semafori, schermo intero, Spazi): qui serve poco."""

    def __init__(self):
        self._win = None
        self._fs = False

    def setup(self):
        return {"max": False, "mac": True}

    def fullscreen(self, on):
        on = bool(on)
        if on != self._fs:
            self._fs = on
            self._win.toggle_fullscreen()
        return self._fs


def _mac_identity():
    """Nome "VODcut" nel menu in alto e icona nel Dock (il processo e' il Python dentro l'app)."""
    try:
        from Foundation import NSBundle
        b = NSBundle.mainBundle()
        info = b.localizedInfoDictionary() or b.infoDictionary()
        if info is not None:
            info["CFBundleName"] = "NoonFrame"
    except Exception:
        pass
    try:
        from AppKit import NSApplication, NSImage
        icns = os.environ.get("VODCUT_ICON") or ""
        mine = os.path.join(ROOT, "web", "app-icon-mac.png")   # icona che arriva con gli aggiornamenti (logo NoonFrame)
        if os.path.exists(mine):
            icns = mine
        if icns and os.path.exists(icns):
            img = NSImage.alloc().initWithContentsOfFile_(icns)
            if img is not None:
                NSApplication.sharedApplication().setApplicationIconImage_(img)
    except Exception:
        pass


def _mac_webkit_tweaks():
    """WKWebView di pywebview: i video partono anche senza clic (i video AI dell'anteprima sono muti e partono da soli
    mentre scorre la timeline; senza questo il Mac li blocca con NotAllowedError) e schermo intero degli elementi."""
    try:
        from webview.platforms import cocoa as C
        real = C.WebKit

        class _Alloc:
            def init(self):
                c = real.WKWebViewConfiguration.alloc().init()
                try:
                    c.setMediaTypesRequiringUserActionForPlayback_(0)
                except Exception:
                    traceback.print_exc()
                try:
                    c.setAllowsAirPlayForMediaPlayback_(False)
                except Exception:
                    pass
                try:
                    c.preferences().setElementFullscreenEnabled_(True)
                except Exception:
                    pass
                return c

        class _Cfg:
            @staticmethod
            def alloc():
                return _Alloc()

        class _WK:
            def __getattr__(self, n):
                return _Cfg if n == "WKWebViewConfiguration" else getattr(real, n)

        C.WebKit = _WK()
    except Exception:
        traceback.print_exc()


# ------------------------------------------------------------------ trascina e rilascia con il percorso vero del file
# Senza questo, un file trascinato nella finestra veniva ricopiato per intero passando dalla pagina: con una live da ore
# (decine di GB) la finestra si bloccava. Ora la finestra nativa ci dice dov'e' il file e lo si apre li', senza copie.
DROPS = []   # (nome, percorso, quando)


def _install_drop(win):
    if sys.platform == "darwin":
        return   # sul Mac pywebview legge gli eventi con eval(), che la nostra CSP vieta: si usa il caricamento normale
    def setup():
        try:
            from webview.dom import DOMEventHandler

            def on_drop(e):
                for f in ((e or {}).get("dataTransfer") or {}).get("files") or []:
                    p = f.get("pywebviewFullPath")
                    if p and os.path.isfile(p):
                        DROPS.append((str(f.get("name") or os.path.basename(p)), p, time.time()))
                del DROPS[:-30]
            win.dom.document.events.drop += DOMEventHandler(on_drop, False, False)
        except Exception as ex:
            print("[drop] percorsi dei file trascinati non disponibili:", ex, flush=True)
    try:
        win.events.loaded += setup
    except Exception:
        pass


def run_native_window_mac(url):
    import webview
    _mac_identity()
    _mac_webkit_tweaks()
    # niente js_api sul Mac: pywebview creerebbe le funzioni con new Function(), vietato dalla nostra CSP.
    # Lo schermo intero passa dal server (/api/window/fullscreen).
    api = MacApi()
    win = webview.create_window("NoonFrame", url, width=1440, height=900, min_size=(1000, 640), background_color="#161618",
                                text_select=True, zoomable=False)
    api._win = win
    NATIVE["api"] = api
    NATIVE["win"] = win
    _install_drop(win)
    webview.start(gui="cocoa", private_mode=False, storage_path=os.path.join(APP_DIR, "finestra-app"))


def run_native_window(url):
    """Finestra dell'app senza la barra del titolo di Windows: la barra in alto la disegna VODcut."""
    if sys.platform == "darwin":
        return run_native_window_mac(url)
    import webview
    try:  # la barra delle app raggruppa VODcut come app a se' (non come "Python")
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("VODcut.App")
    except Exception:
        pass
    api = WinApi()
    win = webview.create_window("NoonFrame", url, width=1440, height=920, min_size=(1000, 640), frameless=True, easy_drag=False,
                                background_color="#161618", js_api=api, text_select=True, zoomable=False)
    api._win = win
    NATIVE["win"] = win
    _install_drop(win)
    try:
        win.events.shown += lambda: api.set_icon()
    except Exception:
        pass
    try:
        webview.settings["DRAG_REGION_SELECTOR"] = ".vodcut-no-drag-region"
    except Exception:
        pass
    ico = os.path.join(ROOT, "vodcut.ico")
    try:
        webview.start(gui="edgechromium", private_mode=False, storage_path=os.path.join(APP_DIR, "finestra-app"),
                      icon=ico if os.path.exists(ico) else None)
    except TypeError:
        webview.start(gui="edgechromium", private_mode=False, storage_path=os.path.join(APP_DIR, "finestra-app"))


def watchdog(httpd):
    """Chiude il server quando la finestra e' chiusa da un po' e non c'e' lavoro in corso."""
    while True:
        time.sleep(10)
        if time.time() - LAST_PING[0] > 240 and not running_jobs():
            httpd.shutdown()
            return


def migrate_brand_windows():
    """VODcut, poi Nuvora, ora si chiama NoonFrame: su chi l'aveva gia' installato rinomina i collegamenti (desktop,
    menu Start) e il nome in Impostazioni > App. La cartella dell'app e i progetti restano dove sono. Una volta sola."""
    if sys.platform != "win32":
        return
    import ctypes
    from ctypes import wintypes
    mark = os.path.join(os.path.expanduser("~"), "VODcut", "nome-noonframe.txt")
    if os.path.exists(mark):
        return
    try:
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        for csidl in (0x10, 0x02):   # desktop, menu Start > Programmi
            buf.value = ""
            if ctypes.windll.shell32.SHGetFolderPathW(None, csidl, None, 0, buf) != 0 or not buf.value:
                continue
            new = os.path.join(buf.value, "NoonFrame.lnk")
            for oldname in ("Nuvora.lnk", "VODcut.lnk"):
                old = os.path.join(buf.value, oldname)
                if os.path.exists(old):
                    if os.path.exists(new):
                        os.remove(old)
                    else:
                        os.replace(old, new)
        import winreg
        for key, name, val in ((r"Software\Microsoft\Windows\CurrentVersion\Uninstall\VODcut", "DisplayName", "NoonFrame"),
                               (r"Software\Classes\VODcut.Progetto", "", "Progetto NoonFrame")):
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key, 0, winreg.KEY_SET_VALUE) as k:
                    winreg.SetValueEx(k, name, 0, winreg.REG_SZ, val)
            except OSError:
                pass
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)
        os.makedirs(os.path.dirname(mark), exist_ok=True)
        with open(mark, "w", encoding="utf-8") as f:
            f.write("collegamenti rinominati in NoonFrame\n")
    except Exception as e:
        print("[nome] non riesco a rinominare i collegamenti:", e)


def main():
    global PORT
    if not shutil.which("ffmpeg"):
        _fatal("Manca ffmpeg. Fai doppio clic su INSTALLA.bat e poi riapri NoonFrame.")
    no_window = "--no-window" in sys.argv
    native = not no_window and have_webview()
    # doppio clic su un file .vodcut: l'app si apre e lo importa
    open_arg = next((a for a in sys.argv[1:] if a.lower().endswith(".vodcut") and os.path.isfile(a)), None)
    qs_open = ("&open=" + urllib.parse.quote(os.path.abspath(open_arg))) if open_arg else ""
    if not no_window and not native:
        install_webview_bg()
    if port_in_use_by_us(PORT):
        # gia' aperta: apri solo un'altra finestra
        if not no_window:
            url = app_url(PORT, qs_open)
            if native:
                try:
                    run_native_window(url)
                    return
                except Exception:
                    traceback.print_exc()
            open_window(url)
        return
    PORT = free_port(PORT)
    threading.Thread(target=migrate_brand_windows, daemon=True).start()
    ensure_gpu_bg()
    if "--no-update" not in sys.argv:
        UPD.start_background(load_settings)
    FB.start_background()
    if sys.platform != "win32":
        try:
            os.chmod(APP_DIR, 0o700)    # i progetti e i video restano leggibili solo da questo utente del computer
        except OSError:
            pass
    def beta_guard():
        if load_settings().get("updateChannel") == "beta" and ACC.beta_access(max_age=0) is False:
            s = load_settings()
            s["updateChannel"] = "stable"
            save_settings(s)
            print("[update] beta non autorizzata: torno alle versioni stabili", flush=True)
    ACC.BETA_GUARD = beta_guard
    ACC.start_background()
    class Server(ThreadingHTTPServer):
        def handle_error(self, request, client_address):
            ex = sys.exc_info()[1]
            if isinstance(ex, (ConnectionResetError, BrokenPipeError, ConnectionAbortedError)) or getattr(ex, "errno", None) in (55, 10055):
                return
            super().handle_error(request, client_address)
    httpd = Server(("127.0.0.1", PORT), H)
    httpd.daemon_threads = True
    url = app_url(PORT, qs_open)
    print(f"NoonFrame {VERSION} su http://127.0.0.1:{PORT}/")
    if native:
        # il server gira in un thread, la finestra nativa tiene il thread principale
        srv = threading.Thread(target=httpd.serve_forever, daemon=True)
        srv.start()
        try:
            run_native_window(url)
        except Exception:
            traceback.print_exc()
            open_window(url)
            threading.Thread(target=watchdog, args=(httpd,), daemon=True).start()
            srv.join()
            return
        # finestra chiusa: i lavori "di servizio" (anteprime, miniature) si fermano subito; quelli veri
        # (es. esportazione) finiscono in background. Intanto questo server non ha piu' una finestra.
        NATIVE["win"] = None
        NATIVE["headless"] = True
        for j in running_jobs():
            if j.kind.startswith(DISPOSABLE_JOBS):
                j.cancelled = True
        while running_jobs():
            time.sleep(1)
        httpd.shutdown()
        return
    if not no_window:
        threading.Timer(0.4, lambda: open_window(url)).start()
    if "--keep-alive" not in sys.argv:
        threading.Thread(target=watchdog, args=(httpd,), daemon=True).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
